# Strings export ownership peer review — 2026-11-19

## Finding

**Both forced-export ownership defects are current production defects.** With `force=True`, the current writer can publish a foreign replacement at its staging pathname and return success. On an injected ordinary I/O failure, it can instead delete that foreign replacement during cleanup. The retained exclusive-staging and PR319 variants reproduce both failures. No complete forced repair was found among the inspected local path history and retained PR319 objects.

The retained work has useful scoped contributions: exclusive random staging, exclusive no-force publication, a later held-source no-force repair, and restoration of the original non-I/O cancellation boundary. These should be recovered with their exact provenance, without treating them as full forced ownership.

## Bound source and execution

- Actual production import: `/workspace/scratch/81e4938f4a3a/PatchTrace/src/patchtrace/strings/export.py` at `153f6cea8289547aa83acf85100e8c162631b77e`. Its blob `c642cc148f9f8d90373e679f81f46f8976c72537` is identical to the originally requested `7093ee68050fd81756b9e71573ce8c11fa2d3a7b`. Source SHA256: `837b511a9ea4b2c5b6edf0543655df0d78b2e076b68ab54a27d8018cbbf40ccc`.
- The root advanced during review; at report time HEAD is `5208c7589495cea749142f57599c4382be9caed5`. Export source still matches the immutable production snapshot: **True**.
- The production variant was actually imported from that path. Retained variants were loaded as unchanged complete Python modules from their Git objects; the retained owned-publication helper was loaded unchanged in the probe process. No export input was executed as code.
- Interpreter: primary CPython 3.12.14; shared dependencies were read only, with Pydantic 2.13.5 recorded. Root `.venv-main` was not used or modified.
- The 27 ownership schedules finished in 0.497 seconds. Only three small authored byte strings were written in fresh temporary directories. The old, new and foreign byte oracles, identities, hashes and before/after snapshots are retained in JSON before fixture removal. No original sample or external system was used.

## Exact forced schedule

1. Create an authored prior export at `report.json`.
2. Call the actual writer with authored expected new bytes and `force=True`. It writes, flushes and fsyncs its stage, then closes the stream.
3. At the `os.replace(stage, target)` call boundary, move the genuine stage to a separate authored path and create an authored foreign file at the former stage pathname. The previous target is still intact at this point.
4. For the success case, invoke the real `os.replace` with the substituted name. All three variants replace the old export with foreign bytes; the genuine expected bytes remain in the parked stage.
5. For the I/O failure case, raise an authored `OSError` after substitution but before the real replacement. All three variants keep the old target, then unlink the foreign staging entry and raise `PT-STR-EXPORT`.
6. Repeat the same boundary for `KeyboardInterrupt`, `SystemExit` and `RuntimeError`. The current and PR319 writers preserve the foreign name and propagate the identical exception. The intermediate exclusive-staging writer deletes the foreign name.

The success hook performs the real filesystem replacement; it does not fabricate the returned file contents. These runs executed on Linux. The post-close forced schedule avoids relying on the ability to rename an open file, but it is not native Windows qualification.

## All 27 ownership schedules

“Invariant held” describes the intended ownership check for that row. There are **14 held and 13 violated invariants** across the three historical variants; these are reproduced observations, not 27 green product-security tests. The probe exits zero because its explicit defect observations matched. “Foreign” means the authored replacement bytes.

| Source | Schedule | Target bytes afterward | Exception | Staging/concurrent-file observation | Invariant held |
|---|---|---|---|---|---|
| Current 153f6cea | F0 Normal forced replacement | expected new | none | normal control | yes |
| Current 153f6cea | F1 Source swap, successful replace | foreign | none | foreign source name consumed/deleted | **no** |
| Current 153f6cea | F2 Source swap, OSError | old | PT-STR-EXPORT | foreign source name consumed/deleted | **no** |
| Current 153f6cea | F3 Source swap, KeyboardInterrupt | old | KeyboardInterrupt | foreign source name preserved | yes |
| Current 153f6cea | F4 Source swap, SystemExit | old | authored interruption | foreign source name preserved | yes |
| Current 153f6cea | F5 Source swap, RuntimeError | old | RuntimeError | foreign source name preserved | yes |
| Current 153f6cea | F6 Preexisting PID staging file | expected new | none | prior PID stage overwritten/consumed | **no** |
| Current 153f6cea | N1 Destination arrives during fsync | expected new | none | concurrent destination overwritten | **no** |
| Current 153f6cea | N2 Source name swapped during fsync | foreign | none | substituted source published | **no** |
| Retained 2e37daf1 | F0 Normal forced replacement | expected new | none | normal control | yes |
| Retained 2e37daf1 | F1 Source swap, successful replace | foreign | none | foreign source name consumed/deleted | **no** |
| Retained 2e37daf1 | F2 Source swap, OSError | old | PT-STR-EXPORT | foreign source name consumed/deleted | **no** |
| Retained 2e37daf1 | F3 Source swap, KeyboardInterrupt | old | KeyboardInterrupt | foreign source name consumed/deleted | **no** |
| Retained 2e37daf1 | F4 Source swap, SystemExit | old | authored interruption | foreign source name consumed/deleted | **no** |
| Retained 2e37daf1 | F5 Source swap, RuntimeError | old | RuntimeError | foreign source name consumed/deleted | **no** |
| Retained 2e37daf1 | F6 Preexisting PID staging file | expected new | none | prior PID stage preserved | yes |
| Retained 2e37daf1 | N1 Destination arrives during fsync | foreign | PT-STR-EXPORT | concurrent destination preserved | yes |
| Retained 2e37daf1 | N2 Source name swapped during fsync | foreign | none | substituted source published | **no** |
| PR319 a56ab13 / f6c4b084 | F0 Normal forced replacement | expected new | none | normal control | yes |
| PR319 a56ab13 / f6c4b084 | F1 Source swap, successful replace | foreign | none | foreign source name consumed/deleted | **no** |
| PR319 a56ab13 / f6c4b084 | F2 Source swap, OSError | old | PT-STR-EXPORT | foreign source name consumed/deleted | **no** |
| PR319 a56ab13 / f6c4b084 | F3 Source swap, KeyboardInterrupt | old | KeyboardInterrupt | foreign source name preserved | yes |
| PR319 a56ab13 / f6c4b084 | F4 Source swap, SystemExit | old | authored interruption | foreign source name preserved | yes |
| PR319 a56ab13 / f6c4b084 | F5 Source swap, RuntimeError | old | RuntimeError | foreign source name preserved | yes |
| PR319 a56ab13 / f6c4b084 | F6 Preexisting PID staging file | expected new | none | prior PID stage preserved | yes |
| PR319 a56ab13 / f6c4b084 | N1 Destination arrives during fsync | foreign | PT-STR-EXPORT | concurrent destination preserved | yes |
| PR319 a56ab13 / f6c4b084 | N2 Source name swapped during fsync | expected new | none | anonymous source; no swappable name | yes |

F6 begins with a foreign regular file at the predictable PID-based staging name. The current `open(..., "wb")` truncates and consumes it; exclusive staging leaves it intact. N1 starts without a target and inserts a foreign destination during fsync; the current writer overwrites it. N2 substitutes a named source during fsync; the current and intermediate writers publish the replacement, while PR319 uses an anonymous held source with no replaceable staging name.

## Existing contributions and current state

| Source | Contribution available | Limitation |
|---|---|---|
| `2e37daf175533113fe73dc9a903f797a10ea9fc9` | Exclusive `mkstemp`, correct descriptor transfer, no-force hard-link publication, collision/predictable-name controls. | Both paths still publish by stage pathname. Its unconditional BaseException cleanup introduces the cancellation deletion regression. |
| PR319 `a56ab13aaf9916fc12bea70ba1494075991b7f09` | Runtime `owned_publication.py`, no-force existing-parent anchor, held-source publication, no content reuse, source/parent/collision tests; narrowed forced cleanup exception boundary. | Force still calls pathname `os.replace`, and its OSError handler still unlinks that pathname. |
| `f6c4b0844e5973ba054d58490628e77492d57ec0` | Same export blob as PR319: `28a79b13e0ae70d158a5ac2c3494311f9717bfdb`. | Same two forced defects; no additional forced repair. |
| Current `tools/research_qualification/winpairs.py` | Existing PW-01 Linux anonymous/descriptor-link publisher and rooted Windows source/parent handles, handle-bound discard, capability refusal normalization. | Exclusively no-replace; its native rename sets `ReplaceIfExists=False`. Runtime `src/patchtrace/owned_publication.py` is not present on the reviewed root. |

Retained documentation names original no-force source `6e0342ff5217552e14fb37739a4e529ca5db089b` (recovery `96f2f103`) and cancellation source `14f0e2c973dc5a9f6025aa6fa98138b1efe07023`. Those original commit objects were not locally resolvable. Their recovered source/tests and QA receipts are accessible through PR319 and were inspected; the provenance receipt preserves the failed original-object lookups rather than asserting ancestry.

The current production writer preserves non-I/O staging names because it catches only OSError. It does not contain the retained cancellation patch or the retained no-force ownership recovery. The current QA document’s open no-force clobber claim remains accurate. Retained documentation explicitly leaves force success-substitution and ordinary OSError cleanup blocked; the new observations corroborate it.

## Typed capability refusals

Four additional, separate probes checked the retained no-force adapter. Unsupported platform, missing O_TMPFILE and filesystem EOPNOTSUPP all become `PT-STR-EXPORT`, with no files left. A simulated unavailable descriptor-link operation raises raw `NotImplementedError`; no file is published, but the typed error contract is lost. Current PW-01 already normalizes that capability exception. A compatible port needs to carry that normalization forward instead of copying the retained adapter blindly.

## Concrete narrow repair plan and file ownership

### A. Recover no-force ownership

Recover the PR319 runtime helper and no-force adapter. Preserve the already-existing parent anchor, collision refusal for files/links/directories, refusal of identical-content reuse, and typed refusal when ownership primitives are unsupported. Normalize known capability failures, including `NotImplementedError`, to a bounded `PT-STR-EXPORT` message. Do not add a pathname publication fallback. Keep the current PW-01 tooling implementation unchanged during this recovery; runtime code should not import a research tool.

### B. Minimal force cleanup-only improvement

Recover exclusive random staging and correct descriptor ownership. On forced failures, close only descriptors owned by the attempt and **do not unlink a staging pathname**. Preserve the original exception: ordinary I/O failure remains `PT-STR-EXPORT`; cancellation and other non-I/O exceptions propagate unchanged. A prior lstat/fstat match is not authority to unlink a name that another writer may replace immediately afterward.

**Explicit tradeoff:** an unsuccessful forced export can leave its own complete or partial 0600 stage, or a foreign replacement, for inspection. Normal successful force replacement still consumes its stage. This requires explicitly splitting/updating the existing forced-OSError test that expects an empty directory; it must not be silently described as complete temporary-file cleanup. Retained-stage behavior and any revealed export data need to be documented by the owner. This bounded improvement closes the demonstrated foreign-name deletion path, but does not close successful source substitution.

### C. Keep full forced replacement separate

The existing native Windows class holds source and parent handles and discards the exact source, but its public rename operation is no-replace. An explicit separate replacement operation is a plausible design direction; the flag/semantics, sharing behavior, old-target preservation, reparse refusal and handle cleanup require native tests. No such force-capable implementation was found in the inspected sources.

The existing Linux anonymous-stage/exclusive-link primitive has no replacement operation. There is no qualified source-bound forced protocol to recover here. A pre/post-stat plus pathname rename, deleting the target before linking, or moving files and rolling back must not be credited as preserving atomic replacement. Keep this blocker until a supported protocol is qualified. A typed unsupported-force refusal is a separate behavior decision, not an implicit regression hidden in this recovery.

Proposed implementation ownership is limited to:

1. `src/patchtrace/owned_publication.py` — new retained runtime helper.
2. `src/patchtrace/strings/export.py` — adapter, typed capability boundary, exclusive staging and conservative forced-failure handling.
3. `tests/test_owned_publication.py` — retained helper controls; its current PW-01 test fixture dependency exists.
4. `tests/test_strings_export.py` — preserve output behavior and explicitly distinguish force/no-force failure cleanup.
5. `tests/test_strings_export_publication.py` — retained exclusive/collision controls.
6. `tests/test_strings_export_source_ownership.py` — retained no-force source/parent controls plus capability-error normalization.
7. `tests/test_strings_export_force_cancellation.py` — retained exception-identity and foreign-name controls.
8. `tests/test_strings_export_force_cleanup.py` — focused OSError foreign-name preservation and explicit residual-stage behavior.

Root/doc worker owns QA/spec/remaining-work edits, including the retained forced-success blocker. No modification to the PW-01 research tool is proposed in this slice. No repository or remote edit was made in this review.

### Qualification

Run focused export/CLI/shared-publication tests on the resulting head; preserve all 27 historical observations and add positive cleanup/no-force regressions against the new implementation. Keep the forced-success substitution receipt visibly red rather than counting it as repaired. Actual Windows filesystem/handle runs remain a separate required qualification. Neither source inspection nor Linux portable native-call assertions complete that gate.

## Evidence

`strings-ownership-peer-results-20261119.json` contains all 27 schedules, exact source snapshots, exception identity, byte oracles and file identities. `strings-ownership-peer-capability-results-20261119.json` contains the four capability checks. `strings-ownership-peer-provenance-20261119.json` maps recovered source and documents, available/unavailable commits, current PW-01 source and copied receipts. The companion review JSON contains machine-readable findings and the file ownership plan. All review artifacts use the `strings-ownership-peer-` prefix.
