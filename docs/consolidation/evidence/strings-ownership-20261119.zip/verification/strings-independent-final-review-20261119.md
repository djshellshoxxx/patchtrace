# Independent final review: strings publication recovery

Review date: 2026-11-19. Reviewer: `pe_metadata`. Scope: the eight runtime/test
paths prepared in `/tmp/pt81-strings-ownership`, based on
`5208c7589495cea749142f57599c4382be9caed5`, and their compatibility with the
integrator's preceding WB3 contract amendment. The contributor was still
preparing its provenance document at review time. No repository source, tests,
index, branch, or remote state was changed by this review.

## Decision

No remaining blocker was found for the authorized recovery of no-force
publication and the narrow repair of forced-failure cleanup. This decision does
not approve a claim that successful forced replacement binds either the source
or selected parent. Both successful-force substitution defects remain observed
and open. Native Windows behavior is not qualified by this Linux review.

The reviewed bytes are bound by
`strings-ownership-peer-batch7-source-manifest.json`, SHA256
`666089c407020adb65c4ca950db5466a3d937ac0f5159328210f4bdd6401abca`.
All eight files were independently checked against that manifest.

| Runtime path | Reviewed SHA256 |
| --- | --- |
| `src/patchtrace/owned_publication.py` | `b9f6d60a64b2c426f43c71d282805a48f4013445e408a3dd3b6fe520afeebedd` |
| `src/patchtrace/strings/export.py` | `61cade4a41cc7e79cdd7d193ecc4c5880c4fb742a858e017658c5b2cbe3b5850` |

## Source review

Compared the complete recovered helper with the retained PR319 helper blob
`71f3bbd5b74fb8ddfa212001e50ade82e4340354`, already preserved as
`strings-ownership-peer-owned-publication-a56ab13.py`. The only helper changes
are the two anchor-verification gates. In Linux traversal, missing components
cannot be created before the supplied anchor identity has been checked. In
Windows traversal, OPEN_IF is requested only below a checked anchor; above and
at that anchor, opens remain non-creating. Identity comparison precedes setting
the verification flag. Existing creation below a verified anchor is retained.

The no-force adapter acquires the selected existing parent's anchor and invokes
held-source publication without allowing existing-file reuse. Existing files,
including identical content and dangling links, therefore remain collisions.
NotImplementedError around both anchor acquisition and publication becomes a
fixed PT-STR-EXPORT capability error. Other ordinary I/O and owned-publication
failures retain the typed error boundary. The adapter does not turn arbitrary
RuntimeError, KeyboardInterrupt, or SystemExit into a capability failure. There
is no pathname-replacement fallback for an unsupported safe primitive.

Forced replacement creates an exclusive random stage. The raw descriptor remains
owned by the attempt until fdopen succeeds; the stream owns it thereafter. The
failure path closes an untransferred descriptor and performs no pathname unlink.
The stream context closes a transferred descriptor. The reviewed tests retain
exact original-byte, descriptor-closure, typed-error, and exception-identity
assertions. They include complete and partial residual stages and both owned
and substituted stage names. The code and contract explicitly permit residue,
including bytes that the user chose to reveal.

The existing no-force prepublication-failure control now injects fsync instead
of os.replace, which the new no-force implementation does not call. Its
PT-STR-EXPORT and empty-directory assertions remain. The recovered tests cover
concurrent destination creation, predictable-stage links, source and parent
substitution, cancellation, capability refusal, and no adoption of equal bytes.

Independent AST comparison against the base verifies that `_fail`, `selected`,
`_lineage`, `_record`, `document`, `_cell`, `_csv_row`, `render`, `export_delta`,
and `ExportResult` are unchanged. No serialization, digest, lineage, selection,
CSV/JSON, redaction, or result-shape change was introduced through those paths.

## Verification observed and performed

Read the contributor's exact command, source hashes, log, and JUnit receipt:
`strings-ownership-peer-batch7-focused-green-result.json`, `.log`, and `.xml`.
The selection includes six owned test modules and the existing strings CLI
module: **74 passed in 3.56 seconds**. That is the contributor's run, not an
additional independent run. Its retained-source red result, reported as 11
failed and three passed, remains preserved separately.

Performed four fresh, small controls against the exact recovered helper. The
first two used actual temporary Linux directories. The last two executed the
Windows directory method against a portable native-call model, with no Windows
filesystem or native NT operation:

1. Replaced an ancestor after capturing the selected leaf anchor. Publication
   refused with FileNotFoundError, created no child inside the foreign ancestor,
   preserved its marker bytes, and left the parked original leaf empty.
2. Published successfully into newly created descendants below a verified
   anchor, preserving the positive creation contract.
3. Supplied a mismatching Windows anchor identity. The sole descendant open was
   non-creating at the anchor; no child traversal occurred, and both opened
   handles were closed.
4. Supplied the matching Windows anchor identity. The selected anchor was opened
   with creation disabled, then child and leaf opens allowed creation. Every
   modeled handle was closed.

All four passed. Receipt: `strings-independent-final-probes-20261119.json`.
The process used isolated stdlib Python 3.12.14, directly loaded the exact helper,
made no network request, and removed its own temporary directories afterward.
No dependency installation or broad regression run was needed for this review.

## Remaining limits retained by the decision

Reviewed the contributor's fresh
`strings-ownership-peer-batch7-force-probe.json`, bound to the same exporter hash.
Both forced source substitution and forced parent substitution returned success
while publishing the authored foreign bytes. These are explicit unresolved
success-ownership defects. The forced OSError substitution schedule, in contrast,
returned PT-STR-EXPORT while preserving the prior output, the foreign stage, and
the parked original source. The narrow cleanup repair must not be credited as
repair of the two successful-force schedules.

No-force ownership is about the operation's held source and selected parent;
it is not permanent protection of a destination name after publication. A
post-publication verification failure can occur after a file has been linked or
renamed, so an error alone does not prove that no output exists. This review
does not qualify power-loss directory durability, all filesystems, live Windows
sharing/reparse behavior, or a complete release/CI acceptance gate.

The imported helper's optional bounded-reuse APIs retain their existing
implementation. Strings explicitly does not enable reuse. No tools package is
imported into runtime code; the helper uses the standard library only.

## Commit binding

The contributor subsequently committed the reviewed slice as
`397abd44325ccf6d37aa1f95c86383e305fb3b0e`, adding its own provenance document
as the ninth path. Independently loaded each of the eight reviewed runtime/test
blobs from that commit and verified all SHA256 values against the original
matched manifest. Receipt:
`strings-independent-final-commit-binding-20261119.json`. The decision above
therefore applies to those exact committed runtime/test bytes.
