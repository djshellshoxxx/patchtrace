"""Read-only source triage using only authored byte strings in temporary directories.

The application code is imported or loaded unchanged from retained git objects.
No export content is executed. The harness preserves all authored byte oracles
and outcome snapshots in JSON before temporary fixtures are removed.
"""
from __future__ import annotations
import datetime
import hashlib
import importlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import types
from unittest.mock import patch

ROOT = Path('/workspace/scratch/81e4938f4a3a/PatchTrace')
RECEIPTS = ROOT.parent / 'verification'
SHARED = Path('/workspace/scratch/80dddc5347b2/patchtrace-venv/lib/python3.12/site-packages')
BASE = '153f6cea8289547aa83acf85100e8c162631b77e'
REL = 'src/patchtrace/strings/export.py'
OLD = b'authored prior complete export\n'
NEW = b'authored expected new export\n'
FOREIGN = b'authored foreign replacement\n'
REAL_REPLACE = os.replace
REAL_FSYNC = os.fsync
sys.dont_write_bytecode = True
sys.path[:0] = [str(ROOT / 'src'), str(SHARED)]

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

def fingerprint(data):
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'hex': data.hex(),
            'text': data.decode('ascii')}

def snapshot(path):
    if not path.exists() and not path.is_symlink():
        return {'exists': False}
    info = path.lstat()
    result = {'exists': True, 'identity': [info.st_dev, info.st_ino], 'name': path.name,
              'is_symlink': path.is_symlink(), 'is_file': path.is_file()}
    if path.is_file() and not path.is_symlink(): result.update(fingerprint(path.read_bytes()))
    return result

def load_source(name, source, source_label):
    module = types.ModuleType(name)
    module.__file__ = source_label
    module.__package__ = name.rpartition('.')[0]
    sys.modules[name] = module
    exec(compile(source, source_label, 'exec'), module.__dict__)
    return module

current_source = (ROOT / REL).read_bytes()
assert current_source == git('show', f'{BASE}:{REL}'), 'current export code differs from selected production snapshot'
current = importlib.import_module('patchtrace.strings.export')
assert Path(current.__file__).resolve() == (ROOT / REL).resolve()
assert Path(current.__file__).read_bytes() == current_source
owned_source = git('show', 'a56ab13:src/patchtrace/owned_publication.py')
load_source('patchtrace.owned_publication', owned_source, 'git:a56ab13:src/patchtrace/owned_publication.py')
variants = [('current', BASE, current_source, current)]
for label, revision in [('exclusive_stage', '2e37daf1'), ('pr319', 'a56ab13')]:
    source = git('show', f'{revision}:{REL}')
    module = load_source('patchtrace.strings._ownership_peer_' + label, source, f'git:{revision}:{REL}')
    variants.append((label, revision, source, module))
assert git('show', f'a56ab13:{REL}') == git('show', f'f6c4b084:{REL}')
source_bindings=[]
for label, revision, source, module in variants:
    full = git('rev-parse', revision + '^{commit}').decode().strip()
    copy = RECEIPTS / ('strings-ownership-peer-source-' + label + '.py')
    copy.write_bytes(source)
    source_bindings.append({'label':label, 'commit':full, 'source_path':REL,
                            'git_blob':git('rev-parse', f'{revision}:{REL}').decode().strip(),
                            'source_sha256':hashlib.sha256(source).hexdigest(),
                            'receipt_source_copy':copy.name,
                            'load':'actual production import' if label=='current' else 'unchanged full module from retained git object'})
(RECEIPTS / 'strings-ownership-peer-owned-publication-a56ab13.py').write_bytes(owned_source)

results=[]
for label, revision, source, module in variants:
    for mode in ('normal_force', 'swap_success', 'swap_oserror', 'swap_keyboardinterrupt',
                 'swap_systemexit', 'swap_runtimeerror', 'predictable_stage_collision',
                 'no_force_concurrent_destination', 'no_force_source_substitution'):
        with tempfile.TemporaryDirectory(prefix='strings-ownership-peer-') as dirname:
            folder=Path(dirname); target=folder/'report.json'; parked=folder/'held-original-bytes'
            events=[]; stages=[]; error=None; injected=None
            force=not mode.startswith('no_force_')
            if force: target.write_bytes(OLD)
            expected_stage=target.with_name(f'.{target.name}.{os.getpid()}.tmp')
            if mode=='predictable_stage_collision': expected_stage.write_bytes(FOREIGN)
            before_target=snapshot(target)
            before_stage=snapshot(expected_stage)
            def replace(source_path, destination):
                stage=Path(source_path); stages.append(stage)
                events.append({'event':'replace_entry_after_stream_close', 'source':snapshot(stage), 'destination':snapshot(target)})
                if mode.startswith('swap_'):
                    REAL_REPLACE(stage, parked)
                    stage.write_bytes(FOREIGN)
                    events.append({'event':'source_name_substituted', 'parked_owned':snapshot(parked), 'source_name':snapshot(stage)})
                    if mode != 'swap_success':
                        error_type={'swap_oserror':OSError,'swap_keyboardinterrupt':KeyboardInterrupt,
                                    'swap_systemexit':SystemExit,'swap_runtimeerror':RuntimeError}[mode]
                        nonlocal_holder['injected'] = (error_type(13,'authored replace refusal') if error_type is OSError
                                                       else error_type('authored interruption'))
                        raise nonlocal_holder['injected']
                REAL_REPLACE(stage, destination)
                events.append({'event':'real_replace_returned', 'destination':snapshot(target)})
            def sync(descriptor):
                REAL_FSYNC(descriptor)
                if mode=='no_force_concurrent_destination':
                    target.write_bytes(FOREIGN)
                    events.append({'event':'destination_arrived_during_fsync','destination':snapshot(target)})
                elif mode=='no_force_source_substitution':
                    named=list(folder.glob('.*.tmp'))
                    if not named:
                        info=os.fstat(descriptor)
                        assert info.st_nlink==0
                        events.append({'event':'held_anonymous_source_has_no_substitutable_name','identity':[info.st_dev,info.st_ino]})
                    else:
                        assert len(named)==1
                        stage=named[0]; stages.append(stage)
                        REAL_REPLACE(stage,parked)
                        stage.write_bytes(FOREIGN)
                        events.append({'event':'source_name_substituted_during_fsync','parked_owned':snapshot(parked),'source_name':snapshot(stage)})
            nonlocal_holder={}
            try:
                with patch.object(os,'replace',replace), patch.object(os,'fsync',sync):
                    module.write_atomic(target,NEW,force=force)
            except BaseException as caught:
                error={'type':type(caught).__name__,'message':str(caught),
                       'code':getattr(caught,'code',None),
                       'same_injected_object':caught is nonlocal_holder.get('injected')}
            target_after=snapshot(target)
            stage_after=[snapshot(p) for p in dict.fromkeys(stages)]
            remaining={p.name:snapshot(p) for p in folder.iterdir()}
            record={'variant':label,'mode':mode,'force':force,'events':events,'target_before':before_target,
                    'predictable_stage_before':before_stage,'target_after':target_after,
                    'parked_owned_after':snapshot(parked),'observed_stage_names_after':stage_after,
                    'predictable_stage_after':snapshot(expected_stage),'remaining':remaining,'raised':error,
                    'outcome':{'target_is_old':target_after.get('hex')==OLD.hex(),
                               'target_is_expected_new':target_after.get('hex')==NEW.hex(),
                               'target_is_foreign':target_after.get('hex')==FOREIGN.hex(),
                               'foreign_source_name_survives':any(x.get('hex')==FOREIGN.hex() for x in stage_after),
                               'predictable_foreign_stage_survives':snapshot(expected_stage).get('hex')==FOREIGN.hex()}}
            if mode=='normal_force': assert error is None and record['outcome']['target_is_expected_new']
            if mode=='swap_success': assert error is None and record['outcome']['target_is_foreign']
            if mode=='swap_oserror':
                assert error and error['code']=='PT-STR-EXPORT' and record['outcome']['target_is_old']
                assert not record['outcome']['foreign_source_name_survives']
            if mode in ('swap_keyboardinterrupt','swap_systemexit','swap_runtimeerror'):
                assert error and error['same_injected_object'] and record['outcome']['target_is_old']
                assert record['outcome']['foreign_source_name_survives'] == (label!='exclusive_stage')
            if mode=='predictable_stage_collision':
                assert record['outcome']['target_is_expected_new']
                assert record['outcome']['predictable_foreign_stage_survives'] == (label!='current')
            if mode=='no_force_concurrent_destination':
                assert record['outcome']['target_is_foreign'] == (label!='current')
                assert bool(error) == (label!='current')
            if mode=='no_force_source_substitution':
                assert error is None
                assert record['outcome']['target_is_expected_new'] == (label=='pr319')
            results.append(record)

summary=[]
for label,revision,source,module in variants:
    cases={r['mode']:r for r in results if r['variant']==label}
    summary.append({'variant':label,
      'force_publishes_substituted_foreign_source':cases['swap_success']['outcome']['target_is_foreign'],
      'force_oserror_deletes_foreign_source_name':not cases['swap_oserror']['outcome']['foreign_source_name_survives'],
      'force_non_io_failures_preserve_foreign_name':all(cases[m]['outcome']['foreign_source_name_survives'] for m in ('swap_keyboardinterrupt','swap_systemexit','swap_runtimeerror')),
      'preserves_preexisting_predictable_stage':cases['predictable_stage_collision']['outcome']['predictable_foreign_stage_survives'],
      'no_force_preserves_concurrent_destination':cases['no_force_concurrent_destination']['outcome']['target_is_foreign'],
      'no_force_publishes_owned_source':cases['no_force_source_substitution']['outcome']['target_is_expected_new']})
receipt={'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
  'interpreter':sys.executable,'python':sys.version,'platform':sys.platform,
  'pydantic_version':importlib.metadata.version('pydantic'),
  'pydantic_origin':str(importlib.import_module('pydantic').__file__),
  'production_import':str(current.__file__),
  'head_at_finish':git('rev-parse','HEAD').decode().strip(),
  'source_still_matches_bound_current':(ROOT/REL).read_bytes()==current_source,
  'source_bindings':source_bindings,
  '7093_and_153f_export_blobs_match':git('rev-parse',f'7093ee68:{REL}')==git('rev-parse',f'{BASE}:{REL}'),
  'a56ab13_and_f6c4b084_export_blobs_match':True,
  'authored_byte_oracles':{'old':fingerprint(OLD),'new':fingerprint(NEW),'foreign':fingerprint(FOREIGN)},
  'fixture_policy':'Only these small authored byte strings were written in fresh temporary directories. No original sample was used and no export data was executed. Byte oracles and all outcomes are retained here before temporary-directory cleanup.',
  'interpretation':'Harness checks observed defect schedules; zero process exit is successful reproduction, not a green product-security test.',
  'summary':summary,'cases':results}
out=RECEIPTS/'strings-ownership-peer-results-20261119.json'
out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':str(out),'cases':len(results),'source_bindings':source_bindings,'summary':summary,
                  'pydantic_version':receipt['pydantic_version'],'source_still_matches_bound_current':receipt['source_still_matches_bound_current']},indent=2))
