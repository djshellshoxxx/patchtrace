# Independent strings publication design review — 2026-11-19

## Recommendation

Recover the retained held-source **no-force** publisher with two corrections:
normalize unsupported capability errors, including `NotImplementedError`, and
prevent directory creation before a supplied anchor has been verified. Repair
forced-failure cleanup by closing owned handles without unlinking a mutable
staging pathname. Keep successful forced replacement explicitly unresolved.

The current and retained force paths still select their source by pathname at
`os.replace`. Exclusive random staging and conservative cleanup improve those
paths, but do not bind a successful replacement to the original source inode.
The reviewed Linux primitives do not supply a drop-in held-source replacement.
A Windows handle-based replacement has a documented API design direction, but
requires its own implementation and native qualification.

This review made no repository, index, dependency, or remote change. It used
source inspection, primary OS documentation, the other reviewer's preserved
observations, and one independent small filesystem probe in a disposable
directory. It did not rerun the broad suite or claim Windows execution.

## Bound sources

| Source | Commit | Git blob |
|---|---|---|
| Current `src/patchtrace/strings/export.py` | `5208c7589495cea749142f57599c4382be9caed5` | `c642cc148f9f8d90373e679f81f46f8976c72537` |
| Current `tools/research_qualification/winpairs.py` | `5208c7589495cea749142f57599c4382be9caed5` | `d55f02578680f0234da6ebdbcd4b456182169d06` |
| Retained `src/patchtrace/strings/export.py` | `a56ab13aaf9916fc12bea70ba1494075991b7f09` | `28a79b13e0ae70d158a5ac2c3494311f9717bfdb` |
| Retained `src/patchtrace/owned_publication.py` | `a56ab13aaf9916fc12bea70ba1494075991b7f09` | `71f3bbd5b74fb8ddfa212001e50ade82e4340354` |

`strings-independent-source-bindings-20261119.json` records full SHA-256 hashes
and lengths. The retained helper used by the independent probe was byte-compared
with its Git object. The root-owned live WB3 specification amendment was also
read; this review does not assign that evolving document to the source commits
above. Runtime code should consume a runtime helper, without importing PW-01
research tooling.

## R1 — Correct creation before anchor verification

**Confirmed additional defect in the retained helper.** `publish_linux` and
`publish_windows` request directory creation during traversal even when an
existing `DirectoryAnchor` was supplied. The identity check occurs when traversal
reaches the anchor. Earlier missing components can therefore be created inside
a replacement ancestor before the mismatch is noticed.

The independent Linux schedule was:

1. Create `selected/leaf` and capture `directory_anchor(selected/leaf)`.
2. Rename `selected` to `parked`, then create a foreign `selected` directory
   containing one marker file.
3. Call the unchanged retained `publish_bytes(selected/leaf/out.json, data,
   anchor=anchor)`.

The call raises `OwnedPublicationError` for the identity mismatch and publishes
no export bytes. Nevertheless, it creates `selected/leaf` inside the foreign
replacement. The original anchored leaf and foreign marker remain intact. This
violates the intended preexisting-parent boundary even though source publication
itself is refused. Evidence: `strings-independent-anchor-create-20261119.json`.

For a supplied anchor, allow creation only **below an already verified anchor**.
Before reaching it, missing ancestors and the anchor itself must fail without
`mkdir` or Windows `OPEN_IF`. Preserve generic creation below a verified root and
the existing behavior for callers that deliberately supply no anchor. Verify the
anchor before creating descendants, including when it is a filesystem root.

The Windows traversal has the equivalent source-level ordering problem; that
observation is not a native reproduction. The implementation worker and root
were notified, and the worker accepted Linux and Windows traversal controls plus
a positive below-anchor creation case.

## R2 — Preserve the no-force ownership and typed-error boundaries

The retained Linux route writes and verifies an anonymous `O_TMPFILE` through an
owned descriptor, then links that descriptor into a held destination directory.
Its Windows route creates the stage relative to a held native parent, denies
write/delete sharing on the source, and renames that held source without replacing
an existing destination. Both designs avoid publishing a substituted staging
pathname. Preserve those properties and keep existing-content reuse disabled for
strings export, even when the bytes match.

The current PW-01 wrapper handles `OSError`, `NotImplementedError`, and missing
capability attributes. The retained strings adapter catches only `OSError` and
`OwnedPublicationError`; the peer's descriptor-link probe consequently exposes a
raw `NotImplementedError`. Normalize supported capability refusals across both
anchor acquisition and publication into bounded `PT-STR-EXPORT` text. Keep
`FileExistsError` distinct. Do not introduce a pathname fallback or catch
cancellation as an unsupported capability.

Portable controls should cover unsupported dispatch, missing anonymous staging,
filesystem refusal, unavailable descriptor linking, and unavailable directory
primitives. They must retain existing/concurrent files and propagate non-I/O
exceptions according to the public boundary. Parent or destination changes
detected after publication can leave a published file while returning an error;
the caller must not infer that every error means nothing was written.

The helper's held-source guarantee concerns the source and parent used by the
publication operation. It does not make the destination immutable against later
writers, nor establish power-loss durability. File fsync alone is not a recorded
directory-durability qualification in this slice.

## R3 — Forced cleanup can be repaired separately

The current OSError handler unlinks the staging pathname after that name may
have been replaced. The retained force adapter still does this. Removing every
failure-path pathname unlink closes the reproduced foreign-file deletion route.
Keep exclusive random staging and descriptor ownership transfer: if `fdopen`
fails, close the still-owned raw descriptor; after transfer, the stream owns it.

Retain the original error boundary: ordinary I/O errors become `PT-STR-EXPORT`;
`KeyboardInterrupt`, `SystemExit`, and other non-I/O exceptions propagate without
being replaced by a cleanup error. An identity check immediately before unlink
cannot authorize a later pathname mutation; another writer can replace the name
between those operations.

**Accepted tradeoff requiring an explicit contract:** complete or partial own
stages can remain after failure, and foreign replacement stages remain intact.
Such residues can contain intentionally revealed strings. Do not claim complete
temporary-file cleanup or hide the retained-data behavior. A future cleanup
mechanism needs its own authority; a later filename/hash match is not an atomic
delete primitive.

Separate the existing failure test by operation. Its `os.replace` injection no
longer exercises the no-force path. Keep a real prepublication failure control
for no-force, and explicitly verify retained stages plus prior-target bytes for
forced failure. Preserve the peer's successful forced source-substitution
observation as an open defect rather than counting cleanup success as its repair.

## R4 — Force-success primitive feasibility

| Approach | Assessment |
|---|---|
| Linux descriptor link | Binds the source descriptor, but refuses an existing destination; useful for no-force publication. |
| Linux `renameat` / `renameat2` | Directory descriptors anchor directories; the source remains a name resolved at the operation. The documented exchange flag exchanges two names. Neither is a recovered descriptor-to-replace primitive. |
| Link a held descriptor to a new name, then rename that name | Reintroduces the source-name substitution interval before rename. |
| Check before rename or validate after rename | A check before the operation leaves a race; a check afterward can discover foreign bytes only after they have replaced the prior target. |
| Unlink target, then link source | Loses atomic replacement and can destroy the prior target before the new link succeeds. |
| Exchange and roll back after verification | Publication has already changed names; another actor can intervene before rollback. It does not establish the required failure-preservation guarantee. |
| Windows native source-handle rename with replacement requested | A feasible separate design candidate, not an implemented or qualified guarantee in the inspected helper. |

The Linux manual documents name-based replacement for `rename`, directory-relative
names for `renameat`, and the named-entry exchange/noreplace flags for `renameat2`.
It documents descriptor-assisted linking separately and an existing-destination
error for `link`. This supports the limited conclusion that these reviewed calls
do not provide the missing portable forced primitive; it is not a proof that no
other platform-specific protocol could ever be designed.
[rename(2)](https://www.man7.org/linux/man-pages/man2/rename.2.html),
[link(2)](https://man7.org/linux/man-pages/man2/link.2.html).

Microsoft documents `NtSetInformationFile` operating on an existing source handle
and `FileRenameInformation` using a replacement flag and a destination root
handle. The retained helper already passes the source handle, but sets
`ReplaceIfExists=False`. A separate replacement operation could retain this
source-handle boundary and exact-handle discard. It must qualify access/share
rules, existing target handles, readonly targets, reparse/path changes, filesystem
support, synchronous completion, and failures around the publication point.
[NtSetInformationFile](https://learn.microsoft.com/en-us/windows-hardware/drivers/ddi/content/ntifs/nf-ntifs-ntsetinformationfile),
[FILE_RENAME_INFORMATION](https://learn.microsoft.com/windows-hardware/drivers/ddi/ntifs/ns-ntifs-_file_rename_information).

Keep the immutable-evidence `publish_bytes` operation no-replace. Do not silently
turn it into a force-capable API or treat a Windows design sketch as a Linux
solution. A new typed refusal of all forced exports would be a separate product
behavior change, requiring explicit scope and specification.

## Evidence and next review

The other reviewer's `strings-ownership-peer-results-20261119.json` and capability
receipt preserve its 27 authored schedules and four capability controls. Those
are attributed peer observations, not new runs by this reviewer. This independent
review corroborates their mechanism from the bound source and adds the anchor
creation reproduction above.

The implementation worker is preparing the scoped port in
`/tmp/pt81-strings-ownership`. Review its resulting diff for the anchor-creation
gate, typed capabilities, absence of failure-path pathname deletion, unchanged
format/digest semantics, and preserved cancellation behavior. Native Windows and
full force-success qualification remain open. The current report approves the
bounded design direction with R1/R2 addressed; it does not approve an unseen
implementation or close the forced-success defect.
