from pathlib import Path
import datetime,errno,importlib,json,os,sys,tempfile,types
from unittest.mock import patch
ROOT=Path('/workspace/scratch/81e4938f4a3a/PatchTrace')
OUT=ROOT.parent/'verification'
sys.dont_write_bytecode=True
sys.path[:0]=[str(ROOT/'src'),'/workspace/scratch/80dddc5347b2/patchtrace-venv/lib/python3.12/site-packages']
def load(name,path):
 module=types.ModuleType(name); module.__file__=str(path); module.__package__=name.rpartition('.')[0]
 sys.modules[name]=module; exec(compile(path.read_bytes(),str(path),'exec'),module.__dict__); return module
owned=load('patchtrace.owned_publication',OUT/'strings-ownership-peer-owned-publication-a56ab13.py')
export=load('patchtrace.strings._ownership_peer_capability',OUT/'strings-ownership-peer-source-pr319.py')
original_open=os.open; tmpflag=os.O_TMPFILE
results=[]
for mode in ('unsupported_platform','missing_O_TMPFILE','filesystem_refuses_O_TMPFILE','descriptor_link_not_implemented'):
 with tempfile.TemporaryDirectory(prefix='strings-ownership-peer-capability-') as directory:
  target=Path(directory)/'report.json'; caught=None
  def unavailable_open(path,flags,*args,**kwargs):
   if flags & tmpflag == tmpflag: raise OSError(errno.EOPNOTSUPP,'authored anonymous staging refusal')
   return original_open(path,flags,*args,**kwargs)
  def unavailable_link(*args,**kwargs): raise NotImplementedError('authored exact-descriptor link unavailable')
  try:
   if mode=='unsupported_platform':
    with patch.object(sys,'platform','ownership-peer-unsupported'): export.write_atomic(target,b'authored small export',force=False)
   elif mode=='missing_O_TMPFILE':
    del os.O_TMPFILE
    try: export.write_atomic(target,b'authored small export',force=False)
    finally: os.O_TMPFILE=tmpflag
   elif mode=='filesystem_refuses_O_TMPFILE':
    with patch.object(os,'open',unavailable_open): export.write_atomic(target,b'authored small export',force=False)
   else:
    with patch.object(os,'link',unavailable_link): export.write_atomic(target,b'authored small export',force=False)
  except BaseException as exc: caught={'type':type(exc).__name__,'code':getattr(exc,'code',None),'message':str(exc)}
  result={'mode':mode,'raised':caught,'typed_export_refusal':caught is not None and caught['code']=='PT-STR-EXPORT','remaining_entries':[p.name for p in Path(directory).iterdir()]}
  assert caught and result['remaining_entries']==[]
  results.append(result)
receipt={'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':'unchanged PR319 a56ab13 export and owned_publication copies','scope':'Four additional capability-error normalization probes, separate from the27 ownership schedules; authored small bytes only.','results':results}
path=OUT/'strings-ownership-peer-capability-results-20261119.json'; path.write_text(json.dumps(receipt,indent=2)+'\n'); print(json.dumps(receipt,indent=2))
