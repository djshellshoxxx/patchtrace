"""Small authored-data controls; never execute export content."""
from __future__ import annotations
import datetime
import hashlib
import json
import os
from pathlib import Path
import tempfile
from unittest.mock import patch

from patchtrace.strings import export
from patchtrace.strings.contracts import StringsError

EXPECTED = b"authored expected export"
FOREIGN = b"authored foreign replacement"
PREVIOUS = b"authored previous export"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.is_file() else None


def run():
    receipts = []
    real_replace = os.replace
    for schedule in ("force-source-substitution-success", "force-parent-substitution-success", "force-io-cleanup-substitution"):
        with tempfile.TemporaryDirectory(prefix="pt81-strings-force-probe-") as name:
            root = Path(name)
            selected = root / "selected"
            selected.mkdir()
            target = selected / "report.json"
            target.write_bytes(PREVIOUS)
            owned = root / "parked-owned-stage"
            parked = root / "parked-parent"
            observations = {}

            def intercept(stage, destination):
                stage = Path(stage)
                assert Path(destination) == target
                assert stage.read_bytes() == EXPECTED
                observations["injection_point"] = "os.replace after the source stream context exits"
                if schedule == "force-parent-substitution-success":
                    selected.rename(parked)
                    selected.mkdir()
                    (selected / "foreign-marker").write_bytes(b"authored foreign marker")
                    stage.write_bytes(FOREIGN)
                else:
                    real_replace(stage, owned)
                    stage.write_bytes(FOREIGN)
                observations["stage_name"] = stage.name
                if schedule == "force-io-cleanup-substitution":
                    raise OSError(13, "authored replacement refusal")
                return real_replace(stage, destination)

            with patch.object(export.os, "replace", intercept):
                try:
                    export.write_atomic(target, EXPECTED, force=True)
                except StringsError as error:
                    observations["outcome"] = error.code
                    observations["message"] = error.message
                else:
                    observations["outcome"] = "returned successfully"
            stage = selected / observations["stage_name"]
            observations.update(target_sha256=digest(target), stage_sha256=digest(stage),
                                parked_source_sha256=digest(owned))
            if schedule == "force-io-cleanup-substitution":
                assert target.read_bytes() == PREVIOUS
                assert stage.read_bytes() == FOREIGN
                assert owned.read_bytes() == EXPECTED
                assert observations["outcome"] == "PT-STR-EXPORT"
                observations["cleanup_preserved_foreign_name_and_previous_export"] = True
            else:
                assert target.read_bytes() == FOREIGN
                assert observations["outcome"] == "returned successfully"
                observations["successful_force_source_ownership_invariant"] = False
                if schedule == "force-parent-substitution-success":
                    assert (parked / "report.json").read_bytes() == PREVIOUS
                    assert (parked / observations["stage_name"]).read_bytes() == EXPECTED
                    assert (selected / "foreign-marker").read_bytes() == b"authored foreign marker"
                    observations["original_parent_previous_export_preserved"] = True
                    observations["successful_force_parent_ownership_invariant"] = False
                else:
                    assert owned.read_bytes() == EXPECTED
            receipts.append({"schedule": schedule, **observations})
    return {"observed_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "source": str(Path(export.__file__)),
            "source_sha256": hashlib.sha256(Path(export.__file__).read_bytes()).hexdigest(),
            "platform": os.name, "fixture_scope": "authored bytes in temporary directories; no target execution",
            "expected_sha256": hashlib.sha256(EXPECTED).hexdigest(),
            "foreign_sha256": hashlib.sha256(FOREIGN).hexdigest(),
            "previous_sha256": hashlib.sha256(PREVIOUS).hexdigest(),
            "qualification": "Linux observations only; success-binding defects remain open", "schedules": receipts}


if __name__ == "__main__":
    print(json.dumps(run(), indent=2))
