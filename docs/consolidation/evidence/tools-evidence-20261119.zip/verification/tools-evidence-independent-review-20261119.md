# Independent review: batch 8 evidence handling

Review date: 2026-11-19. Reviewer: `pe_metadata`.

## Decision and binding

No remaining blocker was found in the reviewed scope of commit
`45828168056e67a3ca419483d9582b9b0660f651`. The review found a material
partial-output defect in the first Windows sampler correction; that defect was
reproduced, preserved, corrected, and independently replayed before approval.

The two committed implementation blobs were independently loaded from Git and
checked against the exact bytes used by the final probes:

| Path | SHA256 |
| --- | --- |
| `tools/bundle_acceptance.py` | `bfa83ab49e6ee7c4d7acd560b701f2429b3ecdd542e699cce8329552c3fd85a2` |
| `tools/unified/gates_u.py` | `91e216e382ac121428903c39ec97ad83e6a0cd5eb01a54cc419e2af1e7ba0431` |

Binding receipt: `tools-evidence-independent-commit-binding-20261119.json`.
Reviewed the complete two-tool diff, both amended specifications, the new health
tests, added JUnit admission controls, the existing Windows-branch fixture
adjustment, and `RECOVERY_BATCH_8.md`. No repository source, tests, index, branch,
or remote state was changed by this review.

## Material finding and correction

The first correction rejected failed Windows polls but discarded stdout before
recording any endpoints. A nonzero process result and a TimeoutExpired result
can both contain bytes already emitted by the sampler. Authored offline probes
supplied `203.0.113.9:443` on the failed first poll, followed by three successful
empty polls. Both yielded four attempts, three successful observations, one
error, and an empty seen set. The exact acceptance predicate, extracted from
the candidate's AST, evaluated to true.

Original receipt: `tools-evidence-independent-partial-windows-20261119.json`,
bound to the first-correction source SHA256
`8355f5e5dad98bb829ba19218346a21463839e27fffacbc635d7c8a854e2ffac`.
This receipt remains unchanged. The contributor added three failing regressions
for nonzero exit stdout and byte/text timeout stdout before applying the repair.

The committed Windows sampler now returns an error ConnectionSample carrying
those endpoints. A timeout's byte output is decoded before tokenization; text
output is also retained. ConnectionMonitor updates seen endpoints independently
of whether the observation is successful. All three corrected schedules retain
the endpoint and refuse the gate despite the three later healthy empty polls.

## Health accounting and compatibility

`polls` retains the meaning of attempted samples. Successful observations,
sampling errors, and unavailable observations have separate counters. The
consumer requires at least three successful observations and an empty seen set.
An error is recorded as an observation-health failure, without modifying the
separate positive-control result or declaring that the OS block itself failed.

Linux sampling returns unavailable when the child has not left the host network
namespace or its namespace/tables have disappeared. Other table-read failures
are errors. Endpoints read from either table survive a failure reading the other.
Complete empty tables remain a successful observation. Windows nonzero exit,
timeout, and missing-process-tool cases cannot become healthy empty samples;
successful empty stdout remains a legitimate observation.

Existing list-returning sampler callbacks remain supported. The acceptance JSON
schema identifier is unchanged; health counters and sorted endpoints are
additive fields in the existing step data. Historical polls-only evidence is
explicitly insufficient to establish successful observation coverage. The diff
does not alter the OS-block positive control, timing/performance thresholds,
comparison success requirement, or before/after digest requirement.

The existing POSIX test of the Windows orchestration branch previously depended
on unavailable PowerShell being ignored. Its fixture now explicitly supplies
three authored successful empty samples. The test's existing ordering, command,
positive-control, and digest assertions remain. This is appropriate fixture
correction; it is not native sampler evidence.

## Bounded JUnit admission

The CLI's JUnit path now opens in binary mode and requests at most 8 MiB plus
one sentinel byte. Oversize data is refused with ContractError before parsing.
Each admitted file is parsed and hashed before opening the next, instead of
retaining a list of all raw XML bodies. Explicit --junit and --inputs discovery
reach the same bounded reader. Admission and read errors occur before replacing
an existing JSON or Markdown report.

The direct parser retains its original size, UTF-8, NUL, DTD/entity, XML syntax,
root, and outcome behavior. Gate-report schema, digest ordering, outcome merge
order, gate evaluation, and strict/advisory exit policy remain unchanged. This
is a per-file read limit, not a claim of bounded aggregate file count, merged
outcomes, total parser memory, or a filesystem read deadline.

## Independent verification

Seven fresh controls passed against the exact final implementation hashes:

1. Three OSError attempts record zero successful observations and cannot pass.
2. Windows nonzero exit stdout survives three later healthy empty observations.
3. Windows timeout byte stdout survives the same recovery sequence.
4. Windows timeout text stdout survives the same recovery sequence.
5. A Linux endpoint survives a later table PermissionError without incrementing
   the successful counter.
6. Three successful empty observations still satisfy the connection predicate.
7. The actual 8 MiB JUnit budget requests exactly 8,388,609 bytes, refuses the
   sentinel overflow before calling the parser, closes the stream, returns CLI
   exit 2, and preserves a previously written report.

Receipt: `tools-evidence-independent-final-probes-20261119.json`. The predicate
used by the monitor controls was compiled from the reviewed consumer AST,
avoiding a separately guessed gate expression. The process used the contributor's
isolated interpreter with -I -B; patchtrace, bundle_acceptance, and gates_u import
origins were checked against the contributor's checkout. All subprocesses and
thread starts were replaced by authored fixtures for the sampler schedules. No
process, thread, socket, native Windows command, or target binary was executed
by these controls. No dependencies were installed.

Read the contributor's final affected log and JUnit result: **111 passed, three
skipped in 4.48 seconds** across the four affected test files. These are the
contributor's pytest results, not an additional independent suite run. The three
existing skips require Linux unshare --net: dry-run denial/digest equality,
missing control baseline, and launcher mutation detection. Their exact names
and reasons are recorded in the commit-binding receipt.

## Limits retained

Sampling remains supplementary and can miss brief activity. The Windows query
still covers the named child PID, not every descendant; three successful polls
do not establish continuous observation. Native Windows firewall/ACL/sampler
acceptance and the unavailable Linux namespace checks remain separate gates.
The existing positive control remains required. No timing or performance gate
was relaxed, and no full current-head suite or release acceptance is asserted.
