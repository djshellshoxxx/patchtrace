# Independent triage of candidate groups 26 and 27

## Group 26: environment restriction

`tests/test_network_consent_guard.py::test_a_local_unix_socket_is_not_network`
fails constructing `socket.socket(AF_UNIX)` with `PermissionError: [Errno 1]`.
It has not entered `NetworkGuard` yet. In fresh isolated Python, both the Python
and raw `_socket` constructors fail with EPERM before importing PatchTrace or
pytest. This establishes an environment capability restriction rather than an
application guard failure or dependence on earlier tests. The host enforcement
mechanism is not identified. Keep this acceptance blocked on this runner and
execute the unchanged test on a host supporting AF_UNIX; do not weaken assertions.

Original group: 1 failed, 266 passed, 48 skipped in 13.43s. Preserve that outcome.

## Group 27: test teardown and immediate cleanup

Both parameterizations of
`tests/test_nway_recovery_copy_20261105.py::test_new_copy_descriptor_closed_on_setup_failure`
(`fstat`, `fdopen`) pass their test bodies, then error in teardown. Their
`capture_open(candidate, flags, *args)` replaces the process-wide `os.open`
through `store.os` but does not accept `dir_fd`. The partition runner sets
`tmp_path_retention_policy=failed`; pytest then removes a passing test's directory
inside `tmp_path` teardown while the monkeypatch fixture is still active.
`shutil.rmtree` calls `os.open(..., dir_fd=...)`, causing the recorded TypeError.
pytest-qt wraps teardown but is not the failing implementation here.

The isolated two-case replay reproduces **2 passed, 2 errors in 1.23s** with
failed retention. With all retention, the same cases and assertions yield
**2 passed in 1.13s**. No preceding tests are needed. Both affected test files and
`tests/conftest.py` are byte-identical to main `fdc2696c`. This is an existing
mock/fixture-lifetime issue exposed by the diagnostic cleanup setting, not
evidence of a new N-way runtime regression.

The narrow repair is to scope the OS patches with `monkeypatch.context()` and
restore them before temporary-directory teardown. Preserve every original
assertion: typed storage error, exactly one created descriptor, descriptor closure
checked through the original fstat, and unchanged damaged input bytes. Keyword
forwarding alone addresses the visible TypeError but leaves global fault injection
active during unrelated cleanup, including possible descriptor-number reuse.
The all-retention replay is a diagnostic contrast, not a reason to erase the
original errors or call the group qualified.

Original group: 304 passed, 1 warning, 2 errors in 14.08s. No product, test, tool,
fixture or frozen-candidate file was changed during this review. The isolated
interpreter resolves PatchTrace and N-way code under `/tmp/pt81-candidate`.

## Receipts

The sibling `partition26-27-peer-triage.json` retains source comparisons, exact
original receipt hashes, environment observations and narrow-run suite counts.
Original group logs/JUnit were copied to `partition26-peer-original.*` and
`partition27-peer-original.*`. Replays are
`partition27-peer-failed-retention.{log,xml}` and
`partition27-peer-all-retention.{log,xml}`. The bare constructor probe is
`partition26-27-peer-environment.json`.
