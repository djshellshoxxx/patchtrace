# PR #322 CI queue and qualification review

Observed 2026-11-19 11:59:05 UTC. Read-only REST inspection plus unchanged workflow source at local `d7842532`, whose workflow bytes match the published candidate.

## Exact source and queue

PR #322 is open and draft at `32cc4b04cf1f5b9e69d1d0e8691db7083c7a45a7`; base/main is `fdc2696c23bdbfe7668348f25e3b336ce33039f7`. Compare: ahead 2, behind 0; mergeable true, mergeable state unstable.

All five candidate workflow runs remain queued. Twenty-one substantive jobs are instantiated with runner ID 0, no runner name, no steps and null conclusion. Their populated started_at fields do not establish execution. The QA release-gate is intentionally skipped on a pull request.

| Workflow | Run IDs | Required observations for this candidate |
| --- | --- | --- |
| QA and Windows standalone | 44517577038 | Both full QA legs (Linux/Windows), all five repeated Qt legs, downstream Linux package and both Ubuntu smoke legs. Windows QA includes frozen executable, portable ZIP and install/launch/uninstall checks. |
| Native Windows Ghidriff | PR 44517576866; push 44517464281 | Five native variants per triggered run: clean, seeded store, no adjacent PDB, raw cache hit, and intentional upstream failure reproduction. Do not use another head's native results. |
| Live rizin rz-diff | 44517576844 | Linux and Windows pinned-tool jobs and passed JSON receipts. |
| Live BinDiff | 44517577122 | Linux and Windows job conclusions plus actual provision/live status JSON; Windows live execution is advisory in this workflow. |

QA downstream Linux package, two smoke jobs and skipped release job have not yet appeared because prerequisite jobs have not finished. The four triggered workflow definitions contain no draft condition. Their concurrency keys include workflow, event and ref, so native push and PR runs have different groups.

QA pending_deployments returned an empty list. No observed run has an approval-required status or message. Repository rulesets returned an empty list; main reports protected=false and no required status contexts. This does not waive the owner's all-test-jobs-green/no-blocker rule in AGENTS.md.

The repository snapshot contained 25 queued runs and one in-progress workflow on another branch (run 44502066991, PR318 head c4ace2088). That workflow had five active runner jobs, two successful jobs and a skipped release-gate. Some runners are operating. The exact cause of PR322's wait is not exposed by the available metadata; capacity, billing and workflow-level concurrency are not established causes.

## Qualification boundaries

The Windows BinDiff provisioner can record blocked extraction/runtime qualification while exiting zero in advisory mode. The Windows live-test step uses continue-on-error. The status summarizer is called without --fail-on-failed. Live BinDiff's optional cancellation/network controls can also produce an overall blocked receipt without a pytest failure. A green workflow must therefore be accompanied by inspection of uploaded live status JSON before claiming full native compatibility.

The non-gating Windows BinExport memory-cap measurement has continue-on-error. A successful QA job does not certify that measurement or manual clean-machine/accessibility acceptance.

The sole external status is Snyk success with description “No manifest changes detected in 1 project.” This is not evidence of a fresh vulnerability audit.

The ready-for-review connector operation explicitly documents a GraphQL mutation. Current AGENTS.md requires REST-only operations. No ready transition was attempted. Resolve that capability constraint at the qualified-head delivery step; do not quietly use the GraphQL tool.

## Final merge preflight

1. Refresh the final PR head and current main; recompute compare/mergeability and confirm the reviewed tree. These observations qualify only the recorded head.
2. Enumerate every current-head workflow/check/status, including downstream jobs and newest attempts. All applicable test jobs must have actual successful conclusions; missing, queued, cancelled or failed required jobs remain unresolved.
3. Read QA/native artifacts for actual outcomes and advisory blocked/failed details. Preserve platform skips, layer-specific accuracy limits and outstanding acceptance requirements.
4. Resolve blocking review/findings, satisfy draft readiness through an allowed mechanism, and retain source branches.
5. Merge through REST with the exact expected head SHA and an explicit [no release] merge message; verify resulting main commit/tree and subsequent main checks.

No workflow changes, dispatches, cancellations, approvals, ready transitions, PR mutations or merges were performed. No site/tools/site/Pages workflow changes were present in the reviewed source; release/backend-bundle workflows were not dispatched.

Sources: GitHub REST pull322, branchmain, head compare/check-runs/status/actions-runs, each run's jobs, QA pending_deployments, repository rulesets; local AGENTS.md, .github/workflows/{qa-windows,live-backend,live-rizin,live-bindiff,pages}.yml, tools/{provision_bindiff,check_live_status,live_rzdiff_check,release_gate}.py, tests/test_live_bindiff.py. Compact raw observations are in ci322-queue-review-20261119.json. The branch-specific /rules/branches/main endpoint was rejected by connector allowlisting; no absence of rules was inferred from that rejection.
