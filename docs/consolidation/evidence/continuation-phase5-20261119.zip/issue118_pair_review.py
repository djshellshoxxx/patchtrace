"""Read-only source audit: authored offline observations plus retained c3868d83 assertions.

Only temporary test projects and this review's JSON receipts are written. Existing
root/candidate checkout files are untouched. Synthetic PE bytes are never executed.
"""
from __future__ import annotations

import json
from pathlib import Path

import pytest
from kbc_k1_support import no_sockets  # noqa: F401
from test_kbc_acquire_cli import HOSTS, NET, SHA_N, SHA_O, plan_of, ready, staging_root  # noqa: F401

from patchtrace.kbcorrelation.service import KbService
from patchtrace.kbcorrelation.store import WorkspaceStore
from patchtrace.sample import synthetic_pe

pytestmark = pytest.mark.usefixtures('no_sockets')
RECEIPTS = Path('/workspace/scratch/81e4938f4a3a/verification')


@pytest.mark.parametrize('previous_selection', [None, 'arm64', 'amd64'])
def test_acquired_pair_keeps_selected_scope_and_links_approved_index_identity(
    ready, staging_root, previous_selection,
):
    kb, server, inv, flags, project = ready
    scope = flags[1]
    if previous_selection:
        code, products, _ = kb('products', inv)
        assert code == 0
        other = next(p['scope_id'] for p in products['result']['products'] if p['architecture'] == previous_selection)
        code, _ = kb.search('CVE-2099-20001', '--investigation', inv, '--product', other)
        assert code == 0
    svc = KbService(kb.workspace, kb.env)
    _, found, _, _ = svc._resolve_pairs(inv, scope, [NET])
    planned_pair = svc._pick_pair(found, None)
    preview = plan_of(kb, inv, flags, project)
    with WorkspaceStore(kb.workspace) as ws:
        before = ws.current_revision(inv).model_dump(mode='json')
    code, doc, err = kb('acquire', inv, '--project', str(project), *flags,
                       '--consent-hosts', HOSTS, '--consent-plan', preview['plan_sha'])
    with WorkspaceStore(kb.workspace) as ws:
        rev = ws.current_revision(inv)
        decisions = ws.decisions(inv)
        history = ws.revisions(inv)
        journal = ws.journal_ops()
    bundles = svc._project_bundles(str(project)) if (project / 'project.sqlite3').exists() else []
    observed = {
        'scope': 'authored synthetic fixtures; fake HTTP opener; sockets denied; no PE execution',
        'source_head': 'dceb71386d0f08c53ac05f9c1a7c6f9509d4d10c',
        'original_recovery_source': 'c3868d8335a8f32f676905032dc1a6d0e9f22fd6',
        'previous_selection': previous_selection,
        'planned_pair': planned_pair.model_dump(mode='json'),
        'preview': preview,
        'before': before,
        'exit': code,
        'document': doc,
        'stderr': err,
        'after': rev.model_dump(mode='json'),
        'decisions': [d.model_dump(mode='json') for d in decisions],
        'history': [r.model_dump(mode='json') for r in history],
        'journal': journal,
        'bundles': [b.model_dump(mode='json') for b in bundles],
        'fake_transport_calls': server.calls,
        'staging_is_empty': not any(staging_root.iterdir()),
    }
    (RECEIPTS / f'issue118-pair-{previous_selection or "unselected"}.json').write_text(
        json.dumps(observed, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    # Source c3868d83's positive contract: preserve explicit product, link the
    # source proposal to conservative verified local identity, never boost claims.
    assert code == 0, doc
    assert rev.selected_scope_id == scope
    bundle = bundles[-1]
    assert bundle.scope_id == scope
    assert bundle.older_sha == SHA_O and bundle.newer_sha == SHA_N
    assert doc['result']['pair']['grade'] == 'B'
    assert doc['result']['pair']['lineage_state'] == 'user-asserted'
    assert doc['result']['pair']['pair_id'] != preview['pair_id']
    acquisition = doc['result']['acquisition']
    assert acquisition['source_pair_id'] == preview['pair_id']
    assert acquisition['verified_pair_id'] == bundle.pair_id == rev.selected_pair_id
    assert acquisition['scope_id'] == scope
    binding = next(d for d in decisions if d.op == 'acquisition-pair-binding')
    assert binding.prior == preview['pair_id'] and binding.next == bundle.pair_id
    assert all(value in binding.reason for value in (preview['plan_sha'], scope, SHA_O, SHA_N))
    assert not any(staging_root.iterdir())


def test_acquisition_rehash_refuses_staged_path_changed_after_verification(ready, staging_root, monkeypatch):
    kb, _server, inv, flags, project = ready
    preview = plan_of(kb, inv, flags, project)
    with WorkspaceStore(kb.workspace) as ws:
        before, history, decisions = ws.current_revision(inv), ws.revisions(inv), ws.decisions(inv)
    original = kb.env.acquirer.stage

    def changed(_self, *args, **kwargs):
        staged = original(*args, **kwargs)
        path = Path(staged.newer_path)
        path.chmod(0o600)
        path.write_bytes(synthetic_pe(7))
        return staged

    monkeypatch.setattr(type(kb.env.acquirer), 'stage', changed)
    code, doc, _ = kb('acquire', inv, '--project', str(project), *flags, '--consent-hosts', HOSTS,
                     '--consent-plan', preview['plan_sha'])
    (RECEIPTS / 'issue118-pair-staged-change.json').write_text(json.dumps({
        'scope': 'retained c3868d83 control; authored replacement bytes, never executed; sockets denied',
        'preview': preview, 'exit': code, 'document': doc,
        'expected_newer_sha': preview['newer_sha256'],
        'replacement_newer_sha': __import__('hashlib').sha256(synthetic_pe(7)).hexdigest(),
    }, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    assert code == 3 and 'PT-KBC-VERIFY' in doc['error']
    assert not project.exists() and not any(staging_root.iterdir())
    with WorkspaceStore(kb.workspace) as ws:
        assert ws.current_revision(inv) == before
        assert ws.revisions(inv) == history and ws.decisions(inv) == decisions
