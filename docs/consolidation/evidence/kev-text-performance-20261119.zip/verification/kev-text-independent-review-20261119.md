# Independent review: KEV printable-ASCII validation fast path

Review date: 2026-11-19. Reviewer: `pe_metadata`.

## Decision

Approve commit `c84ca5a28b54d696dca58b24d29931c32a9ad093` for the scoped local
optimization. No semantic or validation blocker was found. The retained paired
measurements support this one-line change on the recorded Linux environment;
they do not establish that the earlier Windows timing failure is fixed.

Commit tree: `18d743f8442fe983a0f76c152143bb2eb3e5a396`.
Parent: `cf55415587f996f54a9d957a48d57818ebe9ff42`.

| Committed path | Git blob |
| --- | --- |
| `src/patchtrace/kev/contracts.py` | `7c44374e54c543ef2e6be1eb0978023d289e5c13` |
| `tests/test_kev_contracts.py` | `f3b83180bf9f96e11d14a47c081010ad19550fac` |
| `docs/consolidation/KEV_TEXT_VALIDATION_PERFORMANCE_20261119.md` | `4b7ca73bf3b3507f4d97ddf396b6e15701aeff19` |

Each committed blob was independently read and checked against the working
files. The complete source hashes, protected-file hashes, probes, and recomputed
measurement summaries are in `kev-text-independent-review-binding-20261119.json`.
The contracts source SHA256 is
`81ae7597745d477f4f7c9ff61d046de44560b98d52d50fde7f63199c65a7877a`.

## Semantic reasoning and checks

For an ordinary str, the new bypass is restricted to printable ASCII. That
subset contains no character in the existing unsafe ranges: the unsafe ASCII
characters are C0 controls and DEL, which isprintable excludes. Empty text also
remains accepted where the field's length permits it. The existing strip
comparison executes first and is unchanged, so surrounding spaces remain an
error. Every non-ASCII string or string containing a nonprintable ASCII character
still executes the original unsafe-regex search. No text is transformed.

Independently compiled the exact baseline and candidate validator functions from
their committed ASTs and compared 690 ordinary strings. The corpus includes all
128 ASCII code points in standalone, embedded, leading, and trailing positions;
unsafe-range endpoints and adjacent values; Unicode whitespace; visible Unicode;
combining marks; emoji; and surrogate boundaries. All acceptance results,
returned values, and ValueError messages matched.

The public model boundary was checked separately. In a private process, the
actual KevEntry AfterValidator function was instrumented before delegating to
the exact baseline or candidate code, then restored in finally. Fourteen model
probes covered a str subclass whose strip/isascii/isprintable methods lie, valid
ASCII and accented text, embedded DEL and bidi controls, surrounding whitespace,
and high/low surrogates. All observed AfterValidator arguments were built-in str;
none of the subclass overrides ran. Valid text retained its exact value,
controls and padding retained their notes/value_error refusal, and lone
surrogates retained the earlier notes/string_unicode refusal. Both variants
also rejected a wrong entry digest. This binds the normalization observation to
the installed Pydantic 2.14.2 public model, without assuming behavior of arbitrary
future dependency versions or direct calls with unsupported argument types.

The complete contracts-module AST is unchanged except for _plain_line.
The parser implementation, identity module, limits, pyproject, and entire parser
test file are byte-identical to the parent. The exact `elapsed < 1.0` assertion
remains. No schema, digest validation, field rule, dependency, or performance
threshold was relaxed.

## Performance evidence

Inspected both benchmark scripts and independently recomputed their summaries
from all retained raw timings; no further benchmark was run during this review.

| Experiment | Recorded parses | Median wall reduction | Median CPU reduction | Slower wall blocks |
| --- | ---: | ---: | ---: | ---: |
| Four fresh-process ABBA blocks | 80 | 4.91% | 10.15% | 2 of 4 |
| Six same-process ABBA blocks | 72 | 12.43% | 11.96% | 2 of 6 |

The scripts warm outside recorded timing, retain every recorded timing, compare
full serialized catalog hashes, and preserve the source/dependency bindings.
The same-process experiment swaps only the exact source-derived validator code
outside timed parsing, uses the same compiled models, and restores the original
code in finally. Every retained serialized output hash agrees within each
experiment. The slower blocks and the original mixed fresh-process result remain
visible; the percentages are descriptive local observations, not statistical
guarantees or cross-platform promises.

The benefit is sufficient for this small, semantically equivalent optimization.
It does not justify removing the digest recheck, changing the authored workload,
or increasing the one-second budget; none of those changes occurred.

## Functional evidence and limits

Inspected the contributor's source-bound final command/result and log:
**386 passed in 5.55 seconds** across the contract, parser, and schema tests.
This is the contributor's pytest run, separate from the independent semantic
probes above. The added public-model controls assert accepted values and actual
error locations/types rather than counting regex calls. The recovery report
retains the initial surrogate-expectation correction and failed benchmark-harness
attempt instead of claiming them as runtime repairs.

The independent process verified its isolated import resolved to
`/tmp/pt81-kev-text-performance/src/patchtrace`. No source/test edits, package
installation, network request, target execution, or new performance run occurred.
Only review artifacts were written under the task workspace's verification
directory. Native Windows timing, final combined-head CI, packaging, and the
original Windows gate remain separate qualification.
