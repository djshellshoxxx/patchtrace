"""Balanced process-level comparison; timings are observations, not acceptance thresholds."""
from __future__ import annotations
import datetime
import hashlib
import json
from pathlib import Path
import statistics
import subprocess
import sys
import time

VERIFY = Path('/workspace/scratch/81e4938f4a3a/verification')
PYTHON = '/tmp/pt81-kev-text-venv/bin/python'
ROOTS = {'baseline': Path('/tmp/pt81-kev-text-baseline'),
         'candidate': Path('/tmp/pt81-kev-text-performance')}


def worker(label):
    root = ROOTS[label]
    sys.path.insert(0, str(root / 'src'))
    sys.path.insert(0, str(root / 'tests'))
    from kev_helpers import document, entry, parse_bytes, render
    from patchtrace.kev import contracts, parse
    import pydantic
    import pydantic_core
    assert Path(parse.__file__).is_relative_to(root / 'src')
    rows = [entry(n, shortDescription='D' * 700, requiredAction='A' * 400,
                  notes='https://example.invalid/' + 'n' * 80) for n in range(1, 1742)]
    raw = render(document(rows))
    catalog = parse_bytes(raw)  # one warmup outside every recorded sample
    samples = []
    for _ in range(5):
        wall = time.perf_counter_ns()
        cpu = time.process_time_ns()
        catalog = parse_bytes(raw)
        cpu_elapsed = (time.process_time_ns() - cpu) / 1e9
        wall_elapsed = (time.perf_counter_ns() - wall) / 1e9
        assert catalog.meta.entry_count == 1741
        samples.append({'wall_seconds': wall_elapsed, 'cpu_seconds': cpu_elapsed})
    assert catalog.by_cve == {item.cve_id: item for item in catalog.entries}
    serialized = {'meta': catalog.meta.model_dump(mode='json'),
                  'entries': [item.model_dump(mode='json') for item in catalog.entries],
                  'released': catalog.released.isoformat()}
    model_bytes = json.dumps(serialized, sort_keys=True,
                            ensure_ascii=True, separators=(',', ':')).encode()
    return {'label': label, 'source_root': str(root), 'python': sys.version,
            'pydantic': pydantic.__version__, 'pydantic_core': pydantic_core.__version__,
            'contracts_sha256': hashlib.sha256(Path(contracts.__file__).read_bytes()).hexdigest(),
            'parser_sha256': hashlib.sha256(Path(parse.__file__).read_bytes()).hexdigest(),
            'fixture_bytes': len(raw), 'fixture_sha256': hashlib.sha256(raw).hexdigest(),
            'serialized_catalog_sha256': hashlib.sha256(model_bytes).hexdigest(),
            'entry_count': catalog.meta.entry_count, 'content_digest': catalog.meta.content_digest,
            'samples': samples}


def controller():
    raw_path = VERIFY / 'kev-text-performance-paired-samples-20261119.jsonl'
    result_path = VERIFY / 'kev-text-performance-paired-results-20261119.json'
    assert not raw_path.exists() and not result_path.exists()
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    groups = []
    for block in range(4):
        group = []
        for label in ('baseline', 'candidate', 'candidate', 'baseline'):
            command = [PYTHON, '-I', '-B', str(Path(__file__)), '--worker', label]
            process = subprocess.run(command, check=True, text=True, capture_output=True)
            observed = json.loads(process.stdout)
            observed['block'] = block + 1
            observed['observed_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
            with raw_path.open('a') as output:
                output.write(json.dumps(observed) + '\n')
            group.append(observed)
        groups.append(group)
        print('Completed balanced block', block + 1, flush=True)
    rows = [item for group in groups for item in group]
    for field in ('parser_sha256', 'fixture_sha256', 'serialized_catalog_sha256', 'entry_count',
                  'content_digest', 'python', 'pydantic', 'pydantic_core'):
        assert len({item[field] for item in rows}) == 1, field
    aggregate = {}
    for label in ROOTS:
        times = [sample for item in rows if item['label'] == label for sample in item['samples']]
        aggregate[label] = {'samples': len(times),
                            'wall_median': statistics.median(t['wall_seconds'] for t in times),
                            'cpu_median': statistics.median(t['cpu_seconds'] for t in times),
                            'wall_min': min(t['wall_seconds'] for t in times),
                            'wall_max': max(t['wall_seconds'] for t in times)}
    paired = []
    for index, group in enumerate(groups):
        medians = {label: {metric: statistics.median(s[metric] for item in group if item['label'] == label
                                                   for s in item['samples'])
                           for metric in ('wall_seconds', 'cpu_seconds')}
                   for label in ROOTS}
        paired.append({'block': index + 1, 'medians': medians,
                       'wall_reduction_percent': 100 * (1 - medians['candidate']['wall_seconds'] /
                                                       medians['baseline']['wall_seconds']),
                       'cpu_reduction_percent': 100 * (1 - medians['candidate']['cpu_seconds'] /
                                                      medians['baseline']['cpu_seconds'])})
    result = {'started_at_utc': started, 'finished_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'base': 'cf55415587f996f54a9d957a48d57818ebe9ff42',
              'protocol': 'Four sequential ABBA blocks in fresh processes; each process warms once and times five parses; all 80 timings retained; no concurrent tests launched by this worker',
              'aggregate': aggregate, 'paired_blocks': paired,
              'wall_reduction_percent': 100 * (1 - aggregate['candidate']['wall_median'] / aggregate['baseline']['wall_median']),
              'cpu_reduction_percent': 100 * (1 - aggregate['candidate']['cpu_median'] / aggregate['baseline']['cpu_median']),
              'exact_outputs_and_dependency_versions_match': True,
              'source_hashes': {label: next(r['contracts_sha256'] for r in rows if r['label'] == label) for label in ROOTS},
              'raw_samples': str(raw_path), 'limit': 'Current Linux interpreter/dependencies only; no Windows performance fix established'}
    result_path.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    if len(sys.argv) == 3 and sys.argv[1] == '--worker':
        print(json.dumps(worker(sys.argv[2])))
    else:
        controller()
