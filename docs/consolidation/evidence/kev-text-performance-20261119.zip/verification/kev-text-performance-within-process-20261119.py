"""One confirmation experiment alternating exact validator code in a private process."""
from __future__ import annotations
import ast
import datetime
import hashlib
import json
from pathlib import Path
import statistics
import sys
import time

ROOT = Path('/tmp/pt81-kev-text-performance')
BASE = Path('/tmp/pt81-kev-text-baseline')
VERIFY = Path('/workspace/scratch/81e4938f4a3a/verification')
sys.path.insert(0, str(ROOT / 'src'))
sys.path.insert(0, str(ROOT / 'tests'))
from kev_helpers import document, entry, parse_bytes, render
from patchtrace.kev import contracts

codes = {}
source_hashes = {}
for label, root in [('baseline', BASE), ('candidate', ROOT)]:
    path = root / 'src/patchtrace/kev/contracts.py'
    source_hashes[label] = hashlib.sha256(path.read_bytes()).hexdigest()
    tree = ast.parse(path.read_text())
    function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == '_plain_line')
    isolated = ast.Module(body=[function], type_ignores=[])
    namespace = {}
    exec(compile(isolated, str(path), 'exec'), namespace)
    codes[label] = namespace['_plain_line'].__code__

rows = [entry(n, shortDescription='D' * 700, requiredAction='A' * 400,
              notes='https://example.invalid/' + 'n' * 80) for n in range(1, 1742)]
raw = render(document(rows))
original_code = contracts._plain_line.__code__
records = []
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
try:
    for label in ('baseline', 'candidate'):
        contracts._plain_line.__code__ = codes[label]
        parse_bytes(raw)
    for block in range(6):
        for label in ('baseline', 'candidate', 'candidate', 'baseline'):
            # Pydantic holds the same Python function object. Only that function's
            # exact baseline/candidate code changes, outside the measured parse.
            contracts._plain_line.__code__ = codes[label]
            samples = []
            for _ in range(3):
                wall = time.perf_counter_ns()
                cpu = time.process_time_ns()
                catalog = parse_bytes(raw)
                cpu_elapsed = (time.process_time_ns() - cpu) / 1e9
                wall_elapsed = (time.perf_counter_ns() - wall) / 1e9
                assert catalog.meta.entry_count == 1741
                samples.append({'wall_seconds': wall_elapsed, 'cpu_seconds': cpu_elapsed})
            assert catalog.by_cve == {item.cve_id: item for item in catalog.entries}
            serialized = {'meta': catalog.meta.model_dump(mode='json'),
                          'entries': [item.model_dump(mode='json') for item in catalog.entries],
                          'released': catalog.released.isoformat()}
            digest = hashlib.sha256(json.dumps(serialized, sort_keys=True, ensure_ascii=True,
                                               separators=(',', ':')).encode()).hexdigest()
            records.append({'block': block + 1, 'label': label, 'samples': samples,
                            'serialized_catalog_sha256': digest})
        print('Completed same-process block', block + 1, flush=True)
finally:
    contracts._plain_line.__code__ = original_code
assert len({r['serialized_catalog_sha256'] for r in records}) == 1
aggregates = {}
for label in codes:
    times = [sample for r in records if r['label'] == label for sample in r['samples']]
    aggregates[label] = {'samples': len(times),
                         'wall_median': statistics.median(t['wall_seconds'] for t in times),
                         'cpu_median': statistics.median(t['cpu_seconds'] for t in times)}
paired = []
for block in range(1, 7):
    medians = {label: {metric: statistics.median(s[metric] for r in records if r['label'] == label and r['block'] == block
                                                for s in r['samples'])
                       for metric in ('wall_seconds', 'cpu_seconds')}
               for label in codes}
    paired.append({'block': block, 'medians': medians,
                   'wall_reduction_percent': 100 * (1 - medians['candidate']['wall_seconds'] / medians['baseline']['wall_seconds']),
                   'cpu_reduction_percent': 100 * (1 - medians['candidate']['cpu_seconds'] / medians['baseline']['cpu_seconds'])})
result = {'started_at_utc': started, 'finished_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'protocol': 'Six balanced ABBA blocks in one private process; exact source-derived validator code swapped outside parse timing; same compiled models and dependencies; original code restored in finally; no file mutation',
          'source_hashes': source_hashes, 'aggregate': aggregates, 'paired_blocks': paired,
          'wall_reduction_percent': 100 * (1 - aggregates['candidate']['wall_median'] / aggregates['baseline']['wall_median']),
          'cpu_reduction_percent': 100 * (1 - aggregates['candidate']['cpu_median'] / aggregates['baseline']['cpu_median']),
          'raw_samples': records, 'exact_serialized_outputs_match': True,
          'limit': 'Current Linux interpreter/dependencies only; old Windows failure remains unresolved'}
path = VERIFY / 'kev-text-performance-within-process-results-20261119.json'
assert not path.exists()
path.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'raw_samples'}, indent=2))
