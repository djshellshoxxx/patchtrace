"""Run every tracked pytest test file in small sequential processes; retain exact coverage and failures."""
from __future__ import annotations

import fnmatch
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from xml.etree import ElementTree

ROOT = Path('/workspace/scratch/81e4938f4a3a/pt-candidate')
OUT = Path('/tmp/pt81-final-results')
PYTHON = Path('/tmp/pt81-final-venv/bin/python')
BATCH_SIZE = 16
PREFIX = 'candidate-remaining'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def source_fingerprint():
    body = git('ls-tree', '-r', 'HEAD', '--', 'src', 'tests', 'tools')
    return hashlib.sha256(body.encode()).hexdigest()


def persist(value):
    target = OUT / f'{PREFIX}-manifest.json'
    temp = target.with_suffix('.json.tmp')
    temp.write_text(json.dumps(value, indent=2) + '\n')
    temp.replace(target)


def disk_state():
    return {str(p): shutil.disk_usage(p).free for p in (ROOT, Path('/tmp'))}


def junit_counts(path):
    if not path.is_file():
        return None
    doc = ElementTree.parse(path).getroot()
    suites = [doc] if doc.tag == 'testsuite' else list(doc.findall('testsuite'))
    return {key: sum(int(s.attrib.get(key, '0')) for s in suites)
            for key in ('tests', 'failures', 'errors', 'skipped')}


def main():
    changed = git('status', '--porcelain', '--untracked-files=all', '--', 'src', 'tests', 'tools')
    if changed:
        raise SystemExit('Refusing an unfrozen source/test/tool tree: ' + changed)
    files = [p for p in git('ls-files', 'tests').splitlines()
             if fnmatch.fnmatch(Path(p).name, 'test_*.py') or fnmatch.fnmatch(Path(p).name, '*_test.py')]
    files = sorted(set(files))
    groups = [files[i:i + BATCH_SIZE] for i in range(0, len(files), BATCH_SIZE)]
    fingerprint = source_fingerprint()
    prior_path = OUT / 'candidate-final-manifest.json'
    prior_bytes = prior_path.read_bytes()
    prior = json.loads(prior_bytes)
    assert prior['outcome'] == 'blocked_disk_space'
    assert prior['completed_groups'] == 34
    assert prior['files'] == files and prior['groups'] == groups
    assert prior['source_tests_tools_sha256'] == fingerprint
    receipt = {
        'started_utc': datetime.now(UTC).isoformat(),
        'source_commit': git('rev-parse', 'HEAD'),
        'source_tree': git('rev-parse', 'HEAD^{tree}'),
        'source_tests_tools_sha256': fingerprint,
        'scope': 'Only original groups 35 through 54; groups 1 through 34 retain their stopped diagnostic outcomes. No file exclusions.',
        'prior_manifest': prior_path.name,
        'prior_manifest_sha256': hashlib.sha256(prior_bytes).hexdigest(),
        'prior_source_commit': prior['source_commit'],
        'continuation_reason': 'Same source/test/tool fingerprint; checkout relocated with all 3946 tracked-file hashes verified to recover tmp space.',
        'qualification': 'Separate processes provide partitioned coverage, not an unsplit full-suite pass.',
        'batch_size': BATCH_SIZE,
        'files': files,
        'groups': groups,
        'results': [],
        'outcome': 'running',
    }
    persist(receipt)
    env = dict(os.environ, QT_QPA_PLATFORM='offscreen', PYTHONUNBUFFERED='1')
    for number, group in enumerate(groups[34:], 35):
        if source_fingerprint() != fingerprint or git('diff', '--name-only', '--', 'src', 'tests', 'tools'):
            receipt['outcome'] = 'blocked_source_changed'
            break
        space = disk_state()
        if space[str(ROOT)] < 128 * 1024**2 or space['/tmp'] < 256 * 1024**2:
            receipt['outcome'] = 'blocked_disk_space'
            receipt['remaining_disk_bytes'] = space
            break
        name = f'{PREFIX}-{number:02d}'
        log = OUT / f'{name}.log'
        xml = OUT / f'{name}.xml'
        temp = Path('/tmp') / f'pt81-{name}'
        command = [str(PYTHON), '-m', 'pytest', '-q', *group, f'--basetemp={temp}',
                   f'--junitxml={xml}', '-o', 'tmp_path_retention_policy=failed',
                   '-o', 'faulthandler_timeout=90', '--durations=5']
        print(f'[{number}/{len(groups)}] starting {len(group)} test files', flush=True)
        started = time.monotonic()
        with log.open('w') as stream:
            process = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
        result = {'group': number, 'files': group, 'command': command,
                  'exit_code': process.returncode, 'elapsed_seconds': round(time.monotonic() - started, 3),
                  'log': log.name, 'junit': xml.name if xml.is_file() else None,
                  'counts': junit_counts(xml), 'log_sha256': hashlib.sha256(log.read_bytes()).hexdigest()}
        receipt['results'].append(result)
        persist(receipt)
        print(f'[{number}/{len(groups)}] exit={process.returncode} counts={result["counts"]}', flush=True)
        if process.returncode in (-9, 137):
            receipt['outcome'] = 'blocked_killed_process'
            break
        if process.returncode == 0 and temp.is_dir():
            shutil.rmtree(temp)
    else:
        receipt['outcome'] = ('passed_remaining_partitioned' if all(r['exit_code'] == 0 for r in receipt['results'])
                              else 'failed_remaining_partitioned')
    receipt['ended_utc'] = datetime.now(UTC).isoformat()
    receipt['completed_groups'] = len(receipt['results'])
    receipt['total_groups'] = len(groups[34:])
    receipt['total_plan_groups'] = len(groups)
    receipt['final_commit'] = git('rev-parse', 'HEAD')
    persist(receipt)
    print(json.dumps({k: receipt[k] for k in ('outcome', 'completed_groups', 'total_groups')}, indent=2), flush=True)
    return 0 if receipt['outcome'] == 'passed_remaining_partitioned' else 1


if __name__ == '__main__':
    sys.exit(main())
