"""Finish the frozen diagnostic without discarding original killed-process evidence."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
from datetime import UTC, datetime
from pathlib import Path
from xml.etree import ElementTree

ROOT = Path('/workspace/scratch/81e4938f4a3a/pt-candidate')
OUT = Path('/tmp/pt81-final-results')
PYTHON = '/tmp/pt81-final-venv/bin/python'
PREFIX = 'candidate-final-subpartitions'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def fingerprint():
    return hashlib.sha256(git('ls-tree', '-r', 'HEAD', '--', 'src', 'tests', 'tools').encode()).hexdigest()


def counts(path):
    if not path.is_file():
        return None
    doc = ElementTree.parse(path).getroot()
    suites = [doc] if doc.tag == 'testsuite' else list(doc.findall('testsuite'))
    return {key: sum(int(s.attrib.get(key, '0')) for s in suites)
            for key in ('tests', 'failures', 'errors', 'skipped')}


def save(receipt):
    target = OUT / (PREFIX + '-manifest.json')
    temp = target.with_suffix('.json.tmp')
    temp.write_text(json.dumps(receipt, indent=2) + '\n')
    temp.replace(target)


def main():
    prior_path = OUT / 'candidate-tail-manifest.json'
    prior_bytes = prior_path.read_bytes()
    prior = json.loads(prior_bytes)
    assert prior['outcome'] == 'blocked_killed_process'
    assert prior['results'][-1]['group'] == 51 and prior['results'][-1]['exit_code'] == -9
    assert prior['results'][-1]['counts'] is None
    assert git('status', '--porcelain', '--untracked-files=all', '--', 'src', 'tests', 'tools') == ''
    source_fingerprint = fingerprint()
    assert source_fingerprint == prior['source_tests_tools_sha256']
    groups = prior['groups']
    perf = groups[50][0]
    assert perf == 'tests/test_unified_ladder_residual_perf.py'
    dense_path = OUT / 'candidate-dense-isolated-result.json'
    dense_bytes = dense_path.read_bytes()
    dense = json.loads(dense_bytes)
    assert dense['returncode'] == 0 and dense['source'] == git('rev-parse', 'HEAD')
    dense_counts = counts(OUT / 'candidate-dense-isolated.xml')
    assert dense_counts == dict(tests=1, failures=0, errors=0, skipped=0)
    plan = [{'name': '51-generated', 'original_group': 51,
             'selectors': [perf + '::' + name for name in (
                 'test_residual_ladder_under_budget',
                 'test_blocking_never_builds_full_matrix_at_scale',
                 'test_residual_pairs_are_right_and_tier_c_precision_is_reported')]}]
    for number in range(51, 55):
        files = groups[number - 1][1:] if number == 51 else groups[number - 1]
        for offset in range(0, len(files), 8):
            plan.append({'name': f'{number}-{offset // 8 + 1}', 'original_group': number,
                         'selectors': files[offset:offset + 8]})
    env = dict(os.environ, QT_QPA_PLATFORM='offscreen', PYTHONUNBUFFERED='1', PYTHONDONTWRITEBYTECODE='1')
    receipt = {
        'started_utc': datetime.now(UTC).isoformat(),
        'source_commit': git('rev-parse', 'HEAD'),
        'source_tree': git('rev-parse', 'HEAD^{tree}'),
        'source_tests_tools_sha256': source_fingerprint,
        'prior_manifest': prior_path.name,
        'prior_manifest_sha256': hashlib.sha256(prior_bytes).hexdigest(),
        'scope': 'Original groups51-54; group51 generated fixture separated from dense fixture, all other files in batches of at most8. No assertion or fixture changes.',
        'qualification': 'Partitioned diagnostic coverage on frozen source/old Pydantic; not an unsplit pass and not a pass on current integration source.',
        'original_group51_kill_preserved': True,
        'dense_isolated_receipt': dense_path.name,
        'dense_isolated_receipt_sha256': hashlib.sha256(dense_bytes).hexdigest(),
        'dense_isolated_counts': dense_counts,
        'plan': plan,
        'results': [],
        'outcome': 'running',
    }
    collect_log = OUT / (PREFIX + '-collection.log')
    collect_command = [PYTHON, '-m', 'pytest', '--collect-only', '-q', *sum(groups[50:], [])]
    with collect_log.open('w') as stream:
        collected = subprocess.run(collect_command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
    receipt['collection'] = {'command': collect_command, 'exit_code': collected.returncode,
                             'log': collect_log.name, 'sha256': hashlib.sha256(collect_log.read_bytes()).hexdigest()}
    if collected.returncode != 0:
        receipt['outcome'] = 'blocked_collection'
        save(receipt)
        return 1
    save(receipt)
    for entry in plan:
        if fingerprint() != source_fingerprint or git('diff', '--name-only', '--', 'src', 'tests', 'tools'):
            receipt['outcome'] = 'blocked_source_changed'
            break
        space = {str(p): shutil.disk_usage(p).free for p in (ROOT, Path('/tmp'))}
        if space[str(ROOT)] < 128 * 1024**2 or space['/tmp'] < 192 * 1024**2:
            receipt['outcome'] = 'blocked_disk_space'
            receipt['remaining_disk_bytes'] = space
            break
        name = PREFIX + '-' + entry['name']
        log = OUT / (name + '.log')
        xml = OUT / (name + '.xml')
        temp = Path('/tmp') / ('pt81-' + name)
        command = [PYTHON, '-m', 'pytest', '-q', *entry['selectors'], f'--basetemp={temp}',
                   f'--junitxml={xml}', '-o', 'tmp_path_retention_policy=failed',
                   '-o', 'faulthandler_timeout=90', '--durations=5']
        print(f"[{entry['name']}] starting", flush=True)
        start = time.monotonic()
        with log.open('w') as stream:
            process = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
        result = dict(entry, command=command, exit_code=process.returncode,
                      elapsed_seconds=round(time.monotonic() - start, 3), log=log.name,
                      junit=xml.name if xml.is_file() else None, counts=counts(xml),
                      log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        receipt['results'].append(result)
        save(receipt)
        print(f"[{entry['name']}] exit={process.returncode} counts={result['counts']}", flush=True)
        if process.returncode in (-9, 137):
            receipt['outcome'] = 'blocked_killed_process'
            break
        if process.returncode == 0 and temp.is_dir():
            shutil.rmtree(temp)
    else:
        receipt['outcome'] = 'passed_subpartitions' if all(r['exit_code'] == 0 for r in receipt['results']) else 'failed_subpartitions'
    receipt['ended_utc'] = datetime.now(UTC).isoformat()
    receipt['completed_subpartitions'] = len(receipt['results'])
    receipt['final_commit'] = git('rev-parse', 'HEAD')
    save(receipt)
    print(receipt['outcome'], flush=True)
    return 0 if receipt['outcome'] == 'passed_subpartitions' else 1


if __name__ == '__main__':
    sys.exit(main())
