# Supplemental tools static review — 2026-11-19

## Result and exact scope

All **70 tools findings across 37 files** have an individual disposition. They are the tools subset of
`verification/security-static-phase6.json`, which contains 134 rows: the 64 source findings were classified
separately. Every flagged source location and caller reference in this review was read from commit
`5208c7589495cea749142f57599c4382be9caed5`, not from the changing integration worktree. The input file used
here has SHA-256 `06a0c71750cc4286707a46b411ab45a63cb40b597310c0ed17c96c1c04d35eb9`.

The companion [JSON record](tools-static-review-20261119.json) preserves all original scanner rows,
including severity, rule text, columns and the two distinct MD5/SHA1 findings on one line. Each record adds
the pinned Git blob, source SHA-256, enclosing function and its exact span, source-line evidence, input
trust, observed guards, remaining limits and followup status. There are no unmapped findings.

**Classification is not a clean security scan.** Forty-nine findings are explicit developer-tool execution
boundaries, not blanket false positives. Two HTTPS dispatch gaps were already owned by the integration
worker and its independent reviewer. This review found two additional evidence-handling defects that
were repaired separately in commit `45828168056e67a3ca419483d9582b9b0660f651`; the table retains their
original scan locations and behavior. Native acceptance, full-current-head qualification and release
readiness are not established by this review.

## Rules and dispositions

| Rule | Findings |
|---|---:|
| S101 | 1 |
| S103 | 1 |
| S105 | 1 |
| S108 | 1 |
| S110 | 3 |
| S310 | 3 |
| S311 | 6 |
| S314 | 2 |
| S324 | 2 |
| S603 | 39 |
| S607 | 10 |
| S608 | 1 |

| Review disposition | Findings |
|---|---:|
| Confirmed observation-health gap; batch8 repair | 1 |
| Defensive XML parser; batch8 ingress repair | 1 |
| Development constant invariant | 1 |
| Developer tool execution boundary | 49 |
| Optional check fails closed | 1 |
| Caller-guarded network helper | 1 |
| Intentional build permission normalization | 1 |
| Confirmed baseline HTTPS dispatch gap | 2 |
| Legacy fixture hash metadata | 2 |
| Lexical false positive | 3 |
| Deterministic nonsecurity randomness | 6 |
| Optional metadata suppression; retained limit | 1 |
| Workflow-owned XML trust boundary | 1 |

## Findings that affect evidence or trust

### Connection observation health: reproduced and repaired separately

At the scan baseline, `ConnectionMonitor.poll` swallowed sample exceptions and counted them as polls;
the acceptance consumer passed `no-external-connections` when `seen` was empty. Three authored exceptions
therefore produced a passing observation step despite zero successful samples. The Linux sampler also
mapped read failures to empty observations, and the Windows sampler discarded its nonzero exit status.
The OS-block positive control was a separate requirement and was not shown to be ineffective by this
reproduction. Source: `tools/bundle_acceptance.py:273–320,390–404,600–630`; required observation count:
`docs/specs/program-e/BUNDLE-acceptance-isolation-spec.md:92`.

Batch8 retains attempted polls and adds successful/error/unavailable counts. It requires at least three
successful observations, preserves endpoints seen before a partial read or Windows command failure,
and records a bounded Windows sampling timeout. Independent review caught and reproduced a partial
Windows stdout loss in the first proposed correction; that failure and its three additional red controls
are retained. The final affected group had **111 passes and three existing Linux-unshare skips in 4.48 s**
across four test files, with configured Ruff passing and independent review approval. All new controls use
authored observations. None proves real PowerShell, firewall, namespace or native backend acceptance.

The committed scope and receipt table are in `docs/consolidation/RECOVERY_BATCH_8.md`. Fixed source and
review receipts are listed separately in
[the batch8 receipt manifest](tools-evidence-receipt-manifest-20261119.json). This static report is not
part of that fixed receipt set. Polling remains supplementary: short-lived connections can be missed,
Windows still samples the named child PID, and successful samples do not imply continuous coverage.

### Two different XML boundaries

`tools/unified/gates_u.py:162–181` already rejected XML above 8 MiB, non-UTF-8/NUL input, DTD/entity
declarations and unexpected roots before interpreting test outcomes. Failed, skipped and missing required
tests do not become a successful integrity gate. The public CLI nevertheless read every file with
`Path.read_bytes()` and retained all raw JUnit bodies before applying the cap (`438–440,494–500`). Batch8
moves the existing per-file budget to a bounded read plus sentinel, rejects oversize input before XML
parsing, and parses/hashes each body before opening the next file. Prior reports survive refusal. File
count, aggregate merged outcomes, explicit-path ownership and other artifact readers remain outside this
narrow repair.

`tools/milestone_notes.py:45` instead assumes pytest artifacts owned by its release workflow. The actual
caller downloads the same workflow's `qa-*` artifacts and supplies fixed XML paths; notes failure falls
back to a static preamble (`.github/workflows/qa-windows.yml:219–240,265–270`). There is no explicit byte
cap or DTD/entity admission guard at that parser. It must not be advertised as a hardened arbitrary-XML
importer. Its derived JUnit-attribute counts are also not an independent substitute for pytest's summary
of passed bodies when teardown errors coexist. This remains a documented trust limitation, unchanged
by the batch8 repair.

### HTTPS sites: keep independent repairs distinct

The flagged Request constructors in `tools/build_backend_bundle.py:271` and
`tools/verify_backend_pins.py:202` feed ordinary urllib openers that follow redirects. An initial HTTPS
prefix and an eventual response/digest check do not enforce an HTTPS decision before each request.
The complete URL/authority/control-character and redirect repair is owned and tested separately by the
integration worker and HTTPS reviewer; no duplicated implementation or independent qualification claim
is made here.

`tools/research_qualification/winpairs.py:185` has a different normal call path. Its opener disables
automatic redirects; `fetch_checked` checks the initial URL and each joined redirect before the next
request, limits hops, and enforces a body cap. `check_url` requires HTTPS, an allowed host, no nonempty parsed username/password and
port 443 or no explicit port (`69–75,176–225`). The low-level helper still depends on callers honoring that
precondition. A hostname check is not evidence authenticity or authorization to execute downloaded bytes.
The truthiness check does not literally exclude an empty userinfo marker; URL normalization and malformed-port exception typing were not independently qualified. This review made no network request and does not certify every malformed URL/parser edge case.

### Process arguments and executable trust

All 49 S603/S607 rows are list-based process calls. That avoids Python's implicit shell-string parsing;
it does **not** authenticate `argv[0]`, PATH resolution, the interpreter, its imports, a build hook, an MSI,
a native parser, a selected compiler or an operator-chosen test suite. The per-row records identify the
actual executable and ordinary caller rather than treating `shell=False` as an all-purpose safety result.

Representative distinctions are material:

- PyInstaller/NSIS and offline pip wheel construction intentionally execute trusted build code. A matching
  version or source digest identifies a tool/input; it is not a sandbox.
- The frozen smoke and native API research runner intentionally execute operator-selected product/control
  executables. Their paths and measured hashes do not authorize arbitrary compared binaries.
- `provision_bindiff.extract_msi` is reached after normal pin/digest admission, but `msiexec /a` remains a
  trusted installer operation. It must not be described as a general data-only parser for hostile MSIs.
- Clang, nm and llvm-pdbutil inspect/compile data through trusted native tools. The input binary is not the
  executable position. A post-process output-size check does not bound bytes written while the tool runs.
- Test/Qt runners intentionally execute tests and plugins; developer CLI options are not an untrusted
  command input surface. Git census calls are read operations under local repository/tool trust. The triage
  helper only removes its own newly allocated worktree, though cleanup status and timeout limits remain.
- The Windows `taskkill` call is cleanup for the harness-owned child PID; return-code/timeout and PID-lifetime
  limitations remain. A cleanup invocation alone does not establish successful process containment.

None of the reviewed build, provisioning, live-probe or native-control commands, or compared binaries,
was launched for the static classification. Inspection used read-only Git and local Python/report tooling.
The separate repair's authored and existing affected tests are reported under their own evidence scope.

### Three suppressed-error findings require three different dispositions

The monitor exception suppression was a reproduced evidence defect. In contrast,
`build_backend_bundle.py:1112` catches a failure in an optional normalized-content comparison after a byte
mismatch and still falls through to the pin-mismatch rejection; that catch does not authorize unknown data.
The PyInstaller optional-dependency hook catches all metadata-copy failures, so an installed package's
metadata fault can look like an absent optional extra. That last behavior is retained as a packaging
observability limit, not promoted to proof that all metadata ships.

### Nonsecurity uses and lexical matches

The six seeded PRNG sites build reproducible fuzz, benchmark and synthetic mutation inputs; no credential,
nonce or security secret is generated there. The two MD5/SHA1 sites populate legacy metadata for authored
PE fixtures; the reader's identity binding uses SHA-256. The module assertion compares authored operator
registries and can disappear under optimized Python, so it is not validation of outside input. The 0755
permission operation normalizes a staged distribution tree and is not group/world writable.

Three findings are lexical false positives with precise scope: the site's S608 string is HTML prose with
no SQL operation; the S108 `/tmp/` string is a forbidden-path leak detector rather than a temporary file;
and S105's `P00` is a ladder pass identifier rather than a password. Those dispositions do not certify the
surrounding renderer, compiler or parity subsystem.

## Every recorded tools finding

Locations below refer only to the pinned baseline. The JSON supplies caller lines, source blobs, exact
scanner columns/messages and the full remaining limits. Duplicate line/rule rows are intentionally kept.

| ID | Source location | Rule | Disposition | Site and remaining trust boundary |
|---|---|---|---|---|
| tools-001 | `tools/branch_inventory.py:48` | S603 | Developer tool execution boundary | Git.read runs repository read operations for the branch census. Generic helper is not an arbitrary-command security API. PATH/configuration and captured-output/workload budgets remain trusted. |
| tools-002 | `tools/branch_inventory.py:49` | S607 | Developer tool execution boundary | Git.read runs repository read operations for the branch census. Generic helper is not an arbitrary-command security API. PATH/configuration and captured-output/workload budgets remain trusted. |
| tools-003 | `tools/build_backend_bundle.py:271` | S310 | Confirmed baseline HTTPS dispatch gap | download creates a Request used by automatic urllib redirects. The final check happens after dispatch and cannot prevent an intermediate downgrade; complete authority/control admission is part of the separate repair. |
| tools-004 | `tools/build_backend_bundle.py:623` | S603 | Developer tool execution boundary | run_tool launches offline pip wheel construction and the pinned JDK jlink tool. Offline wheel building still executes build code. Digest equality is byte identity, not safety; PATH/toolchain trust and captured-output allocation remain outside the guard. |
| tools-005 | `tools/build_backend_bundle.py:874` | S607 | Developer tool execution boundary | Reads git rev-parse HEAD for build metadata. The GITHUB_SHA fast path is trusted directly. Neither that metadata nor a Git version authenticates the build. |
| tools-006 | `tools/build_backend_bundle.py:1014` | S103 | Intentional build permission normalization | Normalizes staged POSIX directories to0755 and files to0755/0644. Distribution permissions are intentional. Concurrent hostile staging mutation and general permission hardening are not established. |
| tools-007 | `tools/build_backend_bundle.py:1112` | S110 | Optional check fails closed | Ignores a failed optional normalized-content comparison after byte hash/size mismatch. The suppressed optional-check exception is not fully retained, but the mismatch remains a failure. |
| tools-008 | `tools/build_linux.py:274` | S603 | Developer tool execution boundary | Runs fixed git -C ROOT rev-parse HEAD for build metadata. Search-path and metadata trust remain; no executable authentication. |
| tools-009 | `tools/build_linux.py:274` | S607 | Developer tool execution boundary | Runs fixed git -C ROOT rev-parse HEAD for build metadata. Search-path and metadata trust remain; no executable authentication. |
| tools-010 | `tools/build_linux.py:406` | S603 | Developer tool execution boundary | Invokes sys.executable -m PyInstaller with repository entrypoint/hooks. Build hooks deliberately execute trusted code; no per-call build timeout or hostile-code sandbox. |
| tools-011 | `tools/build_linux.py:454` | S603 | Developer tool execution boundary | Runs the freshly built launcher --self-test and rank --help. A path identifies a candidate build, not its authenticity; smoke checks do not prove native backend acceptance. |
| tools-012 | `tools/build_linux.py:455` | S603 | Developer tool execution boundary | Runs the freshly built launcher --self-test and rank --help. A path identifies a candidate build, not its authenticity; smoke checks do not prove native backend acceptance. |
| tools-013 | `tools/build_windows.py:87` | S603 | Developer tool execution boundary | Invokes this interpreter and PyInstaller for the Windows desktop build. Intentional build-code execution; no per-call timeout or malicious-toolchain containment. |
| tools-014 | `tools/build_windows.py:154` | S603 | Developer tool execution boundary | Executes newly produced PatchTrace.exe for self-test and help smoke. No executable authenticity, general hostile-bundle safety or real comparison acceptance established. |
| tools-015 | `tools/build_windows.py:160` | S603 | Developer tool execution boundary | Executes newly produced PatchTrace.exe for self-test and help smoke. No executable authenticity, general hostile-bundle safety or real comparison acceptance established. |
| tools-016 | `tools/bundle_acceptance.py:318` | S110 | Confirmed observation-health gap; batch8 repair | Baseline counts failed sample attempts and accepts no-external-connections solely because seen is empty. At baseline Linux read failures and Windows nonzero exits can become empty data; polling cannot prove continuous absence. |
| tools-017 | `tools/bundle_acceptance.py:387` | S603 | Developer tool execution boundary | Runs configured product probes and fixed isolation wrappers. Trusted product/host commands execute intentionally. No malicious-bundle sandbox or bounded capture is implied. |
| tools-018 | `tools/bundle_acceptance.py:392` | S603 | Developer tool execution boundary | Starts bundle Python/Ghidriff under the isolation wrapper while monitoring. Native backend parser trust remains. Baseline monitor-health gap is tracked separately; capture is not streaming-capped. |
| tools-019 | `tools/bundle_acceptance.py:395` | S603 | Developer tool execution boundary | Executes a fixed PowerShell connection-query script containing integer PID values. Baseline ignores nonzero exit and has no sampler timeout. Batch8 fixes health and partial-output retention; Windows native behavior is still unverified. |
| tools-020 | `tools/calibration/corpus.py:71` | S603 | Developer tool execution boundary | Uses git ls-files to enumerate candidate files, with walk fallback. Git/tool search-path trust remains; fallback scope is not proof of source authenticity. |
| tools-021 | `tools/calibration/corpus.py:71` | S607 | Developer tool execution boundary | Uses git ls-files to enumerate candidate files, with walk fallback. Git/tool search-path trust remains; fallback scope is not proof of source authenticity. |
| tools-022 | `tools/calibration/mutations/opt_transforms.py:43` | S101 | Development constant invariant | Checks equality of authored ordered operator registries at import. Optimization may remove the development invariant; this is not runtime validation of untrusted operators. |
| tools-023 | `tools/calibration/tier_r/shard.py:222` | S603 | Developer tool execution boundary | Runs selected Python with fixed TierR module and internally built case/evaluation commands. Plan hash is not execution authorization. stdout/stderr tails are sliced after capture and do not bound allocation. |
| tools-024 | `tools/calibration/tier_w/make_fixtures.py:69` | S108 | Lexical false positive | The /tmp/ literal is forbidden-path search text in generated fixture bytes. No insecure fixed temporary filename occurs at this site; compiler trust remains a separate boundary. |
| tools-025 | `tools/calibration/tier_w/run_local.py:148` | S603 | Developer tool execution boundary | Runs selected Python for known TierW stages and corpus guard. Interpreter/toolchain/proxy settings are trusted; output capture is unbounded. No stage or network operation ran in this audit. |
| tools-026 | `tools/calibration/tier_w/symbols_llvm.py:38` | S603 | Developer tool execution boundary | Runs llvm-pdbutil version and PDB dump commands. Path/version are not authenticity. The 256 MiB cap follows writing the file, so it is not a streaming disk cap; version text has no corresponding cap. |
| tools-027 | `tools/corpus_check.py:114` | S603 | Developer tool execution boundary | Invokes clang for syntax-only JSON AST parsing of corpus C files. Accumulated findings do not sandbox compiler/preprocessor behavior or cap captured AST JSON; compared code is parsed, not launched. |
| tools-028 | `tools/frozen_smoke.py:54` | S603 | Developer tool execution boundary | Executes an explicitly chosen frozen launcher using authored smoke commands. Resolution is not authentication of arbitrary launchers. No compared input binary is used as argv0. |
| tools-029 | `tools/fuzz_binexport.py:80` | S311 | Deterministic nonsecurity randomness | Uses a fixed seeded PRNG for parser mutations. Finite fuzz campaigns do not prove parser safety or complete coverage. |
| tools-030 | `tools/fuzz_parsers.py:134` | S324 | Legacy fixture hash metadata | Computes MD5/SHA1 as legacy ArtifactCopy fields alongside SHA256 for synthetic PE context. No collision resistance is inferred for MD5/SHA1. Provider/FIPS availability remains an environment limit. |
| tools-031 | `tools/fuzz_parsers.py:134` | S324 | Legacy fixture hash metadata | Computes MD5/SHA1 as legacy ArtifactCopy fields alongside SHA256 for synthetic PE context. No collision resistance is inferred for MD5/SHA1. Provider/FIPS availability remains an environment limit. |
| tools-032 | `tools/fuzz_parsers.py:375` | S311 | Deterministic nonsecurity randomness | Seeds reproducible per-target parser mutations. Finite iterations and after-return timing checks do not prove coverage or preemptively limit each parser call. |
| tools-033 | `tools/gen_binexport_descriptor.py:31` | S603 | Developer tool execution boundary | Runs operator-selected protoc --version and descriptor generation. Compiler path/version are not authentication; subprocess calls have no timeout. Pinned data cannot make a malicious compiler safe. |
| tools-034 | `tools/gen_binexport_descriptor.py:32` | S603 | Developer tool execution boundary | Runs operator-selected protoc --version and descriptor generation. Compiler path/version are not authentication; subprocess calls have no timeout. Pinned data cannot make a malicious compiler safe. |
| tools-035 | `tools/live_kbc_probe.py:71` | S603 | Developer tool execution boundary | Runs sys.executable -m patchtrace with authored KB plan/sync/verify/search args. Trusted code can request network access by design; capture unbounded. Static review did no live probe or reachability request. |
| tools-036 | `tools/live_kev_probe.py:92` | S603 | Developer tool execution boundary | Runs checkout PatchTrace KEV fetch using sys.executable. Inherited import/plugin configuration is not a sandbox. No live provider compatibility was tested. |
| tools-037 | `tools/live_nvd_probe.py:68` | S603 | Developer tool execution boundary | Runs checkout PatchTrace correlate/fetch from the live probe. Output capture is unbounded; inherited environment remains trusted. No live CLI/network request ran in this audit. |
| tools-038 | `tools/milestone_notes.py:45` | S314 | Workflow-owned XML trust boundary | Parses pytest JUnit XML to render release-note counts. No explicit byte or DTD/entity admission guard here. This is not a hardened arbitrary-XML importer. JUnit-derived passed counts are not independently equivalent to pytest body-pass summaries when teardown errors coexist. |
| tools-039 | `tools/package_windows_installer.py:107` | S603 | Developer tool execution boundary | Executes NSIS for version validation and installer compilation. Matching version/path is not compiler authentication; compilation is intentional code execution and has no per-call timeout. |
| tools-040 | `tools/package_windows_installer.py:116` | S603 | Developer tool execution boundary | Executes NSIS for version validation and installer compilation. Matching version/path is not compiler authentication; compilation is intentional code execution and has no per-call timeout. |
| tools-041 | `tools/provision_bindiff.py:243` | S603 | Developer tool execution boundary | Performs msiexec /a administrative extraction of the pinned Windows MSI. Administrative MSI extraction is a trusted installer operation, not a hostile data-only parser. Direct helper callers assume prior pin admission; digest identity is not safety. |
| tools-042 | `tools/pyinstaller_hooks/hook-patchtrace.optional_deps.py:14` | S110 | Optional metadata suppression; retained limit | Suppresses copy_metadata failures for optional distributions during packaging. Broad catch hides installed metadata faults as well as absent extras. Frozen/package-content validation remains necessary; not proof all metadata shipped. |
| tools-043 | `tools/qt_gate.py:67` | S603 | Developer tool execution boundary | Runs Python/pytest over default authored tests or operator test selectors. Tests deliberately execute code; selectors are not an untrusted-input surface. No call-level timeout or tool authenticity boundary. |
| tools-044 | `tools/release_gate.py:162` | S603 | Developer tool execution boundary | Executes git and gh api prefixes for release scheduling/history. Scheduling is not source review, permission or all-jobs-green acceptance. CLI refs/environment/tool search path are trusted; this audit made no API request. |
| tools-045 | `tools/research_qualification/fixture_pairs.py:68` | S603 | Developer tool execution boundary | Queries compiler target/version for authored fixture preparation. Version/target/hash measurement is descriptive after execution, not pre-execution authentication. |
| tools-046 | `tools/research_qualification/fixture_pairs.py:84` | S603 | Developer tool execution boundary | Queries compiler target/version for authored fixture preparation. Version/target/hash measurement is descriptive after execution, not pre-execution authentication. |
| tools-047 | `tools/research_qualification/fixture_pairs.py:96` | S603 | Developer tool execution boundary | Compiles module-authored source into a synthetic ELF fixture. No hostile compiler/toolchain containment or general source sandbox is claimed. |
| tools-048 | `tools/research_qualification/fixture_pairs.py:105` | S603 | Developer tool execution boundary | Uses nm to inventory fixture function symbols. The image is data, not argv0. No authenticity/native parser safety claim; return status is indirectly constrained by inventory validation. |
| tools-049 | `tools/research_qualification/perf_harness.py:44` | S603 | Developer tool execution boundary | Calls taskkill /F /T /PID on the harness-created child. PID lifetime, path trust and cleanup failure remain limits. Nonzero return is ignored and there is no timeout; this call alone does not prove containment. |
| tools-050 | `tools/research_qualification/perf_harness.py:44` | S607 | Developer tool execution boundary | Calls taskkill /F /T /PID on the harness-created child. PID lifetime, path trust and cleanup failure remain limits. Nonzero return is ignored and there is no timeout; this call alone does not prove containment. |
| tools-051 | `tools/research_qualification/winpairs.py:185` | S310 | Caller-guarded network helper | Creates one-hop requests behind fetch_checked URL approval. Direct urllib_fetcher callers must honor the checked-URL precondition. Truthiness checks do not literally exclude an empty userinfo marker; URL parser normalization and malformed-port exception typing were not independently qualified. Host checks are not byte authenticity or execution permission; no request occurred in this audit. |
| tools-052 | `tools/run_test_suite.py:72` | S603 | Developer tool execution boundary | Runs sys.executable -m pytest with explicit developer options and saves its log. Intentional test-code execution; no subprocess timeout; full log read afterward. Not a sandbox for untrusted options. |
| tools-053 | `tools/run_test_suite.py:80` | S603 | Developer tool execution boundary | Creates an owned temporary detached base-ref worktree for triage. Base tests/plugins and Git config remain trusted; no command timeout. |
| tools-054 | `tools/run_test_suite.py:80` | S607 | Developer tool execution boundary | Creates an owned temporary detached base-ref worktree for triage. Base tests/plugins and Git config remain trusted; no command timeout. |
| tools-055 | `tools/run_test_suite.py:89` | S603 | Developer tool execution boundary | Removes the triage-created temporary worktree in finally. Unchecked return/no timeout can leave registration after cleanup failure; not evidence of universal successful cleanup. |
| tools-056 | `tools/run_test_suite.py:89` | S607 | Developer tool execution boundary | Removes the triage-created temporary worktree in finally. Unchecked return/no timeout can leave registration after cleanup failure; not evidence of universal successful cleanup. |
| tools-057 | `tools/rzdiff/native_evidence.py:140` | S603 | Developer tool execution boundary | Runs an explicitly selected authored native public-API control. Executable hash is measured rather than authenticated here. Acceptance is native-API control scope only, not CLI JSON/runtime/application acceptance. |
| tools-058 | `tools/site/build_site.py:279` | S608 | Lexical false positive | Returns screenshot HTML prose containing Select, without any SQL operation. S608 lexical classification only; this is not a full HTML/XSS content audit. |
| tools-059 | `tools/unified/bench.py:205` | S311 | Deterministic nonsecurity randomness | Seeds synthetic instructions/constants for reproducible ingest/facts benchmarks. Deterministic synthetic counts do not establish real-binary accuracy/performance. |
| tools-060 | `tools/unified/bench.py:251` | S311 | Deterministic nonsecurity randomness | Seeds synthetic instructions/constants for reproducible ingest/facts benchmarks. Deterministic synthetic counts do not establish real-binary accuracy/performance. |
| tools-061 | `tools/unified/gates_u.py:177` | S314 | Defensive XML parser; batch8 ingress repair | Parser has defensive XML admission, but baseline CLI reads all files unbounded before parsing. Baseline initial read/all-raw-body retention is unbounded. Followup caps each read+sentinel and parses sequentially; total file count/merged outcome map and explicit-path ownership remain limits. |
| tools-062 | `tools/unified/mutations/templates.py:277` | S311 | Deterministic nonsecurity randomness | Seeds planted-mutant preludes and per-function source templates. Synthetic authored truth is not promoted evidence about real CVE cases. |
| tools-063 | `tools/unified/mutations/templates.py:278` | S311 | Deterministic nonsecurity randomness | Seeds planted-mutant preludes and per-function source templates. Synthetic authored truth is not promoted evidence about real CVE cases. |
| tools-064 | `tools/unified/parity.py:90` | S105 | Lexical false positive | P00 is the ladder pass identifier for manual anchors excluded from parity. Password heuristic is inapplicable here; overall parity provenance is not certified by this classification. |
| tools-065 | `tools/verify_backend_pins.py:49` | S603 | Developer tool execution boundary | Runs Git/GPG and interpreter-based Sigstore for explicit pin verification. Local tools/configuration and pin-controlled Git URL are trusted. Verification intentionally can access network; none was run in this audit. |
| tools-066 | `tools/verify_backend_pins.py:110` | S603 | Developer tool execution boundary | Runs git archive for a pinned commit to build a deterministic tarball. Search-path/configuration trust and whole stdout memory capture remain limits. |
| tools-067 | `tools/verify_backend_pins.py:110` | S607 | Developer tool execution boundary | Runs git archive for a pinned commit to build a deterministic tarball. Search-path/configuration trust and whole stdout memory capture remain limits. |
| tools-068 | `tools/verify_backend_pins.py:153` | S607 | Developer tool execution boundary | Runs git --version for mismatch diagnostics. No timeout and ignored return status; diagnostic tar/member reading has no aggregate resource cap. |
| tools-069 | `tools/verify_backend_pins.py:202` | S310 | Confirmed baseline HTTPS dispatch gap | Constructs the request used by _fetch automatic redirects. No complete pre-dispatch HTTPS URL/redirect policy at baseline. Byte limits do not protect request authority. |
| tools-070 | `tools/windows_version_info.py:150` | S607 | Developer tool execution boundary | Reads git rev-parse --verify HEAD when CI SHA is absent. Commit validation is metadata correctness, not authenticity of git/product bytes. |

## Validation and limits of this record

The classification was checked against the full original tools-row sequence: all 70 original dictionaries
are preserved unchanged and in order; every flagged source line, source hash and caller reference resolves
at the pinned commit; all counts sum to 70; there are zero unmapped rows and zero invalid caller-line
references. The source subset's earlier 64-row receipt is distinct from the SHA-256 of the current combined
134-row input file recorded here. No frozen census counts or source classification records were changed.

Remaining explicit trust assumptions include workflow-owned XML, executable and search-path provenance,
trusted build source/toolchains and described output/time limits. Static review cannot establish native
compatibility, absence of all malicious compiler/parser behavior, concurrency safety of every staging
operation, real Windows or Linux denial evidence, a full current-head test pass or release readiness.
