"""Read-only timing/profile of the exact authored full-size KEV fixture."""
from __future__ import annotations
import cProfile
import datetime
import hashlib
import io
import json
from pathlib import Path
import platform
import pstats
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/81e4938f4a3a/PatchTrace')
VERIFY = ROOT.parent / 'verification'
sys.path.insert(0, str(ROOT / 'tests'))
from kev_helpers import document, entry, parse_bytes, render
from patchtrace.kev import parse
import pydantic
import pydantic_core

rows = [entry(n, shortDescription='D' * 700, requiredAction='A' * 400,
              notes='https://example.invalid/' + 'n' * 80) for n in range(1, 1742)]
raw = render(document(rows))
assert len(raw) > 1_500_000
observations = []
for _ in range(3):
    start = time.perf_counter()
    catalog = parse_bytes(raw)
    elapsed = time.perf_counter() - start
    assert catalog.meta.entry_count == 1741
    observations.append({'elapsed_seconds': elapsed, 'entry_count': catalog.meta.entry_count,
                         'content_digest': catalog.meta.content_digest})
profile = cProfile.Profile()
catalog = profile.runcall(parse_bytes, raw)
assert catalog.meta.entry_count == 1741
profile.dump_stats(str(VERIFY / 'ci318-kev-current-root-profile-20261119.pstats'))
stream = io.StringIO()
stats = pstats.Stats(profile, stream=stream).strip_dirs().sort_stats('cumulative')
stats.print_stats(30)
(VERIFY / 'ci318-kev-current-root-profile-20261119.txt').write_text(stream.getvalue())
functions = []
for (filename, line, name), (primitive, total, own, cumulative, callers) in sorted(
        stats.stats.items(), key=lambda item: item[1][3], reverse=True)[:35]:
    functions.append({'filename': filename, 'line': line, 'function': name,
                      'primitive_calls': primitive, 'total_calls': total,
                      'own_seconds': own, 'cumulative_seconds': cumulative,
                      'callers': [{'filename': c[0], 'line': c[1], 'function': c[2], 'stats': v}
                                  for c, v in callers.items()]})
result = {'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'root_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
          'python': sys.version, 'platform': platform.platform(), 'pydantic': pydantic.__version__,
          'pydantic_core': pydantic_core.__version__, 'parser_source': str(parse.__file__),
          'parser_sha256': hashlib.sha256(Path(parse.__file__).read_bytes()).hexdigest(),
          'fixture_bytes': len(raw), 'fixture_sha256': hashlib.sha256(raw).hexdigest(),
          'unprofiled_samples': observations, 'profile_total_seconds': stats.total_tt,
          'profile_total_calls': stats.total_calls, 'functions': functions,
          'scope': 'Current Linux root and new dependencies only; profile overhead is not a timing threshold result; no source modifications'}
(VERIFY / 'ci318-kev-current-root-profile-20261119.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'functions'}, indent=2))
print(stream.getvalue())
