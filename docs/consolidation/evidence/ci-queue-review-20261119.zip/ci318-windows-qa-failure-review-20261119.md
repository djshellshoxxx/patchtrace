# PR #318 completed Windows QA failure and current-root comparison

## Exact failure and execution source

Completed job **135484259463**, Windows full QA in run **44502066991**, failed
one test: `tests/test_kev_parse.py::test_a_full_size_catalog_parses_within_the_budget`.
The parser returned all **1,741 entries**, but the measured parse time was
**1.4662241000000904 seconds**, exceeding the unchanged strict **less than 1.0
second** assertion. This is the recorded failure; it is not attributed to runner
load or dismissed as a flake.

The terminal pytest summary was **1 failed, 25,615 passed, 151 skipped, 2 xfailed,
25 warnings in 4,612.02 seconds**. It is a failed run. Later Windows build,
frozen smoke, ZIP and installer steps were skipped after pytest failed.

The run belongs to PR #318 head
`c4ace2088ce8dc9ce78a0bf3036b81096accbdb5`, targeting
`f2b6827fc6270b96fb241b0722f2878de5a17361`. The checkout log records the actual
PR merge commit **`de9a8cf060a5def95acb9d887f68e0dc01237221`**. A separate REST
Git-commit read confirms those two parents and tree
**`ee130e5c201683794abf42b76fb6c9372731d892`**. The full recursive tree read was
not truncated. This distinction avoids assuming that the head commit itself was
the checkout used by `actions/checkout`.

The Windows environment installed CPython **3.12.10**, Pydantic **2.13.5**, and
pydantic-core **2.46.5**, as recorded in the decoded job log. The clock tool reported
**2026-11-19 13:08:02 UTC** at retrieval. Only the source-binding lines, complete
failure block and terminal summary are retained in the bounded log excerpt.

## Source identity comparison

The following blobs were compared across the actual tested merge tree, PR #318
head, current root **`cf55415587f996f54a9d957a48d57818ebe9ff42`**, and local
published checkpoint **`0ed53876c0460edafdb089121744c167493fb8ff`** (the source
whose tree was published as PR #322 head `eb94510b...`). All six tested-code and
fixture paths below are byte-identical. The performance assertion and KEV spec are
unchanged. This establishes a shared source boundary, not reproduction of the
Windows timing outcome on the newer dependency environment.

| Path | Tested merge blob | Current root comparison |
| --- | --- | --- |
| `tests/test_kev_parse.py` | `6cc68db15536492efe60e65b205b3273d3ef9d5b` | Identical |
| `tests/kev_helpers.py` | `a6e3aa9e44c2225766a8b3c6c6ee0694d1d1b378` | Identical |
| `src/patchtrace/kev/parse.py` | `ca50ee9ac915175d62dc4ee9b6f497fb0b762329` | Identical |
| `src/patchtrace/kev/contracts.py` | `6b0d584d20ed8acc5f87449a191d7890ced6d3c5` | Identical |
| `src/patchtrace/kev/limits.py` | `5e7f1840c3a35829e55f0a43079fce5f531eb4ae` | Identical |
| `src/patchtrace/enrichment/identity.py` | `2e3c5da5996826b0cb4484ac6ff67308bebc694b` | Identical |
| `pyproject.toml` | `7d619559d3d94364c2b81e8700fbc5268a417da6` | Different Pydantic pin |
| `docs/specs/program-e/KEV-integration-plan.md` | `fb74931cf563bf97836b0b575b8113819b8c20a3` | Identical |

## Current Linux check, unchanged threshold

The existing single performance test was run through the current root's private
interpreter with `-I -B`, disabled pytest caching, offscreen Qt, a dedicated `/tmp`
fixture directory, and durable log/JUnit receipts. The source remained
`cf554155...`; imports were verified to resolve to that root. It used CPython
**3.12.14**, Pydantic **2.14.2**, and pydantic-core **2.50.2**.

Result: **1 passed in 1.25 seconds of total pytest time**. That total includes
collection/setup and is not the parse time compared to the one-second assertion.
No threshold, fixture, model validation, dependency or source file was changed.

A separate small profile used the exact authored fixture construction from the
existing test. It produces **3,023,173 bytes** locally, SHA-256
`39652f335cf25e9b3f55ddea462085729b7f9d96dc6427c0df2d8f178842ef04`.
Three unprofiled parse samples took **0.169237, 0.106382 and 0.123659 seconds**;
all returned 1,741 entries and the same content digest. These Linux observations
do not qualify the old Windows run, prove a fix, or establish what the current
head will do on Windows.

## Profile and bounded proposal

The instrumented parse took **0.308392 seconds**, including profiling overhead,
with **320,529 function calls**. Its largest repeated work was canonical identity
construction: `entry_digest` was called **3,482 times**, twice per entry, and
accounted for about **0.138 seconds cumulative**. The parser computes a digest,
then the strict `KevEntry` validator independently verifies that digest against
its validated fields. Removing this second verification would weaken the public
model boundary and is not proposed as a shortcut.

The smaller text-validation hotspot is more narrowly actionable:
`_plain_line` was called **10,446 times**, and regex `search` accounted for about
**0.022 seconds** in the profile. `clean_text` already avoids its Unicode regex
for ASCII printable strings. The same logical guard can avoid `_plain_line`'s
Unicode unsafe-character search for that subset, while keeping leading/trailing
whitespace rejection and the complete existing fallback for all other text.
Printable ASCII contains none of the ranges in `_UNSAFE`.

This is a candidate for paired measurement and independent semantic tests, not a
demonstrated Windows repair. A change should be retained only if paired actual
parser measurements show a useful gain. Tests should check independent input/output
and rejection boundaries, including ASCII controls, surrounding whitespace,
non-ASCII valid text, and unsafe Unicode ranges; they should not merely count regex
calls or mirror the new condition. Digest consistency validation and the exact
one-second test must remain intact. Any later implementation and its results will
have separate receipts and a separate recovery report.

## CI boundary and receipts

The current PR #322 head still had six queued workflows at the separate
13:07:51 UTC refresh. The two still-active PR #318 Qt job log downloads returned
404 `BlobNotFound`, preserved in the queue receipt. This completed Windows log is
available; those active-job logs are not. The exact reason for PR #322's queue
remains unproven, and no workflow/runner action was taken.

Evidence under workspace `verification/`:

- `ci318-windows-qa-failure-excerpt-20261119.log`: bounded original failure and checkout evidence.
- `ci318-windows-qa-failure-binding-20261119.json`: clock, run/job, merge parents/tree, exact relevant Git blobs, failure counts and original dependency versions.
- `ci318-windows-failure-local-source-comparison-20261119.json`: local refs, Git blobs and SHA-256 hashes for all eight compared paths.
- `ci318-kev-current-root-performance-test-20261119.{log,xml}` and `-result.json`: unchanged single-test run, exact command and imported versions/source.
- `ci318-kev-current-root-profile-20261119.{py,json,txt,pstats}`: reproducible authored timing/profile and call/caller records.
- `ci322-queue-refresh-eb94510-20261119.{md,json}`: current and superseded CI inventory, native/live limits and observed access blockers.

This read-only phase changed no repository source, test, dependency or remote state.
