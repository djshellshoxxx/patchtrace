# Independent review: build-tool HTTPS redirect boundary

Review date: 2026-11-19. Reviewer: `pe_metadata`. This review inspected the
uncommitted change above root HEAD `e430309ac9c9d1ea7a5b271af68df5a5113ea1bb`.
It changed no repository source, tests, index, pins, or external state. It made
no network requests and executed no downloaded or backend tools.

## Scope and evidence

Reviewed the new `verify_backend_pins.open_https` helper, its `_NoRedirect`
handler and `_require_https` validation, both download callers, the 28 authored
redirect tests, the gzip fixture seam, the offline `Run` seam, and the amended
bundle contract. Compared the implementation with the installed Python 3.12.14
stdlib `urllib.request` handler and connection code. The initial helper file
SHA256 was
`909d29c6e6c3c4e502fa8024e428cc3e23f4671854429aa459a054ad2c06ee8c`.

The original red receipt remains `backend-https-red.log` / `.xml`: 17 failed,
11 passed in 1.97 seconds. The integrator reported an initial corrected
five-file selection of 260 passed, one existing skip in 6.17 seconds; this
review did not rerun that selection or treat it as final approval.

Two direct, stdlib-only probes are recorded in
`backend-https-independent-probes-20261119.json`. Both HTTP and HTTPS transport
handlers were replaced with authored in-memory responses. The HTTPS probe
constructed, then closed, `http.client.HTTPSConnection` to retain its authority
validation, without calling connect, request, or any socket operation. The
probe disabled proxies within its own process to avoid environment-dependent
request metadata. No repository files were modified.

## Findings requiring correction before approval

### 1. Generated Host header is copied across hosts

The initial implementation rebuilt redirects with
`headers=dict(request.header_items())`. `opener.open` mutates the first Request
by placing its generated Host in `unredirected_hdrs`. `header_items()` includes
those headers. The probe followed `https://vendor.invalid/start` to
`https://cdn.invalid/component`, and the second request had host `cdn.invalid`
but header `Host: vendor.invalid`. The initial tests observed URLs only, so
they did not detect the mismatch.

The follow-up should use intentional redirectable headers, excluding generated
Host and content headers, allowing urllib to derive Host from each new target.
The integrator is adding actual Host assertions to relative and cross-host
controls before correcting this implementation. The two production callers
supply only fixed public User-Agent and, for the verifier, Accept-Encoding.
They do not currently supply Authorization or Cookie. If the helper remains
general enough to accept those headers, cross-origin forwarding needs its own
explicit tested policy; this is not evidence of existing caller credential
exposure.

### 2. Encoded authority controls escape typed failure handling

The initial `_require_https` checked scheme, hostname presence, and the parsed
port. The redirect `https://bad%0ahost.invalid/component` passed that check.
`Request` decoded the authority to a hostname containing a newline, and the
real HTTPSConnection constructor raised `http.client.InvalidURL`, outside the
callers' URLError/OSError/TimeoutError/ValueError catches. The redirect response
was closed, but the error was not normalized to the specified tool boundary.

Reject control/whitespace characters in the decoded authority before transport
dispatch and cover both initial URLs and redirect targets. Normalize the
concrete InvalidURL failure if the transport can still produce it. Do not
interpret a raw malformed-authority error as a successful HTTPS-only policy
test. The probe records the exact exception and shows the original response
closed.

## Design checks with no additional blocker found

The handler overrides `http_error_302` and its 301/303/307/308 aliases before
stdlib redirect parsing or draining. Raising HTTPError there allows the helper
to inspect and validate Location itself. Every HTTPError path enters a finally
that closes the response without reading its body, including non-redirect
errors, missing locations, invalid URLs, and an exhausted redirect budget.

The range of eleven requests permits the initial request and ten follow-ups.
A successful response at the last allowed request can return; another redirect
at that point is closed and refused before an eleventh follow-up. Relative and
cross-host HTTPS are retained. Latin-1 quoting follows the relevant stdlib
header decoding convention, and URL join/encoding failures are normalized.
The initial and joined target are checked before each opener dispatch.

The caller owns the successful final response and closes it with its existing
context manager. Redirect/error failure occurs before opening or replacing the
download destination. Existing final payload, decompression, digest, signature,
and pin checks are retained by the inspected diff. This does not claim atomic
preservation of a builder destination after a failure during payload streaming;
that behavior was outside this redirect change.

Injecting the existing `Run` seam into
`test_verify_without_inputs_records_nothing` makes its offline claim true while
preserving its evidence assertions. Moving the gzip fixture to `open_https`
keeps that test focused on decoding; the separate transport tests exercise real
urllib redirect dispatch with no sockets.

## Boundaries

The helper currently serves GET callers. This review does not qualify arbitrary
POST/HEAD method preservation, user credential handling, live vendor/CDN
compatibility, operating-system proxy policy, or Windows-native execution.
The 120-second timeout remains per request, not a deadline for the entire
redirect chain. Other provisioning/corpus downloaders do not use this helper
and were not changed or qualified by this work.

Approval is pending correction and focused verification of the two reproduced
findings. The original red and probe receipts must remain intact when final
results are added.
