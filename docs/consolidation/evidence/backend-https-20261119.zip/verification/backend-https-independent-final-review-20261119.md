# Final independent verification: build-tool HTTPS redirects

Review date: 2026-11-19. Reviewer: `pe_metadata`.

## Decision and exact source binding

The two reproduced findings in
`backend-https-independent-review-20261119.md` are resolved in the corrected
source below. No remaining blocker was found for the reviewed builder/verifier
HTTPS redirect change. The original review, probe result, initial red receipt,
and peer-regression red receipt remain intact; this is a separate final record.

| Reviewed path | SHA256 |
| --- | --- |
| `tools/verify_backend_pins.py` | `b7bf3ddfcadd9ca5841ce8c9caba1f48bb582f20ba1912376a158c3e3ca68de7` |
| `tools/build_backend_bundle.py` | `db040d7e1ff2ec9694cc3f69c47f7439a84853d4b316563c4d7c09ce27b5a368` |

Both hashes were checked before and after the independent probes. The files
were loaded directly from `/workspace/scratch/81e4938f4a3a/PatchTrace`.
The approval binds these runtime bytes, independent of subsequent documentation
or import-order-only test edits.

## Reproduced findings now resolved

The corrected helper builds a redirect from the current request's intentional
headers, omitting Host, content headers, and Proxy-Authorization. It no longer
copies urllib's generated, unredirected Host from the initial request. The
original `vendor.invalid` to `cdn.invalid` replay now sends
`Host: cdn.invalid`; the response payload remains identical and all opened
response bodies close.

HTTPS validation checks the decoded authority for whitespace and controls as
well as the scheme, hostname, and port. The original
`https://bad%0ahost.invalid/component` replay now raises URLError after only
the initial valid request. The malformed follow-up never reaches the transport,
and the initial redirect body closes. The concrete http.client.InvalidURL case
is also normalized at the helper boundary, so both public callers retain their
specified error types.

Cross-origin comparison includes hostname and effective HTTPS port. The helper
removes Authorization and Cookie when that origin changes, while retaining the
fixed public User-Agent and Accept-Encoding headers used by existing callers.
Content and proxy-authorization headers are excluded from every follow-up.

## Independent checks

Seven focused probes passed:

1. Original cross-host replay: correct new Host, exact payload, closed bodies.
2. Original encoded-control authority replay: typed URLError before follow-up
   dispatch and closed redirect body.
3. Same-origin redirect: Authorization and Cookie retained; public headers
   retained; proxy/content headers removed.
4. Cross-host redirect: Authorization and Cookie removed; public headers retained;
   Host recomputed for the new authority.
5. Cross-port redirect: treated as an origin change, with the same credential
   removal and correct Host including the port.
6. Concrete transport InvalidURL through builder.download: PT-BUNDLE-FETCH,
   preserving the existing destination bytes.
7. Concrete transport InvalidURL through verifier._fetch: VerifyError,
   preserving the existing destination bytes.

Receipt: `backend-https-independent-final-probes-20261119.json`, SHA256
`9eb42c012d843b8da53bf0991f2bb89b66b7737162f2074f03faeb8fe0c8fa3b`.
It records the exact requests and header dictionaries, response-closure state,
exception types, source hashes, and original receipt hash.

The probes used `/workspace/scratch/81e4938f4a3a/.venv-main/bin/python -I -B`.
The isolated patchtrace import was verified to resolve to the root checkout
before loading either tool. HTTP and HTTPS transport methods were replaced
with authored in-memory handlers. HTTPSConnection was constructed and closed
only to retain its authority validation; connect and request were never called.
Proxies were disabled within that process. The two typed-error controls used a
rejecting opener. No socket connection, package installation, backend execution,
or repository mutation occurred, and temporary output fixtures were removed.

A preceding setup attempt using isolated primary Python stopped while importing
the builder because patchtrace was not on that interpreter's path. It executed
no probe. The receipt retains this setup failure; the seven results above come
from the corrected, explicitly verified interpreter.

## Integration evidence inspected

Read the saved peer-regression log: **28 failed, two passed in 1.37 seconds**
before the correction. Read `backend-https-final-result.json`, `.log`, and `.xml`:
the integrator's five-file selection reports **289 passed, one skipped in
8.20 seconds**, with the same runtime hashes listed above. The existing skip is
`test_real_wheel_build_from_a_source_tarball_is_byte_compared`, reason
`needs setuptools+wheel`.

These are the integrator's pytest results, not another independent pytest run.
The integrator subsequently corrected test import ordering without changing
assertions or runtime source. Independent verification here is the seven
focused probes against the exact runtime hashes.

## Scope retained

The no-redirect handler still intercepts before stdlib body draining or target
following. HTTPError responses close in a finally block; the successful final
response remains owned by the caller. The initial request plus at most ten
follow-ups remains the bound. The final payload/decompression limits and
existing digest, signature, and pin contracts are unchanged by the reviewed
correction.

This decision does not qualify live vendor/CDN compatibility, other provisioning
downloaders, native Windows execution, arbitrary non-GET method semantics, or
an aggregate release gate. Timeout remains per request rather than an overall
chain deadline. The builder's pre-existing behavior after a failure during
payload streaming was not redesigned by this redirect change.
