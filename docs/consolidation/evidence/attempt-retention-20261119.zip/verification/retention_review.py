"""Authored storage-only reproduction; no comparator, network, or original project inputs."""
from __future__ import annotations
import hashlib,json
from pathlib import Path
from patchtrace.enrichment.storage import EnrichmentStore, Guard
from patchtrace.secondary.runs import EngineRun
from patchtrace.secondary.store import publish_run
from patchtrace.service import ProjectService

root=Path('/tmp/pt81-attempt-retention-repro')
root.mkdir(exist_ok=True)
observations={}
with ProjectService.sample(root/'post-write') as svc:
    project=svc.project
    primary=next(r for r in project.runs if r.status=='completed' and r.raw_sha256)
    sides={a.side:a.sha256 for a in project.artifacts}
    g=Guard(project.id,primary.id,primary.raw_sha256,'f'*64)
    store=EnrichmentStore(svc.store)
    store.publish('secondary-matches',g,g,project.revision,'complete',{},'authored-malformed-set')
    with svc.store.connection as db:
        db.execute('UPDATE enrichment_entries SET body=?,body_sha256=? WHERE id=?',
                   ('[]',hashlib.sha256(b'[]').hexdigest(),'authored-malformed-set'))
    run=EngineRun(run_id='authored-failed-attempt',engine='rz-diff',engine_version='0.9.1',
                  executable_path_sha256=None,argv_digest='d'*64,older_sha256=sides['older'],newer_sha256=sides['newer'],
                  orientation='older->newer',cache_key='c'*64,status='failed',error_code='PT-SECONDARY-PROCESS',
                  returncode=1,started_utc='2099-01-01T00:00:00Z',duration_ms=1,stderr_tail='authored failure',
                  output_sha256=None,match_set_id=None)
    error=None
    try:
        publish_run(store,g,g,project.revision,run)
    except Exception as exc:
        error=type(exc).__name__
    observations['post_write']={'exception':error,'persisted_run_ids':[r[0] for r in svc.store.connection.execute(
        "SELECT id FROM enrichment_entries WHERE kind='engine-run'")],
        'malformed_body':svc.store.connection.execute('SELECT body FROM enrichment_entries WHERE id=?',
                                                     ('authored-malformed-set',)).fetchone()[0]}
with ProjectService.sample(root/'malformed-runs') as svc:
    project=svc.project
    primary=next(r for r in project.runs if r.status=='completed' and r.raw_sha256)
    g=Guard(project.id,primary.id,primary.raw_sha256,'f'*64)
    store=EnrichmentStore(svc.store)
    for i in range(3):
        key=f'authored-malformed-run-{i}'
        store.publish('engine-run',g,g,project.revision,'complete',{},key)
        with svc.store.connection as db:
            db.execute('UPDATE enrichment_entries SET body=?,body_sha256=? WHERE id=?',
                       ('[]',hashlib.sha256(b'[]').hexdigest(),key))
    before=list(svc.store.connection.execute('SELECT id,body,body_sha256 FROM enrichment_entries ORDER BY id'))
    deleted=store.prune_runs(keep=1)
    after=list(svc.store.connection.execute('SELECT id,body,body_sha256 FROM enrichment_entries ORDER BY id'))
    observations['malformed_runs']={'pruned':deleted,'before':before,'after':after}
path=Path('/workspace/scratch/81e4938f4a3a/verification/retention-review-observations.json')
path.write_text(json.dumps(observations,indent=2,sort_keys=True)+'\n')
print(json.dumps(observations,indent=2,sort_keys=True))
