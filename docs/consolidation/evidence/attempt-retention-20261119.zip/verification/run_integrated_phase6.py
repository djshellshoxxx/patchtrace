from pathlib import Path
import subprocess,os,json,time,hashlib,shutil
from xml.etree import ElementTree
root=Path('/workspace/scratch/81e4938f4a3a/PatchTrace'); out=root.parent/'verification'
py=root.parent/'.venv-main/bin/python'
groups=[['test_engine_run_retention_integrity.py','test_enrichment_storage.py','test_enrichment_retention.py'],['test_secondary_runs.py','test_evidence_attempt_storage.py','test_prune_backup.py','test_audit2_fixes.py'],['test_kbc_acquire_pair_binding.py','test_kbc_acquire_cli.py','test_kb_acquire_lifecycle_20261105.py'],['test_pydantic_security_pin.py','test_enrichment_hit_golden.py','test_algorithm_digests.py','test_pe_metadata_cache.py']]
receipt={'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'scope':'Integrated retention/acquisition/cache/identity under patched Pydantic; affected selections, not full-suite qualification.','results':[]}
for i,names in enumerate(groups,1):
 files=['tests/'+n for n in names]
 assert all((root/f).is_file() for f in files)
 temp=Path('/tmp')/f'pt81-integrated-phase6-{i}'
 log=out/f'integrated-phase6-{i}.log';xml=out/f'integrated-phase6-{i}.xml'
 cmd=[str(py),'-m','pytest','-q',*files,'--basetemp='+str(temp),'-o','tmp_path_retention_policy=failed','--junitxml='+str(xml)]
 start=time.monotonic()
 with log.open('w') as stream:r=subprocess.run(cmd,cwd=root,env=dict(os.environ,QT_QPA_PLATFORM='offscreen',PYTHONDONTWRITEBYTECODE='1'),stdout=stream,stderr=subprocess.STDOUT)
 suites=ElementTree.parse(xml).getroot().findall('testsuite') if xml.exists() else []
 counts={k:sum(int(s.attrib.get(k,0)) for s in suites) for k in ['tests','failures','errors','skipped']}
 result={'group':i,'command':cmd,'exit':r.returncode,'seconds':time.monotonic()-start,'counts':counts,'log':log.name,'junit':xml.name,'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
 receipt['results'].append(result);(out/'integrated-phase6-results.json').write_text(json.dumps(receipt,indent=2)+'\n');print(result,flush=True)
 if r.returncode==0 and temp.exists():shutil.rmtree(temp)
 if r.returncode in [-9,137]:break
raise SystemExit(0 if len(receipt['results'])==len(groups) and all(x['exit']==0 for x in receipt['results']) else 1)
