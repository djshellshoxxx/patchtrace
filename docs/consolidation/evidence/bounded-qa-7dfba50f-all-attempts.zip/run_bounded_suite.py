"""Run every collected test file in bounded, sequential processes on a frozen worktree."""
from __future__ import annotations

import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

repo = Path(sys.argv[1]).resolve()
python = sys.argv[2]
out = Path(sys.argv[3]).resolve()
out.mkdir(parents=True, exist_ok=True)
sha = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=repo, text=True).strip()
files = sorted(str(p.relative_to(repo)) for p in (repo / 'tests').rglob('*.py')
               if p.name.startswith('test_') or p.name.endswith('_test.py'))
prior = json.loads(Path(sys.argv[4]).read_text()) if len(sys.argv) > 4 else None
if prior:
    assert prior['commit'] == sha and prior['files'] == files
done_files = {name for r in (prior or {}).get('results', [])
              if r['exit'] == 0 and r.get('counts', {}).get('errors', 1) == 0
              and r.get('counts', {}).get('failures', 1) == 0 for name in r['files']}
groups, group, size = [], [], 0
for name in files:
    if name in done_files:
        continue
    length = (repo / name).stat().st_size
    if group and (len(group) >= 8 or size + length > 90_000):
        groups.append(group)
        group, size = [], 0
    group.append(name)
    size += length
if group:
    groups.append(group)
record = {'commit': sha, 'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'],
          cwd=repo, text=True).strip(), 'files': files, 'groups': groups, 'results': [],
          'environment': {'QT_QPA_PLATFORM': 'offscreen', 'PYTHONPATH': 'src'},
          'prior_summary': str(Path(sys.argv[4]).resolve()) if prior else None,
          'prior_completed_files': sorted(done_files),
          'started': time.time(), 'status': 'running'}

def save():
    temp = out / 'summary.tmp'
    temp.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    temp.replace(out / 'summary.json')

save()
env = {**os.environ, 'QT_QPA_PLATFORM': 'offscreen', 'PYTHONPATH': 'src',
       'PYTHONDONTWRITEBYTECODE': '1'}
scratch = Path('/tmp/patchtrace-bounded-792fd5ca6555')
scratch.mkdir(exist_ok=True)
print(f'{sha}: {len(files)} files in {len(groups)} sequential groups', flush=True)
for number, names in enumerate(groups, 1):
    if (out / 'STOP').exists():
        record['status'] = 'stopped-between-groups'
        save()
        print('Stopped between groups by task checkpoint request.', flush=True)
        raise SystemExit(2)
    tag = f'{number:03d}'
    xml = out / f'group-{tag}.xml'
    log = out / f'group-{tag}.log'
    temp = scratch / f'group-{tag}'
    command = [python, '-m', 'pytest', '-q', *names, f'--junitxml={xml}',
               f'--basetemp={temp}', '--durations=8']
    started = time.monotonic()
    result = {'group': number, 'command': command, 'files': names}
    with log.open('w', encoding='utf-8') as stream:
        try:
            child = subprocess.Popen(command, cwd=repo, env=env, stdout=stream, stderr=subprocess.STDOUT)
            peak = 0
            while child.poll() is None:
                try:
                    for line in Path(f'/proc/{child.pid}/status').read_text().splitlines():
                        if line.startswith('VmRSS:'):
                            peak = max(peak, int(line.split()[1]))
                except OSError:
                    pass
                if time.monotonic() - started > 1200:
                    child.kill()
                    child.wait()
                    raise subprocess.TimeoutExpired(command, 1200)
                time.sleep(0.25)
            result['exit'] = child.returncode
            result['peak_parent_rss_kib'] = peak
        except subprocess.TimeoutExpired:
            result['exit'] = 'timeout'
    result['seconds'] = round(time.monotonic() - started, 2)
    if xml.exists():
        root = ET.parse(xml).getroot()
        suites = list(root.iter('testsuite'))
        result['counts'] = {key: sum(int(s.get(key, 0)) for s in suites)
                            for key in ('tests', 'errors', 'failures', 'skipped')}
        result['problems'] = [{'class': c.get('classname'), 'name': c.get('name'),
                               'kind': child.tag, 'message': child.get('message', '')}
                              for c in root.iter('testcase') for child in c
                              if child.tag in {'failure', 'error'}]
    record['results'].append(result)
    save()
    print(f'group {tag}/{len(groups)} exit={result["exit"]} '
          f'counts={result.get("counts", {})} seconds={result["seconds"]}', flush=True)
    if temp.is_dir():
        shutil.rmtree(temp)
record['status'] = 'completed'
record['finished'] = time.time()
save()
print('All groups attempted; inspect summary.json for failures and blocked native gates.', flush=True)
