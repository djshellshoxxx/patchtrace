"""Bounded compatibility selections for the Pydantic-only version change."""
from pathlib import Path
import json
import os
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path('/tmp/pt81-test-harness')
OUT = Path('/workspace/scratch/81e4938f4a3a/verification')
PYTHON = '/tmp/pt81-pydantic-venv/bin/python'
contracts = sorted(str(path.relative_to(ROOT)) for path in (ROOT/'tests').glob('test_*contracts.py'))
schemas = sorted(str(path.relative_to(ROOT)) for path in (ROOT/'tests').glob('test_*schemas.py'))
groups = [
    ('models', ['tests/test_pydantic_security_pin.py', 'tests/test_models.py',
                'tests/test_enrichment_core.py', 'tests/test_enrichment_numeric_boundaries.py',
                'tests/test_research_qualification_models.py'] + contracts),
    ('schemas', schemas + ['tests/test_codex_pkg_packaging.py', 'tests/test_binexport_descriptor.py',
                          'tests/test_workflow_contract_dependencies.py']),
    ('boundaries', ['tests/test_json_recursion_boundaries.py', 'tests/test_persistence_security_20261105.py',
                    'tests/test_service_storage_audit.py', 'tests/test_cache_manifest_boundaries_20261105.py',
                    'tests/test_enrichment_storage.py', 'tests/test_enrichment_cache.py',
                    'tests/test_enrichment_retention.py', 'tests/test_enrichment_hardening.py',
                    'tests/test_pe_metadata_cache.py', 'tests/test_pe_metadata_cache_qt.py',
                    'tests/test_raw_cache.py', 'tests/test_capa_cache.py',
                    'tests/test_intel_storage.py', 'tests/test_intel_offline_cache.py',
                    'tests/test_evidence_attempt_storage.py']),
    ('stores', ['tests/test_unified_store.py', 'tests/test_unified_cor_store.py',
                'tests/test_secondary_store.py', 'tests/test_fabric_store.py', 'tests/test_kbc_store.py',
                'tests/test_kev_store.py', 'tests/test_rules_store.py', 'tests/test_buildenv_store.py',
                'tests/test_pilot_store.py', 'tests/test_pilot_store_durability.py',
                'tests/test_nway_series.py', 'tests/test_nway_series_tolerance.py',
                'tests/test_nway_path_failures.py', 'tests/test_tier_r_output_persistence.py']),
    ('cli', ['tests/test_cli.py', 'tests/test_project_cli.py', 'tests/test_compare_cli.py',
             'tests/test_pe_inspect_cli.py', 'tests/test_intel_cli.py', 'tests/test_kbc_cli.py',
             'tests/test_kev_cli.py', 'tests/test_strings_cli.py', 'tests/test_rules_cli.py',
             'tests/test_pilot_cli.py', 'tests/test_fabric_cli.py', 'tests/test_report2_cli.py',
             'tests/test_binexport_cli.py', 'tests/test_cli_secondary_run.py', 'tests/test_diaphora_cli.py',
             'tests/test_callgraph_cli.py', 'tests/test_buildenv_cli.py', 'tests/test_unified_cli.py']),
    ('goldens', ['tests/test_enrichment_hit_golden.py', 'tests/test_unified_fixture_read_model_golden.py',
                 'tests/test_intel_reports.py', 'tests/test_report_export_backup.py']),
]
groups = [(f'{name}-{start // 3 + 1:02d}', files[start:start + 3])
          for name, files in groups for start in range(0, len(files), 3)]
all_files = [file for _, files in groups for file in files]
assert len(all_files) == len(set(all_files)), 'duplicate test selection'
assert all((ROOT/file).is_file() for file in all_files), [file for file in all_files if not (ROOT/file).is_file()]
manifest = {'base':'f114eb96c392d97ad88ddbbc0bda55c159b92559', 'interpreter':PYTHON,
            'file_count':len(all_files), 'groups':[]}
(OUT/'pydantic-compatibility-bounded-results.json').write_text(json.dumps(manifest, indent=2)+'\n')
env = {**os.environ, 'PYTHONDONTWRITEBYTECODE':'1', 'QT_QPA_PLATFORM':'offscreen'}
for name, files in groups:
    prefix = 'pydantic-compatibility-' + name
    command = [PYTHON, '-B', '-m', 'pytest', '-q', '-p', 'no:cacheprovider', *files,
               '--basetemp=/tmp/pt81-pydantic-' + name, '-o', 'tmp_path_retention_policy=failed',
               '--junitxml=' + str(OUT/(prefix+'.xml'))]
    row = {'name':name, 'files':files, 'command':command, 'status':'running'}
    manifest['groups'].append(row)
    (OUT/'pydantic-compatibility-bounded-results.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(json.dumps({'starting':name, 'file_count':len(files)}), flush=True)
    start = time.monotonic()
    with (OUT/(prefix+'.log')).open('w') as log:
        completed = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    row.update(returncode=completed.returncode, duration_s=round(time.monotonic()-start, 3), status='finished')
    if (OUT/(prefix+'.xml')).exists():
        tree = ET.parse(OUT/(prefix+'.xml'))
        row['junit'] = [dict(suite.attrib) for suite in tree.iter('testsuite')]
        row['skips'] = [{'case':case.get('classname') + '::' + case.get('name'), 'reason':skip.get('message')}
                        for case in tree.iter('testcase') for skip in case.findall('skipped')]
    row['summary'] = (OUT/(prefix+'.log')).read_text().splitlines()[-1:]
    (OUT/'pydantic-compatibility-bounded-results.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print(json.dumps({key:row[key] for key in ('name','returncode','duration_s','summary')}), flush=True)
    if completed.returncode:
        raise SystemExit(completed.returncode)
