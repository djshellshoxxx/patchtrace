"""Regenerate every repository schema generator under the old and new validators."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import time

CHECKOUT = Path('/tmp/pt81-test-harness')
RECEIPTS = Path('/workspace/scratch/81e4938f4a3a/verification')
MODULES = sorted('tools.' + path.stem for path in (CHECKOUT/'tools').glob('generate*schemas.py'))
MODULES += ['tools.calibration.schemas', 'tools.calibration.tier_r.schemas', 'tools.calibration.tier_r.report_schemas']


def snapshot():
    paths = [path for path in (CHECKOUT/'docs/schemas').rglob('*') if path.is_file()]
    paths.append(CHECKOUT/'src/patchtrace/intelligence/csaf/schema_data.py')
    return {str(path.relative_to(CHECKOUT)): hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(paths)}


initial = snapshot()
result = {'modules': MODULES, 'initial': initial, 'phases': []}
env = {**os.environ, 'PYTHONDONTWRITEBYTECODE': '1'}
with (RECEIPTS/'pydantic-schema-compare.log').open('w') as log:
    for phase, interpreter in [('old', '/tmp/pt81-test-harness-venv/bin/python'),
                               ('new', '/tmp/pt81-pydantic-venv/bin/python')]:
        phase_result = {'phase': phase, 'interpreter': interpreter, 'commands': []}
        result['phases'].append(phase_result)
        for module in MODULES:
            command = [interpreter, '-B', '-m', module]
            start = time.monotonic()
            log.write(json.dumps({'phase': phase, 'command': command}) + '\n')
            log.flush()
            completed = subprocess.run(command, cwd=CHECKOUT, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=90)
            phase_result['commands'].append({'command': command, 'returncode': completed.returncode,
                                             'duration_s': round(time.monotonic()-start, 3)})
            if completed.returncode:
                (RECEIPTS/'pydantic-schema-compare.json').write_text(json.dumps(result, indent=2)+'\n')
                raise SystemExit(completed.returncode)
        generated = snapshot()
        phase_result['snapshot'] = generated
        phase_result['changed'] = [name for name in sorted(set(initial)|set(generated)) if initial.get(name) != generated.get(name)]
        (RECEIPTS/'pydantic-schema-compare.json').write_text(json.dumps(result, indent=2)+'\n')
        print(json.dumps({'phase': phase, 'modules': len(MODULES), 'files': len(generated), 'changed': phase_result['changed']}), flush=True)
        if phase_result['changed']:
            raise SystemExit(1)
