import ast
import gc
import json
import platform
import statistics
import time
from pathlib import Path
from patchtrace.codetext import tokens

root=Path('/workspace/scratch/3101cbc8680b/patchtrace-asm')
namespace={}
for node in ast.parse((root/'tests/test_codetext_tokens.py').read_text()).body:
    if isinstance(node,ast.FunctionDef) and node.name=='realistic_asm':
        exec(compile(ast.Module(body=[node],type_ignores=[]),'fixture','exec'),namespace)
text=namespace['realistic_asm']()[:200000]
report={'python':platform.python_version(),'gc_enabled':gc.isenabled(),'gc_thresholds':gc.get_threshold(),'samples':[]}
for _ in range(20):
    events=[]
    started={}
    def observe(phase,info):
        generation=info['generation']
        if phase=='start':
            started[generation]=time.perf_counter()
        else:
            events.append({'generation':generation,'seconds':time.perf_counter()-started[generation], 'collected':info['collected']})
    gc.callbacks.append(observe)
    cpu=time.process_time()
    wall=time.perf_counter()
    tokens.tokenize(text,'asm')
    elapsed=time.perf_counter()-wall
    cpu_elapsed=time.process_time()-cpu
    gc.callbacks.remove(observe)
    report['samples'].append({'wall_seconds':elapsed,'cpu_seconds':cpu_elapsed,'collections':events})
Path('/workspace/scratch/3101cbc8680b/asm-evidence/gc-observation.json').write_text(json.dumps(report,indent=2)+'\n')
for s in report['samples']:
    print('wall',round(s['wall_seconds']*1000,3),'cpu',round(s['cpu_seconds']*1000,3),'GC ms', round(sum(e['seconds'] for e in s['collections'])*1000,3),'collections',[sum(e['generation']==i for e in s['collections']) for i in range(3)])
