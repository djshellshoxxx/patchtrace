import ast
import gc
import hashlib
import json
import platform
import random
import statistics
import time
from pathlib import Path

from patchtrace.codetext import tokens

root = Path('/workspace/scratch/3101cbc8680b/patchtrace-asm')
namespace = {}
for node in ast.parse((root / 'tests/test_codetext_tokens.py').read_text()).body:
    if isinstance(node, ast.FunctionDef) and node.name == 'realistic_asm':
        exec(compile(ast.Module(body=[node], type_ignores=[]), 'fixture', 'exec'), namespace)
original = tokens._SCANNERS['asm']

def scan_findall(line, base, in_comment, out):
    append, memo, new = out.append, tokens._ASM_MEMO, tokens._new_token
    start, expect_mnemonic = base, True
    for ws, number, word, punct, op, comment, string, char, other in tokens._ASM_SCAN.findall(line):
        if ws:
            kind, value = 'ws', ws
        elif number:
            kind, value = 'number', number
        elif word:
            value = word
            kind = memo.get(word) or tokens._remember(memo, word, tokens._asm_word_kind(word))
            end = start - base + len(word)
            if expect_mnemonic and kind != 'auto_name' and not (
                    line.startswith(':', end) and not line.startswith('::', end)):
                kind = 'mnemonic'
                expect_mnemonic = word.lower() in tokens._PREFIX_MNEMONICS
        elif punct:
            kind, value = 'punct', punct
        elif op:
            kind, value = 'op', op
        elif comment:
            kind, value = 'comment', comment
        elif string:
            kind, value = 'string', string
        elif char:
            kind, value = 'char', char
        else:
            kind, value = 'other', other
        stop = start + len(value)
        append(new(tokens.Token, (kind, start, stop)))
        start = stop
    return False

candidate = tokens._Scanner(scan_findall, original.open_after)
rng = random.Random(322)
fragments = ['MOV', 'rep', 'LOCK', 'FUN_1234', 'uVar1', 'name::member', 'rax', ':', '::', '.5', '0x10', '0x', '10h',
             '\n', '\r', '\t', ' ', '\x00', '\u202e', '\ud800', '"', "'", '\\', '->', '-', ';', '/', '.', '_', '$', '?', '@', '[', ']']
cases = [''.join(rng.choices(fragments, k=rng.randrange(1, 80))) for _ in range(5000)]
for text in cases:
    tokens._SCANNERS['asm'] = original
    baseline = tokens.tokenize(text, 'asm')
    tokens._SCANNERS['asm'] = candidate
    assert tokens.tokenize(text, 'asm') == baseline, repr(text)
samples = {
    'gate': namespace['realistic_asm']()[:200000],
    'varied': '\n'.join(f'LAB_{0x140000000+i:09x}: MOV R{i%16},qword ptr [RSP + 0x{i:x}]; row {i}' for i in range(10000))[:200000],
    'dense': ('MOV RAX,RBX\nADD EAX,10h\nLOCK XADD [RSP],RAX\n' * 10000)[:200000],
}
report = {'python': platform.python_version(), 'gc_enabled': gc.isenabled(), 'gc_thresholds': gc.get_threshold(), 'parity_cases': len(cases), 'results': {}}
for name, text in samples.items():
    tokens._SCANNERS['asm'] = original
    expected = tokens.tokenize(text, 'asm')
    tokens._SCANNERS['asm'] = candidate
    assert tokens.tokenize(text, 'asm') == expected
    data = {'input_sha256':hashlib.sha256(text.encode()).hexdigest(), 'characters':len(text), 'tokens':len(expected), 'blocks':[]}
    for block in range(10):
        order = ['original', 'candidate'] if block % 2 == 0 else ['candidate', 'original']
        row = {'order': order}
        for version in order:
            tokens._SCANNERS['asm'] = original if version == 'original' else candidate
            tokens.tokenize(text, 'asm')
            times = []
            for _ in range(5):
                started = time.perf_counter()
                tokens.tokenize(text, 'asm')
                times.append(time.perf_counter() - started)
            row[version] = times
        data['blocks'].append(row)
    report['results'][name] = data
    medians = {v: statistics.median([min(b[v]) for b in data['blocks']]) for v in ('original','candidate')}
    print(name, medians, 'reduction', 1-medians['candidate']/medians['original'], flush=True)
tokens._SCANNERS['asm'] = original
Path('/workspace/scratch/3101cbc8680b/asm-evidence/findall-probe.json').write_text(json.dumps(report,indent=2)+'\n')
