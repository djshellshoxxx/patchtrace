"""Synthetic assertion-message control; never reported as a measured lexer failure."""
import sys
sys.path.insert(0, '/workspace/scratch/3101cbc8680b/patchtrace-asm/tests')
import test_codetext_tokens as gate

samples = (0.170, 0.160, 0.156169465, 0.161, 0.171)
clock = iter(samples)
gate._elapsed = lambda call: next(clock)
try:
    gate.test_200k_characters_tokenize_within_the_budget('asm', gate.realistic_asm)
except AssertionError as exc:
    message = str(exc)
    print('Synthetic gate failure message:', repr(message))
    assert 'samples_seconds=' in message and repr(samples) in message, 'all five samples missing from failure message'
    assert 'best_seconds=0.156169465' in message, 'best sample missing'
    assert 'budget_seconds=0.150' in message, 'budget missing'
    assert '200000 characters' in message, 'actual input length missing'
else:
    raise AssertionError('strict gate accepted over-budget values')
print('Synthetic failure diagnostics control passed')
