import ast
import gc
import hashlib
import json
import platform
import random
import re
import statistics
import time
from pathlib import Path

from patchtrace.codetext import tokens

root = Path('/workspace/scratch/3101cbc8680b/patchtrace-asm')
namespace = {}
module = ast.parse((root / 'tests/test_codetext_tokens.py').read_text())
for node in module.body:
    if isinstance(node, ast.FunctionDef) and node.name in ('realistic_asm', 'realistic_c'):
        exec(compile(ast.Module(body=[node], type_ignores=[]), 'fixture', 'exec'), namespace)
original = tokens._ASM_SCAN
candidate = re.compile(rf'''
    [ \t\r\n\f\v]+(?P<ws>)
  | (?:0[xX][0-9A-Fa-f]++|[0-9]++(?:\.[0-9]++)?|\.[0-9]++)[A-Za-z0-9_]*+(?P<number>)
  | [A-Za-z_.$@?][A-Za-z0-9_.$@?]*+(?:::[A-Za-z0-9_.$@?]++)*+(?P<word>)
  | [()\[\]{{}},:](?P<punct>)
  | (?:->|[-+*/%&|^~<>=!])(?P<op>)
  | ;[^\n]*(?P<comment>)
  | "{tokens._QUOTED}(?P<string>)
  | '{tokens._CHAR}(?P<char>)
  | (?:[^\x00-\x7f]++|[\x00-\x08\x0e-\x1f\x7f]++|[\s\S])(?P<other>)
''', re.VERBOSE | re.ASCII)
assert original.groupindex == candidate.groupindex
rng = random.Random(322)
fragments = ['MOV', 'rep', 'LOCK', 'FUN_1234', 'uVar1', 'name::member', 'rax', ':', '::', '.5', '0x10', '0x', '10h',
             '\n', '\r', '\t', ' ', '\x00', '\u202e', '\ud800', '"', "'", '\\', '->', '-', ';', '/', '.', '_', '$', '?', '@', '[', ']']
cases = [''.join(rng.choices(fragments, k=rng.randrange(1, 80))) for _ in range(20000)]
cases.extend(chr(n) for n in range(128))
for text in cases:
    def spans(pattern):
        return [(m.group(), m.span(), m.lastindex) for m in pattern.finditer(text)]
    assert spans(original) == spans(candidate), repr(text)

samples = {
    'gate': namespace['realistic_asm']()[:200000],
    'varied': '\n'.join(f'LAB_{0x140000000+i:09x}: MOV R{i%16},qword ptr [RSP + 0x{i:x}]; row {i}' for i in range(10000))[:200000],
    'dense': ('MOV RAX,RBX\nADD EAX,10h\nLOCK XADD [RSP],RAX\n' * 10000)[:200000],
}
report = {'python': platform.python_version(), 'gc_enabled': gc.isenabled(), 'gc_thresholds': gc.get_threshold(), 'parity_cases': len(cases), 'results': {}}
for name, text in samples.items():
    tokens._ASM_SCAN = original
    expected = tokens.tokenize(text, 'asm')
    tokens._ASM_SCAN = candidate
    assert tokens.tokenize(text, 'asm') == expected
    data = {'input_sha256':hashlib.sha256(text.encode()).hexdigest(), 'characters':len(text), 'tokens':len(expected), 'blocks':[]}
    for block in range(10):
        order = ['original', 'candidate'] if block % 2 == 0 else ['candidate', 'original']
        row = {'order': order}
        for version in order:
            tokens._ASM_SCAN = original if version == 'original' else candidate
            tokens.tokenize(text, 'asm')
            times = []
            for _ in range(5):
                started = time.perf_counter()
                tokens.tokenize(text, 'asm')
                times.append(time.perf_counter() - started)
            row[version] = times
        data['blocks'].append(row)
    report['results'][name] = data
    medians = {v: statistics.median([min(b[v]) for b in data['blocks']]) for v in ('original','candidate')}
    print(name, medians, 'reduction', 1-medians['candidate']/medians['original'], flush=True)
tokens._ASM_SCAN = original
Path('/workspace/scratch/3101cbc8680b/asm-evidence/marker-probe.json').write_text(json.dumps(report,indent=2)+'\n')
