# Forced strings-export replacement: bounded recovery and design review

Date: 2026-11-19. This review is read-only with respect to project source, tests,
shared documents and remote branches. Its machine-readable evidence is in
[strings-force-replacement-review-20261119.json](strings-force-replacement-review-20261119.json).

## Decision

No complete, compatible forced-replacement repair was found in the inspected
retained history. The newly observed PR #319 head
`8d130aefe1be6e737cff1d90d2a5b1658d60a3a6` contains the same exporter,
publication helper and WB3 publication specification as the previously retained
`a56ab13aaf9916fc12bea70ba1494075991b7f09`. The old lineage remains intact.

There is a concrete Windows implementation direction: retain the existing source
handle and directory handles, and perform an explicitly replacing native rename.
The existing helper already implements the corresponding **no-replace** operation.
This would be new, narrowly scoped work, not a missing cherry-pick. Native Windows
qualification and path-admission compatibility remain necessary before acceptance.

For Linux, the inspected rename/link interfaces do not combine source-descriptor
identity with atomic replacement of an existing destination. A directory-relative
rename can protect the selected parent while still resolving a mutable source
name. A descriptor-sourced hard link refuses an existing destination. Rejecting
the unsafe force path would prevent that publication, but would reduce the
existing Linux `--force` behavior. It must be an explicit contract decision,
not reported as a behavior-preserving recovery.

## Exact scope and contract

The requested integration baseline is
`7d4aead2f10580b80d6c856fc37d26da5a3b6d17`. The observed integration head
`f26ba7b7561bf72a1c3c1b43267b6e32b785835f` has identical contents for both
reviewed runtime files. This is a file-specific comparison, not a qualification
of either whole tree.

| Runtime path | Git blob at the requested baseline | SHA-256 |
| --- | --- | --- |
| `src/patchtrace/strings/export.py` | `d31789af27098afb2191aeda4eaf1e2d2bd0b63e` | `61cade4a41cc7e79cdd7d193ecc4c5880c4fb742a858e017658c5b2cbe3b5850` |
| `src/patchtrace/owned_publication.py` | `734245b4a88bd19155809e7be02ef56bf141cc05` | `b9f6d60a64b2c426f43c71d282805a48f4013445e408a3dd3b6fe520afeebedd` |

The governing contract is WB3 section 8 in
[`WB3-integration-plan.md`](../PatchTrace/docs/specs/program-e/WB3-integration-plan.md).
It explicitly distinguishes held-source/held-parent no-force publication from
the remaining pathname-based force operation. Force still stages exclusively,
writes and flushes, then replaces the destination. On failure it closes owned
handles without unlinking a mutable stage name. Ordinary I/O failures remain
`PT-STR-EXPORT`; cancellation and other non-I/O exceptions retain their original
types. The current specification openly records the successful-force ownership
gap.

`test_never_overwrites_without_force` in
[`test_strings_export.py`](../PatchTrace/tests/test_strings_export.py) includes the
positive requirement that `force=True` replaces an existing export. A proposed
implementation that only creates missing destinations does not preserve this
requirement. JSON/CSV rendering, redaction, basis, lineage and the export contract
version are independent of the storage repair.

The ownership question here concerns the byte source and selected directory.
The current force contract does not additionally require a compare-and-swap
against a previously inspected destination inode. Such a requirement would be a
separate product/contract change. The resulting filename is also not promised to
remain immutable against writers after the publication operation.

## Existing successful-race evidence still applies

The preserved
[force probe](strings-ownership-peer-batch7-force-probe.json) observed three
authored schedules at `2026-11-19T12:54:27.004450+00:00`. Its exporter SHA-256 is
exactly the current hash above. The source
[probe program](strings-ownership-peer-batch7-force-probe.py) uses authored bytes
and temporary directories; it does not execute compared binaries. This review
reuses that evidence and does not claim a new execution.

| Schedule | Preserved observation | Disposition |
| --- | --- | --- |
| Replace the stage entry immediately before the real `os.replace` | The function returns success with foreign bytes at the target. The parked original stage retains the intended bytes. | Successful source binding remains broken. |
| Move the selected parent aside, create a replacement directory and stage entry, then call the real `os.replace` | The function returns success and writes foreign bytes in the replacement parent. The original parent's prior export remains. | Successful source and parent binding remain broken. |
| Substitute the stage, then raise an authored I/O error | `PT-STR-EXPORT`; the prior export, foreign stage and parked original stage remain. | The accepted failure-cleanup repair remains evidenced. |

The source explains these observations: `write_atomic(force=True)` closes the
stream before `os.replace(stage, path)`, leaving both operands as pathnames.
`export_delta` subsequently returns the digest of the intended rendered bytes.
Therefore a false-success publication can associate that intended digest with
different bytes at the destination. This consequence follows from the current
caller; it is not an additional separately executed probe.

The independent
[final review](strings-independent-final-review-20261119.md) and
[commit binding](strings-independent-final-commit-binding-20261119.json) already
separated the accepted no-force/cleanup slice from these failures. Their Linux
and portable Windows-model observations do not qualify native Windows force.

## Bounded branch and source recovery

The review enumerated `git rev-list --all --full-history` for the two runtime
paths, then separately included the latest PR #319 head. This covers **29 unique
path-history commits**, including merge trees. The latest head contributes nine
path-history commits, all already present in that set. The trees reduce to
**four exporter blobs and three non-absent helper blobs**. The JSON records every
commit, parent, blob, digest and grouping. This is a bounded path-history result,
not a repeated census or a claim about every unrelated file on every branch.

| Exact retained point | Relevant contents and disposition |
| --- | --- |
| PR #319 old `a56ab13aaf9916fc12bea70ba1494075991b7f09` | Exporter `28a79b13e0ae70d158a5ac2c3494311f9717bfdb`; helper `71f3bbd5b74fb8ddfa212001e50ade82e4340354`. No held-source force replacement. |
| PR #319 latest `8d130aefe1be6e737cff1d90d2a5b1658d60a3a6` | Exact same two blobs and WB3 specification as a56; a56 is an ancestor. No additional recovery in this slice. |
| PR #320 `188b4962e527c82b29e599f75cd952029b749348` | Same two retained blobs. No force repair. |
| PR #321 `976dddfbbcdf9a320e48813d8cf2c3c6540aac81` | Same two retained blobs. No force repair. |
| `2e37daf175533113fe73dc9a903f797a10ea9fc9` | Random exclusive staging history; force still closes the source before pathname replacement. Its pathname cleanup also predates the accepted preservation fix. Not a repair candidate. |
| `e5c75e24882ac62cda798883bddb5c11150989d5` | Introduces the held-source/held-parent helper. Native `ReplaceIfExists` is false. Useful infrastructure already represented in the current tree. |
| `4b12c5e547bb1abb6a255389a42c159e348581f7` | Its helper differs from the prior helper only by trailing blank lines. No replacement semantics added. |
| `f6c4b0844e5973ba054d58490628e77492d57ec0` | Accessible retained no-force/cleanup lineage used by batch 7; no force-success repair. |
| `397abd44325ccf6d37aa1f95c86383e305fb3b0e` | Accepted batch 7 source, already integrated. Exactly the current exporter/helper blobs. Its scope deliberately leaves successful force unresolved. |

All four exporter variants retain a pathname-based forced `os.replace`. The
helper variants use no-replace native rename; the current helper's semantic
addition is anchor validation before directory creation. The alternate native
helper in `tools/research_qualification/winpairs.py` also sets replacement false.
Source searches at the requested baseline and the new PR #319 head found no
alternate replacing handle primitive in the inspected runtime/tooling sites.

The historical hashes `e14331018d53370e9f4cdf70bd485349a3fec496`,
`6e0342ff5217552e14fb37739a4e529ca5db089b` and
`14f0e2c973dc5a9f6025aa6fa98138b1efe07023` remain unavailable as local Git objects
after the new fetch. Their retained reports describe no-force ownership and
cancellation cleanup, and explicitly leave successful force unresolved. They
are documentation evidence, not newly recovered source commits.

The exact latest-head fetch used `--no-write-fetch-head --no-tags
--no-auto-maintenance` and requested only its SHA. This review did not update
refs, push, or overwrite another checkout.

## Native primitive assessment

The documented desktop target is Windows 10/11 x64; Linux packaging uses an
Ubuntu 22.04 build baseline with 22.04/24.04 smoke targets. Those project targets
come from the baseline `docs/windows.md` and `docs/linux.md`; no new platform
acceptance is inferred here.

| Operation | Documented capability | Relevance to the current source |
| --- | --- | --- |
| Windows `FileRenameInformation` | The source is specified by a file handle; a relative target can use a directory handle; `ReplaceIfExists` selects replacement. Same-volume, access, sharing and filesystem restrictions apply. [Microsoft native API](https://learn.microsoft.com/en-us/windows-hardware/drivers/ddi/ntifs/ns-ntifs-_file_rename_information) | `WindowsPublication.rename` already supplies the two handles but sets replacement false. |
| Windows `SetFileInformationByHandle` rename structure | Documents the same replacement control and relative destination-root field. [Microsoft Win32 structure](https://learn.microsoft.com/en-us/windows/win32/api/winbase/ns-winbase-file_rename_info) | Confirms a source-handle design direction; it does not qualify this project's ctypes binding or native behavior. |
| Linux `renameat` / `renameat2` | Directory descriptors bind pathname resolution. The source is still a name; the documented flags add exchange, no-replace and whiteout. [Linux rename manual](https://man7.org/linux/man-pages/man2/rename.2.html) | Holding the parent prevents retargeting into a substituted directory, but holding the source fd separately does not make rename consume that fd. |
| Linux `linkat` | A held source can be linked through `AT_EMPTY_PATH`, or procfs with symlink following; existing destination names are not overwritten. [Linux link manual](https://man7.org/linux/man-pages/man2/link.2.html) | The current anonymous-stage helper can create exclusively, but cannot supply force overwrite. |

### Actionable Windows slice

The following is a proposed implementation and qualification plan, not an
accepted change:

1. Specify a separate replacement operation for the ordinary-parent case.
   Preserve `publish_bytes` as never-replace for every existing caller. Do not
   change the default flag on a shared immutable-evidence API.
2. Reuse the current rooted directory traversal and selected-parent anchor. Open
   the stage relative to the held directory, retain its source handle through
   write, flush and verification, and keep the directory chain alive through
   publication. The existing source handle denies write/delete sharing; the
   directory guards deny delete sharing.
3. Invoke the native rename using that source handle, the held destination
   directory and explicit replacement. Do not add POSIX replacement flags,
   read-only overrides, copy fallback or a pathname fallback as incidental
   compatibility work.
4. Preserve primary exceptions and ownership of descriptor transfers. Cleanup
   must only act on the held object when its disposition is known; a failure
   after possible publication is not proof of rollback or of an absent output.
5. Before acceptance, run native Windows controls for ordinary overwrite,
   creation when absent, missing parents, folder targets, source substitution,
   ancestor replacement, reparse points, read-only/open destinations, I/O
   failures and cancellation. Verify final bytes/digest, retained prior evidence
   on definite refusal, and no foreign-entry deletion. Retain the existing
   JSON/CSV and no-force collision assertions.

This can preserve the meaningful force-overwrite operation on a supported native
filesystem. It is **not yet a proven drop-in replacement for every accepted
path**: the safe helper rejects reparse parents, whereas the old pathname route
can traverse them, and native sharing/filesystem behavior still needs direct
comparison. Any stricter admission must be documented in the force contract.
Portable handle models can check call wiring but cannot discharge this gate.

### Linux boundary and policy choices

The following conclusions are design inferences from the inspected code, API
contracts and preserved schedules:

- **A parent-only repair is possible.** Stage and replace relative to a held
  selected directory, validating its anchor. That can prevent writing into the
  substituted parent from the preserved schedule. It remains a partial repair
  because the final source entry can still be substituted.
- **A named intermediate restores the same gap.** Linking the anonymous source
  to a random stage and then renaming that stage creates another replaceable
  source entry. An open source fd, randomness, same-user directory permissions
  or cooperative locking does not establish the missing source-binding invariant
  against the actor allowed by the authored replacement schedules.
- **Detection does not restore atomic custody.** Pre/post identity or digest
  checks leave an interval around the name-based operation. An exchange followed
  by verification can already have exposed foreign bytes; a later rollback is
  another concurrent mutation, not proof that publication was safe.
- **Deleting first loses the existing guarantee.** Unlinking the prior export
  before linking the held source introduces a missing-destination interval and
  can discard prior evidence on a later failure. Renaming `/proc/self/fd/N` is
  also not the descriptor-following hard-link operation used by the helper.
- **Failing closed changes functionality.** Refusing force when safe replacement
  is unavailable is clear and implementable. Restricting force to an absent
  destination is another refusal policy. Both cease to satisfy the existing
  ordinary overwrite control on Linux; neither is a transparent completion of
  the current behavior.

No inspected retained commit resolves this tradeoff. A trusted isolated staging
service, a different principal, filesystem-specific machinery, or a future
primitive would require new assumptions and architecture. This review does not
claim a general impossibility theorem about all such designs.

## Recommended disposition

Keep successful forced-source/parent replacement **open**. Treat Windows as a
bounded implementation candidate followed by native qualification. Treat Linux
as a partial parent-binding opportunity plus an explicit replacement-policy
decision; do not hide the source gap behind passing checks or no-force evidence.
There is no complete retained commit to cherry-pick for this boundary.

This pass performed source/history/hash inspection, one exact-SHA fetch and
primary API documentation review. It added no runtime experiment, test pass,
native claim, packaging result or release acceptance. Project source and tests
were not changed. The JSON preserves the exact comparison and evidence hashes
for a later independently reviewed implementation.
