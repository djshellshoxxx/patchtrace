from __future__ import annotations

import collections
import datetime as dt
import hashlib
import io
import json
import subprocess
import zipfile
from pathlib import Path

ROOT = Path('/workspace/scratch/81e4938f4a3a')
REPO = ROOT / 'pt-census'
OUT = REPO / 'docs/consolidation'
MAIN = 'fdc2696c23bdbfe7668348f25e3b336ce33039f7'
CANDIDATE = 'a56ab13aaf9916fc12bea70ba1494075991b7f09'
BROAD = 'c4ace2088ce8dc9ce78a0bf3036b81096accbdb5'
PRIOR_PATH = 'docs/audits/consolidation-20261119/post-foundation-evidence.zip'
FOOTPRINT_PATH = 'docs/plans/autonomous-consolidation-20261118/branch-inventory.json'


def command(*args: str, timeout: int = 45) -> str:
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True, timeout=timeout)


def blob(ref: str, path: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(REPO), 'show', f'{ref}:{path}'], timeout=30)


def sha256(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


snapshot_raw = (ROOT / 'census-remote-snapshot.json').read_bytes()
snapshot = json.loads(snapshot_raw)
assert snapshot['main'] == MAIN
assert snapshot['page_sizes'] == [100, 100, 100, 20, 0]
assert len(snapshot['branches']) == len({r['name'] for r in snapshot['branches']}) == 320
assert next(r['sha'] for r in snapshot['branches'] if r['name'] == 'main') == MAIN
prior_raw = blob(CANDIDATE, PRIOR_PATH)
with zipfile.ZipFile(io.BytesIO(prior_raw)) as archive:
    prior = json.loads(archive.read('post-foundation-residue.json'))
    simulations = json.loads(archive.read('post-foundation-merge-simulations.json'))
assert prior['baselines']['main'] == simulations['main'] == MAIN
old_rows = {(r['name'], r['sha']): r for r in prior['branches']}
old_by_name = {r['name']: r for r in prior['branches']}
old_sims = {(r['branch'], r['head']): r for r in simulations['branches']}
footprint_raw = blob(BROAD, FOOTPRINT_PATH)
footprints = json.loads(footprint_raw)
old_files = {(r['branch'], r['head_sha']): r for r in footprints['branches']}
pulls_raw = (ROOT / 'all-prs.json').read_bytes()
pulls = json.loads(pulls_raw)
by_branch = collections.defaultdict(list)
for pull in pulls:
    by_branch[pull['head']].append(pull)
main_history = set(command('rev-list', MAIN).splitlines())
candidate_history = set(command('rev-list', CANDIDATE).splitlines())
broad_history = set(command('rev-list', BROAD).splitlines())
rows = []
delta_rows = []
reused = 0
fresh_files = 0
for item in sorted(snapshot['branches'], key=lambda x: x['name']):
    name, tip = item['name'], item['sha']
    key = name, tip
    prior_row = old_rows.get(key)
    in_main = tip in main_history
    if prior_row is not None:
        comparison = dict(prior_row['comparisons']['main'])
        assert comparison['baseline'] == MAIN and comparison['ancestor'] == in_main
        merge_base = prior_row['merge_base']
        ahead = prior_row['ahead_main']
        behind = prior_row['behind_main']
        subject = prior_row['subject']
        provenance = 'reused exact main SHA and exact branch head SHA from prior census'
        reused += 1
    elif in_main:
        comparison = {'baseline': MAIN, 'ancestor': True, 'unmatched_nonmerge_commits': [],
                      'equivalent_nonmerge_commits': [], 'merge_commits': []}
        merge_base = tip
        ahead = 0
        behind = int(command('rev-list', '--count', f'{tip}..{MAIN}').strip())
        subject = command('show', '-s', '--format=%s', tip).strip()
        provenance = 'fresh ancestry from pinned main history; no unique patches'
    else:
        merge_base = command('merge-base', MAIN, tip).strip()
        ahead = int(command('rev-list', '--count', f'{MAIN}..{tip}').strip())
        behind = int(command('rev-list', '--count', f'{tip}..{MAIN}').strip())
        unmatched, equivalent = [], []
        for line in command('cherry', MAIN, tip).splitlines():
            sign, patch = line.split()
            (unmatched if sign == '+' else equivalent).append(patch)
        comparison = {'baseline': MAIN, 'ancestor': False, 'unmatched_nonmerge_commits': unmatched,
                      'equivalent_nonmerge_commits': equivalent,
                      'merge_commits': command('rev-list', '--merges', f'{MAIN}..{tip}').splitlines()}
        subject = command('show', '-s', '--format=%s', tip).strip()
        provenance = 'fresh delta-only merge-base, ancestry and git cherry comparison'
    if in_main:
        for field in ('unmatched_nonmerge_commits', 'equivalent_nonmerge_commits', 'merge_commits'):
            comparison.setdefault(field, [])
    else:
        assert all(field in comparison for field in
                   ('unmatched_nonmerge_commits', 'equivalent_nonmerge_commits', 'merge_commits'))
    if prior_row is None:
        delta_rows.append({'branch': name, 'head': tip, 'previous_head': old_by_name.get(name, {}).get('sha'),
                           'evidence': provenance})
        print(f'Compared changed/new head: {name}', flush=True)
    if name == 'main':
        disposition = 'baseline'
    elif in_main:
        disposition = 'integrated-by-ancestry'
    elif not comparison['unmatched_nonmerge_commits'] and not comparison['merge_commits']:
        disposition = 'patch-equivalent-only'
    elif tip in candidate_history:
        disposition = 'contained-in-pr319'
    elif tip in broad_history:
        disposition = 'contained-in-broad-candidate'
    elif name.startswith('automation/') or 'skills-manifest' in name or 'skills-spec56' in name:
        disposition = 'retained-experimental'
    elif name.startswith(('docs/', 'research/')):
        disposition = 'retained-research-or-docs'
    else:
        disposition = 'retained-for-semantic-review'
    if name == 'main' or in_main:
        simulation = {'conflicts': False, 'paths': [], 'evidence': 'exact main ancestry'}
    elif key in old_sims:
        s = old_sims[key]
        simulation = {'conflicts': s['conflicts'], 'paths': s['paths'],
                      'evidence': 'reused exact main SHA and exact branch head SHA'}
    else:
        p = subprocess.run(['git', '-C', str(REPO), 'merge-tree', '--write-tree', '--name-only',
                            '--no-messages', MAIN, tip], capture_output=True, text=True, timeout=45)
        assert p.returncode in (0, 1), p.stderr
        simulation = {'conflicts': p.returncode == 1, 'paths': p.stdout.splitlines()[1:] if p.returncode else [],
                      'evidence': 'fresh delta-only simulation'}
    f = old_files.get(key)
    if in_main:
        files = []
        file_provenance = 'no source delta outside main ancestry'
    elif f and f['main_merge_base'] == merge_base:
        files = f['main_delta_file_comparison']['changed_paths']
        file_provenance = 'reused identical head and identical merge-base path footprint'
    else:
        files = command('diff', '--name-only', '-z', merge_base, tip).rstrip('\0').split('\0')
        files = [x for x in files if x]
        file_provenance = 'fresh source delta from pinned merge base'
        fresh_files += 1
    associations = [{'number': p['number'], 'state': p['state'], 'draft': p.get('draft'),
                     'title': p['title'], 'head': p['head_sha'], 'head_matches_tip': p['head_sha'] == tip,
                     'merged_at': p.get('merged_at')} for p in by_branch.get(name, [])]
    rows.append({'branch': name, 'head': tip, 'subject': subject, 'disposition': disposition,
                 'merge_base': merge_base, 'ahead_main': ahead, 'behind_main': behind,
                 'comparison': comparison, 'comparison_evidence': provenance,
                 'in_pr319': tip in candidate_history, 'in_broad_candidate': tip in broad_history,
                 'merge_simulation': simulation, 'source_delta_files': sorted(set(files)),
                 'file_evidence': file_provenance, 'pull_requests': associations,
                 'ci_status': 'not refreshed in this census; current-head qualification required',
                 'semantic_review': 'retained unless exact ancestry or scoped recovery is documented',
                 'delete_authorized': False})
file_catalog = sorted({p for row in rows for p in row['source_delta_files']})
file_ids = {name: i for i, name in enumerate(file_catalog)}
for row in rows:
    row['source_delta_file_ids'] = [file_ids[p] for p in row.pop('source_delta_files')]
counts = dict(sorted(collections.Counter(r['disposition'] for r in rows).items()))
record = {'schema': 'patchtrace/consolidation-census/1', 'observed_at_utc': snapshot['observed_at_utc'],
          'generated_at_utc': dt.datetime.now(dt.timezone.utc).isoformat(), 'main': MAIN,
          'candidate_pr319': CANDIDATE, 'broad_candidate_pr318': BROAD,
          'coverage': {'branches': len(rows), 'topic_branches': len(rows) - 1,
                       'branch_page_sizes': snapshot['page_sizes'], 'all_state_prs': len(pulls),
                       'open_prs': sum(p['state'] == 'open' for p in pulls),
                       'exact_prior_rows_reused': reused, 'delta_rows': len(delta_rows),
                       'new_path_footprints': fresh_files},
          'counts': counts, 'changes_from_prior_census': delta_rows,
          'inputs': {'remote_snapshot_sha256': sha256(snapshot_raw), 'all_prs_sha256': sha256(pulls_raw),
                     'prior_zip': f'{CANDIDATE}:{PRIOR_PATH}', 'prior_zip_sha256': sha256(prior_raw),
                     'historical_footprints': f'{BROAD}:{FOOTPRINT_PATH}',
                     'historical_footprints_sha256': sha256(footprint_raw)},
          'limits': ['Retained disposition is not completed semantic review or recovered functionality.',
                     'Ancestry, patch equivalence, merge compatibility and runtime acceptance are distinct.',
                     'PR associations use ref-name matches; head_matches_tip records exact source equality.',
                     'No current CI approval is inferred; PR319 and broad candidates remain unmerged here.',
                     'source_delta_file_ids index file_catalog; footprints do not prove missing current behavior.',
                     'The earlier full recomputation timed out; only reused exact evidence and completed deltas are claimed.'],
          'file_catalog': file_catalog, 'branches': rows}
OUT.mkdir(parents=True, exist_ok=True)
(OUT / 'BRANCH_INVENTORY.json').write_text(json.dumps(record, separators=(',', ':'), ensure_ascii=True) + '\n')
meaning = {'baseline': 'Pinned main, not a topic branch.',
           'integrated-by-ancestry': 'Exact head already belongs to pinned main history.',
           'patch-equivalent-only': 'Nonmerge patches match main; no unique merge commits; semantic context remains retained.',
           'contained-in-pr319': 'Exact head is in the unmerged selective candidate.',
           'contained-in-broad-candidate': 'Exact head is in mixed PR316/318 work with unresolved qualification.',
           'retained-experimental': 'Preserved automation/skill scope; no activation or production adoption.',
           'retained-research-or-docs': 'Preserved historical research/documentation; current-contract review remains.',
           'retained-for-semantic-review': 'Unmatched patch evidence remains; compare behavior and port selectively.'}
lines = ['# PatchTrace branch inventory', '',
         f'Observed UTC: **{snapshot["observed_at_utc"]}**. Pinned main: `{MAIN}`. '
         f'PR319: `{CANDIDATE}`. Broad PR318: `{BROAD}`.', '',
         f'The complete REST branch pages contain **{len(rows)} branches including main** '
         f'({len(rows) - 1} topics); page sizes are 100 / 100 / 100 / 20 / 0. '
         f'The supplied all-state PR snapshot contains **{len(pulls)} PR records**. '
         'Every fetched branch has a documented disposition below. Retained work is not counted as recovered.', '',
         '## Classification', '', '| Disposition | Branches | Meaning |', '|---|---:|---|']
lines += [f'| {k} | {v} | {meaning[k]} |' for k, v in counts.items()]
lines += ['', '## Evidence and scope', '',
          f'The previous complete 318-branch census uses the same main SHA. '
          f'**{reused} exact-name/exact-head rows** were reused only after that identity check; '
          f'**{len(delta_rows)} changed or new rows** were independently compared. '
          'One current main-history read cross-checked every ancestry claim. '
          'Existing merge simulations were reused only for the identical main and topic head. '
          'Path footprints were reused only for identical topic head and merge base; absent footprints were read directly.', '',
          'The earlier attempt to recompute every branch with `tools/branch_inventory.py` timed out '
          'during `git cherry` and published no result. The execution environment then became unavailable. '
          'This report comes from the completed reuse-and-delta pass after recovery; it does not relabel '
          'the interrupted attempt as passing.', '',
          '[BRANCH_INVENTORY.json](BRANCH_INVENTORY.json) retains full heads, merge bases, unique and '
          'patch-equivalent commit lists, source file footprints, conflict paths, PR associations, '
          'evidence identities and limitations. Its integer file IDs index the complete `file_catalog` '
          'to avoid duplicating long paths across hundreds of rows. Source file changes are review leads, '
          'not proof that the corresponding current feature is missing.', '',
          'The prior source-pinned census is '
          f'[{CANDIDATE[:12]}:{PRIOR_PATH}](https://github.com/djshellshoxxx/patchtrace/blob/{CANDIDATE}/{PRIOR_PATH}). '
          'The JSON records the archive and input SHA-256 values. Current-head CI/review was not refreshed '
          'by this census. No branch, PR, protection or remote ref was changed by the inventory worker.', '',
          '## Changed and new references', '', '| Branch | Previous head | Current head |', '|---|---|---|']
for d in delta_rows:
    lines.append(f'| `{d["branch"]}` | `{d["previous_head"] or "new"}` | `{d["head"]}` |')
lines += ['', 'The new checkpoint branch at the main SHA contains no additional product work. '
          'Its ancestry classification is not a newly recovered feature.', '',
          '## Complete disposition', '',
          '`Unique` is the number of commits outside main; `Patches` counts unmatched nonmerge patches. '
          '`Files` counts the source delta footprint, including documentation/tests. A clean merge '
          'simulation is not approval. The main row is the baseline.', '',
          '| Branch | Head | Unique | Patches | Files | PRs | Disposition | Conflicts |',
          '|---|---|---:|---:|---:|---|---|---|']
for r in rows:
    references = ', '.join(f'[#{p["number"]}](https://github.com/djshellshoxxx/patchtrace/pull/{p["number"]})'
                           for p in r['pull_requests']) or '—'
    lines.append(f'| `{r["branch"]}` | `{r["head"][:12]}` | {r["ahead_main"]} | '
                 f'{len(r["comparison"]["unmatched_nonmerge_commits"])} | {len(r["source_delta_file_ids"])} | '
                 f'{references} | {r["disposition"]} | {"yes" if r["merge_simulation"]["conflicts"] else "no"} |')
lines += ['', '## Recovery and next action', '',
          '[RECOVERED_WORK.md](RECOVERED_WORK.md) documents the confirmed installer-receipt contribution, '
          'its source attribution and verification. The source branch retains separate workflow redesign '
          'work; it is not declared wholly recovered.', '',
          'For retained topics, inspect the recorded unmatched commits and paths against current behavior, '
          'then recover only compatible changes with focused tests and independent review. For candidate-contained '
          'topics, finish the exact candidate gates before guarded main integration. After a main merge or source '
          'movement, refresh this snapshot. Preserve source branches and original failure evidence.', '']
(OUT / 'BRANCH_INVENTORY.md').write_text('\n'.join(lines))
assert len(record['branches']) == len({r['branch'] for r in record['branches']}) == 320
assert sum(record['counts'].values()) == 320
assert all(r['head'] == next(x['sha'] for x in snapshot['branches'] if x['name'] == r['branch']) for r in rows)
assert all(all(0 <= i < len(file_catalog) for i in r['source_delta_file_ids']) for r in rows)
print(json.dumps({'coverage': record['coverage'], 'counts': counts,
                  'output_bytes': {p.name: p.stat().st_size for p in OUT.iterdir()}}, indent=2), flush=True)
