"""Pin the core admission slice and deny child/network execution in its gate."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import ssl
import subprocess
import sys
import tempfile
import time

ROOT = Path('/workspace/scratch/c7a9e8d98848/security-residual-qa')
QA = Path(__file__).resolve().parent
SOURCE, LABEL, *FILES = sys.argv[1:]
assert LABEL.replace('-', '').isalnum() and FILES
sys.dont_write_bytecode = True
sys.path[:0] = [str(ROOT / 'src'), str(ROOT), str(ROOT / 'tests')]
os.environ.update(PYTHONPATH=f'{ROOT}/src:{ROOT}', QT_QPA_PLATFORM='offscreen',
                  PYTHONDONTWRITEBYTECODE='1', PATCHTRACE_OPEN_REVIEW_OUTPUT=str(QA / f'{LABEL}-observations'))
for suffix in ('command.json', 'xml', 'imports.json', 'exit.json'):
    assert not (QA / f'{LABEL}.{suffix}').exists()
assert not Path(os.environ['PATCHTRACE_OPEN_REVIEW_OUTPUT']).exists()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT,
                                   env=dict(os.environ, GIT_NO_REPLACE_OBJECTS='1'))


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert git('diff', '--name-only', 'HEAD') == b''
blobs = {}
for entry in git('ls-tree', '-r', '-z', SOURCE, 'src', 'tests').split(b'\0'):
    if entry:
        meta, name = entry.split(b'\t', 1)
        blobs[name.decode()] = meta.split()[2].decode()
files = [{'path': str(Path(path).resolve()), 'sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest()}
         for path in FILES]
import pytest

attempts = []


def audit(event, _args):
    if event in {'socket.__new__', 'socket.connect', 'subprocess.Popen', 'os.system', 'os.fork', 'os.posix_spawn'}:
        attempts.append(event)
        raise AssertionError('core admission controls cannot execute children or network operations')


start = time.monotonic()
with tempfile.TemporaryDirectory(prefix='core-admission-') as temporary:
    arguments = ['-q', '-p', 'no:cacheprovider', '-c', str(ROOT / 'pyproject.toml'),
                 '--basetemp', str(Path(temporary) / 'pytest'), *FILES, f'--junitxml={QA}/{LABEL}.xml']
    (QA / f'{LABEL}.command.json').write_text(json.dumps({
        'source_commit': SOURCE, 'cwd': str(ROOT), 'python': sys.version,
        'argv': [sys.executable, str(Path(__file__).resolve()), SOURCE, LABEL, *FILES],
        'pytest_arguments': arguments, 'test_files': files,
        'environment': {key: os.environ[key] for key in ('PYTHONPATH', 'QT_QPA_PLATFORM', 'PYTHONDONTWRITEBYTECODE',
                                                       'PATCHTRACE_OPEN_REVIEW_OUTPUT')},
    }, indent=2) + '\n')
    sys.addaudithook(audit)
    result = int(pytest.main(arguments))
modules, drift = [], []
for name, module in sorted(sys.modules.items()):
    if not getattr(module, '__file__', None):
        continue
    path = Path(module.__file__).resolve()
    if not (name.startswith('patchtrace') or path.is_relative_to(ROOT / 'tests')):
        continue
    entry = {'name': name, 'path': str(path)}
    if not path.is_relative_to(ROOT):
        drift.append(name)
    else:
        relative = path.relative_to(ROOT).as_posix()
        data = path.read_bytes()
        blob = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
        entry.update(relative_path=relative, git_blob=blob, expected_git_blob=blobs.get(relative),
                     sha256=hashlib.sha256(data).hexdigest())
        if blob != blobs.get(relative):
            drift.append(name)
    modules.append(entry)
for entry in files:
    if hashlib.sha256(Path(entry['path']).read_bytes()).hexdigest() != entry['sha256']:
        drift.append(entry['path'])
(QA / f'{LABEL}.imports.json').write_text(json.dumps({
    'source_commit': SOURCE, 'modules': modules, 'drift': drift,
}, indent=2) + '\n')
exit_code = result if not drift and not attempts else 1
(QA / f'{LABEL}.exit.json').write_text(json.dumps({
    'source_commit': SOURCE, 'pytest_exit': result, 'exit_code': exit_code,
    'source_pinned_modules': len(modules), 'drift': drift, 'prohibited_attempts': attempts,
    'seconds': time.monotonic() - start,
}, indent=2) + '\n')
raise SystemExit(exit_code)
