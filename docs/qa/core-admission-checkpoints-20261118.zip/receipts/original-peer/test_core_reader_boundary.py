"""Independent authored POSIX mechanics; no native reader or source-authenticity credit."""
from __future__ import annotations

import builtins
import hashlib
import io
import os
from contextlib import contextmanager
from pathlib import Path

import pytest

from patchtrace import ingestion
from patchtrace.input_readers import HeldInput, InputReadError, PairInputReaders
from patchtrace.persistence import ProjectStore
from patchtrace.sample import synthetic_pe
from patchtrace.service import ProjectService


class Lease(HeldInput):
    def __init__(self, path, checkpoint, *, phase=None, error=None):
        self.path, self.checkpoint = Path(path), checkpoint
        self.fd = os.open(path, os.O_RDONLY)
        self.initial = os.fstat(self.fd)
        self.phase, self.error = phase, error
        self.opens = self.closes = self.bytes = 0
        self.active = False

    def stop(self, phase):
        if phase == self.phase:
            raise self.error

    def check(self, path):
        self.checkpoint(0)
        self.stop('check')
        assert Path(path) == self.path
        current = os.fstat(self.fd)
        assert (current.st_dev, current.st_ino, current.st_size, current.st_mtime_ns, current.st_ctime_ns) == (
            self.initial.st_dev, self.initial.st_ino, self.initial.st_size,
            self.initial.st_mtime_ns, self.initial.st_ctime_ns)

    @contextmanager
    def open_reader(self, path):
        self.check(path)
        self.stop('open')
        assert not self.active
        self.active = True
        self.opens += 1
        try:
            with os.fdopen(os.dup(self.fd), 'rb') as raw:
                raw.seek(0)  # Serial authored POSIX provider, not an independently rooted native open.
                owner = self

                class Reader:
                    def fileno(self):
                        return raw.fileno()

                    def read(self, size):
                        assert type(size) is int and 0 <= size <= ingestion.CHUNK_SIZE
                        owner.checkpoint(0)
                        owner.stop('read')
                        data = raw.read(size)
                        owner.bytes += len(data)
                        owner.checkpoint(len(data))
                        return data

                    def seek(self, offset):
                        assert type(offset) is int and 0 <= offset <= owner.initial.st_size
                        owner.checkpoint(0)
                        result = raw.seek(offset)
                        owner.checkpoint(0)
                        return result

                yield Reader()
                self.stop('exit')
                self.check(path)
        finally:
            self.closes += 1
            self.active = False

    def close(self):
        os.close(self.fd)


def source(tmp_path, side='older', variant=0):
    path = tmp_path / (side + '.sys')
    path.write_bytes(synthetic_pe(variant) + b'authored-padding' * 9000)
    return path


def deny_selected_path_opens(monkeypatch, paths):
    selected = {os.fspath(path) for path in paths}
    attempts = []

    def wrap(real):
        def checked(path, *args, **kwargs):
            if isinstance(path, (str, os.PathLike)) and os.fspath(path) in selected:
                attempts.append(os.fspath(path))
                raise AssertionError('held input fell back to a selected-source path open')
            return real(path, *args, **kwargs)
        return checked

    monkeypatch.setattr(builtins, 'open', wrap(builtins.open))
    monkeypatch.setattr(io, 'open', wrap(io.open))
    monkeypatch.setattr(os, 'open', wrap(os.open))
    return attempts


@pytest.mark.parametrize('api', ['inspect', 'pe'])
@pytest.mark.parametrize('phase', ['check', 'open', 'read', 'exit'])
def test_refused_held_provider_never_falls_back_to_a_readable_source_path(tmp_path, monkeypatch, api, phase):
    path = source(tmp_path)
    error = InputReadError('cancelled')
    lease = Lease(path, lambda count: None, phase=phase, error=error)
    attempts = deny_selected_path_opens(monkeypatch, [path])
    root = tmp_path / 'project'
    try:
        with pytest.raises(InputReadError) as caught:
            if api == 'inspect':
                ingestion.inspect_artifact(path, 'older', root, reader=lease)
            else:
                ingestion.validate_pe(path, reader=lease)
        assert caught.value is error
        assert not attempts and lease.opens == lease.closes and not lease.active
        assert os.fstat(lease.fd).st_ino == lease.initial.st_ino
        assert not list(root.rglob('*.bin')) and not list(root.rglob('.input-*'))
    finally:
        lease.close()


@pytest.mark.parametrize('failed_side', [0, 1])
def test_public_create_preserves_neutral_stop_and_foreign_files(tmp_path, monkeypatch, failed_side):
    paths = [source(tmp_path, side, variant) for side, variant in [('older', 0), ('newer', 1)]]
    error = InputReadError('limited')
    leases = [Lease(path, lambda count: None, phase='exit' if index == failed_side else None,
                    error=error) for index, path in enumerate(paths)]
    root = tmp_path / 'project'
    root.mkdir()
    foreign = root / 'keep.txt'
    foreign.write_bytes(b'foreign evidence')
    attempts = deny_selected_path_opens(monkeypatch, paths)
    try:
        pair = PairInputReaders(*leases, lambda count: None)
        with pytest.raises(InputReadError) as caught:
            ProjectService.create(*paths, 'must refuse', root, input_readers=pair)
        assert caught.value is error and not attempts
        assert foreign.read_bytes() == b'foreign evidence'
        assert not (root / 'project.sqlite3').exists()
        assert not list(root.rglob('*.bin')) and not list(root.rglob('.input-*'))
        assert all(lease.opens == lease.closes and not lease.active for lease in leases)
    finally:
        for lease in leases:
            lease.close()


def test_actual_read_bytes_equal_one_shared_checkpoint_ledger(tmp_path, monkeypatch):
    paths = [source(tmp_path, side, variant) for side, variant in [('older', 0), ('newer', 1)]]
    expected = [hashlib.sha256(path.read_bytes()).hexdigest() for path in paths]
    charged, core_reads = [], []
    leases = [Lease(path, charged.append) for path in paths]
    root = tmp_path / 'project'
    actual_open = io.open

    class CoreStream:
        def __init__(self, stream):
            self.stream = stream

        def __enter__(self):
            self.stream.__enter__()
            return self

        def __exit__(self, *args):
            return self.stream.__exit__(*args)

        def __getattr__(self, name):
            return getattr(self.stream, name)

        def read(self, size):
            result = self.stream.read(size)
            core_reads.append(len(result))
            return result

    def counted_open(path, *args, **kwargs):
        result = actual_open(path, *args, **kwargs)
        if isinstance(path, (str, os.PathLike)) and Path(path).is_relative_to(root):
            return CoreStream(result)
        return result

    monkeypatch.setattr(io, 'open', counted_open)
    try:
        with ProjectService.create(*paths, 'counted', root,
                                   input_readers=PairInputReaders(*leases, charged.append)) as made:
            assert [artifact.sha256 for artifact in made.project.artifacts] == expected
        assert core_reads and sum(core_reads) >= sum(lease.initial.st_size for lease in leases)
        assert sum(charged) == sum(core_reads) + sum(lease.bytes for lease in leases)
        assert all(type(value) is int and 0 <= value <= ingestion.CHUNK_SIZE for value in charged)
    finally:
        for lease in leases:
            lease.close()


def test_existing_snapshot_and_history_survive_a_real_precommit_stop(tmp_path):
    path = source(tmp_path)
    error = InputReadError('cancelled')
    with ProjectService.create(path, path, 'before', tmp_path / 'project') as made:
        snapshot = made.store.connection.execute('SELECT * FROM current_snapshot').fetchall()
        history = made.store.connection.execute('SELECT * FROM history').fetchall()
        traces = []
        made.store.connection.set_trace_callback(traces.append)
        candidate = made.project.model_copy(deep=True)
        candidate.name = 'must not commit'

        def checkpoint(count):
            if made.store.connection.in_transaction and any(
                    line.startswith('INSERT INTO current_snapshot') for line in traces):
                raise error

        with pytest.raises(InputReadError) as caught:
            made.store.save(candidate, checkpoint=checkpoint)
        assert caught.value is error and 'ROLLBACK' in traces and 'COMMIT' not in traces
        assert made.store.connection.execute('SELECT * FROM current_snapshot').fetchall() == snapshot
        assert made.store.connection.execute('SELECT * FROM history').fetchall() == history


def test_exception_constructing_service_after_commit_preserves_the_project(tmp_path):
    path = source(tmp_path)
    root = tmp_path / 'project'
    error = InputReadError('cancelled')

    class PostCommitFailure(ProjectService):
        def __init__(self, *args):
            raise error

    with pytest.raises(InputReadError) as caught:
        PostCommitFailure.create(path, path, 'retained after commit', root)
    assert caught.value is error
    with ProjectService.open(root, maintenance=False) as retained:
        assert retained.project.name == 'retained after commit'
        assert retained.project.artifacts[0].sha256 == hashlib.sha256(path.read_bytes()).hexdigest()


def test_original_operation_stop_survives_owned_temporary_cleanup_failure(tmp_path, monkeypatch):
    path = source(tmp_path)
    error = InputReadError('cancelled')
    lease = Lease(path, lambda count: None, phase='read', error=error)
    original_unlink = Path.unlink
    retained = []

    def fail_owned_unlink(temporary, *args, **kwargs):
        if temporary.name.startswith('.input-'):
            retained.append(temporary)
            raise PermissionError('authored cleanup refusal')
        return original_unlink(temporary, *args, **kwargs)

    monkeypatch.setattr(Path, 'unlink', fail_owned_unlink)
    root = tmp_path / 'project'
    try:
        with pytest.raises(InputReadError) as caught:
            ingestion.inspect_artifact(path, 'older', root, reader=lease)
        assert caught.value is error
        assert retained and all(path.exists() for path in retained)
        assert not list(root.rglob('*.bin'))
    finally:
        lease.close()
