"""Immutable authored probe for the owned-open failure/cleanup boundary."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path

import pytest

from patchtrace.input_readers import InputReadError
from patchtrace.persistence import ProjectStore
from patchtrace.sample import synthetic_pe
from patchtrace.service import ProjectService

OUTPUT = Path(os.environ['PATCHTRACE_OPEN_REVIEW_OUTPUT'])


def existing(tmp_path):
    paths = [tmp_path / f'{side}.sys' for side in ('older', 'newer')]
    for number, path in enumerate(paths):
        path.write_bytes(synthetic_pe(number))
    root = tmp_path / 'project'
    with ProjectService.create(*paths, 'authored existing project', root) as service:
        owned = [root / 'project.sqlite3', *(root / item.relative_path for item in service.project.artifacts)]
    return root, {path: path.read_bytes() for path in owned}


def observe(name, value):
    OUTPUT.mkdir(parents=True, exist_ok=True)
    with (OUTPUT / f'{name}.json').open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def exercise(tmp_path, monkeypatch, primary, cleanup):
    root, expected = existing(tmp_path)
    instances = []
    real_init, real_close = ProjectStore.__init__, ProjectStore.close

    def initialize(store, *args, **kwargs):
        real_init(store, *args, **kwargs)
        instances.append(store)

    def verify(*args, **kwargs):
        raise primary

    def close(store):
        if cleanup == 'before-close':
            raise PermissionError('authored private cleanup text must not enter the retained diagnostic')
        real_close(store)
        if cleanup == 'after-close':
            raise PermissionError('authored private cleanup text must not enter the retained diagnostic')

    monkeypatch.setattr(ProjectStore, '__init__', initialize)
    monkeypatch.setattr(ProjectStore, '_verify_files', verify)
    monkeypatch.setattr(ProjectStore, 'close', close)
    caught = None
    try:
        try:
            ProjectService.open(root, maintenance=False)
        except BaseException as exc:
            caught = exc
        assert len(instances) == 1
        store = instances[0]
        result = {'caught_type': type(caught).__name__, 'primary_preserved': caught is primary,
                  'closed': store.closed, 'connection_closed': store.connection is None,
                  'lock_closed': store.lock is None, 'notes': getattr(caught, '__notes__', []),
                  'database_sha256': hashlib.sha256(expected[root / 'project.sqlite3']).hexdigest()}
    finally:
        # Only test-owned fixture resources are closed here; product behavior above is recorded first.
        for store in instances:
            real_close(store)
    assert all(path.read_bytes() == raw for path, raw in expected.items())
    return caught, result


@pytest.mark.parametrize('primary', [KeyboardInterrupt('authored interrupt'), SystemExit(7)],
                         ids=['keyboard-interrupt', 'system-exit'])
def test_failed_owned_open_closes_its_connection_for_baseexception(tmp_path, monkeypatch, primary):
    caught, result = exercise(tmp_path, monkeypatch, primary, 'normal')
    observe(type(primary).__name__, result)
    assert caught is primary
    assert result['closed'] and result['connection_closed'] and result['lock_closed']


@pytest.mark.parametrize('cleanup', ['before-close', 'after-close'])
def test_secondary_close_failure_preserves_the_neutral_stop(tmp_path, monkeypatch, cleanup):
    primary = InputReadError('cancelled')
    caught, result = exercise(tmp_path, monkeypatch, primary, cleanup)
    observe(cleanup, result)
    assert caught is primary
    assert result['notes'] and all('authored private' not in note for note in result['notes'])
    assert result['connection_closed'] is (cleanup == 'after-close')


def test_ordinary_failed_open_still_closes_without_a_false_cleanup_note(tmp_path, monkeypatch):
    primary = InputReadError('limited')
    caught, result = exercise(tmp_path, monkeypatch, primary, 'normal')
    observe('ordinary-positive', result)
    assert caught is primary
    assert result['closed'] and result['connection_closed'] and result['lock_closed']
    assert result['notes'] == []
