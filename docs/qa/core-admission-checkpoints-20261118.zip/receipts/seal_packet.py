"""Seal only retained local core-admission receipts and canonical Git sources."""
from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/c7a9e8d98848/security-residual-qa')
QA = Path(__file__).resolve().parent
BASE = '7b5f558fb1a51d45427648c39c15995ab3697e2c'
PORT = '1102f1baba94a8ce3dd5bc12df52e69a2595e995'
RED = 'cb26b38de018612e76f87c544fb8b1dfe70acbf2'
SOURCE = '441c47c2262603555aa77c11e63fedcce11ba502'
STEM = 'core-admission-checkpoints-20261118'
DOCS = ROOT / 'docs' / 'qa'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(*args, input=None):
    return subprocess.check_output(['git', *args], cwd=ROOT, input=input,
                                   env=dict(os.environ, GIT_NO_REPLACE_OBJECTS='1'))


def dump(name, value):
    (QA / name).write_text(json.dumps(value, indent=2) + '\n')


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('status', '--porcelain')
assert git('rev-parse', f'{SOURCE}^').decode().strip() == RED
assert git('rev-parse', f'{RED}^').decode().strip() == PORT
assert git('rev-parse', f'{PORT}^').decode().strip() == BASE
assert git('diff', '--name-only', BASE, SOURCE, '--', 'src').decode().splitlines() == [
    'src/patchtrace/persistence.py', 'src/patchtrace/service.py',
]
assert not git('diff', '--name-only', BASE, SOURCE, '--', 'tools', 'schemas', '.github')
assert not git('diff', '--name-only', BASE, RED, '--', 'src', 'tests/conftest.py')

command = json.loads((QA / 'affected-v2.command.json').read_text())
result = json.loads((QA / 'affected-v2.exit.json').read_text())
assert result['source_commit'] == SOURCE and result['exit_code'] == 0
assert not result['drift'] and not result['prohibited_attempts']
assert result['temporary_storage']['removed'] and len(result['children']) == 5
tests_unchanged = []
for item in command['test_files']:
    path = Path(item['path'])
    assert digest(path.read_bytes()) == item['sha256']
    if path.is_relative_to(ROOT):
        relative = path.relative_to(ROOT).as_posix()
        assert git('show', f'{SOURCE}:{relative}') == path.read_bytes()
        if relative in {'tests/test_project_creation_identity.py', 'tests/test_project_open_checkpoint.py'}:
            assert git('show', f'{RED}:{relative}') == path.read_bytes()
            tests_unchanged.append(relative)
assert len(tests_unchanged) == 2

probes = [
    (QA / 'test_open_failure_boundary.py', '715353bb34f604295abb1d04d1e286d144f01568143d5118ed75e4d663432c6c'),
    (Path('/workspace/scratch/c7a9e8d98848/qa/core-held-inputs-cleanup/original-peer/test_core_reader_boundary.py'),
     'b7b5ad118cfd8b4b15fd6e1276d3dff0136c21f7b8df555b21db386fda49c1ed'),
]
for path, expected in probes:
    assert digest(path.read_bytes()) == expected

imports = json.loads((QA / 'affected-v2.imports.json').read_text())
assert imports['source_commit'] == SOURCE and not imports['drift']
blobs = sorted({item['expected_git_blob'] for item in imports['modules']})
output = git('cat-file', '--batch', input=('\n'.join(blobs) + '\n').encode())
cursor, canonical = 0, {}
for expected in blobs:
    end = output.index(b'\n', cursor)
    oid, kind, length = output[cursor:end].decode().split()
    assert oid == expected and kind == 'blob'
    start = end + 1
    data = output[start:start + int(length)]
    assert output[start + len(data):start + len(data) + 1] == b'\n'
    canonical[oid] = data
    cursor = start + len(data) + 1
assert cursor == len(output)
for item in imports['modules']:
    assert item['git_blob'] == item['expected_git_blob']
    assert digest(canonical[item['git_blob']]) == item['sha256']
    assert git('rev-parse', f"{SOURCE}:{item['relative_path']}").decode().strip() == item['git_blob']

ast_checks = []
for name in ('service', 'persistence'):
    earlier = (QA / f'first-green-{name}.py').read_bytes()
    relative = f'src/patchtrace/{name}.py'
    current = git('show', f'{SOURCE}:{relative}')
    same_ast = ast.dump(ast.parse(earlier), include_attributes=False) == ast.dump(ast.parse(current), include_attributes=False)
    assert same_ast
    ast_checks.append({'path': relative, 'first_green_sha256': digest(earlier),
                       'committed_sha256': digest(current), 'same_bytes': earlier == current,
                       'same_ast_without_locations': same_ast})
assert not ast_checks[0]['same_bytes'] and ast_checks[1]['same_bytes']

summaries = []
expected_counts = {
    'open-red': (5, 4, 0, 0), 'spec-red': (47, 41, 0, 0),
    'first-green': (47, 0, 0, 0), 'affected': (512, 2, 0, 0),
    'affected-v2': (512, 0, 0, 0),
}
for label, expected in expected_counts.items():
    path = QA / f'{label}.xml'
    suites = list(ET.parse(path).getroot().iter('testsuite'))
    counts = tuple(sum(int(suite.attrib.get(key, 0)) for suite in suites)
                   for key in ('tests', 'failures', 'errors', 'skipped'))
    assert counts == expected, (label, counts)
    summaries.append({'label': label, **dict(zip(('tests', 'failures', 'errors', 'skipped'), counts)),
                      'passed': counts[0] - sum(counts[1:]), 'sha256': digest(path.read_bytes())})

snapshots = {}
source_manifest = []
final_paths = {
    'AGENTS.md', 'pyproject.toml', 'docs/modules.md', 'docs/specs/core-held-inputs.md',
    'docs/specs/architecture.md', 'docs/plans/package-core-admission-seams-20261118.md',
    'src/patchtrace/service.py', 'src/patchtrace/persistence.py', 'src/patchtrace/models.py',
    'src/patchtrace/ingestion.py', 'src/patchtrace/input_readers.py', 'src/patchtrace/sample.py',
    'src/patchtrace/raw_cleanup.py',
}
for item in command['test_files']:
    path = Path(item['path'])
    if path.is_relative_to(ROOT):
        final_paths.add(path.relative_to(ROOT).as_posix())
for item in imports['modules']:
    if item['relative_path'].startswith('tests/'):
        final_paths.add(item['relative_path'])
for role, commit, paths in (
    ('final', SOURCE, sorted(final_paths)),
    ('base', BASE, ['src/patchtrace/service.py', 'src/patchtrace/persistence.py',
                    'src/patchtrace/models.py', 'docs/specs/core-held-inputs.md', 'docs/specs/architecture.md']),
):
    for relative in paths:
        data = git('show', f'{commit}:{relative}')
        member = f'canonical-source/{role}/{relative}'
        snapshots[member] = data
        source_manifest.append({'role': role, 'commit': commit, 'path': relative, 'member': member,
                                'git_blob': git('rev-parse', f'{commit}:{relative}').decode().strip(),
                                'sha256': digest(data), 'bytes': len(data)})
dump('canonical-source.json', source_manifest)
dump('verification.json', {
    'source_commit': SOURCE, 'base': BASE, 'design_port': PORT, 'spec_test_commit': RED,
    'canonical_git_snapshots': len(source_manifest), 'verified_pinned_parent_imports': len(imports['modules']),
    'verified_unique_import_blobs': len(blobs), 'xml': summaries, 'test_bytes_unchanged_since_red': tests_unchanged,
    'original_probes': [{'path': str(path), 'sha256': sha} for path, sha in probes],
    'first_green_comparison': ast_checks, 'production_paths': ['src/patchtrace/service.py', 'src/patchtrace/persistence.py'],
    'source_diff': {'insertions': 38, 'deletions': 12}, 'schema_tools_workflows_unchanged': True,
    'constructor_interrupt_limit': 'Owned-open close assertions begin only after ProjectStore construction returns.',
    'failed_affected_temp_retained': '/tmp/core-admission-affected-95juu3ud',
})
for name, left, right in (('source.patch', RED, SOURCE), ('spec-tests.patch', PORT, RED), ('complete-chain.patch', BASE, SOURCE)):
    (QA / name).write_bytes(git('diff', '--binary', left, right))
dump('chain.json', [{'role': role, 'commit': commit,
                     'tree': git('rev-parse', f'{commit}^{{tree}}').decode().strip(),
                     'parents': git('show', '-s', '--format=%P', commit).decode().strip().split(),
                     'subject': git('show', '-s', '--format=%s', commit).decode().strip()}
                    for role, commit in [('base', BASE), ('design_port', PORT), ('spec_test', RED), ('source', SOURCE)]])

payloads = dict(snapshots)
for path in sorted(QA.rglob('*')):
    if path.is_file() and path.name not in {'manifest.json', 'evidence.zip', 'seal-result.json'}:
        assert not path.is_symlink()
        payloads['receipts/' + path.relative_to(QA).as_posix()] = path.read_bytes()
payloads['receipts/original-peer/test_core_reader_boundary.py'] = probes[1][0].read_bytes()
archive = DOCS / f'{STEM}.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(payloads.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        output.writestr(info, data)
manifest = {'source_commit': SOURCE, 'archive': archive.name, 'archive_sha256': digest(archive.read_bytes()),
            'archive_bytes': archive.stat().st_size, 'payload_count': len(payloads),
            'uncompressed_bytes': sum(map(len, payloads.values())),
            'payloads': [{'path': name, 'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(payloads.items())]}
(DOCS / f'{STEM}.manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None and len(check.namelist()) == len(payloads)
    for item in manifest['payloads']:
        data = check.read(item['path'])
        assert len(data) == item['bytes'] and digest(data) == item['sha256']
report = (QA / 'README.md').read_text()
report += (f'\n## Sealed packet\n\nThe [{manifest["payload_count"]}-payload archive]({archive.name}) '
           f'contains {manifest["uncompressed_bytes"]:,} uncompressed bytes '
           f'({manifest["archive_bytes"]:,} ZIP bytes), including {len(source_manifest)} canonical Git snapshots.\n'
           f'Archive SHA-256: `{manifest["archive_sha256"]}`. '
           f'The [manifest]({STEM}.manifest.json) records every payload hash and size.\n')
(DOCS / f'{STEM}.md').write_text(report)
dump('seal-result.json', {key: manifest[key] for key in ('source_commit', 'archive', 'archive_sha256',
                                                       'archive_bytes', 'payload_count', 'uncompressed_bytes')})
print(json.dumps({'archive': str(archive), 'payload_count': len(payloads), 'source_snapshots': len(source_manifest),
                  'sha256': manifest['archive_sha256'], 'bytes': manifest['archive_bytes']}))
