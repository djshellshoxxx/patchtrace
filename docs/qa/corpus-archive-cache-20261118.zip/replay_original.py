"""Route unchanged historical source checks to the exact candidate; prohibit I/O."""
from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

R = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
Q = Path(__file__).resolve().parent
label = sys.argv[1]
names = [
    ('test_codex_pkg_workflows.py', 'test_remote_actions_are_immutable'),
    ('test_codex_pkg_workflows.py', 'test_pip_downloads_require_hashes'),
    ('test_codex_pkg_workflows.py', 'test_corpus_cache_does_not_skip_verification'),
    ('test_codex_pkg_packaging.py', 'test_linux_package_runs_full_cli_smoke'),
]
expected = {
    'test_codex_pkg_workflows.py': '6f066e3ac6d32f9115bf881ebd34e8969071ed4c5956d0d214f74fa7dfa91dd9',
    'test_codex_pkg_packaging.py': '1a2573ab52fc3db24e3e09afa24440cb1e65aa2b6c94a16080016781a2cf91f2',
}
for name, digest in expected.items():
    assert hashlib.sha256((Q / 'original' / name).read_bytes()).hexdigest() == digest
os.chdir(R)
sys.path[:0] = [str(R / 'src'), str(R)]
os.environ['PYTHONPATH'] = str(R / 'src') + ':' + str(R)
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
sys.dont_write_bytecode = True
meta = {
    'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
    'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], text=True).strip(),
    'working_diff_sha256': hashlib.sha256(subprocess.check_output(['git', 'diff', 'HEAD'])).hexdigest(),
    'python': sys.executable,
    'original_tests': expected,
    'cwd': str(R),
    'started_utc': datetime.now(UTC).isoformat(),
}
attempts = []


def audit(event, args):
    if event in {'socket.__new__', 'socket.connect', 'socket.bind', 'subprocess.Popen',
                 'os.system', 'os.posix_spawn', 'os.fork', 'os.exec'}:
        attempts.append(event)
        raise PermissionError('Original source probes prohibit network/children')


class Route:
    def pytest_collection_modifyitems(self, items):
        for item in items:
            if Path(item.path).parent == Q / 'original':
                item.module.ROOT = R
                if hasattr(item.module, 'WORKFLOWS'):
                    item.module.WORKFLOWS = R / '.github/workflows'


sys.addaudithook(audit)
import pytest

argv = ['-q', '-ra', '--runxfail', '-p', 'no:cacheprovider',
        *[str(Q / 'original' / name) + '::' + node for name, node in names],
        '--junitxml=' + str(Q / (label + '.xml'))]
meta['argv'] = argv
with (Q / (label + '.log')).open('x') as out:
    stdout, stderr = sys.stdout, sys.stderr
    sys.stdout = sys.stderr = out
    try:
        code = int(pytest.main(argv, plugins=[Route()]))
    finally:
        sys.stdout, sys.stderr = stdout, stderr
meta.update(returncode=code, denied_attempts=attempts, finished_utc=datetime.now(UTC).isoformat())
(Q / (label + '.command.json')).write_text(json.dumps(meta, indent=2) + '\n')
print(label, 'exit', code, 'denied', attempts)
print((Q / (label + '.log')).read_text()[-1500:])
raise SystemExit(code)
