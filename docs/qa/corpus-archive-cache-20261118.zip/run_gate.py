"""Record a bounded source-pinned pytest invocation without overwriting evidence."""
from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

R = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
Q = Path(__file__).resolve().parent
label, *targets = sys.argv[1:]
env = dict(os.environ, PYTHONPATH=str(R / 'src') + ':' + str(R),
           QT_QPA_PLATFORM='offscreen', PYTHONDONTWRITEBYTECODE='1')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
diff = subprocess.check_output(['git', 'diff', 'HEAD'], cwd=R)
argv = [sys.executable, '-m', 'pytest', '-q', '-ra', '-p', 'no:cacheprovider',
        *targets, '--junitxml=' + str(Q / (label + '.xml'))]
meta = dict(head=head, tree=subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=R, text=True).strip(),
            cwd=str(R), argv=argv, python=sys.executable, started_utc=datetime.now(UTC).isoformat(),
            working_diff_sha256=hashlib.sha256(diff).hexdigest(),
            environment={k:env[k] for k in ['PYTHONPATH', 'QT_QPA_PLATFORM', 'PYTHONDONTWRITEBYTECODE']})
with (Q / (label + '.log')).open('x') as output:
    process = subprocess.run(argv, cwd=R, env=env, stdout=output, stderr=subprocess.STDOUT)
assert head == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert diff == subprocess.check_output(['git', 'diff', 'HEAD'], cwd=R)
meta.update(returncode=process.returncode, finished_utc=datetime.now(UTC).isoformat())
(Q / (label + '.command.json')).write_text(json.dumps(meta, indent=2) + '\n')
print((Q / (label + '.log')).read_text()[-3000:])
raise SystemExit(process.returncode)
