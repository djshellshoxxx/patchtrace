"""Independent structural controls for the synthetic-fixture-only repair."""
import ast
import hashlib
import importlib
import json
import subprocess
import sys
import types
from pathlib import Path

root = Path('/workspace/scratch/142cb233d750/wt-rz-fixtures')
sys.path[:0] = [str(root / 'src'), str(root / 'tests')]
base = 'd317c7941429fa189dbcff88749935a2b885cd71'


def original(path):
    return subprocess.check_output(['git', 'show', f'{base}:{path}'], cwd=root).decode()


class RemoveExplicitQuarantineVersion(ast.NodeTransformer):
    def visit_Call(self, node):
        self.generic_visit(node)
        if isinstance(node.func, ast.Name) and node.func.id in ('rz', 'rzdiff_set'):
            node.keywords = [kw for kw in node.keywords
                             if not (kw.arg == 'version' and isinstance(kw.value, ast.Constant)
                                     and kw.value.value == '0.9.1')]
        return node


negative_path = 'tests/test_rzdiff_orientation_20261101.py'
before = ast.parse(original(negative_path))
after = ast.parse((root / negative_path).read_text())
assert ast.dump(before) == ast.dump(RemoveExplicitQuarantineVersion().visit(after))
print('PASS: negative test AST unchanged apart from explicit 0.9.1 constructor arguments')

for path in ('tests/test_unified_worker.py', 'tests/test_tier_r_eval_metrics.py'):
    assert (root / path).read_text() == original(path)
print('PASS: original worker assertions and root-owned scoring file byte-identical')

cli_path = 'tests/test_unified_cli_show.py'
assert ast.dump(ast.parse(original(cli_path))) == ast.dump(ast.parse(
    (root / cli_path).read_text().replace('0.9.0', '0.9.1')))
print('PASS: CLI test AST unchanged apart from displayed synthetic version')

old = types.ModuleType('_original_unified_s0_fixtures')
sys.modules[old.__name__] = old
exec(compile(original('tests/unified_s0_fixtures.py'), '<base-fixture>', 'exec'), old.__dict__)
new = importlib.import_module('unified_s0_fixtures')
digests = []
for rows, kw in [([(0x1000, 0x1080)], {'older': '1' * 64, 'newer': '2' * 64}),
                 ([(0x1000, 0x1100)], {}),
                 ([(0x1000, 0x1080), (0x1200, 0x1280)], {})]:
    prior = old.rzdiff_set([old.rz(*pair) for pair in rows], **kw).model_dump_json()
    current = new.rzdiff_set([new.rz(*pair, version='0.9.1') for pair in rows],
                            version='0.9.1', **kw).model_dump_json()
    assert current == prior
    digests.append(hashlib.sha256(current.encode()).hexdigest())
print('PASS: all three quarantine constructions produce byte-identical normalized sets')
print(json.dumps({'quarantine_set_sha256': digests}, indent=2))

for flipped in (False, True):
    data = new.rich_inputs(flipped)
    [rz_set] = [item.match_set for item in data.secondary if item.match_set.engine == 'rz-diff']
    assert rz_set.engine_version == '0.9.0'
    assert len(rz_set.matches) == 2 and all(row.engine_version == '0.9.0' for row in rz_set.matches)
print('PASS: positive synthetic forward/reverse set and row versions are consistent')
