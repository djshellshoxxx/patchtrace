"""External reference replay has no transport or child execution capability."""
import socket
import subprocess
import urllib.request

import pytest


@pytest.fixture(autouse=True)
def forbid_external_effects(monkeypatch):
    def refused(*_args, **_kwargs):
        pytest.fail('Reference-only schema validation attempted transport or process execution')

    monkeypatch.setattr(socket.socket, 'connect', refused)
    monkeypatch.setattr(socket, 'create_connection', refused)
    monkeypatch.setattr(urllib.request, 'urlopen', refused)
    monkeypatch.setattr(subprocess, 'Popen', refused)
