# Phase 2 reference disposition receipt

Frozen current source: 068513a72e8a1412ce3960d3024c462d68d51376, tree 2183dcf3b9cfee268c3ebb163ad9f3e9e928e10f.
Historical source: 4522030ff3ff76d720a5efc33953aaa5e5837398.

Read disposition.md and disposition.json for all nine record families, current
callers, incompatible fields and remaining scope. caller-proofs.json retains
62 exact AST symbol spans/hashes and call inventories. current-source/ contains
73 exact Git source/spec/test/schema snapshots; reference/ contains all five
original reference files unchanged. Both source manifests bind their blobs and
SHA256s. No production or existing test change was made.

Actual independent invocations at the frozen current source:

- current-contracts: 697 passed / 0 failed / 0 skipped in 8.29 seconds (11 files).
- reference-original: unchanged 23 reference tests passed in 0.12 seconds;
  already-installed runtime dependencies, plugin autoload disabled, no install.
- wire-boundary: 10 expected current-format refusals passed in 0.21 seconds.
- navigation-boundary-red: 3 failures / 4 positive controls in 1.67 seconds.
  The real persisted/reopened desktop selects code for a stale excerpt, wrong
  side or wrong run, while the existing validator refuses all three and valid
  navigation succeeds. Original observations and probe bytes are immutable.

The navigation probe SHA256 is
61b5d7c21778e12ba71bc6d32a0779f7d1d457656955bf2bfdab64c8c5953688.
For independent replay use phase2_observation_redirect with the explicit
PATCHTRACE_PHASE2_OBSERVATIONS environment path pointing at a fresh directory.
Only the output destination changes; assertions and original sources do not.

prior-batch7/ preserves the original missing-jsonschema collection error and
later 23-pass reference result at the earlier 55f3 comparison window. They are
historical receipts, not results relabeled to this source. Current-only runs
have their own commands, environment, head/tree, log and XML records.

No native engine, compiler, target, live provider, package, frozen executable,
Windows acceptance or calibration run occurred. Counts have different scopes
and overlap; no additive coverage or completion percentage is asserted. The
UI navigation omission is already noted in the current hardening backlog.
Root approved a separate validator-wiring repair; this packet contains no fix.
