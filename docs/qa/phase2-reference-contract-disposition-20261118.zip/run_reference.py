"""Retain a fresh replay of the unchanged original five-file reference package."""
from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import os
import subprocess

Q = Path(__file__).resolve().parent
R = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
PY = '/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python'
VENV_SITE = '/workspace/scratch/3a6632a6e5ff/venv/lib/python3.12/site-packages'
TARGET = Q / 'reference/tests/test_phase2_contract_examples.py'
LABEL = 'reference-original'
argv = [PY, '-m', 'pytest', '-q', '-ra', '-p', 'no:cacheprovider', '-p', 'reference_offline',
        str(TARGET), '--junitxml=' + str(Q / (LABEL + '.xml'))]
env = dict(os.environ, PYTHONPATH=str(Q) + ':' + VENV_SITE, QT_QPA_PLATFORM='offscreen',
           PYTHONDONTWRITEBYTECODE='1', PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
diff = subprocess.check_output(['git', 'diff', 'HEAD'], cwd=R)
probe = [PY, '-c', "import importlib.metadata as m,json,jsonschema,pytest,referencing,rpds;print(json.dumps({'versions':{k:m.version(k) for k in ['jsonschema','jsonschema-specifications','referencing','rpds-py','attrs','pytest']},'modules':{x.__name__:x.__file__ for x in [jsonschema,pytest,referencing,rpds]}}))"]
meta = dict(head=head, tree=subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=R, text=True).strip(),
            cwd=str(R), argv=argv, started_utc=datetime.now(UTC).isoformat(),
            working_diff_sha256=hashlib.sha256(diff).hexdigest(),
            original_test_sha256=hashlib.sha256(TARGET.read_bytes()).hexdigest(),
            dependencies=json.loads(subprocess.check_output(probe, cwd=R, env=env)),
            environment={k: env[k] for k in ('PYTHONPATH', 'QT_QPA_PLATFORM', 'PYTHONDONTWRITEBYTECODE',
                                            'PYTEST_DISABLE_PLUGIN_AUTOLOAD')},
            scope='Original reference-only checks; no production schema compatibility or semantic qualification implied.')
with (Q / (LABEL + '.log')).open('x') as output:
    result = subprocess.run(argv, cwd=R, env=env, stdout=output, stderr=subprocess.STDOUT)
assert head == subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert diff == subprocess.check_output(['git', 'diff', 'HEAD'], cwd=R)
meta.update(returncode=result.returncode, finished_utc=datetime.now(UTC).isoformat())
(Q / (LABEL + '.command.json')).write_text(json.dumps(meta, indent=2) + '\n')
print((Q / (LABEL + '.log')).read_text())
raise SystemExit(result.returncode)
