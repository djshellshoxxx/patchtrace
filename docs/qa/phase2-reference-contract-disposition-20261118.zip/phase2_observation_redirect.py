"""Route only authored observation outputs when replaying the immutable navigation probe."""
import os
from pathlib import Path


def pytest_collection_modifyitems(items):
    destination = Path(os.environ['PATCHTRACE_PHASE2_OBSERVATIONS']).resolve()
    destination.parent.mkdir(parents=True, exist_ok=True)
    for item in items:
        if item.path.name == 'test_phase2_navigation_boundary.py':
            item.module.OBSERVATIONS = destination
