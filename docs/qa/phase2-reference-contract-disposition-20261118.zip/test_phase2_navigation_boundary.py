"""External SPEC-07 §4 proof: checksum-valid stored metadata must not authorize stale navigation.

The project and code are authored by ProjectService.sample. No target/native tool runs.
This exercises actual pipeline publication, reopen, desktop loading and cursor selection.
The malformed derived row is intentionally authored through the public enrichment adapter;
it is not evidence that a normal detector emits that row or that a checksum is authorization.
"""
from __future__ import annotations

import dataclasses
import hashlib
import json
from pathlib import Path

import pytest
from PySide6.QtCore import QSettings, Qt

from patchtrace.enrichment import pipeline, views
from patchtrace.enrichment.contracts import EnrichmentError, SourceLocation
from patchtrace.enrichment.storage import EnrichmentStore
from patchtrace.service import ProjectService
from patchtrace.ui import MainWindow

OBSERVATIONS = Path(__file__).parent / 'navigation-observations'
MISMATCHES = {
    'excerpt': {'excerpt_sha256': '0' * 64},
    'side': {'side': 'older'},
    'run': {'run_id': 'authored-other-run'},
}


@pytest.fixture(autouse=True)
def no_transport_or_process(monkeypatch):
    import socket
    import subprocess
    import urllib.request

    def refused(*_args, **_kwargs):
        pytest.fail('This authored navigation control attempted network or a child process')

    monkeypatch.setattr(socket, 'create_connection', refused)
    monkeypatch.setattr(socket.socket, 'connect', refused)
    monkeypatch.setattr(urllib.request, 'urlopen', refused)
    monkeypatch.setattr(subprocess, 'Popen', refused)


def _prepared(tmp_path, kind):
    service = ProjectService.sample(tmp_path / 'authored-project')
    result = pipeline.run(service.project)
    selected_set = next(item for item in result.signal_sets
                        if any(signal.locations[0].side == 'newer' for signal in item.signals))
    selected_signal = next(signal for signal in selected_set.signals if signal.locations[0].side == 'newer')
    original = selected_signal.locations[0]
    changed = SourceLocation.model_validate(original.model_dump() | MISMATCHES.get(kind, {}))
    signal = selected_signal.model_copy(update={'locations': (changed,) + selected_signal.locations[1:]})
    signal_set = selected_set.model_copy(update={'signals': tuple(
        signal if old.signal_id == signal.signal_id else old for old in selected_set.signals)})
    modified = dataclasses.replace(result, signal_sets=tuple(
        signal_set if old.pairing_id == signal_set.pairing_id else old for old in result.signal_sets))
    snapshot = service.project.model_dump_json()
    written = pipeline.publish(EnrichmentStore(service.store), service.project, modified)
    assert written and not any(entry.stale for entry in written)
    assert service.project.model_dump_json() == snapshot
    root = service.root
    service.close()
    return root, selected_set.match_id, signal.signal_id, original, changed


@pytest.mark.parametrize('kind', tuple(MISMATCHES))
def test_existing_validator_refuses_authored_metadata(tmp_path, kind):
    root, _match, _signal, original, changed = _prepared(tmp_path, kind)
    with ProjectService.open(root) as service:
        assert views.validate_location(service.project, original).id == original.function_id
        with pytest.raises(EnrichmentError) as problem:
            views.validate_location(service.project, changed)
        assert problem.value.code == ('PT-ENRICH-STALE' if kind == 'excerpt' else 'PT-ENRICH-OWNERSHIP')


@pytest.mark.parametrize('kind', ('valid', *MISMATCHES))
def test_reopened_signal_navigation_obeys_live_location(tmp_path, qtbot, monkeypatch, kind):
    root, match_id, signal_id, original, changed = _prepared(tmp_path, kind)
    service = ProjectService.open(root)
    window = MainWindow(service, QSettings(str(tmp_path / 'settings.ini'), QSettings.Format.IniFormat))
    qtbot.addWidget(window)
    window.show()
    errors = []
    monkeypatch.setattr(window, 'show_error', lambda message: errors.append(str(message)))
    try:
        target = next(window.navigator.item(i) for i in range(window.navigator.count())
                      if window.navigator.item(i).data(Qt.ItemDataRole.UserRole) == match_id)
        window.navigator.setCurrentItem(target)
        candidates = [window.signal_list.item(i) for i in range(window.signal_list.count())
                      if window.signal_list.item(i).data(Qt.ItemDataRole.UserRole) == signal_id]
        for pane in window.views.values():
            cursor = pane.textCursor()
            cursor.clearSelection()
            pane.setTextCursor(cursor)
        calls = []
        real_reveal = window.reveal_lines

        def observed_reveal(*args):
            calls.append(args)
            return real_reveal(*args)

        monkeypatch.setattr(window, 'reveal_lines', observed_reveal)
        if candidates:
            window.jump_signal(candidates[0])
        selected = {side: pane.textCursor().selectedText() for side, pane in window.views.items()}
        observation = {
            'case': kind, 'match_id': match_id, 'signal_id': signal_id,
            'original': original.model_dump(), 'stored': changed.model_dump(),
            'actionable_items': len(candidates), 'reveal_calls': calls,
            'selected': selected, 'diagnostics': errors,
            'project_json_sha256': hashlib.sha256(service.project.model_dump_json().encode()).hexdigest(),
        }
        OBSERVATIONS.mkdir(exist_ok=True)
        with (OBSERVATIONS / f'{kind}.json').open('x') as output:
            json.dump(observation, output, indent=2)
            output.write('\n')
        if kind == 'valid':
            assert candidates and calls
            assert selected[original.side]
        else:
            assert not calls, f'{kind} mismatch reached real code navigation: {observation}'
            assert not any(selected.values())
    finally:
        window.close()
