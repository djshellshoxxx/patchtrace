"""Retain exact-source contract and caller proofs; no production mutation."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess

R=Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
Q=Path(__file__).resolve().parent
BASE='068513a72e8a1412ce3960d3024c462d68d51376'
REFERENCE='4522030ff3ff76d720a5efc33953aaa5e5837398'

symbols={
 'src/patchtrace/enrichment/identity.py':['canonical_json','domain_id','diff_id','occurrence','pairing_id','signal_id'],
 'src/patchtrace/enrichment/views.py':['FunctionView.location','location_problem','validate_location','build_views','match_view'],
 'src/patchtrace/enrichment/ranking.py':['config_digest','score_signals','rank'],
 'src/patchtrace/enrichment/signals.py':['detect'],
 'src/patchtrace/enrichment/profiles.py':['AnalysisProfile.ranking_config'],
 'src/patchtrace/enrichment/cache.py':['RuntimeFingerprint.raw_key','RuntimeFingerprint.eligible','DerivedCache.get','DerivedCache.put','DerivedCache.get_raw','DerivedCache.put_raw'],
 'src/patchtrace/backend.py':['run_comparison'],
 'src/patchtrace/enrichment/wil.py':['analyze','wil_signals'],
 'src/patchtrace/enrichment/cve.py':['parse_snapshots','normalize','_snapshot_id','_snapshot','select_latest','contextual_rank'],
 'src/patchtrace/enrichment/pipeline.py':['input_digest','_locations_owned','_cached','_run','publish','load_default','load_profile'],
 'src/patchtrace/cli.py':['_config','_run_pipeline','cmd_rank','cmd_flags','cmd_correlate'],
 'src/patchtrace/ui.py':['MainWindow._render_signals','MainWindow.jump_signal','MainWindow.reveal_lines','MainWindow.rank_changes','MainWindow._load_enrichment','MainWindow._enrichment_export'],
 'src/patchtrace/reports.py':['_ranking_section'],
 'src/patchtrace/pilot/collect.py':['_signal_sets','collect'],
 'src/patchtrace/pilot/sources/code.py':['B1Evidence','_b1_observations'],
 'src/patchtrace/pilot/tiers.py':['derive','_moderate'],
 'src/patchtrace/pilot/ranking.py':['advisory_key','code_key','place'],
 'src/patchtrace/pilot/service.py':['_rank_context','_rank_cve','localize'],
}
proofs=[]
for path,names in symbols.items():
 raw=subprocess.check_output(['git','show',BASE+':'+path],cwd=R);lines=raw.decode().splitlines(keepends=True)
 found={}
 def walk(nodes,prefix=''):
  for node in nodes:
   if isinstance(node,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
    qual=prefix+node.name;found[qual]=node
    walk(node.body,qual+'.')
 walk(ast.parse(raw).body)
 for name in names:
  node=found[name];body=''.join(lines[node.lineno-1:node.end_lineno]).encode()
  proofs.append({'path':path,'symbol':name,'start_line':node.lineno,'end_line':node.end_lineno,
                 'source_sha256':hashlib.sha256(raw).hexdigest(),'symbol_sha256':hashlib.sha256(body).hexdigest(),
                 'calls':sorted({ast.unparse(n.func) for n in ast.walk(node) if isinstance(n,ast.Call)})})
(Q/'caller-proofs.json').write_text(json.dumps({'baseline':BASE,'symbols':proofs},indent=2)+'\n')
scan=subprocess.run(['git','grep','-n','-E','PatchTrace-Phase2|EvidenceRefV1|FeatureGateV1|CVEContextV1|FunctionRankingV1',BASE,'--','src','tools'],cwd=R,text=True,capture_output=True)
assert scan.returncode==1 and not scan.stdout and not scan.stderr
(Q/'reference-runtime-call-search.json').write_text(json.dumps({'baseline':BASE,'argv':scan.args,'returncode':scan.returncode,'stdout':scan.stdout,'stderr':scan.stderr,'meaning':'No matching reference-name consumer in current src/tools; exit 1 means no match. Confirmed additionally by public snapshot parser refusal and actual producer/consumer trace.'},indent=2)+'\n')

def row(name,projection,producers,consumers,kept,difference,residue):
 return dict(reference=name,current_projection=projection,producers=producers,consumers=consumers,
             retained_behavior=kept,wire_and_semantic_differences=difference,residual_obligation=residue,
             disposition='Explicit incompatible reference wire shape; retain current versioned contract and listed behavior; no wholesale port')
rows=[
 row('EvidenceRefV1',['SourceLocation','RunView','Guard','FunctionView'],
 ['views.FunctionView.location','views.build_views'],
 ['pipeline._locations_owned','MainWindow.jump_signal','pilot.sources.code._b1_observations'],
 'Owned function/run/artifact/side, inclusive line ranges, exact excerpt SHA256, zero address distinct from absent, domain-separated input identity.',
 'Reference combines project/run/artifact SHA/raw/diff/occurrence identity, source kind, pointer, address kind and quality in one object. Current SourceLocation contains project-owned IDs and line/excerpt data; RunView/Guard supply outer identity. Hash prefix and occurrence recipes differ, so old IDs cannot be aliases. Pilot ObsRef/Nav are separate source/RVA contracts.',
 'Confirmed UI omission: current jump_signal bypasses existing live validator. Reference p-code/raw-json locators are not automatically supported by enrichment SourceLocation; no invented conversion.'),
 row('FeatureGateV1',['FeatureSite','FeatureTransition'],
 ['wil.analyze','wil.wil_signals'],['pipeline._run','cli.cmd_flags','MainWindow._render_signals'],
 'Numeric identifiers, duplicate sites, lexical enclosure versus adjacent/unknown, old/new transition, bounded scanning and explicit uncertainty; no CFG claim.',
 'Current records omit friendly-name provenance, explicit parent feature IDs and resolved-symbol hashes from the proposed record. Pipeline invokes analyze with absent symbol status; it does not supply an authenticated PDB-name map. Nested lexical enclosure tests are not a graph or typed dominance proof.',
 'Typed dominance, authenticated private-wrapper/name mapping and explicit nesting provenance need separate evidence and versioned design; no stronger tier inferred.'),
 row('ChangeSignalV1',['ChangeSignal','SignalSet','DetectorOutcome','StageResult'],
 ['signals.detect','wil.wil_signals','pipeline._run'],['ranking.rank','MainWindow._render_signals','pilot.sources.code.B1Evidence'],
 'Eight detector IDs, two-sided prerequisites, edit grouping, confidence limitations, exact locations, unavailable separated from complete zero output.',
 'Reference places common stage metadata, category, base weight and presence flags inside each signal. Current groups these across SignalSet/DetectorOutcome and pipeline/config records. typed_evidence is not created by importing a schema or by a higher numeric score.',
 'Current lexical detectors remain heuristic; reference typed-IR acceptance requires a separately implemented trusted source and independent qualification.'),
 row('RankingConfigV1',['RankingConfig'],
 ['cli._config','profiles.AnalysisProfile.ranking_config'],['ranking.config_digest','ranking.score_signals','pipeline._run'],
 'Same eight default weights, exact integer arithmetic, 40-point group cap, 80-point raw cap, attention/1 formula and semantic config digest.',
 'Reference schema serializes multipliers, caps, id and disabled_detectors. Current has weights/enabled/formula; multipliers and caps are fixed algorithm constants. The schema permits alternative multiplier values even though the reference prose defines defaults; that does not authorize changing current calibration semantics.',
 'No migration or configurable multiplier feature is approved. Never reinterpret current attention as probability or pilot confidence.'),
 row('FunctionRankingV1',['RankingEntry','RankingResult'],
 ['ranking.rank'],['cli.cmd_rank','MainWindow._load_enrichment','reports._ranking_section'],
 'Score/raw/group subtotals, deterministic score/strong-group/pairing order, separate match certainty/evidence status, default-profile/staleness guards and same displayed/exported base values.',
 'Reference missing_reasons, tie_key and common provenance are not fields of RankingEntry. Current diagnostics live in outcomes/stages/notes, ties are deterministic rather than pilot tie classes. No direct reference object can be loaded as RankingEntry.',
 'Do not claim all proposed per-row diagnostics are exported; richer projection would require explicit versioned output scope. Pilot consumes signals rather than this numeric score.'),
 row('CVEContextV1',['CveSnapshot','AttributedText','AttributedValue','CvssRecord'],
 ['cve.normalize','cve.select_latest','cli.cmd_correlate'],['cve.contextual_rank','cve.parse_snapshots'],
 'Bounded strict provider/import parsing, provider attribution, response-pinned identity, conflicts, conservative freshness, explicit consent and imported-file unverified warning with feature-ID claims removed.',
 'Reference adds modified timestamp, richer affected predicates and common availability/provenance fields. Current snapshot ID binds CVE/normalization/provider byte digests, not the reference object recipe. Current CVE limit/ASCII boundary differs from the prose; the reference schema itself omits the prose total-length cap. No automatic wire conversion exists.',
 'Richer advisory predicates in intelligence/pilot do not turn B3 snapshots into authenticated CSAF. Live provider qualification and any new normalized fields remain separate.'),
 row('ContextualRankingV1',['ContextContribution','ContextualEntry','ContextualRanking'],
 ['cve.contextual_rank','pipeline._run'],['cli.cmd_correlate','pipeline.publish'],
 'Base score/rank preserved, bounded +12/+10/+8/+4 contributions and +30 cap, binary-support and conflicting-CWE guards, explicit stale/term-limit partial status.',
 'Current separates result-wide snapshot/input identity from each entry. ContextContribution stores source label/binary reference/detail, not every proposed field-digest/token/rule field. CLI is the actual snapshot-fed pipeline entry; desktop rank_changes supplies no snapshots, and current report ranking adapter emits base ranking only.',
 'Full proposed B3 desktop contextual-rank/report projection is not proven replaced by Leads. Treat it as an additional product design decision; never feed B3 points into pilot tiers.'),
 row('CacheManifestV1',['CacheManifest','CacheConfig','RuntimeFingerprint'],
 ['enrichment.cache.DerivedCache','enrichment.cache.RuntimeFingerprint.raw_key'],['pipeline._cached','backend.run_comparison'],
 'Content/stage keys, payload size/hash verification, strict manifest, ownership revalidation, private staging and manifest publication, lease/retention policy and raw fingerprint eligibility.',
 'Reference has a files list, explicit state/integrity algorithm/tool digest and durable access field. Current manifest describes one payload, complete state is implied by publication, access uses mtime, and tool inputs are in stage/raw keys. These are not interchangeable wire objects.',
 'This packet inspects cache source but does not rerun native power-loss/Windows locking or raw engine acceptance. Recorded cache performance objectives are not qualified here.'),
 row('PipelineExecutionV1',['PipelineStatus','StageResult','PipelineOptions','PipelineResult','enrichment.storage.Entry'],
 ['pipeline._run','pipeline.publish'],['cli._run_pipeline','MainWindow.rank_changes','pipeline.load_default','pilot.collect._signal_sets'],
 'Owner-thread publication, guard/current input checks, separate stage statuses, cancellation refusal, preservation of earlier work, version/config identities and additive SQLite extension.',
 'Reference stores offline/cache policy and common provenance in each execution. Current operational policy is in options/profile/cache adapters; pipeline rows carry stage/config/algorithm metadata. Current currency excludes note-only revision changes by an explicit later contract. A different field layout is not a drop-in migration.',
 'Publication validation and complete provenance export deserve their own scopes; this narrow confirmed repair is navigation only and leaves stored evidence unchanged.'),
]
ledger={'scope':'Read-only reconciliation of nine historical Phase 2 reference contracts against actual enrichment/pilot production consumers. Not whole-branch closure, not an implementation or calibration migration.',
 'baseline':BASE,'tree':'2183dcf3b9cfee268c3ebb163ad9f3e9e928e10f','reference_tip':REFERENCE,
 'original_inventory':'All 131 original reconciliation tips already received bounded focal dispositions in batches 1–7; this follow-up does not alter that denominator or close broader residues.',
 'reference_provenance':json.loads((Q/'reference-manifest.json').read_text()),'record_count':len(rows),'records':rows,
 'runtime_search':'reference-runtime-call-search.json','caller_proofs':'caller-proofs.json',
 'pilot_boundary':{'inputs':'collect._signal_sets loads/computes B1 SignalSets; B1Evidence emits tool-reported code shape observations from Ghidra origin. It does not consume attention/1 or contextual numeric scores.',
                  'classification':'pilot/1 is ordinal mechanism/class with explicit gates, component independence and tie-aware ordering; STRONG_REACHABLE is False, AssignedMechanism excludes strong.',
                  'future_tie_note':'pilot/ranking.py states the plan attention-rank tie preference has no supplying source yet; current exact tie behavior is candidate_key order, preserved.'},
 'confirmed_gap':{'id':'P2-NAV-1','state':'Existing documented open contract boundary reproduced; source unchanged',
   'source':'src/patchtrace/ui.py:MainWindow.jump_signal','existing_validator':'src/patchtrace/enrichment/views.py:validate_location',
   'historical_scope_note':'docs/specs/enrichment-hardening-backlog.md explicitly deferred UI wiring to its owner.',
   'probe':'test_phase2_navigation_boundary.py','probe_sha256':'61b5d7c21778e12ba71bc6d32a0779f7d1d457656955bf2bfdab64c8c5953688',
   'outcomes':{'failed':3,'passed':4,'seconds':1.67},
   'reachability':'Authored checksum-valid derived row through real pipeline publication, project close/reopen, real MainWindow load and actual code cursor selection; invalid excerpt/side/run each reaches reveal_lines.',
   'limit':'Does not claim normal detectors produce invalid rows, that checksums authenticate origins, or native/manual acceptance. Publication behavior is observed, not included in the approved navigation-only repair.'},
 'qualification':[
   {'run':'current-contracts','passed':697,'failed':0,'skipped':0,'seconds':8.29,'scope':'11 inspected current enrichment/UI/pilot test files; authored fixtures, source-only Python child import/schema checks, offscreen Qt.'},
   {'run':'reference-original','passed':23,'failed':0,'skipped':0,'seconds':0.12,'scope':'Exact original reference test bytes; existing runtime JSON Schema dependency, no installation/network/processes in tests; no semantic or runtime compatibility claim.'},
   {'run':'wire-boundary','passed':10,'failed':0,'skipped':0,'seconds':0.21,'scope':'Nine reference-valid wire objects refused by their current projection, plus public snapshot parser typed refusal. Refusal is expected and protective.'},
   {'run':'navigation-boundary-red','passed':4,'failed':3,'skipped':0,'seconds':1.67,'scope':'Actual persisted/reopened GUI navigation defect and pure-validator/valid-navigation positives.'}],
 'limits':['No production or existing test changes.','Original batch7 missing-jsonschema collection error and later historical 23-pass run retained with original source attribution.','No live CVE fetch, target execution, native engine, compiler, Windows package, frozen application, calibration run or manual desktop acceptance.','Current-source tests do not turn reference schema examples into operational authenticity or complete supplied-schema support.','No percentages or additive coverage totals; gates overlap and have different purposes.']}
(Q/'disposition.json').write_text(json.dumps(ledger,indent=2)+'\n')
print(len(rows),'reference dispositions;',len(proofs),'exact symbol/caller proofs.')
