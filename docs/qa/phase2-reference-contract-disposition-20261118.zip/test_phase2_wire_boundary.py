"""The supplied wire objects are references, never an implicit enrichment/1 import format."""
import json
from pathlib import Path

import pytest
from pydantic import ValidationError

from patchtrace.enrichment import contracts, cve

EXAMPLES = json.loads((Path(__file__).parent / 'reference/docs/schemas/phase2/'
                       'PatchTrace-Phase2-Synthetic-Examples-v1.json').read_bytes())
PROJECTIONS = (
    ('EvidenceRefV1', contracts.SourceLocation),
    ('FeatureGateV1', contracts.FeatureTransition),
    ('ChangeSignalV1', contracts.ChangeSignal),
    ('RankingConfigV1', contracts.RankingConfig),
    ('FunctionRankingV1', contracts.RankingEntry),
    ('CVEContextV1', contracts.CveSnapshot),
    ('ContextualRankingV1', contracts.ContextualRanking),
    ('CacheManifestV1', contracts.CacheManifest),
    ('PipelineExecutionV1', contracts.PipelineStatus),
)


@pytest.mark.parametrize('reference,current', PROJECTIONS)
def test_reference_objects_require_an_explicit_versioned_adapter(reference, current):
    with pytest.raises(ValidationError):
        current.model_validate_json(json.dumps(EXAMPLES['valid'][reference]))


def test_public_snapshot_parser_refuses_reference_wire_shape():
    with pytest.raises(contracts.EnrichmentError) as problem:
        cve.parse_snapshots(json.dumps(EXAMPLES['valid']['CVEContextV1']).encode())
    assert problem.value.code == 'PT-ENRICH-INPUT'
