"""Atomic exports from validated, persisted project snapshots."""
from __future__ import annotations

import hashlib
import html
import json
import os
import re
import tempfile
from pathlib import Path

from .hostile_text import escape_text, is_hostile
from .models import ComparisonProject, ExportManifest

MAX_REPORT_BYTES = 20 * 1024 * 1024
SAFE_SETTING_KEYS = {'timeout_seconds', 'allow_symbol_downloads', 'older_sha256', 'newer_sha256', 'python_version',
                     'pyghidra_version', 'ghidra_version', 'java_runtime_version', 'symbol_mode',
                     'symbol_input_digest', 'launcher_version', 'staged_symbols'}


class ExportError(ValueError):
    pass


class _Verbatim(str):
    """Decompiled code, assembly or evidence text: credentials are redacted but paths and URLs are
    not, because rewriting `a /b; // c:/x` would make exported evidence disagree with the source."""


def _redact(text: str, verbatim: bool = False) -> str:
    text = re.sub(r'(?i)\b(?:authorization\s*:\s*bearer|bearer)\s+[^\s,;"\']+', '[REDACTED]', text)
    text = re.sub(r'(?i)\b(?:api[_-]?key|password|secret|access[_-]?token)\s*[:=]\s*["\']?[^\s,;"\']+',
                  '[REDACTED]', text)
    text = re.sub(r'\bsk-[A-Za-z0-9_-]{8,}', '[REDACTED]', text)
    if verbatim:
        return text
    # Windows paths may contain spaces; keep consuming words while a later separator stays in the token.
    text = re.sub(r'(?i)(?:[a-z]:[\\/]|\\\\)[^\s<>"\']*(?:[ \t]+[^\s<>"\'\\/]*[\\/][^\s<>"\']*)*',
                  '[PATH REDACTED]', text)
    text = re.sub(r'(?<![\w:/<])/(?:[^\s/<>"\']+/)*[^\s<>"\']+', '[PATH REDACTED]', text)
    text = re.sub(r'https?://[^\s/@:]+:[^\s/@]+@[^\s]+', '[CREDENTIAL URL REDACTED]', text)
    return text


def _clean(value):
    if isinstance(value, _Verbatim):
        return _redact(str(value), verbatim=True)
    if isinstance(value, str):
        return _redact(value)
    if isinstance(value, list):
        return [_clean(v) for v in value]
    if isinstance(value, dict):
        return {k: _clean(v) for k, v in value.items()}
    return value


def _safe_staged(value) -> list[dict] | None:
    """Names and hashes of staged PDBs only (SPEC-53); anything malformed drops the whole key."""
    if not isinstance(value, list) or len(value) > 64:
        return None
    rows = []
    for row in value:
        if (not isinstance(row, dict) or set(row) != {'name', 'guid_age', 'sha256'}
                or not isinstance(row['name'], str) or not re.fullmatch(r'[\w.+@ -]{1,255}', row['name'])
                or not isinstance(row['guid_age'], str) or not re.fullmatch('[0-9A-F]{33,40}', row['guid_age'])
                or not isinstance(row['sha256'], str) or not re.fullmatch('[0-9a-f]{64}', row['sha256'])):
            return None
        rows.append({'name': row['name'], 'guid_age': row['guid_age'], 'sha256': row['sha256']})
    return rows


def _safe_settings(settings: dict) -> dict:
    result = {}
    for key in sorted(SAFE_SETTING_KEYS & settings.keys()):
        value = settings[key]
        if key == 'allow_symbol_downloads':
            if isinstance(value, bool):
                result[key] = value
        elif key == 'timeout_seconds':
            if type(value) is int and 1 <= value <= 86400:
                result[key] = value
        elif key == 'symbol_mode':
            if value in ('off', 'local', 'online'):
                result[key] = value
        elif key == 'symbol_input_digest':
            if isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value):
                result[key] = value
        elif key == 'staged_symbols':
            rows = _safe_staged(value)
            if rows is not None:
                result[key] = rows
        elif key.endswith('_sha256'):
            if isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value):
                result[key] = value
        elif isinstance(value, str) and re.fullmatch(
                r'(?:unknown|unverified|unavailable|not-installed|[0-9][A-Za-z0-9_.+ -]{0,99})', value):
            result[key] = value
    return result


def _ranking_section(project: ComparisonProject, enrichment: dict | None, selected_matches: set[str]) -> dict | None:
    """Validated attention/1 ranking for exported matches; values identical to GUI/CLI."""
    if enrichment is None:
        return None
    from .enrichment.contracts import RankingResult
    if set(enrichment) - {'profile'} != {'ranking', 'stale'} or type(enrichment['stale']) is not bool:
        raise ExportError('PT-EXPORT: malformed ranking input')
    profile = enrichment.get('profile')
    if profile is not None and (not isinstance(profile, dict) or set(profile) != {'name', 'digest'}
                                or not isinstance(profile['name'], str)
                                or not re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9 _.-]{0,63}', profile['name'])
                                or not isinstance(profile['digest'], str)
                                or not re.fullmatch(r'[0-9a-f]{64}', profile['digest'])):
        raise ExportError('PT-EXPORT: malformed ranking profile')
    try:
        ranking = RankingResult.model_validate_json(json.dumps(enrichment['ranking']))
    except (ValueError, RecursionError):
        raise ExportError('PT-EXPORT: ranking failed validation') from None
    known = {m.id: m for m in project.matches}
    if any(e.match_id not in known for e in ranking.entries):
        raise ExportError('PT-EXPORT: ranking references a match outside this project')
    entries = []
    for entry in ranking.entries:
        if entry.match_id not in selected_matches:
            continue
        match = known[entry.match_id]
        entries.append({'rank': entry.rank, 'score': entry.score, 'raw': entry.raw, 'evidence': entry.evidence,
                        'match_id': entry.match_id, 'pairing_id': entry.pairing_id,
                        'match_certainty': entry.match_certainty, 'strong_groups': entry.strong_groups,
                        'groups': [g.model_dump(exclude={'contract'}) for g in entry.groups],
                        'functions': sorted({f.name for f in match.older + match.newer})})
    return {'formula': ranking.formula, 'config_digest': ranking.config_digest,
            'input_digest': ranking.input_digest, 'status': ranking.status, 'stale': enrichment['stale'],
            'profile': dict(profile) if profile is not None else None,
            'note': 'Attention scores prioritize research; they do not establish exploitability or CVE relevance.',
            'entries': entries}


def _annotation(annotation, include_code: bool) -> dict:
    """A match override embeds full previous matches (code, assembly); without code export keep only ids."""
    data = annotation.model_dump()
    if annotation.kind == 'match-override' and not include_code:
        try:
            record = json.loads(annotation.text)
            data['text'] = json.dumps({k: record.get(k) for k in ('category', 'reason', 'older_ids', 'newer_ids')},
                                      ensure_ascii=False, sort_keys=True)
        except (ValueError, AttributeError, RecursionError):
            data['text'] = ''
    return data


def _snapshot(project: ComparisonProject, include_code: bool, include_notes: bool,
              finding_ids: list[str] | None, enrichment: dict | None = None) -> dict:
    project = ComparisonProject.model_validate(project.model_dump())
    findings = {f.id: (run, f) for run in project.interpretations for f in run.findings}
    selected = sorted(findings if finding_ids is None else set(finding_ids))
    if any(i not in findings for i in selected):
        raise ExportError('PT-EXPORT: requested finding ID is not in the saved project')
    selected_matches = {m for i in selected for m in findings[i][1].match_ids}
    if finding_ids is None:
        selected_matches.update(m.id for m in project.matches)
    function_ids = set()
    matches = []
    for match in sorted(project.matches, key=lambda m: m.id):
        if match.id not in selected_matches:
            continue
        data = match.model_dump(exclude={'older', 'newer'})
        for side in ['older', 'newer']:
            data[side] = []
            for f in sorted(getattr(match, side), key=lambda f: f.id):
                function_ids.add(f.id)
                function = f.model_dump(exclude={'code', 'assembly', 'metadata'})
                if include_code:
                    function['code'] = _Verbatim(f.code)
                    function['assembly'] = _Verbatim(f.assembly)
                data[side].append(function)
        matches.append(data)
    interpretations = []
    for run in sorted(project.interpretations, key=lambda r: r.id):
        run_findings = [f for f in run.findings if f.id in selected]
        if finding_ids is not None and not run_findings:
            continue
        citations = {ref for f in run_findings for h in [f.hypothesis] + f.alternatives
                     for ref in h.supporting + h.contradicting}
        context = run.context.model_dump(exclude={'payload', 'evidence'})
        context['evidence'] = []
        for ref in sorted(run.context.evidence, key=lambda e: e.id):
            if finding_ids is not None and ref.id not in citations:
                continue
            item = ref.model_dump(exclude=set() if include_code else {'text'})
            if isinstance(item.get('text'), str):
                item['text'] = _Verbatim(item['text'])
            context['evidence'].append(item)
        # Omission strings describe untrusted input names and may contain source/code fragments.
        context['omitted'] = [f'{len(run.context.omitted)} omitted or unavailable context entries']
        context['stale'] = run.context.stale or run.context.revision != project.revision
        data = run.model_dump(exclude={'context', 'findings', 'raw_response'})
        data['context'] = context
        data['findings'] = []
        for f in sorted(run_findings, key=lambda f: f.id):
            result = f.model_dump()
            result['stale'] = f.stale or context['stale']
            if not include_notes:
                result.pop('analyst_conclusion', None)
            data['findings'].append(result)
        interpretations.append(data)
    relevant = {project.id} | selected_matches | function_ids | set(selected)
    result = {
        'schema_version': 1, 'project_id': project.id, 'name': project.name, 'revision': project.revision,
        'created': project.created, 'sample': project.sample,
        'limitations': ['Static evidence and hypotheses require analyst verification.',
                        'Qualitative confidence is not a vulnerability probability.',
                        'Unavailable context and stale findings remain explicitly identified.',
                        'Raw provider responses and original source paths are excluded.'],
        'selection': {'finding_ids': selected, 'include_code': include_code, 'include_notes': include_notes},
        'artifacts': [{'id': a.id, 'side': a.side, 'name': a.name.replace('\\', '/').split('/')[-1],
                       'sha256': a.sha256, 'size': a.size, 'architecture': a.architecture, 'format': a.format}
                      for a in sorted(project.artifacts, key=lambda a: a.id)],
        'analysis_runs': [r.model_dump(include={'schema_version', 'id', 'created', 'status', 'backend',
                                               'backend_version', 'raw_sha256', 'error'})
                          | {'settings': _safe_settings(r.settings)}
                          for r in sorted(project.runs, key=lambda r: r.id)],
        'matches': matches, 'interpretations': interpretations,
        'change_ranking': _ranking_section(project, enrichment, selected_matches),
        'annotations': [_annotation(a, include_code) for a in sorted(project.annotations, key=lambda a: a.id)
                        if include_notes and (finding_ids is None or a.target_id in relevant)],
    }
    return _clean(result)


def _markdown_escape(value: str) -> str:
    value = html.escape(value, quote=False)
    return re.sub(r'([\\`*_{}\[\]()#+.!|>~:-])', r'\\\1', value)


def _cell(value: str) -> str:
    """Markdown table cell: escaped, with line breaks flattened so untrusted names cannot end the row."""
    return _markdown_escape(' '.join(str(value).split()))


def _render(data: dict, format: str) -> str:
    # Outside the layout newline, hostile characters sit inside JSON strings, where the \uXXXX spelling is the same value.
    serialized = ''.join(json.dumps(c)[1:-1] if is_hostile(c) and c != '\n' else c
                         for c in json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False))
    if format == 'json':
        return serialized + '\n'
    if format == 'html':
        title = html.escape(data['name'])
        parts = ['<!doctype html><html lang="en"><head><meta charset="utf-8">',
                 '<meta name="viewport" content="width=device-width, initial-scale=1">',
                 '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'">',
                 f'<title>PatchTrace — {title}</title>',
                 '<style>body{max-width:1000px;margin:2rem auto;padding:0 1rem;font:16px sans-serif;}',
                 'pre{white-space:pre-wrap;overflow-wrap:anywhere;}article{border-top:1px solid #aaa;padding:1rem 0;}</style>',
                 f'</head><body><h1>{title}</h1><p>PatchTrace static comparison report; revision {data["revision"]}.</p>']
        ranking = data.get('change_ranking')
        if ranking:
            parts.append('<h2>Change ranking (' + html.escape(ranking['formula'])
                         + (', STALE' if ranking['stale'] else '') + ')</h2><p>' + html.escape(ranking['note'])
                         + '</p>' + (f'<p>Profile: {html.escape(ranking["profile"]["name"])} '
                                     f'(digest {ranking["profile"]["digest"]})</p>' if ranking.get('profile') else '')
                         + '<table><tr><th>Rank</th><th>Score</th><th>Evidence</th><th>Functions</th></tr>')
            for entry in ranking['entries']:
                parts.append(f'<tr><td>{entry["rank"]}</td><td>{entry["score"]}</td><td>'
                             + html.escape(entry['evidence']) + '</td><td>'
                             + html.escape(', '.join(entry['functions'])) + '</td></tr>')
            parts.append('</table>')
        for run in data['interpretations']:
            for finding in run['findings']:
                parts.append('<article><h2>' + html.escape(finding['summary']) + '</h2><p>'
                             + html.escape(finding['fix_purpose']) + '</p><p>Review: '
                             + html.escape(finding['review']) + '; stale: '
                             + str(finding['stale']).lower() + '</p></article>')
        parts += ['<h2>Evidence and provenance</h2><pre>', html.escape(serialized), '</pre></body></html>\n']
        return escape_text(''.join(parts), keep='\n')
    parts = ['# PatchTrace report', '', _markdown_escape(data['name']), '',
             f'Project revision: {data["revision"]}', '']
    ranking = data.get('change_ranking')
    if ranking:
        parts += ['## Change ranking (' + _markdown_escape(ranking['formula'])
                  + (', STALE' if ranking['stale'] else '') + ')', '', _markdown_escape(ranking['note']), '',
                  *([f'Profile: {_markdown_escape(ranking["profile"]["name"])} '
                     f'(digest {ranking["profile"]["digest"]})', ''] if ranking.get('profile') else []),
                  '| Rank | Score | Evidence | Functions |', '|---:|---:|---|---|']
        parts += [f'| {e["rank"]} | {e["score"]} | {_cell(e["evidence"])} | '
                  + _cell(', '.join(e['functions'])) + ' |' for e in ranking['entries']]
        parts.append('')
    for run in data['interpretations']:
        for finding in run['findings']:
            parts += ['## ' + _markdown_escape(finding['summary']), '',
                      _markdown_escape(finding['fix_purpose']), '',
                      'Review: ' + _markdown_escape(finding['review']) + '; stale: '
                      + str(finding['stale']).lower(), '']
    parts += ['## Evidence and provenance', '', _markdown_escape(serialized), '']
    return escape_text('\n'.join(parts), keep='\n')


def previous_copy_path(destination: Path, data: bytes) -> Path:
    """Where an overwritten export's earlier bytes are kept: `<stem>.previous-<sha256[:8]><suffix>` beside it."""
    digest = hashlib.sha256(data).hexdigest()[:8]
    return destination.with_name(f'{destination.stem}.previous-{digest}{destination.suffix}')


def _keep_previous(destination: Path, content: bytes) -> Path | None:
    """Back up an existing destination whose bytes differ from `content`; never overwrite an earlier backup.

    The dialog's default destination is a fixed `exports/report.<ext>`, so without this every export silently
    replaced the previous one. A file larger than any report is refused rather than read or replaced: the path
    most likely names something that is not a PatchTrace report.
    """
    try:
        if not destination.is_file():
            return None
        if destination.stat().st_size > MAX_REPORT_BYTES:
            raise ExportError(f'PT-EXPORT: {destination.name} exists and is larger than any report; '
                              'choose another destination')
        with destination.open('rb') as stream:
            previous = stream.read(MAX_REPORT_BYTES + 1)
        if len(previous) > MAX_REPORT_BYTES:
            raise ExportError('PT-EXPORT: existing report grew beyond the report cap; choose another destination')
    except FileNotFoundError:
        return None
    if previous == content:
        return None
    backup = previous_copy_path(destination, previous)
    try:
        fd = os.open(backup, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    except FileExistsError:
        if backup.is_symlink() or not backup.is_file():
            raise ExportError('PT-EXPORT: previous report backup is not a regular file; '
                              'choose another destination') from None
        with backup.open('rb') as stream:
            matches = stream.read(len(previous) + 1) == previous
        if not matches:
            raise ExportError('PT-EXPORT: previous report backup does not match; choose another destination') from None
        return backup
    try:
        with os.fdopen(fd, 'wb') as stream:
            stream.write(previous)
            stream.flush()
            os.fsync(stream.fileno())
    except BaseException:
        # Only the exclusive creator may remove its failed copy. A later retry also verifies bytes,
        # so inability to clean up can never turn an incomplete copy into a successful preservation.
        try:
            backup.unlink(missing_ok=True)
        except OSError:
            pass
        raise
    return backup


def _check_destination(project: ComparisonProject, destination: Path, root: Path | None) -> None:
    """Protect owned project state before any export filesystem mutation; not a TOCTOU sandbox."""
    if destination.is_symlink():
        raise ExportError('PT-EXPORT: report destination must not be a symlink')
    if root is None:
        return
    try:
        root = root.resolve()
        exports = root / 'exports'
        resolved = destination.resolve()
        lexical = Path(os.path.abspath(destination))
        for path in (lexical, resolved):
            if path.is_relative_to(root) and not path.is_relative_to(exports):
                raise ExportError('PT-EXPORT: choose exports/ or a destination outside the project')
        evidence = [root / a.relative_path for a in project.artifacts]
        evidence += [root / r.raw_path for r in project.runs if r.raw_path]
        if resolved in {path.resolve() for path in evidence}:
            raise ExportError('PT-EXPORT: report destination is retained project evidence')
        if destination.exists():
            # Namespace checks already protect internal stores. Alias checks stay finite:
            # registered evidence plus reserved SQLite companions and the project lock.
            protected = [root / name for name in ('project.sqlite3', 'project.sqlite3-wal',
                         'project.sqlite3-shm', 'project.sqlite3-journal', '.patchtrace.lock')]
            for path in [*evidence, *protected]:
                if path.is_file() and destination.samefile(path):
                    raise ExportError('PT-EXPORT: report destination aliases protected project data')
    except (OSError, RuntimeError) as exc:
        raise ExportError('PT-EXPORT: cannot verify destination ownership; choose another destination') from exc


def export_project(project: ComparisonProject, format: str, destination: Path, include_code: bool = False,
                   include_notes: bool = True, finding_ids: list[str] | None = None,
                   enrichment: dict | None = None, *, project_root: Path | None = None, report_version: int = 1,
                   sections=None, redaction=None, calibration_profile: str | None = None) -> ExportManifest:
    destination = Path(destination)
    _check_destination(project, destination, project_root)
    if format not in {'json', 'html', 'md'}:
        raise ExportError('PT-EXPORT: supported formats are json, html, and md')
    if report_version not in (1, 2):
        raise ExportError('PT-EXPORT-CONTRACT: report_version must be 1 or 2')
    if report_version == 1 and (sections is not None or redaction is not None or calibration_profile is not None):
        raise ExportError('PT-EXPORT-CONTRACT: sections, redaction and calibration_profile need report_version=2')
    v2 = None
    if report_version == 2:
        from .report2 import text as report2_text
        from .report2.export import render as render_v2
        from .report2.inputs import RedactionProfile
        profile = redaction or RedactionProfile()
        include_code, include_notes = profile.effective(include_code, include_notes)
        data = _snapshot(project, include_code, include_notes, finding_ids, enrichment)
        rendered, v2 = render_v2(project, format, data, include_code=include_code, include_notes=include_notes,
                                 sections=sections, profile=profile, calibration_profile=calibration_profile)
        content = report2_text.encode_report(rendered)
    else:
        data = _snapshot(project, include_code, include_notes, finding_ids, enrichment)
        content = _render(data, format).encode('utf-8')
    if len(content) > MAX_REPORT_BYTES:
        raise ExportError(('PT-EXPORT-SIZE' if v2 else 'PT-EXPORT')
                          + ': report exceeds 20 MiB; select fewer findings or exclude code')
    destination = Path(destination)
    staged = None
    try:
        destination.parent.mkdir(parents=True, exist_ok=True)
        with tempfile.NamedTemporaryFile(dir=destination.parent, prefix='.patchtrace-export-', delete=False) as stream:
            staged = Path(stream.name)
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        _keep_previous(destination, content)  # before the replace: a failed backup leaves the old file in place
        os.replace(staged, destination)
    except OSError:
        raise ExportError(('PT-EXPORT-IO' if v2 else 'PT-EXPORT')
                          + ': cannot write report; check destination permissions and free space') from None
    finally:
        if staged is not None:
            staged.unlink(missing_ok=True)
    v2_fields = {} if v2 is None else {'report_version': 2, 'content_digest': v2['content_digest'],
                                       'sections': v2['sections_present'], 'redaction_profile': profile.name}
    return ExportManifest(project_id=project.id, revision=project.revision, format=format,
                          sha256=hashlib.sha256(content).hexdigest(),
                          finding_ids=data['selection']['finding_ids'],
                          include_code=include_code, include_notes=include_notes, **v2_fields)
