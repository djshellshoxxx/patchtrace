"""Sequential real-CLI qualification; one child and one RSS observation per operation."""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import subprocess
import time
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).parent
OUT = ROOT / 'actual-csv-cli'
OUT.mkdir(exist_ok=True)
WORKSPACE = OUT / 'workspace'
PYTHON = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
SOURCE = Path('/workspace/scratch/e83fbf4505c3/pw01-live-evidence/20261118T074241Z-e077563/proxy-csv-raw.csv')
EXPECTED_SHA = 'b327eb5d0f8d7a0d6a9c8c2d1a7af1df134bc2a54c3e0da2eff0fb335547a627'
OLD = json.loads(Path('/workspace/scratch/e83fbf4505c3/pw01-retention-real-result.json').read_text())
OLD_PAGES = {item['page']: item for item in OLD['pages']}
ENV = os.environ | {'PYTHONPATH': 'src', 'PYTHONDONTWRITEBYTECODE': '1', 'QT_QPA_PLATFORM': 'offscreen'}
REPORT = {
    'source_commit': '0be3b9eb950a2a5a19261fd2f5d2f1fc2eb25b82',
    'source_tree': '81ec2835ec0b1a7b87a55cbe7b061d8b4d948878',
    'scope': 'Offline existing proxy-captured CSV; local unverified import. No production fetch or target acquisition.',
    'capture': str(SOURCE), 'capture_sha256': EXPECTED_SHA, 'capture_bytes': SOURCE.stat().st_size,
    'operations': [], 'pages': [], 'status': 'running',
}


def digest_file(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        while chunk := stream.read(1024 * 1024):
            value.update(chunk)
    return value.hexdigest()


def save():
    (OUT / 'summary.json').write_text(json.dumps(REPORT, indent=2) + '\n')


def run(name, *arguments):
    argv = [PYTHON, str(ROOT / 'offline_cli.py'), 'kb', 'inventory', *arguments,
            '--workspace', str(WORKSPACE), '--json']
    stdout, stderr = OUT / (name + '.stdout.json'), OUT / (name + '.stderr.txt')
    started = time.monotonic()
    when = datetime.now(timezone.utc).isoformat()
    with stdout.open('wb') as output, stderr.open('wb') as error:
        child = subprocess.Popen(argv, env=ENV, stdout=output, stderr=error)
        _, status, usage = os.wait4(child.pid, 0)
        child.returncode = os.waitstatus_to_exitcode(status)
    receipt = {
        'name': name, 'argv': argv, 'cwd': str(Path.cwd()), 'started_at_utc': when,
        'ended_at_utc': datetime.now(timezone.utc).isoformat(),
        'elapsed_seconds': round(time.monotonic() - started, 3), 'returncode': child.returncode,
        'signal': os.WTERMSIG(status) if os.WIFSIGNALED(status) else None,
        'peak_rss_kib': usage.ru_maxrss, 'rss_measurement': 'Linux wait4 child ru_maxrss; observed, not a ceiling',
        'stdout_bytes': stdout.stat().st_size, 'stdout_sha256': digest_file(stdout),
        'stderr_bytes': stderr.stat().st_size, 'stderr_sha256': digest_file(stderr),
        'expected_exit': 3,
    }
    (OUT / (name + '.receipt.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    REPORT['operations'].append(receipt)
    save()
    print(json.dumps({key: receipt[key] for key in ('name', 'returncode', 'elapsed_seconds', 'peak_rss_kib')}),
          flush=True)
    assert child.returncode == 3, receipt
    assert stderr.stat().st_size == 0, stderr.read_text()
    envelope = json.loads(stdout.read_text())
    assert envelope['status'] == 'partial'
    return envelope['result']


def snapshot(import_id):
    with sqlite3.connect(f'file:{WORKSPACE / "kbc.sqlite3"}?mode=ro', uri=True) as db:
        size, expected = db.execute('SELECT length(CAST(body AS BLOB)),body_sha256 '
                                    'FROM kb_inventory_imports WHERE import_id=?', (import_id,)).fetchone()
        actual = hashlib.sha256()
        for offset in range(1, size + 1, 1024 * 1024):
            chunk, = db.execute('SELECT substr(CAST(body AS BLOB),?,?) FROM kb_inventory_imports '
                                'WHERE import_id=?', (offset, 1024 * 1024, import_id)).fetchone()
            actual.update(chunk)
        assert actual.hexdigest() == expected
        return {'v1_body_bytes': size, 'v1_body_sha256': expected,
                'raw_object_sha256': digest_file(WORKSPACE / 'objects' / EXPECTED_SHA[:2] / (EXPECTED_SHA + '.gz')),
                'revisions': db.execute('SELECT COUNT(*) FROM revisions').fetchone()[0],
                'decisions': db.execute('SELECT COUNT(*) FROM decisions').fetchone()[0]}


try:
    assert digest_file(SOURCE) == EXPECTED_SHA
    assert not WORKSPACE.exists(), 'Use a fresh workspace; do not overwrite or reuse prior measurement state'
    imported = run('01-import-v1', 'import', str(SOURCE), '--kb', 'KB5036893', '--offline')
    original_id, original = imported['import_id'], imported['inventory']
    assert original['accepted_count'] == 37_595 and original['records_scanned'] == 42_845
    assert original['rejected_count'] == 5_244 and not original['truncated']
    assert original['source']['authenticity'] == 'unverified-local-file'
    assert original['source']['uri'] is None and original['retrieval'] is None
    before = snapshot(original_id)
    REPORT.update(v1_import_id=original_id, v1_summary=original, before=before)
    pages = {}
    ordinal = 2
    for number in (1, 2, 4):
        result = run(f'{ordinal:02d}-retain-page{number}', 'retain', original_id,
                     '--architecture', 'amd64', '--page', str(number))
        ordinal += 1
        value = result['inventory']
        expected_count = 3_761 if number == 4 else 5_000
        assert value['page_capacity'] == 5_000 and value['accepted_count'] == expected_count
        assert value['scan_complete'] and not value['truncated']
        assert (value['matching_count'], value['excluded_count'], value['records_scanned']) == (18_761, 18_834, 42_845)
        assert value['source'] == original['source'] and value['retrieval'] == original['retrieval']
        assert value['asserted_source'] == original['asserted_source']
        assert value['inventory_id'] == OLD_PAGES[number]['inventory_id']
        assert result['import_id'] == OLD_PAGES[number]['import_id']
        pages[number] = result['import_id']
        show_args = ('--name', 'aarsvc.dll', '--limit', '5') if number in (1, 4) else ('--limit', '1')
        shown = run(f'{ordinal:02d}-show-page{number}', 'show', result['import_id'], *show_args)
        ordinal += 1
        assert shown['inventory']['limits']['max_entries'] == 5_000
        witness = None
        if number in (1, 4):
            entry = next(item for item in shown['entries'] if item['basename'] == 'aarsvc.dll')
            witness = next(item for item in shown['inventory']['conflict_witnesses']
                           if item['conflict_group'] == entry['conflict_group'])
            assert entry['state'] == 'conflicted'
            assert (witness['first']['logical_record'], witness['second']['logical_record']) == (24_355, 41_380)
            assert witness == OLD_PAGES[number]['aarsvc_witness']
        REPORT['pages'].append({'page': number, 'import_id': result['import_id'],
                                'inventory_id': value['inventory_id'], 'accepted_count': expected_count,
                                'page_capacity': value['page_capacity'], 'witness': witness,
                                'prior_v2_ids_exact': True})
        save()
    repeated = run('08-repeat-page1-from-page4', 'retain', pages[4], '--architecture', 'amd64', '--page', '1')
    assert repeated['already_present'] and repeated['import_id'] == pages[1]
    replayed = run('09-show-v1', 'show', original_id, '--limit', '1')
    assert replayed['inventory']['limits']['max_entries'] == 50_000
    assert replayed['inventory']['accepted_count'] == 37_595
    after = snapshot(original_id)
    assert after == before and after['revisions'] == after['decisions'] == 0
    assert digest_file(SOURCE) == EXPECTED_SHA
    with sqlite3.connect(f'file:{WORKSPACE / "kbc.sqlite3"}?mode=ro', uri=True) as db:
        assert db.execute('SELECT COUNT(*) FROM kb_inventory_imports').fetchone()[0] == 4
    REPORT.update(status='passed', after=after, original_v1_and_raw_unchanged=True,
                  repeat_idempotent=True, capture_unchanged=True,
                  maximum_observed_child_rss_kib=max(item['peak_rss_kib'] for item in REPORT['operations']))
except BaseException as error:
    REPORT.update(status='failed', failure_type=type(error).__name__, failure=str(error))
    save()
    raise
save()
print(json.dumps({'status': REPORT['status'], 'operations': len(REPORT['operations']),
                  'maximum_observed_child_rss_kib': REPORT['maximum_observed_child_rss_kib']}), flush=True)
