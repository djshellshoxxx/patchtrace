"""Capture authored production-store records before capacity integration."""
from __future__ import annotations

import hashlib
import json
import socket
import subprocess
import sys
import tempfile
from pathlib import Path

from patchtrace.kbcorrelation.inventory_contracts import InventoryContext, InventoryLimits
from patchtrace.kbcorrelation.inventory_store import add_inventory, get_inventory
from patchtrace.kbcorrelation.store import WorkspaceStore


def prohibited(*args, **kwargs):
    raise AssertionError('No network or target execution is allowed')


socket.socket = prohibited
subprocess.Popen = prohibited
profile, source_commit, output = sys.argv[1:]
now = '2099-03-02T00:00:00Z'
context = InventoryContext(kb='KB5099001')
header = 'File name,File version,File size,Architecture\r\n'
records = []
with tempfile.TemporaryDirectory(prefix='pw303-golden-') as temp:
    with WorkspaceStore(Path(temp)/'workspace') as ws:
        if profile == 'v1':
            raw = (header + 'example.dll,1.2.3.4,128,x64\r\n').encode()
            for budget in (5_000, 50_000):
                value, _ = add_inventory(ws, raw, context, now=now,
                                         limits=InventoryLimits(max_entries=budget))
                assert get_inventory(ws, value.import_id) == value
                records.append((f'published_v1_{budget}', raw, value))
        else:
            from patchtrace.kbcorrelation.inventory_contracts import InventoryRetention
            from patchtrace.kbcorrelation.inventory_store import retain_inventory
            raw = (header + 'arm.sys,1.2.3.4,10,arm64\r\n'
                   'first.sys,1.2.3.4,20,x64\r\nsecond.sys,1.2.3.4,30,x64\r\n'
                   'remotesp.tsp,1.2.3.4,40,x64\r\nfirst.sys,1.2.3.5,20,x64\r\n').encode()
            for name, limits, page in (
                    ('retained_v2_default', InventoryLimits(), 1),
                    ('retained_v2_lowered', InventoryLimits(
                        max_bytes=8_000, max_text_chars=8_000, max_field_chars=128,
                        max_record_chars=256, max_columns=8, max_records=12,
                        max_entries=2, max_diagnostics=2, max_sections=3, max_seconds=3.0), 2)):
                parent, _ = add_inventory(ws, raw, context, now=now, limits=limits)
                value, _ = retain_inventory(ws, parent.import_id,
                                            InventoryRetention(architecture='amd64', page=page))
                assert get_inventory(ws, value.import_id) == value
                records.append((name, raw, value))
    payload = {'authored': True, 'source_commit': source_commit, 'records': [
        {'name': name, 'raw_utf8': raw.decode(), 'record_json': value.model_dump_json(),
         'record_sha256': hashlib.sha256(value.model_dump_json().encode()).hexdigest()}
        for name, raw, value in records]}
    Path(output).write_text(json.dumps(payload, indent=2)+'\n')
    print(json.dumps({'profile': profile, 'records': len(records), 'output': output}))
