"""Run the shipped CLI with network and external-child creation denied."""
import socket
import subprocess


def forbidden(*args, **kwargs):
    raise AssertionError('Offline captured-CSV qualification forbids network and target execution')


socket.socket = socket.create_connection = socket.getaddrinfo = forbidden
subprocess.Popen = forbidden
from patchtrace.__main__ import main  # noqa: E402

raise SystemExit(main())
