"""Independent small-row store controls for parent/page budget separation."""
import socket

import pytest

from patchtrace.kbcorrelation.inventory_contracts import InventoryContext, InventoryLimits, InventoryRetention
from patchtrace.kbcorrelation import inventory_store as store
from patchtrace.kbcorrelation.sources.cvrf import SourceError
from patchtrace.kbcorrelation.store import WorkspaceStore


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def refused(*args, **kwargs):
        raise AssertionError('independent capacity review is offline')
    for name in ('socket', 'create_connection', 'getaddrinfo'):
        monkeypatch.setattr(socket, name, refused)


@pytest.mark.parametrize('capacity', [1, 2, 4_999, 5_000, 5_001, 50_000])
def test_page_clamps_only_entry_capacity_and_empty_next_page_preserves_evidence(tmp_path, capacity):
    raw = b'File name,File version,File size,Architecture\r\nreview.dll,1.2.3.4,64,x64\r\n'
    limits = InventoryLimits(max_entries=capacity, max_bytes=1_024, max_text_chars=1_024,
                             max_field_chars=64, max_record_chars=128, max_columns=4,
                             max_records=3, max_diagnostics=1, max_sections=1, max_seconds=2.0)
    with WorkspaceStore(tmp_path / 'workspace') as ws:
        parent, added = store.add_inventory(ws, raw, InventoryContext(kb='KB5099001'),
                                            now='2099-03-02T00:00:00Z', limits=limits,
                                            asserted_source='https://support.microsoft.com/help/5099001')
        assert added
        original_body = parent.model_dump_json()
        original_raw = ws.object_path(parent.source.sha256).read_bytes()
        child, added = store.retain_inventory(ws, parent.import_id,
                                              InventoryRetention(architecture='amd64', page=1))
        assert added and child.parsed.scan_complete and child.parsed.accepted_count == 1
        assert child.parsed.limits.model_dump() == limits.model_dump() | {'max_entries': min(capacity, 5_000)}
        assert child.source == parent.source and child.retrieval == parent.retrieval
        assert child.asserted_source == parent.asserted_source
        assert store.get_inventory(ws, parent.import_id).model_dump_json() == original_body
        before = tuple(ws.db.execute(f'SELECT * FROM {store.INVENTORY_TABLE} ORDER BY import_id'))
        with pytest.raises(SourceError) as raised:
            store.retain_inventory(ws, parent.import_id, InventoryRetention(architecture='amd64', page=2))
        assert raised.value.code == 'PT-KBC-INPUT'
        assert tuple(ws.db.execute(f'SELECT * FROM {store.INVENTORY_TABLE} ORDER BY import_id')) == before
        assert store.inventory_count(ws) == 2
        assert ws.object_path(parent.source.sha256).read_bytes() == original_raw
        assert ws.db.execute('SELECT count(*) FROM revisions').fetchone()[0] == 0
