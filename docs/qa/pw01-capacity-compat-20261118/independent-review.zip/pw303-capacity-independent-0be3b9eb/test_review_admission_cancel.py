"""Independent synthetic cancellation controls; no network or target inputs."""
from __future__ import annotations

import socket
import threading

import pytest
import test_kbc_inventory_selection as support

from patchtrace.kbcorrelation import inventory_selection as selected
from patchtrace.kbcorrelation.store import KbcStoreError, WorkspaceStore


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def refuse(*args, **kwargs):
        raise AssertionError('admission review is offline')
    for name in ('socket', 'create_connection', 'getaddrinfo'):
        monkeypatch.setattr(socket, name, refuse)


def prepare(tmp_path, repeat):
    svc = support.service(tmp_path)
    state = support.start(svc)
    identity = support.inventory(svc, tmp_path)
    if repeat:
        first = support.select(svc, state, identity)
        state = state[0], state[1], first.result['revision']
    return svc, state, identity, support.snapshot(svc, state[0])


@pytest.mark.parametrize('repeat', [False, True])
def test_cancel_after_replay_preserves_new_and_idempotent_selection(tmp_path, monkeypatch, repeat):
    svc, state, identity, before = prepare(tmp_path, repeat)
    token = threading.Event()
    original = selected.get_inventory

    def cancel_after_replay(*args, **kwargs):
        result = original(*args, **kwargs)
        token.set()
        return result

    monkeypatch.setattr(selected, 'get_inventory', cancel_after_replay)
    with pytest.raises(KbcStoreError) as raised:
        support.select(svc, state, identity, cancel=token)
    assert token.is_set()
    assert raised.value.code == 'PT-KBC-CANCEL'
    assert support.snapshot(svc, state[0]) == before


@pytest.mark.parametrize('repeat', [False, True])
def test_cancel_during_admission_source_read_rolls_back(tmp_path, monkeypatch, repeat):
    svc, state, identity, before = prepare(tmp_path, repeat)
    token = threading.Event()
    observed = []
    original = WorkspaceStore.sources

    def cancel_on_transaction_read(ws):
        result = original(ws)
        if ws.root == svc.root and ws.db.in_transaction:
            observed.append(True)
            token.set()
        return result

    monkeypatch.setattr(WorkspaceStore, 'sources', cancel_on_transaction_read)
    with pytest.raises(KbcStoreError) as raised:
        support.select(svc, state, identity, cancel=token)
    assert observed == [True]
    assert raised.value.code == 'PT-KBC-CANCEL'
    assert support.snapshot(svc, state[0]) == before
