# Independent frozen PW/#303 capacity integration review

**Disposition: approve the reviewed capacity, replay and source-admission integration at `0be3b9eb950a2a5a19261fd2f5d2f1fc2eb25b82`, tree `81ec2835ec0b1a7b87a55cbe7b061d8b4d948878`.** No blocking source issue was found in this bounded review. No repository source edits, downloads or target execution occurred.

## What is preserved

The merge has actual parents `3fee13616a80ecc65eb544e2feb0670f2f2f2df9` and fresh #303 `2b697222b34359bb46adc90aad69fd0a12708601`; the first parent descends from PW source `c662d00c151e89d9db419c8b40cd9b616e0a4124`. `structure-review.json` records the exact head/tree/parents, verified ancestry and clean source status.

| Contract | Result of independent review |
| --- | --- |
| Published v1 | Default and hard entry capacity remain 50,000; captured historical 5,000 budgets replay using their stored values |
| V2 source pages | Separate strict `InventoryPageLimits`; default/hard entry capacity 5,000; invalid wider budgets are refused even for a one-row source |
| Retained arrays/counts | Explicit 5,000 ceilings for entries, conflict witnesses, accepted, duplicate and conflict counts; scanned/matching/excluded/omitted counts retain the 100,000 record ceiling |
| Parent-derived limits | Only entry capacity changes, to `min(parent recorded max_entries, 5000)`; every other captured budget remains exact |
| Serialized identity | Same limits fields and field order, no extra serialized discriminator; prior v1/v2 body bytes and inventory/import/entry identities remain exact |
| Selection admission | Incoming source snapshot, index-build verification, final source/cancellation guard and guarded no-op revision check are preserved |
| Earlier PW safeguards | SQL-side 8,192-byte decision-body admission and v2 incomplete-scan refusal are preserved |

The narrow production changes implement that split in `inventory_contracts.py`, validate the v2 parser's incoming limits through the strict page model, and derive the effective page budget in `retain_inventory`. Both direct parsing and saved JSON validate the 5,000 v2 ceiling. The identity helper uses the separate page default. Existing v1 filename semantics remain explicitly frozen to the original eight suffixes, with `.tsp` confined to v2 classification; no identity rebinding was introduced.

## Independently executed checks

**44 focused tests passed:** 38 cases in the combined targeted gate and six additional independently authored one-row controls. The 38 cover the new 18 capacity/replay tests, seven incoming source-admission tests, four independent cancellation tests, six prior SQL decision storage/type bounds, the stored-record/list byte guard, workspace budget recheck, and incomplete-page selection refusal. JUnit reports 38 passes in 6.43 seconds. The six additional controls passed in 0.32 seconds.

The independent one-row controls use parent entry capacities 1, 2, 4,999, 5,000, 5,001 and 50,000. They verify exact preservation of all non-entry limits, source provenance, asserted support URL and parent record bytes; they confirm the 5,001 and 50,000 capacities become 5,000 for retained pages. Requesting a second page when the complete source has only one matching row is refused, leaving all existing rows, raw bytes and revision count unchanged. This is a tiny-record captured-budget check, not a 50,000-row performance experiment.

The merged 18-case gate separately exercises page two against 1/2/5,000/50,000 parent budgets with up to 5,001 authored rows, strict v2 rejection of over-wide budgets and corrupted saved page limits, exact replay/list/idempotence for four historical goldens, and schema count/array ceilings. The selection tests independently retain the same stale-source/cancellation behavior previously reproduced on c662 versus fresh 2b.

## Golden provenance independently regenerated

The original production writers were run again in their exact detached source checkouts, using only the tiny authored raw inputs and captured limits. All four generated record bodies match the frozen fixture byte for byte; verified raw replay also returns the same body. These operations do not merely trust the fixture's claimed source commit.

| Record | Original writer | Raw bytes | Record bytes | Exact record SHA-256 |
| --- | --- | ---: | ---: | --- |
| v1 captured 5,000 | 2b697222 | 76 | 2,421 | `b52423dc79c4ff30d7b8d4770499341d34c2a4120942f9d6dee9f6c52fa0a6f3` |
| v1 captured 50,000 | 2b697222 | 76 | 2,422 | `f30eb382536d88a5f4c5fb87007e6381b02dbc2665e6dc5f73458bd67f3e97e2` |
| v2 default page | c662d00c | 181 | 5,725 | `d99bb4ab9ce75aee3d165e125cb96148768d92caeb96abd17f76099731ca433d` |
| v2 lowered page two | c662d00c | 181 | 4,001 | `06bee065211bdb4dc31a7d9c8d121ed3d6dbc4911fc0ad3aa89846c0c6a4ea55` |

`regenerate-2b.json` and `regenerate-c662.json` retain the complete independently generated bodies and exact inventory/import/entry identifiers. Their per-operation receipts record commands, source commit/tree, clean status before/after, timeout, exit code and raw stdout/stderr hashes. The merged gate loads these historical bodies with and without raw verification, lists them, repeats the same import/retention request, and confirms no rewrite or extra revision.

## Merge and bounds analysis

AST comparisons, excluding line metadata, confirm that `_decisions`, `_eligible`, `_product_agrees`, `_entry` and `_hint` are unchanged from PW c662. `_source_snapshot`, `_require_sources`, `_scope`, `selected_hints` and `select` are unchanged from fresh 2b. Thus neither branch's substantive selection protections were displaced by conflict resolution.

The store's `_add`, `_read_record`, `_read_raw`, `_list`, `_budget`, `_verify` and `_write_raw` functions are unchanged from c662. The 16 MiB raw/decoded-source ceiling, 64 MiB serialized import ceiling, 100-record/64 MiB aggregate store listing admission, UI detail and selection limits were not enlarged. The unrelated `secondary/cli_import.py` delta removes a trailing blank line only; its complete AST is unchanged.

These byte limits constrain accepted data, not peak process RSS. Serialization still occurs before `_add`'s final serialized-byte test, and replay can hold decoded strings, JSON/model data and parser state together. This review makes no new memory guarantee and did not repeat a real 50,000-capacity population probe. The author is separately qualifying the saved real CSV through the final service/CLI; that result is not counted here. No native Windows or vulnerability-attribution acceptance is claimed.

## Reproduction

Use `/workspace/scratch/3a6632a6e5ff/venv/bin/python`, `PYTHONDONTWRITEBYTECODE=1`, `QT_QPA_PLATFORM=offscreen` and the exact checkout import paths from each receipt. The focused pytest receipt records all selected test nodes and the configuration/JUnit path; run it with a fresh output directory to preserve these sealed results. `test_review_parent_budget.py` and a byte-identical copy of `test_review_admission_cancel.py` are included. `regenerate_goldens.py` takes the retained fixture, exact original source commit and a fresh output JSON path. The original full repository tests/helpers are resolved through the recorded exact source checkout. No broad suite was repeated for this independent review.
