"""Regenerate tiny stored-record goldens using the original production writers."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import socket
import tempfile

from patchtrace.kbcorrelation.inventory_contracts import InventoryContext, InventoryLimits
from patchtrace.kbcorrelation import inventory_store as store
from patchtrace.kbcorrelation.store import WorkspaceStore


def run(fixture, head):
    def refused(*args, **kwargs):
        raise AssertionError('golden regeneration is offline')
    for name in ('socket', 'create_connection', 'getaddrinfo'):
        setattr(socket, name, refused)
    cases = json.loads(fixture.read_text())['records']
    results = []
    for case in cases:
        if case['source_commit'] != head:
            continue
        expected = json.loads(case['record_json'])
        parsed = expected['parsed']
        raw = case['raw_utf8'].encode()
        context = InventoryContext.model_validate(parsed['context'])
        limits = InventoryLimits.model_validate(parsed['limits'])
        with tempfile.TemporaryDirectory(prefix='pw-golden-regeneration-') as directory:
            with WorkspaceStore(Path(directory) / 'workspace') as ws:
                record, added = store.add_inventory(ws, raw, context,
                                                    now=expected['source']['retrieved_at'], limits=limits)
                assert added
                if parsed['parser_version'] == 2:
                    from patchtrace.kbcorrelation.inventory_contracts import InventoryRetention
                    policy = InventoryRetention.model_validate(parsed['retention'])
                    record, added = store.retain_inventory(ws, record.import_id, policy)
                    assert added
                body = record.model_dump_json()
                assert body == case['record_json']
                assert hashlib.sha256(body.encode()).hexdigest() == case['record_sha256']
                replay = store.get_inventory(ws, record.import_id, verify=True)
                assert replay.model_dump_json() == body
                results.append({'name': case['name'], 'source_commit': head,
                                'raw_bytes': len(raw), 'raw_sha256': hashlib.sha256(raw).hexdigest(),
                                'record_sha256': case['record_sha256'], 'record_bytes': len(body.encode()),
                                'exact_body_equal': True, 'import_id': record.import_id,
                                'inventory_id': record.parsed.inventory_id,
                                'entry_ids': [entry.entry_id for entry in record.parsed.entries],
                                'record_json': body})
    assert len(results) == 2
    return results


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--fixture', type=Path, required=True)
    parser.add_argument('--head', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    result = run(args.fixture, args.head)
    args.output.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps([{k: v for k, v in case.items() if k != 'record_json'} for case in result], indent=2))
