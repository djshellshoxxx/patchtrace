# PR 151 — terminal hosted evidence for 9c468bc7

Source head `9c468bc75077484c1780305d7cc927b30fd0bc8b`, tree `7841c1bea17657c0085015c429520d12a01c823b`; synthetic merge `b5fcd431a66f5841e13fbcc2d22483443f59736d` has the identical tree on accepted main `25c9795bd9cd58bfad855f30594ee3a0c7584cec`. Original metadata, child steps, check outputs and reviews are in `terminal-9c468bc7.json.gz`.

QA run `41416413045`, native PR `41416412926` and native push `41416407478` all completed successfully. Sonar and Snyk succeeded. CodeRabbit's check succeeded, but its exact-head review still reports the substantive post-link backup cleanup/history-trust finding. That finding is not settled by passing execution. Root has a separately reviewed storage repair; no result in this receipt qualifies its different source.

| Gate | Original job | Result |
| --- | --- | --- |
| Linux full + Ruff | 125181359519 | 18,482 passed, 47 skipped, 7 xfailed, 1 warning; 1766.16s. Ruff passed. |
| Windows full + Ruff | 125181359967 | 18,449 passed, 81 skipped, 6 xfailed, 1 warning; 2364.58s. Ruff passed. |
| Linux Qt 1/4 | 125181359870 | 10,100 passed; 2330.60s. |
| Linux Qt 2/4 | 125181359750 | 8,700 passed; 1664.39s. |
| Linux Qt 3/4 | 125181359840 | 9,640 passed; 1563.21s. |
| Linux Qt 4/4 | 125181359925 | 9,060 passed; 1419.80s. |
| Windows Qt | 125181359974 | 9,375 passed; 2282.26s. |
| Windows frozen/portable/installer | 125181359967 | All A1–A4, optional-dependency self-test, clean portable extraction/checksum, installer registration/runtime/self-test and non-destructive uninstall succeeded. |
| Linux package | 125210655386 | Build and upload succeeded. |
| Ubuntu 24.04 smoke | 125212813865 | Artifact digest and tar checksum verified; offscreen and xcb/Xvfb frozen self-tests succeeded, all optional dependencies present. |
| Ubuntu 22.04 smoke | 125212814031 | Same checksum and both frozen self-test modes succeeded. |
| Native acceptance | Both five-variant runs | Applicable offline-analysis, no-adjacent-PDB, raw-cache byte identity and plain-Ghidriff cached-PDB error reproduction steps succeeded. Conditional matrix skips are preserved in original metadata. |

Release/release-gate jobs were explicitly skipped in PR scope. All applicable Actions work on this head is terminal; no pending package/smoke job remains to preserve before a head change.

Both original JUnit artifacts were downloaded and their ZIP digests matched GitHub. Each has 18,536 child cases, no failures/errors: Linux 18,482 passed + 54 skip/xfail children; Windows 18,449 passed + 87 skip/xfail children. Five individual workflow tests in each leg skipped because `yaml` was absent (four `test_ci_summary` checks and `test_tier_r_shard::test_workflow_structure_and_pins`). This is preserved explicitly and is separate from the three-module/35-test collection gap discovered on combined PR 152. The reviewed central PyYAML dev-extra addition is outside this source head.

The package ZIP artifacts and each inner package were independently downloaded and hashed. No package binaries are included in this compact archive.

| Package | Bytes | Computed SHA-256, matching shipped checksum |
| --- | ---: | --- |
| `PatchTrace-0.1.0-windows-x64.zip` | 65,569,808 | `1c792a989bc5cc248a52d49c1026f856e04abcb6407b71974a52f2eb9dcb4177` |
| `PatchTrace-Windows-x64-Setup.exe` | 64,393,080 | `d620cfd8fb88e5bad16997ab6f632a4eb9c8cf6642855afdc283e817d45c0654` |
| `PatchTrace-0.1.0-linux-x86_64.tar.gz` | 94,401,184 | `1a6cb9ba02708338a57d81bd1b24decdf67a612c92a4b6c0eea82cb2f6925a6d` |

Outer Windows artifact `13131427661` is 129,311,981 bytes, SHA-256 `bfbb1e8afe1f9726ecbce5320abaaa7558dbd9da0688f29c1fe97346adf2b81a`. Outer Linux artifact `13131448877` is 93,811,495 bytes, SHA-256 `25824ccf0dceb29b206ddd4c26c8a91e45e744b554fa7e4ddb321d7878e6ae38`. Detailed artifact/JUnit receipts include exact member names and recomputed hashes.

Read-only audit only: no source changes, test reruns, workflow dispatches, approvals, merges, scanner suppressions or review-thread mutations.
