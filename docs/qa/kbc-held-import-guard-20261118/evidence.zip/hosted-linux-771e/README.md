# Actual Linux full QA at published source 771e

Hosted run **44409973351**, Linux job **135175350876**, finished at
2026-11-18 22:52:53 UTC with failure. The job checks out merge preview
`ac6632ad6de486ba16343f0eeb4a2b5a446e4ac1`; its tree equals published head
`771e5a775f5bf60a8d9094232b51dcdbb47d6389`, tree
`ddf151c6ff8fb3f70b74378525fe1d8d5c9050e3`, over main
`9c411ca3d7b47f950be5f0c6f01b3c54184554c6`. Original commit API deliveries,
the exact decoded log, artifact metadata and ZIP are retained.

The actual full command is `python -m pytest -q --junitxml=qa-results.xml`.
It reports **25,292 passed, 3 failed, 60 skipped, 3 xfailed, 21 warnings in
1893.98 seconds**. JUnit has 25,358 cases, three failures, zero errors and 63
skipped elements (which include the three expected failures). All three failures
are the architecture-import guard in `test_kbc_contracts.py`, rejecting the
already reviewed shared `input_readers` declarations in `service.py`, `store.py`
and `wiring.py`. The original failed result is not rewritten or called a pass.

The preceding immutable-publication selection reports **134 passed, 3 skipped**.
The normal Ruff step was skipped after the full pytest failure. Windows-only
steps are naturally inapplicable to this Linux matrix leg; they provide no
Windows packaging acceptance. At this separate refresh, five other QA/Qt jobs
are still running. The skipped release gate and pending jobs remain unverified.

Artifact **14477819807** is 434,680 bytes, SHA-256
`552ba012c89e46013ff4c6d6094db93f0662b8c67cac0c9716b9aabd66df531f`.
All three members pass ZIP CRC, size/hash and retained-text byte equality. The
log is 96,006 characters and retained exactly. Eleven source snapshots match
the canonical tree. The transfer receipt stores no signed download URL. No
artifact member or target binary was executed during this read-only inspection.

The dedicated held-input specification and module index already describe these
neutral shared reader types. A narrowly defined per-file/symbol guard correction
is being qualified separately with original failure retention and new forbidden
import controls. It changes no product behavior, source capability or release
requirement. That later local correction does not retroactively qualify this
failed hosted job, nor does this old-source run qualify newer core changes.
