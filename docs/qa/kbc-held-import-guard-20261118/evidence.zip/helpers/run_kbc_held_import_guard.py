"""Pin the reviewed architecture-guard scope and retain genuine red/green receipts."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
PHASE, SOURCE = sys.argv[1:]
assert PHASE in {'spec-red', 'guard-green', 'affected-green'}
assert re.fullmatch('[a-f0-9]{40}', SOURCE)
OUT = ROOT / 'qa/kbc-held-import-guard' / PHASE
NODES = ['tests/test_kbc_contracts.py']
if PHASE == 'affected-green':
    NODES += ['tests/test_kbc_held_input_admission.py', 'tests/test_kbc_held_inspection_prefix.py',
              'tests/test_input_readers.py', 'tests/test_spec_registry.py']


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(name, payload):
    with (OUT / name).open('x') as f:
        json.dump(payload, f, indent=2)
        f.write('\n')


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE and not git('status', '--porcelain')
OUT.mkdir(parents=True, exist_ok=False)
selected = [dict(path=p, sha256=sha(REPO / p)) for p in NODES]
owned_paths = ['src/patchtrace/input_readers.py', 'src/patchtrace/kbcorrelation/service.py',
    'src/patchtrace/kbcorrelation/store.py', 'src/patchtrace/kbcorrelation/wiring.py',
    'tools/generate_kbc_schemas.py', 'docs/specs/kb-held-inputs.md', *NODES]
owners = [dict(path=p, sha256=sha(REPO / p)) for p in owned_paths]
for row in owners:
    assert (REPO / row['path']).read_bytes() == git('show', SOURCE + ':' + row['path'])
owned = Path(tempfile.mkdtemp(prefix='patchtrace-kbc-held-import-' + PHASE + '-'))
assert not any((p / '.git').exists() for p in (owned, *owned.parents))
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', QT_QPA_PLATFORM='offscreen',
    PYTHONPATH=os.pathsep.join(map(str, [REPO / 'src', REPO / 'tests', REPO, ROOT / 'ops'])),
    GIT_ALLOW_PROTOCOL='file', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null', GIT_TERMINAL_PROMPT='0',
    PATCHTRACE_BATCH_COLLECTION_RECEIPT=str(OUT / 'imports.json'),
    PATCHTRACE_OFFLINE_GUARD_RECEIPT=str(OUT / 'offline-guard.json'))
argv = [sys.executable, str(ROOT / 'ops/continuation_offline_pytest.py'), '-q', '-ra',
    '-p', 'no:cacheprovider', '-p', 'project_and_tools_receipt', *NODES,
    '--basetemp=' + str(owned / 'pytest'), '--junitxml=' + str(OUT / 'result.xml')]
write('command.json', dict(source=SOURCE, tree=git('rev-parse', 'HEAD^{tree}').decode().strip(),
    argv=argv, cwd=str(REPO), pythonpath=env['PYTHONPATH'], selected_files=selected,
    reviewed_owner_files=owners, owned_temp=str(owned), timeout=120,
    started_utc=datetime.now(timezone.utc).isoformat(), helper_sha256=sha(__file__),
    qualification='Reviewed architecture/schema/held-input offline controls only; no native execution or full-suite claim.'))
start = time.monotonic()
with (OUT / 'result.log').open('x') as f:
    result = subprocess.run(argv, cwd=REPO, env=env, stdout=f, stderr=subprocess.STDOUT, timeout=120)
imports = json.loads((OUT / 'imports.json').read_text())
drift = []
for name, row in imports['final_sources'].items():
    path = Path(row['path'])
    if not path.is_relative_to(REPO) or not (path.is_relative_to(REPO / 'src') or path.is_relative_to(REPO / 'tools')):
        drift.append(name)
        continue
    raw = git('show', SOURCE + ':' + path.relative_to(REPO).as_posix())
    if path.read_bytes() != raw or hashlib.sha256(raw).hexdigest() != row['sha256']:
        drift.append(name)
cases = list(ET.parse(OUT / 'result.xml').getroot().iter('testcase'))
counts = dict(tests=len(cases), failures=sum(c.find('failure') is not None for c in cases),
    errors=sum(c.find('error') is not None for c in cases), skipped=sum(c.find('skipped') is not None for c in cases))
status = git('status', '--porcelain').decode()
valid = not status and git('rev-parse', 'HEAD').decode().strip() == SOURCE and not drift
unchanged = all(sha(REPO / r['path']) == r['sha256'] for r in owners)
removed = False
if result.returncode == 0 and valid and unchanged:
    shutil.rmtree(owned)
    removed = True
receipt = dict(source=SOURCE, exit=result.returncode, elapsed=time.monotonic() - start,
    junit=counts, verified_imports=len(imports['final_sources']), drift=drift,
    owner_and_test_files_unchanged=unchanged, status_after=status,
    owned_temp=str(owned), temp_removed=removed)
write('exit.json', receipt)
print(json.dumps(receipt))
print('\n'.join((OUT / 'result.log').read_text().splitlines()[-20:]))
assert valid and unchanged and counts['errors'] == counts['skipped'] == 0
assert result.returncode == (1 if PHASE == 'spec-red' else 0)
assert counts['failures'] == (13 if PHASE == 'spec-red' else 0)
