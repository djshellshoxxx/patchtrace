"""Seal the independently reviewed guard correction with immutable hosted evidence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
Q = ROOT / 'qa/kbc-held-import-guard'
SOURCE = '52a562b6f4c8063b7cb47b31c3942f55db7fa5f5'
BASE = 'c1685bca780de6702d8c3d1932136f75f760de35'
DEST = REPO / 'docs/qa/kbc-held-import-guard-20261118'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE and not git('status', '--porcelain')
assert set(git('diff', '--name-only', BASE, SOURCE).decode().splitlines()) == {
    'docs/specs/kb-held-inputs.md', 'tests/test_kbc_contracts.py'}
red = json.loads((Q / 'spec-red/exit.json').read_text())
green = json.loads((Q / 'guard-green/exit.json').read_text())
assert red['exit'] == 1 and red['junit'] == dict(tests=247, failures=13, errors=0, skipped=0)
assert green['exit'] == 0 and green['junit'] == dict(tests=247, failures=0, errors=0, skipped=0)
assert all(r['verified_imports'] == 39 and r['drift'] == [] and r['owner_and_test_files_unchanged'] for r in [red, green])
assert json.loads((Q / 'normal-ruff.json').read_text())['exit'] == 0
s = json.loads((Q / 'strict-sites-comparison.json').read_text())
assert s['exit'] == 1 and s['findings'] == 80 and s['same_path_code_selected_statement_multiset']
peer = ROOT / 'qa/kbc-held-import-guard-independent'
replay = json.loads((peer / 'replay-exit.json').read_text())
assert replay['source'] == SOURCE and replay['exit'] == 0 and replay['canonical_imports'] == 39
assert replay['counts'] == dict(tests=247, failures=0, errors=0, skips=0)
assert replay['offline']['network_audit_event_counts'] == {} and replay['offline']['process_audit_count'] == 0
assert sha((peer / 'evidence.zip').read_bytes()) == '0ab44532768cd98298aacefae49f230d3bdbbe046adf6102ef1c66d63aaf5d16'
hosted = ROOT / 'qa/hosted-pr316-771e-linux-qa'
assert sha((hosted / 'evidence.zip').read_bytes()) == '93b944ed2ead20101357a01062ce2f0dc05f735f785e5957e69117e43c39d9b9'
payloads = {}
for p in sorted(Q.rglob('*')):
    if p.is_file() and '__pycache__' not in p.parts:
        payloads['author/' + p.relative_to(Q).as_posix()] = p.read_bytes()
for label, directory, names in [
    ('independent', peer, ['review.md', 'review.json', 'manifest.json', 'evidence.zip']),
    ('hosted-linux-771e', hosted, ['README.md', 'findings.json', 'manifest.json', 'seal.json', 'evidence.zip']),
]:
    for name in names:
        payloads[label + '/' + name] = (directory / name).read_bytes()
for name in ['run_kbc_held_import_guard.py', 'scan_kbc_held_import_guard.py',
             'continuation_offline_pytest.py', 'project_and_tools_receipt.py', 'seal_kbc_held_import_guard.py']:
    payloads['helpers/' + name] = (ROOT / 'ops' / name).read_bytes()
payloads['helpers/offline_replay.py'] = (ROOT / 'qa/full-batch-path-recheck/offline_replay.py').read_bytes()
payloads['comparison/prior-strict.stdout'] = (ROOT / 'qa/kb-native-followup-integration-v2/ruff-strict.stdout').read_bytes()
payloads['source/patch.diff'] = git('diff', BASE, SOURCE)
payloads['source/history.txt'] = git('log', '--reverse', '--format=fuller', BASE + '..' + SOURCE)
for path in ['docs/specs/kb-held-inputs.md', 'tests/test_kbc_contracts.py', 'src/patchtrace/input_readers.py',
             'src/patchtrace/kbcorrelation/service.py', 'src/patchtrace/kbcorrelation/store.py',
             'src/patchtrace/kbcorrelation/wiring.py']:
    payloads['source/' + path] = git('show', SOURCE + ':' + path)
DEST.mkdir(exist_ok=False)
with zipfile.ZipFile(DEST / 'evidence.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path, raw in sorted(payloads.items()):
        z.writestr(path, raw)
with zipfile.ZipFile(DEST / 'evidence.zip') as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == len(payloads)
    for path, raw in payloads.items():
        assert z.read(path) == raw
archive = (DEST / 'evidence.zip').read_bytes()
manifest = dict(source=SOURCE, base=BASE, tree=git('rev-parse', 'HEAD^{tree}').decode().strip(),
    archive_bytes=len(archive), archive_sha256=sha(archive), sealed_utc=datetime.now(timezone.utc).isoformat(),
    payloads=[dict(path=p, bytes=len(b), sha256=sha(b)) for p, b in sorted(payloads.items())])
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(DEST / 'README.md').write_text((Q / 'checkpoint-note.md').read_text() +
    f'\n## Archive integrity\n\n{len(payloads)} payloads; {len(archive):,} bytes. SHA-256 `{sha(archive)}`.\n')
note = '''

## Exact held-reader import guard and full Linux result — 2026-11-18

The preceding published771e Linux full run has25,292 passes,3 failures,60 skips,
3 expected failures and21 warnings. Its three failures are stale static import
guards for the already reviewed shared reader types in KB service/store/wiring.
The original failed hosted result, API ownership, exact log and artifact remain
immutable; newer candidate acceptance cannot reuse it as a pass.

Guard52a562b6 follows spec/regressions5cdf1732: thirteen original failures,
234 positives, then247 passes with zero skips. Independent replay also passes
all247 with39 canonical imports and no child/network events. Seven exact
file/symbol exceptions preserve all previous import restrictions. All45 original
functions,67 new controls and the prior guard AST are independently checked for
preservation. Runtime/tools/workflows/configuration are unchanged. Full normal
Ruff passes; strict S still fails on80 unchanged sites. No waiver or suppression.

[Complete correction and retained evidence](qa/kbc-held-import-guard-20261118/README.md).
Five Windows/Qt jobs remain incomplete at the separate snapshot. Main merge,
native/package/security and final beta acceptance remain blocked. No release.
'''
for path, link_prefix in [('docs/qa.md', 'qa/'),
    ('docs/plans/autonomous-consolidation-20261118/consolidation-ledger.md', '../../qa/'),
    ('docs/plans/patchtrace-completion-matrix.md', '../qa/')]:
    with (REPO / path).open('a') as f:
        f.write(note.replace('(qa/', '(' + link_prefix))
with (REPO / 'tasks/todo.md').open('a') as f:
    f.write('''

### Shared-reader architecture guard — 2026-11-18

- [x] Retain the exact771e Linux full-QA failure and original artifact/log/source evidence.
- [x] Specify seven exact file/symbol permissions, preserve13-red/234-positive baseline and all prior assertions, and pass247 cases independently.
- [x] Preserve normal lint success and strict80-site failure without suppression or waiver.
- [ ] Publish the reviewed candidate append-only and require a new exact-head full/platform gate; do not relabel the historical hosted failure.
''')
print(json.dumps(dict(source=SOURCE, payloads=len(payloads), archive_bytes=len(archive), archive_sha256=sha(archive))))
