"""Replay retained authored native records; never execute tools or score a case."""
from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from pathlib import Path


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repository", type=Path, required=True)
    ap.add_argument("--expected-sha", required=True)
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    repo = args.repository.resolve()
    root = Path("/workspace/scratch/e83fbf4505c3")
    def git(*argv: str) -> str:
        return subprocess.check_output(["git", *argv], cwd=repo, text=True).strip()
    assert git("rev-parse", "HEAD") == args.expected_sha
    assert git("status", "--porcelain=v1") == ""
    source_paths = [repo / "tools/research_qualification/adapters/rizin.py",
                    repo / "tools/research_qualification/adapters/_common.py"]
    before_sources = {str(p.relative_to(repo)): sha(p) for p in source_paths}
    pilot = root / "l2-native-pilot/20261118T082742Z-http-parser"
    preserved = {n: sha(pilot / n) for n in ("pilot-plan.json", "pilot-result.json")}
    assert preserved == {
        "pilot-plan.json": "d6a2dc2b5a1dc59304fc2a8279b6c186537be267448cf9bd0d700e6617e6dbef",
        "pilot-result.json": "6d95d0b857d2a2cdb61ceecf6a69d05133dd852677aa6889b10fbd4544de339e",
    }
    sys.path.insert(0, str(repo))
    from tools.research_qualification.adapters import rizin
    records = []
    for variant in ("archive", "unmodified", "patched"):
        for fixture in ("shared", "executable", "authored-pe"):
            path = root / "l2-rizin-discovery-patch-20261118/raw" / f"{variant}-{fixture}.stdout"
            data = path.read_bytes()
            digest = hashlib.sha256(data).hexdigest()
            document = json.loads(data)
            record = {"variant": variant, "fixture": fixture, "source": str(path),
                      "bytes": len(data), "sha256": digest, "raw_rows": len(document),
                      "distinct_older_addresses": len({r["original"]["addr"] for r in document if r["original"] is not None}),
                      "distinct_newer_addresses": len({r["modified"]["addr"] for r in document if r["modified"] is not None})}
            try:
                names = rizin.parse(data)
            except ValueError as exc:
                record.update(adapter="refused", reason=str(exc))
            else:
                record.update(adapter="accepted", ranked_names=names)
            assert sha(path) == digest
            records.append(record)
    assert {str(p.relative_to(repo)): sha(p) for p in source_paths} == before_sources
    assert {n: sha(pilot / n) for n in preserved} == preserved
    assert git("rev-parse", "HEAD") == args.expected_sha
    assert git("status", "--porcelain=v1") == ""
    result = {"scope": "Retained authored native-output parsing only; no native execution, oracle or case scoring.",
              "source_sha": args.expected_sha, "tree_sha": git("rev-parse", "HEAD^{tree}"),
              "source_file_sha256": before_sources, "argv": sys.argv, "python": sys.executable,
              "records": records, "frozen_pilot_unchanged": preserved}
    with args.output.open("x", encoding="utf-8") as output:
        json.dump(result, output, indent=2, sort_keys=True)
        output.write("\n")
    print(json.dumps({"source_sha": args.expected_sha, "records": [
        {k:r[k] for k in ("variant", "fixture", "raw_rows", "adapter")}
        for r in records], "source_and_raw_unchanged": True, "pilot_unchanged": True}))


if __name__ == "__main__":
    main()
