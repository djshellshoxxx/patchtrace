"""Export immutable local commit objects for reviewed, guarded GitHub REST publication.

This helper reads Git only. It makes no network request and never updates a ref.
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import json
import re
import subprocess
from pathlib import Path


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--repository", type=Path, required=True)
    ap.add_argument("--base", required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("commits", nargs="+")
    args = ap.parse_args()
    for identity in [args.base, *args.commits]:
        if re.fullmatch(r"[0-9a-f]{40}", identity) is None:
            raise SystemExit("Only exact commit SHAs are accepted")
    repo = args.repository.resolve()
    def git(*argv: str) -> bytes:
        return subprocess.check_output(["git", *argv], cwd=repo)
    args.output.mkdir(parents=True, exist_ok=True)
    plans = []
    previous = args.base
    for index, commit in enumerate(args.commits, 1):
        parents = git("show", "-s", "--format=%P", commit).decode().strip().split()
        if parents != [previous]:
            raise SystemExit(f"Unexpected parent chain at {commit}: {parents}")
        tree = git("rev-parse", f"{commit}^{{tree}}").decode().strip()
        base_tree = git("rev-parse", f"{previous}^{{tree}}").decode().strip()
        message = git("show", "-s", "--format=%B", commit).decode().rstrip("\n")
        if "[no release]" not in message:
            raise SystemExit(f"Missing no-release message marker in {commit}")
        paths = git("diff", "--name-only", "-z", previous, commit).split(b"\0")
        elements, blobs = [], []
        for raw in paths:
            if not raw:
                continue
            path = raw.decode("utf-8", errors="strict")
            entry = git("ls-tree", "-z", commit, "--", path)
            if not entry:
                elements.append({"path": path, "sha": None})
                continue
            fields, reported_path = entry.rstrip(b"\0").split(b"\t", 1)
            mode, kind, oid = fields.decode().split()
            assert reported_path == raw
            if kind != "blob" or mode not in {"100644", "100755"}:
                raise SystemExit(f"Unexpected file kind/mode: {path}")
            body = git("cat-file", "blob", oid)
            actual = hashlib.sha1(f"blob {len(body)}\0".encode() + body).hexdigest()
            assert actual == oid
            encoded = base64.b64encode(body).decode("ascii")
            blob_path = args.output / f"{oid}.base64"
            if blob_path.exists():
                assert blob_path.read_text() == encoded
            else:
                blob_path.write_text(encoded)
            elements.append({"path": path, "mode": mode, "type": kind, "sha": oid})
            blobs.append({"path": path, "sha": oid, "bytes": len(body),
                          "base64_chars": len(encoded), "base64_path": str(blob_path.resolve())})
        plan = {"local": commit, "parents": parents, "tree": tree, "base_tree": base_tree,
                "message": message, "elements": elements, "blobs": blobs}
        plan_path = args.output / f"{index:02d}-{commit[:8]}.json"
        if plan_path.exists():
            raise SystemExit(f"Plan already exists: {plan_path}")
        plan_path.write_text(json.dumps(plan, indent=2, sort_keys=True) + "\n")
        plans.append({"plan_path": str(plan_path.resolve()), "local": commit, "tree": tree,
                      "files": len(elements), "bytes": sum(b["bytes"] for b in blobs)})
        previous = commit
    print(json.dumps(plans))


if __name__ == "__main__":
    main()
