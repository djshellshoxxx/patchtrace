from pathlib import Path
import json
import os
import subprocess

root=Path('/workspace/scratch/c7a9e8d98848/semantic-disposition')
qa=Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch1')
files='''test_gui_creation_retry test_audit116_create_rollback test_export_destination_guard
 test_kb_investigation_service test_ui_kb_entry test_ui_kb_investigation test_kbc_msrc_review_findings
 test_kbc_card_field_provenance test_kbc_saved_scope test_kbc_components test_kbc_pairs_index
 test_kbc_resolver test_kbc_resolver_architecture test_ui test_gui_core_anchors test_files_announcements
 test_ui_export_accessibility test_tooltips test_acquisition_cli test_acquisition_delta
 test_acquisition_quarantine test_acquisition_transport test_acquisition_winbindex test_ui_acquisition
 test_profiles test_ui_profiles test_raw_cache test_enrichment_core test_enrichment_cve test_enrichment_intelligence
 test_nway_graph test_nway_series test_cli_secondary test_secondary_reconcile test_secondary_bindiff
 test_secondary_binexport test_secondary_rzdiff test_backend_symbol_local test_diaphora_import
 test_diaphora_cli test_symbols_staging test_ui_symbol_local test_ptlaunch test_backend_cli
 test_search_pilot_buildenv_bugfixes_20261111 test_audit_ai_reports test_audit_core test_audit_desktop
 test_audit_enrichment test_audit_runtime'''.split()
paths=[f'tests/{name}.py' for name in files]
missing=[path for path in paths if not (root/path).is_file()]
assert not missing,missing
source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()
assert source=='ac789497597fba3cb87696990d171a7a27024fca'
env={**os.environ,'QT_QPA_PLATFORM':'offscreen','PYTHONPATH':f'{root}/src:{root}/tests'}
args=['/workspace/scratch/3a6632a6e5ff/venv/bin/python','-m','pytest','-q',*paths,
      f'--junitxml={qa}/current-affected.xml','--tb=short']
receipt={'source':source,'cwd':str(root),'args':args,'env':{key:env[key] for key in ('QT_QPA_PLATFORM','PYTHONPATH')}}
with (qa/'current-affected.log').open('w') as log:
    receipt['exit_code']=subprocess.run(args,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
(qa/'current-command.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('exit',receipt['exit_code'])
raise SystemExit(receipt['exit_code'])
