from pathlib import Path
import json, subprocess, os
p=Path(__file__).resolve().parent;w=Path('/workspace/scratch/c7a9e8d98848/semantic-disposition');h=p/'historical-controls'
items={'test_callgraph_cap_truth.py':['test_actual_cycle_hub_is_partial_in_view_paired_json_and_dot','test_actual_cli_export_and_neighbours_return_partial_for_cycle_hub','test_duplicate_claims_and_shared_neighbours_below_cap_remain_complete','test_duplicate_focus_ids_do_not_hide_a_distinct_root_or_claim_truncation'], 'test_callgraph_path_budget.py':['test_actual_normalized_hub_query_stops_at_shared_budget_and_retains_found_path','test_existing_csr_is_used_without_a_global_edge_scan','test_cancel_at_start_reads_no_edges','test_shortest_first_tie_order_and_five_path_limit_are_stable_under_edge_permutations']}
a=['/workspace/scratch/3a6632a6e5ff/venv/bin/python','-m','pytest','-q',*[str(h/file)+'::'+name for file,names in items.items() for name in names],'--junitxml='+str(p/'callgraph-red.xml'),'--tb=short']
e=os.environ.copy();e.update(QT_QPA_PLATFORM='offscreen',PYTHONPATH=str(w/'src')+':'+str(w/'tests'))
with (p/'callgraph-red.log').open('w') as f:r=subprocess.run(a,cwd=w,env=e,stdout=f,stderr=subprocess.STDOUT)
(p/'callgraph-command.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'cwd':str(w),'args':a,'env':{k:e[k] for k in ('QT_QPA_PLATFORM','PYTHONPATH')},'exit_code':r.returncode},indent=2)+'\n')
print('exit',r.returncode)
raise SystemExit(r.returncode)
