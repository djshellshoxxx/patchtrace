"""Independent current-source probe from the historical strict incomplete-creation validator."""
import sqlite3

import pytest

from patchtrace.persistence import ProjectStore
from patchtrace.sample import synthetic_pe
from patchtrace.service import ProjectService


def incomplete(tmp_path):
    root = tmp_path / 'incomplete'
    ProjectStore(root, create=True).close()
    pair = tmp_path / 'older.dll', tmp_path / 'newer.dll'
    for index, path in enumerate(pair):
        path.write_bytes(synthetic_pe(index))
    return root, pair


@pytest.mark.parametrize('extra', ['view', 'trigger', 'column'])
def test_incomplete_creation_must_preserve_foreign_schema(tmp_path, extra):
    root, pair = incomplete(tmp_path)
    path = root / 'project.sqlite3'
    with sqlite3.connect(path) as db:
        statement = {
            'view': 'CREATE VIEW operator_notes AS SELECT 1 AS retained_note',
            'trigger': 'CREATE TRIGGER operator_note AFTER INSERT ON history BEGIN SELECT 1; END',
            'column': 'ALTER TABLE history ADD COLUMN operator_note TEXT',
        }[extra]
        db.execute(statement)
    before = path.read_bytes()
    with pytest.raises(ValueError):
        with ProjectService.create(*pair, 'must refuse foreign schema', root):
            pass
    assert path.read_bytes() == before


def test_plain_current_incomplete_creation_can_still_be_reused(tmp_path):
    root, pair = incomplete(tmp_path)
    with ProjectService.create(*pair, 'current incomplete control', root) as service:
        assert len(service.project.artifacts) == 2
