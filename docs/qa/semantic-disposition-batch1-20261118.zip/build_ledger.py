"""Build the read-only batch receipt from captured Git and pytest evidence."""
from __future__ import annotations

import collections
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition')
QA = Path(__file__).resolve().parent
BASE = 'ac789497597fba3cb87696990d171a7a27024fca'
OUT = ROOT / 'docs/plans/autonomous-consolidation-20261118'


def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def names(*values: str) -> list[str]:
    return ['tests/' + value + '.py' for value in values]


def row(scope, finding, proof, tests, recommendation, remaining, *, candidates=(), origins=(), partial=False):
    return dict(assessed_scope=scope, semantic_finding=finding, current_replacement_proof=proof,
                current_tests=tests, recommendation=recommendation, remaining_qualification=remaining,
                candidate_ids=list(candidates), replacement_commits=list(origins),
                disposition='partial_with_selective_candidates' if partial else 'scoped_behavior_retained',
                whole_branch_resolved=False)


details = {
 'codex/autonomous-checkpoint-20261102-0945': row(
    'Project-safe export/adoption, owner-thread KB panel loading, frozen KB journey, creation staging, '
    'and bounded callgraph exploration in the broad checkpoint.',
    'The export/adoption and KB snapshot behavior has current replacements. The checkpoint retains useful '
    'callgraph cap-truth and path-work fixes absent from the comparison baseline. Its private creation helper '
    'and full synthetic F8 self-test are absent as named paths; the creation strategy and packaged journey '
    'are not equivalent to current rollback and sample-only self-test. Research/native residue is still partial.',
    ['gui/qt/project_adoption.py is byte-identical; reports._check_destination and '
     'ProjectService.export_report have equal ASTs.',
     'Historical adapters/panel_snapshot.py is replaced by cli_leads.read_snapshot, KbSnapshot, '
     'SnapshotRows/SnapshotEngine and leads_from_snapshot; panel_qt reads on the owner thread, then computes on a worker.',
     'Historical callgraph/algo.py, query.py and paths.py are byte-identical across both selected checkpoints '
     'and #159, but differ from current. Extracted historical controls reproduce the missing behavior.',
     'raw_alignment_view.py and representations/alignment.py are byte-identical. Desktop raw wiring is '
     'separately accepted at raw-integration e6f9ea3fafa400d5585a2db17131efcac8791bcd.'],
    names('test_export_destination_guard','test_gui_creation_retry','test_audit116_create_rollback',
          'test_kb_investigation_service','test_ui_kb_investigation','test_gui_project_adoption',
          'test_kbc_snapshot','test_ui_kb_panel'),
    'Selectively recover C2/C3 after independent review. Evaluate C4/C5 separately. Preserve the checkpoint '
    'and the unreviewed native/unified research deltas; no whole-branch merge.',
    ['Unified proof, calibration, CFG/literal matching and native engine differences were inventoried but '
     'not exhaustively semantically qualified in this batch.',
     'No current packaged F8 journey or native/Windows acceptance is claimed.'],
    candidates=('C2','C3','C4','C5'), partial=True),
 'codex/autonomous-checkpoint-20261102-1020': row(
    'The previous checkpoint plus bounded, identity-aware incomplete-creation retry and its desktop adapter.',
    'project_retry._database checks exact schema, limits and cancellation. Current '
    'persistence._abandoned_creation accepts a snapshot-less database with a foreign view, trigger or '
    'extra column and deletes/replaces it. Three real SQLite probes fail; ordinary empty-schema retry passes. '
    'The shared callgraph omissions from the earlier checkpoint also remain.',
    ['project_retry.py is absent from current; its blob is identical to #159. '
     'project_creation.py is identical in all three selected broad tips.',
     'Current ProjectService.create has rollback and exclusive-publication repairs. It does not implement '
     'the historical explicit bounded partial-artifact retry workflow, so the old helper is not a safe wholesale port.',
     'Current KB owner-thread snapshot and project adoption replacements are exercised by the two passing gates.'],
    names('test_gui_creation_retry','test_audit116_create_rollback','test_export_destination_guard',
          'test_gui_project_adoption','test_kbc_snapshot','test_ui_kb_panel'),
    'Prioritize C1 strict refusal while preserving healthy incomplete retry. Recover C2/C3 separately; '
    'retain C4/C5 and research residue as open scope.',
    ['Foreign schema refusal is confirmed missing; full bounded retry UX, filesystem identity/publication '
     'semantics and Windows behavior need a separately owned design/review.',
     'No blanket conclusion about the other 515 changed paths.'],
    candidates=('C1','C2','C3','C4','C5'), partial=True),
 'codex/essential-project-safety-20261031': row(
    'PR #148 project-safe legacy export, explicit offline KB investigation/pair preview, and transactional GUI adoption.',
    'The focal safety and offline investigation behavior is retained. Current investigation adds online/current-project '
    'and candidate-index journeys; these are later extensions, not a reason to restore the older whole file.',
    ['gui/qt/project_adoption.py is byte-identical. reports._check_destination and '
     'ProjectService.export_report are AST-identical to this tip.',
     'test_export_destination_guard.py and test_kb_investigation_service.py are byte-identical.',
     'Historical test_ui_kb_entry.py is no longer present. Current host adoption plus '
     'test_gui_project_adoption.py and the real dialog journey provide explicit replacement evidence.'],
    names('test_export_destination_guard','test_kb_investigation_service','test_ui_kb_investigation',
          'test_kb_candidate_journey_20261105','test_gui_project_adoption'),
    'No selective product port for the assessed #148 behavior. Keep later investigation features and '
    'current publication helpers. Preserve historical receipts without treating them as current approval.',
    ['The original full-suite/native/package claims are historical. Current evidence here is offline and offscreen.',
     'The exact missing entry test was inspected, but not asserted to be byte-equivalent to all replacement tests.']),
 'codex/msrc-mixed-format-revision-20261102': row(
    'PR #158 native/synthetic ambiguous MSRC revision conflict handling.',
    'The mixed-format quarantine is retained and further scoped by active tracking groups and release month. '
    'Current comparison checks all active relevant documents once a native ambiguous group exists, so a '
    'synthetic snapshot cannot conceal disagreement or missing applicability fields.',
    ['ReverseIndex.lookup has the mixed-format comparison with improved revision/group ordering.',
     'Ancestor d99cd7712b76e9e42661ef0b268417d7ca322d3e incorporates synthetic revisions in conflicts.',
     'Current tests explicitly cover native+synthetic disagreement, missing fields, agreement/reload, '
     'and isolation from a different release month.'],
    names('test_kbc_msrc_review_findings','test_kbc_card_field_provenance'),
    'No port for the narrow conflict behavior; do not replace the newer index with the older implementation.',
    ['Live Microsoft format compatibility and upstream freshness are not inferred from synthetic fixtures.'],
    origins=('d99cd7712b76e9e42661ef0b268417d7ca322d3e',)),
 'codex/msrc-reconcile-integration-20261102': row(
    'PR #159 card field provenance and saved investigation scope, plus inherited broad checkpoint source.',
    'Current field provenance and document-scoped lookups retain the focal MSRC/saved-scope behavior. '
    'Inherited project-retry and callgraph fixes are still missing; the three broad tips are one overlapping '
    'repair lineage, not three independent findings.',
    ['test_kbc_card_field_provenance.py and test_kbc_scope_retained.py exercise the current contract.',
     'project_retry.py, project_creation.py, callgraph/algo.py, query.py, paths.py and the two historical '
     'callgraph regression files match the 1020 checkpoint blobs.',
     'The current KB snapshot seam provides the former adapter behavior without reopening the held project.'],
    names('test_kbc_card_field_provenance','test_kbc_scope_retained','test_kbc_msrc_review_findings',
          'test_kbc_snapshot','test_ui_kb_panel'),
    'No port for focal MSRC provenance/scope. Carry C1-C5 by their shared lineage; keep unreviewed '
    'native/unified/calibration residue explicit.',
    ['The 481-path historical branch is only partially semantically disposed. Branch name and card tests '
     'do not prove all inherited behavior equivalent.'],
    candidates=('C1','C2','C3','C4','C5'), partial=True),
 'codex/kb-explicit-filename-selection-20261104': row(
    'PR #190 an explicit analyst filename surviving a conflicting advisory-title mention and candidate cap.',
    'Selectable tiers outrank contextual D; an explicitly selected title collision remains tier E with '
    'both reasons and unknown changed-in-KB status. Current inventory/TSP extensions preserve this rule.',
    ['The single source commit is patch-equivalent. Ancestor '
     '1dfd535d3ef9467091cee7daf05aecc53ecf108b applies the fix.',
     'test_kbc_components.py is byte-identical; the existing pairs-index reopen control covers persisted selection.'],
    names('test_kbc_components','test_kbc_pairs_index'),
    'No selective port for this behavior.',
    ['No claim that a selected filename proves applicability or that current inventory extensions were '
     'qualified by this one historical patch.'],
    origins=('1dfd535d3ef9467091cee7daf05aecc53ecf108b',)),
 'codex/pr110-kb-arch-scope-20261029': row(
    'PR #122 reject incompatible product architectures before Winbindex pair resolution, including inherited integration fixes.',
    'The explicit supported-architecture guard remains. Later current repairs isolate mixed x64/WoW64 '
    'rows before predecessor/tie selection, preserving raw rows while preventing cross-architecture pairing.',
    ['resolver.py retains the SUPPORTED_ARCH guard and later per-row architecture selection.',
     'Ancestors b244369c296bceb13ce6e0d716f99e078d440f13 and '
     '11e88b634af70a40f6860e0abb843b3f627ad5cc record architecture-isolated index lineage.',
     'Current acquisition Winbindex and symbol-profile controls cover the inherited focused seams.'],
    names('test_kbc_resolver','test_kbc_resolver_architecture','test_acquisition_winbindex','test_ui_profiles'),
    'No port for the architecture guard; preserve the stronger current lineage isolation.',
    ['Offline metadata and synthetic PE controls do not qualify live retrieval or native binaries.'],
    origins=('b244369c296bceb13ce6e0d716f99e078d440f13','11e88b634af70a40f6860e0abb843b3f627ad5cc')),
 'codex/pr110-persistence-feedback-20261029': row(
    'PR #119 failed save/bookmark/review/note operations must preserve analyst drafts and avoid false success.',
    'The helper and all four affected MainWindow actions retain the historical behavior.',
    ['ui_persistence.py is byte-identical.',
     'MainWindow.save_project, bookmark_evidence, review_finding and save_note are AST-identical.',
     'The current test_ui.py failed-save controls exercise all four actions.'],
    names('test_ui','test_acquisition_winbindex','test_ui_profiles'),
    'No port for the persistence feedback scope.',
    ['This does not certify every unrelated edit in the branch parent or all native desktop behavior.']),
 'codex/pr111-bounded-nav-into-integration-20261029': row(
    'PR #117 the bounded ambiguous-navigation repair carried onto its integration parent.',
    'The same limited candidate buffer is current; the inherited integration Winbindex/symbol seams have '
    'later tested replacements. This is the same navigation behavior as #111, not an additional feature.',
    ['gui/anchors.py is byte-identical to the tip.',
     'NavResult.ambiguous retains only MAX_CANDIDATES while counting the iterable; the original '
     '100,000-item stream/memory controls are current.'],
    names('test_gui_core_anchors','test_acquisition_winbindex','test_ui_profiles'),
    'No port for navigation; preserve the later integration fixes.',
    ['No claim about all non-source parent history or native UI acceptance.']),
 'codex/gui-bounded-ambiguous-candidates-20261029': row(
    'PR #111 bounded memory when an ambiguous anchor returns many navigation candidates.',
    'The sole changed production file and its regression file are byte-identical to current.',
    ['src/patchtrace/gui/anchors.py and tests/test_gui_core_anchors.py have matching Git blobs.',
     'The current stream, cap and memory assertions ran in the 50-file gate.'],
    names('test_gui_core_anchors'),
    'No selective port. Retain the reference; merge history/patch IDs do not change the byte-equality finding.',
    ['The bounded list remains ambiguous; these tests do not validate semantic match correctness.']),
 'codex/analyst-accessibility-20261109': row(
    'Export keyboard/focus behavior and Files-pane announcements and accessibility controls.',
    'Both changed production files are byte-identical. Current announcement tests have additional retry '
    'and project-path controls; no unique source omission was found in this scope.',
    ['ui_export_v2.py and ui_inspection.py match exactly; ui_export_v2/accessibility regression files match.',
     'Ancestor 45997cfc997b06996a982705e6cd60dc73a8fae1 carries the accessibility work.',
     'Current tooltip registry sweep and actual export/dialog/inspection tests ran.'],
    names('test_files_announcements','test_ui_export_accessibility','test_tooltips'),
    'No source port; preserve historical timeouts as historical incomplete evidence.',
    ['Offscreen Qt is not native Windows keyboard, screen-reader or assistive-technology acceptance.'],
    origins=('45997cfc997b06996a982705e6cd60dc73a8fae1',)),
 'feat/acquisition': row(
    'Original acquisition contracts, transport, quarantine, Winbindex resolution, delta integration and CLI.',
    'The original modules/APIs remain, with stronger URL/host consent, byte/deadline/hash limits, '
    'cancellation and publication/retention rules. The inherited audit foundation is represented by current '
    'audit tests; native/live behavior is not requalified.',
    ['No changed production path is missing. Original CLI/delta tests and fixtures are retained.',
     'Current acquisition.workflow is a Qt-free facade reused by the KB journey.',
     'Current quarantine keeps an already committed project if provenance/annotation publication fails; '
     'restoring older cleanup behavior would regress preservation.'],
    names('test_acquisition_cli','test_acquisition_delta','test_acquisition_quarantine',
          'test_acquisition_transport','test_acquisition_winbindex','test_gui_creation_retry',
          'test_audit_core','test_audit_desktop','test_audit_runtime'),
    'No selective port for the focal acquisition workflow. Use existing current services for future work.',
    ['The Windows msdelta.dll execution control is skipped on this host.',
     'No live Microsoft acquisition, network credentials, delta execution or target execution occurred.']),
 'feat/acquisition-gui': row(
    'Desktop acquisition dialog, explicit pair selection, background acquisition and owner-thread adoption.',
    'The dialog remains integrated in current MainWindow. The original test_ui_acquisition.py is '
    'byte-identical; current creation/retention fixes extend failure handling.',
    ['AcquisitionDialog still captures explicit older/newer choices and exact consent before worker acquisition.',
     'GUI-thread promote/adopt, busy state and error paths are covered by the current original tests.'],
    names('test_ui_acquisition','test_gui_creation_retry'),
    'No selective source port for this workflow.',
    ['No live download/native delta or manual Windows GUI acceptance is implied.']),
 'feat/phase3-batch': row(
    'PR #13 N-way series and unchanged-hop raw-address matches, acquisition GUI, and secondary engine import/reconciliation.',
    'Current N-way preparation/computation/storage/staleness and secondary CLI/import APIs retain the '
    'focal feature set. The modern BinExport/secondary reader and native-producer ownership policies supersede '
    'the old implementations; temporary Windows CI diagnostics are not product omissions.',
    ['Historical functional commits include 70bdb28db2d8bf3260f5e510acb5ccc6609b5208 (N-way), '
     '44d431788bcc55429a033049ed997fa33c92289b (unchanged-hop matching), '
     'b932ae1a1c8916aeac7be2d49ce27c24717f2846 (secondary engines), and '
     '462ef7fa098caa0df8608a7ea28c07003904b92d (integration CLI).',
     'Current nway.series performs verified raw reading and corruption/staleness checks; '
     'secondary facades route to newer bounded readers instead of missing old helper names.'],
    names('test_nway_graph','test_nway_series','test_ui_acquisition','test_cli_secondary',
          'test_secondary_reconcile','test_secondary_bindiff','test_secondary_binexport','test_secondary_rzdiff'),
    'No focal feature port. Preserve current conservative native Rizin/producer qualification boundaries.',
    ['Native BinDiff/BinExport/Rizin compatibility and Windows packaging are not exercised here.',
     'Broad inherited audit/profile/cache code is scoped by the other batch rows, not blanket certified.']),
 'feat/profiles': row(
    'Persistent named enrichment profiles, validation/digest and desktop selection; inherited acquisition/audit foundation.',
    'The profile model/store/digest and UI behavior remain. Current code additionally validates profile '
    'names/paths and supports the reviewed local-symbol policy.',
    ['enrichment/profiles.py retains historical functions; differences add local symbol policy and strict '
     'ProfileStore._path validation.',
     'Current profile and UI-profile controls cover store roundtrip, selection and symbol policy.'],
    names('test_profiles','test_ui_profiles','test_acquisition_cli','test_audit_enrichment'),
    'No profile port; avoid reverting current path validation or local symbol policy.',
    ['No native engine/profile compatibility or all historical parent changes are certified by profile tests.']),
 'feat/raw-cache': row(
    'Ghidriff raw-output cache keyed by input/runtime identity, cache hit/miss/no-cache/refresh behavior.',
    'The raw cache remains and is more conservative: runtime identity includes selected symbol mode and '
    'staged PDB digest; online/unknown version cases stay ineligible. This is not the separate unresolved capa cache.',
    ['backend._read_raw_cache is AST-identical; _open_raw_cache evolves the identity and eligibility checks.',
     'tests/test_raw_cache.py is byte-identical to the historical tip.',
     'Current profile UI retains cached-result labels and selected-symbol settings.'],
    names('test_raw_cache','test_ui_profiles','test_backend_symbol_local'),
    'No port for raw Ghidriff caching. Retain current identity and staging rules.',
    ['Fake-engine cache mechanics are not a fresh Ghidra/Ghidriff/PDB/native run.']),
 'feat/enrichment-cve': row(
    'B3 CVE normalization, contextual reranking, exact consented MSRC/NVD request planning and provider transport.',
    'The original normalization and transport APIs remain with stricter parsing, Unicode handling, '
    'deadline/pacing, partial-provider-failure and snapshot-selection controls. This is distinct from the '
    'separately reviewed CVRF-to-pilot bridge already present in the comparison baseline.',
    ['enrichment/cve.py and enrichment/intelligence.py retain the original contracts and CLI correlate seam.',
     'Original fixtures/core tests are retained; the current intelligence suite exercises stricter transport behavior.'],
    names('test_enrichment_core','test_enrichment_cve','test_enrichment_intelligence'),
    'No source port for the original B3 feature.',
    ['All provider tests here are offline or injected. Live API availability, current upstream compatibility '
     'and freshness are separate gates; no applicability inference follows from contextual reranking.']),
 'claude/patchtrace-features': row(
    'PR #100 local/off/online PDB policy and private launcher plus Diaphora Mode A import.',
    'The local symbol policy, CodeView/PDB identity staging, private launcher and Diaphora storage/import '
    'remain. Current implementation adds stricter ownership/read boundaries and newer CLI routing.',
    ['13 of 26 changed production paths match exactly; no changed production path is missing.',
     'Current backend, symbols.staging, ghidriff_launch, diaphora.service and sqlite_guard retain the '
     'specific behavior while evolving security and provenance rules.',
     'test_ptlaunch.py and corresponding contract/support artifacts are retained.'],
    names('test_backend_symbol_local','test_diaphora_import','test_diaphora_cli',
          'test_symbols_staging','test_ui_symbol_local','test_ptlaunch'),
    'No focal source port; retain newer Diaphora and publication safety changes.',
    ['Local-symbol tests use authored/fake fixtures. No native PDB, Ghidra, IDA or Diaphora engine acceptance '
     'is claimed. The tested producer version matrix remains a separate gate.']),
 'claude/spec53-diagnose-launcher': row(
    'PR #280 backend diagnose showing the private launcher Ghidriff revision as tested/untested.',
    'The exact patch is equivalent and backend._launcher_line has the same AST. The diagnostic behavior is retained.',
    ['test_backend_cli.py is byte-identical.',
     'The existing tested prefix 4f5d895 is historical qualification metadata, not evidence that this review '
     'ran the native tool or validated an arbitrary current revision.'],
    names('test_backend_cli'),
    'No selective port.',
    ['Native tested-version claims must be assessed from their own retained receipts.']),
 'claude/bugfix-search-pilot-20261111': row(
    'PR #288 unsigned address/cursor guards, signature phrase/exclude semantics, exact CVE-ID matching, '
    'real UTC timestamp validation and bounded multiline buildenv provenance.',
    'The patch is equivalent. Three production files are byte-identical; the evolved search service retains '
    'the address bounds, cursor error and phrase/exclude controls. The entire original regression file is identical.',
    ['pilot/contracts.py and buildenv report/viewmodel paths match the tip; search/service.py retains the '
     'reviewed boundary behavior in a later implementation.',
     'test_search_pilot_buildenv_bugfixes_20261111.py ran unchanged.',
     'Saved/recent search is separately accepted at saved-integration '
     'ef34fff23ff62a4ad0e0b7319006f45897314761 and is not a new omission here.'],
    names('test_search_pilot_buildenv_bugfixes_20261111'),
    'No port for these six defect families; preserve later saved/recent generation guards.',
    ['This does not certify all search/pilot behavior or supersede the separately reviewed CVRF/staleness work.']),
}

candidates = [
 dict(id='C1', status='confirmed_missing_refusal', priority='narrow repair',
      title='Reject foreign schemas before recycling an incomplete project',
      historical_source='c13d3257c88140c23fb585a8a59a4dce81e81928:src/patchtrace/project_retry.py::_database',
      current_source='src/patchtrace/persistence.py::_abandoned_creation; ProjectStore.__init__',
      evidence=['creation-schema-red.log','creation-schema-red.xml','test_incomplete_creation_refusal_review.py'],
      observation='Real SQLite empty current-schema databases with a foreign view, trigger, or extra column '
                  'are accepted and replaced by ProjectService.create. Three negative controls fail; '
                  'ordinary empty current-schema retry is the passing positive.',
      acceptance='Preserve healthy incomplete retry; refuse/preserve foreign schema objects and columns, '
                 'bound DB/VM work, retain lock and artifact preservation rules, and check cancellation. '
                 'Do not port the entire historical publication/retry UI stack.'),
 dict(id='C2', status='confirmed_missing_behavior', priority='narrow analyst-output repair',
      title='Report capped callgraph views as partial and deduplicate focus inputs',
      historical_source='c13d3257c88140c23fb585a8a59a4dce81e81928:src/patchtrace/callgraph/{query,export_json,dot,view_model,panel_qt}.py',
      current_source='src/patchtrace/callgraph/query.py::neighbourhood',
      evidence=['callgraph-red.log','callgraph-red.xml','historical-controls/test_callgraph_cap_truth.py'],
      observation='The real cycle_hub view shows 64 of 66 neighbours, retains a MoreMarker, but has '
                  'truncated=False. Two CLI format controls fail at neighbours returning exit 0/ok. '
                  'Duplicate focus IDs can consume the root budget and hide another root. '
                  'The below-cap duplicate-claims control passes.',
      acceptance='Propagate per-origin omission into conservative partial state/limits, CLI exit, JSON/DOT '
                 'and desktop text. Preserve below-cap complete behavior and exact per-origin counts. '
                 'The original failing assertions stop before later export assertions; export and UI '
                 'acceptance must be executed after repair, not inferred from this red run.'),
 dict(id='C3', status='confirmed_missing_behavior', priority='bounded analyst-query repair',
      title='Share the path-query work budget across prepasses and avoid whole-graph/row copies',
      historical_source='c13d3257c88140c23fb585a8a59a4dce81e81928:src/patchtrace/callgraph/{algo,csr,paths,limits}.py',
      current_source='src/patchtrace/callgraph/paths.py::find_paths; algo.simple_paths',
      evidence=['callgraph-red.log','callgraph-red.xml','callgraph-budget-red.log','callgraph-budget-red.xml',
                'historical-controls/test_callgraph_path_budget.py'],
      observation='A caller budget of 40 allows 202 adjacency examinations in the reverse-prepass control. '
                  'The actual normalized 816-node hub query copies 200145 adjacency entries. '
                  'find_paths rebuilds the complete CSR; an already-cancelled query still copies/reads '
                  '859 entries before refusal. The normal shortest/tie-order positive passes.',
      acceptance='Bound actual adjacency examinations across shortest, reverse and enumeration phases; '
                 'check cancellation before work and during scans; preserve shortest lexical order, '
                 'the five-path/length caps, listed-membership and endpoint rules, and a completed '
                 'shortest witness on later exhaustion. Independently review this algorithmic port.'),
 dict(id='C4', status='coverage_gap_confirmed_no_product_failure_claim', priority='separate package-QA design',
      title='Recover an updated synthetic F8 packaged journey',
      historical_source='c13d3257c88140c23fb585a8a59a4dce81e81928:src/patchtrace/gui/qt/kb_selftest.py',
      current_source='src/patchtrace/__main__.py::main (--self-test)',
      evidence=['candidate-lineage.json'],
      observation='The historical helper exercised offline advisory import, ambiguity/explicit scope, '
                  'pair preview/create/adopt, fixture import/rank, candidates, export, Unicode paths, '
                  'reopen and stale-reopen using the normal event loop. Current --self-test checks a '
                  'sample window and panel construction. Separate current pytest journeys cover many '
                  'components, but do not replace that packaged end-to-end journey.',
      acceptance='Adapt the journey to current contracts and packaging in a separate reviewed slice. '
                 'Keep synthetic labeling, no target/network execution, bounded event-loop cleanup, '
                 'and real frozen Windows/Linux runs distinct from source offscreen tests.'),
 dict(id='C5', status='incomplete_workflow_requires_design', priority='separate feature decision',
      title='Explicit bounded recovery of partially created projects',
      historical_source='c13d3257c88140c23fb585a8a59a4dce81e81928:src/patchtrace/{project_creation,project_retry,ui_new_project}.py',
      current_source='src/patchtrace/service.py::ProjectService.create; ui.py creation wizard',
      evidence=['candidate-lineage.json'],
      observation='The historical workflow privately staged artifacts/snapshot and offered an explicit '
                  'check-and-retry action with byte identity, entry/schema bounds and owner/revision '
                  'checks. Current creation supports rollback and some backend incomplete retry, but '
                  'the wizard admits only absent/empty/lock-only destinations. The larger explicit '
                  'partial-artifact recovery action is not implemented.',
      acceptance='First fix C1 without broad changes. Before any larger port, reconcile current owned '
                 'publication helpers, UI seam caps, locks, identity checks, cancellation and late '
                 'adoption policy. Do not describe the current busy-disabled wizard as a confirmed '
                 'reachable project-switch race without a reproducer.'),
]


def main() -> None:
    inputs = json.loads((QA / 'snapshot.json').read_text())
    symbols = json.loads((QA / 'symbol-comparison.json').read_text())
    assert inputs['comparison_base'] == BASE
    assert len(inputs['branches']) == len(details) == 20
    subprocess.run(['git','diff','--exit-code',BASE,'--','src','tests','tools'],cwd=ROOT,check=True,
                   stdout=subprocess.DEVNULL)
    gates = []
    by_file = {}
    for gate_id, file, elapsed, kind in [
        ('current-replacements','current-affected.xml',69.24,'current behavior'),
        ('owner-thread-replacements','owner-thread.xml',6.62,'current behavior'),
        ('foreign-schema-red','creation-schema-red.xml',0.30,'external red controls'),
        ('historical-callgraph-red','callgraph-red.xml',0.66,'unchanged historical red/positive controls'),
        ('shared-budget-red','callgraph-budget-red.xml',0.38,'unchanged historical red control')]:
        tree = ET.parse(QA / file)
        suites = list(tree.iter('testsuite'))
        assert len(suites) == 1
        counts = {key:int(suites[0].get(key,'0')) for key in ('tests','failures','errors','skipped')}
        counts['passed'] = counts['tests'] - counts['failures'] - counts['errors'] - counts['skipped']
        gate = dict(id=gate_id,source=BASE,artifact=file,kind=kind,pytest_summary_seconds=elapsed,
                    junit_suite_seconds=float(suites[0].get('time')),**counts)
        gate['skips'] = [{'test':c.get('classname')+'::'+c.get('name'),
                         'reason':s.get('message')} for c in tree.iter('testcase') for s in c.findall('skipped')]
        gates.append(gate)
        if kind == 'current behavior':
            for c in tree.iter('testcase'):
                path = c.get('classname').replace('.', '/')+'.py'
                by_file.setdefault(path,{'gate':gate_id,'tests':0,'passed':0,'skipped':0})
                by_file[path]['tests'] += 1
                by_file[path]['skipped' if c.find('skipped') is not None else 'passed'] += 1
    symbol_map = {b['branch']:b for b in symbols['branches']}
    branches=[]
    for index,b in enumerate(inputs['branches'],1):
        d=details[b['branch']]
        sources=[p for p in b['source_projection'] if p['path'].startswith('src/')]
        baseline_only,tip_only=map(int,b['ahead_behind_baseline'].split())
        entry = {**b, 'id':f'B{index:02d}', **d,
                 'divergence':{'comparison_only_commits':baseline_only,'tip_only_commits':tip_only},
                 'source_path_counts':dict(collections.Counter(p['state'] for p in sources)),
                 'ast_symbol_counts':dict(collections.Counter(r['status'] for r in symbol_map[b['branch']]['symbols'])),
                 'test_evidence':[{'path':p,**by_file[p]} for p in d['current_tests']],
                 'replacement_ancestor_checks':[{ 'commit':sha,
                    'ancestor_of_comparison':subprocess.run(['git','merge-base','--is-ancestor',sha,BASE],
                        cwd=ROOT).returncode==0} for sha in d['replacement_commits']]}
        assert entry['tip_matches_inventory']
        branches.append(entry)
    report = {
       'schema':'patchtrace-semantic-disposition/1','generated_at_utc':datetime.now(UTC).isoformat(),
       'comparison_source':BASE,'comparison_tree':git('rev-parse',BASE+'^{tree}'),
       'inventory_source_sha256':inputs['inventory_source_sha256'],
       'inventory_observed_at':inputs['inventory_observed_at'],
       'local_refs_observed_at':inputs['captured_at_utc'],
       'remote_status_refresh':'None in this batch. PR records retain the original inventory observation; '
                               'local fetched tips were checked to that inventory.',
       'scope':{'historical_needs_reconciliation_denominator':131,'selected_tips_examined':20,
                'not_examined_by_this_batch':111,'scoped_behavior_retained':17,
                'broad_tips_remaining_partial':3,'whole_branch_closure_authorized':False,
                'completion_percentage':None,
                'criteria':'One entry requires exact tip/merge base, source patch inspection, actual '
                           'current replacement or missing-behavior evidence, qualification limits, '
                           'and a port recommendation. It is not exhaustive full-branch certification.'},
       'method':['Inspect merge-base-to-tip source patches and tip-to-current source differences; '
                 'retain exact paths/blobs and git cherry results.',
                 'Use file/AST equality as local evidence only; inspect changed implementation and '
                 'its consumer before claiming focal behavior is retained.',
                 'Run selected current regression suites and actual SQLite/normalized-graph/CLI '
                 'negative controls; retain failures without changing current source.',
                 'Do not reclassify native/research or uninspected inherited source by a branch title, '
                 'merged PR status, patch ID or passing unrelated tests.'],
       'excluded_as_separately_owned':['PR308–313 publication/GUI/search/safety slices',
                                     'accepted CVRF/pilot/staleness bridge and row/budget repairs',
                                     'concurrent XML/DTD and scanner repairs'],
       'separate_feature_comparisons':{
         'raw_alignment':'e6f9ea3fafa400d5585a2db17131efcac8791bcd',
         'saved_recent_search':'ef34fff23ff62a4ad0e0b7319006f45897314761'},
       'gates':gates,'counting':'Gate results are listed separately. Shared tests mapped to multiple '
                              'branches are not additive evidence or a completion denominator.',
       'candidates':candidates,'branches':branches,
       'evidence_archive':'../../qa/semantic-disposition-batch1-20261118.zip',
       'limitations':['No historical tip full suite was run; historic controls were replayed against '
                      'the pinned current source.',
                      'No live network acquisition, target execution, native engines, Windows execution, '
                      'package builds or manual acceptance occurred.',
                      'No fresh GitHub review/check state was asserted; root owns publication decisions.',
                      'A first test-selection preflight named two absent historical files and ran no '
                      'pytest. Its failure summary and original selection script are retained.']}
    (OUT/'semantic-disposition-batch1.json').write_text(json.dumps(report,indent=2)+'\n')
    md=['# Semantic branch disposition — batch 1 (2026-11-18)', '',
        '**Result:** 20 of the 131 mechanically classified reconciliation tips received a scoped '
        'semantic examination. Seventeen retain their focal behavior in the current implementation. '
        'Three broad, overlapping checkpoint tips remain partial and expose three concrete repair '
        'candidates plus two larger workflow/qualification gaps. This is not whole-branch closure.', '',
        f'Comparison source: `{BASE}`; tree `{report["comparison_tree"]}`. The original inventory '
        f'observation remains `{inputs["inventory_observed_at"]}`. The local fetched refs were captured '
        f'at `{inputs["captured_at_utc"]}` and all 20 tips match the committed inventory. No live REST '
        'refresh, source edits, remote mutations, closures, merges or deletions were performed.', '',
        'The source baseline includes the accepted CVRF/staleness/advisory-read stack. Raw alignment '
        'and saved/recent search are separate accepted follow-on trees, recorded below; their absence '
        'from this comparison baseline is not rediscovered as an omission.', '',
        '## Review basis and limits', '',
        'Each row combines exact tip/merge-base and changed-path evidence, actual source inspection, '
        'current replacement or missing-behavior proof, a test/qualification record, and a selective-port '
        'decision. File and AST equality support only the compared scope. A merged PR or a matching '
        'patch ID alone does not prove semantic equivalence. Current tests exercise current replacements; '
        'they do not qualify historical trees or live/native compatibility.', '',
        'There are 111 original reconciliation tips outside this batch. The three broad tips inside '
        'this batch also retain unreviewed source residue. No completion percentage is reported: the '
        'denominator is branch entries, and the amount of unreviewed behavior within them is not known. '
        'The original inventory classifications and historical evidence are unchanged.', '',
        'Evidence: [machine-readable ledger](semantic-disposition-batch1.json), '
        '[raw receipt archive](../../qa/semantic-disposition-batch1-20261118.zip), and '
        '[QA receipt](../../qa/semantic-disposition-batch1-20261118.md). The archive retains the full '
        'mechanical snapshot, source/test patches, AST comparisons, probes and original test logs/XML.', '',
        '## Candidate repairs and unresolved workflows', '']
    for c in candidates:
        md += [f'### {c["id"]}: {c["title"]}', '',f'**Status:** `{c["status"]}`. '
               f'**Suggested scope:** {c["priority"]}.', '',c['observation'], '',
               f'Historical source: `{c["historical_source"]}`. Current seam: `{c["current_source"]}`.', '',
               c['acceptance'], '', 'Retained evidence: '+', '.join('`'+x+'`' for x in c['evidence'])+'.', '']
    md += ['## Exact tips and scoped dispositions', '',
           '“Retained” means the focal behavior described in its detailed entry below. “Partial” '
           'means unresolved selective work remains in a broad tip; all three share source ancestry.', '',
           '| ID | Branch / historical PR | Exact tip | Focal disposition |',
           '|---|---|---|---|']
    for b in branches:
        prs=', '.join('#'+str(pr['number']) for pr in b['pull_requests']) or 'no associated PR in frozen inventory'
        status='Partial; '+', '.join(b['candidate_ids']) if b['disposition'].startswith('partial') else 'Retained in current scope'
        md += [f'| {b["id"]} | `{b["branch"]}` ({prs}) | `{b["tip"]}` | {status} |']
    md += ['', '## Per-branch evidence and decisions', '']
    for b in branches:
        count=b['source_path_counts']; divergence=b['divergence']
        md += [f'### {b["id"]}: {b["branch"]}', '',
               '**Assessed scope:** '+b['assessed_scope'], '', b['semantic_finding'], '',
               f'Exact tip is in the table above. Merge base with the comparison source: `{b["merge_base"]}`. '
               f'Divergence: {divergence["comparison_only_commits"]} comparison-only / '
               f'{divergence["tip_only_commits"]} tip-only commits. Of the changed production paths, '
               f'{count.get("identical",0)} are byte-identical, {count.get("different",0)} differ and '
               f'{count.get("missing_current",0)} are absent by that path. These counts are mechanical '
               'evidence, not semantic scores.', '']
        md += ['- '+x for x in b['current_replacement_proof']]
        md += ['', '**Current regression seams:** '+', '.join('`'+p+'`' for p in b['current_tests'])+'. '
               'Results map to the shared gates below; repeated references are not additional runs.', '',
               '**Recommendation:** '+b['recommendation'], '', '**Remaining qualification:** '+' '.join(b['remaining_qualification']), '']
    md += ['## Current gates and preserved failures', '',
           '| Gate | Pinned source | Result | Elapsed pytest summary | Interpretation |',
           '|---|---|---|---|---|',
           '| 50 selected current files | `ac789497` | 1,069 passed; 1 skipped | 69.24 s | Current retained-behavior evidence; the skip is the Windows-only `msdelta.dll` synthetic delta execution. |',
           '| Owner-thread/adoption replacement, 3 additional files | `ac789497` | 51 passed | 6.62 s | Actual held-project snapshot, worker calculation, stale result refusal and transactional adoption. |',
           '| External incomplete-project schema controls | `ac789497` | 3 failed; 1 passed | 0.30 s | Original foreign view/trigger/column failures plus healthy incomplete retry. |',
           '| Unchanged historical callgraph controls | `ac789497` | 7 failed; 2 passed | 0.66 s | Cap truth/focus/copy/cancellation omissions; below-cap and shortest-order positives. |',
           '| Unchanged historical shared-budget control | `ac789497` | 1 failed | 0.38 s | 202 adjacency examinations despite a caller budget of 40. |', '',
           'All pytest executions use the current worktree source through absolute `PYTHONPATH`; Qt uses '
           '`QT_QPA_PLATFORM=offscreen`. Commands and JUnit durations are retained separately from pytest '
           'summary wall times. The first selection preflight named two absent historical test files and '
           'started no pytest; its original script and an explicitly labeled post hoc failure summary '
           'remain in the archive. No source repair was applied to turn these red controls green.', '',
           'The separate accepted raw-alignment tree is '
           '`e6f9ea3fafa400d5585a2db17131efcac8791bcd`; saved/recent search is '
           '`ef34fff23ff62a4ad0e0b7319006f45897314761`. Their author and independent receipts stay with '
           'those slices. Tests from those tasks are not added to this batch’s counts.', '',
           '## Remaining branch work', '',
           'The 111 unselected reconciliation tips still need source inspection. Within B01/B02/B05, '
           'unified semantic proofs, typed literals/CFG matching, calibration and native producer changes '
           'remain explicitly partial. The successful narrow replacements in B03–B20 do not authorize '
           'deleting or merging their branches. Root owns separately assigned repairs, final review and '
           'publication. No native/manual/Windows/live-provider acceptance is claimed here.', '']
    (OUT/'semantic-disposition-batch1.md').write_text('\n'.join(md))
    (QA/'ledger-build-summary.json').write_text(json.dumps({'source':BASE,'branches':len(branches),
        'dispositions':dict(collections.Counter(b['disposition'] for b in branches)),
        'gates':gates,'source_unchanged':True},indent=2)+'\n')
    print('built',len(branches),'rows;',len(candidates),'candidate/workflow entries')


if __name__=='__main__':
    main()
