from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime
import hashlib
import json
import subprocess

ROOT=Path('/workspace/scratch/c7a9e8d98848/semantic-disposition')
OUT=Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch1')
BASE='ac789497597fba3cb87696990d171a7a27024fca'
NAMES=[
'codex/autonomous-checkpoint-20261102-0945',
'codex/autonomous-checkpoint-20261102-1020',
'codex/essential-project-safety-20261031',
'codex/msrc-mixed-format-revision-20261102',
'codex/msrc-reconcile-integration-20261102',
'codex/kb-explicit-filename-selection-20261104',
'codex/pr110-kb-arch-scope-20261029',
'codex/pr110-persistence-feedback-20261029',
'codex/pr111-bounded-nav-into-integration-20261029',
'codex/gui-bounded-ambiguous-candidates-20261029',
'codex/analyst-accessibility-20261109',
'feat/acquisition',
'feat/acquisition-gui',
'feat/phase3-batch',
'feat/profiles',
'feat/raw-cache',
'feat/enrichment-cve',
'claude/patchtrace-features',
'claude/spec53-diagnose-launcher',
'claude/bugfix-search-pilot-20261111',
]

def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT,text=True)

def tree(sha):
    return {line.split('\t',1)[1]:line.split()[2] for line in git('ls-tree','-r',sha,'--','src','tests').splitlines()}

inventory_path=ROOT/'docs/plans/autonomous-consolidation-20261118/branch-inventory.json'
D=json.loads(inventory_path.read_text())
rows={row['branch']:row for row in D['branches']}
prs={row['number']:row for row in D['pull_requests']}
base_tree=tree(BASE)

def capture(name):
    old=rows[name]
    assert old['classification']=='needs_reconciliation',name
    sha=git('rev-parse','refs/remotes/origin/'+name).strip()
    mb=git('merge-base',BASE,sha).strip()
    paths=git('diff','--name-only',mb,sha).splitlines()
    src=[p for p in paths if p.startswith('src/')]
    tests=[p for p in paths if p.startswith('tests/')]
    source_tree=tree(sha)
    projection=[{'path':p,'tip_blob':source_tree.get(p),'base_blob':base_tree.get(p),
                 'state':'identical' if source_tree.get(p)==base_tree.get(p) else
                         'missing_current' if p not in base_tree else
                         'deleted_at_tip' if p not in source_tree else 'different'} for p in src+tests]
    label=name.replace('/','__')
    patch=git('diff','--binary',mb,sha,'--','src','tests')
    (OUT/(label+'.patch')).write_text(patch)
    between=git('diff','--binary',BASE,sha,'--',*src) if src else ''
    (OUT/(label+'.current-comparison.patch')).write_text(between)
    return {'branch':name,'tip':sha,'inventory_tip':old['head_sha'],'tip_matches_inventory':sha==old['head_sha'],
            'inventory_classification':old['classification'],'merge_base':mb,
            'ahead_behind_baseline':git('rev-list','--left-right','--count',BASE+'...'+sha).strip(),
            'patch_equivalence':git('cherry',BASE,sha).splitlines(),
            'unique_log':git('log','--no-merges','--format=%H %s',BASE+'..'+sha).splitlines(),
            'pull_requests':[prs[p['number']] for p in old['pull_requests']],
            'changed_paths':paths,'source_projection':projection,
            'branch_patch':{'file':label+'.patch','sha256':hashlib.sha256(patch.encode()).hexdigest()},
            'current_comparison_patch':{'file':label+'.current-comparison.patch',
                                        'sha256':hashlib.sha256(between.encode()).hexdigest()}}

with ThreadPoolExecutor(max_workers=4) as pool:
    captured=list(pool.map(capture,NAMES))
output={'schema':'patchtrace-semantic-disposition-input/1','captured_at_utc':datetime.now(UTC).isoformat(),
        'comparison_base':BASE,'inventory_source_sha256':hashlib.sha256(inventory_path.read_bytes()).hexdigest(),
        'inventory_observed_at':D['observed_at_utc'],'classification_denominator':131,
        'selected_count':len(captured),'remote_refresh':'local fetched refs cross-checked to committed inventory; no remote mutation',
        'branches':captured}
(OUT/'snapshot.json').write_text(json.dumps(output,indent=2)+'\n')
for row in captured:
    non=[x['path'] for x in row['source_projection'] if x['path'].startswith('src/') and x['state']!='identical']
    missing=[x['path'] for x in row['source_projection'] if x['path'].startswith('src/') and x['state']=='missing_current']
    same=sum(x['path'].startswith('src/') and x['state']=='identical' for x in row['source_projection'])
    print(row['branch'],row['tip'][:10],f'identical_src={same} nonidentical_src={len(non)} missing={len(missing)}',','.join(missing[:5]))
