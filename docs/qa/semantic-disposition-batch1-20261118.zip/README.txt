Semantic disposition batch 1. Comparison source ac789497597fba3cb87696990d171a7a27024fca; no product-source edits.
20 exact local fetched tips match the frozen 2026-11-18T13:50:56.954Z inventory.
Full snapshot, mechanical patches, AST comparisons and original test log/XML are retained.
current-affected: 1069 passed, 1 Windows-only msdelta skip; owner-thread: 51 passed.
creation-schema-red: 3 failed, 1 positive; original command was not separately archived. The probe and original log/XML are retained.
callgraph-red: 7 failed, 2 positive; extracted historical tests are byte-identical to c13d3257.
callgraph-budget-red: 1 failure, separate unchanged control; not part of the original nine-case run.
selection-preflight-failure is a labeled post hoc tool-output summary, not a raw pytest log; no pytest ran in that selection attempt.
Historical behavior, native tools, Windows, package/manual and live-provider gates are not requalified here.
