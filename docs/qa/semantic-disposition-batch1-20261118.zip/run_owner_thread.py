from pathlib import Path
import json, subprocess, os
p=Path(__file__).resolve().parent
w=Path('/workspace/scratch/c7a9e8d98848/semantic-disposition')
a=['/workspace/scratch/3a6632a6e5ff/venv/bin/python','-m','pytest','-q','tests/test_gui_project_adoption.py','tests/test_kbc_snapshot.py','tests/test_ui_kb_panel.py','--junitxml='+str(p/'owner-thread.xml'),'--tb=short']
e=os.environ.copy();e.update(QT_QPA_PLATFORM='offscreen',PYTHONPATH=str(w/'src')+':'+str(w/'tests'))
with (p/'owner-thread.log').open('w') as f:r=subprocess.run(a,cwd=w,env=e,stdout=f,stderr=subprocess.STDOUT)
(p/'owner-thread-command.json').write_text(json.dumps({'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'cwd':str(w),'args':a,'env':{k:e[k] for k in ('QT_QPA_PLATFORM','PYTHONPATH')},'exit_code':r.returncode},indent=2)+'\n')
print('exit',r.returncode)
raise SystemExit(r.returncode)
