# Durable held-package admission: read-only design receipt

Frozen product authority: `195e04af27f7a724c6a2037363b7fe68df418a6b`, tree
`b976c61b0ac4ffb55b7b0e78d7a2b206742c00b1`.
Design commit: `efe68b18654459e704d358d64423fbc1820afc0a` on
`codex/package-durable-admission-design-20261118`.

The two proposed-design files are retained under `proposal/docs/plans/`.
They are not product contracts or implemented APIs. Production, repository
tests, current schemas, CLI/UI/native entry points and remote refs are unchanged.
The seven observations below qualify only the exact frozen Linux SQLite
behavior, with authored small local databases and normal system-temp fixtures.

## Current observations and the interpretation correction

Exact command/environment/source/import comparisons are in
`workspace-version.command.json`. Original output: **7 passed in 0.35 s**, zero
failures/errors/skips; **32** imported project modules match the frozen Git bytes.
The child denied network and process launches and observed **zero attempts**.
There was one test invocation, without fixture corrections or retried assertions.

The test source SHA-256 is
`f7a0cdcf8d079068f39a34ccca17adb11c72c2594c88535db7e03310bf078a5c`.

| Observation | Result |
|---|---|
| New ordinary v1 store | Writable; version remains 1 |
| Quiescent store stamped v2, then freshly opened by frozen code | Known rows readable; public write returns nonrecoverable PT-KBC-STORAGE; direct SQL write is read-only; database fixture bytes unchanged |
| Fresh v2 generic repair | Refuses before attempt/journal/project calls in the authored fixture |
| v1 handle already open before external v2 stamp | Cached `read_only=False`; subsequent ordinary journal write succeeds |
| New held-looking fields in such a legacy journal row | Frozen `mark_interrupted` ignores them and writes one attempt plus interrupted state |
| Package-looking row only in a separate additive table | Frozen journal enumeration/marking does not see or modify it; ordinary legacy writes are still possible |
| Authored table/first-row/version transaction followed by rollback | All three changes roll back; v1 ordinary write still succeeds |

`interpretation-corrections.json` retains the initial marker-plus-version design
hypothesis and the counterexample that supersedes it. The final recommendation
keeps package attachment progress entirely outside legacy journal enumeration,
supplements it with fresh-reader v2 gating and requires new-code refusal before
generic marking. It does not claim that a schema number stops every already-open
or historical client. The v2 opening observation is quiescent SQLite, not a
forensic no-I/O guarantee for hot recovery or a Windows observation.

The rollback observation executes authored SQL only. It is evidence that the
tested SQLite transaction can combine DDL/version/first row; it is not an
implementation or acceptance test for a production package migration.

## Source/caller evidence

- `source-provenance.json`: **42** exact Git snapshots with object/byte hashes;
  **11** exact equality checks to accepted prior source; **16** prior design,
  test, command, original result and harness-correction files copied unchanged;
  **five** complete searches of production/tool callers.
- `source-seams.json`: **56** complete AST symbol spans with source/span hashes.
- `source/`: the corresponding frozen files, including every current package
  model/budget/path/platform/worker module, KB attachment/recovery/port/scope,
  core creation/open/load, enrichment publication, object publication and specs.
- `references/`: retained originals from the earlier held-reader, native and
  core design packets. Their source-specific results stay historical and are
  not rerun or counted as new passes here.
- `later-core-constructor.diff`: separately identified exact `63ebc427` diff.
  It is not part of the frozen runtime authority or observation invocation.

Current five core files equal `9740860928c7911e6fa975528db1f7fa5ca1940b`;
three KB files plus its spec equal `d9a939911f39f3641bd5eed97a2ce067d618856b`;
two worker files equal `7259f86838c2181d6bdbcabe98c7a294a4499e8d`.
The public expected-ID/open/load additions are absent at this frozen source.
The core owner subsequently reported `441c47c2`; root reported review and porting
of its constructor-cleanup follow-up `63ebc427`. The latter preserves the primary
failure after ProjectLock returns, with no new adoption or cleanup authority.
Their reported 562-case author result is not this packet's test evidence.

## Review decisions requested

The proposal is complete enough for spec/test-first ownership review:

1. Lazy workspace v2 and one typed package table at the first accepted intent,
   with all package progress excluded from the old journal. Preserve base-v1
   reads/ordinary behavior and make failed transactions explicit.
2. Durable expected UUID and full source/member/side/revision/scope binding before
   core creation, complete actual ID/side-hash receipts, no reuse of foreign
   projects and no callback inserted before created-progress capture.
3. Verified non-recovering existing project scope before sidecars and rows,
   repeated identity checks, exact selected-row provenance compare/reuse and
   honest split-commit association states.
4. One-intent committed-project reconciliation without original inputs, generic
   repair, extraction, approval or creation; current and all selected captured
   saved-scope checks plus operation-specific investigation/progress CAS.
5. The explicit strict metadata envelope and proposed caps: 1 MiB intent/progress,
   at most six metadata objects, lower existing/captured per-object limits,
   original aggregate budget, 500 package records and 32 MiB aggregate record
   text per workspace. Broader inventory serialization remains valid pure data
   but can be refused by this deliberately narrower first admission envelope.

The plan names each proposed file/schema responsibility, legacy behavior,
unknown/foreign/committed outcomes, failure matrix and meaningful red/positive
acceptance groups. All production ownership still needs root review. Core and
native work remain separately owned. No alternate service or durable cleanup
authority is introduced through a JSON record.

## Artifact verification correction

The first seal verification stopped on a byte-for-byte comparison of a replayed
`rg` search. Parallel traversal returned the same complete filename/line/text
matches in a different order. The initial verifier and exact tool-returned
traceback are preserved in `seal_packet_first_attempt.py.txt` and
`seal-first-attempt.log`; `caller-order-diagnosis.json` confirms equal sorted
line multisets for all five searches. The corrected verifier retains both raw
outputs/hashes and compares those full multisets without dropping duplicates.
No source, original observation assertion or product test result changed, and
no product test was rerun for this artifact-only correction.

## Limits

No production test suite was rerun because production was not changed. No new
package schema was generated or installed. This packet does not qualify its
proposed facade, migrations, metadata limits or reconciliation; no passing
current-behavior observation is counted as future acceptance. Required source
tests/Ruff/registry/schema checks belong to the later implementation slices.

Native Windows locks, rooted reopening, FileIdInfo, rename, FDI ABI/callbacks,
Job/process transfer/termination, exact cleanup and a frozen full package journey
remain unqualified. Source hashes/receipts preserve evidence and cannot recreate
lost live authority. No release, main merge, remote update or package exposure
occurred.
