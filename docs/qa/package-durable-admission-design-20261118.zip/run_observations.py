from __future__ import annotations

import datetime
import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
QA = Path(__file__).resolve().parent
PYTHON = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
BASE = '195e04af27f7a724c6a2037363b7fe68df418a6b'


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


assert git('rev-parse', 'HEAD').decode().strip() == BASE
env_delta = {'PYTHONDONTWRITEBYTECODE': '1', 'PYTHONPATH': str(ROOT / 'src'),
             'PACKAGE_DESIGN_ROOT': str(ROOT),
             'PACKAGE_DESIGN_OBSERVATIONS': str(QA / 'workspace-version.observations.json'),
             'PACKAGE_DESIGN_IMPORTS': str(QA / 'workspace-version.imports.json')}
argv = [PYTHON, '-m', 'pytest', '-q', '-p', 'no:cacheprovider',
        '--confcutdir=' + str(QA), str(QA / 'test_workspace_version_observation.py'),
        '--junitxml=' + str(QA / 'workspace-version.xml')]
started = datetime.datetime.now(datetime.UTC).isoformat()
with (QA / 'workspace-version.log').open('xb') as output:
    run = subprocess.run(argv, cwd=ROOT, env={**os.environ, **env_delta}, stdout=output,
                         stderr=subprocess.STDOUT, check=False)
imports = json.loads((QA / 'workspace-version.imports.json').read_text())
checks = []
for item in imports['imports']:
    expected = hashlib.sha256(git('show', BASE + ':' + item['path'])).hexdigest()
    checks.append({**item, 'expected_sha256': expected, 'matches': expected == item['sha256']})
receipt = {'source': BASE, 'tree': git('rev-parse', BASE + '^{tree}').decode().strip(),
           'argv': argv, 'cwd': str(ROOT), 'environment': env_delta,
           'started_utc': started, 'finished_utc': datetime.datetime.now(datetime.UTC).isoformat(),
           'exit_code': run.returncode, 'import_checks': checks,
           'forbidden_attempts': imports['forbidden_attempts'],
           'scope': 'Frozen-current Linux SQLite observations; no proposed migration or native qualification'}
(QA / 'workspace-version.command.json').write_text(json.dumps(receipt, indent=2) + '\n')
assert all(check['matches'] for check in checks)
assert not imports['forbidden_attempts']
raise SystemExit(run.returncode)
