# PW-02 native worker and stage: concrete interface proposal

Status: design only, for root review. No source edits, native launch, SDK build,
package retrieval, package execution, new workflow or test rerun occurred in
this audit. Corrected source `645839646a68815ee1822ee61039af42d583903a` and its
QA-only tip `dc4ebf9ccf04abc284ffe334b858c6d39047b68d` remain unchanged. Root has
ported that slice to integration `27e4318b`; the inspected `jobs.py`, native
publication, ingestion, ProjectService, store, ports and wiring bytes are equal
between those two production bases. KB service admission differs on integration;
the report reviewer owns its current-source map.

## 1. Handoff choice and authority

| Approach | Concrete behavior | Decision |
| --- | --- | --- |
| Child opens the parent with PROCESS_DUP_HANDLE | Worker can duplicate any handle permitted by that process right; request JSON is only a convention. Microsoft explicitly documents duplication of the parent pseudo handle into a maximum-access process handle. | Reject the initial proposal. Do not grant this right or enable debug privileges. |
| Inherit every working file handle | An explicit list can restrict inheritance, but working duplicates are initially inheritable in the child and require later flag clearing. | Not preferred for working handles. |
| Parent duplicates into its already-owned suspended child | CreateProcessW gives the parent the actual process handle. After Job assignment, the parent duplicates only declared file handles with narrowed access and noninheritability. | Preferred. Reuse the existing supervisor; no parent-process handle reaches the worker. |

Primary sources: [process rights][process-rights], [DuplicateHandle][duplicate],
[handle inheritance][inheritance], [CreateProcessW][create-process]. This avoids
granting additional parent-process authority; it is not a claim that an ordinary
same-user worker is a security sandbox against arbitrary code execution.

### Proposed optional supervisor seam

The following types are proposed in `jobs.py`; they are in-process objects, not
serialized package or KB models. Type and range checks precede process creation.

```python
@dataclass(frozen=True)
class WindowsFileTransfer:
    token: str                     # unique bounded ASCII application token
    source_handle: int             # borrowed live parent file handle
    access: Literal['read', 'write', 'read_write']

@dataclass(frozen=True)
class WindowsHandoffReceipt:
    pid: int                       # captured from PROCESS_INFORMATION
    creation_ticks: int            # GetProcessTimes on that exact held process
    handles: tuple[tuple[str, int], ...]  # values valid only in that child

@dataclass(frozen=True)
class WindowsFileHandoff:
    bootstrap_handle: int          # parent's owned R/W request file
    transfers: tuple[WindowsFileTransfer, ...]
    prepare: Callable[[WindowsHandoffReceipt], None]

def run_process(..., windows_handoff: WindowsFileHandoff | None = None) -> ProcessResult: ...
```

`prepare` is trusted parent code and only receives the receipt, not a process
handle, permission to resume, or a child-provided handle to close. It performs a
bounded request write using the already-owned bootstrap handle, verifies the
complete bytes, resets its shared cursor to zero, and checks the original budget
and cancellation immediately before return. It raises on every failure. No
network, directory traversal, process launch or unbounded work belongs there.
The package wrapper retains an exact once-only receipt and rejects an injected
process result if the preparation step never ran.

The bootstrap is an ordinary private file with a hard 1 MiB first-capability
ceiling, separate from the inventory/result's 64 MiB ceiling. It contains the
strict request, source identity, worker grant and token/child-handle mapping.
All handles are positive bounded native integers; no pseudo handles, strings,
booleans, arbitrary access masks or worker-selected handles are accepted.
Limit the transfer table to 260 entries, each an ordinary non-reparse disk file.

### Exact lifecycle inside the existing Windows launcher

1. Under `_WINDOWS_SPAWN_LOCK`, create the existing bounded-output pipes. Duplicate
   the bootstrap as a read-only inheritable handle in the parent, without changing
   the original handle's inheritance flag. Use it as standard input. Ordinary
   callers retain NUL input.
2. Use STARTUPINFOEX and PROC_THREAD_ATTRIBUTE_HANDLE_LIST containing exactly that
   stdin handle and the stdout/stderr child ends. Do not fall back to unrestricted
   inheritance if an attribute API fails. Keep process/thread and Job handles
   noninheritable. The explicit list is required only by the opt-in seam initially;
   any wider supervisor migration is a separate change. The bootstrap/pipes have
   inheritable child ends because the documented handle-list API requires them;
   only these standard handles are inherited. The worker clears inheritance on
   all three before parsing package data. Working file duplicates are created
   noninheritable from the outset. Do not describe the inherited bootstrap as
   noninheritable before that child-side transition. [Handle list][handle-list]
3. Create the trusted internal worker suspended, apply the existing memory cap and
   kill-on-close/no-breakaway Job policy, then assign that exact process to the Job.
4. Query creation time on the returned process object. Duplicate each prevalidated
   source file into that process with the fixed role access mask, `bInheritHandle`
   false and options zero. Never use DUPLICATE_SAME_ACCESS or CLOSE_SOURCE.
5. Invoke `prepare` exactly once with the final mapping. It writes and verifies the
   bootstrap while the child cannot read it. Source bytes, roles, operation ID,
   request ID, original absolute deadline and remaining allowance are bound here.
6. Resume only after all preceding operations succeed. Require the fresh primary
   thread's expected suspend count; a contradictory result fails the attempt.
   Close only the parent's temporary inheritance duplicates and attribute storage.
7. Reuse the existing stream readers, output ceiling, cancellation and Job teardown.
   Require exit/no stop reason and full raw result length before package admission.
   A successful opt-in return must also establish bounded Job termination, rather
   than assuming the main process exit proves every descendant has exited.

The existing startup-error branch invokes TerminateProcess and a five-second wait
without checking their results. For this opt-in path, record/refuse termination
uncertainty and retain stage evidence; it cannot be silently treated as clean
shutdown. Query the Job's active-process count after termination and wait for zero
within the existing cleanup allowance. The parent never issues cleanup based on
a PID lookup or a worker claim. Before Job assignment, the never-resumed process
is the only possible child and must be observed terminated; after assignment,
the Job must also have zero active processes. No retry resumes an uncertain child. This is a
narrow lifecycle condition for the new handoff, not a second supervisor.

The result shape can stay `ProcessResult`: the opt-in path raises if successful
termination cannot be established. The package wrapper maps that failure to an
explicit retained/cleanup-uncertain outcome. Existing callers and default stdin
semantics remain unchanged. Non-Windows use of the opt-in seam refuses before
spawn; PW-02 itself already refuses before any input read or stage creation.

### Bootstrap and close ownership

The parent constructs the bootstrap from captured application records only. It
is not supplied by the CAB, filename, API response or child. The parent holds
its original R/W+DELETE handle with READ sharing; the child gets read access
only. There are no free-form paths to open, executable commands, parent-process
handles or permissions encoded by this request. Read at most 1 MiB plus one byte
before strict JSON validation, check exact request/source IDs and the native
file types/identities/roles, and refuse duplicate physical objects across source,
output and scratch roles. Missing/extra fields or handles refuse, not infer.

The parent tracks only native handles returned to the parent by successful native
calls. A child handle integer is never passed to the parent's CloseHandle. If
handoff fails after partial duplication, terminate/wait the owned child or Job
and let process teardown close those duplicates; do not guess individual remote
ownership or use CLOSE_SOURCE against child-supplied values. The worker closes
only its validated transferred handles and separately tracked callback-owned
resources. Malformed bootstrap fails before acting on arbitrary declared handles;
process exit releases its actual inherited/duplicated objects. A close error
prevents worker success; it is not retried using an uncertain reused integer.
The parent's original stage/source handles survive every worker close.

An opted-in caller retains all original file handles until supervision establishes
termination. On termination uncertainty it reports failure and leaves the known
stage entries for review, closing only its own local handles without deleting
those entries. There is no success receipt or project admission on that path.

## 2. Native handles and fixed access table

| Object | Parent retains | Child receives | Parent lifetime |
| --- | --- | --- | --- |
| Selected local source | Read/data/attributes/synchronize, no write or delete sharing; source/ancestor identities | Read/data/attributes/synchronize only | Through decoding and final source revalidation |
| Bootstrap request | Exclusive R/W+DELETE file under private root | Read-only stdin duplicate | Through confirmed child exit and owned cleanup |
| Selected payload | Exclusive R/W+DELETE, READ sharing only | Write/data/attributes/synchronize; no DELETE, append, ACL or owner rights | Through parent hash, native basename rename, every held-reader use and final outcome |
| Nested-container scratch | Exclusive R/W+DELETE, READ sharing only | Read/write data/attributes/synchronize; no DELETE/ACL rights | Through parent nested-file verification and exact cleanup |
| Root and side directories | Traversal/attributes, creation authority where needed, owned cleanup authority for exclusive roots | None | Until all owned children are disposed or retained |
| Process, thread and Job | Existing supervisor authority | None | Existing verified lifecycle |

Use explicit file masks (`read`: 0x00100081, `write`: 0x00100082,
`read_write`: 0x00100083), subject to actual Windows compatibility controls. These
are proposal masks, not a verified native receipt. Native file-query and I/O calls
must fail closed if the requested operations are unavailable. No package layer
requests an access upgrade.

Precreate a bounded scratch pool under the held stage before launching. At most
256 nested scratch slots and two selected files are needed by the captured first
capability ceiling; a grant exposes only its remaining allowed slots. This avoids
giving the worker a directory handle or relying on child-created names after a
crash. The parent knows every cleanup object before decoding starts. No temporary
file is reused for a different ownership token while a borrower is active.

Duplicates reference the same native file object and share its current file
position. The first implementation remains serial: explicit seek/read/write under
one stream lease, no simultaneous parent hash and worker access, and no concurrent
reader contexts for one file. A reader owns only its duplicate. Closing it never
closes the original stage handle. [DuplicateHandle][duplicate]

## 3. Stage implementation scope

Reuse `WindowsPublication` structures, rooted NtCreateFile behavior, native rename
and exact-handle disposition. Preserve its public byte-publication behavior and
research-tool seams. Its current directory helper uses OPEN_IF and lacks DELETE;
do not call that proof of exclusive attempt-root creation.

New `acquisition/package_stage.py` owns exclusive random attempt/side directories
using FILE_CREATE, a protected current-user/System DACL and held cleanup handles.
The directory API extension in `owned_publication.py`, if needed, must be explicit
and additive; it must not change ordinary directory opening or existing sharing.
All physical leaf names are application-generated opaque tokens. Archive names
never enter a native open or cleanup call. Names selected for handoff pass the
already-reviewed ASCII basename policy.

The stage must query native FILE_ID_INFO for the contract's 128-bit file ID, plus
size, last write, change time and attributes through held handles. Do not pad the
existing publication helper's 64-bit file index into a fabricated 128-bit
observation. Unknown/reparse/remote-volume identity refuses. The first native
qualification target is a local NTFS volume; other filesystems remain unavailable
until their required identity, rename and cleanup behavior has a passing probe.
This filesystem qualification condition belongs to the native capability, not to
the pure `require_supported_platform` function. [FILE_ID_INFO][file-id]

Every source path is anchored from a local volume through held ancestors and
checked for reparse processing; UNC or mapped remote inputs refuse. An initial
successful open is not itself proof of source hash or package authenticity. Full
source hashing and final state checks still run under the original deadline.

After child termination, hash the selected and relevant nested objects through
new read opens rooted in their still-held parent directories. Verify exact byte counts, content classification and owned
member mapping; only then construct reverified records. Rename a selected payload
through its same original DELETE-capable handle into its safe basename with
ReplaceIfExists false. Check immediately before/after and revalidate content after
handoff. Expected metadata changes caused by our rename are tracked as a phase
transition, never used to excuse an unrelated byte/identity change. The lock stays
held through project copying.

Cleanup visits only the parent's creation ledger in reverse ownership order,
using exact handle disposition. Retain unknown entries or any uncertain object;
never recurse through names to make a directory empty. A parent/root replacement,
foreign collision, inability to terminate the child, failed close or cleanup error
is an explicit incomplete outcome. Prior sources and committed projects survive.

## 4. FDI and shared accounting

`package_fdi.py` binds the pinned Microsoft header's exact Windows AMD64 ABI, keeps
all callback objects alive, and loads the system Cabinet DLL explicitly. Callback
IDs are application-owned tokens in a bounded table; an archive string is never a
native handle or a host pathname. Open/read/seek dispatch only to supplied source
or nested-container slots. Write dispatches only to a selected slot, a metadata or
nested slot, or a discard sink. A nested slot is not eligible for publication.

All emitted bytes, including discard and nested materialization, reserve budget
before write/copy and record actual completion. Declared sizes, fdintCLOSE_FILE_INFO
execution intent, continuation requests, spill requests, callback exceptions and
allocation ownership follow the approved first-slice rules. No target is executed.
Callback restrictions are application behavior verified by tests; they are not a
native AppContainer or network-isolation boundary.

`package_worker.py` gets one versioned grant from the parent's PackageBudget.
Parent and worker use the same supported system-wide monotonic clock and the
original absolute deadline, never a reset duration. The parent's check_output
hook observes that deadline even though run_process's elapsed clock begins after
spawn; checks also surround bootstrap preparation, result parsing and each parent
hash chunk. The worker checks before every callback and before reporting success.
Ordinary OS scheduling/I/O latency is not represented as a hard real-time bound.
[Python monotonic clock][clock]

Only one grant is outstanding. Its result must match operation/request/attempt,
source/decoder, exact child PID/creation ticks, expected token identities and the
remaining allowance. Reconciliation is monotone and once-only. Missing receipt,
crash, overspend, replay, malformed finite counts, output truncation or inconsistent
totals permanently fails the parent operation; no allowance is refunded for retry.
If the worker dies without a receipt, its consumption is unknown, not zero. Keep
the known parent counters and mark that attempt's delta unavailable. Poison the
operation so the unobserved remaining allowance cannot be reused. Do not invent
complete reserved/confirmed counts for an interrupted native callback stream.
Parent hashing and both pair sides spend the same work/time budget. Native
container output is additionally checked against the held objects; JSON alone
never proves that a claimed byte or handle existed.

The proposed new worker records are a narrow `acquisition/package_worker_contracts.py`
module, indexed before implementation; the existing source/member/inventory
models remain authoritative. Request fields include version, operation/request
ID, parent-observed child identity, source identity, requested mode/member,
application sink tokens, captured limits, original start/deadline and used/remaining
counts. Result fields include the same ownership IDs, decoder identity, explicit
complete/failed status, bounded observations, sink-token references and either a
validated consumption delta or explicit unavailable consumption. They do not
introduce alternate package, inventory or selected-member identities.

Budget grant issuance/reconciliation belongs to the existing PackageBudget (small
test-first additions, not a second budget implementation). A grant is a single
outstanding owner-bound lease; issuing while another grant or incomplete local
reservation exists refuses. Validate the entire returned delta before mutating
parent counts. Closed/replayed/foreign grants refuse. Failure marks the operation
failed; later cleanup may release only known resources. The child budget derives
from the original absolute clock and remaining counts through a documented
constructor path, not private state mutation or a fresh default PackageLimits.

The stage's public composition shape is an operation context with held sources,
precreated sink tokens, a prepared launch handoff, a post-worker verification/
promotion method and a cleanup outcome. A promoted member contains its exact
inventory/member receipt and an operation-owned HeldInput adapter. It is neither
a persistent file capability nor a worker-returned path. `packages.py` is the one
serial coordinator over those pieces; only the later KB facade writes metadata
or invokes existing project admission.

## 5. Held-reader boundary and ownership coordination

The report reviewer owns the precise KB/ProjectAttachment/ingestion seam at
`qa/pw02-kb-held-reader-design`. Native stage offers a serial borrowed reader only
after the worker has stopped and the selected object has been reverified/renamed.
It returns a read-only binary reader, exposes no native integer to KB domain code,
and checks the same held identity/state plus budget before/after and during reads.

The final reader uses a new rooted NtCreateFile FILE_OPEN of the exact application
basename, with read/data/attributes/synchronize access, no-reparse semantics and
sharing READ|WRITE|DELETE on that new read handle only. That sharing is required
to coexist with the original R/W+DELETE handle. The original handle continues to
share READ only, so it still refuses foreign write/delete opens; a permissive
sharing mask on a second read handle does not remove an existing lock. Compare
the new handle's full native FileIdInfo and state to the original, then perform a
complete second hash through the new reader. Parent and original leaf handles
stay alive, and the stage cannot close while a reader is borrowed. This supplies
an actual rooted name-to-object check and independent file-open/cursor, rather
than labeling DuplicateHandle alone as an independent pathname reopen.
[Native relative open][nt-create] [CreateFile sharing][create-file]

ReOpenFile documents compatible symmetric sharing, but its documented original
handle is CreateFile-created. Our stage is NT-created, so the proposed production
path uses the existing rooted NT mechanism, not an assumed ReOpenFile extension.
Default WindowsPublication read opens keep their current sharing. A narrow
`open_locked_reader(parent, name, original)` operation may be added for the stage;
it must validate the original, open read-only, compare identity, and close/refuse
the new handle on disagreement. There is no public unrestricted sharing override.

Inspection, both ProjectAttachment SHA checks, and immutable ProjectService copy
must all consume that operation-bound reader. Merely changing Env.inspect leaves
later pathname reopens. The original R/W+DELETE handle remains alive throughout;
ordinary Python pathname reopening must not be enabled by dropping locks or
widening the original sharing. The compatible rooted reader is the candidate,
with a mandatory actual Windows probe. [ReOpenFile][reopen] [Sharing rules][sharing]

| Proposed owner | Files / boundary | Scope |
| --- | --- | --- |
| ci_qualification | `acquisition/package_stage.py`, `package_fdi.py`, `package_worker.py`, `packages.py`; narrow new grant contracts/budget integration | Native handles, decoder callbacks, owned slots, worker protocol, parent validation and cleanup |
| ci_qualification, root-reviewed shared seam | `jobs.py`, `tests/test_jobs_windows_handoff.py`, precise architecture amendment | Optional suspended file-handle handoff only; ordinary launches unchanged |
| ci_qualification, root-reviewed additive native primitive | `owned_publication.py`, focused package-stage tests | Exclusive owned directory handle creation if existing primitives need a narrow extension; preserve all old publication seams |
| report_evidence_review design owner | Held-reader protocol, `ingestion.py`, top-level `service.ProjectService.create`, `kbcorrelation` inspection/attachment and factory injection | Exact data reader propagation and current admission/CAS/SQLite/provenance boundaries; implementation ownership assigned after combined review |
| later root-coordinated verification checkpoint | `persistence.py::_verify_files/save`, current project-owned verification calls | Neutral budget/read checkpoint before COMMIT; no alternate verification or raising post-save check in create rollback scope |
| root / existing KB owner | `kbcorrelation/service.py`, `context.py`, `index.py`, `saved_scope.py` | Existing scope/admission behavior; no independent replacement |
| coordinated later package facade | `kbcorrelation/package_service.py`, `package_store.py`, `cli_package.py`, ports/Env/wiring/CLI hooks | Compose reviewed native and current admission paths; no parallel service |

## 6. What proves each invariant

| Invariant | Native observation or mechanism | Additional protocol / limitation |
| --- | --- | --- |
| Child received only named transfer authority | Actual process handle, restricted inheritance list, fixed DuplicateHandle access and noninheritability | Token list binds purpose; it cannot sandbox an ordinary same-user process |
| Worker started under resource containment | Job settings/assignment precede ResumeThread; observed process creation identity | Receipt IDs label the observation; they cannot establish containment by themselves |
| Original source/output object stays held | Native handle and queried FileIdInfo, no-reparse rooted parents, retained original share lock | Hashes prove observed bytes; a file ID alone proves neither content nor authenticity |
| Renamed basename addresses the owned object | Native no-replace rename, fresh parent-rooted read open, matching file ID/state | ASCII basename policy is application validation; no path claim from JSON substitutes for the open |
| Output belongs to selected member | Known precreated sink, parent size/hash/content checks | Raw member identity, ancestry, ordinal and source binding require strict callback/protocol validation |
| Expanded work stayed within allowance | Job memory/time supervision plus actual write completions | Application callbacks reserve/count all exposed output; they do not observe opaque internal decompressor work |
| Both sides share one operation deadline | Same supported monotonic clock and parent-owned original deadline | Once-only serial grants and reconciliation prevent a protocol reset; OS latency is not hard real-time |
| Cleanup cannot delete a foreign pathname | Parent's creation ledger plus exact held disposition; no name-based recursive deletion | Uncertain termination/close/reparse/entry state is retained and reported |
| Source is Microsoft-authentic or the pair is a CVE fix | None provided by this capability | Signature remains unknown; scope, chronology, full-file/base requirements and existing KB admission remain explicit |

## 7. Required native controls and truthful completion

Portable tests first establish invalid-table refusal, prepare-once ordering,
failure before resume, no handle upgrades, original deadline, owned cleanup and
strict protocol reconciliation. They cannot qualify the native API behavior.

Actual Windows controls must record the real OS, interpreter/frozen build, source,
Cabinet DLL and process identities and demonstrate:

- Job assignment/cap before first worker instruction; explicit inheritance excludes
  an unrelated inheritable sentinel; source/selected/scratch access is exactly the
  needed access, and data handles are noninheritable. Missing capability refuses.
- Wrong source, reparse/remote input, exclusive-root collision, native rename
  collision, held FileIdInfo identity and foreign-entry preservation.
- Held R/W+DELETE output, native basename rename and a compatible rooted read open converted
  to the actual Python reader; repeated inspection/hash/project copy use that object
  while ordinary path opens cannot weaken the lock. A closed reader leaves the
  original valid. The native probe must show that the additional R|W|DELETE reader
  still leaves foreign write/delete opens denied by the retained original. Genuine
  close/rename sharing behavior is measured, not mocked. A duplicate-only rehash is
  not credited as the independent name-to-object reopen.
- Header ABI sizes/offsets, callback lifetime/failure sentinels, authored self-
  contained CAB/MSU, nested and discard accounting, malformed cabinets, execution-
  marked entries, continuations/spill refusal, deadlines, cancellation and worker
  failure, with confirmed Job termination and exact cleanup.
- The console-enabled onedir frozen build (the current Windows build flags) follows
  the same actual worker process/handle identity. A bootloader or runtime that forks
  to a different process without the required handles is unsupported; do not make
  handles broadly inheritable to hide that failure.
- One full frozen local-package pair journey through the existing admission and
  immutable project-copy path, plus Linux refusal before input/stage/spawn.

No capability advertises a usable decoder before its runtime probe succeeds.
Native compatibility and the frozen journey remain pending even after authored
portable tests pass. Original contracts, original failure and correction receipts
remain immutable and source-specific.

[process-rights]: https://learn.microsoft.com/en-us/windows/win32/procthread/process-security-and-access-rights
[duplicate]: https://learn.microsoft.com/en-us/windows/win32/api/handleapi/nf-handleapi-duplicatehandle
[inheritance]: https://learn.microsoft.com/en-us/windows/win32/procthread/inheritance
[create-process]: https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createprocessw
[handle-list]: https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-updateprocthreadattribute
[file-id]: https://learn.microsoft.com/en-us/windows/win32/api/winbase/ns-winbase-file_id_info
[reopen]: https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-reopenfile
[sharing]: https://learn.microsoft.com/en-us/windows/win32/fileio/creating-and-opening-files
[clock]: https://docs.python.org/3.12/library/time.html#time.monotonic
[nt-create]: https://learn.microsoft.com/en-us/windows/win32/api/winternl/nf-winternl-ntcreatefile
[create-file]: https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew
