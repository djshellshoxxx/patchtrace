# PW-02 joint interface and file ownership map

Pinned integration: `27e4318b87e0af3be0fc11a1906b86d95c44f46b`, tree
`d0d68f3fb82ceb2032d002f9023fadae67b89e78`. Corrected pure contracts are
`645839646a68815ee1822ee61039af42d583903a`; QA-only tip `dc4ebf9c`. This is a
design map, not implemented native or KB behavior. The native direction has been
accepted for staged work; the only next authorized production slice is the
portable serial worker-grant/receipt boundary, on a separate branch from
`068513a7`. Other rows below remain subject to their own review and native gates.

Detailed native design: [native-handoff.md](native-handoff.md). Independent KB
admission/design owner: `qa/pw02-kb-held-reader-design`. Its controls and original
harness correction remain in that separate packet; they are not native evidence.

## 1. Neutral held-reader contract

Proposed `src/patchtrace/input_readers.py`, Qt-free and standard-library-only:

```python
class HeldInput(Protocol):
    def check(self, path: Path) -> None: ...
    def open_reader(self, path: Path) -> ContextManager[BinaryIO]: ...

@dataclass(frozen=True)
class PairInputReaders:
    older: HeldInput
    newer: HeldInput
    checkpoint: ReadCheckpoint     # Callable[[int], None]; described below

class InputReadError(Exception):
    # A neutral typed reason preserves cancelled / limited / changed / unavailable
    # through acquisition, KB and core error mapping. Exact enum agreed in spec first.
    ...
```

`path` asserts equality with the operation's captured promoted name; it does not
authorize opening a new caller-selected path. The acquisition adapter opens from
its held native parent and application basename, verifies full FileIdInfo/state
against its retained original handle, and supplies a read-only independent
cursor. Each read/seek checks captured byte bounds and the original cancellation/
budget. Unbounded reads refuse. Entry/exit revalidate ownership. A borrower cannot
close the original; the owner cannot dispose the original with a live borrower.

The new rooted read handle uses READ|WRITE|DELETE sharing to coexist with the
original R/W+DELETE handle. The original keeps READ sharing only throughout.
Actual Windows probes must establish both compatibility and continued foreign
write/delete denial. DuplicateHandle alone is not an independently rooted reopen.
No native handles, streams or caller-supplied hash authority enter KB journals.

`ReadCheckpoint` is a neutral synchronous callable: zero checks the original
budget/cancellation; a positive strict byte count records a completed bounded
read against the same operation. The native leased reader calls it internally;
project-owned reads call it explicitly. A caller must not double-charge one read
through both routes. Its typed InputReadError preserves limit/cancel/refusal
through each layer. This is cooperative checking around bounded I/O, not an
assertion that OS I/O or SQLite commit can be preempted at an exact nanosecond.

## 2. Minimal propagation through the current route

All additions are optional and keyword-only. When absent, call existing injected
ports with their original arguments; do not break existing two-argument factories
or one-argument inspectors by passing an unnecessary `None` keyword.

| Existing call | Proposed change | Existing responsibility retained |
| --- | --- | --- |
| `KbService.import_pair` | `input_readers: PairInputReaders \| None = None`; forward both readers, check before `_approve_pair` | Current source snapshot, finite saved scope, revision, product/architecture and pair admission |
| `Env.inspect` → `wiring.inspect_local_file` | Optional `reader`; hash and inspect through `open_reader` | Actual bytes establish LocalFile; a supplied digest cannot bypass hashing |
| `Env.project` → `_project_factory` / `new_project_factory` | Optional bound pair, held on `RealProjectPort` | Existing resume versus create-only semantics and project directory registry |
| `ProjectAttachment.__init__`, `_begin`, `_create`, `_file_sha` | Optional pair/reader; every selected-source SHA check uses it | Existing two-phase attachment, CAS, immutable source checks and project-hash comparison |
| `RealProjectPort.create_project` | Pass bound pair only to new core creation | `ProjectPort.create_project(older_path, newer_path, *, directory)` remains unchanged |
| `ProjectService.create` | Optional pair; pass one reader to each `inspect_artifact`, check before initial save | Existing project lock, immutable artifact copies, first snapshot and owned rollback |
| `ingestion.inspect_artifact` | Optional source reader for source stat/fingerprint/open branch only | Project-owned destination stage validation, exclusive publication and existing-content checks |
| `ingestion.validate_pe` | Optional reader for parent validation of promoted package input | Full AMD64/PE32+ structural checks; project-owned stage validation still ordinary path-based |
| `ingestion.sha256_file` / `verify_artifact`, project-owned `validate_pe` | Optional neutral checkpoint around bounded reads | Existing complete byte verification is always performed; no alternate verifier or skip callback |
| `ProjectStore._verify_files` / `save` | Optional checkpoint propagated to verification, before BEGIN and immediately before COMMIT within the transaction | Existing schema, lock, snapshot validation and commit behavior; no raising post-save check inside create's rollback scope |

Same-descriptor fstat comparisons stay within one descriptor API. The native
adapter owns 128-bit identity, ChangeTime and rooted path binding; no direct
Windows path/fstat ctime equivalence is introduced.

## 3. Non-overlapping file ownership

| Slice | Assigned scope | Explicit boundary |
| --- | --- | --- |
| Next authorized portable worker boundary, ci_qualification | `acquisition/package_budget.py`, new `package_worker_contracts.py`, `tools/generate_package_schemas.py`, new worker schemas, focused `test_package_worker_*.py`, precise spec/module-index additions | No process, native I/O, KB or project-store edits; no new native acceptance |
| Later native/stage/worker, ci_qualification | `acquisition/package_stage.py`, `package_fdi.py`, `package_worker.py`, `packages.py`; focused native/mechanism tests | Uses the portable contracts; worker cannot write SQLite or create a project |
| Later shared native primitives, ci_qualification with root review | Additive `owned_publication.py` exclusive-directory and locked-reader primitives only if needed | Existing publication behavior, directory sharing and research seams unchanged |
| Later supervisor, ci_qualification with root review | Optional `jobs.py` handoff, new `test_jobs_windows_handoff.py`, architecture amendment | One executor; no child parent-process authority; existing ordinary launch behavior preserved |
| Held-reader design, report reviewer; implementation assignment follows review | `input_readers.py`; named sections of `ingestion.py`, top-level `service.py`, `kbcorrelation/wiring.py`, `kbcorrelation/service.py`, `kbcorrelation/store.py`; `test_input_readers.py`, `test_ingestion_held_inputs.py`, `test_kbc_held_input_admission.py` | No `context.py`, `index.py`, `saved_scope.py` or recovery edits; native adapters remain acquisition-owned |
| Later operation checkpoint, explicitly root-coordinated | `persistence.py::_verify_files/save`, existing verification calls, focused pre-commit/cancel tests | Optional neutral check and read accounting only; no alternate verification, snapshot schema or recovery change |
| Later package facade and persistence | `kbcorrelation/package_service.py`, `package_store.py`, `cli_package.py`, coordinated ports/Env/wiring/CLI hooks | Compose existing admission; no parallel KB service or generic recovery replacement |

The original pure-model schemas remain authoritative. Worker records add exact
operation/request/attempt/source ownership and serial budget evidence, without
defining alternate package/member/inventory identities. Native integers are
ephemeral worker transport only, never stored KB/project capabilities.

## 4. Two explicit prerequisites before full package admission

**Project-owned verification needs a neutral checkpoint beyond the source lease.**
`ProjectStore.save()` independently rehashes and validates new project-owned
copies through existing path readers. Its current size bounds are real, but these
passes do not consult the package operation budget per read. Therefore the
reader-only slice cannot establish the approved one-operation deadline/work
accounting across all parent hashing. The concrete proposed extension is the
ReadCheckpoint above, passed through project-copy stage/collision verification
and ProjectStore._verify_files/save. Check before/after bounded reads, before
BEGIN and immediately before COMMIT inside the existing transaction. This hook
requires its own specification and controls before implementation. Do not relabel
cooperative checks as a hard end-to-end pre-commit guarantee. Never add a raising
post-save checkpoint inside ProjectService.create's rollback scope; a later
budget/cancel observation cannot erase a completed SQLite commit.

**A committed project can precede the workspace's recorded project ID.** The
independent 27e source control demonstrates that an `after_project_create` fault
leaves a valid project while the workspace attachment journal is still `intent`
with `project_id=None`. Generic resume rehashes the selected paths, so an expired
temporary lease cannot be resurrected through that route. The package facade
needs its own bounded durable provenance/retained-project phase and verified
binding. Missing ownership stays unresolved; directory plus matching hashes alone
must not be claimed as proof that this package operation created a project.

Until those two boundaries have their own concrete reviewed contracts, the
native and portable worker slices cannot advertise complete PW-02 project import.
Preserve any committed project, retain diagnostics and report incomplete linkage.
There is no fake rollback, automatic generic recovery using expired paths, or
implicit re-download/restaging authorization.

## 5. Qualification order

The next portable slice uses spec and red tests first. It enforces one original
deadline, one outstanding owner-bound grant, exact source/operation/request/
attempt IDs, finite bounded counts, whole-delta validation before reconciliation,
monotone once-only accounting and permanent failure after missing/failed receipts.
Lost worker consumption is unavailable, not invented zero. JSON records alone do
not establish native I/O.

Subsequent native stage and supervised handoff require actual Windows OS/API,
share-mode, cleanup and SDK/FDI receipts. Existing baseline tests cannot count as
native qualification. Reader and full facade changes require the current saved-
scope/creation/attachment regressions plus new meaningful boundary controls. Final
acceptance remains an actual frozen local CAB/MSU pair journey, with no servicing,
hydration, network retrieval or target execution. Linux refusal remains explicit.
