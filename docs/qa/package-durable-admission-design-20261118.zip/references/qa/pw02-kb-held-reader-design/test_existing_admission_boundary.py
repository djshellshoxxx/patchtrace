"""Read-only-source PW02 design controls; authored bytes, no native execution."""
from __future__ import annotations

import builtins
import hashlib
import io
import json
import os
from pathlib import Path
import socket
import sqlite3
import subprocess
import sys
import threading

import pytest

from patchtrace.kbcorrelation import wiring
from patchtrace.kbcorrelation.store import WorkspaceStore
from patchtrace.sample import synthetic_pe
from patchtrace.service import ProjectService


OUTPUT = Path(os.environ['PATCHTRACE_PW02_REVIEW_OUTPUT'])
SOURCE = Path(os.environ['PATCHTRACE_PW02_REVIEW_SOURCE']).resolve()


@pytest.fixture(autouse=True)
def offline(monkeypatch):
    def denied(*_args, **_kwargs):
        raise AssertionError('the existing-admission probe cannot use network or children')
    for name in ('socket', 'create_connection', 'getaddrinfo'):
        monkeypatch.setattr(socket, name, denied)
    monkeypatch.setattr(subprocess, 'Popen', denied)


def pair(tmp_path):
    paths = []
    for side, variant in (('older', 0), ('newer', 1)):
        path = tmp_path / f'authored-{side}' / 'example.sys'
        path.parent.mkdir()
        path.write_bytes(synthetic_pe(variant))
        paths.append(path)
    return tuple(paths)


def record(name, body):
    OUTPUT.mkdir(parents=True, exist_ok=True)
    (OUTPUT / name).write_text(json.dumps(body, indent=2) + '\n')


def test_public_import_reads_every_existing_boundary_then_reopens_its_copies(tmp_path, monkeypatch):
    older, newer = pair(tmp_path)
    inputs = {str(older): 'older', str(newer): 'newer'}
    expected = {side: hashlib.sha256(Path(path).read_bytes()).hexdigest() for path, side in inputs.items()}
    opens = []
    connections = []
    owner = threading.get_ident()
    real_open, real_io_open, real_connect = builtins.open, io.open, sqlite3.connect

    def observed_open(real, file, *args, **kwargs):
        if isinstance(file, (str, os.PathLike)) and str(file) in inputs:
            frames = []
            frame = sys._getframe(1)
            for _ in range(12):
                if frame is None:
                    break
                path = Path(frame.f_code.co_filename)
                if path.is_relative_to(SOURCE):
                    frames.append({'file': str(path.relative_to(SOURCE)),
                                   'function': frame.f_code.co_name, 'line': frame.f_lineno})
                frame = frame.f_back
            opens.append({'side': inputs[str(file)], 'frames': frames})
        return real(file, *args, **kwargs)

    monkeypatch.setattr(builtins, 'open', lambda file, *args, **kwargs: observed_open(real_open, file, *args, **kwargs))
    monkeypatch.setattr(io, 'open', lambda file, *args, **kwargs: observed_open(real_io_open, file, *args, **kwargs))

    def connect(*args, **kwargs):
        connections.append(threading.get_ident())
        return real_connect(*args, **kwargs)

    monkeypatch.setattr(sqlite3, 'connect', connect)
    service = wiring.build_service(tmp_path / 'workspace')
    destination = tmp_path / 'project'
    result = service.import_pair('new', str(older), str(newer), str(destination))
    assert result.exit == 0
    for side in ('older', 'newer'):
        chains = [{item['function'] for item in opened['frames']} for opened in opens if opened['side'] == side]
        assert any('inspect_local_file' in chain for chain in chains)
        assert any({'_file_sha', '_begin'} <= chain for chain in chains)
        assert any({'_file_sha', '_create'} <= chain for chain in chains)
        assert any('inspect_artifact' in chain for chain in chains)
    assert connections and set(connections) == {owner}
    before_reopen = len(opens)
    older.unlink()
    newer.unlink()
    with ProjectService.open(destination, maintenance=False) as reopened:
        found = {artifact.side: artifact.sha256 for artifact in reopened.project.artifacts}
        assert found == expected
        project_id = reopened.project.id
    assert len(opens) == before_reopen
    record('public-read-chain.json', {'input_reads': opens, 'sqlite_connections': len(connections),
                                    'all_sqlite_on_caller_thread': set(connections) == {owner},
                                    'project_id': project_id, 'ordered_hashes': expected,
                                    'source_inputs_removed_before_successful_project_reopen': True,
                                    'scope': 'POSIX execution of existing ordinary path route only'})


def test_post_create_fault_retains_project_but_generic_intent_resume_rehashes_sources(tmp_path):
    older, newer = pair(tmp_path)
    expected = {side: hashlib.sha256(path.read_bytes()).hexdigest()
                for side, path in (('older', older), ('newer', newer))}
    destination = tmp_path / 'project'

    def fault(point):
        if point == 'after_project_create':
            raise RuntimeError('authored post-create interruption')

    service = wiring.build_service(tmp_path / 'workspace', fault=fault)
    with pytest.raises(RuntimeError, match='authored post-create interruption'):
        service.import_pair('new', str(older), str(newer), str(destination))
    with WorkspaceStore(service.root, create=False) as workspace:
        [(op_id, state, body)] = workspace.journal_ops()
        assert state == 'intent' and body['project_id'] is None
        investigation = body['revision']['investigation_id']
        initial_revision = workspace.current_revision(investigation).revision
    with ProjectService.open(destination, maintenance=False) as project:
        assert {item.side: item.sha256 for item in project.project.artifacts} == expected
        project_id = project.project.id
    older.unlink()
    newer.unlink()
    clean = wiring.build_service(service.root)
    result = clean.attach(str(destination), investigation, repair_it=True)
    assert result.exit == 3
    assert [item['code'] for item in result.result['issues']] == ['PT-KBC-VERIFY']
    with WorkspaceStore(service.root, create=False) as workspace:
        after_state, after_body = workspace.journal_get(op_id)
        assert after_state == 'intent' and after_body['project_id'] is None
        assert workspace.current_revision(investigation).revision == initial_revision
        interrupted = [attempt.model_dump(mode='json') for attempt in workspace.attempts(investigation)
                       if attempt.stage == 'interrupted:intent']
        assert len(interrupted) == 1
    with ProjectService.open(destination, maintenance=False) as project:
        assert project.project.id == project_id
        assert {item.side: item.sha256 for item in project.project.artifacts} == expected
    record('post-create-intent.json', {'op_id': op_id, 'project_id': project_id,
                                    'journal_state_before': state, 'journal_state_after': after_state,
                                    'journal_project_id_before': body['project_id'],
                                    'journal_project_id_after': after_body['project_id'],
                                    'repair_exit': result.exit, 'repair_issues': result.result['issues'],
                                    'interrupted_attempts': interrupted,
                                    'committed_project_retained_and_reopens': True,
                                    'scope': 'existing recovery boundary; no new package behavior implemented'})
