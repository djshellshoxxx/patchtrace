# PW-02: existing KB/project admission and held-reader design

Status: **read-only source investigation and proposed interfaces, for root review**.
No production source, schema, workflow, scanner policy, frozen outcome or remote
reference changed. Native Windows, FDI, packaged-worker and frozen journey evidence
remain pending. This packet complements the CI owner's
`qa/pw02-local-packages/native-seam-design/interface-map.md` and `native-handoff.md`.
The initial child-opens-parent proposal in that packet is historical; the current
native direction uses parent-to-suspended-child handle transfer only.

## 1. Source and observed evidence

Requested source: **`27e4318b87e0af3be0fc11a1906b86d95c44f46b`**.
The 27 exact source/spec snapshots, Git blob IDs, SHA-256 hashes and byte sizes are
in `source-provenance.json`; `source-seams.json` records 40 function/class locations
and current signatures. The live continuation advanced to `ccabe168` during this
review. Its `src` bytes equal the requested source; every imported PatchTrace module
was also checked individually against the requested commit.

Two external controls execute the existing public route using authored synthetic
PE bytes, actual workspace/project SQLite and immutable project copies:

| Control | Observation at the requested source |
| --- | --- |
| `test_public_import_reads_every_existing_boundary_then_reopens_its_copies` | Successful `KbService.import_pair('new', ...)`; eight selected-input read opens on this POSIX run, covering inspection, `_begin` hash, `_create` hash and ingestion for each side. All seven SQLite connections were opened on the calling thread. After deleting both authored source files, the project reopened with the original ordered artifact hashes. |
| `test_post_create_fault_retains_project_but_generic_intent_resume_rehashes_sources` | The real `after_project_create` fault point interrupts after a valid project save but before the attachment records its project ID. The journal remains `intent`, `project_id=None`. After source removal, normal `attach --repair` behavior returns exit 3 / `PT-KBC-VERIFY`, records one interrupted attempt, and preserves the valid project and investigation revision. |

Corrected harness: **2 passed, 0 skipped, 0.36 s; 58 pinned imports, no source
drift**. See `existing-admission-v2.{command.json,log,xml,imports.json,exit.json}`
and `existing-observations-v2/`. The first harness had two setup failures because
it replaced `socket.socket` before lazy standard-library `ssl` class creation.
The original file, runner, log, XML and import receipt remain untouched. V2 only
preloads `ssl` before denying socket construction; `harness-correction.json`
records that change. Neither setup failure is a product finding. The tests deny
network and child-process creation during product execution.

These are existing-path and recovery-boundary observations, not native sharing,
FDI, held-reader implementation or package-admission qualification.

## 2. Exact current call chain

All locations below refer to the requested commit and its retained snapshots.

| File / entry | Current behavior that the package route must retain |
| --- | --- |
| `kbcorrelation/service.py:106`, `Env` | Inspection and project factories are injected ports; the service itself remains Qt-free. |
| `kbcorrelation/service.py:742`, `import_pair(...)` | Inspects both paths before opening the workspace. Checks expected investigation revision, builds the full advisory index, compares the ordered source snapshot after reading, validates the saved search, checks scope/architecture and expected pair identity, then approves the pair. It retains the admitted index for context construction. |
| `kbcorrelation/service.py:466–509`, saved-scope helpers | Validate exact saved coverage, finite cached document IDs, readability and drift against full-global admission. Package input plumbing must not rebuild a subset admission index or replace these helpers. |
| `kbcorrelation/wiring.py:214`, `inspect_local_file(path, *, basename=None)` | Streams a full SHA-256 and size, retains a bounded header for architecture, and derives a safe name. The basename hint is not PE `OriginalFilename` authority. |
| `kbcorrelation/store.py:530,594,622`, `_file_sha`, `_begin`, `_create` | Rehashes both ordered inputs before journaling an intent, then rehashes them again before create/resume. Also verifies advisory source objects before intent publication. Changing inspection alone leaves these pathname reads. |
| `kbcorrelation/wiring.py:256,272`, `RealProjectPort` | Creates or opens a project through the existing core, returns actual ordered artifact hashes, then closes its service. `reuse_existing=False` is the desktop create-only policy and must survive reader injection. |
| `service.py:87`, `ProjectService.create` | Acquires the existing project store/lock, ingests both sides, constructs the project and saves once. Its `BaseException` rollback uses the exclusive-creation ledger and preserves preexisting/reused/foreign files. |
| `ingestion.py:57,154`, `file_fingerprint`, `inspect_artifact` | Ordinary sources are statted, fingerprinted, opened and rechecked. Windows fingerprinting opens the path again and obtains native ChangeTime. The copy is capped at 1 GiB, hashed while streamed, checked as AMD64 PE, published exclusively and recorded for owned rollback. |
| `ingestion.py:89,81,233` | `validate_pe`, `sha256_file` and `verify_artifact` validate project-owned copies. The completed stage and hash-collision destination are separate from the held package source. |
| `persistence.py:497,523,634` | `_verify_files`, `save` and `load` reverify immutable project files. First save hashes/validates project copies before committing; reopening verifies those copies without needing the original inputs. |
| `kbcorrelation/store.py:622–695` | Core save precedes the attachment's `created` journal write. Existing `_after_create`, `_cas`, sidecar and row publication then finish the documentary association. |
| `kbcorrelation/service.py:897`, `attach`; `recovery.py:48`, `repair` | Service preflights the current revision and every selected captured journal revision before generic recovery calls `mark_interrupted`. Preserve that order. Generic recovery can still mark unrelated unfinished operations; this slice does not claim broader isolation. |
| `kbcorrelation/investigation_service.py:407,507–538` | The task constructs its service on its own caller thread, checks cancellation before import, and reports a retained project if creation has begun. A task thread may own SQLite; the native package process may not. |

The default project port opens and closes the project within each call. It cannot
operate while the desktop already holds the project lock; the existing host
creation/adoption boundary continues to govern that lifetime. Do not pass an open
workspace, project store, connection or GUI service to the native child.

## 3. Minimal neutral runtime interface

Proposed new module: **`src/patchtrace/input_readers.py`**, stdlib only, no Qt,
acquisition imports, native integers, SQLite or filesystem cleanup.

```python
ReadCheckpoint = Callable[[int], None]
# 0: check the original operation deadline/cancellation.
# n > 0: account n bytes just read, then apply that same check.

class HeldInput(Protocol):
    def check(self, path: Path) -> None: ...
    def open_reader(self, path: Path) -> ContextManager[BinaryIO]: ...

@dataclass(frozen=True)
class PairInputReaders:
    older: HeldInput
    newer: HeldInput
    checkpoint: ReadCheckpoint

class InputReadError(Exception):
    # Fixed reason: cancelled, limited, changed, unavailable or invalid.
    # Bounded application text; never a raw native exception or handle value.
    ...
```

`PairInputReaders` is an operation-owned in-memory capability. Both sides are
required; there is no arbitrary pathname-to-reader registry or fallback for a
missing held side. It is never serialized into an attachment, package record,
workspace object, CLI envelope or task request. The package owner creates both
readers and the callback from the same parent operation/budget. Ordinary imports
omit the argument and retain their path behavior.

The `path` parameter is an equality/binding assertion against the operation's
captured promoted path. It is not authority for an open. The native adapter uses
its own retained parent handle and application-generated basename; it does not
resolve caller or journal text into a new trusted pathname.

The reader context owns only its new read handle/CRT stream. It checks the held
object and name binding at entry and exit, permits one borrower for an object,
and provides a read-only independent cursor. Each read must request a finite
nonnegative length no greater than 1 MiB; `read(-1)`, write/truncate and seeks
outside the captured file extent refuse. Bounded read/seek operations check the
same deadline/cancel callback. `fileno()` supports generic same-descriptor
`fstat` checks; the acquisition adapter retains responsibility for native
128-bit identity, ChangeTime and rooted namespace checks. A generic `fstat`
number is not substituted for those native observations.

The provider must close the reader once on normal exit and every failure, while
leaving the original stage handle open. Cleanup remains possible after the
budget fails; cleanup must not replace the first failure with a later cancellation
exception. Uncertain close or worker ownership prevents successful admission and
causes retained-stage reporting.

## 4. Native adapter agreement and proof boundary

The CI owner agrees to implement this protocol only after the native worker has
terminated and the selected output is reverified and renamed. The proposed new
reader is a **rooted `NtCreateFile(FILE_OPEN)`** of the exact application basename,
with read/data/attributes/synchronize access and sharing READ|WRITE|DELETE on that
new read handle. Its full FileIdInfo, size, last-write, ChangeTime and relevant
attributes must match the retained original. The original R/W+DELETE handle
continues to share READ only for the entire operation.

Microsoft documents bidirectional access/sharing compatibility and that an open
handle's sharing restrictions persist until it closes. Thus the proposed second
reader's compatible sharing does not itself remove the original restriction.
This is a source-backed design inference, **not an observed Windows result**.
Actual Windows controls must demonstrate the new reader works and foreign
write/delete opens remain denied while it is active. [CreateFileW][create-file]
[NtCreateFile][nt-create]

A `DuplicateHandle` rehash alone is insufficient for independent pathname
reopening: duplicates reference the same object and share its current file
position. A distinct rooted open binds the renamed basename to the original
object and has its own cursor. The documented `ReOpenFile` input originates from
`CreateFile`; do not assume that API expands its contract to the NT-created stage.
[DuplicateHandle][duplicate] [ReOpenFile][reopen]

No global `open` monkeypatch, lock dropping, widening of the original sharing,
or reader constructed from a serialized native integer is part of production.
The existing `WindowsPublication` normal read operation keeps its present policy;
an additive locked-reader primitive, if needed, belongs to the CI native owner.

## 5. Optional argument propagation and same admission path

Proposed signatures, preserving existing positional parameters and defaults:

```python
KbService.import_pair(..., input_readers: PairInputReaders | None = None)
inspect_local_file(path, *, basename=None, reader: HeldInput | None = None)
_project_factory(workspace, name, *, input_readers=None)
new_project_factory(workspace, name, *, input_readers=None)
RealProjectPort(..., reuse_existing=True, input_readers=None)
ProjectAttachment(workspace, project, *, input_readers=None)
_file_sha(path, *, reader=None)
ProjectService.create(older, newer, name, root, *, input_readers=None)
inspect_artifact(path, side, root, *, created=None, reader=None, checkpoint=None)
validate_pe(path, *, reader=None, checkpoint=None)
```

The `Env` inspector/factory annotations should express the optional keyword
contracts. The service passes new keywords only for an explicit held pair;
ordinary test ports and path callers keep their current call shape. Both real
factories accept the keyword while preserving their existing reuse/create-only
policy. Package composition uses that known-capable wiring, not a catch-TypeError
fallback to pathname I/O. `ProjectPort.create_project` itself remains unchanged:
the real port instance is bound to the ordered readers for that operation.

`import_pair` recomputes full bytes through its inspector, performs the same
expected revision/source/pair and saved-scope admission, and checks both reader
bindings immediately before `_approve_pair`. It then passes the same pair to the
project factory and attachment. `_begin` and `_create` retain their complete SHA
checks through the reader. No supplied receipt digest can skip these reads.

In ingestion, only the held-source observation/open branch is new. Native
identity validation comes from the reader, while the core retains same-descriptor
regular-file/size/change checks, copied-byte count, SHA calculation, PE validation,
exclusive publication and the existing `created` ledger. Ordinary path stat,
fingerprint and recheck logic remains intact. No root/package handle enters the
rollback ledger: the package owner retains those inputs, and ingestion owns only
its project staging/copy paths.

The package facade must compare the independently computed full ordered hashes
and promoted names to its selected materialized members before admission. An
existing dry-run pair preview can establish `expected_pair_id`; actual import
must enforce that ID together with the captured revision/source snapshot. This
reuses current pair policy and avoids treating raw package metadata as a verified
pair. Neither the reader nor package presence upgrades product membership,
chronology, signature, vulnerability attribution or function confidence.

## 6. Original-operation checkpoints through core verification

The reader alone leaves a concrete deadline gap: `ProjectStore.save` reads the
new immutable copies through normal path functions. Their size is bounded, but
at this source they do not observe the package deadline/cancellation. The narrow
additional proposed hook is:

```python
sha256_file(path, *, checkpoint: ReadCheckpoint | None = None)
verify_artifact(artifact, root, *, checkpoint=None)
ProjectStore._verify_files(project, *, checkpoint=None)
ProjectStore.save(project, *, checkpoint=None)
```

`ProjectService.create` forwards `input_readers.checkpoint` to ingestion's
project-owned stage/possible collision verification and to its initial
`store.save`. `_verify_files` forwards it through `verify_artifact` and any actual
raw-file hash. `validate_pe` uses the same callback for its bounded header/section
reads. Metadata/fingerprint operations check the deadline before and after;
existing verified-file cache rules are unchanged, with checks even on a cache hit.

Every bounded path read checks with `checkpoint(0)` first and reports its actual
returned byte length afterward. Source-reader I/O is already charged by the
lease and must not be charged a second time by its caller. In particular,
`validate_pe(reader=...)` uses the lease's charging rather than an additional
path-read charge. Hashing, PE validation, partial reads and project-copy checks
all keep their byte/size validation; the callback cannot authorize a short read.

**Read work and expanded output are separate counters.** A positive read count
increments a finite `UINT64_MAX` core/read-work byte ledger and consumes the
original parent's callback/work allowance through `PackageBudget.callback()`.
It also observes that budget's original monotonic deadline and cancellation token.
This read ledger includes PE/header reads, so it must not silently change the
meaning of the existing `PackageUsage.hashed_input_bytes` field: native hash
accounting stays hash-specific, and a later facade receipt labels read work
separately. The neutral core slice can test the callback without changing package
grant/receipt schemas. The 1 GiB artifact/entry size and 1 MiB read chunk bound each
source/read. There is no new aggregate read-byte cap being silently claimed:
repeated hashes may read more bytes than the 8 GiB expanded-output allowance.
Reads neither consume nor refund decompressor output reservations; only actual
extraction write reservation and completion use that output ledger. No new side
or hash gets a fresh timer.

### Transaction boundary

Checks occur before verification, between bounded reads, after verification and
serialization before starting a save transaction, and **inside the transaction
immediately before successful COMMIT**. A cancellation/deadline exception there
rolls the transaction back and follows existing creation ownership cleanup.

**No potentially raising checkpoint runs after successful commit inside
`ProjectService.create`'s creation-rollback `try`.** A check after `store.save`
that raised into the existing `except BaseException` could wrongly invoke
creation deletion for a committed project. After commit, cancellation/timeout
belongs to the outer package outcome: report the retained project and incomplete
association, release only owned temporary readers/stage objects, and never enter
creation rollback. SQLite commit and individual OS calls remain cooperative
boundaries, not hard real-time interruption guarantees.

This adds a precise optional `persistence.py` verification/save seam to the later
core slice. It is not part of the CI owner's approved portable grant work, and no
such production edit is made by this packet.

## 7. Workspace capture, SQLite ownership and stale work

1. Require supported Windows AMD64/native capability before package reads,
   staging, process launch or workspace writes. The Linux refusal is separate.
2. On the eventual service caller thread, capture the anchored workspace identity,
   exact investigation JSON/revision, selected product, ordered advisory SourceDoc
   JSON and the saved finite scope. Read/validate saved coverage through the
   existing `_checked_index`/`_stored_scope` path before package metadata writes.
3. Close any capture-only store before child work. The native process receives
   only bounded pure records and allowlisted native file transfers, never SQLite
   or a service. Its decoded/source claims cannot edit advisory rows.
4. Materialize both selected sides under the same parent budget. Confirm worker
   termination, rooted identity, full independent hash and complete AMD64 PE.
   Keep both original output handles and parent guards until synchronous import
   and outcome capture complete. No project starts after only one side succeeds.
5. On the same service caller thread, recheck the workspace anchor and captured
   owner, then invoke the current `import_pair` with expected revision/source/pair
   and the held pair. Its full-global index admission and saved-scope checks run
   before approvals/journal/project creation; retain that admitted index thereafter.
6. A source or revision change before admission refuses without new approval,
   attachment or project writes. Existing admission is not an atomic lock across
   the entire native operation: changes after the checked boundary do not rebuild
   the admitted context. Preserve the current documented policy and CAS behavior.
7. Before the first mutation, cancellation has no project/approval effect. After
   admission begins, append-only progress may already exist. Before core commit,
   observed cancellation follows owned rollback. After core commit, retain/report
   the project. Do not describe every late cancellation as “nothing imported.”

The desktop's existing generation/request/adoption guard remains authoritative.
The package outcome is immutable data; a stale callback may report a retained
path but cannot adopt it into an unrelated open project.

## 8. Durable package provenance: separate facade decision

This section is a **concrete later composition proposal**, not part of the
neutral reader/checkpoint implementation. The external second control establishes
why a live lease plus the current generic journal cannot by itself guarantee
post-crash package provenance repair.

### Durable identity and publication order

1. After both members and the current saved scope/source owner pass validation,
   persist a strict bounded package intent in a separate package metadata store.
   Bind: workspace/investigation owner, original header inventory IDs, exact
   selected source/member/ancestor/side records, distinct materialized inventory
   IDs, complete observed/rehash digests and sizes, safe promoted names, admitted
   pair ID, destination ownership capture, and a **preallocated project UUID**.
   Package records stay outside advisory `docs`, ordered advisory snapshots and
   `AttachRequest.source_shas`; payload files never enter the gzip metadata API.
2. Carry that expected project UUID through the bound real project port to an
   optional `ProjectService.create(..., project_id=...)` argument. It uses the
   existing project ID field; no project schema change is needed. The default
   still generates an ID. The package facade validates the generated UUID and
   existing core identity/ownership rules still apply.
3. The existing attachment intent additionally binds bounded plain fields for
   package intent ID, expected project ID and `input_mode='held'`. This marker
   grants no native authority. Missing live readers for an unfinished held-input
   create must refuse before opening its stored source paths. Ordinary journals
   keep their current interpretation.
4. Use the existing approval, `_begin`, `_create`, core save and documentary
   association sequence. Require the real port's returned project ID and both
   actual artifact hashes to equal the intended values; no default-to-expected
   digest fallback is allowed for this new package route. First save commits the
   preallocated ID, closing the identity ambiguity between core commit and the
   attachment's later `created` journal update.
5. Once the real project is known committed, record the package intent's created
   phase, then publish an idempotent bounded project provenance row keyed by the
   intent and ordered artifacts. Preserve source/header/materialized inventory
   IDs as distinct lineage. Finally mark the package intent linked. A failed
   row or final marker leaves “project retained; package association pending.”
   It does not erase the project or convert pending provenance into success.

The preallocated UUID is an operation identity, not protection against arbitrary
same-user rewriting of project bytes. Destination/parent ownership and the normal
project lock still matter. A preexisting foreign project with matching hashes is
not sufficient to accept an intent.

### Explicit reconciliation, without broad recovery changes

| Durable state / observation | Allowed next action |
| --- | --- |
| No committed expected project, live verified readers still owned | Revalidate scope/current owner and use the existing import/attachment path. |
| No committed expected project, lease expired after process exit | Refuse source resurrection. Require a fresh explicit package operation and source/member revalidation; do not reopen journal paths as a substitute for the lease. |
| Attachment says `created`/`done`, package row or linked marker missing | Reopen and verify the exact project ID/ordered immutable copies; publish the same missing metadata row or completion marker idempotently. No extraction, pair reapproval or second project. |
| Core committed expected ID but attachment is still `intent` | Package-only reconciliation verifies that actual committed project read-only, then completes the existing attachment's created transition and resumes its existing context/CAS path. The package intent/expected ID makes this distinguishable from a foreign directory. |
| Missing, contradictory, unreadable or foreign project/metadata | Retain project/stage evidence and report unresolved association. No deletion, blind adoption or “repaired” label. |

Concrete additional interfaces for that later slice should be a read-only
`RealProjectPort.verify_created_project(directory, expected_project_id,
expected_ordered_hashes)` and a narrowly guarded
`ProjectAttachment.reconcile_created(op_id, ...)`. The latter accepts only the
package-bound unfinished journal, obtains the verified project through the
trusted port, writes the same `created` journal shape and calls existing
`resume`/`_after_create`. It must not create a project, reapprove a pair or invent
reader handles. The generic `recovery.repair` algorithm need not change.

Read-only reconciliation must use the existing
`ProjectStore.load(recover_interrupted=False)` behavior or an explicitly equivalent
port: `ProjectService.open(maintenance=False)` alone disables raw cleanup but
still calls ordinary `load()`, which may recover queued/running runs. Validate
foreign identity before any logical project mutation. Scope preflight of the
current and selected captured revisions still precedes every recovery write.

These facade fields/ports and additive package storage need root's separate
specification/ownership review. The reader/checkpoint slice must not quietly
implement a new creation-identity or recovery protocol.

## 9. Proposed file ownership and acceptance

| Later slice / owner | Exact files and bounded sections |
| --- | --- |
| Neutral reader/checkpoint, root to assign | New `input_readers.py`; `ingestion.py` source reader branch and optional `validate_pe`/`sha256_file`/`verify_artifact` checks; `service.py::ProjectService.create` argument forwarding and precommit lifetime; `persistence.py::_verify_files/save` optional checks. |
| Existing KB reader propagation, root to assign | `kbcorrelation/service.py::Env/import_pair`; `wiring.py::inspect_local_file/RealProjectPort/factories`; `store.py::_file_sha/ProjectAttachment`. No context/index/saved-scope policy changes. |
| Native adapter / CI owner, not yet assigned for implementation | `package_stage.py`, FDI/worker/native package composition, optional `jobs.py` handoff and additive `owned_publication.py` native primitive. All native integers stay here. |
| Approved current CI work | Portable serial worker-grant/receipt contracts and `package_budget.py`, schema generator, tests/spec/module entry, from the separately assigned source. No core/KB/native edits in that slice. |
| Durable package facade, root to assign separately | New package facade/store/CLI composition; expected project ID and held-input journal marker; bounded read-only committed-project verification and explicit reconciliation. Requires the section 8 contract before source. |

Proposed focused tests:

| Area | Meaningful controls before implementation |
| --- | --- |
| `tests/test_input_readers.py` | Both ordered readers required; wrong path/side, closed or overlapping lease, invalid read/seek, bounded error categories; reader close never closes original; no serializer/native-value leakage. |
| `tests/test_ingestion_held_inputs.py` | Actual synthetic PE copy with every selected-source pathname open denied; full hash and descriptor/native-provider checks; late PE header, short read, changed identity, cancellation/limit during either side; exact owned rollback and foreign/preexisting preservation. Normal path controls unchanged. |
| `tests/test_creation_operation_checkpoint.py` | Same callback reaches stage PE validation, collision hash, first-save SHA/PE verification and transaction. Cancel/expire during each read phase and immediately before COMMIT rolls back owned creation; cached verification still checks; positive counts match actual reads and never alter output reservations. A post-commit cancel yields retained project, not rollback. |
| `tests/test_kbc_held_input_admission.py` | Real default wiring/SQLite route uses readers at all four boundaries; wrong expected hash/pair, invalid saved scope, source/revision drift before/during read refuse before approval; global tied/negative/withdrawn admission unchanged; cached empty scope works; every SQLite connection belongs to service caller thread. Reopened project needs no source lease. |
| Later package provenance controls | Every boundary before/after intent, first save, created journal, provenance row and final marker; source lease expiry; wrong project ID even with matching hashes; swapped sides; source/header/materialized receipt mismatch; repeated repair is idempotent and does not create/extract/reapprove; stale captured/current scope prevents recovery writes; foreign queued runs remain untouched during refusal. |
| Native Windows controls, CI owner | Real retained R/W+DELETE/READ-share handle, native basename rename, rooted compatible read open, full ID/state comparison, denied foreign write/delete, closed reader/original lifetime, actual CRT reads and full real project copy/reopen. Record real OS/build/source/process/decoder identities. |

Required neighboring regressions include current ingestion, project creation and
rollback/retry, KBC service/store/CLI, acquisition source admission, saved-scope
current/all-captured journal preflight and desktop create-only adoption. Run only
the relevant gate after source exists, with absolute source pinning; this read-only
packet does not claim those future checks have passed.

[create-file]: https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew
[nt-create]: https://learn.microsoft.com/en-us/windows/win32/api/winternl/nf-winternl-ntcreatefile
[duplicate]: https://learn.microsoft.com/en-us/windows/win32/api/handleapi/nf-handleapi-duplicatehandle
[reopen]: https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-reopenfile
