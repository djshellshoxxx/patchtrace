"""Observe frozen core boundaries with authored PE bytes and real SQLite only.

These are current-behavior controls, not acceptance tests for proposed APIs.
"""
from __future__ import annotations

import hashlib
import inspect
import json
import os
from pathlib import Path
import sqlite3
import threading

import pytest
from held_input_support import authored_pair, deny_source_opens

from patchtrace import ingestion, persistence
from patchtrace.ingestion import inspect_artifact
from patchtrace.models import AnalysisRun, ComparisonProject
from patchtrace.persistence import ProjectStore
from patchtrace.sample import synthetic_pe
from patchtrace.service import ProjectService

OUTPUT = Path(os.environ['PATCHTRACE_CORE_DESIGN_OUTPUT'])


def observe(name, value):
    OUTPUT.mkdir(parents=True, exist_ok=True)
    path = OUTPUT / f'{name}.json'
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def paths(tmp_path):
    result = []
    for side, variant in (('older', 0), ('newer', 1)):
        path = tmp_path / f'{side}.sys'
        path.write_bytes(synthetic_pe(variant))
        result.append(path)
    return result


def pair(project):
    sides = {artifact.side: artifact.sha256 for artifact in project.artifacts}
    return sides['older'], sides['newer']


def snapshot(root):
    database = root / 'project.sqlite3'
    db = sqlite3.connect(database.as_uri() + '?mode=ro&immutable=1', uri=True)
    try:
        current = db.execute('SELECT payload,sha256 FROM current_snapshot').fetchone()
        rows = db.execute('SELECT sequence,revision,payload,sha256 FROM history ORDER BY sequence').fetchall()
        version = db.execute('PRAGMA user_version').fetchone()[0]
    finally:
        db.close()
    return {'database_sha256': hashlib.sha256(database.read_bytes()).hexdigest(),
            'current': current, 'history': rows, 'schema_version': version}


def queued_project(tmp_path):
    older, newer = paths(tmp_path)
    root = tmp_path / 'project'
    with ProjectService.create(older, newer, 'authored', root) as service:
        candidate = service.project.model_copy(deep=True)
        candidate.runs.append(AnalysisRun(status='queued', backend='authored', backend_version='none'))
        service.store.save(candidate)
    return root


def test_existing_model_and_store_commit_a_preallocated_identity_without_schema_change(tmp_path, monkeypatch):
    older, newer = paths(tmp_path)
    expected = '8c240bc9-3fbb-40db-bbf4-1e2240a0c1b8'
    root = tmp_path / 'project'
    owner = threading.get_ident()
    calls = []
    actual_connect = sqlite3.connect

    def connect(*args, **kwargs):
        calls.append(threading.get_ident())
        return actual_connect(*args, **kwargs)

    monkeypatch.setattr(sqlite3, 'connect', connect)
    with ProjectStore(root, create=True) as store:
        assert store.project_id is None
        artifacts = [inspect_artifact(older, 'older', root), inspect_artifact(newer, 'newer', root)]
        made = store.save(ComparisonProject(id=expected, name='authored preallocation', artifacts=artifacts))
        assert store.project_id == made.id == expected
        expected_pair = pair(made)
    before = snapshot(root)
    older.unlink()
    newer.unlink()
    with ProjectStore(root) as store:
        loaded = store.load(recover_interrupted=False)
        assert loaded.id == store.project_id == expected and pair(loaded) == expected_pair
    assert snapshot(root) == before
    assert calls and set(calls) == {owner}
    assert 'project_id' not in inspect.signature(ProjectService.create).parameters
    assert 'expected_project_id' not in inspect.signature(ProjectService.create).parameters
    observe('existing-preallocated-id', {'id': expected, 'ordered_hashes': expected_pair,
            'schema_version': before['schema_version'], 'snapshot_sha256': before['current'][1],
            'same_thread_sqlite_connections': len(calls), 'public_create_option_present': False,
            'scope': 'Existing lower-level model/store capability only; no alternate admission implementation.'})


def test_equal_ordered_hashes_do_not_identify_the_same_project_and_create_preserves_foreign(tmp_path):
    older, newer = paths(tmp_path)
    roots = [tmp_path / name for name in ('first', 'foreign')]
    records = []
    for root in roots:
        with ProjectService.create(older, newer, root.name, root) as service:
            records.append({'id': service.project.id, 'pair': pair(service.project)})
    assert records[0]['id'] != records[1]['id']
    assert records[0]['pair'] == records[1]['pair']
    before = snapshot(roots[1])
    with pytest.raises(ValueError, match='project database already exists'):
        ProjectService.create(older, newer, 'must not replace', roots[1])
    assert snapshot(roots[1]) == before
    observe('same-pair-foreign-project', {'projects': records, 'foreign_snapshot_unchanged': True})


def test_explicit_no_recovery_load_leaves_queued_run_snapshot_and_history_unchanged(tmp_path):
    root = queued_project(tmp_path)
    before = snapshot(root)
    traced = []
    with ProjectStore(root) as store:
        store.connection.set_trace_callback(traced.append)
        project = store.load(recover_interrupted=False)
        assert project.runs[-1].status == 'queued'
        assert project.id == store.project_id
    assert snapshot(root) == before
    assert not any(sql.lstrip().upper().startswith(('INSERT ', 'UPDATE ', 'DELETE ', 'BEGIN', 'COMMIT'))
                   for sql in traced)
    observe('explicit-no-recovery', {'project_id': project.id, 'status': project.runs[-1].status,
            'database_sha256': before['database_sha256'], 'history_rows': len(before['history']),
            'snapshot_and_history_unchanged': True, 'sql': traced,
            'lock_file_excluded_from_nonmutation_claim': True})


def test_maintenance_false_open_still_recovers_a_queued_run(tmp_path):
    root = queued_project(tmp_path)
    before = snapshot(root)
    with ProjectService.open(root, maintenance=False) as service:
        assert service.project.runs[-1].status == 'failed'
        project_id = service.project.id
    after = snapshot(root)
    assert after['current'] != before['current']
    assert len(after['history']) == len(before['history']) + 1
    observe('maintenance-false-recovery', {'project_id': project_id, 'stored_status_after': 'failed',
            'history_rows_before': len(before['history']), 'history_rows_after': len(after['history']),
            'scope': 'Expected existing default startup recovery; maintenance=False disables raw cleanup only.'})


def test_postcommit_copy_reopen_does_not_receive_the_creation_checkpoint(tmp_path, monkeypatch):
    with authored_pair(tmp_path) as (inputs, readers):
        root = tmp_path / 'project'
        with ProjectService.create(*inputs, 'authored held creation', root, input_readers=readers) as service:
            expected_id, expected_pair = service.project.id, pair(service.project)
        before = snapshot(root)
        baseline = list(readers.checkpoint.counts)
        readers.checkpoint.stop = lambda count, kind: True
        for path in inputs:
            path.unlink()
        deny_source_opens(monkeypatch, inputs)
        read_calls, file_options = [], []
        real_read, real_verify = ingestion._read, ProjectStore._verify_files

        def read(stream, size, checkpoint=None):
            data = real_read(stream, size, checkpoint)
            read_calls.append({'requested': size, 'returned': len(data), 'has_checkpoint': checkpoint is not None})
            return data

        def verify(store, project, **kwargs):
            file_options.append(bool(kwargs.get('checkpoint')))
            return real_verify(store, project, **kwargs)

        monkeypatch.setattr(ingestion, '_read', read)
        monkeypatch.setattr(ProjectStore, '_verify_files', verify)
        with ProjectService.open(root, maintenance=False) as reopened:
            assert reopened.project.id == expected_id and pair(reopened.project) == expected_pair
        assert file_options == [False]
        assert read_calls and not any(item['has_checkpoint'] for item in read_calls)
        assert sum(item['returned'] for item in read_calls) >= sum(lease.captured[2] for lease in (
            readers.older, readers.newer))
        assert readers.checkpoint.counts == baseline
        assert snapshot(root) == before
        observe('postcommit-copy-read-gap', {'project_id': expected_id, 'ordered_hashes': expected_pair,
                'read_calls': read_calls, 'creation_checkpoint_called_after_close': False,
                'committed_snapshot_unchanged': True, 'source_inputs_removed': True,
                'scope': 'Known missing propagation into open/load, not a claim that a current API promises it.'})


@pytest.mark.parametrize('phase', ['save-return', 'constructor'])
def test_exception_after_real_commit_preserves_actual_identity_and_copies(tmp_path, monkeypatch, phase):
    inputs = paths(tmp_path)
    root = tmp_path / 'project'
    saved = []
    real_save = ProjectStore.save

    def save(store, project, **kwargs):
        result = real_save(store, project, **kwargs)
        assert not store.connection.in_transaction
        saved.append({'id': result.id, 'pair': pair(result), 'revision': result.revision})
        if phase == 'save-return':
            raise RuntimeError('authored after-commit boundary')
        return result

    class FailingConstructor(ProjectService):
        def __init__(self, *args, **kwargs):
            raise RuntimeError('authored after-commit boundary')

    monkeypatch.setattr(ProjectStore, 'save', save)
    service_type = FailingConstructor if phase == 'constructor' else ProjectService
    with pytest.raises(RuntimeError, match='authored after-commit boundary'):
        service_type.create(*inputs, 'retained', root)
    assert len(saved) == 1 and (root / 'project.sqlite3').is_file()
    for path in inputs:
        path.unlink()
    with ProjectStore(root) as store:
        actual = store.load(recover_interrupted=False)
        assert actual.id == saved[0]['id'] and pair(actual) == saved[0]['pair']
    observe(f'committed-failure-{phase}', {'observed': saved[0], 'project_retained': True,
            'source_inputs_removed': True, 'validated_after_exception': True})


def test_same_project_identity_does_not_replace_ordered_side_hash_checks(tmp_path):
    inputs = paths(tmp_path)
    root = tmp_path / 'project'
    with ProjectService.create(*inputs, 'orientation', root) as service:
        original_id, original_pair = service.project.id, pair(service.project)
        service.swap_orientation()
        assert service.project.id == original_id
        assert pair(service.project) == tuple(reversed(original_pair))
    with ProjectStore(root) as store:
        loaded = store.load(recover_interrupted=False)
        assert loaded.id == original_id and pair(loaded) != original_pair
        observe('ordered-pair-identity', {'id': original_id, 'before': original_pair,
                'after': pair(loaded), 'revision_after': loaded.revision})
