"""Verify and seal this read-only design without running product code."""
from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
QA = Path(__file__).resolve().parent
BASE = '195e04af27f7a724c6a2037363b7fe68df418a6b'
DESIGN = 'efe68b18654459e704d358d64423fbc1820afc0a'


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


authority = json.loads((QA / 'source-provenance.json').read_text())
for item in authority['git_snapshots']:
    raw = git('show', BASE + ':' + item['path'])
    assert sha(raw) == item['sha256']
    assert (QA / item['stored']).read_bytes() == raw
for item in authority['equalities']:
    raw = git('show', item['reference'] + ':' + item['path'])
    current = git('show', BASE + ':' + item['path'])
    assert sha(raw) == item['reference_sha256'] == item['current_sha256']
    assert raw == current
for item in authority['references']:
    assert sha(Path(item['original']).read_bytes()) == item['sha256']
    assert sha((QA / item['stored']).read_bytes()) == item['sha256']
caller_replays = []
for item in authority['caller_searches']:
    assert sha((QA / item['stored']).read_bytes()) == item['sha256']
    replay = subprocess.run(item['argv'], cwd=ROOT, capture_output=True, check=False)
    assert replay.returncode == item['exit_code']
    original = (QA / item['stored']).read_bytes()
    assert sorted(replay.stdout.splitlines()) == sorted(original.splitlines())
    target = QA / 'caller-searches' / (item['name'] + '.replay.txt')
    target.write_bytes(replay.stdout)
    caller_replays.append({'name': item['name'], 'original_sha256': sha(original),
                           'replay_sha256': sha(replay.stdout),
                           'stored': target.relative_to(QA).as_posix(),
                           'line_multiset_equal': True, 'matches': len(original.splitlines())})
(QA / 'caller-search-replay.json').write_text(json.dumps(caller_replays, indent=2) + '\n')
seams = json.loads((QA / 'source-seams.json').read_text())
for item in seams:
    raw = (QA / 'source' / item['path']).read_bytes()
    span = b''.join(raw.splitlines(keepends=True)[item['start'] - 1:item['end']])
    assert sha(raw) == item['source_sha256']
    assert sha(span) == item['sha256']
command = json.loads((QA / 'workspace-version.command.json').read_text())
assert command['source'] == BASE and command['exit_code'] == 0
assert not command['forbidden_attempts']
for item in command['import_checks']:
    assert item['matches'] and item['sha256'] == sha(git('show', BASE + ':' + item['path']))
suites = list(ET.parse(QA / 'workspace-version.xml').getroot().iter('testsuite'))
assert sum(int(s.attrib['tests']) for s in suites) == 7
assert all(int(s.attrib[key]) == 0 for s in suites for key in ('errors', 'failures', 'skipped'))
assert sha((QA / 'test_workspace_version_observation.py').read_bytes()) == 'f7a0cdcf8d079068f39a34ccca17adb11c72c2594c88535db7e03310bf078a5c'
expected_docs = ['docs/plans/package-durable-admission-20261118.json',
                 'docs/plans/package-durable-admission-20261118.md']
changed = git('diff', '--name-only', BASE, DESIGN).decode().splitlines()
assert changed == expected_docs, changed
proposal = []
for path in expected_docs:
    raw = git('show', DESIGN + ':' + path)
    assert (ROOT / path).read_bytes() == raw
    target = QA / 'proposal' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    proposal.append({'path': path, 'commit': DESIGN, 'sha256': sha(raw), 'bytes': len(raw)})
later = git('show', '--format=fuller', '63ebc42746fbfbded311084288a339f26ed08d8c', '--',
            'src/patchtrace/persistence.py')
assert (QA / 'later-core-constructor.diff').read_bytes() == later
verification = {
    'source': BASE, 'source_tree': authority['tree'], 'design_commit': DESIGN,
    'design_tree': git('rev-parse', DESIGN + '^{tree}').decode().strip(),
    'git_snapshots_verified': len(authority['git_snapshots']),
    'source_equalities_verified': len(authority['equalities']),
    'full_symbol_spans_verified': len(seams),
    'caller_searches_replayed': len(authority['caller_searches']),
    'original_prior_files_rehashed_unchanged': len(authority['references']),
    'project_imports_verified': len(command['import_checks']),
    'observations': {'passed': 7, 'failed': 0, 'errors': 0, 'skipped': 0,
                     'scope': 'frozen-current Linux SQLite behavior only'},
    'network_or_child_attempts': [], 'production_test_schema_workflow_files_changed': [],
    'proposal_files': proposal,
    'subsequent_core_diff_verified': '63ebc42746fbfbded311084288a339f26ed08d8c',
    'design_not_implementation_acceptance': True,
    'first_seal_harness_failure_preserved': 'seal-harness-correction.json',
}
(QA / 'verification.json').write_text(json.dumps(verification, indent=2) + '\n')
members = []
for path in sorted(QA.rglob('*')):
    if not path.is_file() or path.name == 'manifest.json' or '__pycache__' in path.parts:
        continue
    assert not path.is_symlink()
    raw = path.read_bytes()
    members.append({'path': path.relative_to(QA).as_posix(), 'bytes': len(raw), 'sha256': sha(raw)})
manifest = {'record': 'sealed-read-only-design/1', 'source': BASE, 'design_commit': DESIGN,
            'members': members}
(QA / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = QA.with_suffix('.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name in sorted([item['path'] for item in members] + ['manifest.json']):
        info = zipfile.ZipInfo(name, (2026, 11, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        output.writestr(info, (QA / name).read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive) as check:
    assert check.testzip() is None
    assert len(check.namelist()) == len(members) + 1
    for item in members:
        assert sha(check.read(item['path'])) == item['sha256']
seal = {'source': BASE, 'source_tree': authority['tree'], 'design_commit': DESIGN,
        'archive_name': archive.name, 'archive_sha256': sha(archive.read_bytes()),
        'archive_bytes': archive.stat().st_size, 'archive_members': len(members) + 1,
        'manifest_sha256': sha((QA / 'manifest.json').read_bytes()),
        'verification': verification}
outer = QA.parent / 'package-durable-admission-design-seal.json'
outer.write_text(json.dumps(seal, indent=2) + '\n')
shutil.copyfile(archive, ROOT / 'docs/qa/package-durable-admission-design-20261118.zip')
(ROOT / 'docs/qa/package-durable-admission-design-20261118.manifest.json').write_text(json.dumps(seal, indent=2) + '\n')
print(json.dumps({k: seal[k] for k in ('design_commit', 'archive_sha256', 'archive_bytes',
                                     'archive_members', 'manifest_sha256')}))
