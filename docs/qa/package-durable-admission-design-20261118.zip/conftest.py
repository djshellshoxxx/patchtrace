"""Observe exact imported project bytes and deny network/process work in this probe."""
from __future__ import annotations

import hashlib
import json
import os
import sys
from pathlib import Path

ATTEMPTS: list[str] = []


def audit(event, args):
    if event in {"socket.connect", "socket.bind", "socket.getaddrinfo", "subprocess.Popen",
                 "os.system", "os.posix_spawn", "os.spawn"}:
        ATTEMPTS.append(event)
        raise AssertionError("observation forbids network/process work")


sys.addaudithook(audit)


def pytest_sessionfinish(session, exitstatus):
    root = Path(os.environ["PACKAGE_DESIGN_ROOT"]).resolve()
    imports = []
    for name, module in sorted(sys.modules.items()):
        if name != "patchtrace" and not name.startswith("patchtrace."):
            continue
        path = Path(module.__file__).resolve()
        assert path.is_relative_to(root / "src")
        imports.append({"module": name, "path": path.relative_to(root).as_posix(),
                        "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
    target = Path(os.environ["PACKAGE_DESIGN_IMPORTS"])
    target.write_text(json.dumps({"imports": imports, "forbidden_attempts": ATTEMPTS,
                                  "exitstatus": exitstatus}, indent=2) + "\n")
