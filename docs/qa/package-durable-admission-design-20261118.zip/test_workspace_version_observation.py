"""Frozen-current behavior observations, not tests of an implemented migration."""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
from pathlib import Path

import pytest

from patchtrace.kbcorrelation.recovery import mark_interrupted, repair
from patchtrace.kbcorrelation.store import KbcStoreError, WorkspaceStore

INV = "00000000-0000-4000-8000-0000000000b2"
OBSERVATIONS: dict[str, object] = {}


@pytest.fixture(autouse=True)
def observations():
    yield
    destination = Path(os.environ["PACKAGE_DESIGN_OBSERVATIONS"])
    destination.write_text(json.dumps(OBSERVATIONS, indent=2, sort_keys=True) + "\n")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def body():
    return {"revision": {"investigation_id": INV}, "interrupted": False,
            "input_mode": "held-package", "package_intent": "a" * 64}


def stamp(root, *, separate_row=False):
    with sqlite3.connect(root / "kbc.sqlite3") as db:
        db.execute("BEGIN IMMEDIATE")
        if separate_row:
            db.execute("CREATE TABLE package_admissions (intent_id TEXT PRIMARY KEY, body TEXT NOT NULL)")
            db.execute("INSERT INTO package_admissions VALUES (?,?)", ("a" * 64, '{"state":"intent"}'))
        db.execute("PRAGMA user_version=2")


def test_fresh_v1_remains_writable(tmp_path):
    with WorkspaceStore(tmp_path / "kb") as ws:
        assert not ws.read_only
        assert ws.db.execute("PRAGMA user_version").fetchone() == (1,)
        ws.journal_put("ordinary", "intent", {})
        assert ws.journal_get("ordinary") == ("intent", {})
    OBSERVATIONS["fresh_v1"] = {"read_only": False, "journal_write": "succeeded"}


def test_fresh_v2_open_reads_legacy_rows_and_refuses_writes(tmp_path):
    root = tmp_path / "kb"
    with WorkspaceStore(root) as ws:
        ws.journal_put("ordinary", "intent", {"captured": "value"})
    stamp(root, separate_row=True)
    before = digest(root / "kbc.sqlite3")
    with WorkspaceStore(root, create=False) as ws:
        assert ws.read_only
        assert ws.journal_get("ordinary") == ("intent", {"captured": "value"})
        with pytest.raises(KbcStoreError) as caught:
            ws.journal_put("ordinary", "done", {})
        assert caught.value.code == "PT-KBC-STORAGE"
        assert not caught.value.recoverable
        with pytest.raises(sqlite3.OperationalError, match="readonly"):
            ws.db.execute("INSERT INTO meta VALUES ('probe','blocked')")
        assert ws.db.execute("PRAGMA user_version").fetchone() == (2,)
    assert digest(root / "kbc.sqlite3") == before
    OBSERVATIONS["fresh_v2"] = {"read_only": True, "legacy_row_read": "succeeded",
                                "public_write": "PT-KBC-STORAGE/nonrecoverable",
                                "direct_sql_write": "readonly", "quiescent_database_unchanged": True}


def test_fresh_v2_repair_stops_before_attempt_or_project_call(tmp_path):
    root = tmp_path / "kb"
    with WorkspaceStore(root) as ws:
        ws.journal_put("held-looking", "intent", body())
    stamp(root)
    before = digest(root / "kbc.sqlite3")

    class ForbiddenProject:
        def __getattr__(self, name):
            pytest.fail(f"unexpected project call: {name}")

    with WorkspaceStore(root, create=False) as ws:
        with pytest.raises(KbcStoreError) as caught:
            repair(ws, ForbiddenProject())
        assert caught.value.code == "PT-KBC-STORAGE"
        assert ws.attempts(INV) == ()
        assert ws.journal_get("held-looking") == ("intent", body())
    assert digest(root / "kbc.sqlite3") == before
    OBSERVATIONS["fresh_v2_repair"] = {"attempts": 0, "project_calls": 0,
                                       "journal_unchanged": True, "error": "PT-KBC-STORAGE"}


def test_preopened_v1_handle_remains_writable_after_external_v2_stamp(tmp_path):
    root = tmp_path / "kb"
    with WorkspaceStore(root) as ws:
        stamp(root)
        assert ws.db.execute("PRAGMA user_version").fetchone() == (2,)
        assert not ws.read_only
        ws.journal_put("legacy-after-upgrade", "intent", {})
        assert ws.journal_get("legacy-after-upgrade") == ("intent", {})
    OBSERVATIONS["preopened_v1"] = {"actual_version": 2, "cached_read_only": False,
                                    "journal_write_after_upgrade": "succeeded"}


def test_unknown_held_fields_do_not_block_preopened_legacy_marking(tmp_path):
    root = tmp_path / "kb"
    with WorkspaceStore(root) as ws:
        ws.journal_put("held-looking", "intent", body())
        stamp(root)
        assert mark_interrupted(ws) == ("held-looking",)
        assert len(ws.attempts(INV)) == 1
        assert ws.journal_get("held-looking")[1]["interrupted"] is True
    OBSERVATIONS["unknown_fields"] = {"legacy_mark_interrupted": "succeeded",
                                       "attempts": 1, "new_fields_not_enforced": True}


def test_separate_package_rows_are_not_enumerated_by_legacy_recovery(tmp_path):
    root = tmp_path / "kb"
    with WorkspaceStore(root) as ws:
        stamp(root, separate_row=True)
        assert not ws.read_only
        before = ws.db.execute("SELECT * FROM package_admissions").fetchall()
        assert ws.journal_ops() == ()
        assert mark_interrupted(ws) == ()
        assert ws.db.execute("SELECT * FROM package_admissions").fetchall() == before
        assert ws.attempts(INV) == ()
    OBSERVATIONS["separate_table"] = {"legacy_enumerated_rows": 0, "attempts": 0,
                                      "package_rows_unchanged": True,
                                      "not_a_general_legacy_write_barrier": True}


def test_sqlite_rolls_back_authored_table_version_and_first_row_together(tmp_path):
    root = tmp_path / "kb"
    with WorkspaceStore(root) as ws:
        try:
            ws.db.execute("BEGIN IMMEDIATE")
            ws.db.execute("CREATE TABLE package_admissions (intent_id TEXT PRIMARY KEY, body TEXT NOT NULL)")
            ws.db.execute("INSERT INTO package_admissions VALUES (?,?)", ("a" * 64, "{}"))
            ws.db.execute("PRAGMA user_version=2")
            raise RuntimeError("authored pre-commit failure")
        except RuntimeError:
            ws.db.execute("ROLLBACK")
        assert ws.db.execute("PRAGMA user_version").fetchone() == (1,)
        assert ws.db.execute("SELECT name FROM sqlite_master WHERE name='package_admissions'").fetchone() is None
        assert ws.journal_ops() == ()
        assert not ws.read_only
        ws.journal_put("ordinary-after-rollback", "intent", {})
    OBSERVATIONS["authored_transaction_rollback"] = {"version": 1, "package_table_present": False,
                                                    "journal_empty_before_positive_write": True,
                                                    "ordinary_write_after_rollback": "succeeded",
                                                    "production_migration_implemented": False}
