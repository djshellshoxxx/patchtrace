"""Regenerate the kbcorrelation/1 artefacts (KB-integration-plan section 7.2 and 7.4).

Run from the repository root:

    PYTHONPATH=src python tools/generate_kbc_schemas.py          # write
    PYTHONPATH=src python tools/generate_kbc_schemas.py --check  # exit 1 on drift

Outputs, deterministic and offline, in ``docs/schemas/kbcorrelation/``: one JSON Schema per record plus
``examples.json`` and ``inventory-examples.json`` (valid and invalid examples, all SYNTHETIC:
KB5099001, Example OS). Inventory examples include an authored CSV and saved HTML. Their future-dated
retrieval receipt is synthetic contract data; this generator never retrieves a source or writes a workspace.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'docs' / 'schemas' / 'kbcorrelation'

CONTRACTS = ('SourceDoc', 'SourceRef', 'SearchScope', 'Coverage', 'ProductScope', 'KbCveEdge', 'ComponentHint',
             'BuildRow', 'BinaryRef', 'PairProposal', 'PairPlan', 'Attempt', 'AnalystDecision',
             'InvestigationRevision', 'ProjectLink', 'ContextReport', 'LeadRow', 'KbcIssue', 'OperationResult')
ERRORS_MODULE = frozenset({'KbcIssue', 'OperationResult'})

A, B, C, D = 'a' * 64, 'b' * 64, 'c' * 64, 'd' * 64
STAMP = '2099-03-01T00:00:00Z'
UUID = '12345678-1234-4234-8234-123456789abc'
INVENTORY_CSV = (b'Example OS 24H2 for x64-based Systems\r\n'
                 b'File name,File version,File size,Date,Time\r\n'
                 b'ExampleSvc.dll,10.0.26100.5001,"1,024","2099-03-\r\n01",12:00\r\n'
                 b'ExampleData.dll,10.0.26100.5001,unknown,2099-03-01,12:00\r\n')
INVENTORY_PAGE_CSV = (b'File name,File version,File size,Architecture\r\n'
                     b'ExampleSvc.dll,10.0.26100.5001,1024,arm64\r\n'
                     b'ExampleSvc.dll,10.0.26100.5001,1024,x64\r\n'
                     b'ExampleData.tsp,10.0.26100.5001,1024,x64\r\n'
                     b'ExampleSvc.dll,10.0.26100.5002,1024,x64\r\n')
SUPPORT_HTML = (b'<h2>File information</h2><p>Download the file information for the cumulative update '
                b'<a href="https://go.microsoft.com/fwlink/?linkid=20995099001">'
                b'Download file information for KB5099001</a></p>')
SUPPORT_URL = 'https://support.microsoft.com/help/5099001'


def _did(domain: str, payload) -> str:
    from patchtrace.enrichment.identity import domain_id
    return domain_id(domain, 1, payload)


def valid_records() -> dict:
    """One valid SYNTHETIC record per contract."""
    from patchtrace.kbcorrelation import contracts as c
    from patchtrace.kbcorrelation import errors as e
    doc_id = _did('kbc.source', {'kind': 'cvrf-month', 'sha256': A})
    source = c.SourceDoc(doc_id=doc_id, kind='cvrf-month', sha256=A, size=1234, origin='local-import',
                         retrieved_at=STAMP, release_id='2099-Mar', dialect='cvrf-1.2-synthetic', parser_version=1,
                         authenticity='unverified-local-file', lineage='msrc', object_path=f'objects/aa/{A}.gz')
    ref = c.SourceRef(doc_id=doc_id, pointer='/Vulnerability/0/Remediations/0', assertion='advisory_fact')
    scope = c.SearchScope(kind='selected_months', months=('2099-Feb', '2099-Mar'))
    coverage = c.Coverage(coverage_id=B, source_kind='cvrf-month', scope=scope, state='complete_in_scope',
                          requested_ids=('2099-Feb', '2099-Mar'), inspected_ids=('2099-Feb', '2099-Mar'),
                          retrieved_at=STAMP)
    product = c.ProductScope(scope_id=C, family='windows-client', release='24H2', architecture='amd64',
                             display_name='Example OS 24H2 amd64', mapping='candidate', alias_catalog_version=1,
                             source_product_ids=(c.ProductRef(doc_id=doc_id, product_id='99001'),))
    edge_key = {'kb': 'KB5099001', 'cve': 'CVE-2099-10001', 'scope_id': C, 'relation': 'vendor-remediation',
                'doc_id': doc_id, 'pointer': ref.pointer}
    edge = c.KbCveEdge(edge_id=_did('kbc.edge', edge_key), kb='KB5099001', cve='CVE-2099-10001', scope_id=C,
                       relation='vendor-remediation', ref=ref, release_id='2099-Mar', fixed_build='26100.5001',
                       supersedes=('KB5098000',))
    hint = c.ComponentHint(hint_id=D, basename='examplesvc.dll', scope_id=C, tier='B', reasons=('named-in-title',),
                           claim_refs=(ref,))
    row = c.BuildRow(file_name='examplesvc.dll', sha256=A, version_key='10.0.26100', kb='KB5099001',
                     release_date=STAMP, release_version='5001', heading_class='standard', variant='full',
                     download='https://example.invalid/examplesvc.dll', record_sha256=B)
    older = c.BinaryRef(sha256=A, size=1000, basename='examplesvc.dll', machine='amd64',
                        file_version='10.0.26100.5000', build_ubr='26100.5000', origin='index-row',
                        availability='direct', authenticity='hash-matched-to-index')
    newer = older.model_copy(update={'sha256': B, 'file_version': '10.0.26100.5001', 'build_ubr': '26100.5001'})
    pair_key = {'older': A, 'newer': B, 'scope_id': C, 'window_id': 'w1'}
    pair = c.PairProposal(pair_id=_did('kbc.pair', pair_key), older=older, newer=newer, scope_id=C, window_id='w1',
                          bytes_state='pending', lineage_state='index-adjacent', fix_boundary='source-supported',
                          window=('KB5099001',), window_complete=True, grade='A', tier='B')
    plan = c.PairPlan(plan_sha=D, pair_id=pair.pair_id, hosts=('example.invalid',), destination_policy='private-staging',
                      requests=(c.PlanRequest(method='GET', url='https://example.invalid/examplesvc.dll',
                                              bytes=1000, why='older binary'),),
                      expected=(c.ExpectedFile(sha256=A, size=1000),))
    attempt = c.Attempt(op='plan', plan_sha=D, stage='preview', result='ok', created_at=STAMP)
    decision = c.AnalystDecision(op='choose-product', prior='NEEDS_PRODUCT', next='PRODUCT_SELECTED',
                                 reason='only one scope fits', created_at=STAMP)
    revision = c.InvestigationRevision(investigation_id=UUID, revision=2, parent=1,
                                       lead=c.Lead(kind='kb', value='KB5099001', raw='kb5099001'),
                                       state='PRODUCT_SELECTED', scope_ids=(C,), coverage_ids=(B,),
                                       selected_scope_id=C)
    link = c.ProjectLink(project_id='project-1', project_revision=3, older_sha=A, newer_sha=B, investigation_id=UUID,
                         revision=2, pair_id=pair.pair_id, state='attached')
    context = c.ContextReport(cards=(c.CveCard(cve='CVE-2099-10001', source_kind='cvrf', title='Synthetic issue'),),
                              coverage=(coverage,), unknowns=('no binary comparison has run',),
                              limitations=('documents are claims, not verification',),
                              hooks=('kb.meaning.coverage', 'kb.next.run_comparison'))
    lead = c.LeadRow(lead_id=A, level='component', group='CVE-2099-10001', subject='examplesvc.dll',
                     chips=(c.Chip(channel='documentary', state='supports', text='named in the advisory', ref=ref),
                            c.Chip(channel='code-change', state='not-run', text='no comparison yet')),
                     rank_basis='documentary tier, then name', nav=c.LeadNav(project_revision=0),
                     hooks=('kb.next.run_comparison',))
    issue = e.KbcIssue(code='PT-KBC-SCOPE', message='a finite search scope is required', source_id=None)
    result = e.OperationResult(status='partial', issues=(issue,), warnings=('2 of 24 documents unreadable',))
    return {'SourceDoc': source, 'SourceRef': ref, 'SearchScope': scope, 'Coverage': coverage,
            'ProductScope': product, 'KbCveEdge': edge, 'ComponentHint': hint, 'BuildRow': row, 'BinaryRef': older,
            'PairProposal': pair, 'PairPlan': plan, 'Attempt': attempt, 'AnalystDecision': decision,
            'InvestigationRevision': revision, 'ProjectLink': link, 'ContextReport': context, 'LeadRow': lead,
            'KbcIssue': issue, 'OperationResult': result}


SPECIFIC_INVALID = {
    'SourceDoc': ({'origin': 'https-fetch'}, 'a fetched document needs an https URI and a TLS authenticity'),
    'SearchScope': ({'months': []}, 'selected_months needs at least one month'),
    'Coverage': ({'inspected_ids': ['2099-Mar']}, 'complete_in_scope needs requested == inspected'),
    'ProductScope': ({'mapping': 'verified'}, 'string-derived scopes are never verified'),
    'KbCveEdge': ({'kb': 'KB123'}, 'KB syntax is KB + 4-10 ASCII digits'),
    'ComponentHint': ({'basename': '../evil.dll'}, 'basename must be a lowercase PE basename'),
    'PairProposal': ({'grade': 'X'}, 'grade X needs a hard block'),
    'PairPlan': ({'hosts': ['other.invalid']}, 'hosts must equal the planned request hosts'),
    'InvestigationRevision': ({'parent': None}, 'a later revision needs a parent'),
    'ProjectLink': ({'state': 'stale'}, 'stale needs stale_reasons'),
    'OperationResult': ({'status': 'ok'}, 'an ok result carries no issues'),
}


def build_examples() -> dict:
    out = {}
    for name, record in valid_records().items():
        valid = json.loads(record.model_dump_json())
        invalid = [{'example': valid | {'unexpected_field': 1}, 'reason': 'extra fields are forbidden'}]
        if 'contract' in valid:
            invalid.append({'example': valid | {'contract': 'kbcorrelation/2'},
                            'reason': 'unsupported future contract version'})
        if name in SPECIFIC_INVALID:
            patch, reason = SPECIFIC_INVALID[name]
            invalid.append({'example': valid | patch, 'reason': reason})
        out[name] = {'valid': valid, 'invalid': invalid}
    return out


def inventory_models() -> dict:
    """PW-01 value records and separately versioned contracts, not kbcorrelation/1 contracts."""
    from patchtrace.kbcorrelation import inventory_contracts as inventory
    from patchtrace.kbcorrelation import inventory_store as store
    from patchtrace.kbcorrelation.contracts import InventoryClaimRef
    from patchtrace.kbcorrelation.inventory_selection import InventorySelection
    return {'InventoryClaimRef': InventoryClaimRef,
            **{name: getattr(inventory, name) for name in
               ('InventoryLimits', 'InventoryPageLimits', 'InventoryContext', 'CsvRecordRef', 'CsvDiagnostic',
                'InventorySection', 'InventoryEntry', 'CsvInventory', 'InventoryPageEntry',
                'InventoryRetention', 'InventoryConflictWitness', 'CsvInventoryPage')},
            **{name: getattr(store, name) for name in
               ('InventoryImport', 'SupportImport', 'RetrievalProvenance')},
            'InventorySelection': InventorySelection}


def valid_inventory_records() -> dict:
    """Authored examples bind exact raw bytes and context; no I/O or authenticity inference."""
    from patchtrace.kbcorrelation import inventory_store as store
    from patchtrace.kbcorrelation.contracts import InventoryClaimRef
    from patchtrace.kbcorrelation.inventory_contracts import (
        InventoryContext,
        InventoryPageLimits,
        InventoryRetention,
    )
    from patchtrace.kbcorrelation.inventory_csv import parse_inventory, parse_inventory_page
    from patchtrace.kbcorrelation.inventory_selection import InventorySelection
    from patchtrace.kbcorrelation.sources.inventory_fetch import build_plan

    context = InventoryContext(kb='KB5099001', product_scope_id=C, product='Example OS',
                               release='24H2', build='26100.5001')
    parsed = parse_inventory(INVENTORY_CSV, context)
    source = store._source(INVENTORY_CSV, 'kb-file-csv', 'csv-file-inventory/1', STAMP, None)
    asserted = 'https://example.invalid/KB5099001.csv'
    inventory = store.InventoryImport(import_id=store._inventory_id(source, parsed, asserted, None),
                                       source=source, parsed=parsed, asserted_source=asserted)
    entry = parsed.entries[0]
    claim = InventoryClaimRef(import_id=inventory.import_id, entry_id=entry.entry_id,
                              **entry.reference.model_dump())
    html_source = store._source(SUPPORT_HTML, 'kb-support-html', 'support-html/1', STAMP, None)
    extraction = store._extraction_digest(SUPPORT_HTML, SUPPORT_URL, None)
    support = store.SupportImport(import_id=store._support_id(html_source, SUPPORT_URL, extraction, None),
                                   source=html_source, page_url=SUPPORT_URL, extraction_sha256=extraction)
    plan = build_plan('https://go.microsoft.com/fwlink/?linkid=20995099001', redirects=(
        'https://download.microsoft.com/download/synthetic/KB5099001.csv',))
    receipt = store.RetrievalProvenance(kind='file-inventory', original_url=plan.urls[0],
                                       final_url=plan.urls[-1], redirect_chain=plan.urls,
                                       sha256=parsed.raw_sha256, size=len(INVENTORY_CSV),
                                       retrieved_at=STAMP, plan_sha=plan.plan_sha)
    selection = InventorySelection(import_id=inventory.import_id, entry_id=entry.entry_id,
                                    scope_id=C, coverage_sha256=B, asserted_scope=False)
    page = parse_inventory_page(INVENTORY_PAGE_CSV, context, InventoryRetention(architecture='amd64'),
                                limits=InventoryPageLimits(max_entries=2))
    return {'InventoryClaimRef': claim, 'InventoryLimits': parsed.limits, 'InventoryPageLimits': page.limits,
            'InventoryContext': context,
            'CsvRecordRef': entry.reference, 'CsvDiagnostic': parsed.diagnostics[0],
            'InventorySection': parsed.sections[0], 'InventoryEntry': entry, 'CsvInventory': parsed,
            'InventoryPageEntry': page.entries[1], 'InventoryRetention': page.retention,
            'InventoryConflictWitness': page.conflict_witnesses[0], 'CsvInventoryPage': page,
            'InventoryImport': inventory, 'SupportImport': support, 'RetrievalProvenance': receipt,
            'InventorySelection': selection}


INVENTORY_INVALID = {
    'InventoryClaimRef': (({'line_end': 1}, 'a physical line span cannot run backwards'),),
    'InventoryLimits': (({'max_bytes': 16 * 1024 * 1024 + 1}, 'callers cannot raise the hard byte ceiling'),
                        ({'max_entries': 50_001}, 'v1 inventories retain at most 50,000 entries'),
                        ({'max_records': True}, 'integer budgets do not coerce booleans')),
    'InventoryPageLimits': (({'max_entries': 5_001}, 'v2 pages retain at most 5,000 entries'),
                            ({'max_entries': True}, 'integer page budgets do not coerce booleans')),
    'InventoryContext': (({'architecture': 'x64'}, 'context uses the canonical amd64 architecture'),),
    'CsvRecordRef': (({'logical_record': 0}, 'logical CSV records are one-based'),),
    'CsvDiagnostic': (({'code': 'ARBITRARY_CODE'}, 'diagnostics use the documented code vocabulary'),),
    'InventorySection': (({'index': 999}, 'section index must agree with its source reference'),),
    'InventoryEntry': (({'basename': '../evil.dll'}, 'normalized names cannot be source paths'),
                       ({'version_components': [10, 0, 26100]}, 'known versions retain exactly four integers')),
    'CsvInventory': (({'accepted_count': 0}, 'accepted count must match retained entries'),
                     ({'inventory_id': A}, 'identity binds exact bytes, context and parsing budgets'),
                     ({'parser_version': True}, 'parser version does not coerce a boolean literal')),
    'InventoryPageEntry': (({'state': 'descriptive-only'}, 'v2 recognizes the TSP PE suffix'),),
    'InventoryRetention': (({'page': True}, 'source page numbers do not coerce booleans'),
                           ({'page': 0}, 'source pages are one-based'),
                           ({'architecture': 'x64'}, 'retention uses canonical architecture names')),
    'InventoryConflictWitness': (({'field': 'architecture'}, 'a witness names one known metadata contradiction'),),
    'CsvInventoryPage': (({'omitted_count': 0}, 'omitted count includes matching rows outside the retained page'),
                         ({'conflict_witnesses': []}, 'cross-page conflicts retain a source-wide witness'),
                         ({'scan_complete': False}, 'an incomplete scan must explicitly mark truncation'),
                         ({'parser_version': True}, 'parser version does not coerce a boolean literal')),
    'InventoryImport': (({'import_id': A}, 'import identity binds parser identity and source provenance'),),
    'SupportImport': (({'import_id': A}, 'support identity binds source, explicit page and link digest'),
                      ({'parser_version': True}, 'parser version does not coerce a boolean literal')),
    'RetrievalProvenance': (({'plan_sha': A}, 'receipt digest binds the exact ordered request plan'),),
    'InventorySelection': (({'asserted_scope': 'false'}, 'an explicit scope assertion is a strict boolean'),),
}


def build_inventory_examples() -> dict:
    out = {}
    for name, record in valid_inventory_records().items():
        valid = json.loads(record.model_dump_json())
        invalid = [{'example': valid | {'unexpected_field': 1}, 'reason': 'extra fields are forbidden'}]
        if 'contract' in valid:
            prefix, version = valid['contract'].rsplit('/', 1)
            invalid.append({'example': valid | {'contract': f'{prefix}/{int(version) + 1}'},
                            'reason': 'unsupported future contract version'})
        invalid.extend({'example': valid | patch, 'reason': reason} for patch, reason in INVENTORY_INVALID[name])
        out[name] = {'valid': valid, 'invalid': invalid}
    return out


def schema_models() -> dict:
    from patchtrace.kbcorrelation import context, contracts, errors
    models = {}
    for name in (*CONTRACTS, 'ContextBundle'):
        module = context if name == 'ContextBundle' else errors if name in ERRORS_MODULE else contracts
        models[name] = getattr(module, name)
    return models | inventory_models()


def render_contract_schemas() -> dict[str, str]:
    out = {}
    for name, model in schema_models().items():
        schema = model.model_json_schema()
        schema['$id'] = f'https://patchtrace.local/schemas/kbcorrelation/1/{name}.json'
        schema['$schema'] = 'https://json-schema.org/draft/2020-12/schema'
        out[f'{name}.json'] = json.dumps(schema, indent=2, sort_keys=True, ensure_ascii=False) + '\n'
    return out


def render() -> dict[Path, str]:
    """Every generated file and its exact text (a pure function of the repository contents)."""
    files = {OUT / name: text for name, text in render_contract_schemas().items()}
    files[OUT / 'examples.json'] = json.dumps(build_examples(), indent=2, sort_keys=True, ensure_ascii=False) + '\n'
    files[OUT / 'inventory-examples.json'] = json.dumps(build_inventory_examples(), indent=2, sort_keys=True,
                                                       ensure_ascii=False) + '\n'
    return files


def main(argv: list[str]) -> int:
    check = '--check' in argv
    drift = []
    for path, text in render().items():
        if check:
            current = path.read_text(encoding='utf-8') if path.is_file() else None
            if current != text:
                drift.append(str(path.relative_to(ROOT)))
        else:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(text, encoding='utf-8', newline='\n')
    for item in drift:
        print(f'stale: {item}', file=sys.stderr)
    return 1 if drift else 0


if __name__ == '__main__':
    raise SystemExit(main(sys.argv[1:]))
