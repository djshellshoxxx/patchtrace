"""Capture exact Git authorities and existing evidence without changing originals."""
from __future__ import annotations

import ast
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
QA = Path(__file__).resolve().parent
BASE = '195e04af27f7a724c6a2037363b7fe68df418a6b'
WORKSPACE = ROOT.parent


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


paths = [
    'AGENTS.md', 'docs/modules.md',
    'docs/specs/local-package-intake.md', 'docs/specs/kb-cve/31-D-acquisition-packages.md',
    'docs/specs/core-held-inputs.md', 'docs/specs/kb-held-inputs.md',
    'docs/plans/kb-held-reader-propagation-20261118.md',
    'docs/plans/package-core-admission-seams-20261118.md',
    'src/patchtrace/input_readers.py', 'src/patchtrace/ingestion.py',
    'src/patchtrace/service.py', 'src/patchtrace/persistence.py', 'src/patchtrace/models.py',
    'src/patchtrace/owned_publication.py', 'src/patchtrace/enrichment/storage.py',
    *['src/patchtrace/acquisition/' + p + '.py' for p in
      ('package_contracts', 'package_paths', 'package_platform', 'package_budget', 'package_worker_contracts')],
    *['src/patchtrace/kbcorrelation/' + p + '.py' for p in
      ('service', 'wiring', 'store', 'recovery', 'context', 'saved_scope', 'index', 'ports',
       'contracts', 'limits', 'workflow', 'inventory_store', 'cli_index')],
    'src/patchtrace/kbcorrelation/sources/importer.py',
    'tools/generate_package_schemas.py', 'tools/generate_kbc_schemas.py',
    *['tests/' + p + '.py' for p in
      ('test_kbc_store', 'test_kbc_recovery', 'test_kbc_service',
       'test_kbc_saved_scope_flow', 'test_kbc_held_input_admission', 'test_kbc_held_inspection_prefix')],
]
available = set(git('ls-tree', '-r', '--name-only', BASE).decode().splitlines())
assert set(paths) <= available, sorted(set(paths) - available)
manifest = []
seams = []
seam_names = {
    'WorkspaceStore', 'ProjectAttachment', 'AttachRequest', 'KbcStoreError',
    'RealProjectPort', 'ProjectFactory', 'Env', 'PairInputReaders', 'HeldInput',
    'PackageBudget', 'PackageWorkerBinding', 'PackageWorkerGrant', 'PackageWorkerReceipt',
    'PackageSelection', 'PackageInventory', 'PackagePart', 'PackageSource', 'PackageLimits',
    'EnrichmentStore.publish', 'EnrichmentStore.entries', 'EnrichmentStore.ensure',
    'KbService.import_pair', 'KbService._approve_pair', 'KbService._bundle',
    'KbService.attach', 'KbService._ops_for', 'KbService._rebuilt_rows',
    'KbService._saved_search', 'KbService._checked_index', 'KbService._stored_scope',
    'ProjectService.create', 'ProjectService.open', 'ProjectService.swap_orientation',
    'ProjectStore.load', 'ProjectStore.save', 'ProjectStore._verify_files', 'ProjectLock',
    'mark_interrupted', 'repair', 'open_operations', 'pending_context', 'resolve',
    'build_bundle', 'context_key', '_project_factory', 'new_project_factory', 'inspect_local_file',
    'directory_anchor', 'verify_anchor', 'publish_bytes', 'read_bytes', 'select_member',
    '_rollback_creation', 'Record', 'ComparisonProject',
}


def walk(nodes, prefix, data, file_path):
    lines = data.decode().splitlines(keepends=True)
    for node in nodes:
        if not isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        name = prefix + node.name
        start = min([node.lineno, *[d.lineno for d in node.decorator_list]])
        span = ''.join(lines[start - 1:node.end_lineno]).encode()
        if name in seam_names:
            seams.append({'path': file_path, 'symbol': name, 'start': start, 'end': node.end_lineno,
                          'sha256': sha(span), 'source_sha256': sha(data),
                          'signature': (ast.unparse(node.args) if hasattr(node, 'args') else 'class')})
        if isinstance(node, ast.ClassDef):
            walk(node.body, name + '.', data, file_path)


for path in paths:
    data = git('show', BASE + ':' + path)
    target = QA / 'source' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    manifest.append({'path': path, 'source': BASE, 'blob': git('rev-parse', BASE + ':' + path).decode().strip(),
                     'sha256': sha(data), 'bytes': len(data), 'stored': target.relative_to(QA).as_posix()})
    if path.startswith('src/') and path.endswith('.py'):
        walk(ast.parse(data).body, '', data, path)

equalities = []
for reference, compared in (
    ('9740860928c7911e6fa975528db1f7fa5ca1940b', [
        'src/patchtrace/input_readers.py', 'src/patchtrace/ingestion.py',
        'src/patchtrace/service.py', 'src/patchtrace/persistence.py', 'docs/specs/core-held-inputs.md']),
    ('d9a939911f39f3641bd5eed97a2ce067d618856b', [
        'src/patchtrace/kbcorrelation/service.py', 'src/patchtrace/kbcorrelation/wiring.py',
        'src/patchtrace/kbcorrelation/store.py', 'docs/specs/kb-held-inputs.md']),
    ('7259f86838c2181d6bdbcabe98c7a294a4499e8d', [
        'src/patchtrace/acquisition/package_budget.py',
        'src/patchtrace/acquisition/package_worker_contracts.py']),
):
    for path in compared:
        current = git('show', BASE + ':' + path)
        older = git('show', reference + ':' + path)
        equalities.append({'path': path, 'reference': reference, 'current': BASE,
                           'reference_sha256': sha(older), 'current_sha256': sha(current),
                           'equal': older == current})
assert all(item['equal'] for item in equalities)

references = []
prior = [
    'qa/pw02-kb-held-reader-design/README.md',
    'qa/pw02-kb-held-reader-design/test_existing_admission_boundary.py',
    'qa/pw02-kb-held-reader-design/test_existing_admission_boundary_v2.py',
    'qa/pw02-kb-held-reader-design/harness-correction.json',
    'qa/pw02-kb-held-reader-design/review-receipt.json',
    'qa/pw02-kb-held-reader-design/existing-admission-v2.command.json',
    'qa/pw02-kb-held-reader-design/existing-admission-v2.log',
    'qa/pw02-kb-held-reader-design/existing-admission-v2.xml',
    'qa/pw02-core-admission-design/README.md',
    'qa/pw02-core-admission-design/test_current_core_boundaries.py',
    'qa/pw02-core-admission-design/current.command.json',
    'qa/pw02-core-admission-design/current.log',
    'qa/pw02-core-admission-design/current.xml',
    'qa/pw02-core-admission-design/verification.json',
    'qa/pw02-local-packages/native-seam-design/interface-map.md',
    'qa/pw02-local-packages/native-seam-design/native-handoff.md',
]
for rel in prior:
    original = WORKSPACE / rel
    data = original.read_bytes()
    target = QA / 'references' / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(original, target)
    references.append({'original': str(original), 'stored': target.relative_to(QA).as_posix(),
                       'sha256': sha(data), 'bytes': len(data)})

searches = [
    ('admission-calls', r'\.import_pair\(|ProjectAttachment\(|create_project\(|open_project\('),
    ('recovery-calls', r'mark_interrupted\(|repair\(|journal_ops\(|journal_get\('),
    ('scope-calls', r'_stored_scope\(|_checked_index\(|build_bundle\('),
    ('package-storage-and-entrypoints', r'package_|PackageBudget|PairInputReaders'),
    ('object-reference-callers', r'unreferenced_objects\(|referenced_raw_hashes\(|workspace_objects_bytes'),
]
search_records = []
for name, pattern in searches:
    argv = ['rg', '-n', '-e', pattern, 'src/patchtrace', 'tools']
    result = subprocess.run(argv, cwd=ROOT, capture_output=True, check=False)
    assert result.returncode == 0, result.stderr
    target = QA / 'caller-searches' / (name + '.txt')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(result.stdout)
    search_records.append({'name': name, 'argv': argv, 'cwd': str(ROOT), 'source': BASE,
                           'exit_code': result.returncode, 'sha256': sha(result.stdout),
                           'stored': target.relative_to(QA).as_posix()})

out = {'source': BASE, 'tree': git('rev-parse', BASE + '^{tree}').decode().strip(),
       'git_snapshots': manifest, 'equalities': equalities, 'references': references,
       'caller_searches': search_records}
(QA / 'source-provenance.json').write_text(json.dumps(out, indent=2) + '\n')
(QA / 'source-seams.json').write_text(json.dumps(seams, indent=2) + '\n')
print(json.dumps({'snapshots': len(manifest), 'seams': len(seams),
                  'equalities': len(equalities), 'references': len(references),
                  'caller_searches': len(search_records)}))
