# Read-only F8 lifecycle scrutiny

Current source: `3faf436a3b11c69220641a167cf424e7f4060839`, detached
`/workspace/scratch/c7a9e8d98848/f8-lifecycle-review`. Historical helper/control:
`c13d3257c88140c23fb585a8a59a4dce81e81928`. Exact current/historical file bytes
and SHA-256 identities are in `source-manifest.json`. No source edits or native,
network, acquisition or target execution occurred.

## Actual controls

`test_create_cleanup.py`: **2 passed, zero skips/failures, 1.23 s**.
`command.json`, `create-cleanup.log/xml` retain exact command/environment/source.
Both cases use the real MainWindow host/TaskRunner, InvestigationDialog and a
worker-owned ProjectService.sample/store, with explicit synchronization around an
already-committed synthetic creation. This is an authored lifecycle control,
not a complete F8 journey or native/package acceptance.

1. Normal close during committed create: dialog.reject marks close-after-create
   but leaves the channel token unset and the dialog open. After worker-side
   service close, queued result delivery announces the retained project and closes
   the dialog. The original MainWindow service remains active. The committed
   destination reopens, on the GUI thread, with the same identity.
2. Host shutdown during that create: TaskRunner.shutdown sets the token, joins the
   worker and drops its result callback. The dialog's _pending consequently remains
   set even though the worker has finished and its SQLite owner has closed the
   store. The original service remains unchanged and the created project reopens.
   No live task threads remain. Cleanup must not wait on _pending after runner shutdown.

## Trace and implications for the self-test helper

`InvestigationDialog.reject/cancel_operation` intentionally preserve an in-flight
local commit. `_execute` checks cancellation before import_pair and returns any
created path after commit. Only a self-owned dialog runner is shut down by
`dialog._shutdown`; a dialog from the desktop uses the owning window's shared
runner. `TaskRunner.shutdown` marks itself closed, and `_deliver` releases/drops
late callbacks rather than reporting the retained path. Check actual shutdown
results and worker/store closure before cleaning the helper's owned temporary root.
Do not use dialog acceptance or `not busy()` alone as that postcondition.

`Host.investigation_dialog.adopt` can deliberately return without adoption when
the original project/worker/closing state changed; `_loaded` can still accept the
dialog because the callback returned. The helper's actual window.service/root
assertion is therefore essential. ProjectService creation/close runs on the worker;
the returned value is only a path. Host opens and adopts on the GUI thread. Preserve
that ordering and never carry the worker's service/SQLite handle into the desktop.

The historical generator runner uses one real application event loop, rejects nested
or wrong-thread entry, and closes its generator to run finally cleanup. Its
cooperative-worker failure test is useful, but it does not by itself prove handling
of non-cooperative work beyond TaskRunner's finite join limit. A stuck/cleanup-failed
worker must prevent a success marker and temporary-root removal. Existing main-window
close can also be refused while its legacy worker runs; a close call alone is not a
verified final shutdown. The new helper author reports checking the shared runner's
return, captured-service fallback cleanup and retained-root failure behavior; those
are appropriate seams. This trace does not independently qualify that uncommitted
helper or its pending frozen build.
