"""External current-source ownership controls; no native engine or network work."""
from pathlib import Path
import threading

import pytest
from PySide6.QtCore import QSettings

from patchtrace.gui.qt.tasks import live_task_threads
from patchtrace.kbcorrelation.investigation_service import InvestigationRequest, InvestigationResult
from patchtrace.service import ProjectService
from patchtrace.ui import MainWindow


@pytest.mark.parametrize('shutdown', [False, True], ids=['delivered-create', 'host-shutdown-drops-callback'])
def test_create_close_observes_real_worker_store_ownership(qtbot, tmp_path, shutdown):
    original = ProjectService.sample(tmp_path / 'original')
    window = MainWindow(original, QSettings(str(tmp_path / 'ui.ini'), QSettings.Format.IniFormat))
    qtbot.addWidget(window)
    dialog = window.investigation_dialog()
    qtbot.addWidget(dialog)
    created, released = threading.Event(), threading.Event()
    state = {}
    destination = tmp_path / 'created'

    def execute(request, token):
        # Model an already-committed local create whose worker still owns its store.
        service = ProjectService.sample(Path(request.destination))
        try:
            state.update(token=token, thread=threading.get_ident(), project=service.project.id)
            created.set()
            if shutdown:
                token.wait(2)
            else:
                released.wait(2)
        finally:
            service.close()
            state['closed_on_thread'] = threading.get_ident()
        return InvestigationResult('create', 'Synthetic project committed', project_path=destination)

    dialog._execute = execute
    request = InvestigationRequest('create', tmp_path / 'workspace', destination=destination)
    try:
        dialog._submit(request)
        qtbot.waitUntil(created.is_set, timeout=5000)
        dialog.reject()
        assert not dialog._closed and dialog._pending is request
        assert dialog._cancel_create and dialog._close_after_create
        assert not state['token'].is_set(), 'dialog close must not cancel an in-flight commit'
        if shutdown:
            assert window.panels.tasks.shutdown(timeout=2) == []
            assert dialog._pending is request, 'a shut-down host drops result callbacks'
        else:
            released.set()
            qtbot.waitUntil(lambda: dialog._pending is None and dialog._closed, timeout=5000)
            assert 'retained without opening' in window.logs.toPlainText()
        assert window.service is original, 'a close-during-create result must never replace the original'
        assert state['closed_on_thread'] == state['thread'] != threading.get_ident()
        with ProjectService.open(destination, maintenance=False) as reopened:
            assert reopened.project.id == state['project']
        assert not live_task_threads()
    finally:
        released.set()
        if 'token' in state:
            state['token'].set()
        window.panels.tasks.shutdown(timeout=2)
        window.close()
