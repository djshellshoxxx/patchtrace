"""Independent baseline control: actual registered inventory/investigation tooltips must be distinct."""


def test_real_dialog_registrations_keep_distinct_workspace_tooltip_meaning(qapp, tmp_path):
    from patchtrace.kbcorrelation.investigation_qt import InvestigationDialog
    from patchtrace.kbcorrelation.inventory_qt import register_inventory_tips
    from patchtrace.tooltips import REGISTRY

    register_inventory_tips()
    dialog = InvestigationDialog(workspace=tmp_path)
    try:
        first = REGISTRY['kb.inventory.browse_workspace'].what
        second = REGISTRY['kb.investigation.browse_workspace'].what
        assert first != second, (first, second)
    finally:
        dialog.reject()
