"""Run the exact desktop entry while refusing Python-level network and child-process boundaries."""
import os
from pathlib import Path
import socket
import subprocess
import sys


def refused(*_args, **_kwargs):
    raise AssertionError('Synthetic desktop entry crossed a network or child-process boundary')


socket.socket.connect = socket.socket.connect_ex = refused
socket.create_connection = socket.getaddrinfo = refused
subprocess.Popen = os.system = refused
import patchtrace.__main__ as entry

assert Path(entry.__file__).resolve() == Path(sys.argv[1]).resolve()
sys.argv = ['patchtrace', '--self-test']
raise SystemExit(entry.main())
