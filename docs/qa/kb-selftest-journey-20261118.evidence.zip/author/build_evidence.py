"""Seal retained F8 receipts without editing any original payload."""
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

root = Path('/workspace/scratch/c7a9e8d98848/kb-selftest')
qa = Path(__file__).resolve().parent
peer = qa.parent / 'f8-lifecycle-independent'
source = '316b0f12fd0180a597366bdec80fa768bdc59fe6'
base = root / 'docs/qa/kb-selftest-journey-20261118'
payloads = {}
for label, directory in [('author', qa), ('independent', peer)]:
    for path in sorted(directory.rglob('*')):
        if path.is_file() and not {'__pycache__', '.pytest_cache'} & set(path.parts):
            payloads[label + '/' + str(path.relative_to(directory))] = path.read_bytes()
for path in ['src/patchtrace/__main__.py', 'src/patchtrace/gui/qt/kb_selftest.py',
             'src/patchtrace/gui/qt/selftest_loop.py', 'src/patchtrace/kbcorrelation/investigation_qt.py',
             'tests/test_ui_kb_selftest.py', 'tests/test_kb_selftest_entry.py',
             'docs/specs/kb-cve/31-F-workflow-ui-persistence.md', 'docs/modules.md']:
    payloads['final/' + path] = subprocess.check_output(['git', 'show', source + ':' + path], cwd=root)
archive = base.with_suffix('.evidence.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(payloads.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        output.writestr(info, data)
manifest = dict(source=source, baseline='3faf436a3b11c69220641a167cf424e7f4060839',
                archive=archive.name, archive_bytes=archive.stat().st_size,
                archive_sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),
                payload_count=len(payloads), payloads=[dict(path=name, bytes=len(data),
                sha256=hashlib.sha256(data).hexdigest()) for name, data in sorted(payloads.items())])
base.with_suffix('.manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as sealed:
    assert set(sealed.namelist()) == set(payloads)
    for row in manifest['payloads']:
        data = sealed.read(row['path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
print(json.dumps({k: v for k, v in manifest.items() if k != 'payloads'}, indent=2))
