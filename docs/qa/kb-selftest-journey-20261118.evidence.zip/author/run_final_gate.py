"""Replay the bounded F8 affected gate against one clean, exact source checkout."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path(sys.argv[1]).resolve()
qa = Path(__file__).resolve().parent
tag = sys.argv[2]
files = [
    'test_ui_kb_selftest.py', 'test_kb_selftest_entry.py', 'test_audit_desktop.py',
    'test_ui_kb_investigation.py', 'test_kb_investigation_service.py', 'test_ui_kb_panel.py',
    'test_gui_host.py', 'test_gui_host_layout.py', 'test_gui_host_palette.py', 'test_gui_host_seam.py',
    'test_tooltips.py', 'test_gui_core_isolation.py', 'test_cli.py', 'test_acceptance_smoke.py',
    'test_optional_deps.py', 'test_windows_build_resources.py', 'test_kbc_leads.py', 'test_kb_current_project.py',
]
external = [qa.parent / 'f8-lifecycle-independent/test_create_cleanup.py', qa / 'test_tooltip_collision_external.py']
command = [sys.executable, '-m', 'pytest', '-q', *[str(root / 'tests' / p) for p in files],
           *map(str, external), '--junitxml=' + str(qa / (tag + '.xml'))]
env = dict(os.environ, PYTHONPATH=str(root / 'src') + ':' + str(root / 'tests'), QT_QPA_PLATFORM='offscreen')
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()

assert not git('status', '--short'), 'Exact gate requires a clean tree'
sha = git('rev-parse', 'HEAD')
source_files = ['src/patchtrace/__main__.py', 'src/patchtrace/gui/qt/kb_selftest.py',
                'src/patchtrace/gui/qt/selftest_loop.py', 'src/patchtrace/kbcorrelation/investigation_qt.py',
                'src/patchtrace/ui.py', *['tests/' + p for p in files]]
context = dict(source=sha, tree=git('rev-parse', 'HEAD^{tree}'), command=command, cwd=str(root),
               pythonpath=env['PYTHONPATH'], qt=env['QT_QPA_PLATFORM'], status='',
               files={p: hashlib.sha256((root / p).read_bytes()).hexdigest() for p in source_files},
               external_controls={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in external})
(qa / (tag + '-context.json')).write_text(json.dumps(context, indent=2) + '\n')
started = time.monotonic()
with (qa / (tag + '.log')).open('w') as stream:
    result = subprocess.run(command, cwd=root, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=180)
exit_receipt = dict(exit=result.returncode, elapsed=time.monotonic() - started,
                    source_after=git('rev-parse', 'HEAD'), status_after=git('status', '--short'))
(qa / (tag + '-exit.json')).write_text(json.dumps(exit_receipt, indent=2) + '\n')
assert exit_receipt['source_after'] == sha and not exit_receipt['status_after']
print(json.dumps(exit_receipt))
print('\n'.join((qa / (tag + '.log')).read_text().splitlines()[-25:]))
raise SystemExit(result.returncode)
