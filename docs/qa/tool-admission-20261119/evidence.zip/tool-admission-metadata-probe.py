"""Retained metadata admission red/green proof; real producer, authored fake FLOSS, synthetic PEs only."""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import subprocess
from tempfile import TemporaryDirectory
import threading

from test_ui_strings_run import fake_floss, make_project, tool_store
from patchtrace.intelligence.tools import runner
from patchtrace.intelligence.tools.common import ToolError, evidence_entry_id

parser=argparse.ArgumentParser()
parser.add_argument('--admitted',action='store_true')
mode=parser.parse_args().admitted
if mode:
    from patchtrace.intelligence.tools.admission import latest_admitted

cases=[]
with TemporaryDirectory(prefix='tool-metadata-admission-') as directory:
    folder=Path(directory)
    with make_project(folder,'floss-static') as service:
        request=runner.RunRequest(tuple(runner.ArtifactRef(a.side,service.root/a.relative_path,a.sha256,a.size)
                                         for a in service.project.artifacts),
                                  runner.Setup(floss=fake_floss(folder,service)),profile='context',engines=('floss',))
        store=tool_store(service)
        first=runner.run_tools(request,store,threading.Event())
        second=runner.run_tools(request,store,threading.Event())
        original=next(r for r in first if r.run.side=='newer')
        cached=next(r for r in second if r.run.side=='newer')
        assert cached.run.cache_hit and cached.run.raw_sidecar is None
        assert cached.evidence.run_id==original.run.run_id!=cached.run.run_id
        assert original.run.raw_sidecar is not None
        db=service.store.connection
        identities={'selected-run':cached.run.run_id,'evidence':evidence_entry_id(cached.evidence),
                    'origin-run':original.run.run_id}
        mutations={'stale':1,'project_id':'foreign-authored-project','run_id':'foreign-guard-run',
                   'raw_sha256':'f'*64,'input_digest':'e'*64,'status':'failed','id':'foreign-authored-row'}
        for row,identity in identities.items():
            for field,value in mutations.items():
                prior=db.execute(f'SELECT {field} FROM enrichment_entries WHERE id=?',(identity,)).fetchone()[0]
                db.execute(f'UPDATE enrichment_entries SET {field}=? WHERE id=?',(value,identity))
                try:
                    if mode:
                        result=latest_admitted(store,engine='floss',side='newer',
                                               artifact_sha256=cached.run.input_artifact_hash)
                        accepted=result is not None
                        selected=result.run.run_id if result else None
                    else:
                        result=store.latest('floss','newer')
                        accepted=result is not None
                        selected=result[0].run_id if result else None
                    outcome={'accepted':accepted,'selected_cached_attempt':selected==cached.run.run_id}
                except ToolError as exc:
                    outcome={'accepted':False,'refused':exc.code}
                finally:
                    db.execute(f'UPDATE enrichment_entries SET {field}=? WHERE id=?',
                               (prior,value if field=='id' else identity))
                cases.append({'row':row,'field':field,**outcome})
        result={'source':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
                'mode':'shared-admission' if mode else 'legacy-latest',
                'producer':{'fresh_cache_hit':original.run.cache_hit,'cached_cache_hit':cached.run.cache_hit,
                            'cached_raw_sidecar':cached.run.raw_sidecar,
                            'cached_stdout_digest':cached.run.stdout_digest,
                            'origin_has_raw_sidecar':original.run.raw_sidecar is not None,
                            'origin_has_stdout_digest':original.run.stdout_digest is not None,
                            'evidence_keeps_origin_run_id':cached.evidence.run_id==original.run.run_id},
                'cases':cases,'invalid_cases_accepted':sum(c['accepted'] for c in cases)}
print(json.dumps(result,indent=2))
