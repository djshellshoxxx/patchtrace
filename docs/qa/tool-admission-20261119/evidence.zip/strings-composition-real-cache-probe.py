"""Actual tool-run/cache producer to Strings composition compatibility probe.

Uses an authored fake FLOSS executable and synthetic PE fixture inputs. No target
or real native engine runs. Run from a chosen worktree with PYTHONPATH=src:tests.
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import tempfile
import threading
from pathlib import Path
from types import SimpleNamespace

from test_ui_strings_run import fake_floss, make_project, tool_store

from patchtrace.intelligence.tools import runner
from patchtrace.strings import compose
from patchtrace.strings.cli import compute

with tempfile.TemporaryDirectory(prefix='strings-independent-cache-') as directory:
    root = Path(directory)
    with make_project(root, 'floss-static') as service:
        request = runner.RunRequest(
            tuple(runner.ArtifactRef(a.side, service.root / a.relative_path, a.sha256, a.size)
                  for a in service.project.artifacts),
            runner.Setup(floss=fake_floss(root, service)), profile='context', engines=('floss',))
        store = tool_store(service)
        first = runner.run_tools(request, store, threading.Event())
        first_sources = compute(SimpleNamespace(source='auto', anchors=None, min_length=4), service,
                                threading.Event()).sources
        again = runner.run_tools(request, store, threading.Event())
        second_sources = compute(SimpleNamespace(source='auto', anchors=None, min_length=4), service,
                                 threading.Event()).sources
        latest = {side: store.latest('floss', side) for side in ('older', 'newer')}
        result = {
            'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
            'compose_sha256': hashlib.sha256(Path(compose.__file__).read_bytes()).hexdigest(),
            'first_cache_hits': [job.run.cache_hit for job in first], 'first_sources': first_sources,
            'second_cache_hits': [job.run.cache_hit for job in again], 'second_sources': second_sources,
            'latest': {
                side: {'cache_hit': pair[0].cache_hit, 'raw_sidecar': pair[0].raw_sidecar,
                       'run_id': pair[0].run_id, 'evidence_run_id': pair[1].run_id,
                       'same_artifact': pair[0].input_artifact_hash == pair[1].artifact_sha256,
                       'same_config': pair[0].config_digest == pair[1].config_digest,
                       'same_key': pair[0].cache_key == pair[1].cache_key}
                for side, pair in latest.items()},
        }

print(json.dumps(result, indent=2))
