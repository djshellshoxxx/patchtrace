"""Real Strings composition after metadata-only tool-run guard drift.

Authored PE inputs and fake FLOSS only; no target or native tool execution.
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import tempfile
import threading
from pathlib import Path
from types import SimpleNamespace

from test_ui_strings_run import make_project, tool_store
from test_ui_strings_source import store_floss

from patchtrace.intelligence.tools import store as store_module
from patchtrace.strings import compose
from patchtrace.strings.cli import compute

record = {'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'source_hashes': {str(Path(module.__file__)): hashlib.sha256(Path(module.__file__).read_bytes()).hexdigest()
                            for module in (compose, store_module)}, 'cases': []}
for name, column, value in [('stale-run', 'stale', 1),
                            ('foreign-run-project', 'project_id', 'foreign-authored-project')]:
    with tempfile.TemporaryDirectory(prefix='strings-independent-guard-') as directory:
        folder = Path(directory)
        with make_project(folder, 'floss-static') as service:
            store_floss(folder, service, 'older', 'newer')
            args = SimpleNamespace(source='auto', anchors=None, min_length=4)
            before = compute(args, service, threading.Event())
            store = tool_store(service)
            run, evidence = store.latest('floss', 'newer')
            if column == 'stale':
                service.store.connection.execute('UPDATE enrichment_entries SET stale=? WHERE id=?',
                                                 (value, run.run_id))
            else:
                service.store.connection.execute('UPDATE enrichment_entries SET project_id=? WHERE id=?',
                                                 (value, run.run_id))
            again = store.latest('floss', 'newer')
            after = compute(args, service, threading.Event())
            record['cases'].append({'case': name, 'before_sources': before.sources, 'after_sources': after.sources,
                                    'same_run_selected': again is not None and again[0].run_id == run.run_id,
                                    'run_body_unchanged': again is not None and again[0] == run,
                                    'evidence_body_unchanged': again is not None and again[1] == evidence})

print(json.dumps(record, indent=2))
