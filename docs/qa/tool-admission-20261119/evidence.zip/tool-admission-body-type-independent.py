"""Selected raw storage-type refusal through the actual tool producer.

Authored fake FLOSS and synthetic PE inputs only. This is a draft-admission
probe, not native acceptance or an assertion that the enclosing branch passed.
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
import subprocess
import tempfile
import threading
from pathlib import Path

from test_ui_strings_run import fake_floss, make_project, tool_store

from patchtrace.intelligence.tools import admission, runner
from patchtrace.intelligence.tools.common import ToolError, evidence_entry_id


def outcome(store, artifact):
    try:
        found = admission.latest_admitted(store, engine='floss', side='newer',
                                          artifact_sha256=artifact.sha256)
        return {'accepted': found is not None}
    except ToolError as exc:
        return {'accepted': False, 'typed_refusal': exc.code}
    except Exception as exc:
        return {'accepted': False, 'unexpected_exception': type(exc).__name__, 'message': str(exc)}


record = {'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'admission_sha256': hashlib.sha256(Path(admission.__file__).read_bytes()).hexdigest(),
          'cases': []}
with tempfile.TemporaryDirectory(prefix='tool-admission-body-type-') as directory:
    folder = Path(directory)
    with make_project(folder, 'floss-static') as service:
        request = runner.RunRequest(
            tuple(runner.ArtifactRef(a.side, service.root / a.relative_path, a.sha256, a.size)
                  for a in service.project.artifacts),
            runner.Setup(floss=fake_floss(folder, service)), profile='context', engines=('floss',))
        store = tool_store(service)
        jobs = runner.run_tools(request, store, threading.Event())
        selected = next(job for job in jobs if job.run.side == 'newer')
        artifact = next(a for a in service.project.artifacts if a.side == 'newer')
        record['before'] = outcome(store, artifact)
        db = service.store.connection
        for row, identity in [('run', selected.run.run_id),
                              ('evidence', evidence_entry_id(selected.evidence))]:
            body, digest = db.execute('SELECT body, body_sha256 FROM enrichment_entries WHERE id=?',
                                      (identity,)).fetchone()
            # SQLite TEXT affinity accepts BLOB. Preserve the exact bytes and hash;
            # this exercises the store boundary before strict JSON/model validation.
            db.execute('UPDATE enrichment_entries SET body=? WHERE id=?',
                       (sqlite3.Binary(body.encode('utf-8')), identity))
            try:
                record['cases'].append({'row': row, 'storage_type': 'blob', **outcome(store, artifact)})
            finally:
                db.execute('UPDATE enrichment_entries SET body=?, body_sha256=? WHERE id=?',
                           (body, digest, identity))

print(json.dumps(record, indent=2))
