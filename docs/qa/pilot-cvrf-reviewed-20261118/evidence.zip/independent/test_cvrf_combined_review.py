"""Independent end-to-end malformed-context/history/report controls."""
import json

import pytest
import test_pilot_kb_context as authored
from pilot_freshness_support import loaded, sidecar_bytes

from patchtrace import cli
from patchtrace.report2.adapters import collect_from_service
from patchtrace.service import ProjectService

case = authored.case
offline = authored.offline


@pytest.mark.parametrize('column,value', [
    ('body', b'{"invalid":"binary storage class"}'),
    ('body_sha256', b'0' * 64),
    ('id', b'kb-context:independent-binary-id'),
])
@pytest.mark.parametrize('route', ['cli', 'desktop'])
def test_corrupt_context_stales_saved_leads_preserves_history_and_restores(case, capsys, column, value, route):
    assert cli.main(['pilot', 'leads', str(case), '--json', '--cve', authored.CVE]) == 0
    initial = json.loads(capsys.readouterr().out)['result']
    assert initial['stored'] and not initial['stale'] and initial['leads']
    with ProjectService.open(case) as service:
        baseline = loaded(service, route)
        assert baseline.state == 'current'
        before = sidecar_bytes(service)
        db = service.store.connection
        original = db.execute('SELECT ' + column + ' FROM enrichment_entries WHERE kind=?', ('kb-context',)).fetchone()[0]
        with db:
            db.execute('UPDATE enrichment_entries SET ' + column + '=? WHERE kind=?', (value, 'kb-context'))
        stale = loaded(service, route)
        assert stale.state == 'stale' and 'kb_link_digest' in stale.changed
        assert stale.assessment == baseline.assessment
        sections = collect_from_service(service)
        assert sections.leads is None
        assert any('stale' in text and 'leads omitted' in text for text in sections.unknowns)
        assert sidecar_bytes(service) == before
        with db:
            db.execute('UPDATE enrichment_entries SET ' + column + '=? WHERE kind=?', (original, 'kb-context'))
        restored = loaded(service, route)
        assert restored.state == 'current' and restored.assessment == baseline.assessment
        assert collect_from_service(service).leads
        assert sidecar_bytes(service) == before
