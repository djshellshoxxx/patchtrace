"""Observe real SQLite constructor cleanup without changing the original root probe."""
from __future__ import annotations

import json
import os
from pathlib import Path
import sqlite3

import pytest

from patchtrace.input_readers import InputReadError
from patchtrace.persistence import ProjectLock, ProjectStore
from patchtrace.sample import synthetic_pe
from patchtrace.service import ProjectService

OUT = Path(os.environ['PATCHTRACE_CONSTRUCTOR_CLEANUP_OUTPUT'])


@pytest.mark.parametrize('primary_kind', ['neutral', 'sqlite'])
@pytest.mark.parametrize('cleanup', ['before-close', 'after-close', 'healthy'])
def test_constructor_secondary_cleanup_preserves_primary_and_uncertainty(tmp_path, monkeypatch,
                                                                        primary_kind, cleanup):
    sources = [tmp_path / (side + '.dll') for side in ('older', 'newer')]
    for variant, path in enumerate(sources):
        path.write_bytes(synthetic_pe(variant))
    root = tmp_path / 'project'
    with ProjectService.create(*sources, 'retained authored project', root):
        pass
    foreign = root / 'analyst.txt'
    foreign.write_bytes(b'Retain analyst-owned evidence.')
    before = {path: path.read_bytes() for path in root.rglob('*')
              if path.is_file() and path.name != '.patchtrace.lock'}
    primary = (InputReadError('cancelled') if primary_kind == 'neutral'
               else sqlite3.OperationalError('authored initialization refusal'))
    secondary = PermissionError('private cleanup detail /secret/location')
    real_connect, real_init = sqlite3.connect, ProjectStore.__init__
    stores, connections, close_calls = [], [], []

    class ActualConnection(sqlite3.Connection):
        def execute(self, statement, *args, **kwargs):
            if statement == 'PRAGMA quick_check':
                raise primary
            return super().execute(statement, *args, **kwargs)

        def close(self):
            close_calls.append(cleanup)
            if cleanup != 'before-close':
                super().close()
            if cleanup != 'healthy':
                raise secondary

    def connect(*args, **kwargs):
        assert 'factory' not in kwargs
        connection = real_connect(*args, factory=ActualConnection, **kwargs)
        connections.append(connection)
        return connection

    def initialize(store, *args, **kwargs):
        stores.append(store)
        return real_init(store, *args, **kwargs)

    monkeypatch.setattr(sqlite3, 'connect', connect)
    monkeypatch.setattr(ProjectStore, '__init__', initialize)
    caught = None
    try:
        try:
            ProjectService.open(root, maintenance=False, recover_interrupted=False)
        except BaseException as exc:
            caught = exc
        assert len(stores) == len(connections) == 1
        store = stores[0]
        notes = getattr(caught, '__notes__', [])
        observed = {
            'primary_kind': primary_kind, 'cleanup': cleanup, 'caught_type': type(caught).__name__,
            'primary_preserved': caught is primary, 'cause_preserved': caught.__cause__ is primary,
            'notes': notes, 'store_closed': store.closed, 'connection_retained': store.connection is not None,
            'lock_retained': store.lock is not None, 'close_calls': list(close_calls),
            'project_files_unchanged': all(path.read_bytes() == data for path, data in before.items()),
        }
        OUT.mkdir(parents=True, exist_ok=True)
        with (OUT / f'{primary_kind}-{cleanup}.json').open('x') as output:
            json.dump(observed, output, indent=2)
            output.write('\n')
    finally:
        # Test-owned cleanup bypasses the authored refusal only after observing it.
        for connection in connections:
            sqlite3.Connection.close(connection)
        for store in stores:
            store.connection = None
            if store.lock is not None:
                ProjectLock.close(store.lock)
                store.lock = None
            store.closed = True
    assert observed['project_files_unchanged']
    if primary_kind == 'neutral':
        assert caught is primary
    else:
        assert type(caught) is ValueError
        assert str(caught) == 'PT-STORAGE: project database cannot be opened'
        assert caught.__cause__ is primary
    if cleanup == 'healthy':
        assert not notes and observed['store_closed']
    else:
        assert len(notes) == 1 and len(notes[0]) < 160
        assert 'cleanup' in notes[0] and 'remain' in notes[0]
        assert 'private' not in notes[0] and '/secret' not in notes[0]
