"""Pin core admission; allow inspected headless children and deny parent network events."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import ssl
import shutil
import stat
import subprocess
import sys
import tempfile
import time

ROOT = Path('/workspace/scratch/c7a9e8d98848/security-residual-qa')
QA = Path(__file__).resolve().parent
SOURCE, LABEL, *FILES = sys.argv[1:]
assert LABEL.replace('-', '').isalnum() and FILES
sys.dont_write_bytecode = True
sys.path[:0] = [str(ROOT / 'src'), str(ROOT), str(ROOT / 'tests')]
os.environ.update(PYTHONPATH=f'{ROOT}/src:{ROOT}', QT_QPA_PLATFORM='offscreen',
                  PYTHONDONTWRITEBYTECODE='1', PATCHTRACE_OPEN_REVIEW_OUTPUT=str(QA / f'{LABEL}-observations'))
os.environ.update(
    PATCHTRACE_CONSTRUCTOR_REVIEW_OUTPUT=str(QA / f'{LABEL}-root-observations'),
    PATCHTRACE_CONSTRUCTOR_CLEANUP_OUTPUT=str(QA / f'{LABEL}-cleanup-observations'),
)
for key in ('PATCHTRACE_CONSTRUCTOR_REVIEW_OUTPUT', 'PATCHTRACE_CONSTRUCTOR_CLEANUP_OUTPUT'):
    assert not Path(os.environ[key]).exists()

for suffix in ('command.json', 'xml', 'imports.json', 'exit.json'):
    assert not (QA / f'{LABEL}.{suffix}').exists()
assert not Path(os.environ['PATCHTRACE_OPEN_REVIEW_OUTPUT']).exists()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT,
                                   env=dict(os.environ, GIT_NO_REPLACE_OBJECTS='1'))


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert git('diff', '--name-only', 'HEAD') == b''
blobs = {}
for entry in git('ls-tree', '-r', '-z', SOURCE, 'src', 'tests').split(b'\0'):
    if entry:
        meta, name = entry.split(b'\t', 1)
        blobs[name.decode()] = meta.split()[2].decode()
files = [{'path': str(Path(path).resolve()), 'sha256': hashlib.sha256(Path(path).read_bytes()).hexdigest()}
         for path in FILES]
import pytest

HEADLESS_IMPORTS = ('import sys\nfrom patchtrace.kbcorrelation import cli, wiring, service\nwiring.build_env()\nbad = [m for m in sys.modules if m.split(".")[0] in ("PySide6", "PyQt5", "PyQt6", "shiboken6")]\nprint(bad)\nsys.exit(1 if bad else 0)\n', 'import sys; import patchtrace.kbcorrelation.investigation_service; assert "PySide6" not in sys.modules')

attempts, children = [], []


def audit(event, args):
    if event == 'subprocess.Popen':
        executable, argv, cwd, environment = args
        direct_cli = len(argv) >= 5 and list(argv[1:4]) == ['-m', 'patchtrace', 'project'] and argv[4] in {'sample', 'info'}
        authored_cli = (len(argv) == 3 and argv[1] == '-c'
                        and str(argv[2]).startswith('import sys\nfrom patchtrace import cli\n'))
        headless_import = len(argv) == 3 and argv[1] == '-c' and argv[2] in HEADLESS_IMPORTS
        pinned = isinstance(environment, dict) and environment.get('PYTHONPATH') == str(ROOT / 'src')
        if executable == sys.executable and pinned and (direct_cli or authored_cli or headless_import):
            children.append({'argv': list(argv), 'cwd': cwd, 'PYTHONPATH': environment['PYTHONPATH'],
                             'scope': 'Existing authored CLI journey or exact headless import control; parent audit only.'})
            return
    if event in {'socket.__new__', 'socket.connect', 'subprocess.Popen', 'os.system', 'os.fork', 'os.posix_spawn'}:
        attempts.append(event)
        raise AssertionError('affected gate permits only source-pinned authored CLI children and no network')


start = time.monotonic()
temporary = tempfile.mkdtemp(prefix='core-constructor-cleanup-')
arguments = ['-q', '-p', 'no:cacheprovider', '-c', str(ROOT / 'pyproject.toml'),
             '--basetemp', str(Path(temporary) / 'pytest'), *FILES, f'--junitxml={QA}/{LABEL}.xml']
(QA / f'{LABEL}.command.json').write_text(json.dumps({
    'source_commit': SOURCE, 'cwd': str(ROOT), 'python': sys.version,
    'argv': [sys.executable, str(Path(__file__).resolve()), SOURCE, LABEL, *FILES],
    'pytest_arguments': arguments, 'test_files': files,
    'environment': {key: os.environ[key] for key in ('PYTHONPATH', 'QT_QPA_PLATFORM', 'PYTHONDONTWRITEBYTECODE',
                                                   'PATCHTRACE_OPEN_REVIEW_OUTPUT', 'PATCHTRACE_CONSTRUCTOR_REVIEW_OUTPUT',
                                                   'PATCHTRACE_CONSTRUCTOR_CLEANUP_OUTPUT')},
}, indent=2) + '\n')
sys.addaudithook(audit)
result = int(pytest.main(arguments))
modules, drift = [], []
for name, module in sorted(sys.modules.items()):
    if not getattr(module, '__file__', None):
        continue
    path = Path(module.__file__).resolve()
    if not (name.startswith('patchtrace') or path.is_relative_to(ROOT / 'tests')):
        continue
    entry = {'name': name, 'path': str(path)}
    if not path.is_relative_to(ROOT):
        drift.append(name)
    else:
        relative = path.relative_to(ROOT).as_posix()
        data = path.read_bytes()
        blob = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
        entry.update(relative_path=relative, git_blob=blob, expected_git_blob=blobs.get(relative),
                     sha256=hashlib.sha256(data).hexdigest())
        if blob != blobs.get(relative):
            drift.append(name)
    modules.append(entry)
for entry in files:
    if hashlib.sha256(Path(entry['path']).read_bytes()).hexdigest() != entry['sha256']:
        drift.append(entry['path'])
(QA / f'{LABEL}.imports.json').write_text(json.dumps({
    'source_commit': SOURCE, 'modules': modules, 'drift': drift,
}, indent=2) + '\n')
exit_code = result if not drift and not attempts else 1
files_retained = []
for parent, _directories, names in os.walk(temporary, followlinks=False):
    for name in names:
        info = (Path(parent) / name).lstat()
        if stat.S_ISREG(info.st_mode):
            files_retained.append((info.st_size, getattr(info, 'st_blocks', 0) * 512))
cleanup = {'owned_directory': temporary, 'regular_files': len(files_retained),
           'logical_bytes': sum(item[0] for item in files_retained),
           'allocated_bytes': sum(item[1] for item in files_retained), 'removed': False}
if exit_code == 0:
    try:
        shutil.rmtree(temporary)
        cleanup['removed'] = True
    except OSError as exc:
        cleanup['error_type'] = type(exc).__name__
        exit_code = 1
(QA / f'{LABEL}.exit.json').write_text(json.dumps({
    'source_commit': SOURCE, 'pytest_exit': result, 'exit_code': exit_code,
    'source_pinned_modules': len(modules), 'drift': drift, 'prohibited_attempts': attempts,
    'seconds': time.monotonic() - start, 'children': children, 'temporary_storage': cleanup,
}, indent=2) + '\n')
raise SystemExit(exit_code)
