"""Retain the constructor follow-up without rewriting the original checkpoint packet."""
from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/c7a9e8d98848/security-residual-qa')
QA = Path(__file__).resolve().parent
BASE = 'fa4bebbb7a5a7095d4764066ffb73cd73cf85499'
RED = 'f40d14c1970bf45efba4de448c00c8c49b463ae7'
SOURCE = '63ebc42746fbfbded311084288a339f26ed08d8c'
STEM = 'core-constructor-cleanup-20261118'
PREVIOUS = 'core-admission-checkpoints-20261118'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args, input=None):
    return subprocess.check_output(['git', *args], cwd=ROOT, input=input,
                                   env=dict(os.environ, GIT_NO_REPLACE_OBJECTS='1'))


def dump(name, value):
    (QA / name).write_text(json.dumps(value, indent=2) + '\n')


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('status', '--porcelain')
assert git('rev-parse', f'{SOURCE}^').decode().strip() == RED
assert git('rev-parse', f'{RED}^').decode().strip() == BASE
assert git('diff', '--name-only', BASE, SOURCE, '--', 'src').decode().splitlines() == ['src/patchtrace/persistence.py']
assert not git('diff', '--name-only', BASE, RED, '--', 'src')
assert not git('diff', '--name-only', BASE, SOURCE, '--', 'tools', 'schemas', '.github', 'src/patchtrace/service.py')
previous = ROOT / 'docs/qa' / f'{PREVIOUS}.zip'
assert sha(previous.read_bytes()) == '89970d49ed048ee63c22c88601831c0a39aca96f0147edcfd7398944cfcc43d6'
for suffix in ('md', 'manifest.json', 'zip'):
    relative = f'docs/qa/{PREVIOUS}.{suffix}'
    assert (ROOT / relative).read_bytes() == git('show', f'{BASE}:{relative}')

originals = json.loads((QA / 'original-root-records.json').read_text())
for item in originals:
    assert sha(Path(item['path']).read_bytes()) == item['sha256']
    assert sha((QA / item['copy']).read_bytes()) == item['sha256']

relative = 'src/patchtrace/persistence.py'
trees = [ast.parse(git('show', f'{commit}:{relative}')) for commit in (BASE, SOURCE)]
for tree in trees:
    owner = next(node for node in tree.body if isinstance(node, ast.ClassDef) and node.name == 'ProjectStore')
    initializer = next(node for node in owner.body if isinstance(node, ast.FunctionDef) and node.name == '__init__')
    protected = next(node for node in initializer.body if isinstance(node, ast.Try) and any(
        isinstance(handler.type, ast.Name) and handler.type.id in {'Exception', 'BaseException'}
        for handler in node.handlers))
    protected.handlers = []
assert ast.dump(trees[0], include_attributes=False) == ast.dump(trees[1], include_attributes=False)

command = json.loads((QA / 'affected.command.json').read_text())
result = json.loads((QA / 'affected.exit.json').read_text())
imports = json.loads((QA / 'affected.imports.json').read_text())
assert result['source_commit'] == imports['source_commit'] == SOURCE
assert result['exit_code'] == 0 and not result['drift'] and not result['prohibited_attempts']
assert result['temporary_storage']['removed'] and len(result['children']) == 5
blobs = {}
for entry in git('ls-tree', '-r', '-z', SOURCE, 'src', 'tests').split(b'\0'):
    if entry:
        meta, name = entry.split(b'\t', 1)
        blobs[name.decode()] = meta.split()[2].decode()
unique = sorted({item['git_blob'] for item in imports['modules']})
batch = git('cat-file', '--batch', input=('\n'.join(unique) + '\n').encode())
cursor, objects = 0, {}
for expected in unique:
    end = batch.index(b'\n', cursor)
    oid, kind, length = batch[cursor:end].decode().split()
    assert oid == expected and kind == 'blob'
    start = end + 1
    data = batch[start:start + int(length)]
    assert batch[start + len(data):start + len(data) + 1] == b'\n'
    objects[oid] = data
    cursor = start + len(data) + 1
assert cursor == len(batch)
for item in imports['modules']:
    assert item['git_blob'] == item['expected_git_blob'] == blobs[item['relative_path']]
    assert sha(objects[item['git_blob']]) == item['sha256']
for item in command['test_files']:
    assert sha(Path(item['path']).read_bytes()) == item['sha256']
red_command = json.loads((QA / 'spec-red.command.json').read_text())
for item in red_command['test_files']:
    assert sha(Path(item['path']).read_bytes()) == item['sha256']
assert git('show', f'{RED}:tests/test_project_store_constructor_cleanup.py') == (ROOT / 'tests/test_project_store_constructor_cleanup.py').read_bytes()
probe = QA / 'test_constructor_cleanup_precedence.py'
first_command = json.loads((QA / 'secondary-red.command.json').read_text())
assert any(item['sha256'] == sha(probe.read_bytes()) for item in first_command['test_files'])

counts = []
for label, expected in {
    'original-root/initial': (3, 2, 0, 0), 'secondary-red': (9, 6, 0, 0),
    'spec-red': (50, 31, 0, 0), 'focused-green': (50, 0, 0, 0), 'affected': (562, 0, 0, 0),
}.items():
    path = QA / f'{label}.xml'
    suites = list(ET.parse(path).getroot().iter('testsuite'))
    actual = tuple(sum(int(suite.attrib.get(key, 0)) for suite in suites)
                   for key in ('tests', 'failures', 'errors', 'skipped'))
    assert actual == expected
    counts.append({'label': label, **dict(zip(('tests', 'failures', 'errors', 'skipped'), actual)),
                   'passed': actual[0] - sum(actual[1:]), 'sha256': sha(path.read_bytes())})

for label, argv in (
    ('exact-normal-ruff', ['/workspace/scratch/3a6632a6e5ff/venv/bin/python', '-m', 'ruff', 'check', 'src', 'tests', 'tools', '--no-cache']),
    ('exact-diff-check', ['git', 'diff', '--check', f'{BASE}..{SOURCE}']),
):
    with (QA / f'{label}.log').open('xb') as output:
        completed = subprocess.run(argv, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
    dump(f'{label}.command.json', {'source_commit': SOURCE, 'cwd': str(ROOT), 'argv': argv, 'exit_code': completed.returncode})
    assert completed.returncode == 0

paths = {'AGENTS.md', 'pyproject.toml', 'docs/specs/core-held-inputs.md', 'docs/specs/architecture.md',
         'src/patchtrace/persistence.py', 'src/patchtrace/service.py', 'src/patchtrace/input_readers.py',
         'src/patchtrace/ingestion.py', 'src/patchtrace/models.py', 'src/patchtrace/sample.py'}
for item in command['test_files']:
    path = Path(item['path'])
    if path.is_relative_to(ROOT):
        paths.add(path.relative_to(ROOT).as_posix())
for item in imports['modules']:
    if item['relative_path'].startswith('tests/'):
        paths.add(item['relative_path'])
payloads, source_records = {}, []
for role, commit, selected in (
    ('corrected', SOURCE, sorted(paths)),
    ('previous', BASE, ['src/patchtrace/persistence.py', 'docs/specs/core-held-inputs.md']),
):
    for relative in selected:
        data = git('show', f'{commit}:{relative}')
        member = f'canonical-source/{role}/{relative}'
        payloads[member] = data
        source_records.append({'role': role, 'commit': commit, 'path': relative, 'member': member,
                               'git_blob': git('rev-parse', f'{commit}:{relative}').decode().strip(),
                               'sha256': sha(data), 'bytes': len(data)})
dump('canonical-source.json', source_records)
dump('verification.json', {
    'source_commit': SOURCE, 'previous_qa': BASE, 'spec_test_commit': RED,
    'previous_archive_sha256': sha(previous.read_bytes()), 'previous_packet_unchanged': True,
    'original_root_records_verified': len(originals), 'secondary_probe_sha256': sha(probe.read_bytes()),
    'tests_and_probes_unchanged_since_red': True, 'xml': counts,
    'pinned_parent_imports': len(imports['modules']), 'unique_verified_import_blobs': len(unique),
    'canonical_git_snapshots': len(source_records),
    'all_persistence_ast_except_existing_constructor_handler_unchanged': True,
    'service_schema_tools_workflows_unchanged': True,
    'production_change': {'path': 'src/patchtrace/persistence.py', 'insertions': 14, 'deletions': 10},
})
for name, start, end in (('source.patch', RED, SOURCE), ('spec-tests.patch', BASE, RED)):
    (QA / name).write_bytes(git('diff', '--binary', start, end, '--', 'src', 'tests', 'docs/specs'))
dump('chain.json', [{'role': role, 'commit': commit,
                     'tree': git('rev-parse', f'{commit}^{{tree}}').decode().strip(),
                     'parents': git('show', '-s', '--format=%P', commit).decode().strip().split(),
                     'subject': git('show', '-s', '--format=%s', commit).decode().strip()}
                    for role, commit in [('previous_qa', BASE), ('spec_test', RED), ('source', SOURCE)]])
for path in sorted(QA.rglob('*')):
    if path.is_file() and path.name != 'seal-result.json':
        assert not path.is_symlink()
        payloads['receipts/' + path.relative_to(QA).as_posix()] = path.read_bytes()
for item in command['test_files']:
    path = Path(item['path'])
    if not path.is_relative_to(ROOT) and not path.is_relative_to(QA):
        payloads['receipts/previous-external/' + path.name] = path.read_bytes()
archive = ROOT / 'docs/qa' / f'{STEM}.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(payloads.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        output.writestr(info, data)
manifest = {'source_commit': SOURCE, 'archive': archive.name, 'archive_sha256': sha(archive.read_bytes()),
            'archive_bytes': archive.stat().st_size, 'payload_count': len(payloads),
            'uncompressed_bytes': sum(map(len, payloads.values())),
            'payloads': [{'path': name, 'sha256': sha(data), 'bytes': len(data)} for name, data in sorted(payloads.items())]}
(ROOT / 'docs/qa' / f'{STEM}.manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None and len(output.namelist()) == len(payloads)
    for item in manifest['payloads']:
        data = output.read(item['path'])
        assert sha(data) == item['sha256'] and len(data) == item['bytes']
report = (QA / 'README.md').read_text()
report += (f'\n## Sealed append packet\n\nThe [{len(payloads)}-payload archive]({archive.name}) '
           f'contains {manifest["uncompressed_bytes"]:,} uncompressed bytes '
           f'({manifest["archive_bytes"]:,} ZIP bytes), including {len(source_records)} canonical Git snapshots.\n'
           f'Archive SHA-256: `{manifest["archive_sha256"]}`. '
           f'The [manifest]({STEM}.manifest.json) records each payload hash and size.\n')
(ROOT / 'docs/qa' / f'{STEM}.md').write_text(report)
dump('seal-result.json', {key: manifest[key] for key in ('source_commit', 'archive', 'archive_sha256',
                                                       'archive_bytes', 'payload_count', 'uncompressed_bytes')})
print(json.dumps({'archive': str(archive), 'payload_count': len(payloads), 'canonical_sources': len(source_records),
                  'sha256': manifest['archive_sha256'], 'bytes': manifest['archive_bytes']}))
