# Authored advisory field attribution review — 2026-11-02

Exact reviewed head: `6f923758efb57e3f19a43b5b1d2c1ba8319e1823`.

Confirmed: context selects the preferred CVRF card at `context.py:121` but independently selects an edge and its source at lines 122/126. Line 131 passes this mixed pair to `IntelligenceRules.interpret`; `wiring.py:153–154` constructs a CWE pointer and source identity from that edge. The unchanged source lines date to `2804fbf9`, so the defect predates the latest identity repair.

The authored CVRF card states CWE-125 at vulnerability row 0 and has no edges. An authored, actually validated CSAF document provides the target CVE edge at row 1 and states CWE-787. The persisted actual ContextBundle classifies CWE-125 at `/vulnerabilities/1/cwe`; that location contains CWE-787 in CSAF and unrelated CWE-476 in CVRF. Its derived hypothesis retains CWE-125. Both source SHA values are present in the bundle, confirming the raw-source identity repair works without correcting per-field attribution.

CweProfile has no persisted source_id. The SHA mismatch is observed at the real RulesPort call and CVEFact construction; the stored error is the pointer/basis linkage, not a nonexistent persisted hypothesis SHA. No binary or target analysis was performed, and fixtures are synthetic CVE-2099 records.

Review disposition: unresolved material provenance defect at this head. Root authorized a separate narrow repair; this receipt claims reproduction only, not a fix or broad merge qualification. Exact source and artifact hashes, command and result are in the JSON sibling.
