"""Bounded authored-advisory provenance probe; no network, target or native analysis execution."""
import argparse
import json
from pathlib import Path

import kbc_helpers as h
from kbc_k1_support import IntelligenceAdvisoryPort

from patchtrace.kbcorrelation import context, wiring
from patchtrace.kbcorrelation.contracts import Lead
from patchtrace.kbcorrelation.index import ReverseIndex
from patchtrace.kbcorrelation.sources.importer import import_bytes

NOW = '2099-02-15T00:00:00Z'


def resolve(value, pointer):
    for token in pointer.split('/')[1:]:
        value = value[int(token)] if isinstance(value, list) else value[token]
    return value


def probe(destination):
    destination.mkdir(parents=True, exist_ok=False)
    cvrf = h.cvrf_document([
        h.vulnerability(h.CVE_A, 'Authored target read issue', cwe=('CWE-125', 'Out-of-bounds Read')),
        h.vulnerability(h.CVE_B, 'Authored unrelated null issue', cwe=('CWE-476', 'NULL Pointer Dereference'))])
    from kbc_k1_support import valid_csaf
    csaf = valid_csaf()
    target = csaf['vulnerabilities'][0]
    target['title'] = 'Authored target write issue'
    target['cwe'] = {'id': 'CWE-787', 'name': 'Out-of-bounds Write'}
    decoy = dict(target, cve=h.CVE_B, title='Authored unrelated integer issue',
                 cwe={'id': 'CWE-190', 'name': 'Integer Overflow'},
                 product_status={'known_affected': [h.PRODUCT_SERVER]})
    decoy.pop('remediations', None)
    csaf['vulnerabilities'] = [decoy, target]
    raw_cvrf, raw_csaf = h.render_json(cvrf), h.render_json(csaf)
    a = import_bytes(raw_cvrf, now=NOW)
    b = import_bytes(raw_csaf, now=NOW, advisory=IntelligenceAdvisoryPort())
    assert not a.edges and any(e.cve == h.CVE_A for e in b.edges)
    observed = []
    class RecordedRules(wiring.IntelligenceRules):
        def interpret(self, card, pointer, source_sha256):
            observed.append({'card': card.model_dump(mode='json'), 'pointer': pointer,
                             'source_sha256': source_sha256})
            return super().interpret(card, pointer, source_sha256)
    index = ReverseIndex()
    index.add(a)
    index.add(b)
    bundle = context.build_bundle(
        investigation_id='00000000-0000-4000-8000-000000000153', base_revision=1,
        lead=Lead(kind='cve', value=h.CVE_A, raw=h.CVE_A), cves=(h.CVE_A,), index=index,
        rules=RecordedRules(), now=NOW, coverage=(index.coverage(now=NOW),), scope_id=None,
        pair_id=None, older_sha=None, newer_sha=None)
    classification, = bundle.cwe_profiles[0].classifications
    pointer, = classification.pointers
    assert bundle.context.cards[0].source_kind == 'cvrf'
    assert classification.cwe_id == 'CWE-125'
    assert observed[0]['source_sha256'] == b.source.sha256 != a.source.sha256
    assert pointer == '/vulnerabilities/1/cwe'
    assert resolve(csaf, pointer)['id'] == 'CWE-787'
    assert resolve(cvrf, pointer)['id'] == 'CWE-476'
    report = {'source_module': context.__file__, 'source_head': '6f923758efb57e3f19a43b5b1d2c1ba8319e1823',
              'cvrf_sha256': a.source.sha256, 'csaf_sha256': b.source.sha256,
              'selected_card': bundle.context.cards[0].model_dump(mode='json'),
              'interpret_arguments': observed, 'classification': classification.model_dump(mode='json'),
              'pointer_value_in_csaf': resolve(csaf, pointer),
              'pointer_value_in_cvrf': resolve(cvrf, pointer),
              'hypotheses': bundle.hypotheses[0].model_dump(mode='json'),
              'all_sources_retained': {s.sha256 for s in bundle.sources} == {a.source.sha256, b.source.sha256},
              'qualification': 'CweProfile stores pointers but no source_id; the wrong SHA is passed to rules, '
                               'while persisted pointers resolve to different CWE values in both retained sources.'}
    (destination / 'authored-cvrf.json').write_bytes(raw_cvrf)
    (destination / 'authored-csaf.json').write_bytes(raw_csaf)
    (destination / 'context.json').write_text(bundle.model_dump_json(indent=2) + '\n')
    (destination / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('destination', type=Path)
    probe(parser.parse_args().destination)
