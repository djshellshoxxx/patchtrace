"""Fresh authored-source #118 plus per-field provenance integration controls."""
import json

import kbc_helpers as h
import pytest
from kbc_k1_support import no_sockets  # noqa: F401
from kbc_k3_support import FixedClock, write_pair
from test_kbc_card_field_provenance import assert_resolves
from test_kbc_saved_scope import _add, _bundle, _document, _search, _service

from patchtrace.kbcorrelation import wiring
from patchtrace.kbcorrelation.context import ContextBundle

pytestmark = pytest.mark.usefixtures('no_sockets')


@pytest.mark.parametrize('mode', ['files', 'cached'])
def test_saved_scope_preserves_field_sources_after_late_card_only_revision(tmp_path, mode):
    service = _service(tmp_path)
    original = _document()
    selected = _add(service, original)
    _, inv, _ = _search(service, tmp_path, mode, selected)
    before = _bundle(service, inv)
    late = _document(title='unselected replacement', date='2099-02-14')
    late['vulnerabilities'][0]['remediations'] = []
    late['vulnerabilities'][0]['cwe'] = {'id': 'CWE-787', 'name': 'Unselected write claim'}
    replacement = _add(service, late)
    other = _add(service, _document('2099-Feb', h.CVE_A, 'out-of-scope same CVE'))
    assert not replacement.edges
    service = wiring.build_service(service.root, clock=FixedClock())
    after = _bundle(service, inv)
    assert after == before
    assert {ref.doc_id for ref in after.card_facts} == {selected.doc_id}
    assert not {replacement.doc_id, other.doc_id} & {ref.doc_id for ref in after.card_facts}
    assert_resolves(after, {selected.source.sha256: h.render_json(original)})
    old, new = write_pair(tmp_path)
    project = tmp_path / 'P'
    assert service.import_pair(inv, str(old), str(new), str(project)).exit == 0
    exported = tmp_path / 'context.json'
    assert service.export(str(project), str(exported), overwrite=False).exit == 0
    attached = ContextBundle.model_validate_json(exported.read_bytes())
    assert {ref.doc_id for ref in attached.card_facts} == {selected.doc_id}
    assert_resolves(attached, {selected.source.sha256: h.render_json(original)})
    assert {p.name for p in (project / 'kb/sources').glob('*.gz')} == {selected.source.sha256 + '.json.gz'}
    assert json.loads(exported.read_bytes())['cwe_profiles'][0]['classifications'][0]['cwe_id'] == 'CWE-125'
