"""Independent bounded static analysis of the authored shared-library control only."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import threading

from patchtrace.jobs import run_process
from patchtrace.secondary import rzdiff
from patchtrace.secondary.engine_env import engine_env

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
RESEARCH = ROOT / 'l2-rizin-discovery-patch-20261118'
SOURCE = ROOT / 'pw01-current-integration'
EXPECTED_SOURCE = '939d4a9051ecbd6ebc0cc97e20756c1a881ee070'
assert Path(rzdiff.__file__).resolve() == SOURCE / 'src/patchtrace/secondary/rzdiff.py'
assert subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD'], text=True).strip() == EXPECTED_SOURCE


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


tools = {
    'unmodified': ('238983217e7b752b2bf7b059303dc0d3a4d36aeb81fb506a4e38b509738414e1',
                   RESEARCH / 'runtime/unmodified/bin/rz-diff'),
    'patched': ('9fda591fe2d64ec5db5579849c52b03eae67930b1f342a0d0161e2eeeecef3c7',
                RESEARCH / 'runtime/patched/bin/rz-diff'),
}
inputs = {side: RESEARCH / f'controls/build/shared/{side}/control.so' for side in ('older', 'newer')}
input_hashes = {side: digest(path) for side, path in inputs.items()}
assert input_hashes == {
    'older': 'e229bdc6e83e66f09ca0c415ac43d9b97ef19d223c0daa8c2b7528d64fd64aff',
    'newer': 'd3b73651874bfaccc4f3455e74f31e085b94bf45a0a340a741d9dbb3f3a8c8c2',
}
pilot = ROOT / 'l2-native-pilot/20261118T082742Z-http-parser'
sealed = {name: digest(pilot / name) for name in ('pilot-plan.json', 'pilot-result.json')}
assert sealed['pilot-result.json'] == '6d95d0b857d2a2cdb61ceecf6a69d05133dd852677aa6889b10fbd4544de339e'
environment = engine_env(os.environ, 'rz-diff')
expected_symbols = {'sym.diag_stable_add', 'sym.diag_stable_xor', 'sym.diag_changed', 'sym.diag_dispatch'}
records = []
for variant, (sha, executable) in tools.items():
    assert digest(executable) == sha
    argv = rzdiff.rzdiff_argv(str(executable), inputs['older'], inputs['newer'])
    result = run_process(argv, cwd=RESEARCH, env=environment, cancel=threading.Event(), timeout_seconds=30,
                         log_limit=8 * 1024 * 1024, separate_streams=True, stderr_limit=2 * 1024 * 1024,
                         max_output_bytes=10 * 1024 * 1024)
    stdout, stderr = result.log_bytes or b'', result.stderr_bytes or b''
    (OUT / f'{variant}.stdout').write_bytes(stdout)
    (OUT / f'{variant}.stderr').write_bytes(stderr)
    receipt = {'source_commit': EXPECTED_SOURCE, 'argv': argv, 'cwd': str(RESEARCH),
               'tool_sha256': sha, 'input_sha256': input_hashes, 'timeout_seconds': 30,
               'stdout_limit': 8 * 1024 * 1024, 'stderr_limit': 2 * 1024 * 1024,
               'combined_output_limit': 10 * 1024 * 1024, 'environment_keys': sorted(environment),
               'returncode': result.returncode, 'reason': result.reason, 'seconds': result.elapsed_seconds,
               'stdout_sha256': hashlib.sha256(stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(stderr).hexdigest(),
               'stdout_bytes': len(stdout), 'stderr_bytes': len(stderr),
               'streams_complete': len(stdout) == result.stdout_total and len(stderr) == result.stderr_total,
               'candidate_reruns': 0, 'target_execution': False, 'ranking_or_scoring': False}
    (OUT / f'{variant}.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    assert result.returncode == 0 and result.reason is None and receipt['streams_complete']
    assert stdout == (RESEARCH / f'raw/{variant}-shared.stdout').read_bytes()
    raw = json.loads(stdout)
    normalized = rzdiff.interpret(result.returncode, stdout, stderr.decode(), '0.9.1',
                                 input_hashes['older'], input_hashes['newer'], 8 * 1024 * 1024)
    assert normalized.file_sha256 == receipt['stdout_sha256']
    assert not rzdiff.ambiguous_stored_ownership(normalized)
    names = {side: sorted({row[side]['name'] for row in raw if row.get(side)})
             for side in ('original', 'modified')}
    records.append({'variant': variant, 'native_rows': len(raw), 'normalized_matches': len(normalized.matches),
                    'authored_symbols': {side: sorted(expected_symbols & set(values)) for side, values in names.items()},
                    'all_authored_symbols_emitted_on_each_side': all(expected_symbols <= set(values) for values in names.values()),
                    'normalizer': 'ACCEPTED', 'singleton_ownership_guard': 'passed',
                    'native_stdout_equals_author_capture': True, 'tool_sha256': sha,
                    'stdout_sha256': receipt['stdout_sha256']})
    assert digest(executable) == sha and {side: digest(path) for side, path in inputs.items()} == input_hashes

assert records[0]['native_rows'] == 5 and not records[0]['all_authored_symbols_emitted_on_each_side']
assert records[1]['native_rows'] == 14 and records[1]['all_authored_symbols_emitted_on_each_side']
assert {name: digest(pilot / name) for name in sealed} == sealed
assert not subprocess.check_output(['git', '-C', str(SOURCE), 'status', '--porcelain'])
summary = {'scope': 'Independent source-patch review and two native static-analysis runs on the authored shared pair only',
           'patch_sha256': digest(RESEARCH / 'source/discovery-seed.patch'), 'source_commit': EXPECTED_SOURCE,
           'records': records, 'original_pilot_unchanged': True, 'candidate_reruns': 0,
           'target_execution': False, 'ranking_or_scoring': False,
           'limitations': ['Authored discovery evidence, not vulnerability-ranking accuracy.',
                           'No Windows native build or complete scheduler/producer qualification.',
                           'Root reviewed source and reran existing frozen binaries; did not independently rebuild them.']}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
