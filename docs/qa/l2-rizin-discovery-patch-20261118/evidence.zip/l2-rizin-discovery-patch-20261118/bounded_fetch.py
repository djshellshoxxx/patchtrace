"""Capture one bounded HTTPS resource through the ordinary environment transport."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time
import urllib.error
import urllib.parse
import urllib.request


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("url")
    p.add_argument("--host", action="append", required=True)
    p.add_argument("--out", type=Path, required=True)
    p.add_argument("--receipt", type=Path, required=True)
    p.add_argument("--max-bytes", type=int, default=2 * 1024 * 1024)
    p.add_argument("--sha256")
    args = p.parse_args()
    if args.out.exists() or args.receipt.exists():
        raise SystemExit("Refusing to replace prior output or receipt")
    begun = time.monotonic()
    record = {
        "kind": "bounded-resource-fetch/1",
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "argv": sys.argv,
        "url": args.url,
        "approved_hosts": args.host,
        "max_bytes": args.max_bytes,
        "expected_sha256": args.sha256,
        "transport": "urllib default environment transport; TLS verification enabled",
        "automatic_redirects": False,
        "status": "BLOCKED",
        "hops": [],
    }
    opener = urllib.request.build_opener(NoRedirect())
    url = args.url
    try:
        for index in range(5):
            parsed = urllib.parse.urlsplit(url)
            if (
                parsed.scheme != "https"
                or parsed.hostname not in args.host
                or parsed.port not in (None, 443)
                or parsed.username is not None
                or parsed.password is not None
                or parsed.fragment
            ):
                raise ValueError("URL outside approved HTTPS scope")
            if time.monotonic() - begun > 90:
                raise TimeoutError("Total request budget exceeded")
            request = urllib.request.Request(
                url, headers={"User-Agent": "PatchTrace-readiness/1", "Accept-Encoding": "identity"}
            )
            try:
                response = opener.open(request, timeout=20)
            except urllib.error.HTTPError as exc:
                response = exc
            with response:
                hop = {
                    "index": index,
                    "request_url": url,
                    "status": response.code,
                    "response_headers": dict(response.headers.items()),
                }
                record["hops"].append(hop)
                if response.code in (301, 302, 303, 307, 308):
                    location = response.headers.get("Location")
                    if not location:
                        raise ValueError("Redirect missing Location")
                    next_url = urllib.parse.urljoin(url, location)
                    hop["next_url"] = next_url
                    hop["next_host"] = urllib.parse.urlsplit(next_url).hostname
                    url = next_url
                    continue
                if response.code != 200:
                    body = response.read(64 * 1024)
                    args.out.write_bytes(body)
                    record["raw_failure_body"] = str(args.out)
                    record["raw_failure_sha256"] = hashlib.sha256(body).hexdigest()
                    record["raw_failure_bytes"] = len(body)
                    raise ValueError(f"HTTP {response.code}; no retry or transport change")
                advertised = response.headers.get("Content-Length")
                if advertised and int(advertised) > args.max_bytes:
                    raise ValueError("Content-Length exceeds resource budget")
                digest = hashlib.sha256()
                count = 0
                with args.out.open("xb") as target:
                    while True:
                        chunk = response.read(min(1024 * 1024, args.max_bytes - count + 1))
                        if not chunk:
                            break
                        if time.monotonic() - begun > 90:
                            raise TimeoutError("Total resource budget exceeded")
                        count += len(chunk)
                        if count > args.max_bytes:
                            raise ValueError("Response exceeds resource budget")
                        digest.update(chunk)
                        target.write(chunk)
                if advertised and count != int(advertised):
                    raise ValueError("Response length disagrees with Content-Length")
                actual = digest.hexdigest()
                record.update(
                    final_url=url, output=str(args.out), bytes=count,
                    actual_sha256=actual, complete=True,
                )
                if args.sha256 and actual != args.sha256:
                    raise ValueError("Pinned SHA-256 mismatch")
                record["status"] = "CAPTURED_PIN_MATCH" if args.sha256 else "CAPTURED"
                break
        else:
            raise ValueError("Redirect count exceeds budget")
    except Exception as exc:
        record["error_type"] = type(exc).__name__
        record["error"] = str(exc)
    finally:
        record["duration_seconds"] = round(time.monotonic() - begun, 3)
        record["finished_utc"] = datetime.now(timezone.utc).isoformat()
        with args.receipt.open("x", encoding="utf-8") as receipt:
            json.dump(record, receipt, indent=2, sort_keys=True)
            receipt.write("\n")
    print(json.dumps({key: record.get(key) for key in ("status", "bytes", "actual_sha256", "error", "duration_seconds")}))
    return 0 if str(record["status"]).startswith("CAPTURED") else 2


if __name__ == "__main__":
    raise SystemExit(main())
