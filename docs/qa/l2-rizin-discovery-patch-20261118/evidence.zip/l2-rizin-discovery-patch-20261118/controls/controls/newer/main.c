/* Authored diagnostic control; MIT licence. Never execute this target. */
int diag_dispatch(int);
int main(int argc, char **argv) { (void)argv; return diag_dispatch(argc); }
