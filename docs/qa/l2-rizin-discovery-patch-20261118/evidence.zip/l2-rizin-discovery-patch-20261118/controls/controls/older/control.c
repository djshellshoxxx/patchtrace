/* Authored diagnostic control; MIT licence. Never execute compiled targets. */
#define KEEP __attribute__((noinline, used, visibility("default")))
KEEP int diag_stable_add(int value) { return value + 2; }
KEEP int diag_stable_xor(int value) { return value ^ 0x24; }
KEEP int diag_changed(int value) { return value + 7; }
KEEP int diag_dispatch(int value) {
    return diag_stable_add(value) + diag_stable_xor(value) + diag_changed(value);
}
