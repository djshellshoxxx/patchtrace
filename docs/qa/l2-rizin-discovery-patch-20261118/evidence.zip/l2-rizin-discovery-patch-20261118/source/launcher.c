// SPDX-License-Identifier: MIT
// Authored thin launcher for the published Rizin CLI entry point.
#include <rz_main.h>

int main(int argc, const char **argv) {
	return rz_main_rz_diff(argc, argv);
}
