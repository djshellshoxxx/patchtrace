"""Rebuild two Rizin CLI variants with identical flags and pinned static libraries."""
from __future__ import annotations

import datetime
import hashlib
import json
import os
from pathlib import Path
import shlex
import shutil
import signal
import subprocess
import time


ROOT = Path(__file__).resolve().parent
PREFIX = ROOT / 'vendor/rizin-0.9.1'
MUSL = ROOT / 'toolchain/musl-1.2.4'
window = json.loads((ROOT / 'build-window.json').read_text())
started_build = datetime.datetime.fromisoformat(window['started_utc'])
ENV = os.environ.copy()
ENV.update(PKG_CONFIG_PATH=str(PREFIX / 'lib/pkgconfig'), PKG_CONFIG_LIBDIR=str(PREFIX / 'lib/pkgconfig'),
           TMPDIR=str(ROOT / 'tmp'))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(label, argv, timeout=180):
    remaining = 900 - (datetime.datetime.now(datetime.timezone.utc) - started_build).total_seconds()
    if remaining <= 0:
        raise SystemExit('overall isolated build window exhausted')
    out, err = (ROOT / 'raw' / f'{label}.{stream}' for stream in ('stdout', 'stderr'))
    receipt = {'argv': argv, 'cwd': str(ROOT), 'timeout_seconds': min(timeout, remaining),
               'environment_overrides': {key: ENV[key] for key in ('PKG_CONFIG_PATH', 'PKG_CONFIG_LIBDIR', 'TMPDIR')},
               'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'target_execution': False}
    print(label, 'starting', flush=True)
    started = time.monotonic()
    with out.open('xb') as stdout, err.open('xb') as stderr:
        process = subprocess.Popen(argv, cwd=ROOT, env=ENV, stdout=stdout, stderr=stderr,
                                   start_new_session=True)
        stop = None
        while process.poll() is None:
            if time.monotonic() - started > receipt['timeout_seconds']:
                stop = 'timeout'
            elif out.stat().st_size + err.stat().st_size > 4 * 1024 * 1024:
                stop = 'output_limit'
            if stop:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=5)
                break
            time.sleep(0.1)
    receipt.update(returncode=process.returncode, stop_reason=stop,
                   duration_seconds=round(time.monotonic() - started, 3),
                   stdout_bytes=out.stat().st_size, stderr_bytes=err.stat().st_size,
                   stdout_sha256=digest(out), stderr_sha256=digest(err))
    (ROOT / 'receipts' / f'{label}.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(label, receipt['returncode'], receipt['duration_seconds'], flush=True)
    if process.returncode != 0 or stop:
        print(err.read_text(errors='replace')[-5000:], flush=True)
        raise SystemExit(f'{label} failed; logs retained, no automatic retry')
    return out.read_text()


pkg = ['/usr/bin/pkg-config', '--define-variable=prefix=' + str(PREFIX), '--static']
cflags = shlex.split(run('rizin-pkg-cflags', pkg + ['--cflags', 'rz_main'], 10))
original_libs = shlex.split(run('rizin-pkg-libs', pkg + ['--libs', 'rz_main'], 10))
old_util = '/usr/lib/gcc/x86_64-alpine-linux-musl/13.2.1/../../../../lib/libutil.a'
assert old_util in original_libs
libs = [str(MUSL / 'lib/libutil.a') if item == old_util else item for item in original_libs]
assert (MUSL / 'lib/libutil.a').is_file()
flags = ['-O2', '-D_GNU_SOURCE', '-static', '-Wl,--build-id=none', *cflags]
(ROOT / 'receipts/link-inputs.json').write_text(json.dumps({
    'compiler_wrapper': str(MUSL / 'bin/musl-gcc'),
    'compiler_wrapper_sha256': digest(MUSL / 'bin/musl-gcc'),
    'musl_libc_sha256': digest(MUSL / 'lib/libc.a'),
    'cflags': flags, 'original_pkg_config_libs': original_libs, 'link_libs': libs,
    'relocation': 'Only the original Alpine absolute libutil.a token is relocated to the isolated musl 1.2.4 equivalent.',
    'library_group': '--start-group/--end-group resolves the published mutually dependent static Rizin libraries.',
}, indent=2) + '\n')
for variant, filename in [('unmodified', 'rz-diff.original.c'), ('patched', 'rz-diff.patched.c')]:
    runtime = ROOT / 'runtime' / variant
    (runtime / 'bin').mkdir(parents=True)
    shutil.copytree(PREFIX / 'share', runtime / 'share')
    output = runtime / 'bin/rz-diff'
    argv = [str(MUSL / 'bin/musl-gcc'), *flags,
            str(ROOT / 'source/launcher.c'), str(ROOT / 'source' / filename),
            '-Wl,--start-group', *libs, '-Wl,--end-group', '-o', str(output)]
    run('build-' + variant, argv)
    output.chmod(0o555)
    run('version-' + variant, [str(output), '-v'], 10)
    run('help-' + variant, [str(output), '-h'], 10)
    (ROOT / 'receipts' / f'binary-{variant}.json').write_text(json.dumps({
        'path': str(output), 'bytes': output.stat().st_size, 'sha256': digest(output),
        'source_path': str(ROOT / 'source' / filename),
        'source_sha256': digest(ROOT / 'source' / filename),
        'launcher_sha256': digest(ROOT / 'source/launcher.c'),
    }, indent=2) + '\n')
print('both isolated variants built', flush=True)
