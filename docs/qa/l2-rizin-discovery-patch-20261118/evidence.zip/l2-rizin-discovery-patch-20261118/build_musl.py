"""One bounded isolated auxiliary-toolchain build; no targets are executed."""
from __future__ import annotations

import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import time


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / 'source/musl-1.2.4'
PREFIX = ROOT / 'toolchain/musl-1.2.4'
START = time.monotonic()
DEADLINE = START + 900
ENV = os.environ.copy()
ENV.pop('MAKEFLAGS', None)
ENV.update(CC='/usr/bin/cc', CFLAGS='-O2', TMPDIR=str(ROOT / 'tmp'))
(ROOT / 'tmp').mkdir(exist_ok=True)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(label, argv, *, timeout=300):
    before = datetime.datetime.now(datetime.timezone.utc).isoformat()
    out = ROOT / 'raw' / (label + '.stdout')
    err = ROOT / 'raw' / (label + '.stderr')
    receipt = {'argv': argv, 'cwd': str(SOURCE), 'environment_overrides': {
        key: ENV[key] for key in ('CC', 'CFLAGS', 'TMPDIR')}, 'started_utc': before,
        'timeout_seconds': min(timeout, max(0, DEADLINE - time.monotonic())),
        'stdout_limit_bytes': 32 * 1024 * 1024, 'target_execution': False}
    print(label, 'starting', flush=True)
    started = time.monotonic()
    with out.open('xb') as stdout, err.open('xb') as stderr:
        process = subprocess.Popen(argv, cwd=SOURCE, env=ENV, stdout=stdout, stderr=stderr,
                                   start_new_session=True)
        cause = None
        while process.poll() is None:
            if time.monotonic() - started > receipt['timeout_seconds']:
                cause = 'timeout'
            elif out.stat().st_size + err.stat().st_size > receipt['stdout_limit_bytes']:
                cause = 'output_limit'
            if cause:
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=5)
                break
            time.sleep(0.2)
    receipt.update(returncode=process.returncode, stop_reason=cause,
                   duration_seconds=round(time.monotonic() - started, 3),
                   finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   stdout_bytes=out.stat().st_size, stderr_bytes=err.stat().st_size,
                   stdout_sha256=digest(out), stderr_sha256=digest(err))
    (ROOT / 'receipts' / (label + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
    print(label, receipt['returncode'], receipt['duration_seconds'], flush=True)
    if process.returncode != 0 or cause:
        raise SystemExit(f'{label} failed; raw logs retained; no automatic retry')


(ROOT / 'build-window.json').write_text(json.dumps({
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'maximum_seconds': 900, 'scope': 'auxiliary musl build plus two narrow native CLI rebuilds',
    'compiler_path': '/usr/bin/cc', 'compiler_real_path': str(Path('/usr/bin/cc').resolve()),
    'compiler_sha256': digest(Path('/usr/bin/cc').resolve()),
    'musl_release_sha256': digest(ROOT / 'source/musl-1.2.4.tar.gz')}, indent=2) + '\n')
run('musl-configure', ['./configure', '--prefix=' + str(PREFIX), '--disable-shared'])
run('musl-make', ['/usr/bin/make', '-j2'], timeout=600)
run('musl-install', ['/usr/bin/make', 'install'], timeout=120)
files = []
for path in sorted(PREFIX.rglob('*')):
    if path.is_file():
        files.append({'path': str(path.relative_to(ROOT)), 'bytes': path.stat().st_size,
                      'sha256': digest(path)})
(ROOT / 'receipts/musl-installed-files.json').write_text(json.dumps(files, indent=2) + '\n')
print('auxiliary toolchain ready', PREFIX, flush=True)
