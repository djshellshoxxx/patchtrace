"""Compare archive/baseline/patched CLI on frozen authored discovery controls only."""
from __future__ import annotations

import datetime
import hashlib
import json
import os
from pathlib import Path
import threading

from patchtrace.jobs import run_process
from patchtrace.secondary.engine_env import engine_env
from patchtrace.secondary import rzdiff
from patchtrace.secondary.contracts import SecondaryError
from tools.research_qualification import receipt as R


ROOT = Path(__file__).resolve().parent
BASE = ROOT.parent
DIAG = BASE / 'l2-postmeasurement-diagnosis/20261118T083739Z-rizin-discovery'
REPO = BASE / 'repair-receipt-identity'
PILOT = BASE / 'l2-native-pilot/20261118T082742Z-http-parser'
assert R.git_head(REPO) == '9ac9cbeb8ba1947b5e0889e03dccad769a6d155b'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    with (ROOT / name).open('x') as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write('\n')


original = BASE / 'l2-tool-preparation/20261118T080830Z-rizin091/tool/rizin-0.9.1/bin/rz-diff'
assert sha(original) == '536987d5d0e5d2a35689f653502dc10f8be8751a46ef2ffd888e8d514ed9712e'
tools = {'archive': original, 'unmodified': ROOT / 'runtime/unmodified/bin/rz-diff',
         'patched': ROOT / 'runtime/patched/bin/rz-diff'}
tool_hashes = {key: sha(path) for key, path in tools.items()}
for variant in ('unmodified', 'patched'):
    expected = json.loads((ROOT / f'receipts/binary-{variant}.json').read_text())
    assert expected['sha256'] == tool_hashes[variant]

pairs = {
    'shared': {'older': ROOT / 'controls/build/shared/older/control.so',
               'newer': ROOT / 'controls/build/shared/newer/control.so'},
    'executable': {'older': ROOT / 'controls/build/executable/older/control.elf',
                   'newer': ROOT / 'controls/build/executable/newer/control.elf'},
    'authored-pe': {'older': ROOT / 'controls/controls/existing-authored-pe/tiny_v1.pe',
                   'newer': ROOT / 'controls/controls/existing-authored-pe/tiny_v2.pe'},
}
hashes = {key: {side: sha(path) for side, path in files.items()} for key, files in pairs.items()}
expected_inputs = {item['path']: item['sha256'] for item in json.loads((ROOT / 'plan.json').read_text())['inputs']}
for files in pairs.values():
    for path in files.values():
        assert sha(path) == expected_inputs[str(path.relative_to(ROOT))]

sealed = [DIAG / 'evidence-manifest.json',
          BASE / 'l2-postmeasurement-diagnosis/rizin-discovery-diagnosis-20261118.zip',
          BASE / 'l2-postmeasurement-diagnosis/rizin-options-addendum-20261118.zip',
          PILOT / 'pilot-plan.json', PILOT / 'pilot-result.json']
sealed_before = {str(path): sha(path) for path in sealed}
assert sealed_before[str(PILOT / 'pilot-result.json')] == '6d95d0b857d2a2cdb61ceecf6a69d05133dd852677aa6889b10fbd4544de339e'
assert sealed_before[str(PILOT / 'pilot-plan.json')] == 'd6a2dc2b5a1dc59304fc2a8279b6c186537be267448cf9bd0d700e6617e6dbef'
env = engine_env(os.environ, 'rz-diff')
normalizer_sources = ('src/patchtrace/jobs.py', 'src/patchtrace/secondary/rzdiff.py',
                      'src/patchtrace/secondary/contracts.py', 'src/patchtrace/secondary/engine_env.py',
                      'src/patchtrace/secondary/registry.py')
plan = {'frozen_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'source_commit': R.git_head(REPO), 'source_sha256': {name: sha(REPO / name) for name in normalizer_sources},
        'tool_paths': {key: str(path) for key, path in tools.items()}, 'tool_sha256': tool_hashes,
        'input_paths': {key: {side: str(path) for side, path in files.items()} for key, files in pairs.items()},
        'input_sha256': hashes, 'flags': ['-C', '-j', '-t', 'functions'], 'timeout_seconds': 30,
        'expected_authored_symbols': ['sym.diag_stable_add', 'sym.diag_stable_xor', 'sym.diag_changed', 'sym.diag_dispatch'],
        'stop_before_patched_analysis_if_archive_and_rebuild_differ': True,
        'normalizer_stage': 'After raw comparisons, pass exact completed stdout and stderr through existing rzdiff.interpret; no scheduler acceptance claim.',
        'candidate_reruns': 0, 'target_execution': False, 'scoring_or_ranking': False,
        'sealed_before': sealed_before}
save('authored-execution-plan.json', plan)
records = {}


def native(variant, case):
    label = variant + '-' + case
    executable, files = tools[variant], pairs[case]
    assert sha(executable) == tool_hashes[variant]
    argv = list(rzdiff.rzdiff_argv(str(executable), files['older'], files['newer']))
    assert argv[0] in plan['tool_paths'].values()
    print(label, 'starting', flush=True)
    result = run_process(argv, cwd=ROOT, env=env, cancel=threading.Event(), timeout_seconds=30,
                         log_limit=8 * 1024 * 1024, separate_streams=True,
                         stderr_limit=2 * 1024 * 1024, max_output_bytes=10 * 1024 * 1024)
    stdout, stderr = result.log_bytes or b'', result.stderr_bytes or b''
    for stream, data in [('stdout', stdout), ('stderr', stderr)]:
        with (ROOT / 'raw' / f'{label}.{stream}').open('xb') as target:
            target.write(data)
    receipt = {'argv': argv, 'cwd': str(ROOT), 'timeout_seconds': 30, 'stdout_limit': 8 * 1024 * 1024,
               'stderr_limit': 2 * 1024 * 1024, 'combined_output_limit': 10 * 1024 * 1024,
               'environment_keys': sorted(env), 'environment_fingerprint': R.env_fingerprint(sorted(env), env),
               'executable_sha256': tool_hashes[variant], 'input_sha256': hashes[case],
               'returncode': result.returncode, 'reason': result.reason, 'elapsed_seconds': result.elapsed_seconds,
               'stdout_sha256': hashlib.sha256(stdout).hexdigest(), 'stderr_sha256': hashlib.sha256(stderr).hexdigest(),
               'stdout_bytes': len(stdout), 'stderr_bytes': len(stderr),
               'stdout_total': result.stdout_total, 'stderr_total': result.stderr_total,
               'streams_complete': len(stdout) == result.stdout_total and len(stderr) == result.stderr_total,
               'candidate_rerun': False, 'target_execution': False}
    save('receipts/' + label + '.json', receipt)
    assert {side: sha(path) for side, path in files.items()} == hashes[case]
    assert sha(executable) == tool_hashes[variant]
    assert result.returncode == 0 and result.reason is None and receipt['streams_complete'], receipt
    rows = json.loads(stdout)
    assert isinstance(rows, list)
    records[variant, case] = (receipt, rows, stdout, stderr)
    print(label, 'rows', len(rows), 'seconds', result.elapsed_seconds, flush=True)


for variant in ('archive', 'unmodified'):
    for case in pairs:
        native(variant, case)
baseline = []
for case in pairs:
    old = (DIAG / 'raw' / f'{case}-production-0-analysis.stdout').read_bytes()
    a, b = records['archive', case], records['unmodified', case]
    result = {'case': case, 'archive_equals_sealed_native_stdout': a[2] == old,
              'unmodified_rebuild_equals_archive_stdout': b[2] == a[2],
              'unmodified_rebuild_equals_archive_stderr': b[3] == a[3],
              'native_rows': len(a[1])}
    baseline.append(result)
save('baseline-comparison.json', baseline)
assert all(row['archive_equals_sealed_native_stdout'] and row['unmodified_rebuild_equals_archive_stdout']
           for row in baseline), 'Baseline output changed; patched analysis deliberately not started'

for case in pairs:
    native('patched', case)

comparison = []
for case in pairs:
    before = records['unmodified', case][1]
    after = records['patched', case][1]
    def sides(rows, side, field):
        return sorted({row[side][field] for row in rows if row.get(side) is not None})
    item = {'case': case, 'baseline_rows': len(before), 'patched_rows': len(after),
            'baseline_original_names': sides(before, 'original', 'name'),
            'patched_original_names': sides(after, 'original', 'name'),
            'baseline_modified_names': sides(before, 'modified', 'name'),
            'patched_modified_names': sides(after, 'modified', 'name'),
            'patched_original_addresses': sides(after, 'original', 'addr'),
            'patched_modified_addresses': sides(after, 'modified', 'addr')}
    if case != 'authored-pe':
        item['expected_authored_symbols'] = plan['expected_authored_symbols']
        item['baseline_emits_all_four'] = set(plan['expected_authored_symbols']) <= set(item['baseline_original_names'])
        item['patched_emits_all_four'] = set(plan['expected_authored_symbols']) <= set(item['patched_original_names'])
    comparison.append(item)
save('discovery-comparison.json', comparison)

normalization = []
for (variant, case), (operation, rows, stdout, stderr) in records.items():
    entry = {'variant': variant, 'case': case, 'native_stdout_sha256': operation['stdout_sha256'],
             'tool_sha256': tool_hashes[variant], 'source_commit': plan['source_commit']}
    try:
        match_set = rzdiff.interpret(operation['returncode'], stdout, stderr.decode('utf-8'), '0.9.1',
                                     hashes[case]['older'], hashes[case]['newer'], 8 * 1024 * 1024)
        entry.update(status='ACCEPTED', normalized_matches=len(match_set.matches),
                     singleton_ownership_ambiguous=rzdiff.ambiguous_stored_ownership(match_set),
                     retained_raw_digest_exact=match_set.file_sha256 == operation['stdout_sha256'])
        save(f'normalized/{variant}-{case}.json', match_set.model_dump(mode='json'))
    except SecondaryError as exc:
        entry.update(status='REFUSED', code=exc.code, message=exc.message,
                     kind=getattr(exc, 'kind', None), reason=getattr(exc, 'reason', None))
    normalization.append(entry)
save('normalizer-results.json', normalization)
sealed_after = {str(path): sha(path) for path in sealed}
assert sealed_after == sealed_before
assert {name: sha(REPO / name) for name in normalizer_sources} == plan['source_sha256']
save('preservation-after.json', {'sealed_after': sealed_after, 'sealed_unchanged': True,
                                'production_source_unchanged': True, 'candidate_reruns': 0,
                                'original_pilot_status': 'MISS', 'scoring_or_ranking_performed': False})
print(json.dumps({'comparison': comparison, 'normalizer': normalization}, indent=2), flush=True)
