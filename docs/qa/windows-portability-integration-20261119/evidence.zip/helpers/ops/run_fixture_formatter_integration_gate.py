"""Run only reviewed fixture controls, authored formatter and specification registry."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = ROOT / 'qa/fixture-formatter-integration'
AUTHOR = '81590f936b3f01555720221e55f99ec0611ec4a1'
FORMATTER = '16c35e1fb1a4dd54b2c2c0cb2033c8160ee99347'
SELECTED = [
    'tests/test_release_source_stat.py::test_authored_checkout_exact_bytes_survive_host_text_newlines',
    'tests/test_release_source_stat.py::test_final_change_assertions_survive_host_text_newlines',
    'tests/test_dependency_security.py::test_authored_receipts_remain_exact_under_host_text_newlines',
    'tests/test_dependency_security.py::test_authored_repository_survives_host_git_normalization',
    'tests/test_windows_bindiff_network.py::test_untracked_source_refusal_survives_host_git_normalization',
    'tests/test_linux_frozen_smoke.py::test_linux_smoke_accepts_canonical_windows_relative_inventory',
    'tests/test_linux_frozen_smoke.py::test_full_smoke_refusal_survives_windows_relative_inventory',
    'tests/test_linux_frozen_smoke.py::test_resource_refusal_survives_windows_relative_inventory',
    'tests/test_windows_network_diagnostics.py', 'tests/test_spec_registry.py',
]


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


source = git('rev-parse', '11c3ffab').decode().strip()
assert git('rev-parse', 'HEAD').decode().strip() == source and not git('status', '--porcelain')
files = {item.split('::')[0] for item in SELECTED}
files.add('tests/test_release_qualification.py')
files.update(['tools/build_linux.py', 'tools/dependency_security.py', 'tools/windows_bindiff_network.py',
              'tools/release_qualification.py'])
for name in files - {'tests/test_windows_network_diagnostics.py'}:
    assert (REPO / name).read_bytes() == git('show', AUTHOR + ':' + name)
assert (REPO / 'tests/test_windows_network_diagnostics.py').read_bytes() == git('show', FORMATTER + ':tests/test_windows_network_diagnostics.py')
author_imports = json.loads((ROOT / 'qa/windows-fixture-portability/affected-v2.imports.json').read_bytes())
for row in author_imports['modules']:
    assert sha((REPO / row['relative_path']).read_bytes()) == row['sha256']
assert len(author_imports['modules']) == 69
assert not git('diff', '--name-only', '1a9942a5', source, '--', 'src', 'tools/windows_network', '.github')
specs = REPO / 'docs/specs'
registry_cases = 1 + sum(p.is_file() and not p.is_relative_to(specs / 'program-e') for p in specs.rglob('*'))
OUT.mkdir(exist_ok=False)
owned = Path(tempfile.mkdtemp(prefix='patchtrace-fixture-formatter-root-'))
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', QT_QPA_PLATFORM='offscreen',
           PYTHONPATH=os.pathsep.join(map(str, [REPO / 'src', REPO / 'tests', REPO, ROOT / 'ops'])),
           GIT_ALLOW_PROTOCOL='file', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null',
           GIT_NO_REPLACE_OBJECTS='1', GIT_TERMINAL_PROMPT='0',
           PATCHTRACE_BATCH_COLLECTION_RECEIPT=str(OUT / 'collection.json'),
           PATCHTRACE_OFFLINE_GUARD_RECEIPT=str(OUT / 'offline-guard.json'))
argv = [sys.executable, str(ROOT / 'ops/continuation_offline_pytest.py'), '-q', '-ra',
        '-p', 'no:cacheprovider', '-p', 'project_and_tools_receipt', *SELECTED,
        '--basetemp=' + str(owned / 'pytest'), '--junitxml=' + str(OUT / 'result.xml')]
command = dict(source=source, tree=git('rev-parse', 'HEAD^{tree}').decode().strip(),
               argv=argv, cwd=str(REPO), pythonpath=env['PYTHONPATH'], timeout=90,
               started_utc=datetime.now(timezone.utc).isoformat(), owned_temp=str(owned),
               author_scope_bytes_equal=True, author_69_imports_equal=True,
               selected_scope='20 unchanged portability controls +9 unchanged authored formatter controls + complete static specification registry. Only bounded authored local Git/C children; no engine, native Windows, scanner, frozen executable, target or network.')
(OUT / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
start = time.monotonic()
with (OUT / 'result.log').open('x') as stream:
    result = subprocess.run(argv, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=90)
collection = json.loads((OUT / 'collection.json').read_bytes())
for row in collection['final_sources'].values():
    path = Path(row['path'])
    rel = path.relative_to(REPO).as_posix()
    assert sha(path.read_bytes()) == row['sha256'] == sha(git('show', source + ':' + rel))
cases = list(ET.parse(OUT / 'result.xml').getroot().iter('testcase'))
counts = dict(tests=len(cases), failures=sum(c.find('failure') is not None for c in cases),
              errors=sum(c.find('error') is not None for c in cases), skipped=sum(c.find('skipped') is not None for c in cases))
assert counts == dict(tests=29 + registry_cases, failures=0, errors=0, skipped=0) and result.returncode == 0
assert git('rev-parse', 'HEAD').decode().strip() == source and not git('status', '--porcelain')
lint_argv = [sys.executable, '-m', 'ruff', 'check', '--no-cache', 'src', 'tests', 'tools']
lint = subprocess.run(lint_argv, cwd=REPO, capture_output=True, timeout=60)
(OUT / 'lint.json').write_text(json.dumps(dict(source=source, argv=lint_argv, exit=lint.returncode,
                                             stdout=lint.stdout.decode(), stderr=lint.stderr.decode()), indent=2) + '\n')
assert lint.returncode == 0
shutil.rmtree(owned)
receipt = dict(source=source, exit=result.returncode, elapsed=time.monotonic() - start,
               junit=counts, portability_controls=20, formatter_controls=9, registry_controls=registry_cases,
               canonical_imports=len(collection['final_sources']), unchanged_author_imports=69,
               source_unchanged=True, clean_head=True, owned_temp_removed=True, lint_exit=0,
               native_windows_acceptance=False, original_windows_failure_relabelled=False,
               earlier_2043_gate_source='1a9942a5c63ba707e8678cb2f6dcd1dc39c4afd2')
(OUT / 'exit.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
print((OUT / 'result.log').read_text())
