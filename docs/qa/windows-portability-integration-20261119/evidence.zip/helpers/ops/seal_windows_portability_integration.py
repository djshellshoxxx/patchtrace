"""Seal root fixture review and exact merged controls; no new product execution."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = REPO / 'docs/qa/windows-portability-integration-20261119'
SOURCE = '11c3ffabf25d8527732b45bc2d949565d91debc5'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE and not git('status', '--porcelain')
gate = json.loads((ROOT / 'qa/fixture-formatter-integration/exit.json').read_bytes())
review = json.loads((ROOT / 'qa/windows-fixture-root-review/verification.json').read_bytes())
guard = json.loads((ROOT / 'qa/fixture-formatter-integration/offline-guard.json').read_bytes())
assert gate['source'] == SOURCE and gate['junit'] == dict(tests=142, failures=0, errors=0, skipped=0)
assert gate['canonical_imports'] == 42 and gate['unchanged_author_imports'] == 69
assert gate['lint_exit'] == 0 and gate['native_windows_acceptance'] is False
assert guard['process_audit_count'] == 102 and not guard['inherited_socket_descriptors']
assert guard['network_audit_event_counts'] == {} and guard['network_filter']['seccomp_load_result'] == 0
assert review['payloads'] == 127 and review['source_snapshots'] == 74 and review['historical_import_pairs'] == 264
assert review['original_assertions_preserved'] == 144 and review['original_test_identities_preserved'] == 110
assert git('rev-parse', SOURCE + ':src') == git('rev-parse', '1a9942a5:src')
assert git('rev-parse', 'refs/heads/codex/verified-continuation-20261118').decode().strip() == 'b2b170e343ab4da680b3629b3ab2e89ce6f42774'
payloads = {}
for label, directory in [('integration-gate', ROOT / 'qa/fixture-formatter-integration'),
                         ('independent-review', ROOT / 'qa/windows-fixture-root-review')]:
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            payloads[label + '/' + path.relative_to(directory).as_posix()] = path.read_bytes()
for name in ['ops/verify_windows_fixture_handoff.py', 'ops/run_fixture_formatter_integration_gate.py',
             'ops/seal_windows_portability_integration.py', 'ops/continuation_offline_pytest.py',
             'ops/project_and_tools_receipt.py', 'qa/full-batch-path-recheck/offline_replay.py']:
    payloads['helpers/' + name] = (ROOT / name).read_bytes()
pairs = [('24651bf5d85c42c65cf207991258ce5d3fe4825e', 'ce98e621d2d88a9be34c9ac5fe68f3a38e7db12d'),
         ('81590f936b3f01555720221e55f99ec0611ec4a1', '49369f41185c8ce4c3ddc75df70bec244160a7a6'),
         ('9e228d8448da14726ce5334b8d1f8e7a6eb7941c', SOURCE)]
for original, integrated in pairs:
    for ref in [original, integrated]:
        payloads['history/' + ref + '.commit'] = git('cat-file', 'commit', ref)
    assert original in git('show', '-s', '--format=%B', integrated).decode()
source_proof = dict(source=SOURCE, tree=git('rev-parse', SOURCE + '^{tree}').decode().strip(),
                    checked_utc=datetime.now(timezone.utc).isoformat(), mappings=pairs,
                    unchanged_src_tree=git('rev-parse', SOURCE + ':src').decode().strip(),
                    retained_original_branch='b2b170e343ab4da680b3629b3ab2e89ce6f42774',
                    strict_80_scan_source='1a9942a5c63ba707e8678cb2f6dcd1dc39c4afd2',
                    strict_scanner_rerun=False, native_acceptance=False)
payloads['source-proof.json'] = (json.dumps(source_proof, indent=2) + '\n').encode()
rows = [dict(path=name, bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(payloads.items())]
manifest = dict(schema='patchtrace-windows-portability-integration/1', source=SOURCE, payloads=rows)
manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
OUT.mkdir(exist_ok=False)
with zipfile.ZipFile(OUT / 'evidence.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in sorted(payloads.items()):
        z.writestr(name, raw)
    z.writestr('manifest.json', manifest_raw)
with zipfile.ZipFile(OUT / 'evidence.zip') as z:
    assert z.testzip() is None and len(z.namelist()) == len(payloads) + 1
    for row in rows:
        raw = z.read(row['path'])
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
archive = (OUT / 'evidence.zip').read_bytes()
readme = f'''# Independently integrated Windows fixture portability — 2026-11-19

The reviewed fixture/builder changes are integrated at `{SOURCE}`, tree
`{source_proof['tree']}`. The source/test commit is
`49369f41185c8ce4c3ddc75df70bec244160a7a6`; its following commit adds only QA and
tracker updates. Main was last verified at
`9c411ca3d7b47f950be5f0c6f01b3c54184554c6`. This packet does not claim a main merge,
remote publication, complete Windows acceptance or beta readiness. `[no release]`.

## Changes, independent review and original evidence

Authored source/requirements fixtures write exact UTF-8/LF bytes. Tiny authored
Git repositories pin local `core.autocrlf=false` before staging. The Linux builder
uses one changed expression, `relative_path.as_posix()`, for its sorted inventory.
Actual Linux names/bytes, regular-file iteration, forbidden-library rejection,
required resources, complete smoke and refusal-before-archive behavior remain.
The builder change is tool source, not a fixture-only change.

The original chain is spec/red `24651bf5`, source `81590f93`, QA `9e228d84`;
each has an attributed append-only integrated commit. Root reviewed the complete
spec, new controls and source diff, reread relevant existing fixture/validator
paths, and independently verified all **127 author payloads, 74 exact source
snapshots and 264 historical import/source pairs**. Original **144 assertions,
110 test identities/decorators** and existing context-manager predicates remain.
The source-boundary verifier independently confirms the single allowed tool
expression and unchanged production/native/receipt validators.

Original authored evidence stays **19 failures / 1 positive** before the repair.
The focused final gate passes20; its affected gate passes678 with **8 original
native-Windows skips**. The first focused recorder omitted one local read-only
Git command, and the first affected recorder omitted one exact authored-local
HEAD update. Both original errors, runner sources, outputs and corrected finite
allowances are preserved. No original failed run is relabeled. See the
[complete author packet](../autonomous-ci-20261118/windows-fixture-portability/README.md).

## Exact integrated candidate gate

Root's bounded replay at `{SOURCE}` passes **142 tests**, with **zero failures,
errors or skips**, in **1.04 pytest seconds** (1.710 seconds outer recorder):

| Scope | Tests | Evidence |
| --- | ---: | --- |
| Unchanged new portability controls | 20 | CRLF, real local Git normalization and inert builder path models |
| Unchanged authored formatter controls | 9 | Real standard-C formatter and preserved acceptance predicates |
| Complete static specification registry | 113 | Every current registered specification path and nonvacuous walk |

All **42 imported project/tool modules** match current Git and disk. All **69**
modules imported by the author's final affected gate are also byte-identical on
the integrated source. The reviewed child scope is95 authored local Git calls
plus7 compiler/formatter process events. The inherited network filter loads;
there are no inherited sockets or network audit events. Only the owned completed
scratch directory is removed. Complete argv, environment, JUnit, source receipts,
helper scripts and observations are retained in this archive.

Full normal `ruff check --no-cache src tests tools` passes on this source. The
`src` tree remains exactly equal to the prior `1a9942a5` source, where the isolated
strict S scan retained **80 unchanged findings**. That strict scan is not rerun or
waived here. The earlier2,043 combined gate and these142 controls are separate,
overlapping observations attributed to their actual sources, not an additive
test count or a full-platform result.

## Historical/platform limits and publication layout

The old published771e Windows result remains51failed/25155passed/150skipped/
2xfailed. This slice addresses the reproduced newline and Linux-inventory
mechanisms. The original two small Git-source failures did not record the
necessary bytes/settings; the portable normalization reproduction does not prove
their precise historical cause. Core creation/ownership and symlink repairs
continue separately. The formatter failure is still awaiting actual Windows
constituent values. The final old-head Qt jobs are cancelled, not passing.

The preceding complete420-payload checkpoint archive is preserved as two
checksum-verified parts because one encoded connector request exceeded16MiB.
Reassembly reproduces all13,132,985 bytes and SHA-256
`ab11b8c014d5fdf0cfe94b2e29f661bd20974019f7c4f9a91151b7593dce4ece` exactly.
The original branch and all original local commits remain. The separate
publication branch carries attributed source commits and the lossless archive
layout; no existing history is rewritten. The initial layout-count recorder
mistake and transport errors are retained in the
[transport checkpoint](../archive-transport-20261119/README.md).

Pure package contracts, native file ownership and the demonstrated core
observation-family correction are active independent workstreams. Required
full Linux/Windows/Qt/native/frozen/package/security/reproducibility gates and
real CVE/KB/analyst journeys continue to block main merge and release readiness.

This archive contains **{len(payloads)} payloads**, plus its manifest,
**{len(archive):,} bytes**, SHA-256 `{sha(archive)}`. Every payload hash, length
and ZIP CRC is verified. All author evidence remains separately immutable.
'''
(OUT / 'README.md').write_text(readme)
manifest['archive'] = dict(bytes=len(archive), sha256=sha(archive), members=len(payloads) + 1)
manifest['readme_sha256'] = sha(readme.encode())
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
append = f'''\n\n## Independently integrated Windows fixture repair — 2026-11-19

Integrated source `{SOURCE}` retains author spec24651bf5/source81590f93/QA9e228d84.
Exact LF fixture bytes, local Git normalization pins and one Linux inventory
`as_posix` projection preserve all144 original assertions/110 test identities.
Root verifies127 author payloads,74 Git snapshots,264 historical import pairs,
both recorder omissions and original19-red/1-positive result. Final author
affected gate:678pass/8 native-Windows skips; those skips remain unverified.

Root's actual integrated replay passes142 with zero errors/skips in1.04seconds:
20 portability,9 formatter and113 specification-registry cases;42 canonical
imports and all69 author affected imports match. Full normal Ruff passes. The
src tree equals the preceding strict80-finding scan source; no waiver or rerun.
Original2,043 and142 counts are source-bound and not additive. The complete
original checkpoint is losslessly split for transport; old local branches and
commit history remain intact. Fresh expected-head PR publication is next.
Main/platform/native/package/security/beta remain blocked. [Complete review
and exact-source evidence]({{link}}).
'''
for name, link in [('docs/qa.md', 'qa/windows-portability-integration-20261119/README.md'),
                   ('docs/plans/patchtrace-completion-matrix.md', '../qa/windows-portability-integration-20261119/README.md'),
                   ('docs/plans/autonomous-consolidation-20261118/consolidation-ledger.md', '../../qa/windows-portability-integration-20261119/README.md')]:
    with (REPO / name).open('a') as stream:
        stream.write(append.replace('{link}', link))
with (REPO / 'tasks/todo.md').open('a') as stream:
    stream.write('''\n\n### Windows portability integration — 2026-11-19

- [x] Verify and integrate original19-red/1-positive fixture repair, preserving144 assertions/110 test identities and both recorder errors.
- [x] Pass142 exact integrated portability/formatter/registry cases, verify42 imports/69 unchanged author imports and full normal lint.
- [x] Preserve all420 original checkpoint payloads as lossless archive parts; preserve original branch/history and transport/layout errors.
- [ ] Complete expected-head PR append and read back the exact ref, tree, parents and body.
- [ ] Complete actual Windows fixture/core/formatter gates and full Qt repeats; original failed/cancelled/skipped outcomes remain unverified.
- [ ] Continue pure admission contracts, core metadata-family correction and native leaf/reader work with independent review before further integration.
''')
print(json.dumps(dict(source=SOURCE, directory=str(OUT), payloads=len(payloads),
                      archive_bytes=len(archive), archive_sha256=sha(archive))))
