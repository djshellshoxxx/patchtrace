"""Independently verify the pinned fixture repair packet, snapshots and original results."""
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = ROOT / 'qa/windows-fixture-root-review'
AUTHOR = '9e228d8448da14726ce5334b8d1f8e7a6eb7941c'
SOURCE = '81590f936b3f01555720221e55f99ec0611ec4a1'
SPEC = '24651bf5d85c42c65cf207991258ce5d3fe4825e'
PREFIX = 'docs/qa/autonomous-ci-20261118/windows-fixture-portability/'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), '--no-replace-objects', *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


archive_raw = git('show', AUTHOR + ':' + PREFIX + 'evidence.zip')
manifest_raw = git('show', AUTHOR + ':' + PREFIX + 'manifest.json')
assert len(archive_raw) == 1731293
assert sha(archive_raw) == 'f34ae4fc89a7cdafa947287f5d7993fd1c9781130c1b7cc2d008d6d5177bde65'
assert sha(manifest_raw) == '316476e28cab108e09de570f9774658f99a995e0d83f30e08c5359443d927705'
manifest = json.loads(manifest_raw)
assert manifest['source'] == SOURCE and len(manifest['payloads']) == 127
assert git('show', '-s', '--format=%P', SOURCE).decode().strip() == SPEC
assert not git('diff', '--name-only', SOURCE, AUTHOR, '--', 'src', 'tests', 'tools', '.github')
snapshots, imports, phases = 0, 0, []
with zipfile.ZipFile(io.BytesIO(archive_raw)) as z:
    assert z.testzip() is None and len(z.namelist()) == 128
    for row in manifest['payloads']:
        raw = z.read(row['path'])
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    assert z.read('manifest.json') == manifest_raw
    expected = {'red': (20, 19, 0, 0), 'green': (20, 1, 0, 0),
                'green-v2': (20, 0, 0, 0), 'affected': (686, 1, 0, 8),
                'affected-v2': (686, 0, 0, 8)}
    for phase, wanted in expected.items():
        command = json.loads(z.read(phase + '.command.json'))
        recorded = json.loads(z.read(phase + '.exit.json'))
        imported = json.loads(z.read(phase + '.imports.json'))
        source = command['source_commit']
        assert source == (SPEC if phase == 'red' else SOURCE)
        assert recorded['source_commit'] == imported['source_commit'] == source
        assert recorded['drift'] == imported['drift'] == []
        assert recorded['network_attempts'] == recorded['native_or_engine_children'] == 0
        for row in command['source_files']:
            raw = z.read(phase + '-source/' + row['path'])
            assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
            assert raw == git('show', source + ':' + row['path'])
            snapshots += 1
        for row in imported['modules']:
            raw = git('show', source + ':' + row['relative_path'])
            assert sha(raw) == row['sha256']
            assert git('rev-parse', source + ':' + row['relative_path']).decode().strip() == row['git_blob'] == row['expected_git_blob']
            imports += 1
        cases = list(ET.fromstring(z.read(phase + '.xml')).iter('testcase'))
        counts = (len(cases), sum(c.find('failure') is not None for c in cases),
                  sum(c.find('error') is not None for c in cases), sum(c.find('skipped') is not None for c in cases))
        assert counts == wanted
        denied = recorded['denied_attempts']
        if phase in ['green', 'affected']:
            assert recorded['exit_code'] == 97 and len(denied) == 1
        else:
            assert not denied and recorded['exit_code'] == (1 if phase == 'red' else 0)
        phases.append(dict(phase=phase, source=source, tests=counts[0], failures=counts[1], errors=counts[2], skipped=counts[3],
                           imports=len(imported['modules']), recorder_refusal=bool(denied),
                           junit_sha256=sha(z.read(phase + '.xml'))))
    boundary = json.loads(z.read('source-boundary.json'))
    assert sum(row['original_assertions'] for row in boundary['original_assertions']) == 144
    assert sum(row['preserved_original_test_functions'] for row in boundary['original_assertions']) == 110
assert snapshots == 74 and imports == 264
verifier = ROOT / 'qa/windows-fixture-portability/verify_source_boundary.py'
with zipfile.ZipFile(io.BytesIO(archive_raw)) as z:
    assert verifier.read_bytes() == z.read('verify_source_boundary.py')
run = subprocess.run(['/workspace/scratch/3a6632a6e5ff/venv/bin/python', str(verifier)], capture_output=True, timeout=30)
assert run.returncode == 0
OUT.mkdir(exist_ok=False)
(OUT / 'source-boundary-replay.log').write_bytes(run.stdout + run.stderr)
result = dict(author_tip=AUTHOR, source=SOURCE, specification=SPEC, archive_sha256=sha(archive_raw),
              payloads=127, members=128, source_snapshots=snapshots, historical_import_pairs=imports,
              original_assertions_preserved=144, original_test_identities_preserved=110,
              source_boundary_replay=True, phases=phases,
              disposition='No blocker in the reviewed narrow fixture and one-line builder delta; actual Windows acceptance remains separate.',
              native_windows_accepted=False, original_hosted_failure_relabelled=False)
(OUT / 'verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
