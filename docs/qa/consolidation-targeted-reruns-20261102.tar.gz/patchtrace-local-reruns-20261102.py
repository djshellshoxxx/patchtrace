"""Audited local tests; invoked only inside a fresh loopback-only namespace."""
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import tempfile

source = Path('/tmp/patchtrace-isolated-imports-venv-20261102/source-f2b7d981')
selection = Path('/tmp/patchtrace-loopback-failed-nodes-20261102.txt')
raw = selection.read_bytes()
assert hashlib.sha256(raw).hexdigest() == 'fa7c77b516110bd675a7e832cfda60b52c6463fe06380379465a47f69bdbc911'
nodes = raw.decode().splitlines()
assert len(nodes) == len(set(nodes)) == 55
allowed = {
    'tests/test_acquisition_hardening.py', 'tests/test_acquisition_transport.py',
    'tests/test_bundle_acceptance_unit.py', 'tests/test_enrichment_intelligence.py',
    'tests/test_interpretation.py', 'tests/test_kev_transport.py',
    'tests/test_network_consent_guard.py', 'tests/test_providers_transport.py',
    'tests/test_slow_drip_deadlines.py',
}
assert all(n.split('::')[0] in allowed for n in nodes)
interfaces = [name for _, name in socket.if_nameindex()]
assert set(interfaces) == {'lo'}, interfaces
routes = json.loads(subprocess.check_output([
    '/usr/sbin/ip', '-j', '-4', 'route', 'show', 'table', 'all'
]))
assert all(r.get('dev') == 'lo' for r in routes), routes
assert not any(r.get('dst') == 'default' for r in routes), routes
env = os.environ.copy()
env['NO_PROXY'] = env['no_proxy'] = '127.0.0.1,localhost,::1'
env['QT_QPA_PLATFORM'] = 'offscreen'
env['PYTHONDONTWRITEBYTECODE'] = '1'
env.pop('PYTHONPATH', None)
receipt = {
    'source_commit': 'f2b7d981008dea25ac09ea82734da64a1dccb96d',
    'source_tree': '985078aed0feb4f909690d6082ec4940540cda17',
    'source_directory': str(source),
    'selection_sha256': hashlib.sha256(raw).hexdigest(),
    'selected_socket_nodes': len(nodes), 'python': sys.executable,
    'network_namespace': os.readlink('/proc/self/ns/net'),
    'interfaces': interfaces, 'ipv4_routes': routes,
    'no_proxy': env['NO_PROXY'],
    'scope': 'No external interface or default route; original tests unchanged',
}
with open('/tmp/patchtrace-loopback-rerun-20261102.log', 'w') as log:
    first = subprocess.run([
        sys.executable, '-m', 'pytest', '-q',
        '--junitxml=/tmp/patchtrace-loopback-rerun-20261102.xml', *nodes
    ], cwd=source, env=env, stdout=log, stderr=subprocess.STDOUT)
receipt['socket_exit_code'] = first.returncode
base = Path(tempfile.mkdtemp(prefix='patchtrace-export-control-', dir='/dev/shm'))
assert not any((p / '.git').exists() for p in [base, *base.parents])
receipt['export_test_base'] = str(base)
with open('/tmp/patchtrace-export-rerun-20261102.log', 'w') as log:
    second = subprocess.run([
        sys.executable, '-m', 'pytest', '-q', '--basetemp', str(base),
        '--junitxml=/tmp/patchtrace-export-rerun-20261102.xml',
        'tests/test_rules_actions.py::test_the_preview_is_exactly_the_file_and_never_replaces',
    ], cwd=source, env=env, stdout=log, stderr=subprocess.STDOUT)
receipt['export_exit_code'] = second.returncode
Path('/tmp/patchtrace-local-rerun-environment-20261102.json').write_text(
    json.dumps(receipt, indent=2) + '\n'
)
print(json.dumps(receipt))
raise SystemExit(0 if first.returncode == second.returncode == 0 else 1)
