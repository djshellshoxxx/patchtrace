"""Actual SQLite caller effects of a failed final staging-name unlink."""
import json
import sqlite3
import tempfile
from pathlib import Path
from unittest.mock import patch

from test_prune_backup import CURRENT, FUTURE, _generations

from patchtrace import persistence
from patchtrace import verified_backup as V
from patchtrace.enrichment.storage import EnrichmentStore
from patchtrace.service import ProjectService


root = Path(tempfile.mkdtemp(prefix='storage-cleanup-', dir='/workspace/scratch/142cb233d750/reviews-resume'))
original = Path.unlink


def fail_stage(path, *args, **kwargs):
    if path.name.endswith('.sqlite3.part'):
        raise PermissionError('injected own-stage unlink refusal')
    return original(path, *args, **kwargs)


def rows(db, table):
    key = 'id' if table == 'enrichment_entries' else 'sequence'
    return {row[0] for row in db.execute(f'SELECT {key} FROM {table}')}


results = {'source': '1f284a19754f6822ff73ba1852d523cd48094d31', 'evidence_root': str(root)}
for label, table in [('retention', 'enrichment_entries'), ('history-prune', 'history')]:
    V.forget_all()
    with ProjectService.sample(root / label) as service:
        if label == 'retention':
            store = EnrichmentStore(service.store)
            _generations(store, 10)
        before = rows(service.store.connection, table)
        with patch.object(Path, 'unlink', fail_stage), patch.object(persistence, 'HISTORY_KEEP', 2):
            if label == 'retention':
                returned = store.apply_retention(CURRENT, started=FUTURE)
            else:
                project = service.project.model_copy(deep=True)
                project.name = 'cleanup-refused-save'
                service.project = service.store.save(project)
                returned = None
        after = rows(service.store.connection, table)
        finals = sorted((service.root / 'backups').glob(f'project-pre-{label}-*.sqlite3'))
        stage_paths = sorted((service.root / 'backups').glob('*.part'))
        with sqlite3.connect(finals[0]) as backup:
            backup_rows = rows(backup, table)
            integrity = backup.execute('PRAGMA integrity_check').fetchall()
        V.forget_all()
        discovered = V.find_verified_backup(service.root, label, project_id=service.project.id, require_tables=(table,))
        results[label] = {'returned': returned, 'before': len(before), 'after': len(after),
                          'deleted': len(before - after), 'deleted_rows_in_backup': (before - after) <= backup_rows,
                          'backup_rows': len(backup_rows), 'integrity': integrity,
                          'finals': [str(p) for p in finals], 'stages': [str(p) for p in stage_paths],
                          'discoverable_after_cache_forget': discovered is not None,
                          'history_session_blocked': service.store._prune_blocked}
print(json.dumps(results, indent=2))
