"""Independent malformed SQLite storage-class controls for retained context capture."""
import pytest
import test_pilot_kb_context as authored
from patchtrace.service import ProjectService

case = authored.case

@pytest.mark.parametrize('column,value', [
    ('body', b'{"invalid":"binary storage class"}'),
    ('body_sha256', b'0' * 64),
    ('id', b'kb-context:authored-binary-id'),
])
def test_malformed_sqlite_storage_class_withholds_context_without_crashing(case, column, value):
    with ProjectService.open(case) as service:
        # Column comes only from the fixed parametrization above.
        with service.store.connection as db:
            db.execute('UPDATE enrichment_entries SET ' + column + '=? WHERE kind=?', (value, 'kb-context'))
        captured = authored.captured(service)
        assert captured.unavailable and not captured.cves
        assert captured.digest and captured.warnings
