from pathlib import Path
from datetime import UTC, datetime
import hashlib
import json
import platform
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

root = Path('/workspace/scratch/c7a9e8d98848/cvrf-pilot')
qa = Path('/workspace/scratch/c7a9e8d98848/qa/cvrf-metadata-budget')
original = Path('/workspace/scratch/c7a9e8d98848/qa/cvrf-independent')
source = '8e368dd88c3ad65726d84701219942ff38c6c2cd'
tree = 'ab751b5ae29a69cb8bbf100c6efefda935bd9ca8'
python = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == source
assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=root, text=True).strip() == tree
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True) == ''

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

pairs = [('test_cvrf_metadata_budget.py', 'independent-original-test.py'),
         ('metadata-budget-red.log', 'independent-original-red.log'),
         ('metadata-budget-red.xml', 'independent-original-red.xml'),
         ('test_cvrf_row_types.py', 'independent-row-types-test.py')]
for origin, copy in pairs:
    assert digest(original / origin) == digest(qa / copy)
assert (qa / 'valid-before.json').read_bytes() == (qa / 'valid-after.json').read_bytes()
assert (qa / 'ruff.log').read_text().strip() == 'All checks passed!'
assert (qa / 'diff-check.log').read_bytes() == b''

def results(name):
    cases = ET.parse(qa / name).findall('.//testcase')
    return {'tests': len(cases), 'failed': sum(c.find('failure') is not None for c in cases),
            'errors': sum(c.find('error') is not None for c in cases),
            'skipped': sum(c.find('skipped') is not None for c in cases)}

outcomes = {name: results(name) for name in ('independent-original-red.xml', 'red.xml', 'focused.xml', 'affected.xml')}
assert outcomes['independent-original-red.xml'] == {'tests': 3, 'failed': 3, 'errors': 0, 'skipped': 0}
assert outcomes['red.xml'] == {'tests': 16, 'failed': 15, 'errors': 0, 'skipped': 0}
assert outcomes['focused.xml'] == {'tests': 41, 'failed': 0, 'errors': 0, 'skipped': 0}
assert outcomes['affected.xml'] == {'tests': 1574, 'failed': 0, 'errors': 0, 'skipped': 0}

sys.path.insert(0, str(root / 'src'))
from patchtrace.pilot.sources import kb_context
assert Path(kb_context.__file__).resolve() == root / 'src/patchtrace/pilot/sources/kb_context.py'
selection = [str(path.relative_to(root)) for path in sorted((root / 'tests').glob('test_pilot*.py'))]
selection += ['tests/test_kbc_card_field_provenance.py', 'tests/test_source_lineage_counts_once.py',
              'tests/test_ui_leads.py', 'tests/test_intel_explain.py', 'tests/test_intel_cli.py',
              'tests/test_fabric_adopt.py', str(original / 'test_cvrf_row_types.py'),
              str(original / 'test_cvrf_metadata_budget.py')]
paths = ['src/patchtrace/pilot/sources/kb_context.py', 'tests/test_pilot_kb_metadata_budget.py',
         'tests/test_pilot_kb_storage_classes.py', 'tests/test_pilot_kb_context.py',
         'docs/specs/program-e/pilot-retained-cvrf-context.md']
provenance = {
    'recorded_at_utc': datetime.now(UTC).isoformat(),
    'source_commit': source, 'source_tree': tree,
    'parent_qa_before_metadata_repair': '3897d2ab63cc77d7146dba0835d37f301f730245',
    'spec_red_commit': '91a96acdf9f2c610d650af1a238e46ace5d0d2c3',
    'previous_storage_class_source': '423a4fc00599cd085ac4a3b95db3e164071f4d79',
    'original_bridge_source': '353902677e6d59961e808a90b2a3dd96d2b43269',
    'source_import': kb_context.__file__, 'python': sys.version,
    'platform': platform.platform(), 'worktree': str(root),
    'source_files': [{'path': path, 'sha256': digest(root / path)} for path in paths],
    'original_evidence': [{'path': str(original / origin), 'copy': copy, 'sha256': digest(qa / copy)}
                          for origin, copy in pairs],
    'outcomes': outcomes,
    'qualification': {
        'cwd': str(root),
        'env': {'QT_QPA_PLATFORM': 'offscreen', 'PYTHONPATH': f'{root / "src"}:{root / "tests"}'},
        'argv': [python, '-m', 'pytest', '-q', *selection, f'--junitxml={qa / "affected.xml"}', '--tb=short'],
        'stdout_stderr': 'affected.log', 'exit_code': 0},
    'compatibility': {'before_source': '423a4fc00599cd085ac4a3b95db3e164071f4d79',
                      'after_source': source, 'same_serialized_snapshot': True,
                      'before_json_sha256': digest(qa / 'valid-before.json'),
                      'after_json_sha256': digest(qa / 'valid-after.json'),
                      'context_digest': json.loads((qa / 'valid-after.json').read_text())['digest']},
    'scope': ['kb_context.py only production edit; no shared schema/reader/current_inputs changes',
              'MAX_BYTES is now a stricter combined selected-field byte budget, measured as length(CAST(column AS BLOB))',
              'All 12 columns and all selected rows share the one cap before full shared-row loading',
              'Thirteen new local budget controls; all six unchanged root storage-type/budget probes are included',
              'UTF-8 and embedded-NUL counting, multiple-row aggregate, exact-limit acceptance and one-byte-under refusal',
              'Focused 41 overlaps the 1574 affected checks; the prior 1558 result is historical and does not qualify this repair',
              'Synthetic authored local stores; no network, target/native engine, manual desktop or native Windows acceptance',
              'No arbitrary concurrent DB mutation, SQLite internal working-memory or total I/O/latency guarantee',
              'Combined freshness-hook review and full/platform qualification remain separate root-owned gates']
}
(qa / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
packet = root / 'docs/qa/pilot-cvrf-metadata-budget-20261118'
packet.mkdir(parents=True)
files = sorted(path for path in qa.iterdir() if path.is_file())
archive = packet / 'raw-evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for path in files:
        bundle.write(path, path.name)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for path in files:
        assert hashlib.sha256(bundle.read(path.name)).hexdigest() == digest(path)
manifest = {'source_commit': source, 'source_tree': tree,
            'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': digest(archive)},
            'members': [{'path': path.name, 'bytes': path.stat().st_size, 'sha256': digest(path)} for path in files]}
(packet / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'archive': manifest['archive'], 'members': len(files), 'outcomes': outcomes}, indent=2))
