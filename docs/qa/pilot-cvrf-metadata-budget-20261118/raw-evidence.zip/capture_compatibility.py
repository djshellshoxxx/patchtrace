"""Read the already retained authored project; write no project data or source."""
from pathlib import Path
import json
import sys

from patchtrace.enrichment.storage import EnrichmentStore
from patchtrace.pilot.sources.kb_context import capture
from patchtrace.service import ProjectService

project = Path('/workspace/scratch/c7a9e8d98848/qa/cvrf-pilot-context/journey/P')
with ProjectService.open(project) as service:
    value = capture(service, EnrichmentStore(service.store))
    assert not value.unavailable and value.cves == ('CVE-2099-20001',)
    payload = {'digest': value.digest, 'cves': value.cves, 'unavailable': value.unavailable,
               'warnings': value.warnings, 'withdrawn': value.withdrawn,
               'bundles': [bundle.model_dump(mode='json') for bundle in value.bundles]}
Path(sys.argv[1]).write_text(json.dumps(payload, sort_keys=True, indent=2) + '\n')
print(value.digest)
