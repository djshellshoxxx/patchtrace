"""Independent retained-row metadata allocation controls, with small authored limits."""
import pytest
import test_pilot_kb_context as authored

from patchtrace.enrichment.storage import EnrichmentStore
from patchtrace.pilot.sources import kb_context
from patchtrace.service import ProjectService

case = authored.case


@pytest.mark.parametrize('column', ['created', 'project_id', 'input_digest'])
def test_context_metadata_cannot_bypass_capture_byte_budget(case, monkeypatch, column):
    with ProjectService.open(case) as service:
        db = service.store.connection
        body_size = db.execute("SELECT length(CAST(body AS BLOB)) FROM enrichment_entries WHERE kind='kb-context'").fetchone()[0]
        cap = body_size + 2048
        monkeypatch.setattr(kb_context, 'MAX_BYTES', cap)
        db.execute('UPDATE enrichment_entries SET ' + column + '=? WHERE kind=?', ('x' * (cap + 1), 'kb-context'))
        enrichment = EnrichmentStore(service.store)

        def refuse_body_loading(*args, **kwargs):
            raise AssertionError('over-budget context metadata reached unbounded shared row loading')

        monkeypatch.setattr(enrichment, 'entries', refuse_body_loading)
        snapshot = kb_context.capture(service, enrichment)
        assert snapshot.unavailable and snapshot.warnings and not snapshot.cves
