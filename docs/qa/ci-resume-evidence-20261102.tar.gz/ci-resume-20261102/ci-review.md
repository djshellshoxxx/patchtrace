# PatchTrace resumed CI review — 2026-11-02 UTC

Read-only GitHub review of the exact published heads after the interrupted workspace was reset. No remote mutation, approval, workflow dispatch, issue resolution or test execution was performed by this reviewer. Source and test evidence already committed before the reset remains historical evidence; unpublished local runs cannot be recovered from this review.

All checks, statuses, workflow runs, jobs, reviews, inline comments and discussion comments were fetched with `per_page=100`; every second page was empty. Review-thread counts agree with the inline-comment collection. Full retrieved records are retained in `audit-raw.json.gz`; original job logs are retained separately. The annotation subresource is unsupported by the connector (HTTP 400); ordinary unauthenticated GitHub REST reads retrieved all annotation pages. No detailed Sonar source-to-sink trace was available in those annotations.

## Exact source and disposition

| PR | Head / tree | Current result |
|---|---|---|
| #151 | `ad63416348c122ade8419b11686164be09bb2af3` / `6237bbc9c842e42370ce5dfd557dbe17dbddcf8e` | HOLD: widespread real Windows backup verification failures; no merge qualification |
| #154 | `f27d23a80ee49573ccca54cdf036427f57eebb2a` / `8ef0a587631bd830ddb44f6a1fdaf1f698ab0f9b` | HOLD: Sonar C security gate; actual QA and packages passed |
| #156 | `4eebea4a5389af16bffe32a2bf9285c406d95fb1` / `eb99eb5b0498e09c1bc3cacf0e212159161b6c09` | Applicable independent-slice gates passed; coordinator reports merged, separately verified below |
| #157 | `aff72cddc902f31a2cf44dea9c48797edabc1c30` / `ee93c927d8a7f7e4d5e7a216da41d5212286c99b` | HOLD: Windows unchanged-file reads fail, Sonar C security gate, additional credit-manifest review pending |

The coordinator merged #156 as `25c9795bd9cd58bfad855f30594ee3a0c7584cec`; a fresh GitHub commit read verifies tree `eb99eb5b0498e09c1bc3cacf0e212159161b6c09`, exactly equal to the qualified candidate. The PR is now closed/merged. This reviewer performed no merge.

Initial main was `6579ed83211b7ff2039e3152728ac1cddc3e93d6`, tree `4da0e0ba4b23c5a3c1e582ab931a3160c3608f57`. The branch API reported `protected: false`, and repository rulesets were empty. These observations do not waive the owner's independent review or acceptance requirements.

## #151: Windows failure is material

[QA run 41313917033](https://github.com/djshellshoxxx/patchtrace/actions/runs/41313917033) failed. Windows full suite job `124869957718`: **563 failed, 17,644 passed, 81 skipped, 6 xfailed, 179 errors** in 3255.03 s. Windows Qt job `124869957831`: **115 failed, 9,215 passed, 80 errors** in 4639.71 s. Repeated traces reach `verified_backup.py:253`: `_fingerprint(part)` returns `None` and raises `BackupError: pre-enrichment database backup changed during verification`; this propagates into project/enrichment/GUI failures. The logs establish a concrete failure, not its exact platform API cause. A Windows stat/fstat consistency hypothesis must be reproduced without weakening identity, mutation, byte-digest or no-overwrite checks.

Linux full QA: **18,412 passed, 47 skipped, 7 xfailed** in 1712.70 s. All four Linux Qt legs passed. Both five-variant native workflows passed their scopes. Sonar and CodeRabbit passed, with no unresolved inline review threads. These successes do not qualify the failing Windows source. Linux packaging/smoke was skipped because QA failed; release and release-gate were skipped.

## #154: passing execution, unresolved source-quality gate

[QA run 41316338796](https://github.com/djshellshoxxx/patchtrace/actions/runs/41316338796) passed. Linux: **18,492 passed, 47 skipped, 7 xfailed** in 1544.59 s. Windows: **18,459 passed, 81 skipped, 6 xfailed** in 2018.98 s. All Qt repetition legs and Windows/Linux package/smoke steps passed. Corpus Tier R workflow `41316338809` passed its own advisory/shard/merge scope; this is not full native engine acceptance. Release was skipped.

Sonar check `124877284805` failed the C security rating. Two annotations:

- `tools/calibration/prereg_gate.py:16`, issue `AaGXQElGeRS3ER4AhK9_`: possible super-linear regex backtracking warning for `_FENCE`.
- `tools/calibration/prereg_gate.py:168`, issue `AaGXQElGeRS3ER4AhK-A`: “Path Traversal via faulty LLM-supplied CLI arguments in prereg_gate.select()”. This is the explicit caller-selected QA file read; the annotation contains no authority-boundary or dataflow trace. No suppression or false-positive designation was made.

All four earlier Markdown correctness threads are resolved. A separate bounded source investigation will determine whether the regex warning is reachable through the real parser; no exploit is inferred from a warning alone.

## #156: independent identity slice qualified

[QA run 41316317810](https://github.com/djshellshoxxx/patchtrace/actions/runs/41316317810): Linux **18,452 passed, 47 skipped, 7 xfailed** in 1583.80 s; Windows **18,419 passed, 81 skipped, 6 xfailed** in 2817.69 s. Linux Qt repetition shards passed 10,100 / 8,700 / 9,640 / 9,060 executed checks; Windows five-repeat leg passed 9,375 checks. These repeat counts are not additional unique tests.

The PR merge ref actually checked out by QA was `66f970c37b06f25245d61f8f750a6f13663bf629`; its tree is exactly `eb99eb5b0498e09c1bc3cacf0e212159161b6c09`, equal to the published head. Its parents are main `6579ed8` and head `4eebea4`.

Windows build, frozen executable smoke, portable extraction/execution, pinned NSIS build and install/launch/uninstall steps passed. Linux package build and both Ubuntu 22.04 / 24.04 offscreen and Xvfb smoke jobs passed. Sonar, CodeRabbit and Snyk passed. Release/release-gate were skipped; no release was published.

[Native workflow 41316317849](https://github.com/djshellshoxxx/patchtrace/actions/runs/41316317849) actually ran each applicable target step across clean, seeded-store, seeded-store-without-adjacent-PDB, raw-cache-hit and plain-Ghidriff cached-PDB reproduction variants; all passed. The Ghidra pin remained 12.0.4, and the Ghidriff source pin was `4f5d895fcbb1eacd65efd81145922c15bb7e741d`. The separate push-triggered native workflow also passed.

[Live Rizin workflow 41316317851](https://github.com/djshellshoxxx/patchtrace/actions/runs/41316317851) reported one authored fixture per OS as passed, with 322 Windows matches and 30 Linux matches on 0.9.1. These records are fixture-local and do not establish conditional orientation, same-run witness, general compatibility or lift the combined candidate's later quarantine.

Both substantive earlier review threads are resolved. One minor documentation thread remains: the old 125-test coordinator run lacks an exact command in its cited JSON receipt. The committed `identity-main-final-review.log.gz` does contain **125 passed in 2.66 s**, and `identity-main-root-review.log.gz` contains **128 passed in 3.19 s**. Thus the count/log exist, while the command attribution remains incomplete. Fresh exact-tree CI qualification does not depend on inferring that missing historical command.

### Downloaded package verification

All outer downloaded GitHub artifact hashes and inner package hashes were recomputed; each inner sidecar matches. These are ordinary package variants, with dependency-version and file-inventory JSON plus notices/licenses and separate Qt libraries. They are not the full offline backend bundle, and contain no full-bundle `build-provenance.json`. Immutable workflow/artifact/head-tree records bind this download to source; no new human desktop acceptance is claimed.

| Artifact / package | Bytes | SHA-256 |
|---|---:|---|
| Windows outer artifact `13091042282` | 129,118,749 | `3d35be3c7d8b8d68167694aaeacb3e70d980c31d75a7fa012fbd52eff0588a17` |
| `PatchTrace-0.1.0-windows-x64.zip` | 65,469,315 | `6ded861cba99cc69f69e9f3283a564f1702d36729100023e744c84f9e33865b2` |
| `PatchTrace-Windows-x64-Setup.exe` | 64,298,766 | `510f3eddac07864826f3856f9cf8bcef330a942068ca0fa879ffa1882e7d4db7` |
| Linux outer artifact `13090844108` | 93,797,101 | `33d761425d2003941d94f903e3d6be2d1f8e1c20238e708e83852e3655e91701` |
| `PatchTrace-0.1.0-linux-x86_64.tar.gz` | 94,377,398 | `12508ad13c54e9daf8e0841e75ed80f1a16ab030a12eddfed46ddbf39fc278fe` |

The packages remain downloadable under QA run `41316317810`; local outer archives are retained only for verification, not duplicated into Git evidence archives.

## #157: Windows reader and remaining review

[QA run 41316567247](https://github.com/djshellshoxxx/patchtrace/actions/runs/41316567247) failed. Windows job `124877832666`, Python 3.12.10 x64: **60 failed, 18,360 passed, 81 skipped, 6 xfailed, 27 errors** in 2521.67 s. Ordinary unchanged output files are rejected by `read_output_bytes` with “output bytes changed while reading or exceed their byte limit”; synthetic training fixtures fail before training. The `output_windows` owner is investigating this separately from #151's backup defect. Linux passed **18,480 tests, 47 skipped, 7 xfailed** in 1722.92 s; all Qt jobs passed. Packaging was skipped after QA failure.

Sonar check `124877970336` failed with one annotation: `output_store.py:91`, issue `AaGXhfrn5xr-Pq-Fbk3s`, generic CLI path traversal title. There is no detailed flow; this finding is distinct from the reproduced Windows read failure.

Earlier key comparability, pre-encoding validation and uncredited-file adoption findings are recorded as resolved by Qodo; one older CodeRabbit comparability thread remains unresolved despite the repair. The current-head CodeRabbit comment at line 359 identifies a separate potential limit problem: credit manifests embed full reports and all successful references, but share the single-output 64 MiB cap, with finalization able to fail after provider work. No large corpus or final evaluation was consumed to test this. Qodo also retains long-name policy and new 0600 publication-permission compatibility concerns; these need contract-aware disposition, not a blind schema widening or permission weakening.

## Limits

## #152 follow-up: exact combined candidate failures

Current combined head `039c696c93a443d152d4ddc1383179408ff86b75`, tree `d5bf7fe7aba3315d1e9244cce922e40c28264fe4`, was inspected separately after the initial independent-slice audit. Metadata is in `combined152-and-merge156.json.gz`. All seven run job collections, workflow runs and checks were retrieved through an empty second page. This follow-up did not re-audit #152 review discussions.

[QA run 41316907996](https://github.com/djshellshoxxx/patchtrace/actions/runs/41316907996) failed. Linux job `124878872933`: **11 failed, 19,112 passed, 49 skipped, 7 xfailed** in 1718.42 s. Windows job `124878873026`: **658 failed, 18,233 passed, 83 skipped, 6 xfailed, 206 errors** in 3345.73 s. Windows includes the independently reproduced #151 backup and #157 output-reader failures as well as these combined fixtures. Linux Qt shard 1 job `124878873257`: **60 failed, 10,840 passed**; shard 2 cancelled, shards 3 and 4 passed. Windows Qt job `124878873123`: **170 failed, 9,320 passed, 80 errors**. Repetition counts are not unique test counts. Packaging, smoke and release were skipped.

The exact Linux failures are:

| Test node | Observed assertion / source of failure |
|---|---|
| `tests/test_audit2_fixes.py::test_adapter_parse_input_error_is_runtime_exit_3` | Expected `PT-SECONDARY-INPUT`, received `PT-SECONDARY-UNSUPPORTED`; synthetic producer still reports quarantined `0.9.1` |
| `tests/test_audit_desktop.py::test_self_test_failure_releases_project` | Expected error regex `self-test`; actual intentional failure is `KB frozen journey: desktop sample matches did not display` |
| `tests/test_calibration_tools.py::test_train_serve_identity_through_features_artifact_and_runtime_predict` | Expected all `G+R` profiles; synthetic positive matches still use `0.9.1` |
| `tests/test_evidence_panel_service.py::test_execute_run_success_and_failure_isolated` | Expected rz-diff success, received failed; synthetic `0.9.1` producer |
| `tests/test_evidence_panel_service.py::test_build_request_and_persist_on_service` | Expected success, received failed; synthetic `0.9.1` producer |
| `tests/test_evidence_ui.py::test_state_ready_three_engines_columns_headers_and_units` | Expected `0.9.1` header while shared synthetic fixture now reports `0.9.0` |
| `tests/test_evidence_ui.py::test_run_success_stores_set_on_gui_thread_and_refreshes` | 5000 ms waitUntil timeout; requires producer-fixture inspection |
| `tests/test_evidence_ui.py::test_run_one_engine_fails_other_result_kept` | 5000 ms waitUntil timeout; requires producer-fixture inspection |
| `tests/test_tier_r_eval_engines.py::test_rzdiff_through_the_production_adapter` | Expected `(ok, 0.9.1)`, received `(blocked, None)` |
| `tests/test_tier_r_eval_engines.py::test_rzdiff_failure_is_failed_not_blocked` | Expected failed, received blocked before intended provider failure |
| `tests/test_tier_r_eval_engines.py::test_visible_symbols_uses_the_debug_images` | Expected ok, received blocked |

These are actionable fixture/message findings; the two UI timeouts still require source confirmation. Preserve real `0.9.1` quarantine controls and negative tests when repairing synthetic positives. No production quarantine, default pin, workflow or test was changed by this review.

Corpus Tier R run `41316907969` has two failing evaluation shards, each explicitly blocked by `rz-diff 0.9.1` orientation quarantine; shard reports have `failed: []` and `blocked: [evaluate:rz-diff]`. The merge reports two failing cases because those shards are blocked. The source-only byte-identical non-discriminating card is deliberately skipped. Live Rizin run `41316907978` is similarly blocked on both OSes (`rz-diff-orientation-unverified`). These remain unresolved acceptance gates; they are not native Ghidriff failures or permission to disable quarantine. Both five-variant native runs, live unified extraction and optional-wheel probes passed their respective workflow scopes; no claim beyond their retrieved job steps is made.

Sonar check `124879052331` failed with 11 annotations, retained through an empty second page in `annotations-124879052331.json`. It includes the known prereg/output-store findings, two variable tuple-length warnings in unified sources, generic CLI path/injection titles in the GT-12 stage script and Windows resource builders, and deterministic benchmark RNG warnings. Every annotation has `raw_details: null`; no exploit or false-positive disposition is inferred.

## Overall limits

No overall completion, combined native/frozen acceptance, final release, real corpus calibration, owner-local Tier W processing or human usability sign-off is established here. This review recovered published evidence only. The interrupted unpublished full-suite and helper results remain unavailable until separately recovered or re-executed.
