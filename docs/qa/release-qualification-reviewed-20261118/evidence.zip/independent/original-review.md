# Independent release qualification review: original source

Reviewed implementation: `0bb63363ed675266ec4572a85ee0c0861aa714b7`.
Author QA tip: `8d090f9722ba9b412c89c9877729a77f35afeca9`.
Original implementation baseline: `9e5a5303da6e9a745e604979932f814de8eca4b0`.
Independent detached checkout: `/workspace/scratch/c7a9e8d98848/release-review`.

This checkpoint records three confirmed publication blockers. It does not accept
the original implementation. The author owns the repairs; the independent
checkout and original red controls are unchanged.

## Confirmed findings

1. `tools/release_qualification.py::checked_source` compares the requested SHA and
   actual commit message without replacement objects, but verifies tracked
   changes with ordinary `git diff --quiet HEAD --`. Actual authored Git
   repositories demonstrate acceptance of changed tracked file bytes hidden by
   a replacement object, `assume-unchanged`, or `skip-worktree`. Each control first
   proves the canonical committed bytes differ from the current file and that
   ordinary Git diff reports no change. The guard then returns successfully.
2. `strict_json` rejects literal NaN/Infinity through `parse_constant`, but accepts
   exponent overflow such as `1e999` as an infinite Python float. The defect occurs
   at the top level and nested in JSON. A complete authored qualification record
   still qualifies when its native BinDiff status ZIP contains an overflowed
   numeric metadata field.
3. `native_artifacts` validates both platform names and ownership fields but does
   not require their artifact IDs to differ. Two platform records claiming the
   same ID qualify the same ZIP twice. This is malformed ownership evidence,
   rather than evidence of two independent platform artifacts.

## Reproducers and results

The independent authored controls are in `test_release_adversarial.py` beside
this receipt. `adversarial-red.log` and `adversarial-red.xml` preserve **7 failed,
4 passed** on the exact source above, with no setup errors. The failures are:

- `test_actual_source_bytes_cannot_be_hidden_from_qualification`: three masks.
- `test_json_exponent_overflow_is_rejected_as_nonfinite_evidence`: two inputs.
- `test_nonfinite_native_extra_metadata_cannot_qualify_the_full_aggregate`.
- `test_two_platform_reports_cannot_claim_the_same_artifact_identity`.

The four passing controls preserve actual commit hold enforcement despite
replacement metadata, a valid nested annotated tag with existing assets,
non-disclosure of an authored dummy credential on command failure, and a valid
finite JSON/complete qualification case. REST and ZIP fixtures reuse the author's
AuthoredAPI scaffold; adversarial mutations, assertions, and local Git
repositories are independently authored.

The existing affected gate independently reports **450 passed, 3 expected
failures**, retained in `affected.log` and `affected.xml`. The expected failures
are the existing CODEX-1 immutable-action, CODEX-5 pip-hash, and CODEX-6 corpus-cache
controls. Whole-tree Ruff passes in `ruff.log`.

All commands use `/workspace/scratch/3a6632a6e5ff/venv/bin/python`,
`QT_QPA_PLATFORM=offscreen`, and the absolute review checkout's `src`, `tests`,
and root on `PYTHONPATH`. `source-context-original.json` identifies the exact
source, runtime, source file hashes, and external test hash.

## Other reviewed boundaries and limitations

Read the implementation, source/spec/test diffs, publishing workflow changes,
and actual author QA receipt. The required workflows have no custom source-ref
override in the reviewed checkout. The guard refuses missing/skipped critical
jobs and steps, preview/fork runs, changed attempts, a different publication
run, stale or foreign native artifact ownership, mismatching or cyclic tag
targets, and existing asset-name collisions. These observations are bounded by
the reviewed code and authored controls; they do not constitute hosted release
qualification.

The reserved dependency/security workflow is missing, and Windows BinDiff's
required network-denial result is still blocked. These remain explicit blockers
in the policy, not passed checks. No native execution, real target processing,
credential inspection, release mutation, or workflow dispatch occurred. The
review does not claim a transaction locking remote refs between verification and
publication.

The author's original archive was fully reopened and verified: **34 unique
members, 70,444 bytes**, SHA-256
`7f5d2eeddfe5b6db3aee84615064b816c78cf79287f8a41166ffb5361061101f`.
Every member's byte count and SHA-256 match its manifest;
`author-archive-verification.json` retains the result. Historical hosted job
receipts contain `run_attempt`; those receipts are historical source evidence
and are not credited to the reviewed implementation.

A separate final receipt will identify the corrected source and rerun these
unchanged controls before any acceptance recommendation.
