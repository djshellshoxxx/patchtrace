"""Read retained hosted bytes only; never invoke a scanner, tool, or target."""
from __future__ import annotations

import collections
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/c7a9e8d98848/static-scan-receipt')
SOURCE = '14efc52369146f4a638b7d688208736a05321bc0'
PREVIEW = '5ed108355f2626c9867782832c76b1c438c51281'
LOCAL = '740869debb111f8edbef33899316e4c75e6fdf7a'


def read_api(name):
    return json.loads(json.loads((ROOT / 'api' / f'{name}.json').read_text())['raw_content'])


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', '-C', str(REPO), *args])


def main():
    source = read_api('source-commit')
    preview = read_api('preview-commit')
    assert source['sha'] == SOURCE and preview['sha'] == PREVIEW
    assert source['tree']['sha'] == preview['tree']['sha'] == git('rev-parse', LOCAL + '^{tree}').decode().strip()
    assert read_api('main')['commit']['sha'] == '9c411ca3d7b47f950be5f0c6f01b3c54184554c6'
    pr = read_api('pr316')
    assert pr['head']['sha'] == SOURCE and pr['merge_commit_sha'] == PREVIEW and pr['state'] == 'open'
    assert '[no release]' in source['message']
    snapshots = []
    for name in ['tools/release_qualification.py', 'tools/windows_bindiff_network.py',
                 'tools/dependency_security.py', '.github/workflows/live-bindiff.yml',
                 '.github/workflows/dependency-security.yml']:
        data = git('show', LOCAL + ':' + name)
        out = ROOT / 'source-tree-b93' / name
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(data)
        snapshots.append({'path': name, 'sha256': hashlib.sha256(data).hexdigest(),
                          'blob': git('rev-parse', LOCAL + ':' + name).decode().strip()})
    log_receipts = []
    for path in sorted((ROOT / 'logs').glob('*.json')):
        envelope = json.loads(path.read_text())
        raw = envelope['raw_content'].encode('utf-8')
        out = path.with_suffix('.log')
        if out.exists():
            assert out.read_bytes() == raw
        else:
            out.write_bytes(raw)
        assert PREVIEW in raw.decode('utf-8')
        log_receipts.append({'job_id': envelope['job_id'], 'bytes': len(raw),
                             'sha256': hashlib.sha256(raw).hexdigest(), 'checkout': PREVIEW})
    metadata = {}
    for run in [44377335166, 44377335068]:
        for artifact in read_api(f'artifacts-{run}')['artifacts']:
            metadata[artifact['id']] = artifact
    artifacts = []
    for path in sorted((ROOT / 'artifacts').glob('*.zip')):
        artifact_id = int(path.stem.removeprefix('artifact-'))
        expected = metadata[artifact_id]
        raw = path.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        assert len(raw) == expected['size_in_bytes'] and 'sha256:' + digest == expected['digest']
        with zipfile.ZipFile(path) as archive:
            assert archive.testzip() is None
            names = archive.namelist()
            assert len(names) == len(set(names))
            item = {'id': artifact_id, 'bytes': len(raw), 'sha256': digest, 'members': names}
            if 'verdict.json' in names:
                item['verdict'] = json.loads(archive.read('verdict.json'))
            if 'static.stdout' in names:
                findings = json.loads(archive.read('static.stdout'))
                item['static'] = {'count': len(findings), 'codes': dict(collections.Counter(x['code'] for x in findings)),
                                  'process': json.loads(archive.read('static.process.json')),
                                  'bootstrap_text_present': 'bootstrap-pip.txt' in names}
                assert len(findings) == 80 and item['static']['process']['exit_code'] == 1
            if 'bindiff.json' in names:
                report = json.loads(archive.read('bindiff.json'))
                assert report['status'] == 'passed' and report['mocked'] is False
                assert len(report['checks']) == 7 and all(c['status'] == 'passed' for c in report['checks'].values())
                assert report['checks']['end_to_end']['semantic_sha256'] == report['checks']['no_network']['semantic_sha256']
                item['bindiff_report'] = report
            artifacts.append(item)
    report = {'source_sha': SOURCE, 'preview_sha': PREVIEW, 'tree': source['tree']['sha'],
              'local_tree_equivalent_commit': LOCAL, 'sources': snapshots, 'logs': log_receipts,
              'artifacts': artifacts, 'qualification': 'Blocked; PR preview evidence is not canonical release evidence',
              'windows_cause': 'Generic tracked-file changed-at-open guard refusal; path/stat fields not logged',
              'scope': 'Bounded read-only snapshot; no native target or scanner run locally'}
    (ROOT / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({'artifacts': len(artifacts), 'source_snapshots': len(snapshots), 'logs': len(log_receipts),
                      'source': SOURCE, 'preview': PREVIEW, 'qualification': 'blocked'}))


if __name__ == '__main__':
    main()
