"""Independent saved-query execution-intent control."""
from threading import Event

from test_ui_search_saved import prepare, rig  # noqa: F401


def test_recalling_recent_text_does_not_run_it_when_an_earlier_build_finishes(rig, qtbot):
    c = rig.controller
    prepare(c, 'old_query')
    c.saved.remember('new_query')
    started, release = Event(), Event()
    def build(_service, _cancel, _progress):
        started.set()
        if not release.wait(5):
            raise RuntimeError('test build was not released')
    c.builder = build
    c.build()
    try:
        qtbot.waitUntil(started.is_set)
        c.saved.recall_recent(1)
        assert c.panel.query.text() == 'new_query'
        release.set()
        qtbot.waitUntil(lambda: not rig.shell.tasks.busy(), timeout=7000)
        qtbot.wait(350)
        assert rig.calls == [], 'completion of an older build executed recalled text without Enter'
    finally:
        release.set()
