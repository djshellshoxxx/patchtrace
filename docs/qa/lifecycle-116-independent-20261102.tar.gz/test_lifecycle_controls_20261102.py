"""Independent controls for committed lifecycle slice 3f5b63b only; no target execution."""
from __future__ import annotations

import threading

import pytest
from PySide6.QtCore import QObject, QSettings, Qt, QTimer, Signal
from PySide6.QtWidgets import QApplication, QMessageBox

from patchtrace import ui_inspection
from patchtrace.enrichment.profiles import AnalysisProfile, ProfileStore
from patchtrace.service import ProjectService
from patchtrace.ui import MainWindow, ProfilesPanel


def panel_for(qtbot, tmp_path):
    store = ProfileStore(tmp_path / 'profiles')
    store.save(AnalysisProfile(name='alpha'))
    store.save(AnalysisProfile(name='beta'))
    panel = ProfilesPanel(store.directory, selected='alpha')
    qtbot.addWidget(panel)
    panel.weights['BND'].setValue(31)
    return panel


def answer_modal(qtbot, choice):
    seen, errors = [], []
    def answer():
        box = QApplication.activeModalWidget()
        try:
            assert isinstance(box, QMessageBox)
            assert box.textFormat() == Qt.TextFormat.PlainText
            assert box.standardButton(box.defaultButton()) == QMessageBox.StandardButton.Cancel
            assert box.standardButton(box.escapeButton()) == QMessageBox.StandardButton.Cancel
            assert all(b.toolTip() and b.accessibleDescription() for b in box.buttons())
            seen.append(box.windowTitle())
            if choice is None:
                qtbot.keyClick(box, Qt.Key.Key_Escape)
            else:
                box.button(choice).click()
        except BaseException as error:
            errors.append(error)
            if isinstance(box, QMessageBox):
                box.reject()
    QTimer.singleShot(0, answer)
    return seen, errors


@pytest.mark.parametrize('action', ['new_profile', 'duplicate_profile'])
@pytest.mark.parametrize('choice', [QMessageBox.StandardButton.Save, QMessageBox.StandardButton.Discard,
                                   QMessageBox.StandardButton.Cancel, None], ids=['save', 'discard', 'cancel', 'escape'])
def test_actual_modal_new_duplicate_decisions(qtbot, tmp_path, action, choice):
    panel = panel_for(qtbot, tmp_path)
    prompts, errors = answer_modal(qtbot, choice)
    getattr(panel, action)()
    assert not errors and prompts == ['Unsaved profile changes']
    saved = choice == QMessageBox.StandardButton.Save
    assert panel.store.get('alpha').weights['BND'] == (31 if saved else 30)
    if choice in (None, QMessageBox.StandardButton.Cancel):
        assert panel.selected_name() == 'alpha' and panel.weights['BND'].value() == 31 and panel.is_dirty()
        assert panel.store.names() == ['alpha', 'beta']
    else:
        created = 'profile' if action == 'new_profile' else 'alpha copy'
        assert panel.selected_name() == created and not panel.is_dirty()
        assert panel.store.get(created).weights['BND'] == (31 if saved and action == 'duplicate_profile' else 30)


@pytest.mark.parametrize('action', ['new_profile', 'duplicate_profile'])
@pytest.mark.parametrize('failure', ['storage', 'validation'])
def test_new_duplicate_save_failure_retains_editor_and_all_saved_bytes(qtbot, tmp_path, monkeypatch, action, failure):
    panel = panel_for(qtbot, tmp_path)
    original = {p.name: p.read_bytes() for p in panel.store.directory.glob('*.json')}
    if failure == 'storage':
        def refuse(*args, **kwargs):
            raise OSError('independent constructed storage refusal')
        monkeypatch.setattr(panel.store, 'save', refuse)
    else:
        panel.feature_ids.setText('invalid feature id')
    prompts, errors = answer_modal(qtbot, QMessageBox.StandardButton.Save)
    getattr(panel, action)()
    assert not errors and prompts == ['Unsaved profile changes']
    assert panel.selected_name() == 'alpha' and panel.weights['BND'].value() == 31 and panel.is_dirty()
    assert 'Not saved' in panel.error.text()
    assert {p.name: p.read_bytes() for p in panel.store.directory.glob('*.json')} == original
    if failure == 'validation':
        assert panel.feature_ids.text() == 'invalid feature id'


class FailureEmitter(QObject):
    failed = Signal(str, object)


def window_for(qtbot, tmp_path, monkeypatch):
    window = MainWindow(ProjectService.sample(tmp_path / 'P'),
                        QSettings(str(tmp_path / 'ui.ini'), QSettings.Format.IniFormat))
    qtbot.addWidget(window)
    monkeypatch.setattr(window, 'start_inspection', lambda: None)
    window.show_file_overview()
    return window


def test_queued_orientation_failure_is_ignored_but_current_failure_is_visible(qtbot, tmp_path, monkeypatch):
    window = window_for(qtbot, tmp_path, monkeypatch)
    emitter = FailureEmitter()
    emitter.failed.connect(window._inspection_failed, Qt.ConnectionType.QueuedConnection)
    old_key = window._project_inspection_key()
    emitter.failed.emit('OldOrientationFailure', old_key)
    window.service.swap_orientation()
    current = window._project_inspection_key()
    assert current != old_key
    qtbot.wait(20)
    assert window._inspection_error is None
    assert 'OldOrientationFailure' not in window.logs.toPlainText()
    emitter.failed.emit('CurrentOrientationFailure', current)
    qtbot.waitUntil(lambda: window._inspection_error is not None)
    assert window._inspection_error == (current, 'CurrentOrientationFailure')
    assert 'CurrentOrientationFailure' in window.panels.controller('files').status.text()
    assert 'CurrentOrientationFailure' in window.logs.toPlainText()
    window.close()


@pytest.mark.parametrize('cancelled', [False, True])
def test_actual_inspection_thread_failure_cancellation_and_queued_delivery(qtbot, tmp_path, monkeypatch, caplog,
                                                                        cancelled):
    window = window_for(qtbot, tmp_path, monkeypatch)
    entered, release = threading.Event(), threading.Event()
    def fail_after_release(*args):
        entered.set()
        if not release.wait(10):
            raise AssertionError('test release was not signalled')
        raise OSError('independent constructed read failure')
    monkeypatch.setattr(ui_inspection, 'inspect_project_artifacts', fail_after_release)
    key = window._project_inspection_key()
    worker = ui_inspection.InspectionThread(window.project.id, window.project.artifacts,
                                            window.service.root, window, key)
    worker.inspection_failed.connect(window._inspection_failed, Qt.ConnectionType.QueuedConnection)
    worker.start()
    try:
        qtbot.waitUntil(entered.is_set)
        if cancelled:
            worker.cancel.set()
        release.set()
        qtbot.waitUntil(worker.isFinished)
        qtbot.wait(20)
        assert 'File inspection failed' in caplog.text
        if cancelled:
            assert window._inspection_error is None
            assert 'File inspection failed' not in window.panels.controller('files').status.text()
            assert 'File inspection failed' not in window.logs.toPlainText()
        else:
            assert window._inspection_error == (key, 'OSError')
            assert 'File inspection failed: OSError' in window.panels.controller('files').status.text()
    finally:
        release.set()
        worker.wait(10000)
        window.close()
