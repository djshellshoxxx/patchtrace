"""Independent behavior controls against source 06f5b210; Linux filesystem, no native target runs."""
from __future__ import annotations

import hashlib
import io
import os
import subprocess
import sys
from pathlib import Path

import pytest

from patchtrace.intelligence import storage
from patchtrace.intelligence.contracts import IntelError
from patchtrace.intelligence.storage import AdvisoryStore

SOURCE = Path('/workspace/scratch/c7a9e8d98848/advisory-bounds-review/src')


@pytest.fixture
def store(tmp_path):
    root = tmp_path / 'project'
    root.mkdir()
    # This read-only API never touches pointer rows or an enrichment connection.
    return AdvisoryStore(root, None, 'independent-review', 1)


def watched_read(monkeypatch, target, *, before=None, after=None):
    """Observe the actual opened file by inode; mutate only at the content read boundary."""
    original = io.open
    identity = (target.stat().st_dev, target.stat().st_ino)
    seen = {'reads': [], 'fds': [], 'mutations': 0}

    class Reader:
        def __init__(self, handle):
            self.handle = handle

        def read(self, amount=-1):
            seen['reads'].append(amount)
            if before:
                before()
                seen['mutations'] += 1
            data = self.handle.read(amount)
            if after:
                after()
                seen['mutations'] += 1
            return data

        def __getattr__(self, attr):
            return getattr(self.handle, attr)

        def __enter__(self):
            return self

        def __exit__(self, *args):
            return self.handle.__exit__(*args)

    def opened(file, mode='r', *args, **kwargs):
        handle = original(file, mode, *args, **kwargs)
        info = os.fstat(handle.fileno())
        if mode == 'rb' and (info.st_dev, info.st_ino) == identity:
            seen['fds'].append(handle.fileno())
            return Reader(handle)
        return handle

    monkeypatch.setattr(io, 'open', opened)
    return seen


def assert_closed(seen):
    for fd in seen['fds']:
        with pytest.raises(OSError):
            os.fstat(fd)


def test_real_default_cap_refuses_matching_digest_without_content_read(store, monkeypatch):
    assert storage.MAX_SIDECAR_BYTES == 64 * 1024 * 1024
    path = store.root / 'oversized'
    size = storage.MAX_SIDECAR_BYTES + 1
    with path.open('wb') as handle:
        handle.truncate(size)  # sparse real file; no over-budget payload allocation in test
    digest = hashlib.sha256()
    block = bytes(1024 * 1024)
    for _ in range(64):
        digest.update(block)
    digest.update(b'\0')
    seen = watched_read(monkeypatch, path)
    with pytest.raises(IntelError) as caught:
        store.read_verified('oversized', digest.hexdigest())
    assert caught.value.code == 'PT-INTEL-INTEGRITY'
    assert seen['reads'] == []


def test_exact_custom_budget_and_valid_digest_are_accepted(store, monkeypatch):
    payload = b'bounded exact boundary'
    path = store.root / 'exact'
    path.write_bytes(payload)
    seen = watched_read(monkeypatch, path)
    assert store.read_verified('exact', hashlib.sha256(payload).hexdigest(), maximum=len(payload)) == payload
    assert seen['reads'] == [len(payload) + 1]
    assert_closed(seen)


def test_growth_after_size_check_is_bounded_and_refused(store, monkeypatch):
    payload = b'bounded exact boundary'
    path = store.root / 'growing'
    path.write_bytes(payload)

    def grow():
        with path.open('ab') as handle:
            handle.write(b' appended after the held descriptor size check')

    seen = watched_read(monkeypatch, path, before=grow)
    with pytest.raises(IntelError) as caught:
        store.read_verified('growing', hashlib.sha256(payload).hexdigest(), maximum=len(payload))
    assert caught.value.code == 'PT-INTEL-INTEGRITY'
    assert seen['mutations'] == 1 and seen['reads'] == [len(payload) + 1]
    assert_closed(seen)


@pytest.mark.parametrize('mutation', ['leaf', 'parent', 'in_place'])
def test_same_byte_digest_does_not_hide_concurrent_identity_change(store, monkeypatch, mutation):
    directory = store.root / 'retained'
    directory.mkdir()
    path = directory / 'data'
    payload = b'previous verified evidence'
    path.write_bytes(payload)

    def change():
        if mutation == 'leaf':
            replacement = directory / 'replacement'
            replacement.write_bytes(payload)
            os.replace(replacement, path)
        elif mutation == 'parent':
            directory.rename(store.root / 'previous-retained')
            directory.mkdir()
            path.write_bytes(payload)
        else:
            before = path.stat()
            path.write_bytes(b'x' * len(payload))
            os.utime(path, ns=(before.st_atime_ns, before.st_mtime_ns + 1_000_000))

    seen = watched_read(monkeypatch, path, after=change)
    with pytest.raises(IntelError) as caught:
        store.read_verified('retained/data', hashlib.sha256(payload).hexdigest(), maximum=len(payload))
    assert caught.value.code == 'PT-INTEL-INTEGRITY'
    assert seen['mutations'] == 1 and seen['reads'] == [len(payload) + 1]
    assert_closed(seen)


def test_digest_failure_closes_the_held_leaf(store, monkeypatch):
    path = store.root / 'mismatch'
    path.write_bytes(b'source')
    seen = watched_read(monkeypatch, path)
    with pytest.raises(IntelError) as caught:
        store.read_verified('mismatch', '0' * 64, maximum=6)
    assert caught.value.code == 'PT-INTEL-INTEGRITY'
    assert seen['reads'] == [7]
    assert_closed(seen)


@pytest.mark.parametrize('kind', ['directory', 'fifo'])
def test_nonregular_object_is_refused_without_blocking(store, kind):
    path = store.root / kind
    if kind == 'directory':
        path.mkdir()
    else:
        os.mkfifo(path)
    code = '''
import sys
from pathlib import Path
from patchtrace.intelligence.storage import AdvisoryStore
from patchtrace.intelligence.contracts import IntelError
try:
    AdvisoryStore(Path(sys.argv[1]), None, 'review', 1).read_verified(sys.argv[2], '0' * 64)
except IntelError as exc:
    print(exc.code)
    raise SystemExit(0)
raise SystemExit(9)
'''
    result = subprocess.run([sys.executable, '-c', code, str(store.root), kind],
                            env={**os.environ, 'PYTHONPATH': str(SOURCE)}, capture_output=True,
                            text=True, timeout=5)
    assert result.returncode == 0, result.stderr
    assert result.stdout.strip() == 'PT-INTEL-INTEGRITY'


def test_parent_symlink_refused_even_if_digest_matches(store, tmp_path):
    outside = tmp_path / 'outside'
    outside.mkdir()
    payload = b'matching but not owned'
    (outside / 'data').write_bytes(payload)
    (store.root / 'linked').symlink_to(outside, target_is_directory=True)
    with pytest.raises(IntelError):
        store.read_verified('linked/data', hashlib.sha256(payload).hexdigest())


def test_valid_facts_survive_raw_damage_and_reimport_repairs_cache(tmp_path):
    from test_intel_storage import REV1, add, rows, store_for
    from patchtrace.intelligence.storage import FACTS_KIND, SOURCE_KIND
    from patchtrace.service import ProjectService

    with ProjectService.sample(tmp_path / 'real-project') as service:
        current = store_for(service)
        first = add(current, REV1)
        facts_path = service.root / 'intelligence/csaf/facts' / f'{first.facts.facts_id}.json'
        raw_path = service.root / first.source.raw_path
        exact_facts = facts_path.read_bytes()
        pointers_before = {entry.id: entry.body for kind in (SOURCE_KIND, FACTS_KIND) for entry in rows(service, kind)}
        raw_path.write_bytes(b'corrupt raw cache')
        cached, warnings = current.advisories()
        assert len(cached) == 1 and cached[0].facts == first.facts and warnings == []
        facts_path.write_bytes(b'corrupt normalized cache')
        assert current.advisories()[0] == []
        repaired = add(current, REV1)
        assert repaired.facts == first.facts
        assert raw_path.read_bytes() == REV1 and facts_path.read_bytes() == exact_facts
        assert {entry.id: entry.body for kind in (SOURCE_KIND, FACTS_KIND) for entry in rows(service, kind)} == pointers_before
        assert current.advisories()[1] == []
