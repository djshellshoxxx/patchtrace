from pathlib import Path
from datetime import UTC, datetime
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

root = Path('/workspace/scratch/c7a9e8d98848/advisory-bounds-review')
qa = Path('/workspace/scratch/c7a9e8d98848/qa/advisory-bounds-independent')
author = Path('/workspace/scratch/c7a9e8d98848/qa/advisory-bounds')
python = Path('/workspace/scratch/3a6632a6e5ff/venv/bin/python')
source = '06f5b210e5c6daffaae2b4d51fd8950c28be25c3'
tree = '564ce17da6e8d6fd9e15ad3b3fde16cd91f825bd'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == source
assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=root, text=True).strip() == tree
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True) == ''

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

# Retain the author evidence verbatim and label its independent provenance.
copied = []
for name in ('red.log', 'red.xml', 'affected.log', 'affected.xml', 'ruff.log', 'ruff-initial.log'):
    target = qa / f'author-{name}'
    shutil.copyfile(author / name, target)
    assert digest(target) == digest(author / name)
    copied.append({'original': str(author / name), 'copy': target.name, 'sha256': digest(target)})

selected = [f'tests/{name}.py' for name in ('test_advisory_read_bounds', 'test_intel_cli',
    'test_intel_explain', 'test_intel_storage', 'test_owned_publication', 'test_pilot_cli')]
commands = [
    {'name': 'affected', 'cwd': str(root),
     'env': {'QT_QPA_PLATFORM': 'offscreen', 'PYTHONPATH': str(root / 'src')},
     'argv': [str(python), '-m', 'pytest', '-q', *selected,
              f'--junitxml={qa / "affected.xml"}', '--tb=short'],
     'stdout_stderr': 'affected.log', 'exit_code': 0},
    {'name': 'external_and_backup', 'cwd': str(root),
     'env': {'QT_QPA_PLATFORM': 'offscreen', 'PYTHONPATH': f'{root / "src"}:{root / "tests"}'},
     'argv': [str(python), '-m', 'pytest', '-q', str(qa / 'test_advisory_bounds_review.py'),
              'tests/test_backup_sidecars.py', f'--junitxml={qa / "external.xml"}', '--tb=short'],
     'stdout_stderr': 'external.log', 'exit_code': 0},
]

def suite(path):
    cases = ET.parse(path).findall('.//testcase')
    result = {'tests': len(cases), 'failures': sum(c.find('failure') is not None for c in cases),
              'errors': sum(c.find('error') is not None for c in cases),
              'skipped': sum(c.find('skipped') is not None for c in cases)}
    return result

assert suite(qa / 'affected.xml') == {'tests': 140, 'failures': 0, 'errors': 0, 'skipped': 0}
assert suite(qa / 'external.xml') == {'tests': 16, 'failures': 0, 'errors': 0, 'skipped': 0}
assert suite(qa / 'author-red.xml') == {'tests': 9, 'failures': 7, 'errors': 0, 'skipped': 0}

sys.path.insert(0, str(root / 'src'))
from patchtrace import owned_publication
from patchtrace.intelligence import storage
assert Path(storage.__file__).resolve() == root / 'src/patchtrace/intelligence/storage.py'
assert Path(owned_publication.__file__).resolve() == root / 'src/patchtrace/owned_publication.py'

paths = ['src/patchtrace/intelligence/storage.py', 'src/patchtrace/owned_publication.py',
         'src/patchtrace/ingestion.py', 'src/patchtrace/intelligence/contracts.py',
         'tests/test_advisory_read_bounds.py', 'tests/test_backup_sidecars.py',
         'docs/specs/csaf-cve-interpretation-engine.md']
provenance = {
    'recorded_at_utc': datetime.now(UTC).isoformat(), 'source_commit': source, 'source_tree': tree,
    'baseline': '58fc130631f602b6e907bb054d30c21d810551d4',
    'spec_red_precursor': '7d0e8bac82c8624708932eaff723c246f878835c',
    'review_worktree': str(root), 'review_role': 'independent; no product source edits',
    'python': sys.version, 'executable': sys.executable, 'platform': platform.platform(),
    'import_paths': {'storage': storage.__file__, 'owned_publication': owned_publication.__file__},
    'source_files': [{'path': path, 'sha256': digest(root / path)} for path in paths],
    'commands': commands, 'results': {'affected': suite(qa / 'affected.xml'),
                                    'external_and_backup': suite(qa / 'external.xml'),
                                    'author_red': suite(qa / 'author-red.xml')},
    'author_copies': copied,
    'limits': [
        'Linux filesystem tests only; portable Windows native-call assertions are not native Windows evidence.',
        'No new lint execution by reviewer; author retained initial failure and final pass are copied verbatim.',
        'No total advisory-count/I/O or parsed-model-memory qualification.',
        'No general publication/replacement-race or pre-read selected-root anchoring claim.',
        'No exact-head full suite, frozen build, live advisory, native engine, target execution or manual GUI acceptance.',
        'Tests are distinct selections and controls, not a product-completion or security-accuracy percentage.'
    ]
}
(qa / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')

out = root / 'docs/qa/advisory-read-bounds-independent-20261118'
out.mkdir(parents=True)
artifacts = sorted(path for path in qa.iterdir() if path.is_file())
archive = out / 'raw-evidence.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for path in artifacts:
        bundle.write(path, path.name)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for path in artifacts:
        assert hashlib.sha256(bundle.read(path.name)).hexdigest() == digest(path)
manifest = {'source_commit': source, 'source_tree': tree, 'review_type': 'independent Linux read-budget review',
            'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': digest(archive)},
            'members': [{'path': path.name, 'bytes': path.stat().st_size, 'sha256': digest(path)} for path in artifacts]}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'archive': manifest['archive'], 'members': len(artifacts), 'results': provenance['results']}, indent=2))
