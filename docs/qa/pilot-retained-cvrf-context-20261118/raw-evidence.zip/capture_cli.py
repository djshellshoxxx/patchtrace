"""Retained production CLI dispatch on authored fixture stores; no target or network work."""
from __future__ import annotations

import contextlib
import io
import json
import os
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

REPO = Path('/workspace/scratch/c7a9e8d98848/cvrf-pilot')
QA = Path(__file__).resolve().parent
SOURCE = '353902677e6d59961e808a90b2a3dd96d2b43269'
CVE = 'CVE-2099-20001'
sys.path[:0] = [str(REPO / 'src'), str(REPO / 'tests')]
os.environ['XDG_DATA_HOME'] = str(QA / 'journey-data')
os.environ['XDG_CACHE_HOME'] = str(QA / 'journey-cache')
os.environ['LOCALAPPDATA'] = str(QA / 'journey-data')

from kbc_k3_support import Kb
from kbc_k4a_support import analysed_project


class Capture:
    def __init__(self):
        self.out, self.err = io.StringIO(), io.StringIO()

    def readouterr(self):
        result = SimpleNamespace(out=self.out.getvalue(), err=self.err.getvalue())
        for stream in (self.out, self.err):
            stream.seek(0)
            stream.truncate()
        return result


CHILD = '''import importlib.abc, sys
class NoQt(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.startswith(('PySide6','shiboken6','patchtrace.ui')):
            raise AssertionError('headless CLI imported UI: '+fullname)
sys.meta_path.insert(0,NoQt())
from patchtrace import cli
import socket, subprocess
def denied(*a, **k): raise AssertionError('receipt attempted network or nested external execution')
socket.socket=socket.create_connection=socket.getaddrinfo=denied
subprocess.Popen=denied
raise SystemExit(cli.main(sys.argv[1:]))
'''


def run(name, args):
    command = [sys.executable, '-c', CHILD, *args]
    result = subprocess.run(command, cwd=REPO, env={**os.environ, 'PYTHONPATH': str(REPO / 'src')},
                            text=True, capture_output=True, timeout=30)
    (QA / (name + '.json')).write_text(result.stdout)
    (QA / (name + '.stderr')).write_text(result.stderr)
    assert result.returncode == 0, result.stderr + result.stdout
    return json.loads(result.stdout), {'name': name, 'args': args, 'exit_code': result.returncode,
                                      'headless_guard': True, 'network_and_nested_process_guard': True}


assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == SOURCE
scratch = QA / 'journey'
project = scratch / 'P'
if not scratch.exists():
    scratch.mkdir()
    capture = Capture()
    with contextlib.redirect_stdout(capture.out), contextlib.redirect_stderr(capture.err):
        project = analysed_project(Kb(scratch, capture), scratch, capture)
leads, lead_receipt = run('cli-leads', ['pilot', 'leads', str(project), '--cve', CVE, '--json'])
result = leads['result']
assert result['stored'] and result['cves'][0]['gate'] == 'unverified'
candidate = next(row for row in result['leads'] if row['cve'] == CVE)['candidate_key']
why, why_receipt = run('cli-why', ['pilot', 'why', str(project), '--candidate', candidate,
                                 '--cve', CVE, '--json'])
receipt = {'source_commit': SOURCE, 'level': 'authored real-store integration; no native/provider acceptance',
           'project': str(project), 'result_id': result['result_id'], 'cve': CVE,
           'gate': result['cves'][0]['gate'],
           'leads': len(result['leads']), 'commands': [lead_receipt, why_receipt],
           'displayed_scope_notes': [line for row in why['result']['leads'] for line in row['why']
                                     if 'not reverified' in line or 'do not establish' in line],
           'why_document': 'cli-why.json'}
assert any('not reverified' in line for line in receipt['displayed_scope_notes'])
(QA / 'cli-journey-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'source': SOURCE, 'result_id': result['result_id'], 'gate': receipt['gate'],
                  'lead_count': receipt['leads'], 'commands': len(receipt['commands'])}))
