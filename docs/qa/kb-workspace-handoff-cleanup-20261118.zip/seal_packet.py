"""Seal the independent final-handoff finding and append-only source correction."""
from __future__ import annotations

import ast
import copy
from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path
import platform
import shutil
import sqlite3
import subprocess
import sys
import zipfile

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
QA = Path(__file__).resolve().parent
INITIAL = 'c470a31acec624410a0412e7c803cc38732235a9'
OLD_QA = 'd31c524ab2bdf119a1172de926569a3b8ece6b3b'
SPEC = 'edf4f3ba605eca51e3c7402781b56101e2ba3950'
SOURCE = 'a7a4fb1625a0ed89cbd0cb5f54574345caa1fe8e'
STORE = 'src/patchtrace/kbcorrelation/store.py'
TEST = 'tests/test_kbc_workspace_handoff_cleanup.py'
SPEC_PATH = 'docs/specs/program-e/KB-integration-plan.md'
PRIOR = QA.parent / 'workspace-handoff-independent'


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def write(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as handle:
        handle.write(raw)


def dump(path, value):
    write(path, (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode())


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('status', '--porcelain', '--untracked-files=no').strip()
assert shutil.disk_usage(ROOT).free > 100 * 1024**2
old_tree = ast.parse(git('show', INITIAL + ':' + STORE).decode())
new_tree = ast.parse(git('show', SOURCE + ':' + STORE).decode())
old_cls = next(n for n in old_tree.body if isinstance(n, ast.ClassDef) and n.name == 'WorkspaceStore')
new_cls = next(n for n in new_tree.body if isinstance(n, ast.ClassDef) and n.name == 'WorkspaceStore')
old_methods = {n.name: n for n in old_cls.body if isinstance(n, ast.FunctionDef)}
new_methods = {n.name: n for n in new_cls.body if isinstance(n, ast.FunctionDef)}
expected = copy.deepcopy(old_methods['_open_existing'])
assignment = expected.body.pop()
assert isinstance(assignment, ast.Assign) and ast.unparse(assignment) == 'self.db = db'
assert isinstance(expected.body[-1], ast.Try)
expected.body[-1].body.append(assignment)
assert ast.dump(expected) == ast.dump(new_methods['_open_existing'])
unchanged = []
for name, old in old_methods.items():
    if name != '_open_existing':
        assert ast.dump(old) == ast.dump(new_methods[name]), name
        unchanged.append(name)
assert set(old_methods) == set(new_methods)
numstat = git('diff', '--numstat', INITIAL, SOURCE, '--', 'src').decode().strip()
assert numstat == '1\t1\t' + STORE
for path in (TEST, SPEC_PATH):
    assert git('show', SPEC + ':' + path) == git('show', SOURCE + ':' + path)
old_test = 'tests/test_kbc_workspace_open_mode.py'
assert git('show', INITIAL + ':' + old_test) == git('show', SOURCE + ':' + old_test)
write(QA / 'source.diff', git('diff', INITIAL, SOURCE, '--', STORE))
write(QA / 'spec-tests.diff', git('diff', OLD_QA, SPEC, '--', TEST, SPEC_PATH))
dump(QA / 'source-proof.json', {'original_source': INITIAL, 'original_qa': OLD_QA,
    'spec_tests': SPEC, 'source': SOURCE, 'tree': git('rev-parse', SOURCE + '^{tree}').decode().strip(),
    'only_production_change_numstat': numstat, 'single_assignment_move_ast_equal': True,
    'other_workspace_methods_unchanged': sorted(unchanged),
    'original_46_control_file_unchanged': True, 'new_tests_and_spec_unchanged_since_red': True})

snapshots = {}
for label in ('spec-red', 'affected-green'):
    receipt = json.loads((QA / (label + '.imports.json')).read_bytes())
    assert not receipt['drift']
    for item in receipt['modules']:
        snapshots[(receipt['source'], item['path'])] = item
for commit, path in ((INITIAL, STORE), (SPEC, SPEC_PATH), (SOURCE, SPEC_PATH)):
    snapshots.setdefault((commit, path), None)
source_records = []
for (commit, path), expected_import in sorted(snapshots.items()):
    raw = git('show', commit + ':' + path)
    blob = git('rev-parse', commit + ':' + path).decode().strip()
    if expected_import:
        assert expected_import['git_blob'] == expected_import['expected_blob'] == blob
        assert expected_import['sha256'] == sha(raw)
    member = 'source/' + commit + '/' + path
    write(QA / member, raw)
    source_records.append({'commit': commit, 'path': path, 'member': member, 'git_blob': blob,
                           'sha256': sha(raw), 'bytes': len(raw)})
dump(QA / 'source-manifest.json', source_records)

original_probe = PRIOR / 'test_workspace_handoff_interrupt.py'
assert sha(original_probe.read_bytes()) == 'f1df7f0522d815bd9be70beaf703d50f22b8daa7e9bd370051976ceb1f3177c0'
prior_paths = [PRIOR / name for name in ('test_workspace_handoff_interrupt.py', 'command.json', 'exit.json',
    'imports.json', 'offline-guard.json', 'red.log', 'red.xml')]
prior_paths.extend(PRIOR / 'observations' / name for name in ('interrupt.json', 'exit.json', 'none.json'))
prior_records = []
for path in prior_paths:
    raw = path.read_bytes()
    member = 'root-original/' + path.relative_to(PRIOR).as_posix()
    write(QA / member, raw)
    prior_records.append({'path': str(path), 'member': member, 'sha256': sha(raw), 'bytes': len(raw)})
runner = QA.parent.parent / 'ops/run_workspace_handoff_probe.py'
write(QA / 'root-original/run_workspace_handoff_probe.py', runner.read_bytes())
dump(QA / 'root-original.json', {'files': prior_records, 'runner_path': str(runner),
                                'runner_sha256': sha(runner.read_bytes())})

old_stem = 'docs/qa/kb-workspace-existing-open-20261118'
for suffix, name in (('.zip', 'evidence.zip'), ('.manifest.json', 'manifest.json'), ('.md', 'README.md')):
    raw = git('show', OLD_QA + ':' + old_stem + suffix)
    assert (ROOT / (old_stem + suffix)).read_bytes() == raw
    if suffix == '.zip':
        assert sha(raw) == 'e41b28255cf86d3edc8c2dcbd47305cf65288c826e58164f560bb15f960bf13e'
    write(QA / 'original-c470' / name, raw)
assert (QA / 'run_gate.py').read_bytes() == (QA.parent / 'kb-workspace-existing-open/run_gate.py').read_bytes()
dump(QA / 'environment.json', {'python': sys.version, 'executable': sys.executable,
    'platform': platform.platform(), 'sqlite': sqlite3.sqlite_version, 'observed_utc': datetime.now(UTC).isoformat()})

excluded = {QA / name for name in ('manifest.json', 'evidence.zip', 'seal-receipt.json')}
members = []
for path in sorted(QA.rglob('*')):
    if path.is_file() and path not in excluded:
        raw = path.read_bytes()
        members.append({'path': path.relative_to(QA).as_posix(), 'bytes': len(raw), 'sha256': sha(raw)})
manifest = {'format': 'patchtrace-evidence/1', 'original_source': INITIAL, 'original_qa': OLD_QA,
    'spec_tests': SPEC, 'source': SOURCE, 'source_tree': git('rev-parse', SOURCE + '^{tree}').decode().strip(),
    'payload_count': len(members), 'git_snapshot_count': len(source_records), 'members': members}
dump(QA / 'manifest.json', manifest)
with zipfile.ZipFile(QA / 'evidence.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name in [item['path'] for item in members] + ['manifest.json']:
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, (QA / name).read_bytes())
with zipfile.ZipFile(QA / 'evidence.zip') as archive:
    assert len(archive.namelist()) == len(members) + 1
    assert archive.read('manifest.json') == (QA / 'manifest.json').read_bytes()
    for item in members:
        raw = archive.read(item['path'])
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
result = {'source': SOURCE, 'payload_count': len(members), 'archive_members': len(members) + 1,
    'git_snapshots': len(source_records), 'archive_bytes': (QA / 'evidence.zip').stat().st_size,
    'archive_sha256': sha((QA / 'evidence.zip').read_bytes()),
    'manifest_sha256': sha((QA / 'manifest.json').read_bytes()), 'verified_all_members': True}
dump(QA / 'seal-receipt.json', result)
print(json.dumps(result, indent=2))
