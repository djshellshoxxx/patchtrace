"""Interrupt the actual final connection handoff; real SQLite, no external process."""
from __future__ import annotations

import ast
import inspect
import json
import os
from pathlib import Path
import sqlite3
import sys

import pytest

from patchtrace.kbcorrelation.store import WorkspaceStore


def _record(name, data):
    out = Path(os.environ['PATCHTRACE_WORKSPACE_HANDOFF_OBSERVATIONS'])
    out.mkdir(exist_ok=True)
    (out / (name + '.json')).write_text(json.dumps(data, indent=2) + '\n')


@pytest.mark.parametrize('stop', ['interrupt', 'exit', 'none'])
def test_existing_connection_is_owned_through_final_handoff(tmp_path, monkeypatch, stop):
    root = tmp_path / 'workspace'
    with WorkspaceStore(root) as store:
        store.journal_put('retained', 'intent', {'analyst': 'keep'})
    original = (root / 'kbc.sqlite3').read_bytes()
    connect = sqlite3.connect
    acquired = []

    class TrackedConnection(sqlite3.Connection):
        close_calls = 0

        def close(self):
            self.close_calls += 1
            return super().close()

    def observed(*args, **kwargs):
        db = connect(*args, factory=TrackedConnection, **kwargs)
        acquired.append(db)
        return db

    monkeypatch.setattr(sqlite3, 'connect', observed)
    function = WorkspaceStore._open_existing
    source = Path(inspect.getsourcefile(function))
    tree = ast.parse(source.read_text())
    owner = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'WorkspaceStore')
    method = next(n for n in owner.body if isinstance(n, ast.FunctionDef) and n.name == '_open_existing')
    assignments = [n for n in ast.walk(method) if isinstance(n, ast.Assign) and any(
        isinstance(t, ast.Attribute) and isinstance(t.value, ast.Name)
        and t.value.id == 'self' and t.attr == 'db' for t in n.targets)]
    assert len(assignments) == 1
    handoff_line = assignments[0].lineno
    primary = KeyboardInterrupt('authored handoff interrupt') if stop == 'interrupt' else SystemExit(23)
    fired = False

    def trace(frame, event, arg):
        nonlocal fired
        if frame.f_code is not function.__code__:
            return None
        if event == 'line' and frame.f_lineno == handoff_line and stop != 'none' and not fired:
            fired = True
            raise primary
        return trace

    previous = sys.gettrace()
    assert previous is None
    returned = None
    caught = None
    try:
        sys.settrace(trace)
        try:
            returned = WorkspaceStore(root, open_mode='existing')
        except BaseException as exc:
            caught = exc
        finally:
            sys.settrace(previous)
        assert len(acquired) == 1
        db = acquired[0]
        if stop == 'none':
            assert caught is None and returned is not None
            assert returned.journal_get('retained') == ('intent', {'analyst': 'keep'})
            returned.close()
        readable = True
        try:
            db.execute('SELECT 1').fetchone()
        except sqlite3.ProgrammingError:
            readable = False
        _record(stop, dict(trace_fired=fired, primary_identity=(caught is primary),
            close_calls_before_test_cleanup=db.close_calls, connection_readable_before_test_cleanup=readable,
            retained_database_bytes_unchanged=(root / 'kbc.sqlite3').read_bytes() == original))
        if stop != 'none':
            assert fired and caught is primary
        assert db.close_calls == 1, 'owned connection escaped cleanup at its final handoff'
        assert not readable
        assert (root / 'kbc.sqlite3').read_bytes() == original
    finally:
        sys.settrace(previous)
        for db in acquired:
            sqlite3.Connection.close(db)
