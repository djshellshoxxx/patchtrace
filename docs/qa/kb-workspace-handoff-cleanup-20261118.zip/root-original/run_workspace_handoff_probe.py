"""Preserve one exact-source final-handoff interruption probe under the offline guard."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'semantic-disposition-batch4'
OUT = ROOT / 'qa/workspace-handoff-independent'
SOURCE = 'c470a31acec624410a0412e7c803cc38732235a9'
TEST = OUT / 'test_workspace_handoff_interrupt.py'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(name, payload):
    with (OUT / name).open('x') as f:
        json.dump(payload, f, indent=2)
        f.write('\n')


head = git('rev-parse', 'HEAD').decode().strip()
assert not git('diff', SOURCE, head, '--', 'src', 'tests', 'tools', 'docs/specs', 'pyproject.toml')
assert not git('status', '--porcelain')
owned = Path(tempfile.mkdtemp(prefix='patchtrace-workspace-handoff-red-'))
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', QT_QPA_PLATFORM='offscreen',
    PYTHONPATH=os.pathsep.join(map(str, [REPO / 'src', REPO / 'tests', REPO, ROOT / 'ops'])),
    GIT_ALLOW_PROTOCOL='file', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null', GIT_TERMINAL_PROMPT='0',
    PATCHTRACE_WORKSPACE_HANDOFF_OBSERVATIONS=str(OUT / 'observations'),
    PATCHTRACE_BATCH_COLLECTION_RECEIPT=str(OUT / 'imports.json'),
    PATCHTRACE_OFFLINE_GUARD_RECEIPT=str(OUT / 'offline-guard.json'))
argv = [sys.executable, str(ROOT / 'ops/continuation_offline_pytest.py'), '-q', '-ra',
    '-p', 'no:cacheprovider', '-p', 'project_and_tools_receipt', str(TEST),
    '--basetemp=' + str(owned / 'pytest'), '--junitxml=' + str(OUT / 'red.xml')]
write('command.json', dict(source=SOURCE, checkout_head=head, argv=argv, cwd=str(REPO),
    pythonpath=env['PYTHONPATH'], test_sha256=sha(TEST), helper_sha256=sha(__file__),
    owned_temp=str(owned), started_utc=datetime.now(timezone.utc).isoformat(), timeout=120))
with (OUT / 'red.log').open('x') as f:
    result = subprocess.run(argv, cwd=REPO, env=env, stdout=f, stderr=subprocess.STDOUT, timeout=120)
collection = json.loads((OUT / 'imports.json').read_text())
drift = []
for name, row in collection['final_sources'].items():
    path = Path(row['path'])
    if not path.is_relative_to(REPO):
        drift.append(name)
    else:
        raw = git('show', SOURCE + ':' + path.relative_to(REPO).as_posix())
        if sha(path) != hashlib.sha256(raw).hexdigest() or row['sha256'] != sha(path):
            drift.append(name)
cases = list(ET.parse(OUT / 'red.xml').getroot().iter('testcase'))
counts = dict(tests=len(cases), failures=sum(c.find('failure') is not None for c in cases),
    errors=sum(c.find('error') is not None for c in cases), skipped=sum(c.find('skipped') is not None for c in cases))
after = git('rev-parse', 'HEAD').decode().strip()
assert not git('diff', SOURCE, after, '--', 'src', 'tests', 'tools', 'docs/specs', 'pyproject.toml')
assert not drift and not git('status', '--porcelain')
receipt = dict(source=SOURCE, checkout_head_after=after, exit=result.returncode, junit=counts,
    canonical_imports=len(collection['final_sources']), drift=drift, test_sha256=sha(TEST),
    owned_temp_retained=str(owned))
write('exit.json', receipt)
print(json.dumps(receipt))
print('\n'.join((OUT / 'red.log').read_text().splitlines()[-18:]))
raise SystemExit(result.returncode)
