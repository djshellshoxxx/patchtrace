"""Authored stored-record integrity probe; no network or target execution.

Run from the chosen PatchTrace worktree with PYTHONPATH=src:tests. The fixture
drops the append-only UPDATE trigger only in its disposable authored database
to represent a changed stored body; no real workspace is opened or modified.
"""
import json
import subprocess
import tempfile
from pathlib import Path

import test_kbc_inventory_selection as controls

from patchtrace.kbcorrelation.inventory_selection import _decisions
from patchtrace.kbcorrelation.store import WorkspaceStore

record = {'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip()}
with tempfile.TemporaryDirectory(prefix='patchtrace-inventory-review-') as directory:
    root = Path(directory)
    service = controls.service(root)
    state = controls.start(service)
    identity = controls.inventory(service, root)
    controls.select(service, state, identity)
    with WorkspaceStore(service.root) as store:
        before = store.current_revision(state[0])
        sequence, body = store.db.execute('SELECT seq,body FROM decisions WHERE investigation_id=?',
                                         (state[0],)).fetchone()
        record['before'] = {'revision': before.revision, 'state': before.state,
                            'inventory_decisions': len(_decisions(store, state[0]))}
        store.db.execute('DROP TRIGGER decisions_update')
        store.db.execute('UPDATE decisions SET body=? WHERE seq=?',
                         (json.dumps(json.loads(body), indent=2), sequence))
        record['same_json_reformatted'] = {
            'inventory_decisions': len(_decisions(store, state[0])),
            'ordinary_reader_ops': [decision.op for decision in store.decisions(state[0])],
        }
    outcome = service.components(state[0], product=state[1], files=[])
    with WorkspaceStore(service.root) as store:
        after = store.current_revision(state[0])
    record['components'] = {'exit': outcome.exit, 'hints': len(outcome.result['hints']),
                            'revision': after.revision, 'state': after.state}
print(json.dumps(record, indent=2))
