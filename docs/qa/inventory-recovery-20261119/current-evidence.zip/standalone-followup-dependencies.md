# Bounded follow-up dependencies: PR #314 and PR #307

**Status:** static dependency recommendation only. No tests were run for this follow-up. No remote branch was mutated. Source commits and original failure records remain intact.

## Source pins

| Role | Commit |
|---|---|
| main | `9c411ca3d7b47f950be5f0c6f01b3c54184554c6` |
| foundation_317 | `88b0b52281dd314aa72f93819145a73135618bc4` |
| broad_316 | `f2b6827fc6270b96fb241b0722f2878de5a17361` |
| raw_search_code | `7daebd699ed942d9a7982bcb72f648e8843cb5f4` |
| raw_search_evidence | `25d2949340f507d3bc06c9aaf73989db9a790093` |

## PR #314: bounded candidate after #313

Original PR head `b41d6631e679ad2777d248fa087ea71582a5bf63`, own commit range after `a4061979547ef88855fbdb085228a42c3be21603`. The 19 own commits include 13 source/spec/test commits and 6 historical QA/help commits. The six runtime implementation commits touch pilot collection, current-input capture, storage admission, Leads, and report adapters; retained CVRF parsing is a new pilot source adapter.

Inspected imports and call sites do not depend on the #307 inventory UI, inventory parser/store, native research adapters, or package work. The new adapter consumes `ContextBundle`, `context_key`, `card_provenance.FIELDS`, `fact_key`, and `IntelligenceRules` already present at #317. The card provenance and wiring module blobs are identical between #317 and #314. Context construction differs because #317 contains the later finite saved-scope repair; preserve that repair. #314 must not replace context.py with its older branch version.

The advisory storage difference between #317 and #314 is the #313 bounded reader repair, including the 64 MiB sidecar cap, owned reading, and source.size-bound fallback. Keep the already reviewed #313 port as the preceding qualification layer. The #314 new source adapter itself reads retained enrichment rows and source-bound CVRF card fields; it does not import inventory types.

### Recommended source/spec/test replay order

| Original commit | Purpose |
|---|---|
| `f3cf68dbfecd254e5e5acefb02f82922f4091bf5` | test(pilot): specify current assessment ownership and staleness [no release] |
| `328a3a363cfe6ffe2334eccfab71c72dc456eea7` | fix(pilot): recheck assessment ownership and current evidence [no release] |
| `8ace1999ff6e83369963e0c3bc9690f7f16ff2f9` | test(report): require current pilot evidence at export [no release] |
| `c3a09b43175bcd023596c1dcd7c083be5d5434b9` | fix(report): share pilot current-evidence checks [no release] |
| `8291396f92a1b577027270c88c43c90bcdc393c9` | spec(pilot): define retained CVRF fallback and refusal controls [no release] |
| `35a0dd44dedb56019d9fc93ee652c692b12a2b0a` | feat(pilot): consume bounded retained CVRF context with CSAF precedence [no release] |
| `4c231c558c6fe4ea62dfc0df98454e109ce19b02` | spec(pilot): refuse malformed retained SQLite row types [no release] |
| `870287f2f54fbf9e5715cc256ea5a98ea2646319` | fix(pilot): withhold malformed retained SQLite primitives [no release] |
| `2b197589da370be204499c02c69b4545d115527f` | test(pilot): require retained CVRF identities on current assessment reads [no release] |
| `dfa0be3f4c99dcae8ff16bd6635d4b89114c0565` | test(pilot): persist context withdrawal for independent child reads [no release] |
| `d1a7998ac520d1a77eef09303d1e83e3d2eadde2` | fix(pilot): compare retained CVRF identity in current assessment capture [no release] |
| `c6723e64cffb5210eafd2ec449baff82a088d4c8` | spec(pilot): cap all retained context fields before loading [no release] |
| `402d47eeedb3628ed22ad9aa18d5c2d2cdafd03c` | fix(pilot): include retained row metadata in capture budget [no release] |

### Corrections after the original #314 head

| Commit | Required treatment |
|---|---|
| `fbd47d097a9fdf6ba22a023ab2ba5fe0fb08a373` | Required staging ownership regression and specification |
| `028a67abc5c1a48ef27f9d218179ce095bead798` | Required staging ownership repair |
| `77fc8ea0bd58d9536cfb5cae848c2ac5e177772b` | Historical failed/green staging evidence |
| `23d99f93f8b35c8d9a3c71f349bd1915dc25fe85` | Historical independent staging review |
| `a07fc1cf1c8d618d8d4b451888c286815a4e02de` | Extract only tests/test_pilot_kb_context.py coverage fixture hunk; remaining files have other owners |

The staging repair moves `staged.mkdir(parents=True)` before the cleanup-owning try block. Failed creation therefore does not claim or remove an occupied staging path. Keep the accompanying ownership regression test and specification. The fixture correction supplies `coverage=(index.coverage(now=NOW),)` to the synthetic CVRF bundle so it satisfies #317 finite saved-scope admission. It does not loosen production validation.

Historical #314 review records report 1,924 affected tests passing on their old combined source and explicitly leave native Windows, full application gates, and packages unverified. These are preserved source receipts, not results for the new stable candidate. New candidate qualification must cover pilot/Leads/report2 current evidence, malformed retained SQLite primitives, metadata budgets, staging ownership, Qt repeat behavior, and platform gates.

### Historical evidence and help commits

| Commit | Record |
|---|---|
| `0143fe1a3da6d5e98de1888314ac0da67426b183` | docs(qa): retain pilot current-evidence red and green receipts [no release] |
| `9ba2719244f807b2e1149dd63bb5ce062c2758ce` | docs(qa): retain CVRF pilot bridge failures and exact-source qualification [no release] |
| `2aa98a049c45ba78904c449dd2e0c0c9b400575f` | docs(qa): retain combined CVRF freshness checkpoint and open bridge findings [no release] |
| `af8bcb23abb3aee7e63086c0fbc788b85c7f1aaf` | docs(qa): retain CVRF storage-class regression and repair evidence [no release] |
| `3bc85183d87a893d6f592d5f509b43a50f1349b2` | docs(qa): retain complete-row CVRF budget qualification [no release] |
| `b41d6631e679ad2777d248fa087ea71582a5bf63` | Record combined CVRF review, defect evidence and analyst help [no release] |

Copy historical evidence paths byte-for-byte where possible. Merge append-only QA/todo/module records and analyst help deliberately; do not overwrite later candidate outcomes.

## PR #307: separate integration candidate

Original head `58fc130631f602b6e907bb054d30c21d810551d4` has 49 nonmerge commits beyond #304 `d8c02caea407f6d323eecd636735849c1eb31a2d` and changes 222 files. A whole-branch merge brings inventory product work together with native research fixes and historical qualification documents. It needs a separately reviewed extraction before adding it to the stable candidate.

The inventory feature is a coherent multi-module workflow: bounded CSV contracts/parser, retained support pages, explicit retrieval consent, immutable storage, scoped selection replay, CLI, Qt dialog, provenance schemas, drift refusal, and publication ownership. Cherry-picking just the UI would leave required source admission and persistence behavior behind.

### Required corrections for an eventual inventory port

| Commit | Reason |
|---|---|
| `fea6d6efbe07eb864a3bce98407cef6802f61633` | Tests/spec require finite saved coverage preflight before inventory selection publication. |
| `d909ec5b7b2c65efaa50384215027c7e4dfaa753` | Pass the loaded reverse index and unreadable source set through `_stored_scope`, preserving #317 refusal behavior. |
| `a07fc1cf1c8d618d8d4b451888c286815a4e02de` | Reconcile only inventory-owned fixture hunks; other hunks have separate owners. |

Do not replace #317 saved-scope code with the pre-repair inventory branch. The later broader finite-scope commit `e9c29800228294894a41c7aa6ffe0e3397856c11` overlaps #317 repairs and should be reconciled by behavior, not replayed indiscriminately.

Publication commit `e5c75e24882ac62cda798883bddb5c11150989d5` changes `inventory_store.py` and `store.py`, introduces a 505-line shared `owned_publication.py`, updates Windows QA, and moves research `winpairs.py` onto that boundary. Its proof commit is `4b12c5e547bb1abb6a255389a42c159e348581f7`. The #313 port already recovered the full helper and `test_owned_publication.py` byte-for-byte from #307 via `91175f49476fabba50a45de8da8b5667548cd398`; it uses only `read_bytes`. The security worker confirmed that KB store/inventory_store/winpairs caller rewiring and #307 Windows QA changes were not included. Reuse that dependency rather than duplicating it, and review the remaining callers and ownership boundary separately. Portable checks cannot qualify the native Windows boundary.

The later held-input and workspace-admission sequence changes shared service/store/wiring and contracts: `a753328d510960152f865ac24ba4ab147cc71a01`, `3eb5e39f44786fb04d5cb58f32400095db8218c6`, `23715126557cee78890f6f074392ea56f03a5147`, `b837f6dcbeb3a58a04c0726b10aeb787da22b130`, `bbbd6f23bfad32b56f5ddd857eb14ea9a26f8486`. Those are separate security/admission work, not permission to expand this bounded port silently.

Retain the native research commits separately: linked-worktree receipt identity `0f63e0dcb6b53ef4b57550b183b42f80f376eaa8`; Rizin ambiguity/orphan guards `9934e0278ab509107f905f24293a4ce403ddaf06` and `2b4fbd50e1136a876ffba865cbad86eb6b018627`; Ghidriff ranking ambiguity guard `740f69a785af908dc605862cc13e9c910a4b866a`. Their source and failed/limited qualification receipts remain useful research evidence.

## Related completed work

Raw/search source recovery is at `7daebd699ed942d9a7982bcb72f648e8843cb5f4`; its historical and fresh evidence commit is `25d2949340f507d3bc06c9aaf73989db9a790093`. Fresh affected run remains 1,060 passed / 1 unchanged host timing failure. Same isolated threshold also failed on untouched #317. The attempted 20x Qt repeat remains BLOCKED/ABORTED with its original log retained. No threshold was relaxed and no aborted repeat is counted as a pass.

The full 317-branch inventory, patch-equivalence records, conflicts, PR gates, and historical semantic review mapping are in `branch-consolidation-inventory.md` and the JSON files listed there. This follow-up does not change their coverage or authorize branch deletion.
