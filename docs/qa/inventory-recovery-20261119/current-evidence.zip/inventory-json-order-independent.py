"""Version-pinned SQLite order probe using authored actual service workflows."""
from __future__ import annotations

import ast
import json
import socket
import sqlite3
import subprocess
import sys
import tempfile
from pathlib import Path

import test_kbc_inventory_decision_compatibility as compatibility
import test_kbc_inventory_selection as setup

from patchtrace.kbcorrelation import inventory_selection as selection
from patchtrace.kbcorrelation.contracts import AnalystDecision, SourceRef
from patchtrace.kbcorrelation.store import WorkspaceStore


def refuse(*args, **kwargs):
    raise AssertionError('independent inventory order probe must stay offline')


socket.socket = socket.create_connection = socket.getaddrinfo = refuse
tree = ast.parse(Path(selection.__file__).read_text())
reader = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == '_decisions')
query = next(node.args[0].value for node in ast.walk(reader)
             if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute)
             and node.func.attr == 'execute' and isinstance(node.args[0], ast.Constant))
record = {'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'python': sys.version, 'sqlite': sqlite3.sqlite_version, 'cases': []}

for reverse in (False, True):
    for temp_store in (1, 2):
        for refs_first in (False, True):
            with tempfile.TemporaryDirectory(prefix='inventory-order-review-') as directory:
                root = Path(directory)
                svc = setup.service(root, doc=setup.document(builds=('10.0.26100.9001',) * 80))
                state = setup.start(svc)
                identity = setup.inventory(svc, root)
                chosen = setup.select(svc, state, identity)

                def configure(ws):
                    ws.db.execute(f'PRAGMA reverse_unordered_selects={int(reverse)}')
                    ws.db.execute(f'PRAGMA temp_store={temp_store}')
                    return ws

                with WorkspaceStore(svc.root) as ws:
                    source = next(item for item in ws.sources() if item.kind == 'cvrf-month')
                    refs = tuple(SourceRef(doc_id=source.doc_id, pointer=f'/vulnerabilities/{index}/title',
                                           assertion='advisory_fact') for index in range(80))
                    decision = AnalystDecision(op='review-sources', prior='pending', next='reviewed',
                                               reason='Authored order compatibility control.',
                                               created_at=setup.NOW, refs=refs)
                    fields = decision.model_dump(mode='json')
                    if refs_first:
                        fields = {'refs': [dict(reversed(tuple(ref.items()))) for ref in fields['refs']],
                                  **{key: value for key, value in fields.items() if key != 'refs'}}
                    body = json.dumps(fields, separators=(',', ':')).replace('"op":', '"o\\u0070":')
                    assert len(body.encode('utf-8')) > 8192
                    assert AnalystDecision.model_validate_json(body) == decision
                    ws.db.execute('INSERT INTO decisions(investigation_id,body) VALUES (?,?)', (state[0], body))
                    configure(ws)
                    params = (selection.MAX_SELECTION_BODY_BYTES, selection.MAX_DECISION_SCALAR_BYTES, state[0])
                    plan = [list(row) for row in ws.db.execute('EXPLAIN QUERY PLAN ' + query, params)]
                    ids = {}
                    for row in ws.db.execute(query, params):
                        ids.setdefault(row[0], []).append(row[2])
                    ordered = all(nodes == sorted(nodes) for nodes in ids.values())
                    assert ordered

                real_open = svc._open
                svc._open = lambda **kwargs: configure(real_open(**kwargs))
                compatibility._assert_successful_replay(svc, state, identity, chosen)
                record['cases'].append({'reverse_unordered_selects': reverse, 'temp_store': temp_store,
                                        'refs_first_and_reversed_ref_keys': refs_first,
                                        'body_bytes': len(body.encode('utf-8')),
                                        'nodes_per_decision': [len(nodes) for nodes in ids.values()],
                                        'node_ids_increasing': ordered,
                                        'actual_components_and_idempotent_selection': 'PASS', 'plan': plan})

print(json.dumps(record, indent=2))
