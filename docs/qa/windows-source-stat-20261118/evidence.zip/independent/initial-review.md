# Initial independent Windows source-stat review

## Disposition

Review source is `f8c8877bbf4f7d551fe572f706f725c08f8e2734`, tree
`cd401c7edbe9126d42e515452c2c077705814744`. Its production guard is byte-identical
to `ada5290087934e34fea53649222a6eee054e052f`; the final commit only orders test
imports. The source worktree remained clean and its recorded files unchanged
through all four independent runs. No reviewer product edits were made.

The cross-API compatibility rationale is supported by the retained CPython
v3.12.10 source. However, two reproduced boundaries require the author's
follow-up before this source can be accepted for its intended Windows workflow:

1. The final all-files check can accept bytes changed after their hashing pass.
2. The dependency scanner's receipt reader still rejects valid Windows path/fd
   observations for unchanged files.

Both are confirmed with real inert files and modeled documented implementation
semantics. They are **not native Windows executions**. The particular hosted job's
offending fields remain unobserved, and these controls supply no package, native
engine, dependency-audit or release qualification.

## Finding 1: final Windows pathname check loses ChangeTime

`tools/release_qualification.py:527` returns only the pathname's six-field
`source_state`. The explicit all-files verification at lines 567–568 compares
another pathname state with that snapshot. CPython Windows pathname `ctime`
contains creation time, while descriptor `ctime` contains metadata ChangeTime.
After the hashed descriptor closes, an in-place rewrite with the same size and
restored modification time leaves that final pathname comparison unchanged.

`test_final_source_write_external.py` creates a real local Git repository with
an inert tracked `.CMD` file; nothing executes that file. It calls the actual
reviewed `checked_source`, using real Git canonical metadata and actual file
reads. Immediately after `source_blob` returns, the test rewrites the same inode
with different, equal-length bytes and restores its modification time. It asserts
that actual descriptor ChangeTime changed. Only the path/fd stat representation
is adapted to the retained CPython semantics.

`final-write-red` records **1 failure / 2 positives, 0.25 seconds**. Changed bytes
are accepted under the modeled Windows observations. The same mutation is refused
under actual POSIX observations; unchanged Windows observations pass. The final
authored Git object and changed file bytes are retained in
`late-write-observations.json`.

The peer independently reached the same result first using authored canonical
Git command replies and actual bytes. Its unchanged probe, exact guard snapshot,
provenance and **1-failure / 2-positive** receipt are in `peer-original/`.

This is an adjacent final-verification gap, not a claim that the small cross-view
patch introduced the pathname-ctime semantics. The author has agreed to retain
an immutable descriptor observation and perform a bounded final reopen for each
Windows regular file. Both `checked_source` and the dependency scanner's
`checked_tree` consume this snapshot and need the same final check. Holding all
tracked descriptors open at once is unnecessary. Any repaired check still has
its ordinary observation lifetime; it does not freeze source files after return.

## Finding 2: unchanged dependency receipt falsely rejected

`tools/dependency_security.py:78` and `:81` compare full descriptor state directly
with the original pathname state. `read_json` and `digest` both use this
`read_bytes` function. It therefore retains the same creation-time/ChangeTime
incompatibility that the release guard patch addresses.

`test_dependency_read_external.py` reads an actual inert `profile-inspect.stdout`
through the reviewed public functions. It models stable, valid Windows metadata
with differing creation and change times. `dependency-read-red` records
**2 failures / 2 positives, 0.18 seconds**: both `read_json` and `digest` falsely
report `evidence changed at open`. An actual POSIX receipt and Windows observations
with coincident creation/change times pass. The source-pinned collection receipt
records both imported production modules and zero foreign imports or source drift.

The author has agreed to use the shared compatible cross-view comparison while
retaining complete descriptor-to-descriptor and pathname-to-pathname checks,
size limits and strict JSON validation. No scanner installation or live audit ran.

## Separate malformed-observation behavior

The original `test_source_stat_external.py` has 34 external controls.
`external-first` records **31 passes / 3 failures, 0.30 seconds**. The three
failures expect `QualificationError` for an authored pathname
`st_file_attributes` value of `None`, a float or a string. The preexisting
reparse bitmask at `source_blob:511` executes before the new type check and raises
`TypeError` instead. It does not return a successful source verification.

The inspected CPython conversion at `posixmodule.c:2637` always constructs this
field with `PyLong_FromUnsignedLong`. No supported native path yielding those
three values has been demonstrated. They are retained as deterministic error
hardening observations, separate from the two production-semantic boundaries;
they are not claimed native vulnerabilities. Missing fields, malformed descriptor
metadata, real-byte/index-mask protection, physical permissions, regular-file
type and reparse mismatches, late descriptor/path/tree ctime changes, POSIX
compatibility and the actual reviewed commit hold all passed.

The author plans to validate the Windows observation before applying the pathname
attribute bitmask. The original external probe and red receipt remain unchanged.
Its actual-commit hold control intentionally pins `f8c8877b`; any later-source
replay must identify its different source pin explicitly rather than silently
rewriting this original.

## Existing affected gate and source trace

Independent exact-`f8c8877b` affected replay passed **220 checks / 3 native Windows
skips in 1.28 seconds**. It names `test_release_source_stat.py`,
`test_release_qualification.py` and `test_dependency_security.py`. The three skips
are the actual Windows rewritten-file controls; they remain unexecuted. These
passing tests did not cover the final-write and dependency-reader boundaries above.

An AST comparison against `c7d3f258` confirms that only `source_blob` and the new
`source_open_state` changed among release-guard top-level definitions. Canonical
Git metadata, commit hold, bounded byte hashing, parent checks, API/run/artifact
ownership and publication policy remain outside this delta. Their broader
qualification is not re-established by this small review.

Primary source facts were read and rehashed from the supplied full v3.12.10 files:

| Fact | Retained primary location |
|---|---|
| Path `ctime` is copied from birthtime | `posixmodule.c:2147–2148` |
| Executable suffixes add execute bits | `posixmodule.c:1894–1914` |
| CreationTime and ChangeTime are stored separately | `fileutils.c:1118–1122` |
| Descriptor stat uses that conversion | `fileutils.c:1284` |
| File attributes are constructed as a Python integer | `posixmodule.c:2635–2637` |

Complete primary files, their PSF license and original URL/hash provenance are
included. The primary implementation supports the model; it is not a substitute
for the still-required native Windows run.

## Receipt integrity and replay scope

All four runs use the shared Python interpreter with absolute source paths,
`QT_QPA_PLATFORM=offscreen`, disabled bytecode/cache writes and fresh owned
temporary directories. The runner records the source/tree, exact argv, environment,
source hashes before/after and clean worktree status. The receipt plugin records
selected nodes and source-module ownership. Original logs and JUnit remain intact.

`source-f8c/` preserves the exact guard, dependency reader, author tests and spec.
`initial-review-context.json` binds these to Git blob IDs and primary hashes.
Only authored temporary files and external review receipts were written. No remote
request, target execution, workflow change or source mutation accompanies this
initial handoff. Corrected-source review will receive new receipt labels and a
separate disposition; this packet remains historical evidence of `f8c8877b`.
