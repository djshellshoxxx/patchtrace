# Corrected Windows source-stat independent review

## Review outcome

No remaining blocking finding was found in the bounded review of exact source
**`80df2735ea9001b7ba5f9aacf95614f280e51948`**, tree
`dee6041e11fd30fd036877af3f504798f51d89ce`. The worktree was clean and the recorded
source bytes remained unchanged throughout both final independent runs.

The original probes now pass: **44 passes, zero skips, in 0.41 seconds**.
The affected source-stat, release-qualification and dependency-security suites,
together with 12 additional independent boundary controls, pass **252 checks
with eight explicit native Windows skips in 1.58 seconds**. No failures or errors
remain in these runs. Their source import receipts record zero foreign imports
and zero source drift; the latter run records 43 source/test module paths.
Focused Ruff for both changed tools and their source-stat tests, plus
`git diff --check`, passes.

This accepts the portable mechanics of the corrected source. **Actual Windows
acceptance is still pending.** No target, compiler, native analyzer, scanner
installation, paid experiment, remote mutation or release was run. The test
filenames ending in `.CMD` or `.exe` contain inert authored bytes and are never
executed.

## What was corrected and reviewed

The author committed specification and controls at `a448a808`, then strengthened
the native ChangeTime control at `974d54cc`, before source `80df2735`.
The corrected source introduces an immutable nested-tuple snapshot containing
the original full pathname state, compatible cross-view state and full descriptor
state. `source_unchanged` checks the current pathname, opens one Windows regular
file, binds its compatible observation to the original identity, compares its
full descriptor state including ChangeTime, closes it, then checks the pathname.

Both release `checked_source` and dependency `checked_tree` now consume that
shared final observation. The two independent original final-write probes pass,
including the one with actual local Git canonical metadata. A same-inode,
same-length post-hash rewrite with restored modification time is refused under
the primary-modeled Windows semantics. The POSIX full-state check remains in use;
symlink snapshots do not cause their targets to be opened.

Dependency `read_bytes` now compares compatible path/descriptor state at open
and compares the complete descriptor state with itself after reading. Its final
pathname check, bounded read and strict JSON consumers remain. The original
`read_json` and `digest` false-refusal probes pass without changing their assertions.

Windows regular-file metadata is checked before the attribute bitmask, so the
three earlier malformed-path observations now raise the intended typed refusal.
Their classification remains deterministic error hardening: no supported CPython
route producing those non-integer attribute values was established.

The correction is limited to the two tools, source-stat tests and existing
Windows specification. Canonical Git byte checks, commit holds, parent identity,
job/run/artifact ownership, scan policy and release operations were not relaxed.
All production `source_blob` second-return consumers were traced; the release
and dependency tree checks are the only two and both use the shared helper.

## Independent added controls

The 12 new external controls challenge the final observation and receipt reader
at their actual boundaries:

- Changed descriptor ChangeTime and inode fail the final observation.
- Changed reparse attributes or unavailable birth metadata refuse before a
  replacement descriptor can be admitted.
- A changed final pathname is rejected after the reopen.
- Success and descriptor-refusal paths close their one acquired descriptor;
  at most one descriptor is opened by each final observation.
- A dangling symlink's target remains unopened, and the POSIX final comparison
  does not acquire an unnecessary descriptor.
- Compatible Windows receipt reads still reject descriptor drift, pathname
  replacement, duplicate JSON keys and an oversized file.

These controls supplement the author's exact-source regression gate. They do
not prove arbitrary filesystem race immunity. The final check is an observation
at a point in time; it does not freeze source files after return, defeat forged
filesystem metadata or qualify behavior on every Windows filesystem.

## Exact replay and preserved history

The initial `f8c8877b` packet remains unchanged. All **41 initial payload hashes**
were reverified, including both original probes, all red logs/JUnit, complete
CPython v3.12.10 primary files/license and the source snapshots.

`test_source_stat_external.py` intentionally pins the original actual commit hold
to `f8c8877b`. For final replay, a separately named
`test_source_stat_external_80df.py` changes only that `SOURCE` literal to the new
exact SHA; every behavioral assertion is unchanged. `corrected-replay-pins.json`
records both hashes and verifies this one substitution. The original is retained.
The peer final-write test was copied byte-for-byte into `peer-replay-80df/` beside
an exact `80df2735` guard snapshot, matching its original relative loading method.
The real-Git and dependency-reader probe files themselves are unchanged.

| Exact-source run | Result |
|---|---|
| `f8c`: original external stat controls | 31 passes / 3 malformed-observation typed-refusal mismatches |
| `f8c`: real-Git final write probe | 1 failure / 2 positives |
| `f8c`: dependency receipt compatibility | 2 failures / 2 positives |
| `f8c`: existing affected gate | 220 passes / 3 native Windows skips |
| `80df`: all preserved external/peer controls | 44 passes / 0 skips |
| `80df`: affected gate plus additional boundaries | 252 passes / 8 native Windows skips |

The eight skipped nodes comprise four actual Windows final-source checks across
the two consumers, one actual Windows receipt-read check, and three actual
Windows rewritten-source suffix checks. Their complete node IDs and reasons are
in `corrected-review-context.json`. No skip is counted as acceptance.

Raw receipts, explicit source-pin copies, exact corrected source/spec/test bytes,
source diff and chain, commands/environments, import audits, logs and JUnit are
retained under `qa/windows-source-stat-independent`. The initial and corrected
ZIPs/manifests are separate historical checkpoints. The reviewed repository was
read-only to this reviewer; root owns the source changes and subsequent integration.
