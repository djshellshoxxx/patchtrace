"""Record a bounded, explicitly selected coordinator review at a clean checkout."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--production', required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--timeout', type=int, default=180)
    parser.add_argument('nodes', nargs='+')
    args = parser.parse_args()
    root, out = args.root.resolve(), args.out.resolve()
    out.parent.mkdir(parents=True, exist_ok=True)

    def git(*argv: str) -> str:
        return subprocess.check_output(['git', *argv], cwd=root, text=True).strip()

    assert not git('status', '--short'), 'Review requires a clean checkout'
    source = git('rev-parse', 'HEAD')
    paths = ['src', 'tests', 'tools', '.github']
    assert not git('diff', args.production, source, '--', *paths), 'Code/test/workflow drift'
    command = [sys.executable, '-m', 'pytest', '-q', '-ra', '-p', 'full_batch_receipt',
               *args.nodes, '--junitxml=' + str(out) + '.xml']
    env = dict(os.environ, PYTHONPATH=':'.join(map(str, [root / 'src', root / 'tests', root,
                                                       Path(__file__).resolve().parent])),
               QT_QPA_PLATFORM='offscreen',
               PATCHTRACE_BATCH_COLLECTION_RECEIPT=str(out) + '-collection.json')
    context = dict(source=source, tree=git('rev-parse', 'HEAD^{tree}'),
                   production_commit=args.production, code_test_equivalence_verified=True,
                   argv=command, cwd=str(root), PYTHONPATH=env['PYTHONPATH'],
                   started_utc=datetime.now(timezone.utc).isoformat())
    for suffix in ('-command.json', '-exit.json', '-collection.json', '.log', '.xml'):
        assert not Path(str(out) + suffix).exists(), 'Never overwrite a previous review receipt'
    Path(str(out) + '-command.json').write_text(json.dumps(context, indent=2) + '\n')
    started = time.monotonic()
    with Path(str(out) + '.log').open('x') as stream:
        result = subprocess.run(command, cwd=root, env=env, stdout=stream,
                                stderr=subprocess.STDOUT, timeout=args.timeout)
    after = dict(exit=result.returncode, elapsed=time.monotonic() - started,
                 source_after=git('rev-parse', 'HEAD'), status_after=git('status', '--short'))
    collection_path = Path(str(out) + '-collection.json')
    collection = json.loads(collection_path.read_text()) if collection_path.exists() else {}
    foreign = []
    drift = []
    for name, row in collection.get('final_sources', {}).items():
        path = Path(row['path'])
        if not path.is_relative_to(root / 'src'):
            foreign.append({'module': name, 'path': str(path)})
        elif hashlib.sha256(path.read_bytes()).hexdigest() != row['sha256']:
            drift.append(str(path))
    after.update(foreign_imports=foreign, imported_source_drift=drift,
                 imported_source_count=len(collection.get('final_sources', {})))
    Path(str(out) + '-exit.json').write_text(json.dumps(after, indent=2) + '\n')
    print(json.dumps(after))
    print('\n'.join(Path(str(out) + '.log').read_text().splitlines()[-28:]))
    assert after['source_after'] == source and not after['status_after']
    assert not foreign and not drift and collection
    return result.returncode


if __name__ == '__main__':
    raise SystemExit(main())
