"""One-shot immutable author/independent Windows observation checkpoint."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/c7a9e8d98848')
REPO = ROOT / 'kb-selftest'
SOURCE = '80df2735ea9001b7ba5f9aacf95614f280e51948'
BASE = 'c7d3f25858cfefbacbd8ea4022b3d13e1e2aed2a'
OUT = REPO / 'docs/qa/windows-source-stat-20261118'


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', '-C', str(REPO), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def counts(raw):
    result = dict(passed=0, failed=0, errors=0, skipped=0)
    for case in ET.fromstring(raw).findall('.//testcase'):
        key = ('failed' if case.find('failure') is not None else
               'errors' if case.find('error') is not None else
               'skipped' if case.find('skipped') is not None else 'passed')
        result[key] += 1
    return result


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('status', '--porcelain') and not OUT.exists()
payloads = {}
for path in sorted((ROOT / 'qa/windows-source-stat').rglob('*')):
    if path.is_file() and '__pycache__' not in path.parts:
        payloads['author/' + path.relative_to(ROOT / 'qa/windows-source-stat').as_posix()] = path.read_bytes()
peer_results, first_rows = [], None
for label, expected in [('f8c', '3e1420070223f65990d245658e3970c0fe7abd3535fb8afc074cae1433e37144'),
                        ('80df', '39001a0c8f7f7586177f08bc850d76435dc4d2a8ba9e921393e7d2f6b2276b57')]:
    stem = f'windows-source-stat-independent-{label}-20261118'
    archive, manifest_path = ROOT / 'qa' / (stem + '.zip'), ROOT / 'qa' / (stem + '.manifest.json')
    assert sha(archive.read_bytes()) == expected
    manifest = json.loads(manifest_path.read_text())
    rows = {row['path']: row for row in manifest['files']}
    snapshots = 0
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == len(rows)
        assert set(z.namelist()) == set(rows)
        for name, row in rows.items():
            data = z.read(name)
            assert len(data) == row['bytes'] and sha(data) == row['sha256']
            for prefix, ref in [('source-f8c/', 'f8c8877bbf4f7d551fe572f706f725c08f8e2734'),
                                ('source-80df/', SOURCE)]:
                if name.startswith(prefix):
                    assert data == git('show', ref + ':' + name[len(prefix):]), name
                    snapshots += 1
        if first_rows is not None:
            assert all(rows[name] == row for name, row in first_rows.items())
        else:
            first_rows = rows
        junit = {name: counts(z.read(name)) for name in z.namelist() if name.endswith('.xml')}
        if label == '80df':
            assert junit['original-probes-80df.xml'] == dict(passed=44, failed=0, errors=0, skipped=0)
            assert junit['corrected-boundaries-80df.xml'] == dict(passed=252, failed=0, errors=0, skipped=8)
            assert z.read('peer-replay-80df/release_qualification.py') == git('show', SOURCE + ':tools/release_qualification.py')
            assert z.read('peer-replay-80df/test_final_windows_observation.py') == z.read('peer-original/test_final_windows_observation.py')
        peer_results.append({'source': manifest['source'], 'archive_sha256': expected,
                             'payloads_verified': len(rows), 'git_snapshots_verified': snapshots, 'junit': junit})
    payloads['independent/' + archive.name] = archive.read_bytes()
    payloads['independent/' + manifest_path.name] = manifest_path.read_bytes()
for name in ['initial-review.md', 'initial-review-context.json', 'corrected-review.md',
             'corrected-review-context.json', 'corrected-replay-pins.json']:
    payloads['independent/' + name] = (ROOT / 'qa/windows-source-stat-independent' / name).read_bytes()
primary = json.loads(payloads['author/primary/source-provenance.json'])
for name, row in primary['sources'].items():
    data = payloads['author/primary/' + name]
    assert len(data) == row['bytes'] and sha(data) == row['sha256']
assert counts(payloads['author/final-observation-affected.xml']) == dict(passed=240, failed=0, errors=0, skipped=8)
assert counts(payloads['author/final-observation-spec-red.xml']) == dict(passed=30, failed=9, errors=0, skipped=8)
paths = git('diff', '--name-only', BASE, SOURCE).decode().splitlines()
for name in paths:
    payloads['source-80df/' + name] = git('show', SOURCE + ':' + name)
for name in ['tools/release_qualification.py', 'tools/dependency_security.py', 'tests/test_release_qualification.py',
             'tests/test_dependency_security.py', 'docs/specs/windows-acceptance-and-milestone-builds.md']:
    payloads['baseline/' + name] = git('show', BASE + ':' + name)
payloads['source.diff'] = git('diff', BASE, SOURCE)
payloads['source-chain.log'] = git('log', '--reverse', '--format=%H %s', BASE + '..' + SOURCE)
payloads['helpers/replay_reviewed_checks.py'] = (ROOT / 'ops/replay_reviewed_checks.py').read_bytes()
payloads['helpers/seal_windows_source_stat_checkpoint.py'] = Path(__file__).read_bytes()
payloads['hosted-14ef/README.md'] = (ROOT / 'qa/hosted-14ef-receipt-review/README.md').read_bytes()
payloads['hosted-14ef/evidence.zip'] = (ROOT / 'qa/hosted-14ef-receipt-review/evidence.zip').read_bytes()
payloads['hosted-14ef/manifest.json'] = (ROOT / 'qa/hosted-14ef-receipt-review/manifest.json').read_bytes()
payloads['hosted-14ef/root-review.json'] = (ROOT / 'qa/hosted-14ef-root-review/archive-and-source-review.json').read_bytes()
review = {'at': datetime.now(timezone.utc).isoformat(), 'source': SOURCE,
          'tree': git('rev-parse', SOURCE + '^{tree}').decode().strip(), 'base': BASE,
          'changed_paths': paths, 'independent': peer_results, 'initial_41_payloads_preserved': True,
          'primary_files_verified': 3, 'root_author_result': dict(passed=240, skipped=8),
          'native_windows_qualification': 'unexecuted', 'blocking_findings_in_bounded_portable_review': []}
payloads['coordinator-review.json'] = (json.dumps(review, indent=2) + '\n').encode()
OUT.mkdir(parents=True)
archive = OUT / 'evidence.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for name, data in sorted(payloads.items()):
        z.writestr(name, data)
files = [{'path': name, 'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(payloads.items())]
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(payloads)
    for row in files:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
digest = sha(archive.read_bytes())
manifest = {**review, 'archive_bytes': archive.stat().st_size, 'archive_sha256': digest,
            'payload_count': len(files), 'payload_bytes': sum(row['bytes'] for row in files),
            'all_payloads_verified': True, 'files': files}
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
readme = f'''# Windows source and dependency receipt observations

Final source **`{SOURCE}`**, tree `{review['tree']}`, is based on
`{BASE}`. The seven attributed specification, regression and source commits
are retained in the evidence archive. This QA checkpoint changes no production
code and does not remove the `[no release]` hold.

## Result

The final author gate passes **240 checks with eight explicit native Windows
skips**, zero failures/errors, in **1.34 seconds**. Independent replay passes
**44 preserved external/peer controls** with zero skips in **0.41 seconds**;
the independent affected gate plus 12 additional boundary controls passes
**252 checks with the same eight Windows skips** in **1.58 seconds**. Counts are
overlapping invocations, not additive coverage or accuracy measurements. All
source imports and Git snapshots are pinned; normal full Ruff and whitespace
checks pass. Actual Windows execution remains unverified.

## Supported observation mismatch and hosted limits

The exact retained CPython v3.12.10 implementations show that Windows pathname
stat substitutes creation time into `st_ctime_ns` and synthesizes execute bits
from `.exe`, `.com`, `.bat` and `.cmd` suffixes. Descriptor stat reports the native
change time and physical mode. Comparing their complete tuples as though these
fields had identical meanings falsely refuses otherwise stable files.

Primary files and their license are preserved with URLs, sizes and SHA-256:
[posixmodule.c](https://github.com/python/cpython/blob/v3.12.10/Modules/posixmodule.c)
and [fileutils.c](https://github.com/python/cpython/blob/v3.12.10/Python/fileutils.c).
This source evidence is distinct from native execution.

The retained PR316 preview `5ed108355f2626c9867782832c76b1c438c51281`
has the same tree as published head `14efc52369146f4a638b7d688208736a05321bc0`.
Its Windows BinDiff and two Windows dependency-profile jobs fail at the source
guard before native compilation or scanning. Those logs do not identify the
offending path or individual stat fields. The supported API mismatch is a
credible explanation, but the exact hosted failing field was not observed.
All five original hosted artifacts, logs, API observations and their independent
byte review are retained; the strict static result at that older tree remains
**80 diagnostics, exit 1**. No historical failure is relabeled as passing.

## Corrected boundaries

The first repair compares only compatible cross-view identity: device, inode,
physical mode without suffix-derived execute bits, size, modification time,
explicit creation time and attributes. It retains complete same-API descriptor
and pathname checks, bounded canonical Git blob hashing, parent identities and
the commit hold. Missing or malformed required regular-file observations refuse.

Independent review then reproduced an adjacent final-pass gap. A same-inode,
same-size rewrite with restored modification time, after a file's hashing
descriptor closed but before the final all-files pass, escaped the Windows
pathname-only comparison. The original peer probe and a separate real-local-Git
probe are preserved, each with **one failure and two positives**. They model the
primary implementation's Windows observations over real inert file operations;
neither claims native Windows execution or that the compatibility patch created
the preexisting final-pass limitation.

The final repair retains an opaque immutable snapshot of original pathname,
compatible-open and full descriptor states. A shared `source_unchanged` helper
reopens one Windows regular file at a time in the final pass, binds it to the
captured identity, compares its full descriptor state including ChangeTime,
closes the descriptor, then rechecks the pathname. Both `checked_source` and
dependency `checked_tree` use that helper. It does not hold one descriptor for
every tracked file. POSIX retains its complete final pathname comparison;
symlink targets are not opened by this helper.

A second independent boundary affects dependency evidence itself: `read_json`
and `digest` rejected stable Windows observations because `read_bytes` compared
pathname and descriptor change-time fields directly. The original **two failures
and two positives** remain. Receipt reads now use the compatible comparison at
open and complete same-descriptor stability across reading, plus the original
final pathname, byte limit and strict JSON checks.

Three authored malformed attribute cases previously raised `TypeError` before
the intended typed refusal. Validating required observations before interpreting
attribute bits fixes this deterministic error boundary. No supported CPython
route producing those non-integer fields was established, and they are not
reported as three reachable vulnerabilities.

## Preserved chronology and independent review

| Source/phase | Actual result |
|---|---|
| Original compatibility spec before source | 11 failed / 8 passed / 3 Windows skips |
| First corrected focused gate | 98 passed / 3 Windows skips |
| Dependency neighbors | 122 passed |
| First clean complete portable source `f8c8877b` | 220 passed / 3 Windows skips |
| Initial independent external controls | 31 passed / 3 malformed-observation typed-error mismatches |
| Independent real-Git late-write control | 1 failed / 2 passed |
| Independent dependency receipt controls | 2 failed / 2 passed |
| New spec before final source `974d54cc` | 9 failed / 30 passed / 8 Windows skips |
| Final author source `80df2735` | 240 passed / 8 Windows skips |
| Final original external/peer replay | 44 passed / 0 skips |
| Final independent affected/boundary gate | 252 passed / 8 Windows skips |

The initial coordinator preflight refusal and import-order Ruff finding remain
as explicitly labeled summaries where raw console files were not captured.
All test-run raw commands, logs, JUnit, imports and exit receipts are retained.
Original red observations were not overwritten. All 41 payloads of the initial
independent packet remain byte-identical in the corrected packet. A separately
named exact-source replay changes only the commit-hold test's SHA literal;
the original file and substitution receipt remain.

The 12 additional independent controls cover single-descriptor closure on
success/refusal, ChangeTime and inode changes, reparse attributes, unavailable
metadata, the final pathname, POSIX and dangling-symlink behavior, duplicate JSON
and oversized receipts. The reviewer read both complete consumer changes and
found no remaining blocker within that bounded portable scope.

## Remaining acceptance

The eight unexecuted native Windows checks are four final-source cases across
the two consumers, one dependency receipt case and three rewritten-source suffix
cases. These use inert authored data, never target execution. They must actually
run on the candidate's Windows runtime. No portable test qualifies a Windows
filesystem, SDK/native engine, dependency vulnerability audit, frozen package,
installer or canonical release. The final source check is a point-in-time
observation; it does not freeze later files or defeat arbitrary forged metadata.
Main and publication acceptance remain separate gates.

## Immutable evidence

The adjacent [archive](evidence.zip) contains **{len(files)} verified payloads**,
**{archive.stat().st_size:,} bytes**, SHA-256 **`{digest}`**. The
[manifest](manifest.json) records all payload hashes, exact sources, original
independent archive hashes and the coordinator verification. It includes complete
author receipts, both independent archives, primary sources/license, source and
test snapshots, full source diff/history, hosted evidence and replay helpers.
'''
(OUT / 'README.md').write_text(readme)
with (REPO / 'docs/qa.md').open('a') as stream:
    stream.write('\n\n## [WINDOWS-SOURCE-OBSERVATIONS-20261118]\n\n'
                 'Exact source `80df2735` repairs compatible path/descriptor observations, final Windows '
                 'ChangeTime rechecks in both source consumers and dependency receipt reads. Original '
                 'independent failures remain. Author240/8native skips, independent44/0 and252/8; no '
                 'native Windows or scanner acceptance. [Complete sealed evidence](qa/windows-source-stat-20261118/README.md).\n')
with (REPO / 'tasks/todo.md').open('a') as stream:
    stream.write('\n\n### [WINDOWS-SOURCE-OBSERVATIONS-20261118]\n\n'
                 '- [x] Preserve supported-semantics source evidence and all original author/reviewer failures.\n'
                 '- [x] Specify/test then repair compatible comparisons, both final tree consumers and receipt reads; independently review exact source.\n'
                 '- [ ] Integrate and run actual combined/candidate Windows, native, dependency and package gates; all eight Windows skips remain unverified.\n')
print(json.dumps({'source': SOURCE, 'payloads': len(files), 'archive_bytes': archive.stat().st_size,
                  'sha256': digest, 'independent_packets_verified': peer_results}))
