"""Fixed source, fresh observations, inherited network denial; no archived payload execution."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parent.parent
REPO=ROOT/'semantic-disposition-batch4'
SOURCE='c8ee650f17a1d11b92304af51b2cbf808f3a9417'
OUT=ROOT/'qa/navigation-root-review'


def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])


assert git('rev-parse','HEAD').decode().strip()==SOURCE and not git('status','--porcelain')
owned=Path(tempfile.mkdtemp(prefix='patchtrace-nav-root-'))
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',QT_QPA_PLATFORM='offscreen',
         PYTHONPATH=os.pathsep.join(map(str,[REPO/'src',REPO/'tests',REPO,ROOT/'ops'])),
         GIT_ALLOW_PROTOCOL='file',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_TERMINAL_PROMPT='0',
         PATCHTRACE_NAV_REVIEW_OBSERVATIONS=str(OUT/'fixture-corrected-observations'),
         PATCHTRACE_BATCH_COLLECTION_RECEIPT=str(OUT/'fixture-corrected-imports.json'),
         PATCHTRACE_OFFLINE_GUARD_RECEIPT=str(OUT/'fixture-corrected-offline-guard.json'))
argv=[sys.executable,str(ROOT/'ops/continuation_offline_pytest.py'),'-q','-ra','-p','no:cacheprovider',
      '-p','full_batch_receipt',str(OUT/'test_representation_boundary_v2.py'),
      '--basetemp='+str(owned/'pytest'),'--junitxml='+str(OUT/'fixture-corrected.xml')]
with (OUT/'fixture-corrected-command.json').open('x') as f:json.dump(dict(source=SOURCE,tree=git('rev-parse','HEAD^{tree}').decode().strip(),
    argv=argv,cwd=str(REPO),pythonpath=env['PYTHONPATH'],owned_temp=str(owned),
    probe_sha256=hashlib.sha256((OUT/'test_representation_boundary_v2.py').read_bytes()).hexdigest()),f,indent=2);f.write('\n')
with (OUT/'fixture-corrected.log').open('x') as f:r=subprocess.run(argv,cwd=REPO,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90)
imports=json.loads((OUT/'fixture-corrected-imports.json').read_text())
drift=[]
for name,row in imports['final_sources'].items():
    path=Path(row['path']);assert path.is_relative_to(REPO/'src')
    data=git('show',SOURCE+':'+path.relative_to(REPO).as_posix())
    if hashlib.sha256(data).hexdigest()!=row['sha256'] or path.read_bytes()!=data:drift.append(name)
after=git('rev-parse','HEAD').decode().strip();status=git('status','--porcelain').decode()
receipt=dict(exit=r.returncode,source_after=after,status_after=status,imports=len(imports['final_sources']),
             drift=drift,owned_temp_retained=str(owned))
with (OUT/'fixture-corrected-exit.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt));print((OUT/'fixture-corrected.log').read_text()[-10000:])
assert after==SOURCE and not status and not drift
raise SystemExit(r.returncode)
