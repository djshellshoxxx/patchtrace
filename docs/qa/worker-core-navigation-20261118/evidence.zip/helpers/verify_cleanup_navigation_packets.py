"""Read-only coordinator verification of retained cleanup and navigation evidence."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = ROOT / 'qa/worker-core-root-review'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def write(name, data):
    with (OUT / name).open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


def members(z, rows, extra=()):
    assert len(z.namelist()) == len(set(z.namelist()))
    assert set(z.namelist()) == {row['path'] for row in rows} | set(extra)
    assert z.testzip() is None
    for row in rows:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['path']


def recount(z):
    result = {}
    for name in z.namelist():
        if name.endswith('.xml'):
            tree = ET.fromstring(z.read(name))
            cases = list(tree.iter('testcase'))
            result[name] = dict(tests=len(cases),
                failures=sum(item.find('failure') is not None for item in cases),
                errors=sum(item.find('error') is not None for item in cases),
                skipped=sum(item.find('skipped') is not None for item in cases))
            result[name]['passed'] = len(cases) - sum(result[name][key] for key in ('failures', 'errors', 'skipped'))
    return result


cleanup = REPO / 'docs/qa/core-held-inputs-cleanup-20261118.zip'
manifest = json.loads(cleanup.with_suffix('.manifest.json').read_text())
assert sha(cleanup.read_bytes()) == manifest['archive_sha256'] == '5ffd0899d92cd847205dc70ab6902131ce56514a0ee56bd1307c795619a0eb37'
assert cleanup.stat().st_size == manifest['archive_bytes'] == 134849
with zipfile.ZipFile(cleanup) as z:
    members(z, manifest['files'])
    chain = json.loads(z.read('source-chain.json'))
    canonical = []
    for prefix, commit, rows in (
        ('committed-source/', chain['source_commit'], chain['files']),
        ('red-source/', chain['spec_test_commit'], json.loads(z.read('red-source.json')))):
        for row in rows:
            raw = git('show', commit + ':' + row['path'])
            assert raw == z.read(prefix + row['path']) and sha(raw) == row['sha256']
            canonical.append(dict(commit=commit, path=row['path'], sha256=sha(raw)))
    assert z.read('first-green-ingestion.py') == git('show', chain['source_commit'] + ':src/patchtrace/ingestion.py')
    peers = json.loads(z.read('original-peer.json'))
    assert isinstance(peers, list)
    for row in peers:
        raw = Path(row['original']).read_bytes()
        assert raw == z.read(row['copy']) and sha(raw) == row['sha256'] and len(raw) == row['bytes']
    counts = recount(z)
    assert counts['affected.xml'] == dict(tests=318, failures=0, errors=0, skipped=0, passed=318)
    write('cleanup-packet-verification.json', dict(archive=str(cleanup), archive_sha256=sha(cleanup.read_bytes()),
        members=len(z.namelist()), canonical_git_files=canonical, original_peer_files_unchanged=len(peers),
        first_green_equals_source=True, junit=counts,
        verifier_correction='The earlier inline verifier assumed original-peer.json was a dict; this read-only verifier accepts its actual list of original/copy rows. No evidence or source changed.'))

navigation = ROOT / 'semantic-disposition-batch4/docs/qa/signal-navigation-validation-20261118.zip'
assert sha(navigation.read_bytes()) == 'c5bfd92f7e884661fa54572a99dbf3739ca2a7ca8c19edff208dfcb2155dde80'
assert navigation.stat().st_size == 801824
with zipfile.ZipFile(navigation) as z:
    manifest = json.loads(z.read('manifest.json'))
    members(z, manifest['files'], ['manifest.json'])
    snapshots = json.loads(z.read('git-snapshots.json'))['snapshots']
    for row in snapshots:
        raw = git('show', row['git_commit'] + ':' + row['git_path'])
        assert raw == z.read(row['path']) and sha(raw) == row['sha256'] and len(raw) == row['bytes']
        assert git('rev-parse', row['git_commit'] + ':' + row['git_path']).decode().strip() == row['git_blob']
    preserved = []
    for meta, prefix in [('original-preservation.json', 'original/'), ('root-original-preservation.json', 'root-review-original/')]:
        for row in json.loads(z.read(meta))['files']:
            raw = Path(row['original_path']).read_bytes()
            assert raw == z.read(prefix + row['path']) and sha(raw) == row['sha256'] and len(raw) == row['bytes']
            preserved.append(row)
    proof = json.loads(z.read('source-proof.json'))
    before, after = proof['baseline'], proof['source']
    changed = git('diff', '--name-only', before, after, '--', 'src').decode().splitlines()
    assert changed == proof['changed_production_files']
    def outside(raw):
        module = ast.parse(raw)
        cls = next(item for item in module.body if isinstance(item, ast.ClassDef) and item.name == 'MainWindow')
        method = next(item for item in cls.body if isinstance(item, ast.FunctionDef) and item.name == 'jump_signal')
        lines = raw.splitlines(keepends=True)
        byte_rest = b''.join(lines[:method.lineno - 1] + lines[method.end_lineno:])
        cls.body.remove(method)
        return byte_rest, ast.dump(module)
    assert outside(git('show', before + ':src/patchtrace/ui.py')) == outside(git('show', after + ':src/patchtrace/ui.py'))
    for row in proof['unchanged_paths']:
        raw = git('show', after + ':' + row['path'])
        assert raw == git('show', before + ':' + row['path']) and sha(raw) == row['sha256']
    counts = recount(z)
    for name, total in [('final-representation-affected.xml', 175), ('final-representation-original.xml', 7), ('final-representation-root.xml', 2)]:
        assert counts[name] == dict(tests=total, failures=0, errors=0, skipped=0, passed=total)
    write('navigation-packet-verification.json', dict(archive=str(navigation), archive_sha256=sha(navigation.read_bytes()),
        members=len(z.namelist()), canonical_git_snapshots=len(snapshots), original_files_unchanged=preserved,
        actual_production_boundary=changed, byte_and_ast_preservation_outside_jump_signal=True,
        unchanged_neighbor_files=len(proof['unchanged_paths']), junit=counts))

print(json.dumps(dict(cleanup='verified', navigation='verified', receipts=str(OUT))))
