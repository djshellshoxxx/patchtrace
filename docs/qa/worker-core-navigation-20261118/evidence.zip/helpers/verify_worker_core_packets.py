"""Read-only root verification of source archives; never executes archived payloads."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = ROOT / 'qa/worker-core-root-review'
OUT.mkdir(exist_ok=True)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', '-C', str(REPO), *args])


packets = [
    ('worker', ROOT/'pw02-local-packages/docs/qa/autonomous-ci-20261118/pw02-worker-grants',
     'manifest.json', 'evidence.zip', 'eb50b0283cf7a46e7bd25ffc23cd78b18dfeb2e0',
     '36c5ff29cf8fd31cc5a3c326445e32fc82c528c218f78dfea3bb593a3dc757c8'),
    ('core', ROOT/'security-residual-qa/docs/qa',
     'core-held-inputs-20261118.manifest.json', 'core-held-inputs-20261118.zip',
     'b85a0cf7bf135e9431677737613000707553b192',
     '2d6f638bfec1887188aa15c94a0305dac0efb5b13d2ccff725f3d55566816f4d'),
]
results = []
for label, directory, manifest_name, archive_name, source, expected in packets:
    manifest=json.loads((directory/manifest_name).read_text())
    raw=(directory/archive_name).read_bytes()
    assert sha(raw)==expected
    meta=manifest['archive'] if isinstance(manifest['archive'],dict) else dict(
        bytes=manifest['archive_bytes'],sha256=manifest['archive_sha256'],members=manifest['payload_count'])
    assert len(raw)==meta['bytes'] and expected==meta['sha256']
    files={row['path']:row for row in manifest['files']}
    checked,junit=[],[]
    with zipfile.ZipFile(directory/archive_name) as z:
        assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(files)==meta['members']
        assert set(z.namelist())==set(files)
        for name,row in files.items():
            data=z.read(name)
            assert len(data)==row['bytes'] and sha(data)==row['sha256']
            if name.startswith('committed-source/'):
                path=name.removeprefix('committed-source/')
                assert data==git('show',source+':'+path), (label,path)
                checked.append(path)
            if name.endswith('.xml'):
                xml=ET.fromstring(data)
                cases=xml.findall('.//testcase')
                counts=Counter()
                for case in cases:
                    skip=case.find('skipped')
                    counts['failed' if case.find('failure') is not None else 'errors' if case.find('error') is not None
                           else 'xfail' if skip is not None and skip.get('type')=='pytest.xfail'
                           else 'skipped' if skip is not None else 'passed']+=1
                junit.append(dict(path=name,cases=len(cases),counts=counts,sha256=sha(data)))
        if label=='worker':
            provenance=json.loads(z.read('source-provenance.json'))
            assert len(checked)==78 and set(checked)=={row['path'] for row in provenance['canonical_files']}
            for row in provenance['canonical_files']:
                data=git('show',source+':'+row['path'])
                assert len(data)==row['bytes'] and sha(data)==row['sha256']
            for path in git('ls-tree','-r','--name-only',provenance['base'],'--','docs/schemas/local-package').decode().splitlines():
                assert git('show',source+':'+path)==git('show',provenance['base']+':'+path)
            for name in ('tests/package_worker_support.py','tests/test_package_worker_contracts.py','tests/test_package_worker_grants.py'):
                assert git('show',source+':'+name)==git('show','a522e275ddeedc25bfb2b06fd01b20ec7caef1d7:'+name)
            assert git('show',source+':tests/test_package_worker_edges.py')==git('show','4474686899318efb57dac683e66c3e07f99dcf87:tests/test_package_worker_edges.py')
        else:
            chain=json.loads(z.read('source-chain.json'))
            assert len(checked)==11 and set(checked)==set(chain['all_changed_paths'])
            for row in chain['commits']:
                assert git('rev-parse',row['sha']+'^{tree}').decode().strip()==row['tree']
                assert git('show','-s','--format=%P',row['sha']).decode().strip().split()==row['parents']
            for name in checked:
                if name.startswith('tests/'):
                    assert git('show',source+':'+name)==git('show',chain['spec_test_commit']+':'+name)
            originals=json.loads(z.read('original-receipts.json'))['files']
            for row in originals:
                data=z.read(row['path']);assert len(data)==row['bytes'] and sha(data)==row['sha256']
    results.append(dict(label=label,source=source,archive_sha256=expected,archive_bytes=len(raw),
                        verified_payloads=len(files),canonical_git_snapshots=len(checked),junit=junit,
                        original_spec_test_bytes_preserved=True))
receipt=dict(at=datetime.now(timezone.utc).isoformat(),results=results,
             qualification='Archive/source/test preservation review only; independent behavior review remains separate.')
with (OUT/'archive-source-verification.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt))
