"""Verify read-only design/disposition packets against canonical Git bytes."""
import ast
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

import yaml

ROOT=Path(__file__).resolve().parent.parent
REPO=ROOT/'continuation-integration'
OUT=ROOT/'qa/followup-design-root-review'
OUT.mkdir(exist_ok=True)


def git(*args):return subprocess.check_output(['git','--no-replace-objects','-C',str(REPO),*args])


def sha(data):return hashlib.sha256(data).hexdigest()


phase_ref='1307a627797063c64df79f4d2971b28df85b2c0b'
phase_raw=git('show',phase_ref+':docs/qa/phase2-reference-contract-disposition-20261118.zip')
assert sha(phase_raw)=='fd6a538c735fb6a40552075fd7725e8d0d0c602f9d1107b57eb1b07ca456f252'
phase=zipfile.ZipFile(io.BytesIO(phase_raw))
manifest=json.loads(phase.read('manifest.json'))
files={row['path']:row for row in manifest['files']}
assert phase.testzip() is None and len(phase.namelist())==len(set(phase.namelist()))==118
assert set(phase.namelist())==set(files)|{'manifest.json'}
for path,row in files.items():
    data=phase.read(path);assert len(data)==row['bytes'] and sha(data)==row['sha256']
sources=[]
for name,prefix in [('current-source-manifest.json','current-source/'),('reference-manifest.json','reference/')]:
    rows=json.loads(phase.read(name))['files']
    for row in rows:
        data=git('show',row['commit']+':'+row['path'])
        assert data==phase.read(prefix+row['path']) and sha(data)==row['sha256'] and len(data)==row['bytes']
        assert git('rev-parse',row['commit']+':'+row['path']).decode().strip()==row['git_blob']
    sources.append(dict(name=name,verified=len(rows)))
proofs=json.loads(phase.read('caller-proofs.json'))
for row in proofs['symbols']:
    data=git('show',proofs['baseline']+':'+row['path']);lines=data.decode().splitlines(keepends=True)
    assert sha(data)==row['source_sha256']
    assert sha(''.join(lines[row['start_line']-1:row['end_line']]).encode())==row['symbol_sha256']
    nodes=[node for node in ast.walk(ast.parse(data)) if isinstance(node,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef))
           and node.lineno==row['start_line'] and node.end_lineno==row['end_line']]
    assert len(nodes)==1
    assert sorted({ast.unparse(node.func) for node in ast.walk(nodes[0]) if isinstance(node,ast.Call)})==row['calls']
junit=[]
for name in phase.namelist():
    if name.endswith('.xml'):
        counts=Counter()
        for case in ET.fromstring(phase.read(name)).findall('.//testcase'):
            counts['failed' if case.find('failure') is not None else 'errors' if case.find('error') is not None
                   else 'skipped' if case.find('skipped') is not None else 'passed']+=1
        junit.append(dict(path=name,counts=counts))
assert sha(phase.read('test_phase2_navigation_boundary.py'))=='61b5d7c21778e12ba71bc6d32a0779f7d1d457656955bf2bfdab64c8c5953688'
phase_result=dict(commit=phase_ref,members=118,sha256=sha(phase_raw),sources=sources,
                  canonical_symbol_call_proofs=len(proofs['symbols']),junit=junit)

native_ref='8de96581f9af5b6eabc79b763303c410d5f97dd4'
prefix='docs/qa/autonomous-ci-20261118/pw02-native-seam-design/'
native_raw=git('show',native_ref+':'+prefix+'evidence.zip')
manifest=json.loads(git('show',native_ref+':'+prefix+'manifest.json'))
assert sha(native_raw)==manifest['archive']['sha256']=='7015cbfe58cda8a885d48bb1d25946169bbca4e031350c7eb27920a75fcce94d'
native=zipfile.ZipFile(io.BytesIO(native_raw))
assert native.testzip() is None and len(native.namelist())==len(set(native.namelist()))==26
assert set(native.namelist())=={row['path'] for row in manifest['members']}
for row in manifest['members']:
    data=native.read(row['path']);assert len(data)==row['bytes'] and sha(data)==row['sha256']
provenance=json.loads(native.read('current-source-provenance.json'))
for row in provenance['source_files']:
    data=git('show',provenance['source_sha']+':'+row['path'])
    assert native.read('source/'+row['path'])==data and sha(data)==row['sha256']
    assert git('rev-parse',provenance['source_sha']+':'+row['path']).decode().strip()==row['blob']
native_result=dict(commit=native_ref,members=26,sha256=sha(native_raw),source=provenance['source_sha'],
                   canonical_snapshots=len(provenance['source_files']),qualification='Design only; no native execution or grant of runtime authority.')

lock_ref='5342ece29f1fc8c02b5a7707f5bdb4d5c6a49562'
mapping=json.loads(git('show',lock_ref+':docs/plans/ci-dependency-installer-map-20261118.json'))
base=mapping['baseline'];workflows={}
for path in git('ls-tree','-r','--name-only',base,'--','.github/workflows').decode().splitlines():
    if path.endswith(('.yaml','.yml')):workflows[path]=yaml.safe_load(git('show',base+':'+path))
actual=[]
for path,workflow in workflows.items():
    for job,details in workflow.get('jobs',{}).items():
        for index,step in enumerate(details.get('steps',[])):
            script=step.get('run','')
            if re.search(r'\bpip\s+install\b',script):actual.append((path,job,index,script))
expected=[(row['workflow'],row['job'],row['step'],row['script']) for row in mapping['installers']]
assert sorted(actual)==sorted(expected)
assert len(actual)==mapping['direct_script_count']==41
assert len({row[0] for row in actual})==mapping['direct_workflow_count']==20 and len(workflows)==22
for row in mapping['installers']:
    assert git('rev-parse',base+':'+row['workflow']).decode().strip()==row['baseline_workflow_blob']
for row in mapping['helpers']:
    data=git('show',base+':'+row['path'])
    assert sha(data)==row['baseline_sha256'] and git('rev-parse',base+':'+row['path']).decode().strip()==row['baseline_git_blob']
    if row.get('definitions'):
        nodes={node.name:node for node in ast.walk(ast.parse(data)) if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef))}
        for name,bounds in row['definitions'].items():
            assert nodes[name].lineno==bounds['start'] and nodes[name].end_lineno==bounds['end']
lock_result=dict(commit=lock_ref,source=base,direct_scripts=len(actual),direct_workflows=20,workflows=22,
                 canonical_helpers=len(mapping['helpers']),qualification='Installer inventory and proposed lock design only; no resolution/install/native lock qualification.')
receipt=dict(phase2=phase_result,native_design=native_result,dependency_map=lock_result)
with (OUT/'verification.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt))
