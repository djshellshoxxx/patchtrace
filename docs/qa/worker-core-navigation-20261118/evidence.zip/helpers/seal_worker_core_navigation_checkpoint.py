"""Seal the reviewed portable worker/core/navigation milestone without release claims."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
SOURCE = '207eea9d4e125ac1d371139d4db803ddbc2b4c8a'
BASE = '9f4e1a57dc75de8d34ef9023bea2fb7619690f0b'
MAIN = '9c411ca3d7b47f950be5f0c6f01b3c54184554c6'
REMOTE_BASE = 'e78788791f03bd27b68e5891cd75ff0856b86342'
QA = ROOT / 'qa/worker-core-navigation-integration'
DEST = REPO / 'docs/qa/worker-core-navigation-20261118'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE and not git('status', '--porcelain')
tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
gate = json.loads((QA / 'combined-exit.json').read_text())
assert gate['exit'] == 0 and gate['source_after'] == SOURCE and not gate['status_after']
assert gate['imported_source_count'] == 498 and not gate['foreign_imports']
assert not gate['imported_source_drift'] and not gate['imported_sources_not_exact_git']
assert gate['original_probes_and_observations_unchanged'] and not gate['temp_retained']
counts = Counter()
for case in ET.parse(QA / 'combined.xml').getroot().findall('.//testcase'):
    skip = case.find('skipped')
    kind = 'failed' if case.find('failure') is not None else 'error' if case.find('error') is not None else (
        'xfail' if skip is not None and skip.get('type') == 'pytest.xfail' else 'skipped' if skip is not None else 'passed')
    counts[kind] += 1
assert dict(counts) == {'passed': 1103, 'skipped': 1}
scope = json.loads((QA / 'selected-nodes.json').read_text())
assert len(scope['node_files']) == 51
owners = json.loads((QA / 'source-owner-preservation.json').read_text())
assert owners['source'] == SOURCE and len(owners['files']) == 23
for row in owners['files']:
    assert sha((REPO / row['path']).read_bytes()) == row['sha256']
lint = json.loads((QA / 'ruff-receipts.json').read_text())
strict = json.loads((QA / 'strict-sites-comparison.json').read_text())
assert lint[0]['exit'] == 0 and lint[1]['exit'] == 1 and lint[1]['findings'] == 80
assert strict['same_path_code_selected_statement_multiset']
assert json.loads((QA / 'schema-check.json').read_text())['exit'] == 0
fresh = json.loads((QA / 'fresh-before-publication.json').read_text())
reads = {row['path']: json.loads(row['result']['structuredContent']['content']) for row in fresh['reads']}
assert reads['branches/main']['commit']['sha'] == MAIN
assert reads['pulls/316']['head']['sha'] == REMOTE_BASE
assert not reads['pulls/316']['merged'] and reads['pulls/316']['state'] == 'open'
commits = git('rev-list', '--reverse', BASE + '..' + SOURCE).decode().splitlines()
assert len(commits) == 24
assert all('[no release]' in git('show', '-s', '--format=%B', commit).decode() for commit in commits)

note = f'''# Portable worker, held core input and signal navigation checkpoint

## Exact candidate qualification — 2026-11-18

Clean candidate `{SOURCE}`, tree `{tree}`, passes **1,103 tests**,
with **one native Windows skip**, zero failures/errors/expected failures, in
**44.57 seconds** (46.26 seconds including coordinator verification). The
51 selected files contain all three affected author scopes, five publication/
packaging neighbors and four unchanged independent probes. All **498** loaded
PatchTrace modules match this commit's Git bytes; all **23** changed source,
test, tool and schema files since `{BASE}` match reviewed owner bytes.

Normal `python -m ruff check src tests tools` and
`python tools/generate_package_schemas.py --check` pass. The isolated strict S
scan, with ignore-noqa and no suppression, still exits1 on **80 unchanged
path/code/selected-statement sites**. This milestone does not close that gate.
The sole skip is native Windows junction creation; the duplicate-ZIP fixture
produces its expected warning. Full/platform/native/package/security acceptance
and beta readiness remain open.

## Reviewed changes

| Scope | Implemented behavior | Reviewed source and acceptance boundary |
| --- | --- | --- |
| Serial package worker grants | Strict operation/request/attempt/source bindings, fresh nonce and canonical grant digest, bounded wire size, explicit envelope version, cumulative feasible counters, one outstanding grant, original deadline and quiescence, atomic receipt validation, permanent failure on missing/malformed receipt. | `7259f86838c2181d6bdbcabe98c7a294a4499e8d`; portable records/accounting only. No worker launch, native handles, package intake caller or project admission. |
| Held core inputs | Qt-free optional path-bound readers, bounded read/PE/hash validation without source-path fallback, original error propagation, checkpoints during owned reads and immediately before the first-save COMMIT, preserved ordinary call shapes. | `9740860928c7911e6fa975528db1f7fa5ca1940b`; held provider owns source-read accounting and native identity. No KB propagation or native provider in this slice. No callback after committed save can enter creation rollback. |
| Signal navigation | The existing GUI action uses the unchanged live location validator before reveal and refuses unsupported representations through a 19-line helper. Current mode/cursor/evidence remain unchanged on refusal; valid decompiled navigation is preserved. | `9592f8b362537c0545010d4499e35770a248297e`; persisted/reopened Linux offscreen controls. Validator, detector, scoring, schema and enrichment storage behavior unchanged; existing UI line ceiling remains3077, current3069. |

Three defects reproduced during independent review were corrected with tests
before source changes:

1. A terminal worker receipt prevented later admission but still allowed
   `complete_output` to mutate counters before raising. The correction refuses
   both complete/fail callbacks before token or counter mutation. Original
   independent **2-failed/3-passed** evidence remains; preterminal late-cancel
   accounting and allocation cleanup remain valid.
2. Temporary stage unlink failure could replace the original held-input
   cancellation. Cleanup now preserves the exact primary exception and adds a
   fixed bounded possible-retention note. Successful-path cleanup failure still
   raises. Original independent **1-failed/51-passed** evidence and new
   **6-failed/15-passed** regression remain; independent corrected replay is
   **52 passed**.
3. Validating a stored assembly location was insufficient when the action
   always displayed decompiled text. Original root **1-failed/1-passed** evidence
   and author **4-failed/11-passed** controls remain. The helper explicitly
   refuses unsupported representations while preserving current decompiled
   behavior. The original stale-location **3-failed/4-passed** probe also passes
   unchanged in this integrated candidate.

The coordinator verified all author archive member hashes, canonical Git
snapshots, original independent files and source boundaries. Worker/core
first-source packets, correction packets, all navigation fixture/line-ceiling
failures and corrected receipts remain immutable at their original sources.
Counts from overlapping invocations are not added into coverage percentages.
Original 28 independent cases are replayed directly from unchanged files;
only observation destinations are routed to new directories, with their
original observations protected by hashes.

## Execution and preparation evidence

The reviewed offline guard installs network denial before test collection,
rejects inherited sockets and restricts Git to local file transport. The audit
records410 hostname events and11 inspected local fixture/import subprocesses,
with no network socket operation. An owned temporary directory outside any
Git repository was removed only after success. This guard is not a claim of a
qualified native product sandbox. No native or target binary was executed.

An initial coordinator scope assertion stopped before collection: an extra
existing publication-neighbor test had not belonged to the preceding CI gate.
The original helper and observed preflight failure are retained. That small
file was reviewed directly and kept in the scope; no test or assertion was
removed. The corrected harness distinguishes the four previously reviewed
neighbors from this additional direct review.

The complete command, selected files, environment, source ownership, collection,
JUnit, normal lint, strict scan, schema check, audit and post-run preservation
receipts are in this archive. The combined command uses the retained
`continuation_offline_pytest.py`, `full_batch_receipt` and unchanged
`phase2_observation_redirect` plugins, `QT_QPA_PLATFORM=offscreen`, explicit
candidate PYTHONPATH and an owned system temporary directory.

## Retained design and reconciliation evidence

The nine-family Phase2 reference disposition, dependency-installer map and
native package seam design are integrated as evidence/design records. They do
not implement wire compatibility, statistical calibration, hash-lock closure
or native package support. All131 original focal branch tips retain a
disposition; this does not close whole-branch residue or research work.

The prior KB held-reader/durable-linkage proposal is now independently checked:
49 payloads,27 exact source snapshots, frozen source27e4318b. Its two corrected
real-service authored controls demonstrate current path opens and the
after-project-create intent gap; the initial two fixture failures remain.
The next approved work is narrow propagation through existing KB/core services.
Native stage/FDI/process transfer, read-work accounting and durable package
provenance/reconciliation remain separate implementations and acceptance gates.

## Repository, prior publication and hosted state

At `{fresh['at']}`, main is `{MAIN}` and PR316 remains open/unmerged
at `{REMOTE_BASE}`. Its tree `a389462c90ad84960ad2c7ae26217baa83a92bcc`
equals local `{BASE}`. The preceding13-commit append-only publication,
exact remote object/ref readback and merge-preview parents are preserved here.
The prior CI gate remains1,028 passed/two skips/one known CODEX5 xfail at its
own f3b7a0e8 source; it is not relabeled as this new candidate.

Fresh metadata lists45 check runs for e787: full Linux/Windows QA and repeated
Qt jobs are in progress; Windows dependency inventory and strict security jobs
fail. Other success badges do not establish artifact or native acceptance.
Earlier independently hashed f3 artifacts retain the CP1252 inventory failure
and restricted native process-chain exit125. Read-only diagnosis identified
socket timeout errors and a separate unresolved descendant boundary; timeout
is not reclassified as network denial. No manual Windows/native/paid dispatch
has been requested and no native artifact was executed locally.

PR304 and307 remain blocked by actual-candidate full, Windows, native, package
and security gates. No PR is merged/closed and no branch is deleted. No main,
release/tag/deployment mutation occurs in this milestone. All24 local source/
design/QA commits retain `[no release]`; subsequent remote publication and
readback are separate receipts.

## Next workstreams and release limits

- CI owns bounded stderr diagnostics for the failed native chain, preserving
  every containment/permission/refusal decision; actual Windows build/runtime
  acceptance remains pending.
- Security/review owns an exact-source, spec/test-first Windows inventory UTF-8
  invocation correction, preserving isolated mode and raw strict JSON/exit
  validation. Native hosted replay and dependency hash closure remain required.
- CVE/KB owns the narrow held-reader propagation design and then approved
  existing-service implementation; saved-scope/global index/revision/approval
  checks and caller-thread SQLite remain required. Postcommit durability is
  separate, and expired native leases cannot be resurrected from pathnames.
- Root continues independent review, exact-candidate integration, branch/PR
  disposition and publication. Full current-source qualification and remaining
  analyst/CVE-to-function journeys remain incomplete. Frozen L1/L2/L3 outcomes
  are unchanged; no synthetic test supplies real binary accuracy or calibration.
'''

payloads = {'checkpoint-note.md': note.encode(), 'counts.json': (json.dumps(counts, indent=2)+'\n').encode()}
for label, path in (
    ('combined', QA),
    ('initial-harness-preflight', ROOT/'qa/worker-core-navigation-integration-preflight'),
    ('worker-core-root-review', ROOT/'qa/worker-core-root-review'),
    ('design-root-review', ROOT/'qa/followup-design-root-review'),
    ('navigation-root-review', ROOT/'qa/navigation-root-review')):
    for file in sorted(path.rglob('*')):
        if file.is_file() and '__pycache__' not in file.parts:
            payloads[label+'/'+file.relative_to(path).as_posix()] = file.read_bytes()
for folder in ('pw02-worker-independent', 'core-held-inputs-independent'):
    for file in sorted((ROOT/'qa'/folder).glob('*')):
        if file.is_file():
            payloads['independent/'+folder+'/'+file.name] = file.read_bytes()
for name in ('pw02-worker-independent-20261118.zip',
             'pw02-kb-held-reader-design-20261118.zip', 'pw02-kb-held-reader-design-20261118.manifest.json'):
    payloads['independent/'+name] = (ROOT/'qa'/name).read_bytes()
payloads['native-design/native-seam-design-addendum.md'] = (ROOT/'qa/pw02-local-packages/native-seam-design-addendum.md').read_bytes()
for name in ('objects-013.json', 'readback-before-ref.json', 'ref-update.json',
             'pr316-body.md', 'pr-update.json', 'final-readback.json'):
    payloads['preceding-publication/'+name] = (ROOT/'qa/ci-followup-publication'/name).read_bytes()
for name in ('run_worker_core_navigation_gate.py', 'scan_worker_core_navigation.py',
             'verify_worker_core_packets.py', 'verify_cleanup_navigation_packets.py',
             'verify_followup_design_records.py', 'run_navigation_root_probe.py',
             'run_navigation_root_probe_v2.py', 'continuation_offline_pytest.py',
             'full_batch_receipt.py', 'seal_worker_core_navigation_checkpoint.py'):
    payloads['helpers/'+name] = (ROOT/'ops'/name).read_bytes()
payloads['helpers/phase2_observation_redirect.py'] = (ROOT/'qa/phase2-contract-disposition/phase2_observation_redirect.py').read_bytes()
payloads['independent/test_phase2_navigation_boundary.py'] = (ROOT/'qa/phase2-contract-disposition/test_phase2_navigation_boundary.py').read_bytes()
for path in git('diff','--name-only',BASE,SOURCE,'--','src','tests','tools','.github','docs/specs','docs/schemas').decode().splitlines():
    payloads['candidate-source/'+path] = git('show',SOURCE+':'+path)
payloads['integration/history.txt'] = git('log','--reverse','--format=fuller',BASE+'..'+SOURCE)
payloads['integration/patch.diff'] = git('diff',BASE,SOURCE,'--','src','tests','tools','.github','docs/specs','docs/schemas')
records = [json.loads(line) for line in (ROOT/'qa/followup-integration/record-resolutions.jsonl').read_text().splitlines()]
payloads['integration/append-conflicts.json'] = (json.dumps([row for row in records if row['head'] in {BASE,*commits}],indent=2)+'\n').encode()
DEST.mkdir(exist_ok=False)
archive = DEST/'evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path,data in sorted(payloads.items()):
        z.writestr(path,data)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(set(z.namelist())) == len(payloads) and z.testzip() is None
    for path,data in payloads.items():
        assert z.read(path) == data
manifest = dict(source=SOURCE, tree=tree, sealed_utc=datetime.now(timezone.utc).isoformat(),
    archive=archive.name, archive_bytes=archive.stat().st_size, archive_sha256=sha(archive.read_bytes()),
    payloads=[dict(path=path,bytes=len(data),sha256=sha(data)) for path,data in sorted(payloads.items())])
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(DEST/'README.md').write_text(note+f'\n## Sealed archive\n\n{len(payloads)} verified payloads; {archive.stat().st_size:,} bytes. SHA-256 `{manifest["archive_sha256"]}`.\n')
short = f'''\n\n## Worker, core and navigation milestone — 2026-11-18, source207eea9d

Exact source `{SOURCE}` passes **1,103 tests, one native Windows skip**,
zero failures/errors/xfails,44.57s. The51-file gate preserves all28 unchanged
independent cases,23 reviewed owner paths and498 exact Git-pinned imports.
Normal Ruff and generated schemas pass; strict S remains80 unchanged findings.
Original terminal-counter, cleanup-primary-error and assembly-navigation reds,
fixture/preflight corrections and all preceding source-specific receipts remain.
[Complete checkpoint](../qa/worker-core-navigation-20261118/README.md).
Main remains `{MAIN}`; PR316 is open, PR304/307 blocked by final gates.
No merge/closure/tag/release/deployment or branch deletion occurred.
'''
with (REPO/'docs/plans/patchtrace-completion-matrix.md').open('a') as f:
    f.write(short+'''

| Feature / bounded scope | Current state | Completion | Remaining work | Source | Dependencies | Tests | Security | Owner | Acceptance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Portable serial worker accounting | Implemented and independently reviewed | D,R:50% for this slice | Native handoff/worker composition and final applicable gates |7259f868,PR316|Existing package contracts and original parent budget|Author/corrected/original-red receipts plus exact combined gate|No terminal mutation, refunds or resumed failed worker|CI + root|Native and whole package journey remain separate|
| Neutral held-input core API | Implemented and independently reviewed | D,R:50% for this slice | Existing KB propagation, real native provider, durable package linkage, final gates |97408609,PR316|Core ingestion/store ownership; provider lease|Author318,independent52,exact combined with original14 cases|No path fallback; bounded reads; original error survives cleanup; before-COMMIT checkpoint|Core + root|Real caller/native/journey and final G|
| Live signal navigation validation | Implemented and independently reviewed | D,R:50% for bounded action | Native/manual/frozen analyst acceptance and broader Phase2 work |9592f8b3,PR316|Unchanged live validator and persisted evidence|Author175,unchanged7+2 probes,exact combined|Refuse stale/unsupported locations before mode/cursor changes|GUI + root|Current decompiled action preserved; no assembly support claim|
| Whole local package fallback PW02 | Partial; no package-to-project route | None:0% of whole-feature milestones | Native stage/FDI/process transfer, KB adapter, read ledger, durable provenance and frozen journey |Portable slice plus retained designs|Qualified Windows lane and existing KB/core service|Portable authored scopes only|Lease/lifetime/original budget/durable project ownership remain required|CI + KB + core|Whole-feature D/R/J/G requires complete specified journey|

The Phase2 reference disposition and installer/native/KB designs are now reviewed
records. They do not implement hash locks, reference interchange or native
support. Completion is based on the existing D/R/J/G milestones, not test counts.
Windows inventory encoding and native descendant diagnostics are active focused
workstreams. Final full/platform/native/package/security/reproducibility gates,
real CVE/KB journeys and frozen research limitations remain open.
''')
with (REPO/'docs/plans/autonomous-consolidation-20261118/consolidation-ledger.md').open('a') as f:
    f.write(short.replace('../qa/','../../qa/'))
with (REPO/'docs/qa.md').open('a') as f:
    f.write(short.replace('../qa/','qa/'))
with (REPO/'tasks/todo.md').open('a') as f:
    f.write('''\n\n### Worker/core/navigation checkpoint — 2026-11-18

- [x] Verify preceding13-commit e787 PR316 publication and unchanged main/readback.
- [x] Independently review and port worker/core/navigation corrections and all original red evidence.
- [x] Pass exact207eea9d combined51-file gate:1,103 passes/one native skip;498 modules/23 owner paths exact; all28 independent cases unchanged.
- [x] Preserve normal lint/schema success and unchanged strict80 failure; retain preflight/fixture mistakes without changing assertions.
- [x] Verify reference/native/dependency/KB design evidence and append-only documentation reconciliations.
- [ ] Publish this checkpoint append-only with exact remote tree/parent/ref/preview readback.
- [ ] Complete focused Windows inventory UTF-8 fix and bounded native diagnostic source; obtain actual hosted evidence.
- [ ] Propagate held readers through existing KB services, then qualify native stage/FDI/process transfer, durable package linkage and complete frozen journey.
- [ ] Complete actual-candidate full/platform/native/package/security/reproducibility gates and remaining analyst/CVE-to-function workflows; main/beta acceptance remains blocked.
''')
print(json.dumps(dict(source=SOURCE,tree=tree,members=len(payloads),archive_bytes=archive.stat().st_size,archive_sha256=manifest['archive_sha256'])))
