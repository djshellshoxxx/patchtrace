# PW-02 joint map addendum after design sealing

This attributed clarification supplements the unchanged design checkpoint
`8de96581f9af5b6eabc79b763303c410d5f97dd4` and archive SHA-256
`7015cbfe58cda8a885d48bb1d25946169bbca4e031350c7eb27920a75fcce94d`.
It changes no source, schema, earlier receipt or native qualification claim.

The independent KB design owner confirmed the native/reader file division and
optional reader/checkpoint propagation after our packet was sealed. Its complete
map is `qa/pw02-kb-held-reader-design/README.md`; separate sealed archive
`qa/pw02-kb-held-reader-design-20261118.zip`, SHA-256
`c9be94c2e699a08ef394c26fd8b3cd542ae78f5d34d825edd8f4e3831626df3e`.

Two precise refinements govern the later held-reader/core slice:

1. A positive neutral ReadCheckpoint value includes PE/header reads as well as
   hashing. Record it in a separate finite UINT64 read-work ledger. It uses the
   original PackageBudget callback/work allowance, deadline and cancellation;
   it must not silently redefine `PackageUsage.hashed_input_bytes`, consume
   decompressor output allowance, refund output, or claim a new aggregate
   read-byte ceiling. One read is charged once, by the lease or the ordinary-path
   adapter. This clarification does not add a field to the portable worker grant
   or receipt schemas.
2. Preserve ProjectStore's existing complete verification **and fingerprint-cache
   rules**. The optional checkpoint cannot authorize a skipped verification;
   existing valid cache reuse remains possible, with deadline/cancel checks also
   on that path. The compact map's earlier phrase "always performed" should be
   read as preserving the verification requirement, not forcing a fresh full
   hash on every cache hit.

The separate KB design's section 8 supplies the later package provenance proposal:
preallocated project identity, a held-input intent marker, and read-only exact
committed-project reconciliation. These require their own root-reviewed facade
contract. They do not resurrect an expired reader, rewrite generic recovery, or
permit deletion of committed evidence.

The next authorized branch still implements only the portable serial worker-
grant/receipt boundary from `068513a7`. Native handles, jobs, core readers,
ProjectStore checkpoints and durable package provenance remain outside it.
