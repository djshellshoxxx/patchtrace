## Purpose

Consolidate the reviewed #304 → #307 chain and independently reproduced follow-up repairs while preserving original failures, source attribution, immutable evidence and the `[no release]` hold.

**This PR remains blocked for merge into main.** Actual-candidate full/platform/native/package, dependency/security and representative product-journey gates remain incomplete. No release, tag or deployment is authorized.

## Current published checkpoint

| Identity | Exact value |
| --- | --- |
| Canonical main | `9c411ca3d7b47f950be5f0c6f01b3c54184554c6` |
| Actual PR head | `e78788791f03bd27b68e5891cd75ff0856b86342` |
| Actual PR tree | `a389462c90ad84960ad2c7ae26217baa83a92bcc` |
| Equal-tree local checkpoint | `9f4e1a57dc75de8d34ef9023bea2fb7619690f0b` |
| Locally tested CI follow-up source | `f3b7a0e895c3b9928e08f93ac77d2afda5c56dd8` |
| Corresponding remote tested source | `abfd8a7e9c45dcb24863e8fcca78d1c283d4e1ca` |
| Tested-source tree | `de56f481ed4d18c196f6b069860d3f11035e375e` |

The final checkpoint changes QA/tracking records only; source, tests, tools, workflows, specifications and schemas equal the tested source. This equivalence does not claim a completed hosted/full/native run at the final head.

Publication appends **13 attributed commits** to prior actual head `f3f4492981f2c76c8d461d6a6d3eb1ac682fb996`. Every remote commit was independently reread for exact tree, ordered single parent, reviewed-local attribution and no-release marker before the non-force expected-head update. The preceding f3 milestone appended45 commits and retains its separate publication/evidence receipts. No main ref, PR merge/closure, branch deletion, release or deployment changed.

## New changes in this checkpoint

- **Corpus archive cache:** retain original Rizin/Ghidra archives; validate pin syntax, file type and SHA on cache hits and cold paths; extract into an exclusively fresh runtime directory. Corrupt/linked/nonregular archives and preexisting runtime objects fail before payload setup. This is a cooperative CI workspace boundary, without an active-writer race claim.
- **Full Linux smoke:** invoke the existing complete frozen smoke harness against the built executable, with a 900-second timeout, before archive/digest creation. This local gate checks builder behavior and source CLI smoke; a new frozen package was not built here.
- **Pure imports:** move Linux ctypes loading to actual native directory-publication dispatch. Native move logic, ownership checks and all32 original publication assertions remain unchanged.

Author failures, intermediate fixture/lint/collection errors, contrary controls and original probe bytes remain immutable. The older independent publication replay changes exactly two fixture injection targets from the removed private module attribute to the same imported ctypes module, in a new copy; every assertion and all other AST nodes remain identical.

## Exact-source verification

| Check | Result and boundary |
| --- | --- |
| Combined30-file affected gate | **1,028 passed /2 skipped /1 known xfailed**, zero failures/errors, **22.89s**, at local `f3b7a0e8` |
| Import audit | **221** project modules from the exact checkout; canonical Git bytes match, no foreign imports or drift |
| Owner-byte audit | All **10** changed source/test/tool/workflow paths since the preceding checkpoint match independently reviewed owner bytes |
| Normal Ruff | `ruff check src tests tools` passes |
| Strict security scan | **Fails:80 findings**, unchanged path/code/selected-statement multiset |
| Independent packet review | Cache54members/22Git snapshots; smoke+purity96members/43Git snapshots verified |
| Sealed checkpoint | **70 verified payloads**,718,877bytes; SHA-256 `3eda6ae51107d721b6122998cb55d343d6d3d3d8c1f1756de617ff36f48b07ed` |

The two skips require native Windows junction creation and host-denied AF_UNIX creation. CODEX5 dependency hash closure remains the one expected failure. Cache and full-smoke policy assertions now run as required tests. Network denial is installed before collection, inherited sockets are refused, Git is local-only, and a fresh owned system temporary directory is removed after successful verification. No tests or assertions are deselected.

The preceding broader gate remains **6,356 passed /18 skipped /3 expected failures** at source `068513a7`, with552 imports and101 owner paths verified. It is historical evidence for its own source, not a replacement for new-candidate full acceptance. Its later cache/smoke repairs do not rewrite those old counts.

## Newly inspected hosted evidence on the preceding f3 tree

The downloaded artifacts belong to PR preview `a94495abb6117400c138eaaa0127d260c3010094`, tree `e49299eabe4cff2304d9dbe15f94c3c79566af44`, equal to preceding actual f3. Four artifacts match API SHA-256, exact byte sizes and retained member hashes. Their native binaries were not executed locally.

- **Windows BinDiff:** native helper build and six authored controls pass, including the20/21-function synthetic pair. Actual pytest and `bindiff.json` **fail** the no-network control: restricted control process chain exit125. The job-level badge says success; it supplies no native acceptance.
- **Windows dependency profiles:** source guard and scanner installation proceed, but both runtime and packaging fail `python -I -m pip inspect --local` with CP1252 UnicodeEncodeError for U+1F44B. Neither product dependency audit is accepted.
- **Hosted static scan:** strict scan fails; its artifact now includes `bootstrap-pip.txt`, confirming the prior upload-retention repair. Complete hosted site comparison is a separate review.
- Other hosted full/native/platform jobs remain subject to their actual artifacts, source identities and required acceptance. Green, skipped or queued status alone is insufficient.

These are prior-tree observations and do not qualify this new head.

## Retained consolidation and product work

The reviewed chain preserves CVE/KB lineage, source and binary identity, chronology/architecture boundaries, advisory circularity protection, ownership/publication and retained inventories. Later bounded slices include saved-scope admission, A/A failure classification, optional COFF symbol masking, strict-scan receipt retention, Windows source observations, PW02 pure contracts and immutable workflow action references.

All131 original branch-name focal scopes have exact-tip dispositions. This does not close all whole-branch residue or establish a product completion percentage. Original research outcomes, failures and historical receipts are unchanged.

## Remaining gates and assigned work

- Independently review portable serial worker grants and neutral core held-input/checkpoint propagation; then qualify native transfer/stage/FDI, existing KB propagation, durable provenance and the actual frozen intake journey.
- Repair the reproduced persisted-signal navigation boundary with current run/artifact/side/address/excerpt validation, preserving scoring/confidence semantics.
- Diagnose and fix the hosted Windows encoding and restricted-control failures with preserved original evidence and independent regression.
- Complete platform/profile dependency hash locks and exact-source acceptance.
- Obtain complete actual-candidate Linux/Windows full suites, repeated Qt, native acceptance, frozen ZIP/installer/Linux packages, dependency/security and reproducibility evidence.
- Keep L1's original six failures, L2 independent-ground-truth requirement and L3 source/permission/binary blockers explicit.

## Reviewable records

- [Current CI follow-up and its exact limits](https://github.com/djshellshoxxx/patchtrace/blob/e78788791f03bd27b68e5891cd75ff0856b86342/docs/qa/ci-followup-20261118/README.md)
- [Current evidence manifest](https://github.com/djshellshoxxx/patchtrace/blob/e78788791f03bd27b68e5891cd75ff0856b86342/docs/qa/ci-followup-20261118/manifest.json)
- [Preceding broader continuation](https://github.com/djshellshoxxx/patchtrace/blob/e78788791f03bd27b68e5891cd75ff0856b86342/docs/qa/continuation-tail-20261118/README.md)
- [Completion matrix](https://github.com/djshellshoxxx/patchtrace/blob/e78788791f03bd27b68e5891cd75ff0856b86342/docs/plans/patchtrace-completion-matrix.md)
- [Consolidation ledger](https://github.com/djshellshoxxx/patchtrace/blob/e78788791f03bd27b68e5891cd75ff0856b86342/docs/plans/autonomous-consolidation-20261118/consolidation-ledger.md)

**No beta-ready classification; no main merge, release, tag or deployment.**
