"""Run the reviewed worker/core/navigation union with immutable independent probes."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
SOURCE = '207eea9d4e125ac1d371139d4db803ddbc2b4c8a'
BASE = '9f4e1a57dc75de8d34ef9023bea2fb7619690f0b'
OUT = ROOT / 'qa/worker-core-navigation-integration'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, data):
    with path.open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE and not git('status', '--porcelain')
assert not OUT.exists()
OUT.mkdir()
receipts = [ROOT / path for path in (
    'qa/pw02-local-packages/worker-terminal/final-provenance.json',
    'qa/core-held-inputs-cleanup/affected.command.json',
    'qa/signal-navigation-validation/final-representation-affected.command.json')]
nodes = set()
for path in receipts:
    data = json.loads(path.read_text())
    nodes.update(arg for arg in data.get('argv', data.get('pytest_arguments', []))
                 if arg.startswith('tests/') and arg.endswith('.py'))
neighbors = ['tests/test_unified_packaging.py', 'tests/test_directory_publication.py',
             'tests/test_directory_publication_imports.py', 'tests/test_offline_bundle.py',
             'tests/test_owned_publication.py']
prior = json.loads((ROOT / 'qa/ci-followup-integration/selected-nodes.json').read_text())
for path in neighbors:
    assert path in prior['node_files'], path
    assert git('show', SOURCE + ':' + path) == git('show', prior['source'] + ':' + path)
nodes.update(neighbors)
nodes = sorted(nodes)
external = [ROOT / path for path in (
    'qa/pw02-worker-independent/test_terminal_accounting.py',
    'qa/core-held-inputs-independent/test_core_reader_boundary.py',
    'qa/phase2-contract-disposition/test_phase2_navigation_boundary.py',
    'qa/navigation-root-review/test_representation_boundary_v2.py')]
expected = [
    '5396faa2c3934dbabc4b889949c10695efe490fa318ecaa235643f7d3a4dcc29',
    'b7b5ad118cfd8b4b15fd6e1276d3dff0136c21f7b8df555b21db386fda49c1ed',
    '61b5d7c21778e12ba71bc6d32a0779f7d1d457656955bf2bfdab64c8c5953688',
    '828f531e083ec4dc04733298ca976e1da5e9c0648db8af08c391627ba808f3a5']
for path, wanted in zip(external, expected, strict=True):
    assert digest(path) == wanted, path
nodes.extend(map(str, external))
observations = [*sorted((ROOT / 'qa/phase2-contract-disposition/navigation-observations').glob('*.json')),
                *sorted((ROOT / 'qa/navigation-root-review/fixture-corrected-observations').glob('*.json'))]
protected = {str(path): digest(path) for path in [*external, *observations]}
scope = dict(source=SOURCE, tree=git('rev-parse', 'HEAD^{tree}').decode().strip(),
    author_command_receipts={str(path): digest(path) for path in receipts},
    previous_reviewed_unchanged_neighbors=neighbors, node_files=nodes,
    selected_file_hashes=[dict(path=node, sha256=digest(Path(node) if Path(node).is_absolute() else REPO / node)) for node in nodes],
    original_probe_and_observation_hashes=protected,
    observation_only_redirect='Unchanged phase2_observation_redirect plugin plus existing v2 probe environment destination; no input or assertion adaptation.')
write(OUT / 'selected-nodes.json', scope)

owners = {}
for owner, paths in {
    '7259f86838c2181d6bdbcabe98c7a294a4499e8d': [
        'src/patchtrace/acquisition/package_budget.py', 'src/patchtrace/acquisition/package_worker_contracts.py',
        'tests/package_worker_support.py', 'tests/test_package_worker_contracts.py',
        'tests/test_package_worker_edges.py', 'tests/test_package_worker_grants.py',
        'tests/test_package_worker_terminal.py', 'tools/generate_package_schemas.py',
        'docs/schemas/local-package/PackageWorkerBinding.json', 'docs/schemas/local-package/PackageWorkerGrant.json',
        'docs/schemas/local-package/PackageWorkerReceipt.json'],
    '9740860928c7911e6fa975528db1f7fa5ca1940b': [
        'src/patchtrace/input_readers.py', 'src/patchtrace/ingestion.py', 'src/patchtrace/service.py',
        'src/patchtrace/persistence.py', 'tests/held_input_support.py',
        'tests/test_creation_operation_checkpoint.py', 'tests/test_ingestion_cleanup_errors.py',
        'tests/test_ingestion_held_inputs.py', 'tests/test_input_readers.py'],
    '9592f8b362537c0545010d4499e35770a248297e': [
        'src/patchtrace/ui.py', 'src/patchtrace/ui_signal_navigation.py', 'tests/test_signal_location_navigation.py'],
}.items():
    owners.update({path: owner for path in paths})
changed = git('diff', '--name-only', BASE, SOURCE, '--', 'src', 'tests', 'tools', '.github', 'docs/schemas', 'pyproject.toml').decode().splitlines()
assert set(changed) == set(owners), (set(changed) - set(owners), set(owners) - set(changed))
proofs = []
for path in changed:
    raw = git('show', SOURCE + ':' + path)
    assert raw == git('show', owners[path] + ':' + path) == (REPO / path).read_bytes()
    proofs.append(dict(path=path, reviewed_source=owners[path], sha256=digest(REPO / path), bytes=len(raw)))
write(OUT / 'source-owner-preservation.json', dict(base=BASE, source=SOURCE, files=proofs))

owned = Path(tempfile.mkdtemp(prefix='patchtrace-worker-core-navigation-'))
assert not any((path / '.git').exists() for path in (owned, *owned.parents))
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1',
    PYTHONPATH=os.pathsep.join(map(str, [REPO / 'src', REPO / 'tests', REPO, ROOT / 'ops', ROOT / 'qa/phase2-contract-disposition'])),
    QT_QPA_PLATFORM='offscreen', QT_SCALE_FACTOR='1',
    GIT_ALLOW_PROTOCOL='file', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null', GIT_TERMINAL_PROMPT='0',
    PATCHTRACE_PHASE2_OBSERVATIONS=str(OUT / 'phase2-observations'),
    PATCHTRACE_NAV_REVIEW_OBSERVATIONS=str(OUT / 'representation-observations'),
    PATCHTRACE_OFFLINE_GUARD_RECEIPT=str(OUT / 'combined-offline-guard.json'),
    PATCHTRACE_BATCH_COLLECTION_RECEIPT=str(OUT / 'combined-collection.json'))
command = [sys.executable, str(ROOT / 'ops/continuation_offline_pytest.py'), '-q', '-ra',
    '-p', 'no:cacheprovider', '-p', 'full_batch_receipt', '-p', 'phase2_observation_redirect',
    *nodes, '--basetemp=' + str(owned / 'pytest'), '--junitxml=' + str(OUT / 'combined.xml')]
write(OUT / 'combined-command.json', dict(source=SOURCE, tree=scope['tree'], argv=command, cwd=str(REPO),
    environment={key: value for key, value in env.items() if key in ('PYTHONPATH', 'PYTHONDONTWRITEBYTECODE',
        'QT_QPA_PLATFORM', 'QT_SCALE_FACTOR', 'GIT_ALLOW_PROTOCOL', 'GIT_CONFIG_NOSYSTEM', 'GIT_CONFIG_GLOBAL',
        'GIT_TERMINAL_PROMPT', 'PATCHTRACE_PHASE2_OBSERVATIONS', 'PATCHTRACE_NAV_REVIEW_OBSERVATIONS')},
    owned_system_temp=str(owned), started_utc=datetime.now(timezone.utc).isoformat(), timeout_seconds=300,
    helper_sha256={str(path): digest(path) for path in (Path(__file__), ROOT / 'ops/continuation_offline_pytest.py',
        ROOT / 'ops/full_batch_receipt.py', ROOT / 'qa/phase2-contract-disposition/phase2_observation_redirect.py')}))
started = time.monotonic()
try:
    with (OUT / 'combined.log').open('x') as stream:
        result = subprocess.run(command, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=300)
    code = result.returncode
except subprocess.TimeoutExpired:
    code = 124
collection_path = OUT / 'combined-collection.json'
collection = json.loads(collection_path.read_text()) if collection_path.exists() else {}
foreign, drift, non_git = [], [], []
for name, row in collection.get('final_sources', {}).items():
    path = Path(row['path'])
    if not path.is_relative_to(REPO / 'src'):
        foreign.append(dict(module=name, path=str(path)))
        continue
    if digest(path) != row['sha256']:
        drift.append(str(path))
    if hashlib.sha256(git('show', SOURCE + ':' + path.relative_to(REPO).as_posix())).hexdigest() != row['sha256']:
        non_git.append(str(path))
unchanged = all(digest(path) == wanted for path, wanted in protected.items())
receipt = dict(exit=code, elapsed=time.monotonic()-started,
    source_after=git('rev-parse', 'HEAD').decode().strip(), status_after=git('status', '--porcelain').decode(),
    imported_source_count=len(collection.get('final_sources', {})), foreign_imports=foreign,
    imported_source_drift=drift, imported_sources_not_exact_git=non_git,
    original_probes_and_observations_unchanged=unchanged, owned_system_temp=str(owned), temp_retained=True)
valid = receipt['source_after'] == SOURCE and not receipt['status_after'] and not foreign and not drift and not non_git and unchanged
if code == 0 and valid:
    shutil.rmtree(owned)
    receipt['temp_retained'] = False
write(OUT / 'combined-exit.json', receipt)
print(json.dumps(receipt))
print('\n'.join((OUT / 'combined.log').read_text().splitlines()[-45:]))
assert valid
raise SystemExit(code)
