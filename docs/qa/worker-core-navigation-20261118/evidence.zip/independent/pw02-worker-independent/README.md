# Independent PW-02 worker integration review — 2026-11-18

## Finding and exact evidence

At exact worker source **eb50b0283cf7a46e7bd25ffc23cd78b18dfeb2e0**, the
terminal contract is not fully enforced. `PackageBudget.complete_output`
(`package_budget.py:186–198`) consumes an owned pending token and updates known
confirmed bytes before `check()` observes `_worker_closed`. `worker_receipt()`
sets that flag at line 333. An exported failed receipt can therefore report zero
confirmed bytes while a later rejected completion changes the worker's snapshot
to one or three bytes.

The unchanged authored external probe is `test_terminal_accounting.py`.
`terminal-red.log/xml` records **2 failed / 3 passed**, zero setup errors/skips,
in 0.25 seconds. All nine imported project modules match the exact canonical
source, with no network or child creation attempts. Source snapshots, command,
imports and exit records are adjacent. The inspected author checkout was QA tip
`f427186b9a9e3ba70dbdf90e18b63a5d90315313`, with code/tests equal to the source.
The exact source tree is `e21808397bab4269ed3bf878989816b885e2755e`.

This is a **terminal accounting consistency gap**. It contradicts the spec and
README boundary that only owned allocation cleanup remains legal after terminal
export. It does not establish unsafe extraction or project admission. The
positive control shows that valid failed reconciliation retains the reservation,
marks permanent failure, and refuses further parent hashing and replay. A guard
before terminal-state mutation can preserve useful known-byte accounting when a
write completes after cancellation but *before* terminal export. Root assigned
the narrow correction to the original worker author; this review made no source
change and does not claim that correction has passed.

## Reviewed interactions

| Boundary | Source-backed assessment |
|---|---|
| Original deadline | `PackageBudget.__init__`, `from_worker_grant`, `_time`, and grant validation retain the start/deadline and refuse backward/pre-issuance time. Derived budgets do not restart the timer. `reconcile_worker` keeps the parent's observed time rather than rewinding to the child. |
| Cumulative accounting | The grant captures prior counts; worker derivation applies them. Receipt validation compares all monotone counters, captured lower limits, new-entry capacity and exact source/request/attempt/grant identity before applying usage. Live allocation count can fall only under the documented cleanup/accounting rules; peak is monotone. |
| Cancellation precedence | A preterminal completed write records known actual bytes before observing cancellation. Valid receipt consumption is applied before later parent cancellation/deadline is surfaced. Invalid or missing receipts retain prior known counters and mark unobserved usage, with no retry. |
| Serial lifetime | Issuance requires quiescent local resources and one outstanding grant. Parent counter mutation and child delegation refuse. Native worker termination is still a future caller obligation; receipt observation time is not a termination proof. |
| Terminal lifetime | **Finding above:** new confirmed bytes can appear after terminal receipt. Owned allocation cleanup is explicitly allowed and passes the independent control. |
| Held-reader/core seam | The separate core source `b85a0cf7` exposes a callable `(read_bytes: int) -> None`; the worker records intentionally contain no core read-work field. No adapter connects them in either slice. Positive core read work must not be translated into decompressor output or silently redefine `hashed_input_bytes`. |
| Future provider ordering | The parent must wait for actual supervised worker termination, validate/reconcile its receipt, then lend the operation-held rooted reader while retaining original source/output locks. The future callback needs the same original deadline/cancel and a separate finite read-work ledger. `check()` alone observes time/cancel and is allowed during a grant; it does not establish reader ownership or worker completion. |
| Strict wire boundary | The existing strict/frozen records, bounded JSON parser and identity validation reject coercion, duplicate keys, additional fields, invalid envelopes, nonfinite values and out-of-range counts. A digest binds data; it does not authenticate a worker or prove writes. |

I read the full new worker contract and budget implementation, the relevant
package usage/parse models, the spec and receipt, and the cumulative/deadline/
terminal author controls. The independent executable selection is the five
external cases, not a replay or acceptance claim for the author's complete
441-case gate. The terminal finding blocks this review's acceptance of the
stated terminal contract pending an exact corrected replay.

## Scope and preservation

No core/package/native/process source was edited. These controls use only
authored in-process records and clocks. They do not create a worker, inspect a
package, execute a target, exercise Windows sharing, admit a project or supply
frozen/hosted/release evidence. The portable contract cannot itself prove the
truth of native receipt counts, actual resource lifetime, rooted file identity,
held read semantics or durable provenance. Those remain the assigned later
native/KB/facade layers.

The probe bytes, first result and source snapshots are immutable. A corrected
source must use a new runner/label or explicit new source-pin copy while retaining
this original. `run_review.py` requires a fresh output label, canonical code-byte
equality and no test-time network/child attempts. The archive/manifest adjacent
to this directory retain every packet payload and can be independently rehashed.
