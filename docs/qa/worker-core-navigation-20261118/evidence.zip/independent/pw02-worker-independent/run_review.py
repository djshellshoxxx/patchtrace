"""Bounded exact-source review runner; no native/network/process test work."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import ssl  # preload before socket creation is denied by the audit hook
import subprocess
import sys
import tempfile
import time

ROOT = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages')
QA = Path(__file__).resolve().parent
SOURCE = 'eb50b0283cf7a46e7bd25ffc23cd78b18dfeb2e0'
LABEL = sys.argv[1]
FILES = sys.argv[2:]
assert LABEL.replace('-', '').isalnum() and FILES
for suffix in ('command.json', 'xml', 'imports.json', 'exit.json'):
    assert not (QA / f'{LABEL}.{suffix}').exists(), 'receipt label already exists'
sys.dont_write_bytecode = True
sys.path[:0] = [str(ROOT / 'src'), str(ROOT)]
os.environ['PYTHONPATH'] = str(ROOT / 'src')
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
environment = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, env=environment)


head = git('rev-parse', 'HEAD').decode().strip()
assert git('diff', '--name-only', SOURCE, '--', 'src', 'tests', 'tools', 'docs/schemas') == b''
blobs = {}
for item in git('ls-tree', '-r', '-z', SOURCE, 'src').split(b'\0'):
    if not item:
        continue
    metadata, name = item.split(b'\t', 1)
    blobs[name.decode()] = metadata.split()[2].decode()
import pytest

attempts = []


def audit(event, args):
    if event in {'socket.__new__', 'socket.connect', 'subprocess.Popen', 'os.system', 'os.posix_spawn'}:
        attempts.append(event)
        raise AssertionError('review forbids network or child creation')


started = time.monotonic()
with tempfile.TemporaryDirectory(prefix='pw02-worker-review-') as temp:
    arguments = ['-q', '-p', 'no:cacheprovider', '--basetemp', str(Path(temp) / 'pytest'),
                 *FILES, f'--junitxml={QA}/{LABEL}.xml']
    (QA / f'{LABEL}.command.json').write_text(json.dumps({
        'source_commit': SOURCE, 'checkout_head': head, 'cwd': str(ROOT),
        'argv': [sys.executable, str(Path(__file__).resolve()), LABEL, *FILES],
        'pytest_arguments': arguments,
        'environment': {'PYTHONPATH': str(ROOT / 'src'), 'QT_QPA_PLATFORM': 'offscreen',
                        'PYTHONDONTWRITEBYTECODE': '1'},
        'test_files': [{'path': str(Path(p).resolve()),
                        'sha256': hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in FILES],
    }, indent=2) + '\n')
    sys.addaudithook(audit)
    outcome = int(pytest.main(arguments))
modules, drift = [], []
for name, module in sorted(sys.modules.items()):
    if not name.startswith('patchtrace') or not getattr(module, '__file__', None):
        continue
    path = Path(module.__file__).resolve()
    record = {'name': name, 'path': str(path)}
    if not path.is_relative_to(ROOT / 'src'):
        drift.append(name)
    else:
        relative = path.relative_to(ROOT).as_posix()
        raw = path.read_bytes()
        actual_blob = hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest()
        record.update(relative_path=relative, sha256=hashlib.sha256(raw).hexdigest(),
                      git_blob=actual_blob, expected_git_blob=blobs.get(relative))
        if actual_blob != blobs.get(relative):
            drift.append(name)
    modules.append(record)
(QA / f'{LABEL}.imports.json').write_text(json.dumps({
    'source_commit': SOURCE, 'modules': modules, 'drift': drift,
}, indent=2) + '\n')
result = outcome if not drift and not attempts else 1
(QA / f'{LABEL}.exit.json').write_text(json.dumps({
    'source_commit': SOURCE, 'pytest_exit': outcome, 'exit_code': result,
    'project_imports': len(modules), 'drift': drift, 'denied_attempts': attempts,
    'seconds': time.monotonic() - started,
}, indent=2) + '\n')
raise SystemExit(result)
