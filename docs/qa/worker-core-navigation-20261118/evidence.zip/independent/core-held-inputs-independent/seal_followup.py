"""Seal a separate corrected-source review while retaining the initial red packet."""
import hashlib
import json
import os
import subprocess
import zipfile
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/c7a9e8d98848/security-residual-qa')
SOURCE = '9740860928c7911e6fa975528db1f7fa5ca1940b'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    archive, manifest = OUT / 'followup-evidence.zip', OUT / 'followup-manifest.json'
    if archive.exists() or manifest.exists() or (OUT / 'followup-source').exists():
        raise SystemExit('refusing to overwrite review follow-up')
    originals = {'test_core_reader_boundary.py': 'b7b5ad118cfd8b4b15fd6e1276d3dff0136c21f7b8df555b21db386fda49c1ed',
                 'evidence.zip': '3ffba7099a7e518fd35badc9ede8c6e494cd25705e7f6ad43e4d0c8139dd08a2'}
    if any(sha((OUT / name).read_bytes()) != expected for name, expected in originals.items()):
        raise SystemExit('initial review evidence changed')
    env = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1', GIT_ALLOW_PROTOCOL='file')
    source_rows = []
    for name in ('src/patchtrace/ingestion.py', 'docs/specs/core-held-inputs.md',
                 'tests/test_ingestion_cleanup_errors.py'):
        data = subprocess.check_output(['git', '--no-replace-objects', 'show', SOURCE + ':' + name],
                                       cwd=ROOT, env=env)
        target = OUT / 'followup-source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        source_rows.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
    paths = [OUT / name for name in ('followup-README.md', 'run_corrected.py', 'run_review.py',
             'test_core_reader_boundary.py', 'replay.log', 'replay.xml', 'replay-receipt.json',
             'seal_followup.py')]
    paths += sorted(path for path in (OUT / 'followup-source').rglob('*') if path.is_file())
    rows = []
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for path in paths:
            data = path.read_bytes()
            name = path.relative_to(OUT).as_posix()
            zipped.writestr(name, data)
            rows.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
    with zipfile.ZipFile(archive) as zipped:
        if len(zipped.namelist()) != len(set(zipped.namelist())) or zipped.testzip():
            raise SystemExit('archive CRC or member failure')
        if any(sha(zipped.read(row['path'])) != row['sha256'] for row in rows):
            raise SystemExit('archive hash failure')
    data = archive.read_bytes()
    run = json.loads((OUT / 'replay-receipt.json').read_text())
    record = {'source': SOURCE, 'spec_tests': '072c36965b3807547adb6895aff1259a1599caad',
              'disposition': 'accepted within portable core reader/checkpoint scope',
              'result': {'passed': 52, 'failed': 0, 'skipped': 0, 'seconds': 0.60},
              'loaded_modules': len(run['imports']), 'source_drift': run['source_drift'],
              'audit_attempts': run['attempts'], 'originals_verified': originals,
              'source_snapshots': source_rows,
              'archive': {'path': archive.name, 'bytes': len(data), 'sha256': sha(data), 'members': len(rows)},
              'files': rows}
    with manifest.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
    print(json.dumps({key: value for key, value in record.items() if key not in {'files', 'source_snapshots'}}))


if __name__ == '__main__':
    main()
