"""Preserve a bounded independent review without altering author sources or old receipts."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import zipfile
from pathlib import Path

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/c7a9e8d98848/security-residual-qa')
SOURCE = 'b85a0cf7bf135e9431677737613000707553b192'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    archive, manifest = OUT / 'evidence.zip', OUT / 'manifest.json'
    if archive.exists() or manifest.exists() or (OUT / 'source').exists():
        raise SystemExit('refusing to overwrite independent evidence')
    env = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1', GIT_ALLOW_PROTOCOL='file')
    names = ['src/patchtrace/' + name for name in ('input_readers.py', 'ingestion.py',
             'service.py', 'persistence.py')]
    names += ['docs/specs/core-held-inputs.md', 'tests/held_input_support.py',
              'tests/test_input_readers.py', 'tests/test_ingestion_held_inputs.py',
              'tests/test_creation_operation_checkpoint.py']
    snapshots = []
    for name in names:
        data = subprocess.check_output(['git', '--no-replace-objects', 'show', SOURCE + ':' + name],
                                       cwd=ROOT, env=env)
        target = OUT / 'source' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        snapshots.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
    diff = subprocess.check_output(['git', '--no-replace-objects', 'diff', SOURCE,
        'c791ed4e8a9019541c6789f3cd025d963b3ae8ec', '--', 'docs/specs/core-held-inputs.md'],
        cwd=ROOT, env=env)
    (OUT / 'author-qa-spec-precision.patch').write_bytes(diff)
    rows = []
    payload = sorted(path for path in OUT.rglob('*') if path.is_file()
                     and '__pycache__' not in path.parts and path not in {archive, manifest})
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for path in payload:
            data = path.read_bytes()
            name = path.relative_to(OUT).as_posix()
            zipped.writestr(name, data)
            rows.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
    with zipfile.ZipFile(archive) as zipped:
        if len(zipped.namelist()) != len(set(zipped.namelist())) or zipped.testzip():
            raise SystemExit('archive member or CRC failure')
        for row in rows:
            if sha(zipped.read(row['path'])) != row['sha256']:
                raise SystemExit('archive member hash mismatch')
    data = archive.read_bytes()
    run = json.loads((OUT / 'initial-receipt.json').read_text())
    record = {'source': SOURCE, 'disposition': 'one bounded operation-error precedence mismatch',
              'tests': {'failed': 1, 'passed': 51, 'skipped': 0},
              'loaded_modules': len(run['imports']), 'source_drift': run['source_drift'],
              'audit_attempts': run['attempts'], 'canonical_snapshots': snapshots,
              'archive': {'path': archive.name, 'bytes': len(data), 'sha256': sha(data),
                          'members': len(rows)}, 'files': rows}
    with manifest.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
    print(json.dumps({key: value for key, value in record.items() if key not in {'files', 'canonical_snapshots'}}))


if __name__ == '__main__':
    main()
