"""Replay the unchanged original controls at the appended core correction."""
import run_review

run_review.SOURCE = '9740860928c7911e6fa975528db1f7fa5ca1940b'
raise SystemExit(run_review.main())
