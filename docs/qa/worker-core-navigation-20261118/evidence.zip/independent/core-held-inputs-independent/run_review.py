"""Pinned independent offline controls, with immutable logs and source ownership checks."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path('/workspace/scratch/c7a9e8d98848/security-residual-qa')
OUT = Path(__file__).resolve().parent
SOURCE = 'b85a0cf7bf135e9431677737613000707553b192'


def main():
    phase = sys.argv[1]
    if phase not in {'initial', 'replay'}:
        raise SystemExit('unknown review phase')
    log, junit, receipt = (OUT / (phase + suffix) for suffix in ('.log', '.xml', '-receipt.json'))
    if any(path.exists() for path in (log, junit, receipt)):
        raise SystemExit('refusing to overwrite review evidence')
    os.chdir(ROOT)
    env = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1', GIT_ALLOW_PROTOCOL='file')
    tree = subprocess.check_output(['git', '--no-replace-objects', 'ls-tree', '-rz', SOURCE],
                                   cwd=ROOT, env=env)
    objects = {}
    for item in tree.split(b'\0'):
        if item:
            header, name = item.split(b'\t', 1)
            objects[name.decode()] = header.split()[2].decode()
    sys.path[:0] = [str(ROOT / 'src'), str(ROOT), str(ROOT / 'tests'), str(OUT)]
    sys.dont_write_bytecode = True
    os.environ.update(PYTHONPATH=str(ROOT / 'src') + os.pathsep + str(ROOT),
                      QT_QPA_PLATFORM='offscreen', PYTHONDONTWRITEBYTECODE='1',
                      GIT_NO_REPLACE_OBJECTS='1', GIT_ALLOW_PROTOCOL='file')
    attempts = []

    def audit(event, args):
        if event in {'socket.__new__', 'socket.connect', 'socket.bind', 'subprocess.Popen',
                     'os.system', 'os.posix_spawn', 'os.fork', 'os.exec'}:
            attempts.append(event)
            raise PermissionError('core independent review forbids network/child creation')

    sys.addaudithook(audit)
    import pytest
    tests = [str(OUT / 'test_core_reader_boundary.py'), 'tests/test_input_readers.py',
             'tests/test_ingestion_held_inputs.py', 'tests/test_creation_operation_checkpoint.py']
    argv = ['-q', *tests, '--junitxml=' + str(junit),
            '--basetemp=' + tempfile.mkdtemp(prefix='patchtrace-core-independent-'), '-p', 'no:cacheprovider']
    with log.open('x', encoding='utf-8', newline='\n') as stream:
        previous = sys.stdout, sys.stderr
        sys.stdout = sys.stderr = stream
        try:
            code = int(pytest.main(argv))
        finally:
            sys.stdout, sys.stderr = previous
    imports, drift = [], []
    for name, module in sorted(sys.modules.items()):
        if name.startswith('patchtrace') and getattr(module, '__file__', None):
            path = Path(module.__file__).resolve()
            if not path.is_relative_to(ROOT / 'src'):
                drift.append(str(path))
                continue
            data = path.read_bytes()
            relative = path.relative_to(ROOT).as_posix()
            blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data,
                                usedforsecurity=False).hexdigest()
            if objects.get(relative) != blob:
                drift.append(relative)
            imports.append({'module': name, 'path': relative, 'git_blob': blob,
                            'sha256': hashlib.sha256(data).hexdigest()})
    record = {'source': SOURCE, 'python': sys.version, 'executable': sys.executable,
              'argv': argv, 'exit_code': code, 'attempts': attempts, 'imports': imports,
              'source_drift': drift, 'qualification': 'portable authored core mechanics only'}
    with receipt.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
    print(json.dumps({key: value for key, value in record.items() if key != 'imports'}))
    if attempts or drift:
        raise SystemExit('review boundary or source drift')
    return code


if __name__ == '__main__':
    raise SystemExit(main())
