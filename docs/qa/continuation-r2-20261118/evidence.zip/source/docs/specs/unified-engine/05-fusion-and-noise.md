# SPEC-31 / 05 Fusion (independence components, evidence classes, decisions) and L2 noise control (proof tiers)

Status: S0b built the fusion and the S0 channels (s6). S3 built the IR channels C0-C5 with the operand classifier, alignment, DATA-MAP/1, UNCH/1, COS-ADDR/1, COS-LAYOUT/1, EH-EQ and MAT-ANCHOR over them (2026-10-14, `src/patchtrace/unified/facts/`; the built contract, the deviations and the open limits are in s7). `FactsContext.build(..., ir_sides=)` switches the IR mode on; `compute.py` does not pass it yet (integration owner, s7). S3b (2.8) built the extractor's `decompile` mode with `decompile_side` and its strict reader (03 s12.9), `FactsContext.build(decompiled=)` for C6 of a pair without Ghidriff code and the row selection `facts/refacts.py` (s7); the `refacts` worker mode that drives them is the integration owner's.

Basis: R05 s0-s4 (cited, not repeated); review corrections R-xx in [11-review-log](11-review-log.md). Owner slices: S0b (fusion, S0 channels, verdicts), S3 (IR channels, DATA-MAP, proofs), S3b (on-demand decompile). Hard rules restated as invariants: no averaging, conflicts preserved, missing = unknown, no probability, AI never decides. Numbers: L-xx (02 s6).

## 1. Fusion (`fusion/components.py`, `fusion/arbiter.py`)
### 1.1 Evidence families, components and evidence classes (registry data, D-08)

| Family | Sources / steps | Tags | Joining tags |
|---|---|---|---|
| F-GHIDRIFF | every `ghidriff` atom | D_ghidra, D_symbols, D_callgraph, D_compiler | all |
| F-BINDIFF | `bindiff` | D_ghidra (Ghidra BinExport) or D_ida, D_symbols, D_callgraph | all |
| F-DIAPHORA | `diaphora` | D_ida, D_hexrays, D_symbols, D_callgraph | all |
| F-RZDIFF | `rz-diff` | D_rizin, D_bytes | all |
| F-PT-NAMES | P03 | D_symbols | all |
| F-PT-PE | P01, P02 (import/export names are symbols in Ghidra's table, R-17) | D_pe_tables, D_symbols | all |
| F-PT-BYTES | P04-P09, P14 when BOTH functions are `pdata-confirmed` (source id `pt-bytes`) | D_bytes, D_ghidra_decode | D_bytes only |
| F-PT-STRUCT | every other `pt-ladder` step, and P04-P09/P14 without pdata confirmation | D_ghidra, D_ghidra_decode, D_callgraph | D_ghidra, D_callgraph |
| F-MANUAL | P00 | D_analyst | all |
Components = connected components of the family graph where two families are joined iff they share a joining tag (union-find, deterministic order by family name; `K0` = the component holding F-MANUAL, the others `K1`, `K2`, ... in order of their alphabetically first family). Today: K0 = {F-MANUAL}, K1 = {F-BINDIFF, F-DIAPHORA, F-GHIDRIFF, F-PT-NAMES, F-PT-PE, F-PT-STRUCT}, K2 = {F-PT-BYTES, F-RZDIFF}. The table reproduces `calibration.features.family_dependencies` for G/B/R (features.py:40-47) and only adds families.

Components alone over-count: Ghidriff's ExactMnemonics and `pt-bytes` P08 are the same key over the same Ghidra decoding (and, in `gzf` mode, the same function bodies), yet sit in K1 and K2 (R-05). Every step therefore also has an **evidence class** (what information the key reads); two atoms corroborate only if they differ in BOTH component and class.

| Class | Steps (any source; unknown steps -> E-UNKNOWN, which never corroborates) |
|---|---|
| E-NAME | P01, P02, P03; Ghidriff SymbolsHash, ExternalsName; BinDiff name hash |
| E-BODY | P04-P09; Ghidriff ExactBytes/ExactInstructions/ExactMnemonics/BulkInstructionHash; BinDiff hash, prime signature, instruction count; rz-diff |
| E-CFG | P10; Ghidriff StructuralGraphExactHash, StructuralGraphHash, BulkBasicBlockMnemonicHash, SwitchSigHasher; BinDiff (edges) MD flowgraph, relaxed MD, loop count |
| E-CALL | P11, P13, P15, neighbour-propagated pairs, implied matches; Ghidriff SigCallingCalledHasher, Implied Match; BinDiff callgraph MD steps, call reference, call sequence |
| E-DATA | P12, P14; Ghidriff StringsRefsHasher, StrUniqueFuncRefsHasher; BinDiff string references |
| E-DECOMP | Ghidriff BSIM, Decomp Match; Diaphora pseudo-code rules (registry maps DA-01 descriptions) |
| E-LAYOUT / E-RESID / E-MANUAL | P18, BinDiff address sequence / P16, P17, P19 / P00 |

`support` is the per-component max-pool inventory defined in 02 s4, not a list of mutually corroborating classes. Two same-class atoms in different components retain one support entry per component and both atoms; their decision remains `tentative` unless another rule establishes a match. Class independence is checked by `base_decision` and is explained separately from support by component (07 s11). Native confidence text never changes that inventory or decision.

Assumption **A-IND-1** (narrowed): an E-BODY atom of K2 (pdata-confirmed extents) and a non-E-BODY atom of K1 err independently enough to corroborate; G-U7 (08) measures it per class pair and can join classes by configuration.

### 1.2 Source atoms -> tiers (adapters, 06)

| Source | A | B | C | W |
|---|---|---|---|---|
| ghidriff (`match_types`, strongest of the list wins) | SymbolsHash, ExternalsName, ExactBytesFunctionHasher, ExactInstructionsFunctionHasher | ExactMnemonicsFunctionHasher, BSIM, BulkInstructionHash, StringsRefsHasher, StrUniqueFuncRefsHasher, Decomp Match | StructuralGraphExactHash, StructuralGraphHash, BulkBasicBlockMnemonicHash, SigCallingCalledHasher, SwitchSigHasher, Implied Match, unknown names | added/deleted one-sided observations |
| bindiff (`algorithm`; R02 s14 tiers) | name hash, hash matching, edges flowgraph MD index (rows with `basicblocks = 0` only when both ends are imports) | edges callgraph MD, MD flowgraph top-down/bottom-up, prime signature, MD callgraph top-down/bottom-up | relaxed MD index, instruction count, address sequence, string references, loop count, call reference, call sequence, unknown step names (the step name alone sets the tier; confidence is never read, R02 s7; U7-16 reconciled 2026-11-04) | - |
| rz-diff | - | - | - | every row (`non-exclusive` when its newer endpoint is shared) |
| diaphora (verified sets only, 06 s5) | - | best | partial, unreliable, multimatch (as N:M) | unmatched observations |
| pt-ladder / pt-bytes | pass tier (04 s4) | | | |
Ratios, similarities and confidences are copied to `Atom.native` as upstream text only; no rule reads them (R03 s2: Ghidriff ratios are text-diff statistics; R02 s7: BinDiff confidence is an evidence-quality index).

### 1.3 Decision algorithm (pure, deterministic)
```python
TIER_RANK = {'M': 5, 'A': 4, 'B': 3, 'C': 2, 'W': 1}
def decide(atoms, groups, registry) -> list[UnifiedMatch]:
    edges = defaultdict(list); one_sided = defaultdict(list)     # (older_rva, newer_rva) -> atoms
    for a in atoms: (edges[(a.older_rva, a.newer_rva)] if a.older_rva is not None and a.newer_rva is not None
                     else one_sided[a.older_rva if a.older_rva is not None else ('n', a.newer_rva)]).append(a)
    rows = []
    for cluster in connected_clusters(edges, groups):            # bipartite components over rvas, sorted by min rva
        strength = {e: (max(TIER_RANK[x.tier] for x in edges[e]), n_components(edges[e]), has_ghidriff(edges[e]), -e[0], -e[1])
                    for e in cluster.edges}
        chosen = greedy_matching(sorted(cluster.edges, key=strength.get, reverse=True))   # each rva used once
        for e in chosen:
            against = [x for f in cluster.edges if f not in chosen and touches(f, e) for x in edges[f]]
            rows.append(row(e, edges[e], decision=base_decision(edges[e], registry), against=against))
        rows += one_sided_rows(cluster.nodes - covered(chosen), one_sided)   # older-only / newer-only, never "removed"
    rows += group_rows(groups)                                   # ladder N:M, ICF, inline hints, ghidriff 1:N -> 'ambiguous'
    return sorted(rows, key=lambda r: (min_rva(r.older), min_rva(r.newer), r.row_id))

def base_decision(edge_atoms, registry):
    if any(a.tier == 'M' for a in edge_atoms): return 'matched'      # analyst control; contests still recorded
    best = max_pool_per_component(edge_atoms, registry)            # {component: strongest atom}; idempotent inside a component
    if any(a.tier == 'A' for a in best.values()): return 'matched'
    b = [a for a in edge_atoms if a.tier in ('A', 'B') and registry.cls(a) != 'E-UNKNOWN']
    if any(registry.comp(x) != registry.comp(y) and registry.cls(x) != registry.cls(y) for x, y in combinations(b, 2)):
        return 'matched'                                           # two components AND two evidence classes (C-08, R-05)
    if b: return 'tentative'
    return 'candidate'                                             # only C or W evidence
```
`row()` sets `decision='contested'` when `against` is non-empty (SPEC-27: any source pairing an endpoint differently), keeps the uncontested decision in `hints` (`uncontested:matched`), and sets `Contest.strength = 'strong'` iff any against-atom has tier M, A or B, else `'weak'` (D-12). Contested rows are never auto-anything; a manual row stays `matched` with its contest shown. One-sided observations (Ghidriff `added`/`deleted`, unmatched lists) are absence of evidence (D-14): they never contest a pairing; the row carries hint `one-sided-by:<source>` instead. **A-29 (2026-11-11, p7):** the ladder's leftovers are one-sided observations too: `ladder_output` emits one tier-W atom (source `pt-ladder`, step `leftover`, class E-UNKNOWN, the leftover reason as `native` text) and a `NodeRecord` per leftover function of kind `function` or `thunk`, so an IR-only result (no `ghidriff` source) shows `older-only`/`newer-only` rows exactly as a Ghidriff `added`/`deleted` list does; imports and externals are never rows (`ladder-leftovers-not-shown:<kind>`). `LADDER_VERSION` moves with this change. This deliberately differs from the C6 reconcile verdict for "removed(A) vs engine A->B" (R01 s3): A-08 records it and the Unified tab shows both texts (R-19).

### 1.4 Invariants and what fusion never does

L-39 orientation amendment (2026-11-18 UTC, recovery of UE-R7 commit
`7237c55cba6e134c58df7936f273fd269aa864c5`): the atom cap must preserve the
same evidence when older and newer sides are exchanged. Rank cuts by an
orientation-independent key including native evidence, keep mirror twins
together, and reserve two opposing atoms when the strongest opposing claim is a
twin pair. A capped row can consequently contain one fewer atom than the cap.
Persisted row ordering remains unchanged. Register `arbiter=2` to invalidate
cached results without rolling back newer channel or proof versions. The
selected support atom can name either member of an indistinguishable mirror
twin pair; support component and strength are invariant. Regression coverage
includes the real 64-atom cap and bounded dense mirror properties.

L-39 acceptance-evidence amendment (2026-11-18 UTC, R2 recovery): after the
existing admission and greedy choice, the cap must retain the evidence required
by the chosen decision. A 1:1 `matched` row without chosen tier M/A evidence
reserves one deterministic pair of chosen tier B atoms with different
independence components and different non-unknown classes. A `contested` row
with `uncontested:matched` needs the same witness in addition to its opposing
evidence. Tentative/candidate rows (including their contested forms), one-sided
rows and inferred or analyst groups do not depend on this B+B acceptance rule.
M/A acceptance retains the existing strongest-component reservation.

Select the witness in orientation-independent atom order; retain every member
of each selected mirror-key group. Union it with the strongest-per-component
groups, then reserve the strongest opposing group, before filling the remaining
space by the existing prefix policy. `Support` remains the max-pool inventory
of s1.1: its indices may both name E-BODY atoms while the retained atom list
contains the cross-class witness. No native confidence value affects admission
or that inventory. If a custom L-39 cap cannot hold all mandatory groups, refuse
with `PT-UNIFIED-LIMIT` / `atoms-cap` in both orientations, before writing a
result; never exceed the cap or erase the witness or contest. Custom limits are
the pure/in-process API seam, not a new CLI option. The default cap remains 64.

Register `arbiter=3`; only that channel version changes. Orientation version 2,
other current channel/proof policies and `ude/2` remain intact. A version-2
result receives a different current key but stays verifiable and readable as
historical evidence, including rows whose stored atoms reflect the old
omission. Authored atom, strict store, shared desktop-detail and headless CLI
controls establish these mechanics; they do not establish native accuracy or
change frozen qualification outcomes.

Never averages, sums or ranks native scores across sources; never treats a missing atom as a vote (absent sources leave `support` shorter, nothing else); never converts counts of agreeing sources into a number shown to users; never lets a model override `contested` (SPEC-28 calibration s9.5). Display level is read from `calibration.policy.display_level()` and is `'ordinal'` today; a future validated artifact for a unified profile may add bands through the read model only (C-09). Tests: `test_fusion_never_emits_numbers`, `test_absent_source_is_not_a_vote`, `test_weak_contest_still_contested`, `test_two_ghidra_derived_sources_are_one_component`, `test_same_class_never_corroborates_across_components` (Ghidriff ExactMnemonics + `pt-bytes` P08 -> `tentative`), `test_manual_row_accepted_with_contest_shown`, `test_greedy_matching_keeps_every_against_atom`, `test_one_sided_observation_never_contests`.

### 1.5 How the L1 false-positive rate is bounded
1. Construction: `matched` needs a unique tier-A key (hash collisions ~2^-64 per pair; duplicates fail uniqueness; names guarded by size/callee checks; tiny/thunk excluded) or tier B from two components AND two evidence classes; propagated tier-B pairs need >= 2 votes and 0 conflicts on both endpoints; tail passes give `candidate` only.
2. Conflict surfacing: any contradicting atom makes the row `contested`; nothing is silently resolved.
3. Measurement gates (08): G-U3 matched-pair precision on Tier R with exact truth >= 99.5 % (lineage-cluster CI lower bound >= 99.0 %) and zero truth-contradicted tier-A pairs on A/A corpora; per-pass precision table published; a pass whose precision CI lower bound < 98 % is demoted one tier by config change (recorded in `config_digest`). Targets are [inf] proposals to preregister; every borrowed threshold is a hypothesis (02 s6.1).

## 2. L2 ChangeFacts (`facts/*`)
Scope: a verdict describes the function's code (instruction stream, CFG, referenced targets) and, when `.pdata` exists, its unwind/handler metadata (EH-EQ); data-only patches (tables, strings, globals) are out of scope and belong to SPEC-26 file-level views (R-16).
### 2.1 Channels

| ID | Observation (equal / differs) | Data group | Needs | Slice |
|---|---|---|---|---|
| C0 | raw body bytes `h0` | bytes | IR | S3 |
| C1 | address-masked bytes `h1` (displacement/immediate bytes of address-bearing operands only, 03 s6) | bytes | IR | S3 |
| C2 | aligned operand-class deltas including the target consistency of EVERY address operand (2.2, 2.7) | bytes | IR instructions | S3 |
| C3 | CFG: `n_bb`, `n_edge`, block body multiset, `md_td`, `md_bu`; equality here is a filter, never a proof (COS-LAYOUT needs 2.5) | cfg | IR | S3 |
| C4 | callee multiset mapped through `matched` rows (thunks -> targets, imports by key) | calls | IR (S3) or Ghidriff `called` names mapped through Ghidriff pairs (S0 variant C4n) | S0b/S3 |
| C5 | constant multiset (ALL non-address immediates, not only rare ones) and string-hash multiset | bytes (IR) / decompiler (S0 variant C5t from code literals) | IR or Ghidriff code | S0b/S3 |
| C6 | canonical pseudo-code (2.4) | decompiler | Ghidriff `code` (modified pairs only: Ghidriff never examines same-size, same-refcount pairs, R05 s0.1) or S3b decompile (2.8) | S0b/S3b |
| C7 | BSim-style features | decompiler | not in v1 (B-09) | - |
| C8 | BinDiff flags for this exact pair: differs iff any of G I E L C; J alone is branch inversion (cosmetic hint); O is never set by BinDiff (R02 s7) | bindiff | stored BinDiff set | S0b |
Matching keys use the rarity filter L-15; facts never do (a `cmp edx, 0x40 -> 0x41` bound fix uses a small constant, R03 s3).

### 2.2 Operand-delta classifier C2 (`facts/operands.py`), the first channel to build (R05 R1)
```python
def operand_deltas(a_ins, b_ins, align, rows, dmap, pe) -> tuple[list[Delta], Consistency]:
    out, cons = [], Consistency()                              # cons counts address pairs: mapped / unmapped / conflict
    for i, j in align.matched_pairs():                         # aligned by L2 tokens (opcode + operand classes), 2.3
        x, y = a_ins[i], b_ins[j]
        for ox, oy in zip(x.ops, y.ops):                       # EVERY operand, also when x.l1 == y.l1 (R-01)
            if ox.vkind == oy.vkind == 'address':
                state = target_state(ox.target, oy.target, rows, dmap, i, j, align)   # 2.7: mapped|unmapped|conflict|string
                cons.add(state)
                if state == 'conflict':
                    out.append(Delta('callee' if x.is_call else 'data-ref', 'C2', x.rva, y.rva, x.text, y.text))
                elif state == 'string':                        # both strings, different content
                    out.append(Delta('string', 'C2', x.rva, y.rva, x.text, y.text))
            elif ox.vkind == oy.vkind == 'scalar' and ox.value != oy.value:
                cls = 'frame' if is_frame_alloc(x) and is_frame_alloc(y) else 'constant'   # sub/add rsp, imm (R-14)
                out.append(Delta(cls, 'C2', x.rva, y.rva, x.text, y.text))   # context (cmp/test/and/shift/size arg) in text
            elif ox.vkind == oy.vkind == 'stack' and ox.value != oy.value:
                out.append(Delta('frame', 'C2', x.rva, y.rva, x.text, y.text))      # RSP/RBP frame offsets (R-14)
            elif ox.vkind == oy.vkind == 'memory' and ox.value != oy.value:
                out.append(Delta('struct-offset', 'C2', x.rva, y.rva, x.text, y.text))   # non-frame base + displacement
            elif ox.vkind == oy.vkind == 'register' and ox.value != oy.value:
                out.append(Delta('register-only', 'C2', x.rva, y.rva, x.text, y.text))
            elif ox.vkind != oy.vkind:
                out.append(Delta('unknown', 'C2', x.rva, y.rva, x.text, y.text))
        if x.mnem != y.mnem and x.is_cond_branch and y.is_cond_branch and not inverted_pair(x, y, align):
            out.append(Delta('condition', 'C2', x.rva, y.rva, x.text, y.text))
    out += [Delta('block-added' if side == 'b' else 'block-removed', 'C2', ...) for side, blk in align.unmatched_blocks()]
    return out[:L28], cons                                      # rest counted in deltas_omitted
```
`target_state` (2.7) never trusts a raw address: a function target is `mapped` only through a `matched` row of tier A or M (or equal import keys, or thunks resolving to mapped targets); an intra-function branch target must hit the aligned instruction; a data target needs DATA-MAP/1. `unmapped` (no evidence either way) is not a delta but blocks every cosmetic proof; `conflict` (the target maps elsewhere) and `string` (both strings, different content) are semantic deltas; `cons` counts `string` with the conflicts, so neither can pass a proof.

### 2.3 Alignment (`facts/align.py`)
Pairs with equal `h1` are aligned positionally (instruction k <-> k). Otherwise block level first: blocks paired by unique block body key (block `h1` without its terminating branch) inside the pair, then by CFG position (entry, then successors of paired blocks, unique only); instruction level inside paired blocks: patience diff on L2 tokens, Hirschberg LCS fallback (linear space) when patience leaves gaps; whole-function cap L-27 (beyond: prefix/suffix only, verdict at most `review`, `limits_hit: align-cap`). Tie-breaks (block pairing order, patience anchors, the LCS fill) are deterministic **and orientation-symmetric** (A-31, 2026-11-11, p17): `align(newer, older)` is the mirror of `align(older, newer)`, so no verdict, proof or delta depends on which side is older; a side-dependent RVA tie-break is withdrawn. Property test required (04 s9 style). `align` version 2.

### 2.4 Canonical pseudo-code C6 (`facts/pseudo.py`, version `canon/2`)
Input: Ghidriff `code` of both functions (bounded L-29) or S3b output. Rules (R05 R7): strip comments and whitespace; alpha-rename locals, parameters and decompiler temporaries per function in order of first definition (`uVar1`, `local_18`, `param_3`, `in_RAX` -> `v1`, `v2` ...); replace `FUN_<hex>`/`DAT_<hex>`/`LAB_<hex>`/`PTR_<hex>`/`switchD_`/`caseD_` labels by the counterpart's row id (functions) or DATA-MAP pair id (data) when mapped, else by `U<k>` numbered in order of first use per function and count the unmapped label pairs; keep literal values with type-relevant suffix/radix hints, operators, casts and call names. C6 `equal` = token sequences identical; `unmapped_labels` > 0 forbids COS-PSEUDO (an alpha-renamed unmapped label could hide a swapped global, R-02). Literals are normalised for comparison only (hex/decimal/char spelling, sign extension to the operand width) so value-anchored corroboration (2.5) can match `0x200` with `512`.

### 2.5 Verdicts and proofs (`facts/verdict.py`; first match wins)
```python
def judge(ch: Channels, deltas, cons, row, eh) -> ChangeFacts:
    if row.decision in ('older-only', 'newer-only'): return facts('not-applicable')
    targets_ok = cons.unmapped == cons.conflict == 0           # target consistency of every address operand (2.7)
    structural_ok = targets_ok and eh in ('equal', 'absent')   # eh: equal | differs | absent | unavailable (EH-EQ, R-16)
    if ch.C0 == 'equal' and structural_ok: return facts('unchanged', proof='UNCH/1')   # equal bytes alone are NOT enough (R-03)
    semantic = [d for d in deltas if d.cls in SEMANTIC]        # constant, comparison, condition, callee, call-added, call-removed,
                                                               # data-ref, struct-offset, string, block-added/removed holding a store or call
    if not semantic and ch.C4 == ch.C5 == 'equal':
        if structural_ok and ch.C1 == 'equal' and cfg_positional_equal(row): return facts('cosmetic', proof='COS-ADDR/1')
        if structural_ok and layout_bijection(row): return facts('cosmetic', proof='COS-LAYOUT/1')   # polarity-preserving (R-04)
        if targets_ok and ((ir_available and eh in ('equal', 'absent')) or (not ir_available and eh != 'differs')) and ch.C6 == 'equal' and ch.unmapped_labels == 0:
            return facts('cosmetic', proof='COS-PSEUDO/1')    # decompiler-relative: never hidden by default (R-04, U-03)
    for d in semantic:                                         # value-anchored second channel (MAT-ANCHOR, R-08)
        second = anchored_second_channel(d, ch, row)           # table below; None if no OTHER data group shows THIS change
        if second: return facts('material', second_channel=second, deltas=deltas)
    if any(ch[c] in ('equal', 'differs') for c in CHANNELS) or deltas or cons.unmapped:
        return facts('review', deltas=deltas)                  # incl. address-only (unmapped targets), frame, eh
    return facts('unknown')
```

| Proof / rule | Holds iff (all) | Why sound |
|---|---|---|
| UNCH/1 | `h0` equal; every address operand target `mapped` (2.7); EH-EQ | equal bytes at a moved RVA re-target relative operands; mapping proves they still reach the counterparts |
| COS-ADDR/1 | `h1` equal; every address operand `mapped`; block successors equal positionally (switch tables included); C4, C5 equal; EH-EQ | same opcodes, registers, immediates, order, flags; only address fields differ and each maps to the counterpart |
| COS-LAYOUT/1 | bijection of blocks by unique body key (h1 without terminator) covering all blocks; every edge maps to an edge with the same polarity (jcc inverted only by the closed table JZ/JNZ, JB/JAE, JBE/JA, JL/JGE, JLE/JG, JS/JNS, JO/JNO, JP/JNP with swapped successors); terminators otherwise equal or an added/removed unconditional JMP to the fall-through block; all address operands `mapped`; C4, C5 equal; EH-EQ | equal counts/MD/multisets do NOT prove isomorphism (a then/else swap passes them); the polarity-preserving bijection does |
| COS-PSEUDO/1 | C6 equal with zero unmapped labels; C4, C5 equal; no semantic delta in IR channels when IR exists; EH-EQ when IR exists | relative to Ghidra's decompiler only (it can drop arguments beyond an inferred prototype or flag-only effects), so its rows are listed, never hidden |
| EH-EQ | both sides without unwind data, or equal normalised UNWIND_INFO (version, flags, prolog size, frame register/offset, unwind codes), same handler (mapped or equal import key) and equal handler-data length; `__C_specific_handler` scope records equal after subtracting the function start and mapping filters | SEH scopes are invisible to bytes and decompiler (R-16); otherwise class `eh` -> `review` |

In the pseudocode above, `ir_available` means a complete IR pair was loaded (not merely a planned extraction). **R3-PC01 clarification:** EH-`unavailable` blocks the IR-backed `COS-PSEUDO/1` rule; S0 decompiler-relative results without IR retain the historical `eh != 'differs'` gate. This is a narrowing of an existing proof's implementation, not a new cosmetic class. **R3-PC08:** even with equal C6, a real IR `register-only` delta blocks `COS-PSEUDO/1`; the decompiler can hide ABI-visible register changes. Both adjustments are tracked under proof implementation version 2. The internal `COS-PSEUDO/1` proof implementation version advances to 2 in the registry so cached results are not silently reused.

MAT-ANCHOR (second channel must observe the SAME change, from another data group; any other difference does not count):

| Semantic delta (first channel C2) | Anchored second channel |
|---|---|
| callee, call-added, call-removed | C4 differs by that callee pair (mapped ids); or C8 flag C |
| constant, comparison, struct-offset | C6 token diff contains the normalised old -> new literal pair of that instruction (S3b supplies C6 for same-size edits) |
| condition | C6 shows a changed relational operator or condition expression at an aligned statement |
| data-ref (conflict) | C6 shows the corresponding label changing to another mapped datum |
| block-added/removed holding a store or call | C3 block/edge counts differ; or C8 flag G |
| string | C6 shows the changed string literal (C5 is in the same data group as C2 and never anchors) |
A constant-only edit without C6 therefore stays `review` ranked first (2.6) until S3b decompiles it (2.8); with S3b it is promoted only when the decompiler shows the same value change, which also rejects a mis-classified address. `register-only`, `address-only`, `frame` and `eh` never make `material` (no register-renaming or frame proof in v1: calling-convention registers and buffer resizing make them unsound), they stay `review`. A cheap-tier semantic delta always beats `COS-PSEUDO` (cross-tier consistency, R05 s7). Without IR (S0) the only proof is `COS-PSEUDO/1` and the only anchored second channels are C4n and C8.

### 2.6 Review ordering (sort key, never shown as a number)
Severity order: callee / call-added / call-removed > condition / comparison > constant in a compare, test, mask, shift or size-argument context > struct-offset > data-ref > block-added/removed > eh > constant elsewhere > cfg > string > frame > size-only > refcount-only > address-only > register-only > name-only. Ties: hint `trace-arg` last (F17), then attention/1 score when the row maps to a Ghidriff match (read-only), then RVA.

### 2.7 DATA-MAP/1 and target consistency (`facts/datamap.py`, S3; R-01)
1. Inputs: IR `ref` rows (fid, ord, opi, target, kind code|data|import|stack, 02 s3), `str` rows, `matched` rows of tier A/M.
2. Votes: every `matched` A/M pair whose `h1` is equal is aligned positionally; each operand position with a data reference on both sides votes for the data pair (t, u), recording the voting function pair. Pairs with differing `h1` never vote. A call operand votes for a function pair (x, y) only when neither x is in a matched pair nor y is (symmetric; A-30, p11).
3. Consensus (A-30, 2026-11-11, p15): the *raw consensus* of an older datum t is the newer datum voted by a strict majority of the function pairs voting for t, with at least 2 voters (none for an incomplete datum); symmetrically for a newer datum u. The *consensus* `consensus(t) = u` is the raw consensus u with **no blocking competing claim**: a vote (t', u) with t' != t blocks when t' has >= 2 voters for u and t' has no raw consensus of its own other than u (or t' is incomplete); a single dissenting vote never blocks, with one exception: a *stationary* claim (t', u) with t' == u (the datum kept its address and a function still references it there) blocks with any number of voters when t' has no raw consensus elsewhere. An explanation is void when t itself votes for u' (two data claiming each other's partners are a swap, not two explained dissents; review finding 2026-11-11). Symmetrically `consensus(u) = t` is blocked by a claim (t, u') with >= 2 voters whose u' has no raw consensus other than t (or whose raw consensus t'' itself votes for u), and by a stationary claim (t, u') with u' == t. A voter whose pair differs from an existing consensus is a dissenter (the typical patched function). Rationale: by votes alone, several functions retargeted to a global that other functions still reference cannot be told from that global having moved while the others were retargeted; a proof must abstain. Known cost: two functions retargeted together to a brand-new global make every referrer of the old datum `unmapped` (`review`, never a wrong `cosmetic`). Known residual: three or more functions retargeted to an existing global that MOVED and keeps exactly one referrer still map (by votes alone this is one retarget of that referrer, Occam); two retargeters abstain (leave-one-out tie), a stationary global or a second referrer blocks.
4. Data targets for row r: `mapped` if (a) both are defined strings with equal SHA-256, unique per side; or (b) u is the consensus of t and t the consensus of u over the votes of the function pairs **other than r**: at least two voters in all (r's own vote counts toward that floor, so a row that is not itself a voter needs two witnesses) and a strict majority among the voters other than r, and no blocking competing claim (rule 3) on either datum; in that count a vote of another function for (t, u') with u' != u is ignored when u' has a consensus (rule 3, full table) other than t, and a vote for (t', u) with t' != t is ignored when t' has a consensus other than u (an explained dissenter never tips a leave-one-out tie, exactly as it never blocks in rule 3) (leave-one-out, A-30: r's own vote never tips the majority and a function never proves its own references; two functions that agree with each other and face no competing claim do map, the same evidence as any moved datum; two innocent referrers beside a lone explained dissenter keep their mapping); or (c) region shift (B-21 can cut it, U-12): neither t nor u has a consensus or a vote from a function other than r, and the nearest (b)-mapped data pairs below and above t in the same section have the same displacement u - t and keep order. Both defined strings with different SHA-256 -> delta class `string`. `conflict` if t or u has a consensus that differs from r's pair (r swapped to another datum). Otherwise `unmapped`.
5. Function targets: mapped iff (i) a `matched` A/M row pairs them, (ii) both are imports with equal key, (iii) both are thunks whose targets are mapped, or (iv) both bodies have equal `h0` and they either sit at the same RVA or are the consensus (rule 3 applied to call operands) of a matched caller pair other than r. Rule (iv) covers tiny and unnamed callees, which I6 keeps out of content-key matching; without it G-U1's X vs X run could not reach 100 % `unchanged`. `conflict` if either is in a `matched` A/M row with a different partner. Intra-function targets: mapped iff they land on aligned instructions.
Complexity O(data refs of matched pairs) using the `ref` table only (no instruction decoding); deterministic order by (t, u). Tests: `test_moved_global_is_cosmetic_via_other_function_votes`, `test_swapped_global_same_shape_is_not_cosmetic` (the R-01 hole: the patched function is a dissenter -> `conflict` -> semantic `data-ref`), `test_innocent_functions_keep_mapping_beside_a_dissenter`, `test_single_use_global_needs_region_shift`, `test_function_never_votes_for_itself`, `test_two_way_tie_is_unmapped`; since A-30 also `tests/test_unified_followup_datamap.py` (coordinated retarget to an existing global never maps; two-way orientation property over `TargetMap`).

### 2.8 On-demand decompile S3b (`decompile` mode of `extract/ghidra_script.py`, driven by `extract/runner.py`; R-08)
After facts, rows in `review` whose first semantic delta is constant, comparison, condition or struct-offset and lack C6 are ranked (2.6); the top L-41 pairs are decompiled in ONE extractor session that re-opens both retained GZFs (03 s8) with the same Ghidra and canonicalised by `canon/1`; results feed C6 and MAT-ANCHOR, never L1. Measured [own, 11-review-log]: decompiler open 0.28 s, median 0.013 s, p90 0.16 s, max 2.6 s per function on an analysed program, so L-41 = 64 pairs fits well inside its 600 s budget. Absent GZFs or Ghidra -> rows stay `review` (B-08).

## 3. Noise-filter catalogue (R05 s4 F1-F15 -> where implemented)

| F | Filter | Module / slice | Guard against hiding real change | Test |
|---|---|---|---|---|
| F1 | symmetric producer, mode, options and symbol policy on both sides | extract, pipeline / S1 | asymmetric -> no ladder, S0 only | `test_asymmetric_ir_falls_back_to_s0` |
| F2 | relocation-aware masked hash (displacement/immediate bytes only, 03 s6) | ir/ingest / S1 | mask only positive address evidence; SIB/ModRM never masked | `test_l1_masks_only_positive_address_evidence` |
| F3 | operand-delta classifier with target consistency | facts/operands, facts/datamap / S3 | unmapped targets block proofs; conflicts are deltas | `test_unmapped_target_blocks_cosmetic` |
| F4 | typed downgrade of Ghidriff non-code diff types | sources/ghidriff + verdict / S0b | hint only; cosmetic still needs a proof | `test_diff_types_alone_never_cosmetic` |
| F5 | thunk/import collapse in C4 | facts/channels / S3 | collapse pure jump thunks only | `test_wrapper_with_logic_not_collapsed` |
| F6 | callee mapping through rows | facts/channels / S0b+S3 | unmatched callee = semantic delta | `test_unmatched_callee_is_material_candidate` |
| F7 | canonical pseudo-code with DATA-MAP labels | facts/pseudo / S0b | literals, operators, call names kept; unmapped labels counted | `test_canon_keeps_constants_and_operators` |
| F8 | layout-independent CFG with polarity-preserving bijection | facts/channels / S3 | then/else swap is not cosmetic | `test_block_reorder_is_cos_layout`, `test_then_else_swap_not_cosmetic` |
| F9 | rarity, minimum size, tiny functions | ladder gates / S2 | tiny changes go to review, never dropped | `test_tiny_change_is_review_not_hidden` |
| F10 | cross-function edit-group dedup (identical canonical deltas in >= 3 rows -> one group, rows flagged `induced-candidate`) | read_model / S4 | rows stay listed; group is a view | `test_edit_group_never_removes_rows` |
| F11 | added/removed reconciliation (inline/outline) | ladder/groups / S2 | partial containment -> hint only | `test_inlined_function_not_reported_removed` |
| F12 | N-way churn index | deferred (B-12) | - | - |
| F13 | name/body consistency | ladder P03 + fusion / S2 | mismatch -> tier C + contest | `test_name_body_mismatch_contests` |
| F14 | string/constant significance | 2.1 (keys rare, facts complete) / S3 | small constants count in facts | `test_small_constant_bound_change_detected` |
| F15 | Windows loader idioms (`.reloc` and RVA-form operands in masks; `/GS`, CFG dispatch as hubs; DVRT/GuardCF tables not parsed in v1) | ir/pe_tables, propagate / S1-S2 | hubs excluded only from propagation, never from facts | `test_hub_call_change_still_reported` |
| F16 | library tagging: functions Ghidra FID matched to known library bodies (IR `lib`, row flag `library`) sort after first-party rows (R04 s8 addition) | extract + read_model / S1, S4 | tag and order only; a changed library function stays listed with its verdict; FID names are not P03 anchors (source ANALYSIS) | `test_library_rows_ordered_last_never_hidden` |
| F17 | trace-argument ordering: a `constant` delta whose instruction feeds an argument register (RCX/RDX/R8/R9 or [RSP+0x20..]) of a call in the same block to a tracing callee (closed import table: `EtwWrite*`, `WmiTraceMessage*`, `TraceMessage*`, `TraceLogging*`/`_tlgWrite*`; WPP thunks resolved to them) gets hint `trace-arg` and sorts last inside its verdict | facts/channels / S3 | ordering only; verdict unchanged; never hidden | `test_trace_arg_constant_ordered_last_not_hidden` |
| F18 | frame-only edits (`sub/add rsp`, RSP/RBP displacements) classed `frame`, not `struct-offset` (R04 s5) | facts/operands / S3 | `review`, never cosmetic (a buffer resize is a real change) | `test_frame_only_change_is_review_not_material` |

## 4. How the L2 noise (false "changed") rate is bounded
Construction: `unchanged` and `cosmetic` exist only through the named rules of 2.5, each requiring target consistency (2.7); `material` needs a semantic-class delta plus an anchored second channel from another data group; everything else is `review` (visible, ordered, never auto-hidden; default filters collapse only `unchanged` and structural `cosmetic` rows with a visible count, U-03). Measurement (08): G-U1 A/A rebuilds produce 0 `material` and <= 0.1 % `review` rows [inf target]; G-U2 planted mutations: leakage into `cosmetic`/`unchanged` = 0 and recall (material or review) >= 95 % per class; G-U6: the `material` set has >= 20 % fewer false leads than the best legacy output at non-decreasing planted recall (R05 s7 proposal).

## 5. Failure modes

| Case | Result |
|---|---|
| a channel's data unavailable (no IR, no code, oversize) | that channel `unavailable`; verdict computed from the rest; never `cosmetic` by absence |
| alignment cap hit | `review` + `limits_hit` |
| DATA-MAP cannot map a target | `unmapped`: no proof, row `review` (class `address-only`); never `material` |
| row contested | facts still computed for the chosen edge (labelled "for the shown pairing") |
| group rows (N:M) | `not-applicable` for facts in v1 (B-13) |
| S3b unavailable or over budget | C6 stays `unavailable`; rows stay `review` ranked by 2.6 |

## 6. S0 mode as built by S0b (2026-10-14; no ProgramIR)
Inputs per two-sided row of decision matched, tentative, candidate or contested (for the chosen edge): the Ghidriff function records by RVA (code, callee names, diff types; records of ANY match, so a pair another source made from an `added` and a `deleted` function still has code), the stored BinDiff flags of the exact pair, and the mapping of function RVAs through `matched` rows that hold a tier A or M support (B+B rows never map, U-06). One-sided and group rows get no facts (materiality `not-applicable`).
| Channel | S0 definition | State |
|---|---|---|
| C0-C3, C7 | need IR (C7: not in v1) | always `unavailable` |
| C4 (C4n) | multiset of callee identities from the Ghidriff callee names: a default `FUN_`/`thunk_FUN_` label or a unique real name found in the records resolves to an RVA, then to its row token if mapped, else to a side-specific unmapped identity; other real names are their own identity | `equal`/`differs`; `unavailable` without both records |
| C5 (C5t) | multiset of numeric (value-normalised) and string literals of the canonical code | `equal`/`differs`; `unavailable` without code |
| C6 | `canon/1` token sequences identical (2.4); code over L-29 is omitted (`pseudo-cap`) | `equal`/`differs`/`unavailable` |
| C8 | differs iff the BinDiff row of the exact pair carries G, I, E, L or C; J alone is a hint | `unavailable` without that row |
`canon/1` as built: comments and whitespace dropped; locals, parameters and temporaries (`[a-z]{1,4}Var<n>`, `local_<hex>`, `param_<n>`, `in_/unaff_/extraout_*`) renamed `v<k>` by first occurrence; `LAB_/switchD_/caseD_` labels renamed `L<k>` (they stay inside the function); `FUN_/thunk_FUN_` labels become the token of the mapped row or `U<k>` (counted unmapped); `DAT_/PTR_/EXT_/UNK_/BYTE_/WORD_/DWORD_/QWORD_` data labels are always unmapped in S0 (DATA-MAP is S3) and counted; numeric literals are compared by value (`0x200` = `512`), strings and operators exactly. A pair with unmapped labels never gets COS-PSEUDO/1 (R-02): it is `review`, class `address-only`.
Deltas (<= L-28, sorted by 2.6 severity): callee identity differences from C4 (`callee` when a replaced pair exists, else `call-added`/`call-removed`; channel C4, or C6 when only C6 is available); literal differences from C5 (`constant`, `string`); relational/logical operator count differences from C6 (`comparison`, `condition`); remaining C6 differences `unknown` (never semantic). `ChangeFacts.targets` = (distinct mapped function labels, distinct unmapped labels, callee replacements between two different mapped rows).
Verdict (first match): not-applicable for one-sided/group rows; `cosmetic` with COS-PSEUDO/1 iff no semantic delta, C4 = C5 = C6 `equal`, unmapped = conflict = 0 and eh is not `differs`; `material` iff a callee-class delta has an ANCHORED second channel of another data group that differs by the same callee identity: delta seen by C4 -> C6 (its call tokens contain the identity) or C8 flag C; delta seen by C6 -> C4 or C8 flag C; constants, strings, comparisons and conditions have no anchor in S0 (C5 and C6 share the decompiler group), so they stay `review` ranked first (S3b promotes them); else `review` when any of: a semantic delta, a differing channel, unmapped or conflicting labels, a Ghidriff `modified` pair, a differing C8; else `unknown` (no signal, never `cosmetic` or `unchanged` by absence). `unchanged` and COS-ADDR/COS-LAYOUT cannot be issued in S0 (they need IR bytes and DATA-MAP). Ghidriff diff types never decide (F4): they add the hint `ghidriff-diff-types:<csv>` and, when ALL listed types are non-code (`address`, `refcount`, `size`, `name`), the row classes `address-only`, `refcount-only`, `size-only`, `name-only` for ordering only.

## 7. S3 as built (2026-10-14; IR mode)
Switch: `FactsContext.build(..., ir_sides=IrSides(older, newer, older_sections, newer_sections, identical), budget=)` with the two `IrReader`s of the run. Without `ir_sides` nothing changes (s6). `identical` is set by the caller when both artifacts have the same SHA-256 (G-U1 X versus X); `*_sections` are the PE sections as (start rva, end rva) (`PeTables.sections`), needed only by the region shift. `collect(row)` first builds the S0 evidence, then replaces C4/C5 and the S0 deltas by the IR's and adds C0-C3; C6 (canonical pseudo-code) and C8 stay, because MAT-ANCHOR needs a second channel of another data group. A pair whose functions are not in the IR, or have no instruction data (oversize, truncated), keeps its S0 evidence and gets the row flag `ir-missing`. `Evidence.ir` (`IrEvidence`: positional CFG, layout bijection, mask-unlocated, unmapped pseudo labels, trace-arg) feeds `verdict.judge`; `Judged.flags` carries the row flags of the IR functions (`tiny`, `thunk`, `import`, `oversize`, `truncated`, `library`, `mask-missing`, `mask-unlocated`, `pdata-confirmed` when both sides have it, `ir-missing`).
| Channel | IR definition | State |
|---|---|---|
| C0, C1 | `h0` / `h1` of the two functions | `equal`/`differs`; `unavailable` when a key is missing |
| C2 | the aligned operand deltas of 2.2 (also `unknown` deltas and the CFG deltas of `layout.py`) | `differs` iff any delta carries channel C2 |
| C3 | `n_bb`, `n_edge`, `md_td`, `md_bu` and the multiset of block body keys (`bb.h1`); a filter, never a proof | `equal`/`differs` |
| C4 | callee multiset: callees of one side without a counterpart on the other (function targets through `TargetMap.function_state`, so matched rows and collapsed pure thunks; imports by key; an indirect call only equals another indirect call) | `equal` iff no leftovers on either side |
| C5 | multiset of ALL non-address constants (`cst`, no rarity filter, facts never use L-15) and of the defined-string SHA-256 values | `equal`/`differs` |
Deltas: C2 produces `constant`, `frame` (`sub/add rsp, imm` and stack displacements, R-14), `struct-offset`, `register-only` (also a register change inside an address operand), `data-ref` and `callee` (target `conflict`), `string` (both strings defined, different content), `comparison` (a SETcc/CMOVcc whose condition changed) and `condition` (a Jcc that is not a polarity-preserving inversion), `block-added`/`block-removed`, `cfg`, `call-added`/`call-removed` (an unmatched call instruction) and `unknown` (an unmatched non-call instruction or an operand-kind change; never semantic, but it blocks every proof). C4 and C5 only add what C2 did not already describe (leftover callees, constants and strings), so a change is listed once. `ChangeFacts.targets` counts address operand PAIRS (mapped, unmapped, conflict) including the CFG edges of the terminating branches, not distinct labels as in S0. `Delta.old`/`new` are the sanitised instruction texts (<= 120 characters); the severity key is the one of 2.6 with the context rule (a constant whose instruction is a CMP, TEST, AND, OR, XOR, NOT, BT*, shift or rotate ranks right after `comparison`).
Alignment (`facts/align.py`): first rule of 2.3, equal `h1` and a positionally equal CFG (same block count, per block the same kept length, terminator mnemonic and successor list) align block k with block k and instruction k with instruction k in linear time, with no cap and no unique key needed (switch cases with equal bodies are the usual twins; without this rule the real MinGW pair of docs/qa.md [S3:ir-facts] left 12 of 3,824 untouched functions in `review`). Otherwise blocks pair by unique body key (`bb.h1`; the key `None` of a body-less block, a lone jump, is also a key), then by CFG position per edge kind (cond, fall, jump, switch, call-return: a successor pairs when exactly one successor of that kind is left unpaired on each side); inside a pair the non-NOP bodies align by a patience diff on strict tokens (opcode, operand classes, registers) with an LCS fill on weak tokens (opcode, operand classes); unmatched runs of the same family (Jcc, SETcc, CMOVcc) pair as substitutions, so a changed condition is a changed operand. Terminating direct branches are not aligned as instructions: `layout.py` compares them as edges. Deviation from 2.3: the LCS fill is a dynamic programme with the cell cap `DP_CELL_CAP` (1,000,000) instead of Hirschberg; a gap beyond it stays unmatched and the pair gets `limits_hit: align-cap`, exactly like the whole-function cap L-27 (prefix and suffix only). Either cap ends a pair that would be `unknown` in `review`, and no proof is issued for a pair with `align-cap`. As built for A-31 (2026-11-11): `pair_blocks` seeds its BFS with the entry-involved pairs, then the unique-key pairs ordered by their shared block key, then discovery order; the LCS fill and the patience chain run in a content-based canonical orientation per gap and are swapped back (a different but mirror-consistent choice among equally long matchings); `layout._same_edges` counts an unpaired new-side successor like an old-side one.
CFG proofs (`facts/layout.py`): COS-ADDR/1 needs `positional_cfg_equal` (same block count, same kept length, same terminator mnemonic and the same successor list per block ordinal, switch tables included), `C1` equal, no `mask-unlocated`; COS-LAYOUT/1 needs every block paired by unique key, every edge mapped to an edge of the same polarity, conditional branches inverted only by the closed table (JZ/JNZ, JB(JC)/JAE(JNC), JBE/JA, JL/JGE, JLE/JG, JS/JNS, JO/JNO, JP/JNP) with the successors swapped, and an added or removed unconditional JMP only when it jumps to the fall-through block. A direct jump that leaves the function is judged as a function target. Both proofs also need targets_ok (no unmapped, no conflicting address operand), EH-EQ in `equal`/`absent`, C4 and C5 equal, no delta of a blocking class (semantic, block, `unknown`, `cfg`, `frame`, `register-only`, `eh`).
DATA-MAP/1 (`facts/datamap.py`) is 2.7 with these refinements. Votes come from matched A/M pairs with equal `h1` whose `ref` lists have the same shape (call targets that are entries of a function not itself in a pair vote too, for rule iv); at most L-40 pairs are kept, the cap is reported as `datamap-cap`. Consensus: strict majority with at least two voters, so a function never proves its own references; the region shift additionally needs that nobody else voted for either datum, accepts one confirmed neighbour when the other side of the section has none, and never crosses a section; the PE header region (target below the first section start on both sides, equal) maps; both strings defined with equal SHA-256 map only when each is unique per side, a differing SHA-256 is a `string` delta. Function targets: matched row (A/M) -> equal import keys (different keys conflict) -> a pure jump thunk stands for its target on either side (depth 4, an import stub is the end of the chain) -> a matched row pairing one of them with another function is a `conflict` -> an import against a function is `unmapped` -> rule iv (equal `h0` at the same RVA, or the consensus of the other callers). `identical=True` maps every address to itself and skips the voting. As built for A-30 (2026-11-11): `_blocked` is the rule-3 competing-claim check on the full tables (a competing datum that is incomplete blocks even with a single vote, because its dropped votes are unknown; an incomplete partner blocks too); `_others_agree` is rule 4(b) per judged row with explained dissents ignored, cached per (datum, partner, voter); the conflict clause, `data_token` and the region-shift neighbours use the full-table consensus; under `datamap-cap` which vote pairs are kept still depends on the orientation, but the data of a dropped pair abstain either way. `data_token` hands `@D:<t>.<u>` labels to `canon/1`, so a datum with a bidirectional consensus has the same label on both sides, a swapped global changes the pseudo-code, and a datum without a consensus is an unmapped label (COS-PSEUDO/1 then needs none).
EH-EQ (`facts/eh.py`): both without unwind data -> `absent`; one-sided -> `differs`; a truncated or unparsable signature, a `pdata-unreadable` warning of either image, or a handler or filter that is neither equal, function-relative nor mapped -> `unavailable` (never `equal`); version, flags, prolog size, frame, unwind codes and handler-data length must be equal; a handler that is a `conflict` or scopes that differ in count, begin, end or target -> `differs`. A `differs` adds the row class `eh` and blocks every proof; `unavailable` blocks UNCH/1 and the structural proofs.
Verdict deltas: `_ir_proof` order is UNCH/1 (C0 equal, targets_ok, EH-EQ, no deltas, no cap), then COS-ADDR/1, COS-LAYOUT/1, then COS-PSEUDO/1; the pseudo proof (shared by both modes) additionally forbids the blocking delta classes and any unmapped canon label. A `second_channel` needs a channel of ANOTHER data group in state `differs` (`C0`, `C1`, `C2`, `C5` are one group; a channel that is `equal` never anchors). Anchors as built: calls by C4 (exactly that callee pair is a leftover), else C6 (the call identity is among the removed or added calls of the canonical code), else BinDiff flag C; `constant` and `struct-offset` by the literal pair in the C6 numbers (a literal may be spelled signed, negated or unsigned at any width; a struct offset also as a `field_0x..` name); `comparison`/`condition` by a changed relational or logical operator multiset in C6; `data-ref` by the two DATA-MAP tokens leaving and entering the canonical tokens; `string` by the literal prefix; `block-added`/`block-removed` that hold a store or a call by differing C3 counts or BinDiff flag G. `trace-arg` (F17, `facts/trace.py`): every constant delta of the pair loads an argument register that a later call of its block consumes, the callee being a tracing import from the closed table (thunks resolved); ordering hint only.
Registry: `CHANNEL_VERSIONS` gained C0-C5, `align`, `datamap`, `eh-eq`; `PROOF_VERSIONS` gained UNCH/1, COS-ADDR/1, COS-LAYOUT/1 (all version 1); they enter `config_digest`, so results computed before S3 are recomputed once.
Open limits (reported, not hidden): (1) a switch table whose targets are permuted among the cases is invisible to the IR (the set of targets is equal); (2) block pairing has no similarity fallback, so a guard added at the function entry leaves most blocks unpaired and the pair yields many `unknown` deltas, still `review`/`material`, never a proof; (3) a single-use datum with no confirmed neighbour in its section, a data reference into a code section (ctor lists) and a function with unmapped targets stay `unmapped`: `review`, class `address-only`, never material (the real MinGW pair of docs/qa.md [S3:ir-facts] shows 7 of 61 CRT functions in that state; large images have more confirmed neighbours); (4) instructions are decoded per pair (about 8 microseconds per instruction), equal-`h1` pairs are not fast-pathed on the `ref` rows; (5) MSVC output (RVA-form switches, CFG dispatch, /GS cookies) and Windows were not seen by S3, only clang and MinGW code.
Integration asks (S3 does not edit `compute.py`, `worker.py` or `fusion/arbiter.py`): (a) `compute.py` builds `IrSides` from the two placed sidecars, passes `ir_sides=` and `budget=` and fills the `ir_older`/`ir_newer` references and drops the `ir-not-extracted` limitation; (b) `worker.MODULES` (the frozen self-check list) may list the new `facts.*` modules; (c) `arbiter.to_match(..., flags=judged.flags)` stores the row flags; (d) `IrSides.identical` is `older_sha256 == newer_sha256`; (e) the `IrReader -> IrSide` adapter for the ladder (S2 seam) is still missing; (f) the `refacts` stage (S3b, 2.8): `select_for_decompile` over the judged rows, `decompile_side` for the older and the newer side with the chosen RVAs (the GZFs retained by the run), `FactsContext.build(..., decompiled=)` again, judge those rows only, publish them. As built, a text only ever becomes the SECOND channel: a decompiled difference without a bytes delta cannot make a row `material`, and a text that does not show the edited literal leaves the row in `review`.


## R8 adversarial correction proposal: typed numeric literals (2026-10-30)

**R8-LIT-01 (source-observed, compiler corroborated; no end-to-end Ghidriff accuracy claim).** The earlier `canon/1` value-only numeric rule may not erase type-relevant C literal syntax. For instance, on common 32-bit-`int` Windows x64 C targets, the expressions `x < 2147483648` and `x < 2147483648U` are not interchangeable. Likewise, `0.1` and `0.1f` are double and float literals respectively. Equal normalized tokens from these pairs could incorrectly satisfy the weak `COS-PSEUDO/1` conditions when the decompiler actually emits both forms.

**Conservative `canon/2` amendment (R8):** preserve unsigned and long/long-long suffix type hints in canonical integer tokens; parse leading-zero integer literals as octal per ISO C; retain explicit `f/F` floating suffix while leaving unsuffixed literals distinct; for unsuffixed integer constants above `INT32_MAX` preserve decimal vs hexadecimal vs octal radix as a type-relevant distinction. Normalize same-type small decimal/hex values by mathematical value (e.g. `256` == `0x100`) and equivalent suffix orderings (e.g. `16uL` == `16Lu`). Parse a malformed token conservatively and retain its spelling rather than interpreting it as a valid numeric constant. No signedness or width probability is inferred from missing compiler-specific type information. This is a *false-benign reduction* and may conservatively increase review outcomes.

**Integration requirements:** bump `registry.CHANNEL_VERSIONS['canon']` from 1 to 2 so the result `config_digest` changes; do not modify persisted wire schemas; the `PROOF_VERSIONS` bump belongs to the R3-PC01 EH-EQ narrowing; write failing focused tests before the implementation; preserve existing `0x100`/256 normalization; run native Ghidriff sample to determine whether its real decompiler output exhibits the hostile spellings. This correction must not turn a decompiler-relative canonical proof into a claim of binary behavioral equivalence.

**Reproducibility and constraints:** source fixtures, exact compiler versions and independent `.text` digests are in `docs/research/deep-uncertainty-r8/01-typed-literal-counterexamples.md`; no compiled artifact is committed, and no target binary is executed. Acceptance is *source-unit verified* first, *native integration pending* until CI runs with real Ghidra/Ghidriff.


### Reconciled literal contract clarification

On the Windows x64 LLP64 target, a signed `L` suffix does not remove radix-dependent type selection above `INT32_MAX`: `2147483648L` and `0x80000000L` must remain distinct. Preserve radix for signed long literals above that bound (and signed long-long above `INT64_MAX`), while keeping small same-type spellings equivalent. Both `canon` channel version 2 and `COS-PSEUDO/1` proof implementation version 3 participate in the configuration digest (implementation version 2 was already taken by the FCT-03 register-only blocker, so the R3-PC01 EH-EQ narrowing ported on 2026-11-18 from PR #144 is version 3). This is a conservative proof correction, not native acceptance.

Exponent-form floating constants with no decimal point (such as `010e1`) must be scanned as one float token before octal integer normalization. Otherwise `010e1` (100.0) can collide with `8e1` (80.0) in both C5 and C6. Preserve exponent and suffix spelling conservatively.

Typed integer keys must remain usable by downstream facts: sort by numeric value with type/radix as a deterministic tie-break, render the retained type/radix as C literal syntax, and compare numeric value forms only for MAT-ANCHOR corroboration of an independently observed machine constant delta. Keep full typed keys for C5/C6 equality; a type-only edit cannot fabricate a machine delta.

For machine-value corroboration, project typed numeric tokens to value keys before multiset subtraction. Type-only suffix exchanges between two unchanged values must not manufacture a removed/added value pair. Preserve the original typed counters for C5/C6 equality and display.

For structure offsets, the secondary text fallback recognizes only removed/added field identifiers carrying actual offset syntax (such as `field_0x100`), not raw numeric tokens whose values have already cancelled. Both constant and structure-offset anchors must reject suffix-only exchanges.
