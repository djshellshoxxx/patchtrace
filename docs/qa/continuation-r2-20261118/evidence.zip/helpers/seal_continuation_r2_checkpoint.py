"""Seal the reviewed R2 integration and source-specific hosted evidence without changing product code."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
SOURCE = 'ae0b1660e0cc71c51698d70a685ceeb646619184'
TREE = 'd5b7e08770ee250fc453d55149562476b0bc9926'
QA = ROOT / 'qa/continuation-r2-integration'
DEST = REPO / 'docs/qa/continuation-r2-20261118'
HOSTED = REPO / 'docs/qa/hosted-pr316-55f3-20261118'


def git(*args: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(REPO), *args])


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('status', '--porcelain')
assert git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE
exit_receipt = json.loads((QA / 'combined-exit.json').read_bytes())
assert exit_receipt['exit'] == 0 and exit_receipt['imported_source_count'] == 522
assert not exit_receipt['foreign_imports'] and not exit_receipt['imported_source_drift']
assert json.loads((QA / 'strict-sites-comparison.json').read_bytes())['same_path_code_selected_statement_multiset']
owners = json.loads((QA / 'source-preservation-ae0b1660.json').read_bytes())
assert len(owners['files']) == 31 and owners['all_changed_paths_owned']

note = f'''# Reviewed R2 continuation — 2026-11-18

## Exact candidate and result

Clean source `{SOURCE}`, tree `{TREE}`, passes **3,528 tests with nine explicit
skips and zero failures/errors** in **282.90 seconds** (284.98 seconds wall).
The 108-file selection combines the prior continuation controls, the R2 affected
neighbors and the unchanged external product probes. All 522 imported project
modules came from this checkout, with no foreign editable import or source drift.
The no-input backend-pin probe again records no real process invocation.

All **31** changed source/test/tool/workflow paths since published PR316
`55f3d0742f7d4cf32357a42b8b1cc76d85875e71` match the independently reviewed owner
bytes. No production conflict was resolved manually. The one batch-4 document
conflict preserved both append-only bodies in four tracking files; its exact
stage hashes and bodies are retained. Main was freshly observed unchanged at
`9c411ca3d7b47f950be5f0c6f01b3c54184554c6`; PR316 remained open/unmerged at55
before this append-only publication. No PR was merged/closed, branch deleted,
history rewritten, tag created or release published.

## R2 source repair and independent review

Author source `8f0864277d29d3d77a22ee8b30cede7146aa0c9b` reserves the cross-component,
cross-class B+B atoms needed by an accepted pairing at the L-39 cap, including a
contested row with a matched base. Existing strongest-component Support and
opposition/mirror groups remain intact. An insufficient custom cap raises the
typed atoms-cap refusal before publication. Shared desktop/CLI Decision text
identifies a manual split, merged or ambiguous group only with its recognized
hint and retained on-group manual evidence. Arbiter channel3 rekeys new results;
verified older rows remain readable and byte-identical.

Independent source/spec/test review and **59 focused checks** passed before port.
The author retained 13-red/40-positive spec-first evidence, the intermediate
registry test expectation correction, and the clean764-pass affected gate. Two
unchanged historical Support-index expectations still fail because they demand
a different max-pool contract; they were not rewritten or counted as current
acceptance. The actual external five-node persistence/manual/CLI probe passes
on this combined tree, with original and author observation hashes unchanged.
The [author packet](../r2-evidence-retention-20261118.md) retains its original
failure history. These are authored local mechanics, not native matching accuracy.

## Branch audit and hosted receipts

The independently reviewed [fourth batch](../semantic-disposition-batch4-20261118.md)
adds20 focal dispositions at frozen55: 15 retained scopes, one R2 omission, one
stricter adapter replacement, one retained research prototype and two incomplete
developer/research workflows. Its421 archive members,136 current-source snapshots,
60 current source proofs and all20 tip/merge-base/ahead-behind records were
independently verified. Cumulative selection is **80/131**, with **51** original
tips and broader residue remaining at that checkpoint. This is not a whole-branch
closure count or product-completion percentage.

The [hosted55 review](../hosted-pr316-55f3-20261118/README.md) retains eight jobs,
seven original artifacts and actual checkout identities. Two push jobs ran55;
six PR jobs ran merge preview872947fd, whose tree independently matches55.
Windows/Linux unified fixtures have four identical side digests and explicit
Linux cross-OS passes. Linux BinDiff/rz-diff and the Windows Ghidriff seeded-store
scenario have bounded native positives. Other scenarios remain unverified.
Ubuntu runtime auditing records17 distributions and no reported vulnerabilities;
strict static scanning failed with81 diagnostics and omitted bootstrap-pip.txt
from the artifact upload. All208 packet members and18 source snapshots were
independently checked. None of these older-source results qualifies this candidate.

## Guarded execution, scanners and limits

The combined gate installs the same inherited Linux socket/process-local denial
before collection, verifies no inherited socket descriptors, uses local-only Git
transport, and owns a fresh temporary root outside any Git tree. No assertion was
weakened or test deselected. The capability guard is a test-run boundary, not a
claim about the application's native sandbox. A metadata-construction error
occurred before pytest launch and is retained separately; it was not a test failure.

The nine skips are one native Windows junction, six Windows job/launch/preflight
checks, the optional colorspacious oracle, and the host-denied AF_UNIX capability
probe. Real BinDiff acceptance explicitly reports BLOCKED because no executable
is provisioned locally. The duplicate-ZIP warning is from its hostile-input test.

Configured Ruff over src/tests/tools passes. The isolated ignore-noqa strict S
scan still fails: **80 diagnostics**, with exactly the same path/code/selected
statement multiset as5bbb9256. No diagnostic was suppressed or called a confirmed
vulnerability solely because the scanner reported it. Full Linux/Windows QA,
repeated Qt, native Windows BinDiff isolation, frozen ZIP/installer/Linux packages,
complete dependency/security and reproducibility gates remain open. Main merge
and beta readiness remain blocked.

## Continuing work

The next audit batch has isolated a saved-advisory-scope defect: cached growth can
widen a reopened investigation, and missing coverage can permit mutation. A
separate spec/test-first repair is assigned, preserving global revision admission
and validating scope before writes. An optional dev-only COFF compatibility slice
has a separate reviewed handoff; it is absent from this checkpoint. PW-02 local
MSU/CAB intake remains under bounded native-extraction design, with no implemented
or qualified Windows capability credited here. Remaining branch and A/A research
dispositions continue independently. Frozen L1/L2/L3 records remain unchanged.

## Reproduction

The archive retains exact command/environment/collection/guard/exit/JUnit records,
original observation-integrity proofs, root reviews, source owner hashes, the
five attributed follow-on commits and prepared remote tree/parent mappings.
Run the retained coordinator wrapper only from the exact source after inspecting
its paths; it intentionally refuses existing receipt labels. The original
incomplete broad run remains in the preceding
[continuation checkpoint](../verified-continuation-20261118/README.md), unchanged.
'''

payloads: dict[str, bytes] = {'checkpoint-note.md': note.encode()}
for label, directory in (
        ('combined', QA),
        ('independent-r2', ROOT / 'qa/r2-evidence-retention-root-review'),
        ('independent-batch4', ROOT / 'qa/semantic-disposition-batch4-root-review'),
        ('independent-hosted55', ROOT / 'qa/hosted-55f3-root-review')):
    for path in sorted(directory.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            payloads[label + '/' + path.relative_to(directory).as_posix()] = path.read_bytes()
for name in ('run_continuation_r2_gate.py', 'continuation_offline_pytest.py',
             'replay_r2_continuation.py', 'full_batch_receipt.py',
             'verify_continuation_r2_sources.py', 'seal_continuation_r2_checkpoint.py'):
    payloads['helpers/' + name] = (ROOT / 'ops' / name).read_bytes()
for path in git('diff', '--name-only', '987cfb1b', SOURCE, '--', 'src', 'tests', 'docs/specs').decode().splitlines():
    payloads['source/' + path] = git('show', SOURCE + ':' + path)
payloads['integration/five-commit-history.txt'] = git('log', '--reverse', '--format=fuller',
                                                   '987cfb1b..' + SOURCE)
payloads['integration/source-delta.patch'] = git('diff', '987cfb1b', SOURCE, '--', 'src', 'tests', 'docs/specs')
for name in ('objects.json', 'fresh-before-tail.json'):
    payloads['publication-preparation/' + name] = (ROOT / 'qa/continuation-publication' / name).read_bytes()
resolutions = [json.loads(line) for line in (ROOT / 'qa/followup-integration/record-resolutions.jsonl').read_text().splitlines()]
selected = [r for r in resolutions if r['merge_head'] == '4f71b811dbd1555ce5cb6cffe062dddc3bb801e5']
assert len(selected) == 1 and len(selected[0]['records']) == 4
payloads['integration/append-conflict-record.json'] = (json.dumps(selected, indent=2) + '\n').encode()

DEST.mkdir(parents=True, exist_ok=False)
archive = DEST / 'evidence.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(payloads.items()):
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(set(z.namelist())) == len(payloads)
    assert z.testzip() is None
    for name, data in payloads.items():
        assert z.read(name) == data
raw = archive.read_bytes()
manifest = {'source': SOURCE, 'tree': TREE, 'sealed_utc': datetime.now(timezone.utc).isoformat(),
            'archive': archive.name, 'archive_bytes': len(raw),
            'archive_sha256': hashlib.sha256(raw).hexdigest(),
            'payloads': [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                         for name, data in sorted(payloads.items())]}
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(DEST / 'README.md').write_text(note + '\n## Archive\n\n' +
                              f"{len(payloads)} verified payloads; {len(raw):,} bytes. SHA-256:\n" +
                              f"`{manifest['archive_sha256']}`.\n")

HOSTED.mkdir(exist_ok=False)
for name in ('README.md', 'review.json', 'manifest.json', 'evidence.zip'):
    shutil.copyfile(ROOT / 'qa/hosted-55f3-receipt-review' / name, HOSTED / name)

additions = {
    'docs/plans/patchtrace-completion-matrix.md': '''

## Reviewed R2 continuation and hosted55 evidence — 2026-11-18

Source `ae0b1660e0cc71c51698d70a685ceeb646619184` passes3,528 selected checks with
nine explicit skips, all31 changed source/test/tool/workflow paths equal to reviewed
owners. [Complete source-specific checkpoint](../qa/continuation-r2-20261118/README.md).
R2 witness retention/manual attribution adds the defined D/R milestones (50% for
this bounded slice); representative native/manual J and final G remain open.
Support semantics and old evidence stay intact. Batch4 reaches80/131 selected
original scopes,51 remaining plus broader residue; no whole-branch percentage.

Hosted55 results establish limited authored native fixtures and one runtime audit
at that older tree. Strict81 diagnostics and missing static bootstrap text remain
failed/incomplete; the current source's separate strict scan remains80 unchanged
sites. These results add no final candidate G credit. Saved advisory-scope repair,
remaining branch dispositions, PW-02 local package intake, full/platform/package
qualification and main integration remain unfinished. No beta/release readiness.
''',
    'docs/plans/autonomous-consolidation-20261118/consolidation-ledger.md': '''

## R2 continuation independently reviewed — 2026-11-18

Batch4 and the R2 source chain were selectively appended after independent review.
Clean candidate `ae0b1660e0cc71c51698d70a685ceeb646619184` retains all31 reviewed
owner paths and passes3,528 selected checks/nine explicit skips. No production
conflict resolution occurred. The batch4 document append preserves both histories.
Main remains9c411ca3; all PRs remain unmerged/open where previously open. Exact
hosted55 receipts remain attributed to55 or its equal-tree PR preview, with their
failures and queued states. [Checkpoint](../../qa/continuation-r2-20261118/README.md).
Saved-scope and remaining branch work continue separately; no branch closure.
''',
    'docs/qa.md': '''

## [CONTINUATION-R2-20261118]

Exact source `ae0b1660e0cc71c51698d70a685ceeb646619184`,108 selected files:
3,528 passed/nine explicit skips/zero failures/errors in282.90s. All522 project
imports are pinned; all31 changed owner paths are preserved. Normal Ruff passes;
isolated strict S remains80 identical sites and fails. R2 independent59-pass review,
batch4 proof and hosted55 receipt review retain original contrary evidence.
[Sealed checkpoint](qa/continuation-r2-20261118/README.md) and
[older-source hosted evidence](qa/hosted-pr316-55f3-20261118/README.md).
No final native/package/full/security qualification, main merge or release credit.
''',
    'tasks/todo.md': '''

### [CONTINUATION-R2-20261118]

- [x] Independently review/port batch4 and R2 source/spec/test/QA history; preserve Support and frozen outcomes.
- [x] Verify31 owner paths and exact-source108-file combined gate:3,528 passed/nine skips; retain522 import identities.
- [x] Retain unchanged strict80 findings and independently verify older-source hosted native/runtime/static receipts.
- [x] Seal combined commands/results, original observation hashes and append-only conflict records.
- [ ] Complete append-only PR316 publication and verify remote head/tree/parents without main merge.
- [ ] Repair saved advisory-scope admission before mutations; review remaining51 original tips and broader residue.
- [ ] Qualify PW-02 local package extraction, static artifact retention, current full/platform/native/package/security gates.
''',
}
for path, text in additions.items():
    with (REPO / path).open('a') as stream:
        stream.write(text)
print(json.dumps({'source': SOURCE, 'members': len(payloads), 'archive_bytes': len(raw),
                  'archive_sha256': manifest['archive_sha256'], 'hosted_packet_retained': True}))
