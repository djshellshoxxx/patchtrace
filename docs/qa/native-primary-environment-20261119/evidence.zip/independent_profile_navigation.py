"""Independent review of the New/Duplicate branches of the dirty-draft repair."""
from __future__ import annotations

import pytest
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QMessageBox

from patchtrace.enrichment import profiles
from patchtrace.enrichment.profiles import ProfileStore
from patchtrace.ui import ProfilesPanel


@pytest.fixture
def panel(qtbot, tmp_path):
    store = ProfileStore(tmp_path / 'profiles')
    store.save(profiles.build({'name': 'alpha', 'snapshot_max_age_days': 7}))
    store.save(profiles.build({'name': 'beta', 'snapshot_max_age_days': 15}))
    widget = ProfilesPanel(store.directory, selected='alpha')
    qtbot.addWidget(widget)
    return widget


def answer(monkeypatch, choice):
    seen = []

    def execute(box):
        assert box.defaultButton() == box.button(QMessageBox.StandardButton.Cancel)
        assert box.escapeButton() == box.button(QMessageBox.StandardButton.Cancel)
        assert box.textFormat() == Qt.TextFormat.PlainText
        seen.append(box.text())
        return choice

    monkeypatch.setattr(QMessageBox, 'exec', execute)
    return seen


@pytest.mark.parametrize('action', ['new_profile', 'duplicate_profile'])
@pytest.mark.parametrize('choice', [QMessageBox.StandardButton.Save, QMessageBox.StandardButton.Discard])
def test_create_navigation_resolves_current_draft_before_creating(panel, monkeypatch, action, choice):
    panel.max_age.setValue(30)
    seen = answer(monkeypatch, choice)
    getattr(panel, action)()
    expected = 30 if choice == QMessageBox.StandardButton.Save else 7
    assert len(seen) == 1
    assert panel.store.get('alpha').snapshot_max_age_days == expected
    name = 'profile' if action == 'new_profile' else 'alpha copy'
    assert panel.selected_name() == name and panel._editing == name
    assert not panel.is_dirty()
    if action == 'duplicate_profile':
        assert panel.store.get(name).snapshot_max_age_days == expected
    else:
        assert panel.store.get(name).snapshot_max_age_days == profiles.DEFAULT_PROFILE.snapshot_max_age_days
    assert len(panel.store.names()) == 3


def test_duplicate_after_save_rename_uses_committed_source_identity(panel, monkeypatch):
    panel.name.setText('renamed')
    panel.max_age.setValue(30)
    seen = answer(monkeypatch, QMessageBox.StandardButton.Save)
    panel.duplicate_profile()
    assert len(seen) == 1
    assert panel.store.names() == ['beta', 'renamed', 'renamed copy']
    assert panel.selected_name() == 'renamed copy'
    assert panel.store.get('renamed copy').snapshot_max_age_days == 30
    assert not panel.is_dirty()


@pytest.mark.parametrize('action', ['new_profile', 'duplicate_profile'])
def test_invalid_save_before_creation_preserves_all_existing_profile_bytes(panel, monkeypatch, action):
    original = {path.name: path.read_bytes() for path in panel.store.directory.glob('*.json')}
    panel.feature_ids.setText('bad feature')
    seen = answer(monkeypatch, QMessageBox.StandardButton.Save)
    getattr(panel, action)()
    assert len(seen) == 1
    assert panel.selected_name() == panel._editing == 'alpha'
    assert panel.feature_ids.text() == 'bad feature' and panel.is_dirty()
    assert 'Not saved' in panel.error.text()
    assert {path.name: path.read_bytes() for path in panel.store.directory.glob('*.json')} == original


def test_readonly_default_selection_and_creation_never_prompt(panel, monkeypatch):
    seen = answer(monkeypatch, QMessageBox.StandardButton.Cancel)
    panel.list.setCurrentRow(0)
    assert panel.selected_name() == 'default' and panel._editing is None
    panel.new_profile()
    assert panel.selected_name() == 'profile'
    assert seen == []
