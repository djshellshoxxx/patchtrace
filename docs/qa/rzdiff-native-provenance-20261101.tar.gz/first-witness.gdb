set pagination off
set confirm off
set disable-randomization off
set debuginfod enabled off
set auto-load safe-path /nonexistent
unset environment LD_LIBRARY_PATH
set args -C -j -t functions /workspace/scratch/142cb233d750/rzdiff-witness-native-20261101/inputs/single.exe /workspace/scratch/142cb233d750/rzdiff-witness-native-20261101/inputs/two.exe
break *0x5504d2
run > /workspace/scratch/142cb233d750/rzdiff-witness-native-20261101/first-witness.stdout 2> /workspace/scratch/142cb233d750/rzdiff-witness-native-20261101/first-witness.stderr
printf "PT-WITNESS count_a=%u count_b=%u return_eax=%u pc=%p\n", *(unsigned int*)($rbp+24), *(unsigned int*)($r12+24), $eax, $pc
stepi
stepi
printf "PT-WITNESS branch_pc=%p\n", $pc
continue
