"""Original pinned tool, static-analysis controls only; never execute PE inputs.

Research collector only: no production import or quarantine policy writes.
"""
from pathlib import Path
import hashlib
import json
import sys
import threading
import time

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'wt-rzdiff-witness'
sys.path[:0] = [str(REPO / 'src'), str(REPO / 'tests'), str(REPO / 'tools/research')]
from patchtrace.jobs import run_process
from rzdiff_count_observation import Capture, observation, query_argv
from unified_support.assembler import Assembler
from unified_support.pairs import program

EXE = ROOT / 'runtime/bin/rz-diff'
EXPECTED = '536987d5d0e5d2a35689f653502dc10f8be8751a46ef2ffd888e8d514ed9712e'
env = json.loads((ROOT / 'environment.json').read_text())
config_hash = hashlib.sha256((ROOT / 'environment.json').read_bytes()).hexdigest()


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def runtime_manifest():
    return [{'path': str(p.relative_to(ROOT / 'runtime')), 'bytes': p.stat().st_size, 'sha256': sha(p)}
            for p in sorted((ROOT / 'runtime').rglob('*')) if p.is_file()]


assert sha(EXE) == EXPECTED
before = runtime_manifest()
(ROOT / 'runtime-manifest-before.json').write_text(json.dumps(before, indent=2) + '\n')
two_shift = program((('entry', Assembler().call('head').call('tail').ret()),
                     ('head', Assembler().mov('rax', 17).ret()),
                     ('tail', Assembler().add('rax', 3).ret())), padding=64)
two_shift.write(ROOT / 'inputs/two-shift.exe')
inputs = {p.stem: p for p in sorted((ROOT / 'inputs').glob('*.exe'))}
input_hashes = {name: sha(path) for name, path in inputs.items()}
rows = []
cancel = threading.Event()
timer = threading.Timer(120, cancel.set)
timer.start()
try:
    jobs = [(f'count-{name}', list(query_argv(str(EXE), str(inputs[name]))), 'count')
            for name in ('zero-control', 'single', 'two', 'two-shift')]
    jobs += [(label, [str(EXE), '-C', '-j', '-t', 'functions', str(inputs[a]), str(inputs[b])], 'all-functions')
             for label, a, b in [('zero-vs-two', 'zero-control', 'two'),
                                 ('one-vs-two', 'single', 'two'),
                                 ('two-vs-one', 'two', 'single'),
                                 ('two-vs-shift', 'two', 'two-shift')]]
    jobs += [(label, [str(EXE), '-C', '-j', '-t', 'functions', '-0', anchor,
                     str(inputs[a]), str(inputs[b])], 'forced-singleton')
             for label, a, b, anchor in [
                 ('forced-one-vs-two', 'single', 'two', '0x180001010'),
                 ('forced-two-vs-one', 'two', 'single', '0x180001010'),
                 ('forced-two-vs-shift', 'two', 'two-shift', '0x180001010'),
                 ('missing-function', 'two', 'single', '0x18000ffff')]]
    drift_argv = list(query_argv(str(EXE), str(inputs['two'])))
    drift_argv[1:1] = ['-e', 'analysis.calls=false']
    jobs.append(('config-drift', drift_argv, 'rejected-config-drift'))
    for label, argv, kind in jobs:
        assert sha(EXE) == EXPECTED
        assert all(sha(path) == input_hashes[name] for name, path in inputs.items())
        start = time.monotonic()
        result = run_process(argv, cwd=ROOT, env=env, cancel=cancel, timeout_seconds=20,
                             log_limit=1024*1024, stderr_limit=1024*1024, separate_streams=True,
                             max_output_bytes=2*1024*1024, memory_limit_bytes=2*1024**3)
        stdout, stderr = result.log_bytes or b'', result.stderr_bytes or b''
        (ROOT / f'{label}.stdout').write_bytes(stdout)
        (ROOT / f'{label}.stderr').write_bytes(stderr)
        row = {'label': label, 'kind': kind, 'argv': argv, 'returncode': result.returncode,
               'reason': result.reason, 'seconds': round(time.monotonic()-start, 4),
               'stdout_sha256': hashlib.sha256(stdout).hexdigest(), 'stdout_bytes': len(stdout),
               'stderr_sha256': hashlib.sha256(stderr).hexdigest(), 'stderr_bytes': len(stderr),
               'orientation_authorized': False}
        if kind == 'count':
            name = label.removeprefix('count-')
            capture = Capture(tuple(argv), input_hashes[name], config_hash,
                              returncode=result.returncode, reason=result.reason)
            try:
                row['observation'] = observation(capture, stdout, stderr)
            except ValueError as exc:
                row['observation_rejected'] = str(exc)
        rows.append(row)
        (ROOT / 'controls.json').write_text(json.dumps(rows, indent=2) + '\n')
        print(label, result.returncode, result.reason, len(stdout), len(stderr), flush=True)
        if cancel.is_set():
            break
finally:
    timer.cancel()
after = runtime_manifest()
checks = {'runtime_bytes_unchanged': before == after,
          'inputs_unchanged': all(sha(path) == input_hashes[name] for name, path in inputs.items()),
          'input_sha256': input_hashes, 'environment_sha256': config_hash,
          'orientation_authorized': False, 'ptrace_observer_available': False,
          'executed_targets': False, 'quarantine_changed': False}
(ROOT / 'controls-integrity.json').write_text(json.dumps(checks, indent=2) + '\n')
assert checks['runtime_bytes_unchanged'] and checks['inputs_unchanged']
