"""Authored offline project: actual headless CLI, then real MainWindow/Calls flow."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

from callgraph_cli_support import make_project, match_id
from callgraph_fixtures import build_fixture

QA = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/c7a9e8d98848/callgraph-cap')
SOURCE = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
NOTE = 'The view is capped; some nodes or edges may be omitted.'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    journey = QA / 'journey'
    journey.mkdir()
    project = make_project(journey / 'synthetic-project', build_fixture('cycle_hub'))
    database = project / 'project.sqlite3'
    before = digest(database)
    hub, ordinary = (match_id(project, name) for name in ('TraceMessageHub', 'Caller000'))
    guard = journey / 'headless-guard'
    guard.mkdir()
    (guard / 'sitecustomize.py').write_text(
        "import sys\n"
        "class NoQt:\n"
        "    def find_spec(self, fullname, path=None, target=None):\n"
        "        if fullname.split('.')[0] in {'PySide6', 'PyQt6', 'PyQt5'}:\n"
        "            raise RuntimeError('headless graph imported Qt: ' + fullname)\n"
        "sys.meta_path.insert(0, NoQt())\n")
    env = os.environ.copy()
    env['PYTHONPATH'] = str(guard) + ':' + str(ROOT / 'src')
    commands = [
        ('capped-neighbours', ['neighbours', str(project), '--name', 'TraceMessageHub', '--side', 'newer', '--json'], 3),
        ('capped-dot', ['export', str(project), '--match', hub, '--format', 'dot',
                        '--output', str(journey / 'capped.dot'), '--json'], 3),
        ('capped-json', ['export', str(project), '--match', hub, '--format', 'json',
                         '--output', str(journey / 'capped.json'), '--json'], 3),
        ('uncapped-neighbours', ['neighbours', str(project), '--name', 'Caller000', '--side', 'newer', '--json'], 0),
        ('uncapped-dot', ['export', str(project), '--match', ordinary, '--format', 'dot',
                          '--output', str(journey / 'uncapped.dot'), '--json'], 0),
    ]
    receipt = {'source': SOURCE, 'synthetic': True, 'network': False, 'native_engines': False,
               'qt_import_forbidden_in_cli': True, 'database_before': before, 'cli': [], 'gui': []}
    for name, args, expected in commands:
        argv = [sys.executable, '-m', 'patchtrace', 'graph', *args]
        done = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True, text=True, timeout=30)
        (journey / (name + '.stdout')).write_text(done.stdout)
        (journey / (name + '.stderr')).write_text(done.stderr)
        receipt['cli'].append({'name': name, 'argv': argv, 'exit': done.returncode})
        assert done.returncode == expected, (name, done.returncode, done.stdout, done.stderr)
        data = json.loads(done.stdout)
        assert data['status'] == ('partial' if expected == 3 else 'ok')
        if name.endswith('neighbours'):
            view = data['result']['views'][0]
            assert view['truncated'] is (expected == 3)
            assert (NOTE in view['limitations']) is (expected == 3)
            if expected == 3:
                assert len(view['nodes']) == 65 and len(view['edges']) == 64
                assert [m['count'] for m in view['more']] == [2]
    capped_json = json.loads((journey / 'capped.json').read_text())
    assert capped_json['truncated'] and capped_json['limitations'].count(NOTE) == 1
    assert all(capped_json[side]['truncated'] for side in ('older', 'newer'))
    assert '// Partial graph: ' + NOTE in (journey / 'capped.dot').read_text()
    assert f'  label="{NOTE}";' in (journey / 'capped.dot').read_text()
    assert NOTE not in (journey / 'uncapped.dot').read_text()
    assert digest(database) == before

    from PySide6.QtCore import QSettings
    from PySide6.QtWidgets import QApplication

    from patchtrace.callgraph import panel_data
    from patchtrace.service import ProjectService
    from patchtrace.ui import MainWindow

    app = QApplication.instance() or QApplication([])
    settings = QSettings(str(journey / 'gui-settings.ini'), QSettings.Format.IniFormat)
    service = ProjectService.open(project, maintenance=False)
    window = MainWindow(service=service, settings=settings)
    window.resize(1400, 900)
    try:
        window.show()
        window.panels.show_panel('graph')
        controller = window.panels.controller('graph')
        assert controller is not None

        def settle():
            deadline = time.monotonic() + 15
            while controller.tasks.busy() or controller.loading:
                app.processEvents()
                if time.monotonic() >= deadline:
                    raise RuntimeError('real Calls controller did not settle')
                time.sleep(0.002)
            app.processEvents()

        def select(label):
            table = controller.panel.changes
            model = table.table_model
            row = next(i for i in range(model.rowCount()) if model.texts_at(i)[0] == label)
            table.selectRow(row)
            settle()

        def record(name):
            found = controller.found
            text = controller.panel.state.status_label().full_text()
            receipt['gui'].append({'name': name, 'kind': controller.panel.state.kind,
                                   'status': text, 'flags': sorted(controller.flags),
                                   'view_truncated': found.view.truncated,
                                   'nodes': len(found.view.nodes), 'edges': len(found.view.edges),
                                   'displayed_neighbours': len(found.rows)})
            return text

        settle()
        select('TraceMessageHub')
        assert controller.found.view.truncated
        assert NOTE in record('capped')
        assert '64 of 64' not in receipt['gui'][-1]['status']
        assert NOTE in panel_data.dot_text(controller.data, controller.found)
        controller._refresh_rows()
        settle()
        assert 'capped' in controller.flags and NOTE in record('after-changes-delivery')
        assert window.grab().save(str(journey / 'capped-window.png'))
        select('Caller000')
        assert not controller.found.view.truncated
        assert 'capped' not in controller.flags and NOTE not in record('narrowed')
        assert NOTE not in panel_data.dot_text(controller.data, controller.found)
        assert window.grab().save(str(journey / 'narrowed-window.png'))
    finally:
        window.close()
        app.processEvents()
    receipt['database_after'] = digest(database)
    assert receipt['database_after'] == before
    (QA / 'real-journey.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'source': SOURCE, 'cli_commands': len(receipt['cli']),
                      'gui_states': len(receipt['gui']), 'database_unchanged': True}, indent=2))


if __name__ == '__main__':
    main()
