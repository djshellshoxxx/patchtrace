import sys
class NoQt:
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split('.')[0] in {'PySide6', 'PyQt6', 'PyQt5'}:
            raise RuntimeError('headless graph imported Qt: ' + fullname)
sys.meta_path.insert(0, NoQt())
