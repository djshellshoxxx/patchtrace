from pathlib import Path
import os,sys,json,subprocess,hashlib
p=Path(__file__).resolve().parent;w=Path('/workspace/scratch/c7a9e8d98848/callgraph-cap')
name=sys.argv[1];files=sys.argv[2:]
assert files
a=['/workspace/scratch/3a6632a6e5ff/venv/bin/python','-m','pytest','-q',*files,'--junitxml='+str(p/(name+'.xml')),'--tb=short']
e=os.environ.copy();e.update(QT_QPA_PLATFORM='offscreen',PYTHONPATH=str(w/'src')+':'+str(w/'tests'))
r0={'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=w,text=True).strip(),'status':subprocess.check_output(['git','status','--short'],cwd=w,text=True),'cwd':str(w),'args':a,'env':{k:e[k] for k in ('QT_QPA_PLATFORM','PYTHONPATH')}}
with (p/(name+'.log')).open('w') as f:r=subprocess.run(a,cwd=w,env=e,stdout=f,stderr=subprocess.STDOUT)
r0['exit_code']=r.returncode
(p/(name+'-command.json')).write_text(json.dumps(r0,indent=2)+'\n')
print(name,'exit',r.returncode)
raise SystemExit(r.returncode)
