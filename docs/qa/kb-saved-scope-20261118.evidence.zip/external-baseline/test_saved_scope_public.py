"""Authored public saved-scope evidence; synthetic PE/CVRF inputs, no native/network."""
from __future__ import annotations

import contextlib
import importlib.util
import io
import json
from pathlib import Path

import pytest
from kbc_k1_support import no_sockets  # noqa: F401
from kbc_k3_support import FixedClock, write_pair

from patchtrace.kbcorrelation import cli, wiring
from patchtrace.kbcorrelation.store import KbcStoreError, WorkspaceStore

HERE = Path(__file__).parent
SPEC = importlib.util.spec_from_file_location('original_kbscope_fixture', HERE/'historical/kbscope/tests/test_kbc_saved_scope.py')
H = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(H)
EVIDENCE = HERE/'saved-scope-public'
EVIDENCE.mkdir(exist_ok=True)
pytestmark = pytest.mark.usefixtures('no_sockets')


@pytest.mark.parametrize('grow_cache', [False, True])
def test_cached_search_scope_survives_reopen_project_attach_and_cli(tmp_path, grow_cache):
    service = H._service(tmp_path)
    jan = H._add(service, H._document())
    out = service.search(H.h.KB_CLIENT)
    inv = out.result['investigation_id']
    product = out.result['scopes'][0]['scope_id']
    with WorkspaceStore(service.root) as ws:
        original = ws.current_revision(inv)
        coverage = [ws.get_coverage(key).model_dump(mode='json') for key in original.coverage_ids]
    if grow_cache:
        H._add(service, H._document('2099-Feb', H.h.CVE_B, 'february.sys flaw', date='2099-02-13'))
    service = wiring.build_service(service.root, clock=FixedClock())
    components = service.components(inv, product=product, files=['exampledrv.sys'])
    older, newer = write_pair(tmp_path)
    project = tmp_path/'project'
    attached = service.import_pair(inv, str(older), str(newer), str(project))
    assert attached.exit == 0
    exported = tmp_path/'context.json'
    assert service.export(str(project), str(exported), overwrite=False).exit == 0
    context = json.loads(exported.read_bytes())
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        code = cli.main(['explain', str(project), '--workspace', str(service.root), '--json'],
                        env=wiring.build_env(clock=FixedClock()))
    document = json.loads(out.getvalue())
    assert code == 0
    observed = {row['cve'] for row in document['result']['cves']}
    receipt = dict(grow_cache=grow_cache, original_source=jan.doc_id, original_coverage=coverage,
                   components=components.result, attach=attached.result, exported_context=context,
                   cli_exit=code, cli_document=document, cli_stderr=err.getvalue())
    (EVIDENCE/f'cached-grow-{grow_cache}.json').write_text(json.dumps(receipt, indent=2)+'\n')
    assert observed == {H.h.CVE_A}
    assert {source['doc_id'] for source in context['sources']} == {jan.doc_id}
    assert context['context']['coverage'] == coverage


def test_missing_saved_coverage_refuses_before_investigation_mutation(tmp_path):
    service = H._service(tmp_path)
    jan = H._add(service, H._document())
    out, inv, product = H._search(service, tmp_path, 'months', jan)
    with WorkspaceStore(service.root) as ws:
        original = ws.current_revision(inv)
        key, = original.coverage_ids
        ws.db.execute('DELETE FROM coverage WHERE coverage_id=?', (key,))
        before = '\n'.join(ws.db.iterdump())
    error = None
    outcome = None
    try:
        outcome = service.components(inv, product=product, files=['user.sys'])
    except KbcStoreError as exc:
        error = dict(type=type(exc).__name__, code=exc.code, message=str(exc))
    with WorkspaceStore(service.root) as ws:
        after = '\n'.join(ws.db.iterdump())
        current = ws.current_revision(inv)
    (EVIDENCE/'missing-coverage.json').write_text(json.dumps(dict(error=error,
        outcome=None if outcome is None else outcome.result,
        original_revision=original.revision, current_revision=current.revision,
        database_unchanged=before==after), indent=2)+'\n')
    assert error is not None and before == after
