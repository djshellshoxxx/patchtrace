"""Existing valid saved CSAF receipts; original ae0b index bytes, no native/network work."""
from pathlib import Path
import importlib.util
import json
import sys

import kbc_helpers as h
import pytest
from kbc_k1_support import NOW, no_sockets, valid_csaf  # noqa: F401
from kbc_k3_support import FixedClock

from patchtrace.kbcorrelation import wiring
from patchtrace.kbcorrelation.sources.importer import import_bytes
from patchtrace.kbcorrelation.store import WorkspaceStore
from patchtrace.kbcorrelation.workflow import Event

pytestmark = pytest.mark.usefixtures('no_sockets')
HERE = Path(__file__).resolve().parent
OLD = HERE / 'baseline-source/src/patchtrace/kbcorrelation/index.py'
SPEC = importlib.util.spec_from_file_location('patchtrace.kbcorrelation.original_saved_scope_index', OLD)
ORIGINAL = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = ORIGINAL
SPEC.loader.exec_module(ORIGINAL)


@pytest.mark.parametrize('use_original_receipt', [False, True])
def test_unchanged_cached_csaf_sources_keep_their_valid_saved_receipt(tmp_path, use_original_receipt):
    service = wiring.build_service(tmp_path / 'workspace', clock=FixedClock())
    original = ORIGINAL.ReverseIndex()
    value = valid_csaf()
    for title in ('Authored first snapshot', 'Authored second snapshot'):
        value['document']['title'] = title
        raw = json.dumps(value).encode()
        doc = import_bytes(raw, now=NOW, advisory=service.env.advisory)
        original.add(doc)
        with WorkspaceStore(service.root) as store:
            store.add_document(doc, raw)
    out = service.search(h.KB_CLIENT)
    investigation = out.result['investigation_id']
    receipt = original.coverage(now=NOW)
    assert len(receipt.scope.doc_ids) == 2 and len(receipt.inspected_ids) == 1
    if use_original_receipt:
        with WorkspaceStore(service.root) as store:
            rev = store.current_revision(investigation)
            store.put_coverage(receipt)
            store.apply(rev, Event('search_done', rev.revision, outcome='METADATA_READY',
                                   scope_ids=rev.scope_ids, coverage_ids=(receipt.coverage_id,)))
    reopened = wiring.build_service(service.root, clock=FixedClock())
    assert reopened.products(investigation).exit == 0
