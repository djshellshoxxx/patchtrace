# Saved advisory scope: accepted narrow follow-up design

This investigation is pinned to actual PR316 source
`55f3d0742f7d4cf32357a42b8b1cc76d85875e71`, tree
`11a0c1598764ebd3fd8d3b540377aa52e949f88a`. No repair is included in batch5.
Root assigned implementation to report_evidence_review after its COFF handoff;
that implementation has its own later source pin and must compare changed seams.

## Immutable evidence

- `historical/kbscope/tests/test_kbc_saved_scope.py`: original git-show bytes from
  `0130bf81e2fe3154f30af7b68a0e6ab197946040`, 15,649 bytes, SHA256
  `baa5b56e0c238f74b91c71706abb9a7161cd616f51f1a53a8a1b6ed13a97f0a9`.
- `historical-kbscope.command.json/.log/.xml`: 40 failures / 4 positives. All 44
  nodes are individually classified in `historical-result-disposition.json`.
- `test_saved_scope_public.py`: 4,085 bytes, SHA256
  `cf2f3320e7eaab89a2e38d8a71724e2de67f6270c3a6c4c154fa2f56218fcb5c`.
  `saved-scope-public.command.json/.log/.xml`: 2 failures / 1 positive. Actual
  search -> reopen -> components -> import_pair -> export -> reopened CLI explain
  shows two CVEs while saved coverage still names only January. Deleting the
  coverage row lets components advance revision 3 to 5 and change the database.
  Full observations are in `saved-scope-public/`. Targets are synthetic PE bytes;
  no target execution, engine, acquisition or network was used.

## Current admission contract and bounded repair

Use one pure resolver for advisory leads (KB/CVE). Require exactly one referenced
coverage row; validate table key, body coverage_id and recomputed coverage identity,
coherent kind/fields, selected-source readability and detectable requested/inspected
coverage drift. Translate invalid rows to a domain refusal with repeat-search guidance.
Cached scope uses its finite recorded doc_ids, including an empty tuple. Provided and
mixed IDs remain finite. Months remain the recorded month selector. Coverage does not
contain exact historical document revisions for month-only searches: do not promise an
immutable historical snapshot or infer missing revisions from timestamps.

Retain the full current ReverseIndex for source admission. Preserve active revision,
withdrawn/negative precedence, native ambiguity and product filtering. A selected older
snapshot does not become current because the index was narrowed first. Three historical
tests explicitly demand that behavior and are classified as policy conflicts.

Validate before mutation in `KbService.components` (product selection and decisions),
`import_pair` (approval, journal and project creation), and `attach(repair_it=True)`.
The attach preflight must validate both the current advisory revision and each selected
journal-body revision before calling generic `repair()`: mark_interrupted writes before
context_for, so a callback-only check is too late. Keep generic recovery unchanged.
Use the same check in products and _resolve_pairs; plan/acquire reuse that path before
requests. Keep existing cancellation, current-source/expected-revision guards, retained
inventory preflight and file/pair-only product context behavior intact.

Direct `context.build_bundle` callers must receive the same advisory-scope validation.
Compute one selected-document edge-set digest: retain the existing kbc.edgeset/1 domain
and canonical sorted edge IDs, intersect selected documents with globally admitted
active documents, and use that digest for both bundle and context key. Unrelated cached
documents then cannot perturb the context key. Preserve old serialized context reads;
only new derived keys change. Explicit repeat search is the widening action.

## Proposed owned seams and acceptance

`src/patchtrace/kbcorrelation/service.py`: _stored_scope/_lead_cves/_lead_cards,
products/components/_resolve_pairs, import_pair, _bundle, attach/_rebuilt_rows.
`context.py`: build_bundle and context key input.
`index.py`: optional selected-document edge_set_digest projection and finite cached
selection without changing global revision admission. A pure saved_scope.py helper may
hold coverage identity/consistency logic. Specs: program-e/KB-integration-plan.md and
the current advisory-revision/snapshot identity contract. No schema or UI rewrite.

Keep original public probes byte-identical. Add refusal assertions for no workspace,
project, decision, journal or attempt writes; cached-empty/additional-document/reopen,
missing/invalid/wrong-ID/contradictory coverage, selected-month drift, direct builder,
repair before mark_interrupted and current-vs-captured journal revisions. Add positives
for explicit repeat search, mixed scopes, source restoration, manual pair-only and
product-only import/repair. Preserve global newer/withdrawn/ambiguous admission with
both selected/unselected revision neighbors; preserve current card provenance and
unknown applicability. Old tests with stricter current refusal but changed error text
are not evidence of false current admission. Native/manual/platform gates stay separate.
