"""Independent persisted-scope check: changed admission must change context identity."""
from __future__ import annotations

import copy
import json
import os
from pathlib import Path

import pytest
from kbc_k1_support import no_sockets  # noqa: F401
from kbc_k3_support import NOW, FixedClock
from kbc_saved_scope_support import add, bundle

from patchtrace.kbcorrelation import wiring
from patchtrace.kbcorrelation.store import WorkspaceStore

pytestmark = pytest.mark.usefixtures('no_sockets')
SOURCE = Path(os.environ['PATCHTRACE_SCOPE_REVIEW_ROOT']).resolve()
OUTPUT = Path(os.environ['PATCHTRACE_SCOPE_REVIEW_OUTPUT']).resolve()


@pytest.mark.parametrize('scope_kind', ['cached', 'files'])
def test_current_global_native_counterevidence_invalidates_saved_cve_context_key(tmp_path, scope_kind):
    raw = json.loads((SOURCE / 'tests/fixtures/kbcve/msrc/2024-Aug-CVE-2024-38193.facts.json').read_bytes())
    raw['DocumentTracking']['CurrentReleaseDate'] = '2026-10-28T01:48:49Z'
    negative = copy.deepcopy(raw)
    negative['Vulnerability'][0]['Remediations'] = []
    service = wiring.build_service(tmp_path / 'workspace', clock=FixedClock())
    positive_doc = add(service, raw)
    options = {}
    if scope_kind == 'files':
        selection = tmp_path / 'scope.json'
        selection.write_text(json.dumps({'months': [], 'doc_ids': [positive_doc.doc_id]}))
        options['scope_file'] = selection
    investigation = service.search('CVE-2024-38193', **options).result['investigation_id']
    before = bundle(service, investigation)
    assert len(before.context.cards) == 1
    negative_doc = add(service, negative)
    service = wiring.build_service(service.root, clock=FixedClock())
    after = bundle(service, investigation)
    with WorkspaceStore(service.root) as store:
        index = store.load_index(service.env.advisory)
        revision = store.current_revision(investigation)
        coverage = store.get_coverage(revision.coverage_ids[0])
        lookup = index.lookup_cve('CVE-2024-38193', scope=coverage.scope, now=NOW)
        assert index.active_ids() == {positive_doc.doc_id, negative_doc.doc_id}
        assert not lookup.edges and lookup.disputed
    assert not after.context.cards
    assert before.context != after.context
    OUTPUT.mkdir(exist_ok=True, parents=True)
    with (OUTPUT / (scope_kind + '.json')).open('x') as stream:
        json.dump({'before': before.model_dump(mode='json'), 'after': after.model_dump(mode='json'),
                   'positive_doc': positive_doc.doc_id, 'negative_doc': negative_doc.doc_id,
                   'same_key': before.context_key == after.context_key,
                   'same_edge_digest': before.edge_set_digest == after.edge_set_digest}, stream, indent=2)
        stream.write('\n')
    assert before.context_key != after.context_key, 'changed current admission reused the saved context identity'
