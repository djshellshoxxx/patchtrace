"""Source-pinned authored-data receipts; no target/native/network execution."""
from pathlib import Path
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import time

ROOT = Path(os.environ['PATCHTRACE_SAVED_SCOPE_ROOT']).resolve()
HERE = Path(__file__).resolve().parent
PYTHON = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
label, *args = sys.argv[1:]
prefix = HERE / label
if prefix.with_suffix('.command.json').exists():
    raise SystemExit('receipt already exists')
env = os.environ.copy()
env.update(PYTHONPATH=os.pathsep.join(map(str, (ROOT/'src', ROOT/'tests', ROOT))),
           QT_QPA_PLATFORM='offscreen')
command = [PYTHON, '-m', 'pytest', '-q', *args, f'--junitxml={prefix}.xml']
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT, text=True)
paths = ['src/patchtrace/kbcorrelation/'+name for name in ('service.py','context.py','index.py','saved_scope.py')]
hashes = {p: hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths if (ROOT/p).is_file()}
pin = subprocess.run([PYTHON, '-c', 'from pathlib import Path; import patchtrace.kbcorrelation.service as s; '
    f'assert Path(s.__file__).resolve() == Path({str(ROOT / paths[0])!r}); print(s.__file__)'],
    cwd=ROOT, env=env, capture_output=True, text=True, check=True)
prefix.with_suffix('.command.json').write_text(json.dumps(dict(source=source, status=status, root=str(ROOT),
    command=command, environment={k:env[k] for k in ('PYTHONPATH','QT_QPA_PLATFORM')},
    source_hashes=hashes, imported_service=pin.stdout.strip()), indent=2)+'\n')
start = time.monotonic()
with prefix.with_suffix('.log').open('wb') as output:
    result = subprocess.run(command, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=240)
receipt = dict(exit_code=result.returncode, wall_seconds=round(time.monotonic()-start, 3))
prefix.with_suffix('.exit.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt))
print('\n'.join(prefix.with_suffix('.log').read_text().split('\n')[-12:]))
raise SystemExit(result.returncode)
