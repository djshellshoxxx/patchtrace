"""Actual inventory selection must retain the recorded advisory inspection boundary."""
import json

import kbc_helpers as h
import pytest
import test_kbc_inventory_selection as s
from kbc_k1_support import no_sockets  # noqa: F401

from patchtrace.kbcorrelation.sources.importer import import_bytes
from patchtrace.kbcorrelation.store import KbcStoreError, WorkspaceStore

pytestmark = pytest.mark.usefixtures('no_sockets')


def test_inventory_selection_refuses_newly_inspected_month_before_any_write(tmp_path):
    service = s.service(tmp_path)
    state = s.start(service, months='2099-Feb,2099-Mar')
    identity = s.inventory(service, tmp_path)
    raw = h.render_json(s.document(release='2099-Mar'))  # Same build; no unrelated conflict can mask this boundary.
    with WorkspaceStore(service.root) as store:
        old = store.current_revision(state[0])
        coverage = store.get_coverage(old.coverage_ids[0])
        assert coverage.inspected_ids == ('2099-Feb',) and coverage.state == 'partial_in_scope'
        store.add_document(import_bytes(raw, now=s.NOW), raw)
        before = '\n'.join(store.db.iterdump())
    error = None
    result = None
    try:
        result = s.select(service, state, identity)
    except KbcStoreError as exc:
        error = exc
    with WorkspaceStore(service.root) as store:
        after = '\n'.join(store.db.iterdump())
        current = store.current_revision(state[0])
    detail = dict(error=None if error is None else dict(code=error.code, message=error.message),
                  result=None if result is None else result.result, rows_unchanged=before == after,
                  before_revision=old.revision, after_revision=current.revision)
    assert error is not None and error.code == 'PT-KBC-SCOPE' and before == after, json.dumps(detail, indent=2)
