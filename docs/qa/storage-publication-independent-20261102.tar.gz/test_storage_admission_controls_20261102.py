"""Independent real-SQLite publication admission controls; no target/native execution."""
import os
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path

import pytest

from patchtrace import verified_backup as V
from patchtrace.service import ProjectService


@pytest.mark.parametrize('failure', [PermissionError, FileNotFoundError, OSError])
def test_pending_scan_io_error_must_not_admit_failed_valid_sqlite(tmp_path, monkeypatch, failure):
    V.forget_all()


    with ProjectService.sample(tmp_path / 'P') as service:
        link = os.link
        published = []
        def mutate(stage, final, **kwargs):
            result = link(stage, final, **kwargs)
            with sqlite3.connect(final) as db:
                db.execute('DELETE FROM history')
                assert db.execute('PRAGMA integrity_check').fetchall() == [('ok',)]
            published.append((Path(stage), Path(final)))
            return result
        with monkeypatch.context() as patch:
            patch.setattr(os, 'link', mutate)
            with pytest.raises(V.BackupError):
                V.write_verified_backup(service.root, service.store.connection, 'history-prune')
        stage, final = published[0]
        original = stage.read_bytes(), final.read_bytes()
        assert V._candidates(service.root, 'history-prune') == []
        V.forget_all()
        scandir = os.scandir
        calls = []
        def pending_refused(path):
            if Path(path) == service.root / 'backups':
                calls.append(path)
                if len(calls) == 2:
                    raise failure('independent pending-stage enumeration refusal')
            return scandir(path)
        with monkeypatch.context() as patch:
            patch.setattr(os, 'scandir', pending_refused)
            found = V.find_verified_backup(service.root, 'history-prune', project_id=service.project.id,
                                           require_tables=('history',))
        assert len(calls) == 2
        assert found is None
        assert (stage.read_bytes(), final.read_bytes()) == original
    V.forget_all()



@pytest.mark.parametrize('operation', ['is_symlink', 'is_file'])
def test_candidate_entry_metadata_error_refuses_even_a_cached_valid_backup(tmp_path, monkeypatch, operation):
    V.forget_all()
    with ProjectService.sample(tmp_path / 'P') as service:
        final = V.write_verified_backup(service.root, service.store.connection, 'history-prune')
        original = final.read_bytes()
        scandir = os.scandir
        class RefusedEntry:
            def __init__(self, entry):
                self.entry = entry
            def __getattr__(self, name):
                if name == operation:
                    def refuse(*args, **kwargs):
                        raise PermissionError('independent entry metadata read refusal')
                    return refuse
                return getattr(self.entry, name)
        @contextmanager
        def metadata_refused(path):
            with scandir(path) as entries:
                yield (RefusedEntry(entry) if entry.name == final.name else entry for entry in entries)
        with monkeypatch.context() as patch:
            patch.setattr(os, 'scandir', metadata_refused)
            assert V.find_verified_backup(service.root, 'history-prune', project_id=service.project.id) is None
            assert V.trusted_backup(service.root, 'history-prune', project_id=service.project.id) is None
        assert final.read_bytes() == original
    V.forget_all()

def test_other_thread_refuses_linked_unvalidated_final_then_admits_completed_copy(tmp_path, monkeypatch):
    V.forget_all()
    with ProjectService.sample(tmp_path / 'P') as service:
        link = os.link
        results, errors = [], []
        def read():
            try:
                results.append(V.find_verified_backup(service.root, 'history-prune', project_id=service.project.id,
                                                       require_tables=('history',)))
            except BaseException as exc:
                errors.append(exc)
        def pause_after_link(stage, final, **kwargs):
            result = link(stage, final, **kwargs)
            reader = threading.Thread(target=read)
            reader.start()
            reader.join(3)
            assert not reader.is_alive()
            assert not errors and results == [None]
            assert Path(stage).read_bytes() == Path(final).read_bytes()
            return result
        with monkeypatch.context() as patch:
            patch.setattr(os, 'link', pause_after_link)
            final = V.write_verified_backup(service.root, service.store.connection, 'history-prune')
        V.forget_all()
        read()
        assert not errors and results == [None, final]
    V.forget_all()
