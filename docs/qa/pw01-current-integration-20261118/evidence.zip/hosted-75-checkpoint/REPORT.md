# PR #304 hosted follow-up at 75ffee38

**Outcome: pending. Linux BinDiff completed successfully; native Windows publication and overall acceptance remain unobserved.**

The bounded read-only window ran from 2026-11-18 10:09:00 UTC to 10:17:53 UTC (8 minutes 53 seconds). Initial and final REST responses verify all seven required runs at head `75ffee3840894adb52aff7f3df28043cc8e832ba`, tree `ebe5021a8d2643767cf3f5c0f5452d787cfd81e4`. PR #304 remained open and unmerged at that head. No submitted reviews, inline review comments or issue comments were returned at either check.

## Final returned state

| Workflow | Run | State |
|---|---:|---|
| QA and Windows standalone | 44282386440 | Pending; all seven QA/Qt jobs queued; release gate skipped |
| Native Windows Ghidriff | 44282386422 | Queued; all five jobs queued |
| Live BinDiff | 44282386457 | Queued overall; Ubuntu job succeeded, Windows queued |
| Live rizin | 44282386539 | Queued; both platform jobs queued |
| Dependency wheels | 44282386522 | Pending; both platform jobs queued |
| Unified extraction | 44282386576 | Pending; Windows job queued |
| Corpus Tier R | 44282386439 | Pending; no jobs returned yet |

Twenty jobs were returned: 18 queued, one succeeded, one skipped, zero failures. These are observed job states, not completed workflow acceptance. All seven workflow conclusions remain null.

Windows QA job `134726180099` has no started steps. No native-publication result or Windows log was observed. Continue with the **Native pair-publication boundary controls** step in [QA run 44282386440](https://github.com/djshellshoxxx/patchtrace/actions/runs/44282386440/job/134726180099).

## Progress retained

Linux BinDiff job `134726176384` progressed from queued to dependency installation, then completed successfully. Its native test step and subsequent live-status-summary step both succeeded. The completed decoded log records **1 passed in 12.78 seconds**; `bindiff-ubuntu-completed-log-response.json` preserves the returned log response and `bindiff-ubuntu-completed.log` preserves its decoded text. This does not establish Windows BinDiff or overall workflow success.

## Evidence and limits

`initial-metadata.json` preserves the initial PR/review/workflow inventory. `initial-runs-jobs.json`, five intermediate polls and `final-snapshot.json` preserve run identities, status and job responses. `summary.json` is the compact handoff; `manifest.json` hashes the evidence payloads.

No rerun, cancellation, mutation or remote write was performed. Wait calls did not exceed 45 seconds. No queue-delay cause is inferred. Monitoring is handed back after the bounded window; full exact-head gates remain required.

