#!/usr/bin/env python3
"""Build a read-only PR metadata and local-graph inventory from sealed receipts."""
from __future__ import annotations

import base64
import collections
import csv
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
REPO = ROOT / "patchtrace"
SOURCE = ROOT / "final-state-refresh-20261118T1034Z/final-open-prs.json"
TARGETS = {
    "pr302": "121ffb0bcdd6af4f24e5035389d4709dffddf263",
    "candidate75": "75ffee3840894adb52aff7f3df28043cc8e832ba",
}
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS="0", GIT_NO_REPLACE_OBJECTS="1")
OPERATIONS = []
START = datetime.datetime.now(datetime.timezone.utc).isoformat()


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def git(*args):
    when = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(
        ["git", "-C", str(REPO), *args], env=ENV, capture_output=True, check=False
    )
    OPERATIONS.append({
        "argv": ["git", "-C", str(REPO), *args], "at_utc": when,
        "exit_code": result.returncode,
        "stdout_base64": base64.b64encode(result.stdout).decode(),
        "stderr_base64": base64.b64encode(result.stderr).decode(),
    })
    return result


def commit_exists(sha):
    return bool(sha) and git("cat-file", "-e", f"{sha}^{{commit}}").returncode == 0


def relationship(head, target):
    if not commit_exists(head) or not commit_exists(target):
        return {"ancestry": "unknown", "reason": "commit object unavailable",
                "patch_equivalence": "not computed", "target": target}
    equal = head == target
    a = git("merge-base", "--is-ancestor", head, target).returncode
    b = git("merge-base", "--is-ancestor", target, head).returncode
    label = "equal" if equal else "ancestor" if a == 0 else "descendant" if b == 0 else "diverged"
    if a not in (0, 1) or b not in (0, 1):
        label = "unknown"
    return {"ancestry": label, "head_is_ancestor_of_target": a == 0,
            "target_is_ancestor_of_head": b == 0,
            "patch_equivalence": "not computed", "target": target,
            "semantic_coverage": "unexamined; ancestry is not semantic certification"}


def changes(raw):
    pieces = raw.split(b"\0")
    if pieces and pieces[-1] == b"":
        pieces.pop()
    rows = []
    i = 0
    while i < len(pieces):
        status = pieces[i].decode()
        i += 1
        path = pieces[i].decode("utf-8", "surrogateescape")
        i += 1
        row = {"status": status, "path": path}
        if status.startswith(("R", "C")):
            row = {"status": status, "old_path": path,
                   "path": pieces[i].decode("utf-8", "surrogateescape")}
            i += 1
        rows.append(row)
    return rows


source_bytes = SOURCE.read_bytes()
original = json.loads(source_bytes)
assert len(original["prs"]) == 54
(OUT / "input").mkdir(exist_ok=True)
(OUT / "input/final-open-prs.json").write_bytes(source_bytes)
receipts = []
for path in sorted((OUT / "raw").glob("*.json")):
    rec = json.loads(path.read_text())
    rec["_file"] = str(path.relative_to(OUT))
    body = rec.get("body_utf8")
    rec["_body"] = json.loads(body) if body and not rec.get("parse_error") else None
    receipts.append(rec)

bases = {}
for branch in sorted({p["base_branch"] for p in original["prs"]}):
    observations = []
    for r in receipts:
        if r.get("kind") != "base" or r.get("base_ref") != branch or r.get("is_error"):
            continue
        body = r["_body"] or {}
        sha = body.get("commit", {}).get("sha") or body.get("object", {}).get("sha")
        if sha:
            observations.append({"sha": sha, "observed_at_utc": r.get("observed_at_utc"),
                                 "receipt": r["_file"], "url": r.get("request_url")})
    observations.sort(key=lambda x: x["observed_at_utc"] or "")
    latest = observations[-1] if observations else {}
    local = git("rev-parse", "--verify", f"refs/remotes/origin/{branch}")
    local_sha = local.stdout.decode().strip() if local.returncode == 0 else None
    bases[branch] = {
        "current_sha": latest.get("sha"),
        "observed_at_utc": latest.get("observed_at_utc"),
        "observations": observations,
        "moved_during_observations": len({o["sha"] for o in observations}) > 1,
        "local_remote_tracking_sha": local_sha,
        "local_remote_tracking_matches_rest": local_sha == latest.get("sha") if local_sha else None,
        "local_commit_available": commit_exists(latest.get("sha")),
    }


def collect(pr, kind):
    pages = [r for r in receipts if r.get("kind") == kind and not r.get("is_error")
             and ((kind in ("reviews", "inline") and r.get("pr") == pr["number"])
                  or (kind in ("checks", "status") and r.get("head") == pr["head_sha"]))]
    pages.sort(key=lambda x: x.get("page", 1))
    items = []
    problems = []
    totals = []
    counts = []
    for r in pages:
        b = r["_body"]
        batch = b if kind in ("reviews", "inline") else b.get("check_runs" if kind == "checks" else "statuses", [])
        if not isinstance(batch, list):
            problems.append("unexpected response shape")
            batch = []
        if kind in ("checks", "status"):
            totals.append(b.get("total_count"))
        if kind == "status" and b.get("sha") != pr["head_sha"]:
            problems.append("combined status SHA differs from captured head")
        if kind == "checks" and any(x.get("head_sha") != pr["head_sha"] for x in batch):
            problems.append("check-run head differs from captured head")
        items.extend(batch)
        counts.append(len(batch))
    indexes = [r.get("page", 1) for r in pages]
    if indexes != list(range(1, len(pages) + 1)):
        problems.append("missing or duplicate page")
    ids = [x.get("id") for x in items]
    if len(ids) != len(set(ids)):
        problems.append("duplicate returned item IDs")
    total = max((n for n in totals if isinstance(n, int)), default=None)
    terminal = bool(pages) and (counts[-1] < 100 or total is not None and len(items) >= total)
    if total is not None and len(items) < total:
        problems.append("reported total exceeds collected items")
    if not terminal:
        problems.append("no terminal page")
    return items, {
        "complete": not problems, "problems": problems,
        "pages": indexes, "page_counts": counts, "per_page": 100,
        "reported_total": total, "collected_count": len(items),
        "termination": "short final page" if counts and counts[-1] < 100 else "reported total reached" if terminal else "unknown",
        "receipt_files": [r["_file"] for r in pages],
        "observed_at_utc": [r.get("observed_at_utc") for r in pages],
    }


def counter(items, key):
    return dict(sorted(collections.Counter(str(x.get(key) or "unknown") for x in items).items()))


def metadata(pr):
    reviews, rp = collect(pr, "reviews")
    inline, ip = collect(pr, "inline")
    checks, cp = collect(pr, "checks")
    statuses, sp = collect(pr, "status")
    submitted = [r for r in reviews if r.get("state") != "PENDING"]
    reviews_out = {
        "pagination": rp, "returned_review_count": len(reviews),
        "submitted_count": len(submitted),
        "submitted_on_captured_head": sum(r.get("commit_id") == pr["head_sha"] for r in submitted),
        "states": counter(reviews, "state"),
        "submissions": [{k: r.get(k) for k in ("id", "state", "commit_id", "submitted_at", "html_url")} for r in reviews],
        "approval_policy": "unexamined; historical counts are not current required approvals",
    }
    inline_out = {
        "pagination": ip, "count": len(inline),
        "on_captured_head": sum(r.get("commit_id") == pr["head_sha"] for r in inline),
        "reply_count": sum(bool(r.get("in_reply_to_id")) for r in inline),
        "count_scope": "REST inline comments, including replies; excludes issue conversation comments",
        "thread_resolution": "unknown; not exposed by these REST reads",
    }
    labels = collections.Counter(
        x.get("conclusion") or x.get("status") or "unknown" for x in checks
    )
    check_text = ", ".join(f"{k}:{v}" for k, v in sorted(labels.items())) or "none"
    status_counts = counter(statuses, "state")
    status_text = ", ".join(f"{k}:{v}" for k, v in status_counts.items()) or "none"
    ci_out = {
        "head_sha": pr["head_sha"], "complete": cp["complete"] and sp["complete"],
        "check_runs_pagination": cp, "commit_statuses_pagination": sp,
        "check_run_count": len(checks), "check_status_counts": counter(checks, "status"),
        "check_conclusion_counts": counter(checks, "conclusion"),
        "commit_status_count": len(statuses), "commit_status_states": status_counts,
        "overview": f"checks {check_text}; statuses {status_text}",
        "check_filter": "latest (explicit or GitHub default)",
        "check_runs": [{k: c.get(k) for k in ("id", "name", "head_sha", "status", "conclusion", "started_at", "completed_at", "html_url", "details_url")} for c in checks],
        "commit_statuses": [{k: s.get(k) for k in ("id", "context", "state", "created_at", "updated_at", "target_url")} for s in statuses],
        "required_gate_policy": "unexamined; metadata overview does not certify merge readiness",
    }
    return reviews_out, inline_out, ci_out


rows = []
for pr in original["prs"]:
    row = dict(pr)
    base = bases[pr["base_branch"]]
    current = base["current_sha"]
    comparison = {
        "historical_pr_payload_base_sha": pr["base_sha_from_pr_payload"],
        "current_base_ref": pr["base_branch"], "current_base_sha": current,
        "current_base_observed_at_utc": base["observed_at_utc"],
        "historical_payload_differs_from_current": current != pr["base_sha_from_pr_payload"] if current else None,
        "merge_bases": [], "changed_files": None, "changed_file_count": None,
        "method": "git merge-base --all current-base head; git diff --name-status --find-renames=50% merge-base head",
        "complete": False,
    }
    if commit_exists(pr["head_sha"]) and base["local_commit_available"]:
        mb = git("merge-base", "--all", current, pr["head_sha"])
        comparison["merge_bases"] = mb.stdout.decode().split() if mb.returncode == 0 else []
        if len(comparison["merge_bases"]) == 1:
            diff = git("diff", "--no-ext-diff", "--no-textconv", "--name-status", "--find-renames=50%", "-z",
                       comparison["merge_bases"][0], pr["head_sha"])
            if diff.returncode == 0:
                comparison["changed_files"] = changes(diff.stdout)
                comparison["changed_file_count"] = len(comparison["changed_files"])
                comparison["complete"] = True
            else:
                comparison["problem"] = "git diff failed"
        else:
            comparison["problem"] = "no unique merge base; not arbitrarily choosing one"
        divergence = git("rev-list", "--left-right", "--count", f"{current}...{pr['head_sha']}")
        if divergence.returncode == 0:
            behind, ahead = map(int, divergence.stdout.split())
            comparison.update(commits_behind_current_base=behind, commits_ahead_of_current_base=ahead)
    else:
        comparison["problem"] = "local commit object unavailable"
    row["computed_base_comparison"] = comparison
    row["computed_relationships"] = {label: relationship(pr["head_sha"], target) for label, target in TARGETS.items()}
    row["rest_reviews"], row["rest_inline_comments"], row["exact_head_ci"] = metadata(pr)
    dump(OUT / f"files/pr-{pr['number']}.json", {
        "number": pr["number"], "head_sha": pr["head_sha"],
        **comparison,
    })
    rows.append(row)
    print(f"PR {pr['number']}: files={comparison['changed_file_count']}; {row['exact_head_ci']['overview']}", flush=True)

assert SOURCE.read_bytes() == source_bytes
assert all(all(row[k] == value for k, value in src.items()) for src, row in zip(original["prs"], rows))
summary = {
    "input_count": len(rows),
    "complete_local_file_comparisons": sum(p["computed_base_comparison"]["complete"] for p in rows),
    "complete_review_lists": sum(p["rest_reviews"]["pagination"]["complete"] for p in rows),
    "complete_inline_lists": sum(p["rest_inline_comments"]["pagination"]["complete"] for p in rows),
    "complete_ci_overviews": sum(p["exact_head_ci"]["complete"] for p in rows),
    "fresh_base_refs": len(bases),
    "historical_pr_base_sha_differs": sum(bool(p["computed_base_comparison"]["historical_payload_differs_from_current"]) for p in rows),
    "review_submissions": sum(p["rest_reviews"]["submitted_count"] for p in rows),
    "inline_comments": sum(p["rest_inline_comments"]["count"] for p in rows),
    "relationship_counts": {t: dict(collections.Counter(p["computed_relationships"][t]["ancestry"] for p in rows)) for t in TARGETS},
    "raw_rest_receipts": len(receipts),
    "rest_error_receipts_preserved": sum(bool(r.get("is_error")) for r in receipts),
    "git_commands": len(OPERATIONS),
    "original_scope_and_disposition_preserved": True,
    "incomplete_metadata_prs": [p["number"] for p in rows if not p["computed_base_comparison"]["complete"] or not p["exact_head_ci"]["complete"] or not p["rest_reviews"]["pagination"]["complete"] or not p["rest_inline_comments"]["pagination"]["complete"]],
}
window = sorted(r["observed_at_utc"] for r in receipts if r.get("observed_at_utc"))
report = {
    "generated_at_utc": START,
    "input": {"path": str(SOURCE), "sha256": hashlib.sha256(source_bytes).hexdigest(), "pagination": original["pagination"]},
    "rest_observation_window": {"first": window[0], "last": window[-1]},
    "methods": {
        "read_only": True, "git_repository": str(REPO),
        "git_environment": {"GIT_OPTIONAL_LOCKS": "0", "GIT_NO_REPLACE_OBJECTS": "1"},
        "diff_direction": "unique merge-base with freshly observed base to captured head",
        "changed_file_count": "one per name-status change; rename counts once with old and new path",
        "head_snapshot": "sealed input, not refreshed by this supplement",
        "patch_equivalence": "not computed", "semantic_review": "unexamined",
        "pagination": "per_page=100; continue until short page or total_count covered",
        "historical_base": "PR payload base SHA is retained; fresh branch REST SHA drives Git comparison",
        "raw_receipts": "body_utf8 preserves exact connector body string; no source downloads or remote writes",
    },
    "targets": TARGETS, "summary": summary, "fresh_base_refs": bases, "prs": rows,
}
dump(OUT / "pr-inventory.json", report)
dump(OUT / "summary.json", summary)
dump(OUT / "git-operations.json", OPERATIONS)

fields = ["pr", "title", "head_sha", "base_ref", "historical_payload_base_sha", "fresh_base_sha",
          "merge_base", "changed_file_count", "relationship_to_302", "relationship_to_75",
          "review_submissions", "reviews_on_captured_head", "inline_comments", "inline_on_captured_head",
          "exact_head_ci", "scope", "disposition", "files_json", "changed_files"]
with (OUT / "pr-inventory.tsv").open("w", newline="") as handle:
    writer = csv.DictWriter(handle, fieldnames=fields, delimiter="\t")
    writer.writeheader()
    for p in rows:
        c = p["computed_base_comparison"]
        writer.writerow({
            "pr": p["number"], "title": p["title"], "head_sha": p["head_sha"],
            "base_ref": p["base_branch"], "historical_payload_base_sha": p["base_sha_from_pr_payload"],
            "fresh_base_sha": c["current_base_sha"], "merge_base": ",".join(c["merge_bases"]),
            "changed_file_count": c["changed_file_count"],
            "relationship_to_302": p["computed_relationships"]["pr302"]["ancestry"],
            "relationship_to_75": p["computed_relationships"]["candidate75"]["ancestry"],
            "review_submissions": p["rest_reviews"]["submitted_count"],
            "reviews_on_captured_head": p["rest_reviews"]["submitted_on_captured_head"],
            "inline_comments": p["rest_inline_comments"]["count"],
            "inline_on_captured_head": p["rest_inline_comments"]["on_captured_head"],
            "exact_head_ci": p["exact_head_ci"]["overview"], "scope": p["scope"], "disposition": p["disposition"],
            "files_json": f"files/pr-{p['number']}.json",
            "changed_files": json.dumps(c["changed_files"], separators=(",", ":"), ensure_ascii=False),
        })


def md(value):
    return str(value).replace("|", r"\|").replace("\n", " ")


lines = [
    "# Final open-PR inventory supplement",
    "",
    "This read-only supplement preserves all 54 captured heads and every original scope/disposition field. "
    "It adds fresh base-ref observations, local merge-base/file comparisons, REST submitted reviews and inline comments, "
    "and CI metadata tied to each captured head. It establishes no new semantic approval or closure.",
    "",
    f"REST observation window: {window[0]}–{window[-1]}. The head inventory is the sealed earlier snapshot; this is not an atomic live snapshot.",
    "",
    "The base column shows the **fresh branch-ref SHA**, followed by the historical PR-payload base SHA. "
    "The file count/list is the diff from the unique merge base with that fresh base to the captured PR head. "
    "Ancestry labels describe the PR head relative to the named target. Patch equivalence was not computed. "
    "Review counts are submitted reviews (total / matching captured head); they are not approval-policy decisions. "
    "Inline counts include replies and do not establish thread resolution. Exact-head CI metadata does not establish required-gate satisfaction.",
    "",
    f"Completeness: {summary['complete_local_file_comparisons']}/54 local file comparisons; "
    f"{summary['complete_review_lists']}/54 review lists; {summary['complete_inline_lists']}/54 inline lists; "
    f"{summary['complete_ci_overviews']}/54 CI overviews. "
    f"{summary['historical_pr_base_sha_differs']} historical PR base SHAs differ from the refreshed branch refs.",
    "",
    "Full identities, original scope text, raw API bodies, pagination checks and exact changed-file lists are in "
    "[JSON](pr-inventory.json), [TSV](pr-inventory.tsv), [Git command receipts](git-operations.json), and each Files link.",
    "",
    "| PR / title | Captured head | Base ref / fresh / historical | Merge base | Files | vs #302 | vs candidate75 | Reviews total/head | Inline | Exact-head CI | Preserved disposition | Preserved scope |",
    "| --- | --- | --- | --- | ---: | --- | --- | ---: | ---: | --- | --- | --- |",
]
for p in rows:
    c = p["computed_base_comparison"]
    base_cell = f"{p['base_branch']} / {(c['current_base_sha'] or 'unknown')[:12]} / {p['base_sha_from_pr_payload'][:12]}"
    row = [f"[#{p['number']}]({p['url']}) {p['title']}", p["head_sha"][:12], base_cell,
           ",".join(s[:12] for s in c["merge_bases"]) or "unknown",
           f"[{c['changed_file_count'] if c['changed_file_count'] is not None else 'unknown'}](files/pr-{p['number']}.json)",
           p["computed_relationships"]["pr302"]["ancestry"], p["computed_relationships"]["candidate75"]["ancestry"],
           f"{p['rest_reviews']['submitted_count']}/{p['rest_reviews']['submitted_on_captured_head']}",
           p["rest_inline_comments"]["count"], p["exact_head_ci"]["overview"], p["disposition"], p["scope"]]
    lines.append("| " + " | ".join(md(x) for x in row) + " |")
(OUT / "pr-inventory.md").write_text("\n".join(lines) + "\n")
print(json.dumps(summary, sort_keys=True), flush=True)
