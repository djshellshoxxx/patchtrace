#!/usr/bin/env python3
"""Validate retained metadata without product tests, then create a hashed ZIP."""
import base64
import csv
import datetime
import hashlib
import json
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parent
report = json.loads((ROOT / "pr-inventory.json").read_text())
original_bytes = (ROOT / "input/final-open-prs.json").read_bytes()
source = Path(report["input"]["path"])
original = json.loads(original_bytes)
rows = report["prs"]
assert source.read_bytes() == original_bytes
assert hashlib.sha256(original_bytes).hexdigest() == report["input"]["sha256"]
assert len(rows) == len(original["prs"]) == 54
assert len({p["number"] for p in rows}) == 54
assert all(all(p[k] == v for k, v in o.items()) for p, o in zip(rows, original["prs"]))
with (ROOT / "pr-inventory.tsv").open(newline="") as handle:
    tsv = list(csv.DictReader(handle, delimiter="\t"))
assert len(tsv) == 54
assert [int(p["pr"]) for p in tsv] == [p["number"] for p in rows]
markdown = (ROOT / "pr-inventory.md").read_text()
assert len(re.findall(r"^\| \[#\d+\]", markdown, re.M)) == 54
for destination in re.findall(r"\]\(([^)]+)\)", markdown):
    if not destination.startswith("https://"):
        assert (ROOT / destination).is_file(), destination

operations = json.loads((ROOT / "git-operations.json").read_text())
allowed = {"rev-parse", "cat-file", "merge-base", "diff", "rev-list"}
assert all(o["argv"][3] in allowed for o in operations)
opmap = {tuple(o["argv"][3:]): o for o in operations}
for row, flat in zip(rows, tsv):
    number = row["number"]
    head = row["head_sha"]
    comparison = row["computed_base_comparison"]
    file_report = json.loads((ROOT / f"files/pr-{number}.json").read_text())
    assert file_report == {"number": number, "head_sha": head, **comparison}
    assert comparison["complete"] and len(comparison["merge_bases"]) == 1
    merge_base = comparison["merge_bases"][0]
    mb_command = opmap[("merge-base", "--all", comparison["current_base_sha"], head)]
    assert mb_command["exit_code"] == 0
    assert base64.b64decode(mb_command["stdout_base64"]).decode().split() == [merge_base]
    command = opmap[("diff", "--no-ext-diff", "--no-textconv", "--name-status", "--find-renames=50%", "-z", merge_base, head)]
    assert command["exit_code"] == 0
    parts = base64.b64decode(command["stdout_base64"]).split(b"\0")
    if parts[-1] == b"":
        parts.pop()
    reconstructed = []
    while parts:
        state = parts.pop(0).decode()
        path = parts.pop(0).decode("utf-8", "surrogateescape")
        if state[0] in "RC":
            item = {"status": state, "old_path": path,
                    "path": parts.pop(0).decode("utf-8", "surrogateescape")}
        else:
            item = {"status": state, "path": path}
        reconstructed.append(item)
    assert reconstructed == comparison["changed_files"] == json.loads(flat["changed_files"])
    assert len(reconstructed) == comparison["changed_file_count"] == int(flat["changed_file_count"])
    assert flat["scope"] == row["scope"] and flat["disposition"] == row["disposition"]
    assert row["scope"] in markdown and row["disposition"] in markdown
    for target in report["targets"]:
        relationship = row["computed_relationships"][target]
        sha = report["targets"][target]
        is_ancestor = opmap[("merge-base", "--is-ancestor", head, sha)]["exit_code"] == 0
        is_descendant = opmap[("merge-base", "--is-ancestor", sha, head)]["exit_code"] == 0
        expected = "equal" if head == sha else "ancestor" if is_ancestor else "descendant" if is_descendant else "diverged"
        assert relationship["ancestry"] == expected
        assert relationship["patch_equivalence"] == "not computed"
    for kind, metadata, field in [
        ("reviews", row["rest_reviews"]["pagination"], None),
        ("inline", row["rest_inline_comments"]["pagination"], None),
        ("checks", row["exact_head_ci"]["check_runs_pagination"], "check_runs"),
        ("status", row["exact_head_ci"]["commit_statuses_pagination"], "statuses"),
    ]:
        assert metadata["complete"] and metadata["pages"] == [1]
        assert metadata["per_page"] == 100
        values = []
        for name in metadata["receipt_files"]:
            receipt = json.loads((ROOT / name).read_text())
            assert receipt["kind"] == kind and not receipt["is_error"]
            assert "per_page=100" in receipt["request_url"]
            body = json.loads(receipt["body_utf8"])
            items = body[field] if field else body
            assert len(items) < 100
            if field:
                assert body["total_count"] == len(items)
            if kind == "checks":
                assert all(i["head_sha"] == head for i in items)
            if kind == "status":
                assert body["sha"] == head
            values.extend(items)
        assert len(values) == metadata["collected_count"]
        if kind == "reviews":
            assert len(values) == row["rest_reviews"]["submitted_count"] == 0
        elif kind == "inline":
            assert len(values) == row["rest_inline_comments"]["count"] == 0
        elif kind == "checks":
            assert len(values) == row["exact_head_ci"]["check_run_count"]
        else:
            assert len(values) == row["exact_head_ci"]["commit_status_count"]

raw = sorted((ROOT / "raw").glob("*.json"))
assert len(raw) == 244
ledger = []
for path in raw:
    value = json.loads(path.read_text())
    body = value.get("body_utf8")
    ledger.append({
        "file": str(path.relative_to(ROOT)), "request_url": value["request_url"],
        "is_error": bool(value.get("is_error")),
        "body_utf8_bytes": len(body.encode("utf-8")) if body is not None else None,
        "body_utf8_sha256": hashlib.sha256(body.encode("utf-8")).hexdigest() if body is not None else None,
    })
assert sum(x["is_error"] for x in ledger) == 13
assert len(list((ROOT / "files").glob("pr-*.json"))) == 54
assert all(v["local_commit_available"] for v in report["fresh_base_refs"].values())
assert len(report["fresh_base_refs"]) == 14
assert report["summary"]["incomplete_metadata_prs"] == []
verification = {
    "verified_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "result": "PASS",
    "checks": {
        "sealed_source_bytes_unchanged": True,
        "all_54_original_rows_and_fields_preserved": True,
        "54_rows_in_each_table_and_54_file_reports": True,
        "all_markdown_local_links_resolve": True,
        "all_file_lists_reconstructed_from_exact_git_receipts": True,
        "all_relationships_checked_against_git_receipts": True,
        "all_216_api_resources_terminal_and_exact_head_where_applicable": True,
        "all_14_fresh_base_commit_objects_available": True,
        "only_read_only_git_commands_in_receipts": True,
        "all_244_rest_receipts_preserved_including_13_url_errors": True,
    },
    "scope": "metadata and artifact consistency only; no product tests or semantic certification",
}
for name, value in [("verification.json", verification), ("raw-body-ledger.json", ledger)]:
    (ROOT / name).write_text(json.dumps(value, indent=2) + "\n")
manifest = {
    "format": "sha256-payload-manifest-v1",
    "created_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "excludes": ["manifest.json (self); adjacent archive and archive receipt"],
    "files": [],
}
for path in sorted(ROOT.rglob("*")):
    if path.is_file() and path.name != "manifest.json":
        data = path.read_bytes()
        manifest["files"].append({
            "path": str(path.relative_to(ROOT)), "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(),
        })
(ROOT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
archive = ROOT.with_suffix(".zip")
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
    for path in sorted(ROOT.rglob("*")):
        if path.is_file():
            zf.write(path, str(path.relative_to(ROOT)))
with zipfile.ZipFile(archive) as zf:
    assert zf.testzip() is None
    names = zf.namelist()
    assert len(names) == len(manifest["files"]) + 1
    assert len(names) == len(set(names))
    assert set(names) == {x["path"] for x in manifest["files"]} | {"manifest.json"}
    for entry in manifest["files"]:
        data = zf.read(entry["path"])
        assert len(data) == entry["bytes"]
        assert hashlib.sha256(data).hexdigest() == entry["sha256"]
    assert zf.read("manifest.json") == (ROOT / "manifest.json").read_bytes()
receipt = {
    "archive": str(archive), "bytes": archive.stat().st_size,
    "sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
    "members": len(names), "verified_payloads": len(manifest["files"]),
    "manifest_sha256": hashlib.sha256((ROOT / "manifest.json").read_bytes()).hexdigest(),
    "sealed_input_sha256": report["input"]["sha256"],
    "verification": "all archive members, paths, lengths, CRC and payload SHA-256 digests verified",
    "summary": report["summary"],
}
receipt_path = ROOT.parent / (ROOT.name + "-archive-receipt.json")
receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
