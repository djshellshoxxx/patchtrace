# Read-only inventory supplement: 54 captured open PRs

This package completes the requested metadata table for the **54 exact PR heads** in the sealed input. All 54 have a locally computed unique merge base and changed-file list against a freshly observed actual base branch, complete REST submitted-review and inline-comment lists, and CI metadata associated with the captured head. This is an inventory supplement, not a new semantic review or merge qualification.

## Tables and evidence

- [Markdown table](pr-inventory.md): all 54 PRs, short identities, linked file lists, ancestry, review/comment counts, CI overview, and the original scope/disposition text.
- [TSV table](pr-inventory.tsv): full identities and changed-file lists, suitable for sorting or filtering.
- [JSON table](pr-inventory.json): all original input fields, complete computed metadata, pagination checks, fresh base observations, and individual check-run/status details.
- [Summary](summary.json), [Git command receipts](git-operations.json), and [sealed input copy](input/final-open-prs.json).
- `files/pr-N.json`: one exact changed-file list for every PR. `raw/`: all 244 REST receipt wrappers, including the 13 initial URL-shape failures.

The sealed input SHA-256 is `b889e79334081cad9171aba84bbdb2bfeb64444ad2e4298652bece8b6861873b`. Original input bytes and every input field, including scope and disposition, were preserved. The REST observation window was **2026-11-18 10:52:27.672–10:58:29.643 UTC**. Head identities come from the earlier sealed input and were not refreshed again; the combined table is not an atomic snapshot of GitHub.

## What was computed

Fourteen distinct base branch refs were read through REST. Each comparison uses that fresh branch SHA, while retaining the historical base SHA returned in the original PR payload. **36 of 54** historical payload base SHAs differ from the freshly observed branch tip. `main` was observed at `9c411ca3d7b47f950be5f0c6f01b3c54184554c6`.

The local tracking ref for `codex/consolidation-cve-reviewed-20261118` was stale at `f69614fa6b5bb9d25d4233b06a4c4ce179964a52`; REST observed `75ffee3840894adb52aff7f3df28043cc8e832ba`. The #307 comparison uses the latter. All necessary captured-head, fresh-base and target commit objects were already available locally. No fetch or ref update was performed.

Local comparisons used `git merge-base --all CURRENT_BASE HEAD`, then `git diff --no-ext-diff --no-textconv --name-status --find-renames=50% -z MERGE_BASE HEAD`. Every PR had exactly one merge base. A rename counts as one changed-file record and retains both paths. This measures the PR-side change from the shared ancestor; it is not the tip-to-tip difference from the current base. Behind/ahead commit counts are also retained. All 676 read-only Git commands have exact base64 stdout/stderr receipts. Optional locks and replacement objects were disabled.

| Relationship of captured PR head to target | #302 `121ffb0bcdd6` | Candidate #304 `75ffee384089` |
| --- | ---: | ---: |
| Ancestor | 8 | 11 |
| Equal | 1 | 1 |
| Descendant | 3 | 1 |
| Diverged | 42 | 41 |
| Unknown local ancestry | 0 | 0 |

These are graph facts only. **Patch equivalence was not computed**, and semantic coverage remains unexamined except for the scope statements already present in the sealed input. A diverged result does not prove missing behavior; an ancestor result does not prove a feature was preserved correctly. The supplement does not change any PR disposition or propose closures.

## Reviews, inline comments and exact-head CI

For each captured PR/head, REST GETs read `/pulls/N/reviews`, `/pulls/N/comments`, `/commits/SHA/check-runs`, and `/commits/SHA/status`, using `per_page=100`. Check runs used `filter=latest`, explicitly or the endpoint default. Collection supports further pages; every observed response terminated on its first page with fewer than 100 items and any reported total covered. The largest check-run list contained 61 entries. No GraphQL review-list tool was used.

All 54 submitted-review lists and all 54 inline-comment lists were empty. These observations do not establish approval policy or unresolved-thread status. Inline comments would include replies and exclude general issue conversation comments. Historical review counts would not be treated as current-head approval.

The package contains **996 check-run records** and **44 commit-status records** across the 54 heads. These are metadata records, not test counts. Twenty-four heads had at least one check conclusion of `failure`. Heads #302–#307 had queued or running checks during this observation window. #289 returned no check runs and one successful commit-status context. Required-gate configuration and merge readiness were not evaluated. See the per-head run names, IDs, timestamps and URLs in JSON rather than treating aggregate state labels as a qualification decision.

## Receipt integrity and limits

There are 231 successful REST receipt wrappers and 13 preserved failed branch reads. The failures occurred when the connector rejected percent-encoded slash paths; literal-slash branch paths succeeded. A second successful literal Git-ref probe for `claude/instance-d-gui` agreed with its branch response. The correction did not alter the original receipts.

Each wrapper retains the connector's returned body as `body_utf8`; encoding that string as UTF-8 recovers its exact returned bytes. These are connector response bodies, not packet captures or HTTP-header receipts. The final `manifest.json` covers all payload files, and the adjacent ZIP receipt records the archive digest and member verification.

The builder's initial stdout is preserved unchanged. Its original `unresolved_prs` summary label meant missing metadata only; final tables use the clearer `incomplete_metadata_prs` name. The final Markdown also includes the original scope column explicitly. No product tests, target downloads, source/worktree edits, remote writes, merges, comments or closures were performed for this supplement.
