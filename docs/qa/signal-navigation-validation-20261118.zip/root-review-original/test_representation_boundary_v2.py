"""Persisted authored locations must never reveal another representation's text."""
from dataclasses import replace
import json
import os
from pathlib import Path

import pytest
from PySide6.QtCore import QSettings, Qt

from patchtrace.enrichment import identity, pipeline, views
from patchtrace.enrichment.contracts import SourceLocation
from patchtrace.enrichment.storage import EnrichmentStore
from patchtrace.service import ProjectService
from patchtrace.ui import MainWindow


@pytest.mark.parametrize('representation', ['decompiled', 'assembly'])
def test_actual_navigation_never_substitutes_other_representation(tmp_path, qtbot, monkeypatch, representation):
    service = ProjectService.sample(tmp_path / 'project')
    project = service.project.model_copy(deep=True)
    matches = [match.model_copy(update={side: [
        function.model_copy(update={'assembly': 'mov eax, 1\nret\n'})
        for function in getattr(match, side)] for side in ('older', 'newer')})
        for match in project.matches]
    candidate = project.model_copy(update={'matches': matches})
    service._invalidate(candidate)
    service._commit(candidate)
    result = pipeline.run(service.project)
    group = next(group for group in result.signal_sets if any(
        signal.locations[0].side == 'newer' for signal in group.signals))
    original_signal = next(signal for signal in group.signals if signal.locations[0].side == 'newer')
    original = original_signal.locations[0]
    function = views.validate_location(service.project, original)
    lines = function.code if representation == 'decompiled' else function.assembly
    assert lines and function.code and function.assembly
    assert function.code[0] != function.assembly[0], 'authored representations must have distinct text'
    expected = lines[0]
    loc = SourceLocation.model_validate(original.model_dump() | dict(
        representation=representation, start_line=1, end_line=1,
        excerpt_sha256=identity.excerpt_sha256((expected,))))
    assert views.validate_location(service.project, loc).id == function.id
    signal = original_signal.model_copy(update={'locations': (loc,)})
    changed_group = group.model_copy(update={'signals': tuple(
        signal if old.signal_id == signal.signal_id else old for old in group.signals)})
    changed = replace(result, signal_sets=tuple(
        changed_group if old.pairing_id == group.pairing_id else old for old in result.signal_sets))
    written = pipeline.publish(EnrichmentStore(service.store), service.project, changed)
    assert written and not any(item.stale for item in written)
    root = service.root
    service.close()
    window = MainWindow(ProjectService.open(root),
                        QSettings(str(tmp_path / 'settings.ini'), QSettings.Format.IniFormat))
    qtbot.addWidget(window)
    errors, calls = [], []
    monkeypatch.setattr(window, 'show_error', errors.append)
    actual_reveal = window.reveal_lines

    def reveal(*args):
        calls.append(args)
        return actual_reveal(*args)

    monkeypatch.setattr(window, 'reveal_lines', reveal)
    try:
        target = next(window.navigator.item(i) for i in range(window.navigator.count())
                      if window.navigator.item(i).data(Qt.ItemDataRole.UserRole) == group.match_id)
        window.navigator.setCurrentItem(target)
        window.mode.setCurrentIndex(1)
        item = next(window.signal_list.item(i) for i in range(window.signal_list.count())
                    if window.signal_list.item(i).data(Qt.ItemDataRole.UserRole) == signal.signal_id)
        for pane in window.views.values():
            cursor = pane.textCursor()
            cursor.clearSelection()
            pane.setTextCursor(cursor)
        before = {side: (pane.textCursor().position(), pane.textCursor().anchor())
                  for side, pane in window.views.items()}
        rows_before = window.service.store.connection.execute('SELECT * FROM enrichment_entries ORDER BY id').fetchall()
        window.jump_signal(item)
        selected = window.views[loc.side].textCursor().selectedText()
        record = dict(representation=representation, stored_location=loc.model_dump(),
                      expected=expected, actual_selected=selected, mode=window.mode.currentIndex(),
                      reveal_calls=calls, errors=errors)
        out = Path(os.environ['PATCHTRACE_NAV_REVIEW_OBSERVATIONS'])
        out.mkdir(exist_ok=True)
        with (out / (representation + '.json')).open('x') as f:json.dump(record,f,indent=2);f.write('\n')
        assert window.service.store.connection.execute('SELECT * FROM enrichment_entries ORDER BY id').fetchall() == rows_before
        if representation == 'decompiled':
            assert not errors and calls and selected == expected and window.mode.currentIndex() == 0
        elif errors:
            # The action may explicitly refuse a representation it cannot render faithfully.
            assert not calls and window.mode.currentIndex() == 1
            assert all(len(error) <= 300 for error in errors)
            assert {side: (pane.textCursor().position(), pane.textCursor().anchor())
                    for side, pane in window.views.items()} == before
        else:
            # Any accepted location must reveal precisely its validated representation.
            assert calls and window.mode.currentIndex() == 1 and selected == expected, record
    finally:
        window.close()
