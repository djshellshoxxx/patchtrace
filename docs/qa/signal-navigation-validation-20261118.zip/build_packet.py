"""Seal the navigation-only source boundary and all earlier outcomes without rewriting them."""
from __future__ import annotations

import ast
from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

R = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
Q = Path(__file__).resolve().parent
BASE = '068513a72e8a1412ce3960d3024c462d68d51376'
SOURCE = '9592f8b362537c0545010d4499e35770a248297e'
ARCHIVE = Q.with_suffix('.zip')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=R)


def blob(ref, path):
    return git('show', f'{ref}:{path}')


def put(path, data):
    destination = Q / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('xb') as output:
        output.write(data)


def dump(path, value):
    put(path, (json.dumps(value, indent=2) + '\n').encode())


def method(tree):
    cls = next(item for item in tree.body if isinstance(item, ast.ClassDef) and item.name == 'MainWindow')
    return cls, next(item for item in cls.body if isinstance(item, ast.FunctionDef) and item.name == 'jump_signal')


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('diff', 'HEAD')
tree = git('rev-parse', SOURCE + '^{tree}').decode().strip()
production = git('diff', '--name-only', BASE, SOURCE, '--', 'src').decode().splitlines()
assert production == ['src/patchtrace/ui.py', 'src/patchtrace/ui_signal_navigation.py']
old_ui = blob(BASE, production[0])
new_ui = blob(SOURCE, production[0])
outside = []
trees = []
for content in (old_ui, new_ui):
    parsed = ast.parse(content)
    cls, node = method(parsed)
    lines = content.splitlines(keepends=True)
    outside.append(b''.join(lines[:node.lineno - 1] + lines[node.end_lineno:]))
    cls.body.remove(node)
    trees.append(ast.dump(parsed, include_attributes=False))
assert outside[0] == outside[1] and trees[0] == trees[1]
assert new_ui.count(b'\n') <= 3077

affected = [
    'tests/test_signal_location_navigation.py', 'tests/test_ui_enrichment.py',
    'tests/test_enrichment_p1_gaps.py', 'tests/test_enrichment_core.py',
    'tests/test_enrichment_review_regressions.py', 'tests/test_enrichment_storage.py',
    'tests/test_gui_codediff.py', 'tests/test_ui_raw_alignment.py',
    'tests/test_gui_host_seam.py', 'tests/test_tooltips.py',
]
unchanged = [
    'src/patchtrace/enrichment/contracts.py', 'src/patchtrace/enrichment/views.py',
    'src/patchtrace/enrichment/signals.py', 'src/patchtrace/enrichment/wil.py',
    'src/patchtrace/enrichment/ranking.py', 'src/patchtrace/enrichment/pipeline.py',
    'src/patchtrace/enrichment/storage.py', 'src/patchtrace/service.py',
    *affected[1:],
]
for path in unchanged:
    assert blob(BASE, path) == blob(SOURCE, path), path
dump('source-proof.json', {
    'baseline': BASE, 'source': SOURCE, 'source_tree': tree,
    'changed_production_files': production,
    'only_changed_existing_symbol': 'MainWindow.jump_signal',
    'ui_bytes_outside_jump_signal_identical': True,
    'ui_ast_outside_jump_signal_identical': True,
    'baseline_ui_lines': old_ui.count(b'\n'), 'final_ui_lines': new_ui.count(b'\n'),
    'unchanged_ui_ceiling': 3077,
    'unchanged_paths': [{'path': path, 'sha256': hashlib.sha256(blob(SOURCE, path)).hexdigest()}
                        for path in unchanged],
    'scope': 'Presentation-only support refusal and existing live validator hook; no score/schema/store changes.',
})

commits = git('rev-list', '--reverse', BASE + '..' + SOURCE).decode().splitlines()
history = []
for commit in commits:
    row = json.loads(git('show', '-s', '--format={"commit":"%H","tree":"%T","parents":"%P","subject":"%s"}', commit))
    assert '[no release]' in row['subject']
    history.append(row)
    put('commits/' + commit[:8] + '.patch', git('show', '--format=fuller', '--binary', commit))
dump('history.json', {'baseline': BASE, 'source': SOURCE, 'commits': history})

snapshots = []
baseline_paths = ['AGENTS.md', 'docs/specs/enrichment.md', 'docs/specs/enrichment-hardening-backlog.md',
                  'src/patchtrace/ui.py', 'src/patchtrace/enrichment/views.py',
                  'src/patchtrace/enrichment/contracts.py', 'tests/test_gui_host_seam.py', 'tests/test_tooltips.py']
final_paths = sorted(set([
    *baseline_paths, *unchanged, *affected, 'docs/modules.md', 'pyproject.toml',
    'src/patchtrace/ui_signal_navigation.py', 'tests/conftest.py', 'tests/qt_support.py',
]))
stages = [(BASE, baseline_paths), (SOURCE, final_paths)]
for commit in commits[:-1]:
    paths = git('diff-tree', '--no-commit-id', '--name-only', '-r', commit).decode().splitlines()
    stages.append((commit, paths))
for ref, paths in stages:
    for path in paths:
        data = blob(ref, path)
        archive_path = 'git/' + ref[:8] + '/' + path
        put(archive_path, data)
        snapshots.append({'path': archive_path, 'git_commit': ref, 'git_path': path,
                          'git_blob': git('rev-parse', f'{ref}:{path}').decode().strip(),
                          'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
dump('git-snapshots.json', {'snapshots': snapshots})

outcomes = []
for path in sorted(Q.rglob('*.xml')):
    suites = list(ET.parse(path).getroot().iter('testsuite'))
    tests = sum(int(item.get('tests', 0)) for item in suites)
    failed = sum(int(item.get('failures', 0)) for item in suites)
    errors = sum(int(item.get('errors', 0)) for item in suites)
    skipped = sum(int(item.get('skipped', 0)) for item in suites)
    failed_nodes = [{'classname': case.get('classname'), 'name': case.get('name'),
                     'kind': issue.tag, 'message': issue.get('message', '')}
                    for suite in suites for case in suite.findall('testcase')
                    for issue in list(case) if issue.tag in ('failure', 'error')]
    outcomes.append({'path': str(path.relative_to(Q)), 'tests': tests, 'passed': tests-failed-errors-skipped,
                     'failures': failed, 'errors': errors, 'skipped': skipped,
                     'xml_seconds': sum(float(item.get('time', 0)) for item in suites),
                     'failed_nodes': failed_nodes})
expected = {'final-representation-affected.xml': 175, 'final-representation-original.xml': 7,
            'final-representation-root.xml': 2}
for path, count in expected.items():
    outcome = next(item for item in outcomes if item['path'] == path)
    assert outcome['passed'] == count and outcome['tests'] == count
dump('outcomes.json', {'outcomes': outcomes, 'counts_are_not_additive_coverage': True})

for receipt in ('original-preservation.json', 'root-original-preservation.json'):
    data = json.loads((Q / receipt).read_text())
    for row in data['files']:
        original = Path(row['original_path'])
        assert hashlib.sha256(original.read_bytes()).hexdigest() == row['sha256'], original
for row in snapshots:
    assert (Q / row['path']).read_bytes() == blob(row['git_commit'], row['git_path'])

files = []
for path in sorted(Q.rglob('*')):
    if not path.is_file() or '__pycache__' in path.parts or path.suffix == '.pyc':
        continue
    data = path.read_bytes()
    files.append({'path': str(path.relative_to(Q)), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
dump('manifest.json', {'schema': 1, 'baseline': BASE, 'source': SOURCE, 'source_tree': tree,
                       'sealed_utc': datetime.now(UTC).isoformat(), 'files': files})
with zipfile.ZipFile(ARCHIVE, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for row in files:
        archive.write(Q / row['path'], row['path'])
    archive.write(Q / 'manifest.json', 'manifest.json')
with zipfile.ZipFile(ARCHIVE) as archive:
    assert len(archive.namelist()) == len(files) + 1
    assert set(archive.namelist()) == {row['path'] for row in files} | {'manifest.json'}
    for row in files:
        data = archive.read(row['path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
seal = {'baseline': BASE, 'source': SOURCE, 'source_tree': tree, 'archive': str(ARCHIVE),
        'members': len(files) + 1, 'bytes': ARCHIVE.stat().st_size,
        'sha256': hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
        'git_snapshots': len(snapshots), 'source_commits': len(history)}
with Q.with_name(Q.name + '-seal.json').open('x') as output:
    json.dump(seal, output, indent=2)
    output.write('\n')
print(json.dumps(seal, indent=2))
