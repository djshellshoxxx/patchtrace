"""Independent fixed-boundary controls: fake openers only, no network or target execution."""
import io
import json
import socket
import threading
import urllib.request

import pytest

from patchtrace import providers


@pytest.fixture(autouse=True)
def deny_network(monkeypatch):
    def deny(*args, **kwargs):
        raise AssertionError('external review does not use network')
    monkeypatch.setattr(socket, 'socket', deny)
    monkeypatch.setattr(socket, 'getaddrinfo', deny)
    monkeypatch.setattr(socket, 'create_connection', deny)


def install(monkeypatch, kind, redirect=None, code=302):
    calls, handler_sets, responses = [], [], []
    class Opener:
        def open(self, request, timeout):
            calls.append((request, timeout))
            if redirect:
                handler = next(h for h in handler_sets[-1] if isinstance(h, providers._NoRedirect))
                getattr(handler, 'http_error_' + str(code))(
                    request, io.BytesIO(), code, 'authored redirect', {'location': redirect})
                raise AssertionError('redirect was accepted')
            body = {'message': {'content': '{}'}} if kind == 'ollama' else {'choices': [{'message': {'content': '{}'}}]}
            response = io.BytesIO(json.dumps(body).encode())
            responses.append(response)
            return response
    def build(*handlers):
        handler_sets.append(handlers)
        return Opener()
    monkeypatch.setattr(urllib.request, 'build_opener', build)
    return calls, handler_sets, responses


@pytest.mark.parametrize('kind,endpoint,expected', [
    ('openai', 'https://provider.example.invalid/v1', 'https://provider.example.invalid/v1/chat/completions'),
    ('openai', 'https://127.0.0.1:8443/v1/chat/completions', 'https://127.0.0.1:8443/v1/chat/completions'),
    ('ollama', 'http://127.0.0.1:11434', 'http://127.0.0.1:11434/api/chat'),
    ('ollama', 'https://localhost:11434/api/chat', 'https://localhost:11434/api/chat'),
])
def test_explicit_endpoint_exact_request_and_empty_proxy_policy(monkeypatch, kind, endpoint, expected):
    calls, handlers, responses = install(monkeypatch, kind)
    config = providers.ProviderConfig(kind, endpoint, 'authored-model', 'DUMMY_REVIEW_KEY')
    assert providers.request_completion(config, 'exact system', '{"authored":"payload"}', threading.Event()) == '{}'
    assert len(calls) == 1
    request, timeout = calls[0]
    assert request.full_url == expected and request.get_method() == 'POST' and timeout == providers.TIMEOUT_SECONDS
    payload = json.loads(request.data)
    assert payload['messages'] == [{'role': 'system', 'content': 'exact system'},
                                   {'role': 'user', 'content': '{"authored":"payload"}'}]
    assert payload['model'] == 'authored-model' and payload['stream'] is False
    assert request.get_header('Authorization') == ('Bearer DUMMY_REVIEW_KEY' if kind == 'openai' else None)
    assert next(h for h in handlers[0] if isinstance(h, urllib.request.ProxyHandler)).proxies == {}
    assert any(isinstance(h, providers._NoRedirect) for h in handlers[0])
    assert responses[0].closed


@pytest.mark.parametrize('kind,endpoint', [
    ('openai', 'file:///tmp/authored'), ('openai', 'ftp://provider.example.invalid/data'),
    ('openai', 'http://provider.example.invalid/v1'), ('openai', 'https://user:password@provider.example.invalid'),
    ('openai', 'https://provider.example.invalid/v1?redirect=elsewhere'),
    ('openai', 'https://provider.example.invalid/v1#fragment'),
    ('ollama', 'http://provider.example.invalid/api/chat'), ('ollama', 'http://[::ffff:127.0.0.1]:11434'),
])
def test_invalid_endpoint_is_rejected_before_any_opener(monkeypatch, kind, endpoint):
    calls, handlers, _responses = install(monkeypatch, kind)
    with pytest.raises(providers.ProviderError):
        providers.request_completion(providers.ProviderConfig(kind, endpoint, 'model'), 's', '{}', threading.Event())
    assert calls == handlers == []


@pytest.mark.parametrize('code', [301, 302, 303, 307, 308])
def test_standard_redirect_status_never_sends_to_second_endpoint(monkeypatch, code):
    calls, _handlers, _responses = install(monkeypatch, 'openai', 'https://other.example.invalid/stolen', code)
    config = providers.ProviderConfig('openai', 'https://configured.example.invalid/v1', 'model', 'DUMMY_REVIEW_KEY')
    with pytest.raises(providers.ProviderError, match='redirects are refused'):
        providers.request_completion(config, 's', '{}', threading.Event())
    assert len(calls) == 1 and calls[0][0].full_url == 'https://configured.example.invalid/v1/chat/completions'


def test_file_redirect_cannot_escape_https_endpoint_policy(monkeypatch):
    calls, _handlers, _responses = install(monkeypatch, 'openai', 'file:///tmp/authored')
    with pytest.raises(providers.ProviderError):
        providers.request_completion(providers.ProviderConfig('openai', 'https://configured.example.invalid', 'model'),
                                     's', '{}', threading.Event())
    assert len(calls) == 1


def test_pre_cancelled_call_constructs_no_opener(monkeypatch):
    calls, handlers, _responses = install(monkeypatch, 'openai')
    cancel = threading.Event(); cancel.set()
    with pytest.raises(providers.ProviderCancelled):
        providers.request_completion(providers.ProviderConfig('openai', 'https://configured.example.invalid', 'model'),
                                     's', '{}', cancel)
    assert calls == handlers == []
