# Independent provider S310 boundary review

Source `36e14051a4d36f5c66df0186f037a4905b01bf05` in detached `security-boundaries-review`; production source unchanged. The diagnostic is `src/patchtrace/providers.py:126`, the POST Request construction.

## Caller and endpoint provenance

The only production `request_completion` caller is `interpretation.interpret`, which validates the retained preview context and its digest and checks cancellation before transport. The desktop entry is `MainWindow.preview_interpretation`: it builds the bounded context, opens `ContextDialog`, and returns without starting a job unless the dialog returns Accepted. The dialog presents exact context and system prompt plus the editable provider/endpoint/model and session-only credential fields. Its button is Send context. After acceptance the UI persists only provider/kind, endpoint and model; the credential stays in the worker closure. The two existing actual Qt controls for rejection and preview/session-only secret behavior were rerun.

`ProviderConfig.__post_init__` and `request_completion` call `validate_endpoint`. OpenAI-compatible requests require HTTPS; Ollama requests require HTTP(S) and an explicitly loopback host. Both reject URL userinfo, query, fragment, whitespace/control characters and invalid ports; mapped IPv6 is rejected for the loopback provider. The endpoint originates in explicit user configuration, not advisory/code/model text. User-selected HTTPS endpoints, including loopback/self-hosted service addresses, are intentional capabilities; no generic SSRF defect is inferred from that choice. The lower-level transport is intentionally a callable API, not an independent GUI-consent state machine.

## Request and redirects

`_build_request` preserves the configured endpoint except the documented /api/chat or /chat/completions suffix. It sends a POST with exactly two messages: the fixed system prompt and the supplied context payload. It uses JSON serialization, stream false, and a provider-specific JSON format hint. Authorization is attached only to the OpenAI-compatible provider when a key was supplied. `_exchange` constructs its opener with ProxyHandler({}) and the production _NoRedirect handler; environment proxies do not control this opener. The handler refuses redirect followups rather than sending the body/key to a second destination. Existing cancellation/deadline/2MiB response bounds remain in place.

## Independent controls and result

**21 passed / 0 failures/skips in 1.31 s**: 19 new authored fake-opener controls plus the two existing Qt consent/preview controls. Positives inspect four exact configured URL/suffix variants, POST messages, conditional dummy Authorization, empty proxy map and response close. Negatives refuse eight unsupported/credentialed/otherwise-invalid endpoints before constructing an opener; five standard redirect status paths and a file redirect admit no second request; pre-cancellation constructs no opener. Every network primitive is denied in the external fake-opener controls; no loopback/live provider was contacted.

External probe SHA-256: `f5b0dbf0a726bc46aaaf88424f1f53193b8a0198274bd168a149ad927c172c44`.
Production provider SHA-256: `d60b53a5b2ebecd0fe7c5251130d935b8d923abbebd3a8d402ff5e842d51db15`.
Commands, all three source hashes, pinned environment and timestamps are in `receipt.json`; raw output/JUnit in `providers-s310.log` and `providers-s310.xml`.

Disposition: this S310 site is constrained by fixed scheme/endpoint validation, explicit configured destination and redirect refusal. No source repair is indicated by this bounded review. This does not qualify live DNS/TLS/proxy behavior, server compatibility, native platforms, aggregate response-work/resource limits beyond the inspected guards, or every arbitrary direct API caller. No source edits, remote changes or target execution occurred.
