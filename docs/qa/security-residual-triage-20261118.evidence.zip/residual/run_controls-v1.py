"""Source-pinned, bounded local review receipts. No product/config writes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

parser = argparse.ArgumentParser()
parser.add_argument('--tree', required=True, type=Path)
parser.add_argument('--prefix', required=True, type=Path)
parser.add_argument('tests', nargs='+')
args = parser.parse_args()
tree, prefix = args.tree.resolve(), args.prefix.resolve()
qa = Path(__file__).resolve().parent
python = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
env = dict(os.environ, PYTHONPATH=f'{tree}/src:{tree}/tests', QT_QPA_PLATFORM='offscreen')
source_paths = sorted({row['path'] for row in json.loads((qa/'source-map.json').read_text())['rows']} |
                      {'src/patchtrace/pilot/sources/kb_context.py'})
command = [python, '-m', 'pytest', '-q', *args.tests, f'--junitxml={prefix}.xml']
record = {'command':command, 'tree':str(tree), 'PYTHONPATH':env['PYTHONPATH'],
          'QT_QPA_PLATFORM':env['QT_QPA_PLATFORM'],
          'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip(),
          'source_files':{p:hashlib.sha256((tree/p).read_bytes()).hexdigest() for p in source_paths},
          'external_files':{p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
                            for p in args.tests if Path(p).is_absolute() and Path(p).is_file()}}
Path(f'{prefix}-context.json').write_text(json.dumps(record,indent=2)+'\n')
started=time.monotonic()
with Path(f'{prefix}.log').open('wb') as out:
    result=subprocess.run(command,cwd=tree,env=env,stdout=out,stderr=subprocess.STDOUT,timeout=180)
receipt={'exit':result.returncode,'elapsed_s':round(time.monotonic()-started,3)}
Path(f'{prefix}-exit.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
print(Path(f'{prefix}.log').read_text()[-4500:])
raise SystemExit(result.returncode)
