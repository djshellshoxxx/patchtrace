"""Additional current S608: real SQLite capture over authored retained CVRF context."""
from __future__ import annotations

import socket

import pytest
from test_pilot_kb_context import CVE, native_bundle, publish

from patchtrace.enrichment.storage import EnrichmentStore
from patchtrace.pilot.sources.kb_context import capture
from patchtrace.service import ProjectService


@pytest.fixture(autouse=True)
def no_network(monkeypatch):
    def denied(*_args, **_kwargs):
        raise AssertionError('metadata SQL review is offline')
    for name in ('socket', 'getaddrinfo', 'create_connection'):
        monkeypatch.setattr(socket, name, denied)


@pytest.mark.parametrize('title', [
    'Authored title', "x'); DROP TABLE enrichment_entries; --", "x' OR 1=1 UNION SELECT 'y",
])
def test_valid_context_text_never_becomes_metadata_sql(tmp_path, title):
    service = ProjectService.sample(tmp_path / 'project')
    try:
        bundle, _ = native_bundle(service, title=title)
        publish(service, bundle)
        db = service.store.connection
        schema = db.execute('SELECT type,name,sql FROM sqlite_schema ORDER BY type,name').fetchall()
        before = db.execute('SELECT id,body,body_sha256 FROM enrichment_entries').fetchall()
        queries = []
        db.set_trace_callback(queries.append)
        result = capture(service, EnrichmentStore(service.store))
        db.set_trace_callback(None)
        assert result.cves == (CVE,) and not result.unavailable and result.bundles == (bundle,)
        assert any('typeof(id)' in q and 'length(CAST(body AS BLOB))' in q for q in queries)
        assert all(title not in q for q in queries)
        assert db.execute('SELECT type,name,sql FROM sqlite_schema ORDER BY type,name').fetchall() == schema
        assert db.execute('SELECT id,body,body_sha256 FROM enrichment_entries').fetchall() == before
    finally:
        service.close()


def test_unselected_kind_and_literal_metadata_id_cannot_widen_query(tmp_path):
    service = ProjectService.sample(tmp_path / 'project')
    try:
        bundle, _ = native_bundle(service)
        ident = publish(service, bundle)
        db = service.store.connection
        schema = db.execute('SELECT type,name,sql FROM sqlite_schema ORDER BY type,name').fetchall()
        before = capture(service, EnrichmentStore(service.store))
        poison = "x'); DROP TABLE enrichment_entries; --"
        db.execute('UPDATE enrichment_entries SET id=? WHERE id=?', (poison, ident))
        changed = capture(service, EnrichmentStore(service.store))
        assert changed.digest != before.digest
        assert db.execute('SELECT id FROM enrichment_entries').fetchall() == [(poison,)]
        db.execute('UPDATE enrichment_entries SET kind=?', ("kb-context' OR 1=1 --",))
        absent = capture(service, EnrichmentStore(service.store))
        assert absent.bundles == () and absent.digest is None
        assert db.execute('SELECT type,name,sql FROM sqlite_schema ORDER BY type,name').fetchall() == schema
    finally:
        service.close()
