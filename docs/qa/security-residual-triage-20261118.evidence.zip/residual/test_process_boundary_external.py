"""S603 controls: one harmless pinned Python child, no target/helper execution."""
from __future__ import annotations

import json
import os
import sys
import threading

import pytest

from patchtrace import jobs


def test_metacharacters_remain_argv_data_and_parent_environment_is_not_inherited(tmp_path, monkeypatch):
    marker = tmp_path / 'never-created'
    values = [f'; touch {marker}', f'$(touch {marker})', f'`touch {marker}`', '& | < > ^ % !', 'line\nvalue',
              '--leading-option', 'quoted "value"', 'space value', '/authored/target.bin']
    code = ('import json,os,sys; print(json.dumps({"args":sys.argv[1:],'
            '"kept":os.environ.get("REVIEW_CHILD_VALUE"),'
            '"parent":os.environ.get("REVIEW_PARENT_VALUE")}))')
    monkeypatch.setenv('REVIEW_PARENT_VALUE', 'must-not-be-inherited')
    real_popen = jobs.subprocess.Popen
    launches = []

    def launch(args, **kwargs):
        launches.append((list(args), dict(kwargs)))
        assert args[:4] == [sys.executable, '-I', '-c', code]
        return real_popen(args, **kwargs)

    monkeypatch.setattr(jobs.subprocess, 'Popen', launch)
    result = jobs.run_process([sys.executable, '-I', '-c', code, *values], cwd=tmp_path,
        env={'REVIEW_CHILD_VALUE': 'explicit'}, cancel=threading.Event(), timeout_seconds=5,
        log_limit=8192, max_output_bytes=8192)
    assert result.returncode == 0 and result.reason is None
    assert json.loads(result.log_tail) == {'args': values, 'kept': 'explicit', 'parent': None}
    assert not marker.exists()
    assert len(launches) == 1 and launches[0][1]['shell'] is False
    assert launches[0][1]['env'] == {'REVIEW_CHILD_VALUE': 'explicit'}
    assert launches[0][1]['stdin'] == jobs.subprocess.DEVNULL


@pytest.mark.parametrize('argv,env', [
    (['relative-python', '-c', 'pass'], {}),
    ([sys.executable, 'x\x00y'], {}),
    ([sys.executable], {'BAD=NAME': 'value'}),
    ([sys.executable], {'KEY': 'value\x00NEXT=1'}),
])
def test_invalid_launch_input_is_refused_before_process_creation(tmp_path, monkeypatch, argv, env):
    def denied(*_args, **_kwargs):
        raise AssertionError('invalid input reached Popen')
    monkeypatch.setattr(jobs.subprocess, 'Popen', denied)
    with pytest.raises(ValueError):
        jobs.run_process(argv, cwd=tmp_path, env=env, cancel=threading.Event(), timeout_seconds=1)


def test_cancelled_request_does_not_start_a_process(tmp_path, monkeypatch):
    def denied(*_args, **_kwargs):
        raise AssertionError('cancelled input reached Popen')
    monkeypatch.setattr(jobs.subprocess, 'Popen', denied)
    cancel = threading.Event()
    cancel.set()
    result = jobs.run_process([sys.executable], cwd=tmp_path, env={}, cancel=cancel, timeout_seconds=1)
    assert result.reason == 'cancelled'


def test_windows_batch_policy_refuses_metacharacters_without_claiming_native_execution():
    assert jobs._argv_error(['C:\\tools\\runner.cmd', 'plain'], True) is None
    for suffix in ('.cmd', '.BAT. ', '.bat'):
        assert jobs._argv_error(['C:\\tools\\runner' + suffix, 'name&argument'], True)
    assert jobs._argv_error(['C:\\tools\\runner.exe', 'name&argument'], True) is None
    assert os.name != 'nt'  # receipt explicitly records this as a Linux pure-policy control
