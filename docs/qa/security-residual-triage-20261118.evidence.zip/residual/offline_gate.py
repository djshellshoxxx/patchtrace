"""External pytest guard for this source review; not a repository test/config change."""
import socket

import pytest


@pytest.fixture(autouse=True)
def static_review_no_network(monkeypatch):
    def denied(*_args, **_kwargs):
        raise AssertionError('this independent static-review gate forbids real connections and DNS')
    monkeypatch.setattr(socket.socket, 'connect', denied)
    monkeypatch.setattr(socket.socket, 'connect_ex', denied)
    monkeypatch.setattr(socket, 'getaddrinfo', denied)
