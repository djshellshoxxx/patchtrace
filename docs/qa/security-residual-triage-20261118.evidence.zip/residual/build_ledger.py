"""Reconcile preserved detector snapshots; never edit their bytes or scan policy."""
from __future__ import annotations

import ast
from collections import Counter, defaultdict
import hashlib
import json
from pathlib import Path

BASE = Path('/workspace/scratch/c7a9e8d98848')
QA = BASE / 'qa/security-boundaries-review'
TREE = BASE / 'security-boundaries-current'
SOURCE = '3faf436a3b11c69220641a167cf424e7f4060839'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def path_of(row):
    return 'src/' + row['filename'].split('/src/', 1)[1]


def function_at(path, line):
    tree = ast.parse((TREE / path).read_text())
    found = [n for n in ast.walk(tree) if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))
             and n.lineno <= line <= n.end_lineno]
    return min(found, key=lambda n: n.end_lineno - n.lineno).name if found else None


NETWORK = {
    'acquisition/transport.py': (
        'File-name-derived Winbindex metadata URL or explicitly planned symbol-server URL; exact consent checked by '
        '_consented before Transport._open. _check limits HTTPS, fixed hosts, port 443 and no userinfo/control text. '
        'Metadata redirects are refused; downloads permit one checked Azure blob redirect and verify planned size/SHA.',
        'test_network_boundaries_external.py::test_acquisition_*',
        'The generic urllib_open helper relies on its production Transport callers. No actual download, DNS or TLS '
        'was exercised; arbitrary approved blob-account trust is not expanded by this review.'),
    'enrichment/intelligence.py': (
        'CVE IDs and provider choice are normalized into a fixed plan. _validate rederives every PlannedRequest '
        'including URL/headers/key-header and checks exact consent. _attempt checks every redirect against fixed '
        'HTTPS provider hosts and strips the NVD session key when the host changes.',
        'test_network_boundaries_external.py::test_cve_*',
        'The established contract permits a redirect between allowlisted provider hosts. This is not an arbitrary '
        'destination API. No live response provenance, DNS or TLS claim; lower-level helpers require validated callers.'),
    'intelligence/csaf/transport.py': (
        'CsafTransport requires explicit host consent except cache-only offline mode. get and every _attempt hop '
        'call check_url: exact Microsoft host, HTTPS/443, fixed CSAF path prefixes, no userinfo/query/fragment, '
        'encoded or dot-segment path spelling, or control text. Default opener disables proxies and auto redirects.',
        'test_network_boundaries_external.py::test_csaf_*',
        'Only fake responses and caller-level policy were exercised. No live CSAF server, DNS/TLS or aggregate '
        'store/resource qualification; the low-level urllib helper relies on the checked caller.'),
    'kbcorrelation/sources/inventory_http.py': (
        'fetch_source rederives the complete ordered plan, exact host set and plan digest before any request. '
        'Redirect drift requires a new preview without contacting the target. urllib_open validates raw URL spelling, '
        'scheme/host/path/kind and GET again. connect_public validates the whole bounded DNS answer then connects '
        'to those numeric addresses; certificate/hostname verification remains required.',
        'test_network_boundaries_external.py::test_inventory_*; tests/test_kbc_inventory_sources.py',
        'DNS and sockets were injected data; no real connection, certificate server, resolver race or arbitrary '
        'address-space exhaustion was tested. Header/body framing and ordinary bounds have existing local controls.'),
    'kev/transport.py': (
        'A strict KevPlan and KevConsent name one fixed catalog URL; check_request enforces the exact initial URL. '
        'Each redirect is checked for plain HTTPS on the same approved host before opening. Requests use fixed '
        'headers, no proxy inheritance or automatic redirects, bounded reads and explicit cancellation.',
        'test_network_boundaries_external.py::test_kev_*',
        'Same-host path redirects are intentionally admitted. Live-socket tests were explicitly deselected. '
        'No actual catalog, network freshness, DNS/TLS or server compatibility was qualified.'),
    'providers.py': (
        'User-configured endpoint from the explicit Send context dialog. interpretation.interpret validates the '
        'exact context/digest; desktop refusal returns before starting a job. ProviderConfig and request_completion '
        'validate HTTPS remote or loopback local endpoints and reject userinfo/query/fragment/control text. '
        '_exchange has an empty proxy map and refuses redirect followups, preserving POST destination/body/key.',
        'test_provider_s310_boundary.py (19 controls); tests/test_ui.py::test_interpretation_preview_cancel_sends_nothing; '
        'tests/test_ui.py::test_context_dialog_exact_preview_and_secret_is_session_only',
        'Explicit user-configured HTTPS/self-hosted endpoints are intentional. The lower-level callable API does '
        'not itself implement GUI consent. No generic SSRF, live-provider or DNS/TLS conclusion.'),
}

SUPPRESSIONS = {
    ('jobs.py', 'notify_progress', 413): (
        'Observational progress callback only; primary ProcessResult, output collection and child supervision '
        'do not depend on observer success.', 'No claim that an observer retained its own log or that it is prompt.'),
    ('netutil.py', 'worker', 68): (
        'Close of a response that arrived after abandonment. Caller already received cancellation; the late value '
        'is not returned as successful evidence.', 'A failing close may leave resources. Native cleanup/resource '
        'completeness was not qualified.'),
    ('secondary/scheduler.py', 'emit', 99): (
        'EngineEvent observation only. The typed EngineOutcome is returned independently; ordinary on_outcome '
        'publication exceptions propagate.', 'An observer may lose progress events; no atomic durable delivery claim.'),
    ('secondary/scheduler.py', 'run_engines', 239): (
        'Best-effort delivery of completed outcomes while an existing BaseException is already unwinding; '
        'the primary exception is reraised and cannot become a successful overall return.',
        'An additional delivery failure can remain unpersisted. This is not a guarantee of durable attempts on interruption.'),
    ('service.py', '_rollback_creation', 64): (
        'Only entered after creation failed. Rollback checks the actual snapshot and ownership ledger; uncertain '
        'state is retained and the original creation exception propagates.',
        'Cleanup may leave files/locks; accepted creation repair claims cooperative observed seams only.'),
    ('service.py', '_rollback_creation', 69): (
        'Best-effort store close in the failed-creation rollback finally; cannot make failed creation succeed.',
        'No guarantee of cleanup when close itself fails; original bytes/unknown ownership are retained.'),
    ('ui_engine_setup.py', '_save', 137): (
        'Optional executable-path/setup preference persistence; no admission of validated exports, engine result '
        'or network consent happens in this catch.', 'Reopen may not remember the unsaved preference.'),
    ('ui_evidence.py', '_save', 579): (
        'Optional filter/hide-agreed/show-index preferences only; no matching result or attempt record is published.',
        'Reopen may not remember presentation preferences.'),
    ('unified/extract/ghidra_script.py', 'probe_versions', 320): (
        'Optional Ghidra version observation leaves the initialized value unknown if the native getter fails.',
        'Native version probing was not executed or qualified.'),
    ('unified/extract/ghidra_script.py', 'probe_versions', 324): (
        'Optional Java version observation leaves the initialized value unknown if the native getter fails.',
        'Native version probing was not executed or qualified.'),
    ('unified/extract/ghidra_script.py', 'run', 783): (
        'Project.close occurs in finally after the program-hash and extraction result/error path. It does not '
        'bypass those primary decisions.', 'Native cleanup and retained-handle/resource behavior need native evidence; '
        'no such completeness claim is made.'),
    ('unified/extract/ghidra_script.py', '_write_decomp', 853): (
        'Decompiler.dispose is cleanup after per-function code/status collection. Output write failures outside '
        'the cleanup catch still propagate.', 'Native disposal/resource behavior was not executed; no lossless native cleanup claim.'),
}


def describe(row):
    rule, path, function, line = row['rule'], row['path'].removeprefix('src/patchtrace/'), row['function'], row['detector_line']
    status = 'false-positive-at-reviewed-production-boundary'
    if rule in ('S101', 'S608'):
        return {'classification': status, 'evidence_level':'previous independent 43-site packet',
                'basis':'Previously reviewed exact caller/identifier/optimization boundary; retain the full per-site '
                        'guard ledger and normal/-O external controls in docs/qa/security-contract-triage-20261118.md.',
                'controls':'prior 1,012-check gate and root 16 source-pinned child replays',
                'limits':'This row is referenced, not silently counted as a new residual investigation.'}
    if rule == 'S310':
        basis, controls, limits = NETWORK[path]
        return {'classification':status,'evidence_level':'source trace and independent local controls',
                'basis':basis,'controls':controls,'limits':limits}
    if rule == 'S603':
        return {'classification':status,'evidence_level':'source trace and one harmless Python child',
                'basis':'run_process requires an absolute executable, refuses NUL argv and malformed explicit env, '
                        'and uses a list of arguments with shell=False and DEVNULL stdin. Configured tool executables '
                        'are trusted inputs; target paths remain arguments. The original inherited-environment defect '
                        'was repaired separately and is not reintroduced here.',
                'controls':'test_process_boundary_external.py (7 controls), exact argv/metacharacters/explicit env; '
                           'pure Windows batch policy only',
                'limits':'No target or native helper was executed. Windows process creation, safety of arbitrary '
                         'configured executables, and primary total-output/memory ceilings remain separate qualifications.'}
    if rule == 'S105':
        basis = ('Lexical parentheses/bracket/operator token comparison in source-code analysis; not a credential.'
                 if path == 'enrichment/signals.py' else
                 'The plain visual-style token selects chip/theme rendering; not a credential.'
                 if path.startswith('gui/qt/') else
                 'Hex-byte/wildcard grammar and metrics token; not a credential.'
                 if path == 'rules/contracts.py' else
                 'P00 is the manual-anchor pass identifier used to avoid duplicating manual atoms; not a credential.')
        return {'classification':status,'evidence_level':'literal/data-flow source trace', 'basis':basis,
                'controls':'current gate: enrichment signals, GUI chips/theme and rule-contract suites; '
                           'P00 identity also traced in the previously reviewed ladder contract',
                'limits':'No secret scan policy change, token renaming or general credential-exposure conclusion.'}
    if rule == 'S110' and function == '_engine_finished':
        return {'classification':'confirmed-defect-repaired','evidence_level':'actual SQLite/Qt red and green controls',
                'basis':'Failed/cancelled/timeout attempt storage exceptions were silently lost; a second reproduced '
                        'path falsely said an unstored successful result was kept. Source 7b4402a0 now retains bounded '
                        'class-only/refusal diagnostics in rows, copied details and final summaries, and bases kept '
                        'wording on successful publication.',
                'controls':'original test_failed_attempt_retention.py 3 red/1 positive; test_result_kept_external.py '
                           '1 red/1 positive; author and root exact-source 156-pass gates; unchanged current replay',
                'limits':'UI evidence remains transient, no automatic publication retry, no full run/set object '
                         'retention, no atomic multi-write or native matching claim.'}
    if rule == 'S110':
        basis, limits = SUPPRESSIONS[(path, function, line)]
        return {'classification':status,'evidence_level':'independent source guard trace', 'basis':basis,
                'controls':'security-s110-independent/review.md and receipt.json; no native cleanup execution',
                'limits':limits}
    if rule == 'S108':
        return {'classification':'adjacent-confirmed-ownership-defect-repaired','evidence_level':'real authored filesystem red/green',
                'basis':'The string is a project-relative staging name under safe_path, not a hardcoded shared /tmp '
                        'destination. Independent review nevertheless reproduced deletion of a preexisting stage '
                        'when mkdir failed. Source 43ac4829 moves exclusive creation before the owned-cleanup try.',
                'controls':'original collision 1 red/1 positive; source 219-pass gate and root 140-pass gate; '
                           'unchanged collision probe passes on continuation',
                'limits':'The S108 diagnostic remains. No nonce-prediction or arbitrary same-user namespace-race '
                         'immunity; owned cleanup begins only after successful exclusive creation.'}
    if rule == 'S314':
        return {'classification':'confirmed-encoding-policy-defect-repaired','evidence_level':'authored XML and PE-resource red/green',
                'basis':'BOM-less UTF-16BE with leading whitespace bypassed an encoding-sensitive DTD screen and '
                        'expanded an internal entity. Source e1c5006e refuses DTD at the parser callback, including '
                        'the pure-Python fallback. Current XMLParser and fromstring sites are both still reported.',
                'controls':'unchanged test_manifest_dtd_external.py: original 4 red/3 positive, fixed/current 7 pass; '
                           'normal encodings/DOCTYPE/entity controls in test_pe_manifest_dtd_boundary.py',
                'limits':'No external-file/network XXE or large expansion attack was claimed or executed. Two current '
                         'S314 warnings map to this one original warning; neither is removed from raw scans.'}
    raise AssertionError(row)


prior = json.loads((BASE/'qa/security-contract-triage/selected-source-map.json').read_text())
residual = json.loads((QA/'source-map.json').read_text())
original_rows = prior['rows'] + residual['rows']
current_raw_path = BASE/'qa/continuation-integration/ruff-strict-3faf436a.stdout'
current = json.loads(current_raw_path.read_text())
groups = defaultdict(list)
for entry in current:
    path, line = path_of(entry), entry['location']['row']
    function = function_at(path, line)
    groups[(entry['code'], path, function)].append(entry)
old_groups = defaultdict(list)
for row in original_rows:
    if row['rule'] == 'S314':
        # The first residual map deliberately left the replaced fromstring line
        # unmatched; the retained DTD repair now has two warnings in this function.
        row = dict(row, function=function_at(row['path'], 161))
    old_groups[(row['rule'], row['path'], row['function'])].append(row)
ledger = []
covered = set()
for key, old_rows in sorted(old_groups.items(), key=lambda item: tuple(part or '' for part in item[0])):
    observed = sorted(groups.get(key, []), key=lambda r:r['location']['row'])
    old_rows.sort(key=lambda r:r['detector_line'])
    special_xml = key[0] == 'S314'
    removed_ui = key[0] == 'S110' and key[2] == '_engine_finished'
    assert len(observed) == (2 if special_xml else 0 if removed_ui else len(old_rows)), (key, old_rows, observed)
    for index, old in enumerate(old_rows):
        sites = observed if special_xml else [] if removed_ui else [observed[index]]
        current_sites = []
        for entry in sites:
            line, column = entry['location']['row'], entry['location']['column']
            current_sites.append({'line':line,'column':column,'message':entry['message'],
                'statement':(TREE/old['path']).read_text().split('\n')[line-1].strip()})
            covered.add((entry['code'],old['path'],line,column))
        ledger.append({'rule':old['rule'],'path':old['path'],'original_line':old['detector_line'],
                       'function':old['function'],'current_sites':current_sites,
                       'current_file_sha256':sha(TREE/old['path']),**describe(old)})

additional = []
for entry in current:
    path, line, column = path_of(entry), entry['location']['row'], entry['location']['column']
    key=(entry['code'],path,line,column)
    if key in covered:
        continue
    assert entry['code']=='S608' and path=='src/patchtrace/pilot/sources/kb_context.py' and line==212, entry
    additional.append({'rule':'S608','path':path,'line':line,'column':column,'function':'capture',
        'current_file_sha256':sha(TREE/path),'classification':'false-positive-at-reviewed-production-boundary',
        'basis':'Only the ten literal _TEXT_COLUMNS and two literal _INTEGER_COLUMNS generate typeof/length '
                'expressions. FROM/ORDER BY clauses are fixed; kind and LIMIT use ? bindings. Row/body/CLI text '
                'never becomes SQL syntax. The metadata read preflights storage types and total row bytes.',
        'controls':'test_context_metadata_sql_external.py: 4 actual SQLite controls; independent exact-source '
                   'additional-s608-review.md trace and preserved source bytes',
        'limits':'Added after original strict79 and outside the prior43-site packet. No arbitrary hostile-schema, '
                 'all-store I/O or publication-race claim.'})
    covered.add(key)
assert len(original_rows)==79 and len(ledger)==79 and len(additional)==1 and len(covered)==80
snapshots=[]
for label,source,path in [
    ('configured-original-78','9e5a5303da6e9a745e604979932f814de8eca4b0',BASE/'release-security-static-audit.json'),
    ('strict-original-79','95bf8f5e71a4704befbf0e79f75ba64afe886cbc',
     BASE/'dependency-security-evidence/linux-static-95bf8f5e/static.stdout'),
    ('strict-before-ui-81','cdeada1b1bcc8078f31e6627e3a00b3bb8146542',BASE/'qa/static-root-review/combined-strict-all.json'),
    ('strict-current-80',SOURCE,current_raw_path),
]:
    raw=json.loads(path.read_text())
    snapshots.append({'label':label,'source':source,'path':str(path),'bytes':path.stat().st_size,
                      'sha256':sha(path),'count':len(raw),'codes':dict(Counter(r['code'] for r in raw)),
                      'exit':1})
output={'source':SOURCE,'original_strict_source':prior['detector_source'],'snapshots':snapshots,
        'original_rows':ledger,'additional_current_rows':additional,
        'mapping':'43 prior sites + original36 residual; XML one-to-two, UI one-to-zero, plus one new S608 = current80',
        'security_lane':'still failing; these dispositions do not modify detector results, suppressions or acceptance policy'}
(QA/'strict-disposition-ledger.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({'original_rows':len(ledger),'additional_rows':len(additional),'current_sites':len(covered),
                  'classifications':dict(Counter(r['classification'] for r in ledger))},indent=2))
