"""Independent authored controls for S310 boundaries; every response/socket is local data."""
from __future__ import annotations

import dataclasses
import hashlib
import io
import socket
import urllib.request

import pytest

from patchtrace.acquisition import transport as acquisition
from patchtrace.acquisition.contracts import AcquisitionError, PlannedDownload
from patchtrace.enrichment import intelligence as cve
from patchtrace.enrichment.contracts import EnrichmentError
from patchtrace.intelligence.contracts import IntelError
from patchtrace.intelligence.csaf import transport as csaf
from patchtrace.kbcorrelation.sources import inventory_fetch, inventory_http
from patchtrace.kbcorrelation.sources.cvrf import SourceError
from patchtrace.kev import transport as kev
from patchtrace.kev.contracts import KevError, plan_for

SYMBOL = 'https://msdl.microsoft.com/download/symbols/authored.dll/12341000/authored.dll'
BLOB = 'https://authored.blob.core.windows.net/review?sig=authored-only'
CSAF = 'https://msrc.microsoft.com/csaf/2099/review.json'
SUPPORT = 'https://support.microsoft.com/help/5099001'
INVENTORY = 'https://download.microsoft.com/download/review.csv'


@pytest.fixture(autouse=True)
def no_network(monkeypatch):
    def denied(*_args, **_kwargs):
        raise AssertionError('independent static controls forbid real sockets and DNS')
    for name in ('socket', 'create_connection', 'getaddrinfo'):
        monkeypatch.setattr(socket, name, denied)


class Response:
    def __init__(self, body=b'authored response', *, status=200, headers=None):
        self.body = io.BytesIO(body)
        self.status = status
        self.headers = headers or {}
        self.closed = False

    def read(self, size):
        assert 0 < size <= 65536
        return self.body.read(size)

    read1 = read

    def close(self):
        self.closed = True


class Opener:
    def __init__(self, *responses):
        self.responses = list(responses)
        self.calls = []

    def __call__(self, *args):
        method, url, headers, timeout = args if len(args) == 4 else ('GET', *args)
        self.calls.append((method, url, dict(headers), timeout))
        assert self.responses, 'an unapproved extra request reached the transport'
        return self.responses.pop(0)


def download_plan(body=b'authored non-executable data'):
    return PlannedDownload(side='older', file_name='authored.dll', sha256=hashlib.sha256(body).hexdigest(),
                           size=len(body), url=SYMBOL, record_sha256='0' * 64)


@pytest.mark.parametrize('url', [
    'file:///review/never-read', 'ftp://msdl.microsoft.com/x', 'http://msdl.microsoft.com/x',
    'https://msdl.microsoft.com.evil.invalid/x', 'https://user@msdl.microsoft.com/x',
    'https://msdl.microsoft.com:8443/x', '\thttps://msdl.microsoft.com/x',
])
def test_acquisition_refuses_unapproved_scheme_authority_spelling_before_open(url):
    opener = Opener()
    consent = acquisition.AcquisitionConsent.for_urls([url])
    with pytest.raises(AcquisitionError):
        acquisition.Transport(opener=opener).probe(url, consent)
    assert opener.calls == []


def test_acquisition_exact_url_consent_and_metadata_redirect_refusal():
    opener = Opener()
    transport = acquisition.Transport(opener=opener)
    with pytest.raises(AcquisitionError, match='consent'):
        transport.probe(SYMBOL, acquisition.AcquisitionConsent.for_urls([SYMBOL + '?changed']))
    assert opener.calls == []
    metadata = acquisition.metadata_url('authored.dll')
    response = Response(status=302, headers={'Location': BLOB})
    opener.responses.append(response)
    with pytest.raises(AcquisitionError, match='unexpected redirect'):
        transport.fetch_metadata('authored.dll', acquisition.AcquisitionConsent.for_urls([metadata]))
    assert [x[1] for x in opener.calls] == [metadata] and response.closed


@pytest.mark.parametrize('target', [
    'file:///review/never-read', 'https://authored.blob.core.windows.net.evil.invalid/x',
    'https://msdl.microsoft.com/other', 'https://user@authored.blob.core.windows.net/x',
])
def test_acquisition_redirect_is_checked_before_next_request(tmp_path, target):
    response = Response(status=302, headers={'Location': target})
    opener = Opener(response)
    with pytest.raises(AcquisitionError):
        acquisition.Transport(opener=opener).download(
            download_plan(), acquisition.AcquisitionConsent.for_urls([SYMBOL]), tmp_path)
    assert len(opener.calls) == 1 and response.closed
    assert list(tmp_path.iterdir()) == []


def test_acquisition_authorized_blob_transfer_is_hash_bound(tmp_path):
    body = b'authored non-executable data'
    responses = (Response(status=302, headers={'Location': BLOB}), Response(body))
    opener = Opener(*responses)
    result = acquisition.Transport(opener=opener).download(
        download_plan(body), acquisition.AcquisitionConsent.for_urls([SYMBOL]), tmp_path)
    assert result.path.read_bytes() == body
    assert result.sha256 == hashlib.sha256(body).hexdigest()
    assert result.source_url == SYMBOL and 'authored-only' not in repr(result)
    assert [x[1] for x in opener.calls] == [SYMBOL, BLOB]
    assert all(r.closed for r in responses)


@pytest.mark.parametrize('change', [
    {'url': 'file:///review/never-read'}, {'url': 'https://127.0.0.1/x'},
    {'headers': (('User-Agent', 'altered'),)}, {'key_header': 'Authorization'},
])
def test_cve_rederives_plan_before_open_even_with_matching_forged_consent(change):
    original, = cve.plan_requests(['CVE-2099-12345'], ['nvd'])
    forged = dataclasses.replace(original, **change)
    opener = Opener()
    with pytest.raises(EnrichmentError, match='altered'):
        cve.fetch([forged], cve.FetchConsent.for_plan([forged]), opener=opener)
    assert opener.calls == []


@pytest.mark.parametrize('target', [
    'file:///review/never-read', 'http://services.nvd.nist.gov/x',
    'https://services.nvd.nist.gov.evil.invalid/x', 'https://user@services.nvd.nist.gov/x',
])
def test_cve_rechecks_redirect_before_open(target):
    plan = cve.plan_requests(['CVE-2099-12345'], ['nvd'])
    response = Response(status=302, headers={'Location': target})
    opener = Opener(response)
    with pytest.raises(EnrichmentError):
        cve.fetch(plan, cve.FetchConsent.for_plan(plan), opener=opener, api_key='authored-key')
    assert len(opener.calls) == 1 and response.closed


def test_cve_cross_provider_redirect_strips_session_key_and_keeps_exact_initial_request():
    plan = cve.plan_requests(['CVE-2099-12345'], ['nvd'])
    target, = cve.plan_requests(['CVE-2099-12345'], ['msrc'])
    responses = (Response(status=302, headers={'Location': target.url}), Response(b'{}'))
    opener = Opener(*responses)
    result = cve.fetch(plan, cve.FetchConsent.for_plan(plan), opener=opener, api_key='authored-key')
    assert [x[1] for x in opener.calls] == [plan[0].url, target.url]
    assert 'authored-key' in opener.calls[0][2].values()
    assert 'authored-key' not in opener.calls[1][2].values()
    assert result['CVE-2099-12345']['nvd'].body == b'{}'
    assert all(r.closed for r in responses)


@pytest.mark.parametrize('url', [
    'file:///review/never-read', 'http://msrc.microsoft.com/csaf/x',
    'https://msrc.microsoft.com.evil.invalid/csaf/x', 'https://msrc.microsoft.com/not-csaf/x',
    'https://msrc.microsoft.com/csaf/%2e%2e/x', 'https://msrc.microsoft.com/csaf/x?query=1',
    'https://user@msrc.microsoft.com/csaf/x',
])
def test_csaf_checks_original_and_redirected_urls(url):
    consent = csaf.CsafConsent.for_hosts(['msrc.microsoft.com'])
    opener = Opener()
    client = csaf.CsafTransport(consent, opener=opener)
    with pytest.raises(IntelError):
        client.get(url, 'document')
    assert opener.calls == []
    response = Response(status=302, headers={'Location': url})
    opener.responses.append(response)
    with pytest.raises(IntelError):
        client.get(CSAF, 'document')
    assert len(opener.calls) == 1 and response.closed


def test_csaf_consent_required_and_valid_same_host_redirect_works():
    with pytest.raises(IntelError, match='consent'):
        csaf.CsafTransport(None, opener=Opener())
    target = 'https://msrc.microsoft.com/csaf/2099/review2.json'
    opener = Opener(Response(status=302, headers={'Location': target}), Response(b'{}'))
    result = csaf.CsafTransport(csaf.CsafConsent.for_hosts(['msrc.microsoft.com']), opener=opener).get(
        CSAF, 'document')
    assert result.body == b'{}' and result.final_url == target
    assert [x[1] for x in opener.calls] == [CSAF, target]


@pytest.mark.parametrize('target', [
    'file:///review/never-read', 'https://www.cisa.gov.evil.invalid/x',
    'http://www.cisa.gov/x', 'https://user@www.cisa.gov/x',
    'https://raw.githubusercontent.com/cisagov/kev-data/main/x.json',
])
def test_kev_redirect_cannot_change_approved_host(target):
    plan = plan_for('cisa-site')
    response = Response(status=302, headers={'Location': target})
    opener = Opener(response)
    with pytest.raises(KevError):
        kev.KevTransport(kev.KevConsent.for_plan(plan), opener=opener).fetch(plan)
    assert len(opener.calls) == 1 and response.closed


def test_kev_exact_source_consent_and_same_host_positive():
    plan, other = plan_for('cisa-site'), plan_for('cisa-github')
    opener = Opener()
    with pytest.raises(KevError, match='consent'):
        kev.KevTransport(kev.KevConsent.for_plan(other), opener=opener).fetch(plan)
    assert opener.calls == []
    target = 'https://www.cisa.gov/review.json'
    opener.responses.extend([Response(status=302, headers={'Location': target}), Response(b'{}')])
    result = kev.KevTransport(kev.KevConsent.for_plan(plan), opener=opener).fetch(plan)
    assert result.body == b'{}' and result.final_url == target
    assert all(x[2] == {'Accept': 'application/json', 'User-Agent': 'PatchTrace'} for x in opener.calls)


@pytest.mark.parametrize('url', [
    'file:///review/never-read', 'https://support.microsoft.com.evil.invalid/x',
    'https://user@support.microsoft.com/x', 'https://support.microsoft.com:8443/x',
    '\thttps://support.microsoft.com/x', 'https://support.microsoft.com/%2e%2e/x',
])
def test_inventory_refuses_raw_url_before_opener_construction(url, monkeypatch):
    called = []
    monkeypatch.setattr(urllib.request, 'build_opener', lambda *handlers: called.append(handlers))
    with pytest.raises(SourceError):
        inventory_http.urllib_open('GET', url, {}, 1, kind='support-page')
    assert called == []


def test_inventory_consent_binds_full_ordered_chain():
    first = 'https://go.microsoft.com/fwlink/?linkid=1234'
    plan = inventory_fetch.build_plan(first, kind='file-inventory', redirects=[INVENTORY])
    opener = Opener()
    with pytest.raises(SourceError, match='consent'):
        inventory_fetch.fetch_source(plan, consent_hosts=plan.hosts, consent_plan='0' * 64, opener=opener)
    assert opener.calls == []
    opener.responses.append(Response(status=302, headers={'Location': INVENTORY + '?changed=1'}))
    with pytest.raises(SourceError, match='changed the ordered'):
        inventory_fetch.fetch_source(plan, consent_hosts=plan.hosts, consent_plan=plan.plan_sha, opener=opener)
    assert len(opener.calls) == 1
    opener = Opener(Response(status=302, headers={'Location': INVENTORY}), Response(b'name,size\nf,1\n'))
    result = inventory_fetch.fetch_source(
        plan, consent_hosts=plan.hosts, consent_plan=plan.plan_sha, opener=opener)
    assert result.raw == b'name,size\nf,1\n' and result.redirect_chain == plan.urls
    assert [x[1] for x in opener.calls] == list(plan.urls)


def address(ip):
    ipv6 = ':' in ip
    return (socket.AF_INET6 if ipv6 else socket.AF_INET, socket.SOCK_STREAM, socket.IPPROTO_TCP, '',
            (ip, 443, 0, 0) if ipv6 else (ip, 443))


@pytest.mark.parametrize('private', ['127.0.0.1', '10.0.0.1', '::1', '::ffff:127.0.0.1', '64:ff9b::7f00:1'])
def test_inventory_checks_all_dns_answers_before_any_connection(private):
    made = []
    with pytest.raises(SourceError, match='non-global'):
        inventory_http.connect_public(('support.microsoft.com', 443), 1,
            resolver=lambda *a, **kw: [address('93.184.216.34'), address(private)],
            socket_factory=lambda *a: made.append(a))
    assert made == []


def test_inventory_connects_only_the_once_validated_numeric_address():
    resolved, connected = [], []

    def resolver(*args, **kwargs):
        resolved.append((args, kwargs))
        return [address('93.184.216.34')]

    class FakeSocket:
        def settimeout(self, seconds):
            assert 0 < seconds <= 1

        def connect(self, target):
            connected.append(target)

    sock = FakeSocket()
    result = inventory_http.connect_public(('support.microsoft.com', 443), 1,
        resolver=resolver, socket_factory=lambda *a: sock)
    assert result is sock and len(resolved) == 1 and connected == [('93.184.216.34', 443)]


@pytest.mark.parametrize('module', ['acquisition', 'cve', 'csaf', 'kev', 'inventory'])
def test_real_urllib_adapters_construct_requests_without_proxies_or_auto_redirects(module, monkeypatch):
    requests, handlers = [], []
    monkeypatch.setenv('HTTPS_PROXY', 'http://127.0.0.1:9')
    raw = Response(b'{}')

    class Director:
        def open(self, req, timeout):
            requests.append((req, timeout))
            return raw

    def build(*values):
        handlers.extend(values)
        return Director()

    monkeypatch.setattr(urllib.request, 'build_opener', build)
    url = {'acquisition': SYMBOL, 'cve': cve.plan_requests(['CVE-2099-12345'], ['nvd'])[0].url,
           'csaf': CSAF, 'kev': plan_for('cisa-site').url, 'inventory': SUPPORT}[module]
    if module == 'acquisition':
        response = acquisition.urllib_open('GET', url, {'User-Agent': 'PatchTrace'}, 1)
    elif module == 'inventory':
        response = inventory_http.urllib_open('GET', url, {'User-Agent': 'PatchTrace'}, 1, kind='support-page')
    else:
        response = {'cve': cve, 'csaf': csaf, 'kev': kev}[module].urllib_open(
            url, {'User-Agent': 'PatchTrace'}, 1)
    assert len(requests) == 1 and requests[0][0].full_url == url
    assert requests[0][0].get_method() == 'GET' and requests[0][1] == 1
    proxies = [h for h in handlers if isinstance(h, urllib.request.ProxyHandler)]
    redirects = [h for h in handlers if isinstance(h, urllib.request.HTTPRedirectHandler)]
    assert len(proxies) == 1 and proxies[0].proxies == {}
    assert len(redirects) == 1 and redirects[0].redirect_request(None, None, 302, '', {}, 'https://evil.invalid') is None
    response.close()
    assert raw.closed
