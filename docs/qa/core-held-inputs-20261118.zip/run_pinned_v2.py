"""Exact-source affected gate runner for neutral core held inputs."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path('/workspace/scratch/c7a9e8d98848/security-residual-qa')
QA=Path(__file__).resolve().parent
SOURCE=ROOT/'src'
EXPECTED=sys.argv[1]
LABEL=sys.argv[2]
FILES=sys.argv[3:]
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(SOURCE))
os.environ['PYTHONPATH']=str(SOURCE)
os.environ['QT_QPA_PLATFORM']='offscreen'
import pytest

started=time.monotonic()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
assert head==EXPECTED,(head,EXPECTED)
arguments=['-q',*FILES,f'--junitxml={QA}/{LABEL}.xml']
(QA/f'{LABEL}.command.json').write_text(json.dumps({'source_commit':EXPECTED,'cwd':str(ROOT),
 'command':[sys.executable,str(Path(__file__).resolve()),EXPECTED,LABEL,*FILES],
 'pytest_arguments':arguments,'environment':{'PYTHONPATH':str(SOURCE),'QT_QPA_PLATFORM':'offscreen'},
 'working_diff_before':subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=ROOT,text=True).splitlines()},indent=2)+'\n')
result=int(pytest.main(arguments))
modules=[];drift=[]
for name,module in sorted(sys.modules.items()):
 if not name.startswith('patchtrace') or not getattr(module,'__file__',None):continue
 path=Path(module.__file__).resolve();entry={'name':name,'path':str(path)}
 if not path.is_relative_to(SOURCE):
  drift.append(name);entry['unexpected_source']=True
 else:
  rel=path.relative_to(ROOT).as_posix();raw=path.read_bytes()
  expected=subprocess.check_output(['git','show',f'{EXPECTED}:{rel}'],cwd=ROOT)
  entry.update(relative_path=rel,sha256=hashlib.sha256(raw).hexdigest(),expected_sha256=hashlib.sha256(expected).hexdigest())
  if raw!=expected:drift.append(name)
 modules.append(entry)
(QA/f'{LABEL}.imports.json').write_text(json.dumps({'source_commit':EXPECTED,'modules':modules,'drift':drift},indent=2)+'\n')
changed=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=ROOT,text=True).splitlines()
exit_code=1 if drift or changed else result
(QA/f'{LABEL}.exit.json').write_text(json.dumps({'source_commit':EXPECTED,'pytest_exit':result,'exit_code':exit_code,
 'import_count':len(modules),'source_drift':drift,'working_diff_after':changed,'seconds':time.monotonic()-started},indent=2)+'\n')
raise SystemExit(exit_code)
