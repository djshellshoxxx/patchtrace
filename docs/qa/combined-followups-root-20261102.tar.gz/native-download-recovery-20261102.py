"""Re-download unchanged published tool pins; do not execute compared images or change trust flags."""
import datetime,hashlib,json,os,urllib.request
from pathlib import Path
repo=Path('/workspace/scratch/142cb233d750/wt-full-recovered')
folder=Path('/workspace/scratch/142cb233d750/native-20261102/downloads');folder.mkdir(parents=True,exist_ok=True)
receipt=folder.parent/'download-receipt.json';records=[]
for pin in json.loads((repo/'docs/qa/native-reconciliation-20261101-download-evidence.json').read_text())[:2]:
 row={k:pin[k] for k in ['name','url','expected_sha256','bytes']};row['started_utc']=datetime.datetime.now(datetime.UTC).isoformat()
 target=folder/pin['name'];partial=target.with_suffix(target.suffix+'.part')
 try:
  digest=hashlib.sha256();size=0
  with urllib.request.urlopen(pin['url'],timeout=60) as response,partial.open('xb') as stream:
   while block:=response.read(1024*1024):
    size+=len(block)
    if size>pin['bytes']:raise ValueError('download exceeds exact pinned length')
    stream.write(block);digest.update(block)
   stream.flush();os.fsync(stream.fileno())
  row.update(actual_sha256=digest.hexdigest(),actual_bytes=size)
  if size!=pin['bytes'] or digest.hexdigest()!=pin['expected_sha256']:raise ValueError('pinned digest or size mismatch')
  os.link(partial,target);partial.unlink();row['status']='downloaded-and-hash-verified'
 except Exception as exc:
  row.update(status='failed',error=f'{type(exc).__name__}: {exc}')
 row['finished_utc']=datetime.datetime.now(datetime.UTC).isoformat();records.append(row)
 receipt.write_text(json.dumps({'tool_setup_only':True,'analysis_started':False,'pin_source':'4a82fd311877d31fc322027a94fa1aecfbbec0a9','downloads':records},indent=2)+'\n')
 print(json.dumps(row),flush=True)
 if row['status']=='failed':raise SystemExit(1)
