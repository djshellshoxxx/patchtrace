"""Independent receipt-identity controls: authored JSON only, no processes/network."""
from __future__ import annotations

import json

import pytest
from test_windows_bindiff_network import evidence, validate

from tools import windows_bindiff_network as net


@pytest.mark.parametrize('spelling', ['leading-zero', 'unicode-decimal'])
def test_equal_process_creation_time_cannot_be_disguised_as_a_new_launch(spelling):
    doc = evidence(net)
    validate(net, doc)
    first, second = doc['launches'][:2]
    timestamp = first['created']
    disguised = ('0' + timestamp if spelling == 'leading-zero' else
                 ''.join(chr(0x660 + int(digit)) for digit in timestamp))
    assert disguised != timestamp and int(disguised) == int(timestamp)
    second.update(pid=first['pid'], owner_pid=900, created=disguised)
    decoded = net.read_evidence_bytes(json.dumps(doc, ensure_ascii=False).encode('utf-8'))
    with pytest.raises(net.NetworkEvidenceError):
        validate(net, decoded)


@pytest.mark.parametrize('reuse_pid', [False, True])
def test_canonical_distinct_native_creation_identities_remain_accepted(reuse_pid):
    doc = evidence(net)
    if reuse_pid:
        first, second = doc['launches'][:2]
        second.update(pid=first['pid'], owner_pid=900)
        assert int(second['created']) != int(first['created'])
    validate(net, net.read_evidence_bytes(json.dumps(doc).encode('utf-8')))
