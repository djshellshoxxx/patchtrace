"""Seal a reviewed source checkpoint; retain prior failures and scope boundaries."""
from __future__ import annotations

import collections
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
QA = ROOT / 'qa/continuation-integration'
SOURCE = '5bbb925694b89ddc77e2aae1ea36c9f563c7760d'
BASE = '55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
MAIN = '9c411ca3d7b47f950be5f0c6f01b3c54184554c6'
DEST = REPO / 'docs/qa/verified-continuation-20261118'


def git(*args: str) -> str:
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def read_json(path: Path):
    return json.loads(path.read_text())


def save(path: Path, data) -> None:
    assert not path.exists(), path
    path.write_text(json.dumps(data, indent=2) + '\n')


assert git('rev-parse', 'HEAD') == SOURCE and not git('status', '--porcelain')
tree = git('rev-parse', 'HEAD^{tree}')
proof = read_json(QA / 'source-preservation-5bbb9256.json')
assert proof['source'] == SOURCE and proof['tree'] == tree and len(proof['files']) == 26
exit_receipt = read_json(QA / 'combined-5bbb9256-exit.json')
assert exit_receipt['exit'] == 0 and exit_receipt['source_after'] == SOURCE
assert not exit_receipt['status_after'] and not exit_receipt['foreign_imports']
assert not exit_receipt['imported_source_drift'] and exit_receipt['imported_source_count'] == 517
cases = list(ET.parse(QA / 'combined-5bbb9256.xml').iter('testcase'))
skipped = [dict(classname=c.get('classname'), name=c.get('name'),
                type=c.find('skipped').get('type'), reason=c.find('skipped').get('message'))
           for c in cases if c.find('skipped') is not None]
assert len(cases) == 2773 and len(skipped) == 9
assert not any(c.find('error') is not None or c.find('failure') is not None for c in cases)
save(QA / 'combined-5bbb9256-skip-reasons.json', skipped)
guard = read_json(QA / 'combined-5bbb9256-offline-guard.json')
assert guard['pytest_exit'] == 0 and guard['network_filter']['seccomp_load_result'] == 0
assert guard['inherited_socket_descriptors'] == []
assert read_json(QA / 'combined-5bbb9256-pin-interception.json')['intercepted_default_runner_calls'] == []
assert read_json(QA / 'ruff-normal-5bbb9256-context.json')['exit'] == 0
strict = read_json(QA / 'ruff-strict-5bbb9256-context.json')
assert strict['exit'] == 1 and strict['total'] == 80
assert read_json(QA / 'strict-sites-5bbb9256-comparison.json')['same_site_and_statement_multiset']
partial = read_json(QA / 'original-partial-batch-index.json')
assert partial['counts'] == dict(completed_batches=97, cases=23742, failed=63, errors=0,
                                 skipped_or_xfail=146, skip_types={'pytest.skip': 140, 'pytest.xfail': 6})
assert not partial['full_run_complete'] and not partial['summary_present']
assert not partial['batch98_junit_present'] and not partial['batch99_exists']
path_review = read_json(ROOT / 'qa/full-batch-path-root-review/classification-review.json')
assert path_review['original_failures_matched'] == 61 and path_review['original_receipts_verified'] == 17

history = []
for commit in git('rev-list', '--reverse', '--first-parent', BASE + '..HEAD').splitlines():
    message = git('show', '-s', '--format=%B', commit)
    assert '[no release]' in message
    history.append(dict(sha=commit, parents=git('show', '-s', '--format=%P', commit).split(),
                        tree=git('rev-parse', commit + '^{tree}'), message=message,
                        author=git('show', '-s', '--format=%an <%ae>', commit),
                        author_date=git('show', '-s', '--format=%aI', commit)))
assert len(history) == 37
save(QA / 'integration-history-through-5bbb9256.json', history)

payload = {}
review_dirs = [
    'continuation-integration', 'evidence-attempt-root-review', 'named-superseded-root-review',
    'codetext-root-review', 'codetext-window-guard-root-review', 'backend-pin-root-review',
    'kb-selftest-root-review', 'windows-network-root-review', 'security-residual-root-review',
    'semantic-disposition-batch2-root', 'semantic-disposition-batch3-root-review',
    'full-batch-path-root-review',
]
for name in review_dirs:
    directory = ROOT / 'qa' / name
    assert directory.is_dir()
    for path in sorted(directory.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts and not path.name.endswith('.pyc'):
            payload['review/' + name + '/' + path.relative_to(directory).as_posix()] = path.read_bytes()
prior = ROOT / 'qa/followup-full-batches-55f3d074'
for path in sorted(prior.glob('*')):
    if path.is_file():
        payload['original-partial-broad/' + path.name] = path.read_bytes()
for name in ('command.json', 'result.json', 'collection.json', 'junit.xml', 'pytest.log'):
    for path in sorted(prior.glob('batch-*/' + name)):
        payload['original-partial-broad/' + path.relative_to(prior).as_posix()] = path.read_bytes()
for name in ('README.md', 'manifest.json', 'evidence.zip', 'classification.json'):
    payload['guarded-path-recheck/' + name] = (ROOT / 'qa/full-batch-path-recheck' / name).read_bytes()
for name in ('full_batch_receipt.py', 'resolve_record_appends.py', 'replay_reviewed_checks.py',
             'verify_continuation_sources.py', 'run_continuation_gate.py',
             'continuation_offline_pytest.py', 'seal_continuation_checkpoint.py'):
    payload['coordinator/' + name] = (ROOT / 'ops' / name).read_bytes()
payload['coordinator/reviewed_network_filter.py'] = (ROOT / 'qa/full-batch-path-recheck/offline_replay.py').read_bytes()
for name in proof['files']:
    payload['source/' + SOURCE + '/' + name] = (REPO / name).read_bytes()
payload['source/source-delta.patch'] = subprocess.check_output(['git', '-C', str(REPO), 'diff', BASE, SOURCE])
assert all(not name.startswith('/') and '..' not in Path(name).parts for name in payload)
DEST.mkdir(parents=True, exist_ok=False)
archive = DEST / 'evidence.zip'
with zipfile.ZipFile(archive, 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(payload.items()):
        item = zipfile.ZipInfo(name, (2026, 11, 18, 0, 0, 0))
        item.compress_type = zipfile.ZIP_DEFLATED
        item.external_attr = 0o100644 << 16
        z.writestr(item, data, compresslevel=9)
raw = archive.read_bytes()
manifest = dict(schema='patchtrace-reviewed-continuation/1', source=SOURCE, tree=tree, base=BASE,
                main_observed=MAIN, archive=archive.name, archive_bytes=len(raw),
                archive_sha256=digest(raw), member_count=len(payload),
                members=[dict(path=n, bytes=len(b), sha256=digest(b)) for n, b in sorted(payload.items())])
save(DEST / 'manifest.json', manifest)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(set(z.namelist())) == len(payload) and z.testzip() is None
    assert set(z.namelist()) == set(payload)
    for item in manifest['members']:
        data = z.read(item['path'])
        assert len(data) == item['bytes'] and digest(data) == item['sha256']

readme = f'''# Reviewed continuation checkpoint — November 18, 2026

The local continuation combines independently reviewed repairs on actual PR #316
`{BASE}`. Its selected integration gate passes **2,764 tests, with nine explicit
skips and zero failures/errors**, in 215.13 seconds. Canonical main remains
`{MAIN}`. Main acceptance is open; no main merge, PR closure, release, tag,
deployment, force-push or branch deletion is claimed.

## Exact source and review

Tested source: **`{SOURCE}`**. Tree: **`{tree}`**.
Branch: `codex/verified-continuation-20261118`.
All 26 changed production/test/tool/workflow paths since published #316 match
their reviewed owners byte for byte. The base is an actual ancestor, and all 37
local continuation commits retain `[no release]` and selective-port attribution.
There was no manual production conflict resolution. Two cherry-picks had
documentation append conflicts; both dated bodies survive, with stage hashes
and complete resolution records.

| Scope | Reviewed source | Verified change and independent evidence |
|---|---|---|
| Failed-attempt presentation | `7b4402a0` | Storage failure remains visible after row/copy/final-summary and scheduler failures; kept results contain actual publications only. Root 156 affected passes and original immutable SQLite/Qt controls. |
| Explicit old advisory selection | `51f33d5a` | A bounded selected-superseded explanation appears in text/JSON/desktop while source withholding and ambiguity stay intact. Root 411 affected passes and a separate unchanged historical positive. |
| Directory publication | `843dfec7` | Linux no-replace publication and Windows rename dispatch preserve foreign destinations; reparse stages are refused. Root 319 passes/one native Windows skip; independent 56 passes/two capability skips. Original reservation and metadata failures remain. |
| Code highlighter | `2bf86c88` | Model/session/window checks prevent unnecessary span dispatch inside the existing failure boundary. Root 79 current and three separate unchanged historical passes; author normal/2x gates remain separately scoped. |
| Backend-pin unit fixture | `e4ee7ca4` | No-input verification now injects the existing process seam and refuses a real-runner fallback. Root protected original probe passes with zero process/network attempts; original red call capture is preserved. Product pin verification is unchanged. |
| Packaged synthetic F8 journey | `316b0f12` | Real offscreen dialog/host/store journey covers import, scope, cancel/retry, create/adopt, candidate/report/snapshot and stale reopen, with owned cleanup. Root 43 passes; author 398 passes. Synthetic fixtures are not native engine or real-CVE accuracy evidence. |
| Windows BinDiff acceptance candidate | `857a78e9` | Native containment tooling plus complete semantic fingerprint and source-bound receipts; root review fixed alternate creation-time spellings. Root original 129 and final 213 portable passes. Windows SDK/build/network/lifecycle and real BinDiff acceptance remain pending. |

All counts above overlap the combined gate; they are not added into a unique
coverage total. The original QA packets retain their historical review-pending
wording; this checkpoint records the later independent disposition.

## Combined execution and capability limits

The 87-file selected gate ran unchanged assertions from a clean checkout. All
517 imported project modules resolved under this exact source, with no foreign
editable checkout or changed source. A fresh owned system-temp directory avoided
the earlier path-confinement mistake. The helper loaded an inherited Linux
network-denial filter before collection, confirmed no inherited socket handles,
and restricted Git to local-file transport with global/system configuration
disabled. No test was deselected by this helper. Its observed 577 process-audit
events include authored test children and local fixture tools, not a claim of
native Windows qualification. This execution safeguard is not a product sandbox.

The nine skips are: native Windows junction creation; optional colorspacious
oracle; six Windows job/launch/preflight cases; and the host's unavailable AF_UNIX
socket capability. Every exact node/reason is archived. The live harness also
explicitly reports BinDiff blocked because `PATCHTRACE_BINDIFF` is unset. A
successful pytest exit does not turn that blocked live acceptance into a pass.

Normal Ruff over `src tests tools` passes. The strict isolated, ignore-noqa
security scan still **fails 80 diagnostics**: S101 9, S105 14, S108 1, S110 12,
S310 6, S314 2, S603 1 and S608 35. Root verified the same path/code/statement
multiset as source `3faf436a`; no finding was suppressed or exchanged for a new
site. The residual security ledger accounts for the original 79 plus later
additions/removals, but manual dispositions do not satisfy the failing scan gate.

## Original broad run and its separate repairs

The broad run remains incomplete at actual source `{BASE}`. Ninety-seven of
99 planned batches produced JUnit: **23,533 passed, 63 failed, 140 skipped and
six expected failures**, with zero errors, across 23,742 completed cases. Batch
98 has only a partial log/collection receipt; batch 99 did not begin. There is
no final summary and no full-suite acceptance claim.

Automatic approval review rejected resuming that runner because a nominally
offline backend-pin fixture could invoke a real GitHub fetch. The source trace
and protected probe identified the uninjected process seam without executing
that fetch; the fixture repair above uses authored outcomes. The old runner was
not resumed by the separate reviews or the new selected gate.

A guarded recheck at unchanged source `55f3d074` passed all **61 original failures
affected by temporary-directory placement**: 60 path-confinement cases and one
Git-tree consent case. Its complete 14-module result is 478 passed/one existing
optional skip in 8.93 seconds. Seventeen original receipts remain byte-identical.
Twenty-nine original assertions hid their diagnostics; their classification is
explicitly an inference from source, direct guard checks and unchanged replay,
not recovered stderr. The other two original failures are the unavailable
AF_UNIX capability and a real missing dependency-spec registry row. The latter
is repaired here. A second existing registry control caught the new Windows
acceptance spec's omitted index row (one failure/108 passes); its registration
is fixed and all 109 registry cases pass within the combined gate.

## Branch audit, product gaps and hosted qualification

Semantic batches 2 and 3 are retained as scoped source reviews. Three completed
batches select 60 of the original 131 unresolved tips; 71 remain unselected at
this checkpoint, and broader residue remains open even for selected tips. These
counts do not close branches or measure feature completion. The next batch and
its newly reproduced R2 evidence-retention/manual-attribution defects remain
separate active work; no R2 repair is included in this source.

The full CVE-to-function workflow still needs representative independently
grounded binary/negative-control journeys, approved package acquisition,
PW-02 local MSU/CAB intake, native/manual desktop acceptance and final platform
gates. F8 is an authored offline integration control. L1 frozen failures, the
original L2 miss and unverified L3 acquisition remain unchanged.

The archived fresh GitHub snapshot still shows main `9c411ca3` and PR #316 open
at `55f3d074`. Some hosted checks for that earlier head have completed, with others
queued/in progress or skipped. Their underlying source/log/artifact review is
separate. None supplies final acceptance to this new source. Windows/Linux full
QA, repeated Qt, native adapters, frozen packages/installers, dependency/security
scans and reproducibility remain applicable gates. Publication of a reviewed
candidate is separate from permission to merge it into main or release it.

## Evidence integrity

The adjacent archive contains **{len(payload)} verified payloads**,
**{len(raw):,} bytes**, SHA-256 **`{digest(raw)}`**. Its manifest binds exact names,
sizes and hashes; duplicate names, CRC, membership and every payload were checked
after writing. It includes source/owner proofs, attributed commit history,
independent review logs, clean-source commands, all 97 completed broad-batch
JUnit/commands/logs, partial batch 98 records, original approval rejection,
guarded recheck, strict diagnostics and source snapshots. Earlier author packets
remain separate files in this repository and are hash-verified by the root
review records. No historical failure receipt or frozen research outcome was
rewritten.
'''
(DEST / 'README.md').write_text(readme)

matrix = f'''

## Reviewed continuation source — 2026-11-18

Source `{SOURCE}` (tree `{tree}`) preserves actual PR #316 as its ancestor and
passes 2,764 selected checks with nine explicit skips. All 26 changed source/test/
tool/workflow files match reviewed owner bytes. This is scoped regression
evidence; final full/platform/native/package/security G remains open. Main is
unchanged. The [complete checkpoint](../qa/verified-continuation-20261118/README.md)
retains original failures, per-source results, capability limits and archive hashes.

| Feature/slice | Current state | Milestones | Concrete remaining acceptance |
|---|---|---|---|
| Failed-attempt diagnostics and named superseded-source explanations | Reviewed repairs integrated locally | D/R: 50% | Representative native/manual J; actual final G; unchanged evidence withholding/publication semantics |
| Backup/offline-runtime directory publication | Reviewed no-replacement helper and reparse admission integrated | D/R: 50% | Native Windows filesystem/junction checks, representative recovery J and final G |
| Highlighter dispatch | Narrow model/session/window guard integrated; current/historical positives retained | D/R: 50% | Native/manual scaling and complete investigation J; final G |
| Packaged KB self-test | Synthetic current-service journey, source snapshots and failure cleanup implemented | D/R: 50% | Extracted Windows/Linux packages and real-source/native/manual J; final G; no accuracy credit from authored fixtures |
| Windows BinDiff effective denial | Acceptance candidate plus canonical process identities integrated in tooling | D/R: 50% for portable validator/tooling slice | Windows SDK build, effective socket/token/descendant/lifecycle observations and actual adapter semantic equality; native J/G open |
| Broad suite and strict security | Original broad run incomplete; guarded path recheck and hermetic fixture repaired; strict 80 findings remain | No new G credit | Complete exact-source full/platform/scanner gates; all skips/blocked receipts unverified |
| PW-02 local MSU/CAB intake | Planned separate product slice | None: 0% | Bounded native extraction contract/implementation, independent review and Windows journey |

The seven named fixes add no aggregate product percentage. Batch 2/3 source
reviews select 60/131 original unresolved tips; 71 and broader residue remain at
this snapshot. R2 acceptance-witness/manual-attribution repair is still separate
active work and is absent from this source. Native/frozen L1/L2/L3 boundaries and
the no-release hold remain intact.
'''
with (REPO / 'docs/plans/patchtrace-completion-matrix.md').open('a') as stream:
    stream.write(matrix)
with (REPO / 'docs/plans/autonomous-consolidation-20261118/consolidation-ledger.md').open('a') as stream:
    stream.write(f'''

## Independently reviewed continuation checkpoint — 2026-11-18

Local source `{SOURCE}` appends 37 attributed commits to actual PR #316 `55f3d074`.
All 26 changed production/test/tool/workflow paths match reviewed owner snapshots;
the combined selected gate passes 2,764 with nine explicit skips. Source/QA ports
cover failed-attempt diagnostics, selected-superseded explanations, directory
publication, highlighter dispatch, hermetic pin fixture, synthetic F8 and native
BinDiff acceptance tooling with canonical creation identities. Batch 2/3 and the
residual security ledger are preserved; strict scanning still fails 80 sites.

The [checkpoint](../../qa/verified-continuation-20261118/README.md) retains all
original broad-run receipts (97 completed batches, 63 failures, partial 98), the
separate guarded 61-case path recovery, independent reviews and exact-source
capability limits. Neither a main merge nor whole-branch closure follows. Main
remains `9c411ca3`. Batch 4/R2 work, 71 unselected original tips, broader residue and
full/native/package/security acceptance remain outside this checkpoint.
''')
with (REPO / 'docs/qa.md').open('a') as stream:
    stream.write(f'''

## [VERIFIED-CONTINUATION-20261118]

Clean source `{SOURCE}` passes **2,764 selected checks / nine explicit skips**
in 215.13 seconds; all 26 changed code/test/tool/workflow paths match independently
reviewed owners. Normal Ruff passes; isolated ignore-noqa strict security remains
**80 findings, exit 1**, with the same path/code/statement multiset as `3faf436a`.
All 517 imported project modules are source-pinned. An inherited process-local
network-denial guard and local-only Git transport protect this inspected offline
selection; no assertion was weakened or test deselected. Original broad-run
failures and partial receipts, guarded path recheck, native/live blockers and all
exact skip reasons remain in the [sealed checkpoint](qa/verified-continuation-20261118/README.md).
Full/platform/native/package/scanner gates and main merge remain open.
''')
with (REPO / 'tasks/todo.md').open('a') as stream:
    stream.write(f'''

### [VERIFIED-CONTINUATION-20261118]

- [x] Independently review and selectively port the seven bounded source/tooling repairs; preserve original red evidence, authorship and all branch references.
- [x] Retain semantic batches 2/3 and the source-specific residual security dispositions without converting strict findings to a scanner pass.
- [x] Verify all 26 changed source/test/tool/workflow paths against exact reviewed owners at `{SOURCE}`; preserve append-only documentation conflict bodies.
- [x] Run the 87-file combined offline gate: 2,764 passed, nine skips, zero failures/errors; retain all 517 imported-source identities, normal Ruff and strict 80 findings.
- [x] Preserve incomplete original broad run and automatic-review rejection; separately verify 61 path-related original failures and the hermetic no-input fixture repair.
- [ ] Publish the reviewable continuation append-only to existing PR #316, verify every remote tree/parent and fresh main/PR state; no main merge or release implied.
- [ ] Finish R2 acceptance-witness/manual-attribution repair and remaining semantic branch batches, with independent review and exact-source gates.
- [ ] Implement/qualify separate PW-02 acquisition slice; complete representative CVE/KB/native/manual journeys.
- [ ] Complete final full Linux/Windows, repeated Qt, native, frozen package/installer, dependency/security and reproducibility gates; treat skipped/blocked/stale evidence as unverified.

See the [immutable continuation checkpoint](../docs/qa/verified-continuation-20261118/README.md).
''')
print(json.dumps(dict(source=SOURCE, tree=tree, payloads=len(payload), archive_bytes=len(raw),
                     archive_sha256=digest(raw), selected_passed=2764, selected_skipped=9)))
