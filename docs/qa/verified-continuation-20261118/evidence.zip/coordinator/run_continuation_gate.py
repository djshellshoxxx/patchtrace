"""Seal the selected integration gate without resuming the blocked broad runner."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
SOURCE = '5bbb925694b89ddc77e2aae1ea36c9f563c7760d'
OUT = ROOT / 'qa/continuation-integration/combined-5bbb9256'


def git(*args: str) -> str:
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()


assert git('rev-parse', 'HEAD') == SOURCE and not git('status', '--porcelain')
scope_path = ROOT / 'qa/continuation-integration/combined-selected-nodes.json'
scope = json.loads(scope_path.read_text())
owned = Path(tempfile.mkdtemp(prefix='patchtrace-continuation-gate-'))
assert not any((p / '.git').exists() for p in (owned, *owned.parents))
assert not os.environ.get('PATCHTRACE_BINDIFF'), 'Real external BinDiff is outside this offline selection'
env = dict(os.environ, PYTHONPATH=':'.join(map(str, [REPO / 'src', REPO / 'tests', REPO, ROOT / 'ops'])),
           QT_QPA_PLATFORM='offscreen', QT_SCALE_FACTOR='1',
           GIT_ALLOW_PROTOCOL='file', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null',
           GIT_TERMINAL_PROMPT='0', PT_REVIEW_ROOT=str(REPO),
           PT_REVIEW_RECORD=str(OUT) + '-pin-interception.json',
           PATCHTRACE_OFFLINE_GUARD_RECEIPT=str(OUT) + '-offline-guard.json',
           PATCHTRACE_BATCH_COLLECTION_RECEIPT=str(OUT) + '-collection.json')
command = [sys.executable, str(ROOT / 'ops/continuation_offline_pytest.py'), '-q', '-ra',
           '-p', 'full_batch_receipt', *scope['node_files'], '--basetemp=' + str(owned / 'pytest'),
           '--junitxml=' + str(OUT) + '.xml']
for suffix in ('-command.json', '-exit.json', '-collection.json', '-offline-guard.json', '.xml', '.log'):
    assert not Path(str(OUT) + suffix).exists()
context = dict(source=SOURCE, tree=git('rev-parse', 'HEAD^{tree}'), argv=command, cwd=str(REPO),
               environment={k: env[k] for k in ('PYTHONPATH', 'QT_QPA_PLATFORM', 'QT_SCALE_FACTOR',
                                                'GIT_ALLOW_PROTOCOL', 'GIT_CONFIG_NOSYSTEM',
                                                'GIT_CONFIG_GLOBAL', 'GIT_TERMINAL_PROMPT',
                                                'PT_REVIEW_ROOT', 'PT_REVIEW_RECORD')},
               owned_system_temp=str(owned), started_utc=datetime.now(timezone.utc).isoformat(),
               scope_sha256=hashlib.sha256(scope_path.read_bytes()).hexdigest(),
               helper_sha256={p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                              for p in [Path(__file__), ROOT / 'ops/continuation_offline_pytest.py',
                                        ROOT / 'ops/full_batch_receipt.py']})
Path(str(OUT) + '-command.json').write_text(json.dumps(context, indent=2) + '\n')
started = time.monotonic()
try:
    with Path(str(OUT) + '.log').open('x') as stream:
        run = subprocess.run(command, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=600)
    code = run.returncode
except subprocess.TimeoutExpired:
    code = 124
collection_path = Path(str(OUT) + '-collection.json')
collection = json.loads(collection_path.read_text()) if collection_path.exists() else {}
foreign = [dict(module=n, path=r['path']) for n, r in collection.get('final_sources', {}).items()
           if not Path(r['path']).is_relative_to(REPO / 'src')]
drift = [r['path'] for r in collection.get('final_sources', {}).values()
         if hashlib.sha256(Path(r['path']).read_bytes()).hexdigest() != r['sha256']]
receipt = dict(exit=code, elapsed=time.monotonic() - started, source_after=git('rev-parse', 'HEAD'),
               status_after=git('status', '--porcelain'), foreign_imports=foreign,
               imported_source_drift=drift, imported_source_count=len(collection.get('final_sources', {})),
               owned_system_temp=str(owned), temp_retained=code != 0)
if code == 0:
    shutil.rmtree(owned)
Path(str(OUT) + '-exit.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
print('\n'.join(Path(str(OUT) + '.log').read_text().splitlines()[-45:]))
assert receipt['source_after'] == SOURCE and not receipt['status_after'] and not foreign and not drift
raise SystemExit(code)
