# Independent temporary-path classification

## Disposition

All **61 original failures in the 14 assigned modules passed** when replayed at
published PR316 source `55f3d0742f7d4cf32357a42b8b1cc76d85875e71`, tree
`11a0c1598764ebd3fd8d3b540377aa52e949f88a`. The complete bounded module scope
collected 479 cases: **478 passed, one existing psutil-absent skip, no failures or
errors**, in 8.93 seconds. No product source, test assertion, configuration file,
or path protection was edited. `RQ_ALLOWED_DIRS` was absent at entry and was not
expanded by the replay. Existing tests that deliberately change that variable
remain unchanged.

The original base directories were outside both the original worktree and
`/tmp`, and beneath `/workspace/.git`. Sixty failures are classified as test
harness placement violating default research-tool confinement; the rule-export
failure is the same placement triggering the existing Git-tree consent rule.
`classification.json` maps every original failing node ID to its passing replay.
For the 29 assertions that conceal stderr, this classification is explicitly
based on inspected early confinement checks, direct refusal of the original
base, and the passing unchanged test. Their original missing diagnostics have
not been invented or replaced.

The two other original failures are outside this scope: AF_UNIX creation remains
unavailable in this environment, and the missing dependency-spec registry entry
was a real baseline omission repaired separately by the root agent. This replay
does not claim a complete suite, native Windows qualification, an external-tool
pass, or resolution of other acceptance blockers. The original 99-batch runner
was not resumed; the uninjected backend-pin fetch test was never collected.

## Inspected execution boundary

The replay used a new detached worktree, `full-batch-path-review`, at the exact
published source and a private, newly created system temporary directory:
`/tmp/patchtrace-path-recheck-ncdor816/pytest-tmp`. Neither that base nor an ancestor
contains a Git marker. The old and new locations were checked directly with the
unchanged path guard and rule-export Git-tree predicate. The new worktree and
test grouping differ from the original runner; canonical source bytes match.

Before collection, `offline_replay.py` installed a process-local libseccomp filter
that returns `EPERM` for socket creation, connect, bind/listen/accept, datagram and
message send calls, and io_uring setup. `seccomp_load` returned zero, kernel mode
was 2, and `no_new_privileges` was confirmed. The filter is inherited by child
processes, including those whose production environment omits Python variables.
IPv4/IPv6 socket-creation probes returned `EPERM`; there were no inherited socket
descriptors. An outer filter was already active, so these denial observations do
not attribute an independent product isolation boundary to this helper.

The parent Python audit hook additionally rejected network/name-resolution
operations and uninspected process invocations. It recorded **132 permitted
launch attempts and zero denied events**:

| Inspected purpose | Attempts |
| --- | ---: |
| Trusted gcc identity queries | 37 |
| Exact authored C fixture compilation | 36 |
| nm reads of authored ELF symbols | 36 |
| Offline research CLI | 11 |
| Exact authored Python snippets | 9 |
| Authored missing-executable control | 1 |
| Offline KB plan preview | 1 |
| Rules worker reading synthetic bytes | 1 |

The compiler outputs and synthetic target bytes were never executed. Descendants
of the reviewed Python snippets and compiler are covered by the inherited kernel
filter; the parent audit log is not represented as a complete descendant exec
trace. This is a bounded execution safeguard for inspected fixtures, not a
general sandbox or arbitrary broker-mediated isolation claim. No host firewall,
global ACL, repository permission, or consent mechanism was changed.

`GIT_ALLOW_PROTOCOL=file`, disabled global/system Git configuration, and disabled
Git prompting were also set. No Git command was launched by a test in this scope.
QA preparation and source verification used only local read-only Git operations.

The implementation follows the primary libseccomp manuals for
[initialization](https://man7.org/linux/man-pages/man3/seccomp_init.3.html),
[rule addition](https://man7.org/linux/man-pages/man3/seccomp_rule_add.3.html), and
[loading](https://man7.org/linux/man-pages/man3/seccomp_load.3.html). It fails
before collection if the additional filter cannot be installed.

## Exact source and preserved evidence

Seventy-nine inspected test/caller/configuration files were compared byte for
byte with their canonical Git blobs before execution. After execution, all 168
loaded PatchTrace/research source files were compared to their canonical blobs;
there were no foreign source imports or changed inspected files. The tracked
worktree remains clean. Child CLI imports used this checkout's explicit source
path, not the shared virtual environment's older editable installation.

The 17 relevant original command/result/log/JUnit/classification files are
copied under `original/`, with original absolute paths and SHA-256 values in
`original-receipts.json`. Every retained original was compared again after the
replay and is byte-identical. No frozen receipt was edited.

Key files:

- `commands.json`: interpreter, environment overrides, exact replay arguments.
- `scope.json`: the 14 modules, 61 original failures, canonical inspected files.
- `run.log`, `run.xml`: raw replay output and JUnit.
- `run-receipt.json`: every collected test result, audited parent launch,
  installed-filter receipt, imported-source hashes, and final exit status.
- `source-and-path-proof-after.json`: canonical imports and direct old/new path
  admission evidence.
- `unclassified-original-text-analysis.json`: the unrecovered diagnostic limits
  for the 29 initially unclassified assertions.
- `classification.json`: complete per-case disposition and remaining limits.
- `offline_replay.py`, `classify.py`: the owned execution and evidence helpers.

The original failures and the existing skip remain evidence. This packet closes
only the assigned temporary-path classification; it grants no release credit.
