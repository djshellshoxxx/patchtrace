from pathlib import Path
from datetime import UTC, datetime
import hashlib
import json
import platform
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

root = Path('/workspace/scratch/c7a9e8d98848/cvrf-pilot')
qa = Path('/workspace/scratch/c7a9e8d98848/qa/cvrf-row-types')
original = Path('/workspace/scratch/c7a9e8d98848/qa/cvrf-independent')
source = '423a4fc00599cd085ac4a3b95db3e164071f4d79'
tree = 'ea6dbeaf67441c8ae2d7a2d7f08bcd603966e5c3'
python = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() == source
assert subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=root, text=True).strip() == tree
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=root, text=True) == ''

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

pairs = [('test_cvrf_row_types.py', 'independent-original-test.py'),
         ('storage-class-red.log', 'independent-original-red.log'),
         ('storage-class-red.xml', 'independent-original-red.xml')]
for origin, copy in pairs:
    assert digest(original / origin) == digest(qa / copy)
assert (qa / 'valid-before.json').read_bytes() == (qa / 'valid-after.json').read_bytes()
assert (qa / 'ruff.log').read_text().strip() == 'All checks passed!'
assert (qa / 'diff-check.log').read_bytes() == b''

def results(name):
    cases = ET.parse(qa / name).findall('.//testcase')
    return {'tests': len(cases), 'failed': sum(c.find('failure') is not None for c in cases),
            'errors': sum(c.find('error') is not None for c in cases),
            'skipped': sum(c.find('skipped') is not None for c in cases)}

outcomes = {name: results(name) for name in ('independent-original-red.xml', 'red.xml', 'focused.xml', 'affected.xml')}
assert outcomes['independent-original-red.xml'] == {'tests': 3, 'failed': 3, 'errors': 0, 'skipped': 0}
assert outcomes['red.xml'] == {'tests': 25, 'failed': 24, 'errors': 0, 'skipped': 0}
assert outcomes['focused.xml'] == {'tests': 25, 'failed': 0, 'errors': 0, 'skipped': 0}
assert outcomes['affected.xml'] == {'tests': 1558, 'failed': 0, 'errors': 0, 'skipped': 0}

sys.path.insert(0, str(root / 'src'))
from patchtrace.pilot.sources import kb_context
assert Path(kb_context.__file__).resolve() == root / 'src/patchtrace/pilot/sources/kb_context.py'
selection = [str(path.relative_to(root)) for path in sorted((root / 'tests').glob('test_pilot*.py'))]
selection += ['tests/test_kbc_card_field_provenance.py', 'tests/test_source_lineage_counts_once.py',
              'tests/test_ui_leads.py', 'tests/test_intel_explain.py', 'tests/test_intel_cli.py',
              'tests/test_fabric_adopt.py', str(original / 'test_cvrf_row_types.py')]
paths = ['src/patchtrace/pilot/sources/kb_context.py', 'tests/test_pilot_kb_storage_classes.py',
         'tests/test_pilot_kb_context.py', 'docs/specs/program-e/pilot-retained-cvrf-context.md']
provenance = {
    'recorded_at_utc': datetime.now(UTC).isoformat(),
    'source_commit': source, 'source_tree': tree,
    'parent_before_review_repair': '7cc6a0392c9af5844f226deadcf20ff16f4dc96c',
    'spec_red_commit': 'e1b161fdd1dd64a09379f9ca98bfdec4cc1ca428',
    'original_bridge_source': '353902677e6d59961e808a90b2a3dd96d2b43269',
    'source_import': kb_context.__file__, 'python': sys.version,
    'platform': platform.platform(), 'worktree': str(root),
    'source_files': [{'path': path, 'sha256': digest(root / path)} for path in paths],
    'original_evidence': [{'path': str(original / origin), 'copy': copy, 'sha256': digest(qa / copy)}
                          for origin, copy in pairs],
    'outcomes': outcomes,
    'qualification': {
        'cwd': str(root),
        'env': {'QT_QPA_PLATFORM': 'offscreen', 'PYTHONPATH': f'{root / "src"}:{root / "tests"}'},
        'argv': [python, '-m', 'pytest', '-q', *selection, f'--junitxml={qa / "affected.xml"}', '--tb=short'],
        'stdout_stderr': 'affected.log', 'exit_code': 0},
    'compatibility': {'before_source': '353902677e6d59961e808a90b2a3dd96d2b43269',
                      'after_source': source, 'same_serialized_snapshot': True,
                      'before_json_sha256': digest(qa / 'valid-before.json'),
                      'after_json_sha256': digest(qa / 'valid-after.json'),
                      'context_digest': json.loads((qa / 'valid-after.json').read_text())['digest']},
    'scope': ['kb_context.py only production edit; no shared schema/reader/current_inputs changes',
              'Twenty-two new local controls and three unchanged root probes; focused checks overlap the affected suite',
              'Original BLOB errors plus actual SQL NULL, integer and real neighbors; malformed selected rows withhold all CVRF',
              'Synthetic authored local stores; no network, target/native engine, manual desktop or native Windows acceptance',
              'Combined freshness-hook review and full/platform qualification remain separate root-owned gates']
}
(qa / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
packet = root / 'docs/qa/pilot-cvrf-storage-classes-20261118'
packet.mkdir(parents=True)
files = sorted(path for path in qa.iterdir() if path.is_file())
archive = packet / 'raw-evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for path in files:
        bundle.write(path, path.name)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for path in files:
        assert hashlib.sha256(bundle.read(path.name)).hexdigest() == digest(path)
manifest = {'source_commit': source, 'source_tree': tree,
            'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': digest(archive)},
            'members': [{'path': path.name, 'bytes': path.stat().st_size, 'sha256': digest(path)} for path in files]}
(packet / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'archive': manifest['archive'], 'members': len(files), 'outcomes': outcomes}, indent=2))
