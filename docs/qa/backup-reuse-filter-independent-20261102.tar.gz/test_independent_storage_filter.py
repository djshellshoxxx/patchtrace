"""Reviewer-only SQLite controls; this file is outside the candidate source tree."""
from pathlib import Path
import sqlite3

import pytest

from patchtrace import persistence, verified_backup as V
from patchtrace.service import ProjectService


@pytest.fixture
def service(tmp_path):
    V.forget_all()
    with ProjectService.sample(tmp_path / 'project') as result:
        yield result
    V.forget_all()


@pytest.mark.parametrize('replacement', ['failed', 'project', 'snapshot', 'tables'])
def test_cache_replacement_between_prefilter_and_final_check_is_refused(service, monkeypatch, replacement):
    backup = V.write_verified_backup(service.root, service.store.connection, 'history-prune')
    before = V._VERIFIED[str(backup)][1]
    assert before is not None
    original_cached = V._cached
    observed = []

    def replace_then_check(path):
        assert Path(path) == backup
        if replacement == 'failed':
            backup.write_bytes(b'not SQLite')
        else:
            with sqlite3.connect(backup) as db:
                if replacement == 'project':
                    db.execute("UPDATE current_snapshot SET payload=json_set(payload, '$.id', 'other-project')")
                elif replacement == 'snapshot':
                    db.execute("UPDATE current_snapshot SET sha256=?", ('0' * 64,))
                else:
                    db.execute('DROP TABLE history')
        checked = V._fingerprint(backup)
        problem, facts = V._verify(backup, 'quick_check')
        assert V._remember(backup, facts if problem is None else None, checked)
        verdict = original_cached(path)
        observed.append(verdict)
        return verdict

    monkeypatch.setattr(V, '_cached', replace_then_check)
    assert V.trusted_backup(service.root, 'history-prune', project_id=before.project_id,
                            snapshot_sha=before.snapshot_sha, require_tables=('history',)) is None
    assert len(observed) == 1 and observed[0][0] is True
    assert not V._acceptable(observed[0][1], before.project_id, before.snapshot_sha, ('history',))
    assert backup.exists(), 'raced evidence must remain present'


def test_cache_forgetting_between_prefilter_and_final_check_is_refused(service, monkeypatch):
    backup = V.write_verified_backup(service.root, service.store.connection, 'history-prune')
    original_bytes = backup.read_bytes()
    original_cached = V._cached

    def forget_then_check(path):
        V.forget_all()
        return original_cached(path)

    monkeypatch.setattr(V, '_cached', forget_then_check)
    assert V.trusted_backup(service.root, 'history-prune', project_id=service.project.id) is None
    assert backup.read_bytes() == original_bytes


def test_ineligible_newer_candidate_does_not_hide_good_older_backup(service, tmp_path, monkeypatch):
    good = V.write_verified_backup(service.root, service.store.connection, 'history-prune')
    with ProjectService.sample(tmp_path / 'foreign') as foreign:
        wrong = V.write_verified_backup(service.root, foreign.store.connection, 'history-prune')
    saved_bytes = {path: path.read_bytes() for path in (good, wrong)}
    reads = []
    original = V._fingerprint

    def observed(path):
        reads.append(Path(path))
        return original(path)

    monkeypatch.setattr(V, '_fingerprint', observed)
    assert V.trusted_backup(service.root, 'history-prune', project_id=service.project.id,
                            require_tables=('history',)) == good
    assert reads == [good]
    assert all(path.read_bytes() == data for path, data in saved_bytes.items())


def test_public_save_keeps_rows_and_foreign_backup_if_replacement_cannot_verify(service, tmp_path, monkeypatch):
    with ProjectService.sample(tmp_path / 'foreign') as foreign:
        wrong = V.write_verified_backup(service.root, foreign.store.connection, 'history-prune')
    original_bytes = wrong.read_bytes()
    prior = {row[0] for row in service.store.connection.execute('SELECT sequence FROM history')}
    monkeypatch.setattr(persistence, 'HISTORY_KEEP', 1)
    monkeypatch.setattr(V, '_after_copy', lambda path: path.write_bytes(b'broken replacement'))
    candidate = service.project.model_copy(deep=True)
    candidate.name = 'save survives refused pruning'
    service.project = service.store.save(candidate)
    after = {row[0] for row in service.store.connection.execute('SELECT sequence FROM history')}
    assert prior < after
    assert service.store.load().name == candidate.name
    assert wrong.read_bytes() == original_bytes
    assert list((service.root / 'backups').glob('*.sqlite3')) == [wrong]
    assert not list((service.root / 'backups').glob('*.part'))
