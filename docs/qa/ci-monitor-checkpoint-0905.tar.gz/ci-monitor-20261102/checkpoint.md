# Published repair gates — 2026-11-02, initial checkpoint

Read-only audit; no remote writes. Initial full metadata, checks, statuses,
reviews, threads, discussion comments and workflow child steps are retained in
`checkpoint-initial.json.gz`. Each collection was followed through an empty
second page. A completed parent or review check does not by itself qualify a
candidate. These are live snapshots, not final results.

| PR | Exact head | Exact tree | QA run | Initial observed state |
|---|---|---|---|---|
| #151 | `7d9dce5c228235cecb7a08f3b55895addeb05b86` | `0113a2b637f14917d776d23ad614bbf2a1eade2b` | `41410800144` | Full Linux/Windows and all Qt legs running; both native five-variant runs passed actual applicable steps; Sonar passed |
| #153 | `3bd48a710dcec1b471944f439a79b0fc8655921d` | `14e793eaa1bb4dc74b508169209688b1e5a37633` | `41410831882` | Full Linux/Windows running; Qt/native partial; Sonar passed; fresh substantive review findings |
| #157 | `56b2488f353e3497e1ffe952e67e0d7b6c05e282` | `b74ff17800a46fa86c20019101f0cf7ce0b32717` | `41411310166` | QA and corpus/native mostly queued; Sonar failed |

At 08:22 UTC, all three CodeRabbit check contexts were success. Their inline
comments remain separately applicable. #153 push-native run `41410826219` had
all five children passed; PR-native `41410831778` still had two running.
#157 corpus run is `41411310022`; native push run is `41411302769`.
#151 native PR/push runs are `41410799927` / `41410795509`; actual offline-analysis,
byte-identical raw-cache and plain-Ghidriff cached-PDB reproduction steps each
ran in their applicable variants. These scope-local results do not override
pending QA/package gates or unrelated live Rizin quarantine.

## Current review findings

- #153 comment [4440130537](https://github.com/djshellshoxxx/patchtrace/pull/153#discussion_r4440130537)
  describes insertion-order-dependent `CveCard` metadata when unknown revision
  order keeps multiple snapshots active. Comment
  [4440130544](https://github.com/djshellshoxxx/patchtrace/pull/153#discussion_r4440130544)
  describes silently omitted Type 2 rows when `Description` is absent. These
  fresh current-head findings were sent to the source owner for reproduction.
- Qodo's separate #153 claim that namespace discovery raises `ValueError` is
  contradicted by the exact expression and a synthetic XML probe.
  `ET.iterparse(..., events=('start-ns',))` yields `(event, (prefix, URI))`, so
  `dict(value for _, value in ...)` is correct. `namespace-review-control.py`
  passes. This control does not prove the full archived script is portable or
  revalidate its captures; absolute scratch-path concerns remain separate.
- #151 new comment [4440141036](https://github.com/djshellshoxxx/patchtrace/pull/151#discussion_r4440141036)
  concerns stale spec wording “after rename” where implementation uses hard-link
  publication. A Qodo low-severity performance note concerns hashing cached
  candidates whose facts are already unacceptable, while a write transaction
  is open. Neither establishes a new integrity failure.
- #157 retains credit-manifest cap, long-field contract and owner-only file
  mode comments. Source owners are investigating; no blind cap/schema widening
  or permission change is justified here.
- #157 exact-head Sonar check `125165119104` repeats issue
  `AaGXhfrn5xr-Pq-Fbk3s` at `output_store.py:95`, generic CLI path traversal.
  Its one annotation and empty next page are retained; `raw_details` is null.
  No disposition or suppression has been applied.

No candidate in this initial checkpoint is merge-qualified. Final exact-head
child logs, package bytes, reviews and tree binding must supersede this snapshot.

Read-only unauthenticated Sonar issue-detail API requests for the output reader,
prereg QA path and fence regex returned HTTP 403. No access bypass or scanner
mutation was attempted. The missing detailed traces remain an evidence limit.

08:26 UTC delta: both #153 native five-variant workflows now have all children
passed. Its Linux/Windows full jobs and two Linux Qt shards remain running;
three Qt legs remain queued. #151 full/Qt jobs remain running. #157 corpus
shard 0 started, while QA remains queued and its Sonar failure persists.

GitHub's synthetic merge candidates were independently fetched. All have base
`25c9795bd9cd58bfad855f30594ee3a0c7584cec` and a tree exactly equal to the
corresponding head above: #151 merge `38d19e65004d6e22f92e4bbda6e0d0be1ac454f7`,
#153 merge `cfc5c53baebbf9b1dc2d92a7929414472d60a446`, #157 merge
`17ce810137cc23b48b7623d8d8eb140b73592499`. Final logs must confirm the actual
checked-out commit; any later base/head update requires fresh reconciliation.

Completed native clean-job logs `125163161181` (#151) and `125163263827` (#153)
confirm checkout of the exact synthetic merge commits above. Original logs are
retained. This confirms those jobs' source tree; pending QA/package jobs remain
independently unqualified.

## Combined draft checkpoint #152

New published head `51a9b4af02acb6078f8e06028aa4374eb381766f` was independently
verified against tree `47e5221f4209d2a2ce3846a37171aa22f35a13e7`. It remains an
open draft. Synthetic merge `388f5b250bef6e0e352c965f588f3da2814c616c` onto main
`25c9795bd9cd58bfad855f30594ee3a0c7584cec` has the identical tree. This draft is
not a merge candidate. The coordinator reports a separate immutable local full
run started at 08:29:49 UTC; this reviewer has not duplicated or claimed its result.

Hosted runs: QA `41413769950`, Corpus `41413769468`, live Rizin `41413769491`,
live unified `41413769503`, native PR `41413769508`, native push `41413761907`,
wheels `41413769540`. Initial required jobs are mostly queued. CodeRabbit is
skipped because the PR is a draft. Sonar `125173047261` failed with 10
annotations. Initial metadata, all job collections and empty second pages are
retained in `combined152-initial.json.gz`.

The 10 exact-head Sonar annotations contain no new detailed flow. Relative to
old combined head `039c696`, the two variable tuple-length findings disappeared
and a generic path-traversal title for `output_store.publish_bytes()` at line
260 appeared. All other path/title families match the earlier snapshot;
`raw_details` is null throughout. Annotations and an empty second page are
retained in `annotations-125173047261.json`. No new vulnerability is inferred.

## 08:38 UTC progress

All expected remote heads remain unchanged. #151 Linux Qt shard 3/4 job
`125163162394` passed **9,640 repeated checks** in 1257.45 s; its remaining full
and Qt jobs are running. All #153 full and Qt jobs are running. #157 native
run has all five applicable variants passed; corpus shards each have six cases
and no blocked/failed cases. Its merge reports `failing_cases: 0`,
`merge_sha256: 6237ee18b4d66356276e8007e62f9b97ed29f3d9f7b82312103601efba2fe587`
and `report_sha256: 97f2b2be48ec7f67495184d5f96b394596b34e7b351a880eaeb604d3e558c8c5`.
Original shard and merge logs are retained. These independent-slice results do
not lift #152's Rizin orientation quarantine or represent a final evaluation.
#157 Windows QA/Qt and one Linux Qt shard are running; remaining Linux QA/Qt
are queued. #152 full hosted QA/Qt jobs remain queued. No new completed QA
failure was observed; no new package or merge qualification is claimed.

## 08:44 UTC progress and superseded #153

#151 head `7d9dce5` Linux full job `125163162196` passed **18,478 tests,
47 skipped, 7 xfailed** in 1768.21 s. Three Linux Qt shards have passed:
3/4 **9,640**, 2/4 **8,700**, 4/4 **9,060** repeated checks. Windows full/Qt
and Linux Qt shard 1/4 remain incomplete. The coordinator is reviewing a separate
cache-facts performance repair; none of these results can qualify its future head.

#152 `51a9b4af` live Rizin jobs `125172581826` (Windows) and `125172581578`
(Linux) completed blocked with `rz-diff-orientation-unverified`, and corpus
shard 1 job `125175053199` has six cases, `failed: []`,
`blocked: [evaluate:rz-diff]`. Original logs are retained. These are the intended
orientation quarantine, not a new synthetic-fixture failure. Linux full QA has
started; its result remains pending.

#153 old head `3bd48a7` was superseded and its remaining QA/package jobs were
cancelled. Linux Qt shard 2/4 had passed **8,700 repeated checks** in 1569.94 s;
neither full suite had completed. New published head
`9ae5731cadebd691a1aedc5b5727c3af3fcd58a0` is verified at tree
`295f92680ad8987c33abd79bd6878dd26ed13cf0`. Its synthetic merge
`8df156c1e7c921c6c6ea482975925e3e7201458c` onto main `25c9795` has the same tree.
New QA run `41414624226`, native PR `41414624009` and native push `41414617689`
are queued/running. Sonar passed with zero annotations; CodeRabbit is pending.
Old-head results are retained as historical evidence only.

The prereg source bytes at combined head `51a9b4af` exactly match audited
#154 `f27d23a` (SHA-256 `30e1f275dfe1f731b8e65aeed0939fc46e0971ce1b7f5e1008563ca3e918d992`).
The complete `output_store.py` bytes at combined `51a9b4af` and independent
#157 `56b2488` also match (SHA-256
`84681fd6a27dcba8caafbc2ffa638b767776a7ff64e937a5b57ecfd3cd2e2c00`).
The differing opaque Sonar annotation sets do not by themselves establish or
disprove an authority-boundary defect; a detailed flow is still unavailable.

## Superseded run cancellation and new repair heads

The coordinator published reviewed #151
`9c468bc75077484c1780305d7cc927b30fd0bc8b`, tree
`7841c1bea17657c0085015c429520d12a01c823b`, synthetic merge
`b5fcd431a66f5841e13fbcc2d22483443f59736d` with the same tree. New QA
`41416413045`, native PR `41416412926` and native push `41416407478` are
queued/running. Sonar passed with zero annotations. This supersedes `7d9dce5`.

The old #151 Windows QA log reached a normal-looking summary of **18,445
passed, 81 skipped, 6 xfailed** in 2703.27 s, then cancellation four seconds
later. GitHub marks the pytest step **cancelled**; Ruff/build/portable/installer
steps are skipped. It is recorded as a cancelled gate, not a passing full
workflow or package. All old-head Qt legs completed successfully: Windows
**9,375**, Linux shards **10,100 / 8,700 / 9,640 / 9,060** repeated checks.
Old #153 and #157 Windows logs contain explicit `KeyboardInterrupt` and partial
summaries of **15,063** and **6,164** passes; these are not full-suite results.
Original cancelled logs are retained, including Linux partial logs without a
completed summary.

The coordinator also published reviewed #157
`bb98bae3cf0a3b6a38a298a14186d7f4e1c9c151`, tree
`ba2e53eae575956b60a4adcea7decfb85b065d3d`, same-tree synthetic merge
`935ce127dd2c562ea53fa709d0368d853324d348`. New QA `41415934308` and Corpus
`41415934313` are queued/running. The native workflow does not trigger on this
head's changed paths: all 34 PR files are docs/schemas/tests or
`tools/calibration`, outside the exact workflow's `src/**`, `tests/fixtures/**`
and named native-script/workflow filters. No new native result is claimed.
Earlier `56b2488` native/corpus results remain historical.

#152 `51a9b4af` has both native five-variant workflows passed, including actual
applicable target steps. All full QA/Qt jobs are now running. Its corpus merge
reports two blocked shard cases, not evaluator failures, under the deliberate
Rizin orientation quarantine. The separate immutable local full run remains
bound to coordinator source `4a82fd3`; later combined work is not qualified by
that still-pending run.

Fresh #153 `9ae5731` review findings were forwarded without treating them as
proven defects: [4440348624](https://github.com/djshellshoxxx/patchtrace/pull/153#discussion_r4440348624)
questions whether card-only conflicting snapshots contribute to context identity
and saved sources; [4440384161](https://github.com/djshellshoxxx/patchtrace/pull/153#discussion_r4440384161)
questions field-specific Description/ProductID diagnostic pointers. A green
review check does not resolve these source findings. This monitor made no code
change or comment/thread disposition.
