# Read-only CI checkpoint — 2026-11-02T09:05:50.856Z

Latest metadata was fetched at 2026-11-02T09:02:07.244Z. All four live heads
match the coordinator's requested publications. Main remains `25c9795bd9cd58bfad855f30594ee3a0c7584cec`.
Each fetched synthetic merge tree equals its published head tree. No PR was merged,
approved, changed, resolved, dispatched or closed by this reviewer.

| PR | Head | Tree | Current applicable gates |
|---|---|---|---|
| #151 | `9c468bc75077484c1780305d7cc927b30fd0bc8b` | `7841c1bea17657c0085015c429520d12a01c823b` | Sonar passed (0 annotations); CodeRabbit pending; full suites/native queued; one Qt shard running, other Qt queued |
| #152 draft | `51a9b4af02acb6078f8e06028aa4374eb381766f` | `47e5221f4209d2a2ce3846a37171aa22f35a13e7` | Full suites/all Qt running; both five-variant native workflows passed actual applicable steps; live-unified Windows passed, Linux queued; wheels passed; Rizin/corpus blocked by orientation quarantine; Sonar failed (10 annotations); CodeRabbit skipped because draft |
| #153 | `9ae5731cadebd691a1aedc5b5727c3af3fcd58a0` | `295f92680ad8987c33abd79bd6878dd26ed13cf0` | Sonar and CodeRabbit checks passed; both five-variant native workflows passed; full suites/most Qt running, one Linux Qt shard queued; substantive context-source finding and diagnostic-pointer finding still need disposition |
| #157 | `bb98bae3cf0a3b6a38a298a14186d7f4e1c9c151` | `ba2e53eae575956b60a4adcea7decfb85b065d3d` | Full suites/most Qt running, one Linux Qt shard queued; both corpus shards passed, merge queued; CodeRabbit passed; exact-head Sonar has not posted; native workflow does not apply to this PR's changed paths |

Snyk's latest status is success on all four heads. All workflow and check job collections,
reviews/comments/statuses were fetched through an empty second page. Full records and child
step conclusions are in `current-0905.json.gz`. A queued parent can contain running
children, so the table uses child states. No current head has complete package/installer
qualification; no release is claimed. The draft #152 is not a merge candidate.

## Current run IDs

| PR | QA | Other runs |
|---|---|---|
| #151 | `41416413045` | native PR `41416412926`, native push `41416407478` |
| #152 | `41413769950` | corpus `41413769468`, live Rizin `41413769491`, live unified `41413769503`, native PR `41413769508`, native push `41413761907`, wheels `41413769540` |
| #153 | `41414624226` | native PR `41414624009`, native push `41414617689` |
| #157 | `41415934308` | corpus `41415934313` |

## Original failures and cancellations retained

- Current #152 live Rizin jobs `125172581826` / `125172581578`: explicit
  `rz-diff-orientation-unverified` block on Windows/Linux. Corpus jobs
  `125175053161` / `125175053199`: six cases per shard, no evaluator failures,
  `blocked: [evaluate:rz-diff]`; merge `125177420190` reports two blocked shard
  cases. All five original logs are retained. No quarantine was weakened.
- Superseded #151 `7d9dce5`: Linux full passed 18,478 / 47 skipped / 7 xfailed.
  All Qt legs passed (Windows 9,375; Linux 10,100 / 8,700 / 9,640 / 9,060 repeated checks).
  Windows printed 18,445 passed / 81 skipped / 6 xfailed, then was cancelled;
  GitHub marks pytest cancelled and packaging skipped. The cancelled gate is
  not called passed, nor used to qualify newer `9c468bc`.
- Superseded #153 `3bd48a7` and #157 `56b2488`: cancelled full jobs are retained.
  Their Windows 15,063 / 6,164 pass summaries follow explicit KeyboardInterrupts
  and are partial, not full-suite results.
- Earlier original hard failures and verified #156 package hashes remain in the
  already retained `ci-resume-evidence-20261102.tar.gz`, SHA-256
  `41d489272486ce4ea2dbc23db54983175a825c1dadc3089bdef83d15e8a0fcab`.
  Those unchanged logs/package binaries are not duplicated here.

## Review and scope limits

#151's cache-facts performance note is now marked resolved by Qodo; its hard-link
wording thread is resolved. Current CodeRabbit review is pending. #153's card-consensus
context/source finding `4440348624` and field-specific diagnostic finding `4440384161`
were forwarded for source reproduction; a green check does not resolve them. The
namespace-script crash claim was disproved with a retained synthetic XML control.
#157's credit-manifest and order-key threads are now resolved; current CodeRabbit
only adds a minor documentation-spacing note. Qodo still lists long-name and
0600-mode contract concerns; their disposition must remain contract-aware.

The new #157 head has no Sonar result yet: the older head's failed analysis is historical,
not a new-head success or failure. No suppression was applied. Detailed Sonar issue
API reads returned HTTP 403; opaque GitHub annotations do not establish a full flow.
Its native path filter was checked against all 34 PR files, none of which touch
`src/**`, `tests/fixtures/**` or the named native scripts/workflow.

The separate local full run is bound only to coordinator source `4a82fd3` / published
draft `51a9b4af`. It is not run or duplicated by this reviewer and cannot qualify later
central changes. No actual corpus final evaluation, manual Windows acceptance,
target execution or overall completion is established here.
