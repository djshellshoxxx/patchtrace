"""Check the exact namespace expression questioned on PR #153, with synthetic XML."""
import io
import json
import xml.etree.ElementTree as ET

raw = b'<cvrf:doc xmlns:cvrf="urn:test:cvrf" xmlns:vuln="urn:test:vuln"><vuln:item/></cvrf:doc>'
events = list(ET.iterparse(io.BytesIO(raw), events=('start-ns',)))
namespaces = dict(value for _, value in events)
assert namespaces == {'cvrf': 'urn:test:cvrf', 'vuln': 'urn:test:vuln'}
print(json.dumps({'events': events, 'exact_expression_result': namespaces,
                  'review_claim_reproduced': False}))
