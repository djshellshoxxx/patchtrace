# Hosted Linux completion after the 09:05 checkpoint

This supplements the immutable `ci-monitor-checkpoint-0905.tar.gz`; it does not
alter that snapshot or qualify later source changes.

For draft #152 exact head `51a9b4af02acb6078f8e06028aa4374eb381766f`, Linux full
QA job `125172582878` succeeded at 09:07:37 UTC: **19,314 passed, 49 skipped,
7 xfailed**, 19 warnings, 1660.87 s. The original log confirms checkout of
synthetic merge `388f5b250bef6e0e352c965f588f3da2814c616c`, whose tree
`47e5221f4209d2a2ce3846a37171aa22f35a13e7` equals the published head.

Original `qa-Linux` Actions artifact `13128073325` was downloaded once. Its
331,131-byte ZIP SHA-256 matches GitHub's digest:
`adc38a52394195d7dd34f9e403dd54724b9405eda001f35c27d8bd7419bc57be`.
The original JUnit XML is retained compressed; XML SHA-256:
`2a4e48805c0ab5b0d8224d58fb1aa91796616f453d0b8cd24f8f7859c6680343`.
It records **19,370 cases, 0 failures, 0 errors, 56 skipped** (including xfails).
The exact `tests.test_network_consent_guard::test_a_local_unix_socket_is_not_network`
case is present and **passed**, 0.001 s, with no skip/failure/error child.
This corroborates the coordinator's local host-EPERM control without changing,
skipping or weakening the test. Local and hosted counts remain distinct records.

For #157 exact head `bb98bae3cf0a3b6a38a298a14186d7f4e1c9c151`, corpus merge
job `125182383283` succeeded at 09:08 UTC with two shards and zero failing cases.
Merge SHA `6237ee18b4d66356276e8007e62f9b97ed29f3d9f7b82312103601efba2fe587`;
report SHA `97f2b2be48ec7f67495184d5f96b394596b34e7b351a880eaeb604d3e558c8c5`.
This scope-local result does not lift the combined candidate's Rizin quarantine.

#151 current `9c468bc` CodeRabbit check has also completed successfully. No new
current-head Windows full/Qt/package completion or overall merge qualification
is established by this delta. The larger snapshot retains review/source gates.
