"""Author-only public sharding controls, with all native work replaced by a fake.

Run against frozen current source. No compiler, engine, target or network call.
"""
import importlib.util
import json
from pathlib import Path

import pytest

from tools.calibration.tier_r import shard

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location(
    "original_card_fixtures", HERE / "historical/cards/tests/test_tier_r_shard.py"
)
helpers = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helpers)


@pytest.mark.parametrize(("changed", "returncode"), [(True, 0), (True, 1), (False, 0)])
def test_public_suite_aa_failure_survives_shard_and_merge(tmp_path, changed, returncode):
    source = helpers.write_tree(tmp_path)
    plan = shard.make_plan(source, seed=4, shards=1, subset="suites")

    def runner(argv, timeout, env):
        if argv[3] == "aa":
            return returncode, json.dumps({
                "command": "aa", "status": "findings" if changed else "ok",
                "written": [], "not_byte_identical": ["authored-aa-rebuild"] if changed else [],
            }), None
        return helpers.fake_runner(argv, timeout, env)

    doc = shard.run_shard(plan, 0, runner=runner)
    saved = shard.write_shard(doc, tmp_path / "out")
    persisted = json.loads(saved.read_text())
    aggregate, provenance = shard.merge([persisted])
    cases = [case for case in persisted["cases"] if case["id"].startswith("aa:")]
    assert cases, "the current supported authored-suite grammar must reach A/A"
    output = HERE / "aa-shard-public"
    output.mkdir(exist_ok=True)
    (output / f"changed-{changed}-rc-{returncode}.json").write_text(json.dumps({
        "plan": plan, "persisted_shard": persisted, "aggregate": aggregate,
        "provenance": provenance,
    }, indent=2) + "\n")
    if changed:
        assert all(case["status"] == "failed" for case in cases)
        assert {case["id"] for case in cases} <= set(provenance["failing_cases"])
    else:
        assert all(case["status"] == "ok" for case in cases)
        assert not ({case["id"] for case in cases} & set(provenance["failing_cases"]))
