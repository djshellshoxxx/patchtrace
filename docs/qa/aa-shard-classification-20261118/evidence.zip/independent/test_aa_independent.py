"""Independent authored boundary controls; no compiler, target, engine or network."""
from __future__ import annotations

import json
from types import SimpleNamespace

import pytest
from test_tier_r_shard import fake_runner, write_tree
from tools.calibration.tier_r import cli, shard


def test_real_aa_command_summary_reaches_shard_failure(tmp_path, monkeypatch):
    plan = shard.make_plan(write_tree(tmp_path), seed=81, shards=1, subset='suites')
    documents = [
        {'pair_id': 'different-rebuild', 'reproducibility': {'byte_identical': False}},
        {'pair_id': 'identical-rebuild', 'reproducibility': {'byte_identical': True}},
        {'pair_id': 'layout-control'},
    ]
    monkeypatch.setattr(cli, '_session', lambda args: SimpleNamespace(store=tmp_path))
    monkeypatch.setattr(cli, '_base', lambda args, session: object())
    monkeypatch.setattr(cli.F, 'run_aa', lambda *args, **kwargs: documents)
    written = []
    monkeypatch.setattr(cli, '_write_pairs', lambda store, docs: written.extend(docs) or [])
    observed = []

    def runner(argv, timeout, env):
        if argv[3] != 'aa':
            return fake_runner(argv, timeout, env)
        rc, result = cli.cmd_aa(SimpleNamespace(opt='O2', no_layout=False))
        assert rc == cli.FINDINGS and result['not_byte_identical'] == ['different-rebuild']
        observed.append(result)
        return rc, json.dumps(result), None

    result = shard.run_shard(plan, 0, runner=runner)
    shard.write_shard(result, tmp_path / 'out')
    restored = shard.load_shards(tmp_path / 'out', plan=plan)
    _, merged = shard.merge(restored)
    expected = {row['id'] for row in result['cases'] if row['id'].startswith('aa:')}
    assert observed and len(written) == len(observed) * 3
    assert expected and expected <= set(merged['failing_cases'])
    assert all(row['status'] == 'failed' for row in merged['cases'] if row['id'] in expected)


def test_long_difference_ids_do_not_expand_reason(tmp_path):
    plan = shard.make_plan(write_tree(tmp_path), seed=82, shards=1, subset='suites')
    identity = 'opaque-difference-' + 'q' * 1900

    def runner(argv, timeout, env):
        if argv[3] != 'aa':
            return fake_runner(argv, timeout, env)
        return 1, json.dumps({'command': 'aa', 'not_byte_identical': [identity]}), None

    result = shard.run_shard(plan, 0, runner=runner)
    rows = [row for row in result['cases'] if row['id'].startswith('aa:')]
    assert rows
    assert all(row['status'] == 'failed' for row in rows)
    assert {row['reason'] for row in rows} == {'exit 1: A/A rebuild is not byte-identical'}
    assert all(len(row['reason']) <= shard.REASON_CHARS and identity not in row['reason'] for row in rows)


def test_generic_findings_status_is_stable_across_reload(tmp_path):
    plan = shard.make_plan(write_tree(tmp_path), seed=83, shards=1, subset='suites')

    def runner(argv, timeout, env):
        if argv[3] != 'aa':
            return fake_runner(argv, timeout, env)
        return 1, json.dumps({'command': 'aa', 'not_byte_identical': []}), None

    result = shard.run_shard(plan, 0, runner=runner)
    rows = [row for row in result['cases'] if row['id'].startswith('aa:')]
    assert rows and all(row['status'] == 'findings' for row in rows)
    shard.write_shard(result, tmp_path / 'out')
    restored = shard.load_shards(tmp_path / 'out', plan=plan)
    _, merged = shard.merge(restored)
    aa_ids = {row['id'] for row in rows}
    assert aa_ids.isdisjoint(merged['failing_cases'])
    assert all(row['status'] == 'findings' for row in merged['cases'] if row['id'] in aa_ids)


def test_existing_summary_budget_still_refuses_overlong_difference(tmp_path):
    plan = shard.make_plan(write_tree(tmp_path), seed=84, shards=1, subset='suites')

    def runner(argv, timeout, env):
        if argv[3] != 'aa':
            return fake_runner(argv, timeout, env)
        return 1, json.dumps({'command': 'aa', 'not_byte_identical': ['q' * 2001]}), None

    with pytest.raises(shard.ShardError, match='result string too long'):
        shard.run_shard(plan, 0, runner=runner)
