"""Seal the independently reviewed A/A reporting repair without changing receipts."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/c7a9e8d98848')
REPO = ROOT / 'kb-selftest'
BASE = '740869debb111f8edbef33899316e4c75e6fdf7a'
SPEC = 'a2d3011ebb47bb6e5566e70106ff0b47fde624f6'
SOURCE = '9bd17bbecb54f5a3de05d235a1617a3d2f196883'
PEER_SHA = '4d5f1d9a1e513d4385c5548a61cc96a754decd34ad00ad53cd00f547b229f6e6'
INDEPENDENT_SHA = '4a49ec5c7e12791f6618aeff74511233b6993a6a6273b4e4e0608e4452890238'
AUTHOR = ROOT / 'qa/aa-shard-classification'
INDEPENDENT = ROOT / 'qa/aa-shard-independent'
OUT = REPO / 'docs/qa/aa-shard-classification-20261118'


def git(*args: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def junit(path: Path) -> dict[str, int]:
    cases = ET.parse(path).findall('.//testcase')
    counts = {'passed': 0, 'failed': 0, 'errors': 0, 'skipped': 0}
    for case in cases:
        key = ('failed' if case.find('failure') is not None else
               'errors' if case.find('error') is not None else
               'skipped' if case.find('skipped') is not None else 'passed')
        counts[key] += 1
    return counts


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('status', '--porcelain').strip()
assert not OUT.exists()
archive = ROOT / 'qa/aa-shard-independent.zip'
assert digest(archive.read_bytes()) == INDEPENDENT_SHA
manifest = json.loads((INDEPENDENT / 'manifest.json').read_text())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == set(manifest) | {'manifest.json'}
    for name, row in manifest.items():
        data = z.read(name)
        assert len(data) == row['bytes'] and digest(data) == row['sha256']
        assert (INDEPENDENT / name).read_bytes() == data
    assert z.read('manifest.json') == (INDEPENDENT / 'manifest.json').read_bytes()
source_proof = json.loads((INDEPENDENT / 'source-review.json').read_text())
assert source_proof['source'] == SOURCE
for name, row in source_proof['production_files'].items():
    data = git('show', f'{SOURCE}:{name}')
    assert digest(data) == row['sha256']
    assert git('rev-parse', f'{SOURCE}:{name}').decode().strip() == row['blob']
    assert (INDEPENDENT / 'source' / name).read_bytes() == data

results = {}
for owner, directory, stem, expected in [
    ('author', AUTHOR, 'baseline', (1, 2)),
    ('author', AUTHOR, 'spec-red', (59, 5)),
    ('author', AUTHOR, 'affected', (67, 0)),
    ('independent', INDEPENDENT, 'affected', (69, 1)),
    ('independent', INDEPENDENT, 'affected-final', (71, 0)),
]:
    counts = junit(directory / f'{stem}.xml')
    assert counts == dict(passed=expected[0], failed=expected[1], errors=0, skipped=0), counts
    result = json.loads((directory / f'{stem}-exit.json').read_text())
    assert not result['foreign_imports'] and not result['imported_source_drift']
    assert not result['status_after']
    results[f'{owner}/{stem}'] = {'counts': counts, 'receipt': result}

probe = ROOT / 'qa/semantic-disposition-batch5/test_aa_shard_public.py'
assert digest(probe.read_bytes()) == PEER_SHA
integrity = json.loads((AUTHOR / 'green-observations/original-observations-integrity.json').read_text())
assert integrity['before'] == integrity['after'] and integrity['unchanged']
for name, value in integrity['before'].items():
    assert digest(Path(name).read_bytes()) == value

payload: dict[str, bytes] = {}
for directory, prefix in [(AUTHOR, 'author'), (INDEPENDENT, 'independent')]:
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            payload[f'{prefix}/{path.relative_to(directory).as_posix()}'] = path.read_bytes()
payload['independent-original.zip'] = archive.read_bytes()
payload['peer/test_aa_shard_public.py'] = probe.read_bytes()
for path in sorted((probe.parent / 'aa-shard-public').glob('*.json')):
    payload[f'peer/aa-shard-public/{path.name}'] = path.read_bytes()
for ref, label, names in [
    (BASE, 'baseline', ['tools/calibration/tier_r/shard.py', 'tools/calibration/tier_r/cli.py', 'tests/test_tier_r_shard.py']),
    (SOURCE, 'reviewed', ['tools/calibration/tier_r/shard.py', 'tools/calibration/tier_r/cli.py', 'tests/test_tier_r_shard.py', 'tests/test_tier_r_aa_failures.py', 'docs/specs/known-answer-corpus.md']),
]:
    for name in names:
        payload[f'source/{label}/{name}'] = git('show', f'{ref}:{name}')
payload['source/change.patch'] = git('diff', '--binary', BASE, SOURCE)
payload['source/commits.txt'] = git('log', '--format=fuller', '--reverse', f'{BASE}..{SOURCE}')
for name in ['replay_aa_checks.py', 'replay_aa_shard.py', 'full_batch_receipt.py', 'seal_aa_shard_checkpoint.py']:
    payload[f'helpers/{name}'] = (ROOT / 'ops' / name).read_bytes()
review = {
    'baseline': BASE, 'spec_tests': SPEC, 'source': SOURCE,
    'source_tree': git('rev-parse', f'{SOURCE}^{{tree}}').decode().strip(),
    'independent_archive_sha256': INDEPENDENT_SHA,
    'independent_members_verified': len(manifest) + 1,
    'source_snapshots_git_equal': len(source_proof['production_files']),
    'original_probe_sha256': PEER_SHA, 'original_observations_unchanged': True,
    'junit_verified': results, 'blocking_findings': [],
    'scope': 'Research shard reporting only; authored producers. No compiler, target, native engine, network, frozen-result rewriting or accuracy qualification.',
}
payload['coordinator-review.json'] = (json.dumps(review, indent=2) + '\n').encode()
note = f'''# Preserve A/A rebuild failures in shard provenance

The research shard runner now classifies an A/A summary with a nonempty
`not_byte_identical` list as failed for exit 0 or 1. The existing case-stop,
persist/load, merge, Markdown and CLI paths then retain that failure and a
bounded reason. Ordinary findings, empty A/A lists, other command summaries,
timeout/blocked status and prior runner-error precedence retain their contracts.

Baseline: `{BASE}` (equal tree to published PR #316 `14efc523`).
Spec/tests: `{SPEC}`. Exact reviewed source: `{SOURCE}`.
The production diff is four added lines in `tools/calibration/tier_r/shard.py`.
The preceding specification and regression tests define the behavior first.

## Evidence and independent review

| Source-specific invocation | Passed | Failed | Skipped | Interpretation |
| --- | ---: | ---: | ---: | --- |
| Original unchanged public probe on baseline | 1 | 2 | 0 | Both exit-0/1 failures were omitted from merged failing cases |
| Spec/tests before production edit | 59 | 5 | 0 | New propagation, stop and CLI controls fail on the prior source |
| Author affected gate on `{SOURCE[:8]}` | 67 | 0 | 0 | Existing shard suite, new controls and unchanged peer probe |
| First independent gate | 69 | 1 | 0 | Authored 8,018-character identifier correctly exceeds the pre-existing summary budget |
| Final independent gate | 71 | 0 | 0 | Fixture corrected to admitted 1,918 characters; separate over-budget refusal retained |

These overlapping counts are not additive. The final independent gate took
0.92 seconds; the author gate took 0.77 seconds. Exact commands, JUnit, logs,
imported-source receipts, original fixture bytes and their correction are in
the archive. Both final gates used the clean exact source, with no foreign
project import or source drift. Normal repository Ruff passed. No assertion
was weakened and no frozen research outcome was rewritten.

The independent reviewer inspected the real `cmd_aa`, source/spec/tests,
case-step termination, persisted shard reload, merged provenance, Markdown and
CLI exits. Additional authored controls cover the real command summary,
bounded diagnostics, generic findings reload and the unchanged summary cap.
The initial independent failure was a fixture-domain error; no product edit
followed it. The unchanged original public probe and original observations
are SHA-verified before/after and retained separately from new observations.

Root verified every member of the independent 27-member archive, its three
source snapshots against exact Git objects, all five JUnit totals and original
observation hashes. Independent archive SHA-256: `{INDEPENDENT_SHA}`.

## Qualification limits

All producers here are authored. This repair adds no compiler, native engine,
target execution, network, statistical accuracy or frozen-corpus acceptance.
Historical card/recipe grammar remains a separately incomplete research scope.
Only newly produced shard summaries adopt the repaired classification. The
combined integrated candidate still requires its own gate. Main integration,
native/platform/package/security acceptance and release readiness remain held.
'''
payload['README.md'] = note.encode()
members = {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(payload.items())}
OUT.mkdir(parents=True)
zip_path = OUT / 'evidence.zip'
with zipfile.ZipFile(zip_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(payload.items()):
        z.writestr(name, data)
    z.writestr('manifest.json', json.dumps(members, indent=2) + '\n')
with zipfile.ZipFile(zip_path) as z:
    assert z.testzip() is None and set(z.namelist()) == set(payload) | {'manifest.json'}
    for name, row in members.items():
        data = z.read(name)
        assert len(data) == row['bytes'] and digest(data) == row['sha256']
envelope = {'baseline': BASE, 'source': SOURCE, 'spec_tests': SPEC,
            'archive_bytes': zip_path.stat().st_size, 'archive_sha256': digest(zip_path.read_bytes()),
            'payload_members': len(members), 'members': members}
(OUT / 'manifest.json').write_text(json.dumps(envelope, indent=2) + '\n')
(OUT / 'README.md').write_text(note + f'\n[Complete evidence](evidence.zip), [member hashes](manifest.json).\n\nArchive: {envelope["archive_bytes"]:,} bytes, {len(members)} payload members;\nSHA-256 `{envelope["archive_sha256"]}`.\n')
for path, text in {
    REPO / 'docs/qa.md': '''\n\n## [AA-SHARD-CLASSIFICATION-20261118]\n\nExact source `9bd17bbecb54f5a3de05d235a1617a3d2f196883` retains nonidentical A/A\nrebuilds in failed shard cases, merged provenance and CLI status. Spec/tests\nprecede the four-line production change. Original public 2-fail/1-positive and\nspec-first 5-fail/59-positive receipts remain. Author gate: 67 passed; independent\ngate: 71 passed, zero skips. The independent fixture-budget correction is retained\nwith its original 1-fail/69-pass result; no product change followed it. Source\nimports, old observations, exact Git snapshots and archive members are verified.\nNo compiler/native/accuracy/frozen-result or release credit. [Full QA](qa/aa-shard-classification-20261118/README.md).\n''',
    REPO / 'tasks/todo.md': '''\n\n### [AA-SHARD-CLASSIFICATION-20261118]\n\n- [x] Reproduce both omitted A/A failure outcomes through unchanged public persisted-shard controls.\n- [x] Specify/test before the four-line classification/reason repair; preserve generic findings and prior error precedence.\n- [x] Retain exact-source author and independent controls, original fixture correction, raw outcomes and source hashes.\n- [ ] Selectively integrate attributed commits and verify the combined source; no frozen/native/accuracy or main-merge credit.\n''',
}.items():
    with path.open('a') as stream:
        stream.write(text)
print(json.dumps({k: v for k, v in envelope.items() if k != 'members'}, indent=2))
