"""Retain the peer's exact A/A probe while separating coordinator observations."""
import hashlib
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ORIGINAL = ROOT / 'qa/semantic-disposition-batch5/test_aa_shard_public.py'
EXPECTED = '4d5f1d9a1e513d4385c5548a61cc96a754decd34ad00ad53cd00f547b229f6e6'
OUTPUT = Path(os.environ['PATCHTRACE_AA_OUTPUT']).resolve()
BEFORE = None


def observed():
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted((ORIGINAL.parent / 'aa-shard-public').glob('*.json'))}


def pytest_sessionstart():
    from tools.calibration.tier_r import shard
    assert Path(shard.__file__).resolve() == Path(os.environ['PATCHTRACE_AA_ROOT']).resolve() / 'tools/calibration/tier_r/shard.py'


def pytest_collection_modifyitems(items):
    global BEFORE
    assert hashlib.sha256(ORIGINAL.read_bytes()).hexdigest() == EXPECTED
    BEFORE = observed()
    OUTPUT.mkdir(parents=True, exist_ok=False)
    found = [item for item in items if Path(item.module.__file__).resolve() == ORIGINAL]
    assert len(found) == 3
    for item in found:
        item.module.HERE = OUTPUT


def pytest_sessionfinish():
    after = observed()
    assert after == BEFORE
    with (OUTPUT / 'original-observations-integrity.json').open('x') as stream:
        json.dump({'probe_sha256': EXPECTED, 'before': BEFORE, 'after': after,
                   'unchanged': after == BEFORE}, stream, indent=2)
        stream.write('\n')
