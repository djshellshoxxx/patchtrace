"""Read-only pytest collection receipt for the coordinator's bounded full run."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import sys


def pytest_collection_finish(session):
    destination = Path(os.environ['PATCHTRACE_BATCH_COLLECTION_RECEIPT'])
    payload = {
        'nodeids': [item.nodeid for item in session.items],
        'python': sys.executable,
        'version': sys.version,
        'patchtrace_modules': {
            name: str(Path(module.__file__).resolve())
            for name, module in sorted(sys.modules.items())
            if (name == 'patchtrace' or name.startswith('patchtrace.'))
            and getattr(module, '__file__', None)
        },
    }
    destination.write_text(json.dumps(payload, indent=2) + '\n')


def pytest_sessionfinish(session, exitstatus):
    destination = Path(os.environ['PATCHTRACE_BATCH_COLLECTION_RECEIPT'])
    payload = json.loads(destination.read_text()) if destination.exists() else {'nodeids': []}
    sources = {}
    for name, module in sorted(sys.modules.items()):
        path = getattr(module, '__file__', None)
        if path and (name == 'patchtrace' or name.startswith('patchtrace.')):
            target = Path(path).resolve()
            if target.is_file():
                sources[name] = {'path': str(target), 'sha256': hashlib.sha256(target.read_bytes()).hexdigest()}
    payload.update(exitstatus=int(exitstatus), tests_collected=session.testscollected,
                   tests_failed=session.testsfailed, final_sources=sources)
    destination.write_text(json.dumps(payload, indent=2) + '\n')
