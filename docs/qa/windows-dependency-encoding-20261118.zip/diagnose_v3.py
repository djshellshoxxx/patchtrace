"""Read-only command/encoding diagnosis; no pip, install or network execution."""
from __future__ import annotations

import hashlib
import importlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/workspace/scratch/c7a9e8d98848/continuation-integration')
QA = Path(__file__).resolve().parent
SOURCE = '3e0d4695b6e2b94ba1eddeba3a2a31b78fe9f657'
HOSTED = 'a94495abb6117400c138eaaa0127d260c3010094'
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT))
scan = importlib.import_module('tools.dependency_security')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT,
                                   env=dict(os.environ, GIT_NO_REPLACE_OBJECTS='1'))


snapshots = []
for relative in ('tools/dependency_security.py', 'tools/release_qualification.py',
                 'docs/specs/dependency-security-qualification.md'):
    raw = git('show', f'{SOURCE}:{relative}')
    assert (ROOT / relative).read_bytes() == raw
    target = QA / 'source' / SOURCE[:8] / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        assert target.read_bytes() == raw
    else:
        target.write_bytes(raw)
    snapshots.append({'path': relative, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                      'git_blob': git('rev-parse', f'{SOURCE}:{relative}').decode().strip()})
missing = subprocess.run(['git', 'cat-file', '-t', HOSTED], cwd=ROOT, capture_output=True, text=True)
(QA / 'source-provenance-v3.json').write_text(json.dumps({
    'source_commit': SOURCE, 'snapshots': snapshots, 'hosted_source': HOSTED,
    'hosted_object_local_lookup': {'exit': missing.returncode, 'stderr': missing.stderr},
    'limit': 'No hosted object was fetched; hosted source/argv are read from preserved artifacts, not asserted equal to local Git bytes.',
}, indent=2) + '\n')

payload = '\U0001f44b / \u4fee\u590d / caf\u00e9'
body = (
    'import json,sys; '
    '(sys.stdout.reconfigure(encoding="cp1252") if sys._xoptions.get("utf8") not in (True,"1") else None); '
    'print(json.dumps({"text":' + repr(payload) + ',"utf8_mode":sys.flags.utf8_mode,'
    '"isolated":sys.flags.isolated,"ignore_environment":sys.flags.ignore_environment},ensure_ascii=False))'
)
out = QA / 'authored-output-v3'
out.mkdir(exist_ok=False)
project = {'build-system': {'requires': ['setuptools>=75,<100']},
           'project': {'name': 'patchtrace', 'version': '0.1.0', 'dependencies': ['widget==2.0'],
                       'optional-dependencies': {'search': ['finder==1.2'], 'rules': ['rule-engine==3.0'], 'dev': ['builder>=6,<7']}}}
plans = {profile: scan.commands(out, ROOT, project, profile) for profile in ('runtime', 'packaging', 'static')}
(QA / 'current-command-plans.json').write_text(json.dumps(plans, indent=2) + '\n')
argv = plans['runtime']['scanner-inspect']
prefix = argv[1:argv.index('-m')]
assert prefix == ['-I']
# Model only the absent-explicit-mode CP1252 fallback. Candidate output uses
# the interpreter's actual UTF-8 stream; no duplicate -X override is introduced.
old = [sys.executable, *prefix, '-c', body]
candidate = [sys.executable, *prefix, '-X', 'utf8', '-c', body]
bad = scan.run_logged(old, out, 'current-cp1252-model', timeout=10, limit=8192)
assert bad['exit_code'] != 0 and not bad['output_limited'] and not bad['timed_out']
assert b'UnicodeEncodeError' in (out / 'current-cp1252-model.stderr').read_bytes()
try:
    scan.successful(bad)
except scan.EvidenceError:
    pass
else:
    raise AssertionError('a failed encoding attempt was accepted')
good = scan.run_logged(candidate, out, 'candidate-utf8-model', timeout=10, limit=8192)
scan.process_receipt(out, 'candidate-utf8-model', candidate)
result = json.loads((out / 'candidate-utf8-model.stdout').read_bytes())
assert result == {'text': payload, 'utf8_mode': 1, 'isolated': 1, 'ignore_environment': 1}
try:
    scan.process_receipt(out, 'candidate-utf8-model', old)
except scan.EvidenceError:
    pass
else:
    raise AssertionError('an old command spelling was accepted for new evidence')

identity_code = (
    'import json,os,sys; print(json.dumps({"utf8_mode":sys.flags.utf8_mode,'
    '"isolated":sys.flags.isolated,"ignore_environment":sys.flags.ignore_environment,'
    '"stdout_encoding":sys.stdout.encoding,"env_utf8":os.environ.get("PYTHONUTF8"),'
    '"env_ioencoding":os.environ.get("PYTHONIOENCODING")}))'
)
environment = dict(os.environ, PYTHONUTF8='1', PYTHONIOENCODING='ascii')
direct_argv = [sys.executable, '-I', '-c', identity_code]
direct = subprocess.run(direct_argv, env=environment, capture_output=True, timeout=10)
assert direct.returncode == 0 and len(direct.stdout) < 4096 and len(direct.stderr) < 4096
(QA / 'isolated-environment.stdout').write_bytes(direct.stdout)
(QA / 'isolated-environment.stderr').write_bytes(direct.stderr)
(QA / 'isolated-environment.process.json').write_text(json.dumps({
    'argv': direct_argv, 'environment_overrides': {'PYTHONUTF8': '1', 'PYTHONIOENCODING': 'ascii'},
    'exit': direct.returncode, 'python': sys.version,
}, indent=2) + '\n')
for item in snapshots:
    assert hashlib.sha256((ROOT / item['path']).read_bytes()).hexdigest() == item['sha256']
(QA / 'diagnosis.json').write_text(json.dumps({
    'source_commit': SOURCE, 'hosted_source': HOSTED,
    'modeled_failure_exit': bad['exit_code'], 'modeled_utf8_exit': good['exit_code'],
    'unicode_round_trip': result, 'raw_failure_preserved': True, 'wrong_argv_refused': True,
    'pip_or_installer_executed': False, 'network_audit_run': False,
    'native_windows_acceptance': False, 'production_changes': False,
    'scope': 'Portable interpreter/output model plus actual retained Windows traceback and argv; no claim that model reruns native pip.',
}, indent=2) + '\n')
print(json.dumps({'modeled_failure_exit': bad['exit_code'], 'modeled_utf8_exit': good['exit_code'],
                  'unicode_round_trip': result, 'environment_probe': json.loads(direct.stdout)}))
