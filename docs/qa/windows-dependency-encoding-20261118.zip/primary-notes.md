# Primary interpreter references

Official Python 3.12 command-line documentation:
https://docs.python.org/3.12/using/cmdline.html

The `-I` option retains isolation and implies ignoring Python environment
variables; `-X utf8` explicitly enables UTF-8 mode. Official standard-library
mode documentation says the mode makes standard streams use UTF-8:
https://docs.python.org/3.12/library/os.html#python-utf-8-mode

Read through the web retrieval service on 2026-11-18 (the live 3.12 manual
identifies itself as 3.12.16). Exact 3.12.10 archived pages and tagged C-source
URLs were unavailable through that service; they are not claimed as reviewed.
Local Python 3.12.14 `--help`, `--help-env`, and `--help-xoptions` output is
retained separately. The actual authored child confirms isolated=1,
ignore_environment=1 and utf8_mode=1 with one explicit flag. A separate child
with UTF8/IOENCODING variables present still reports ignore_environment=1 and
does not adopt those settings. These portable checks do not rerun hosted
Python 3.12.10 or pip's Windows Rich console path.
