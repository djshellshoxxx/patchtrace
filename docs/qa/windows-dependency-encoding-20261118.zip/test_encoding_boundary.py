"""Proposed Unicode-output boundary; authored child only, never pip or a network scan."""
from __future__ import annotations

import json
import os
from pathlib import Path
import sys

import pytest

from tools import dependency_security as scan

PAYLOAD = '\U0001f44b / \u4fee\u590d / caf\u00e9'
BODY = (
    'import json,sys; '
    '(sys.stdout.reconfigure(encoding="cp1252") if sys._xoptions.get("utf8") not in (True,"1") else None); '
    'print(json.dumps({"text":' + repr(PAYLOAD) + ',"utf8_mode":sys.flags.utf8_mode,'
    '"isolated":sys.flags.isolated,"ignore_environment":sys.flags.ignore_environment},ensure_ascii=False))'
)
PROJECT = {'build-system': {'requires': ['setuptools>=75,<100']},
           'project': {'name': 'patchtrace', 'version': '0.1.0', 'dependencies': ['widget==2.0'],
                       'optional-dependencies': {'search': ['finder==1.2'], 'rules': ['rule-engine==3.0'],
                                                 'dev': ['builder>=6,<7']}}}


@pytest.mark.parametrize('profile', ['runtime', 'packaging', 'static'])
def test_every_canonical_python_command_explicitly_selects_utf8(profile, tmp_path):
    commands = scan.commands(tmp_path / 'out', tmp_path / 'repo', PROJECT, profile)
    for name, argv in commands.items():
        mode = min(argv.index(option) for option in ('-c', '-m') if option in argv)
        assert argv[1:mode] == ['-I', '-X', 'utf8'], (name, argv)


def observation(name):
    path = Path(os.environ['PATCHTRACE_ENCODING_OBSERVATIONS']) / name
    path.mkdir(parents=True, exist_ok=False)
    return path


def test_current_inspection_command_preserves_unicode_at_authored_cp1252_boundary(tmp_path):
    plan = scan.commands(tmp_path / 'out', tmp_path / 'repo', PROJECT, 'runtime')['scanner-inspect']
    prefix = plan[1:plan.index('-m')]
    argv = [sys.executable, *prefix, '-c', BODY]
    out = observation('canonical-command')
    record = scan.run_logged(argv, out, 'unicode', timeout=10, limit=8192)
    scan.successful(record)
    data = json.loads((out / 'unicode.stdout').read_bytes())
    assert data == {'text': PAYLOAD, 'utf8_mode': 1, 'isolated': 1, 'ignore_environment': 1}
    scan.process_receipt(out, 'unicode', argv)


def test_explicit_utf8_positive_keeps_isolation_and_exact_command_provenance():
    argv = [sys.executable, '-I', '-X', 'utf8', '-c', BODY]
    out = observation('explicit-positive')
    scan.run_logged(argv, out, 'unicode', timeout=10, limit=8192)
    scan.process_receipt(out, 'unicode', argv)
    data = json.loads((out / 'unicode.stdout').read_bytes())
    assert data == {'text': PAYLOAD, 'utf8_mode': 1, 'isolated': 1, 'ignore_environment': 1}
    with pytest.raises(scan.EvidenceError, match='provenance'):
        scan.process_receipt(out, 'unicode', [sys.executable, '-I', '-c', BODY])
