"""Exact-source UTF-8 gate; permit only authored Python and local Git children."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import ssl
import subprocess
import sys
import tempfile
import time

ROOT = Path('/workspace/scratch/c7a9e8d98848/security-residual-qa')
QA = Path(__file__).resolve().parent
SOURCE, LABEL, *FILES = sys.argv[1:]
assert LABEL.replace('-', '').isalnum() and FILES
for suffix in ('command.json', 'xml', 'imports.json', 'exit.json'):
    assert not (QA / f'{LABEL}.{suffix}').exists()
observations = QA / f'{LABEL}-external'
assert not observations.exists()
sys.dont_write_bytecode = True
sys.path[:0] = [str(ROOT / 'src'), str(ROOT), str(ROOT / 'tests')]
os.environ.update(PYTHONPATH=f'{ROOT}/src:{ROOT}', QT_QPA_PLATFORM='offscreen',
                  PATCHTRACE_ENCODING_OBSERVATIONS=str(observations))


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT,
                                   env=dict(os.environ, GIT_NO_REPLACE_OBJECTS='1'))


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert git('diff', '--name-only', 'HEAD') == b''
blobs = {}
for row in git('ls-tree', '-r', '-z', SOURCE, 'src', 'tools').split(b'\0'):
    if row:
        meta, path = row.split(b'\t', 1)
        blobs[path.decode()] = meta.split()[2].decode()
test_files = [{'path': str(Path(p).resolve()), 'sha256': hashlib.sha256(Path(p).read_bytes()).hexdigest()}
              for p in FILES]
import pytest

children, denied = [], []


def audit(event, args):
    if event in {'socket.__new__', 'socket.connect', 'os.system', 'os.fork', 'os.posix_spawn'}:
        denied.append(event)
        raise AssertionError('encoding gate forbids network or unapproved process execution')
    if event == 'subprocess.Popen':
        executable, argv = os.fspath(args[0]), args[1]
        children.append(list(argv))
        python_child = executable == sys.executable and '-c' in argv and '-m' not in argv
        local_git = Path(executable).name == 'git' and not {
            'fetch', 'push', 'clone', 'ls-remote', 'pull', 'send-email',
        }.intersection(argv)
        if not (python_child or local_git):
            denied.append('subprocess.Popen')
            raise AssertionError('encoding gate permits only authored Python and local Git')


started = time.monotonic()
with tempfile.TemporaryDirectory(prefix='dependency-encoding-') as temporary:
    arguments = ['-q', '-p', 'no:cacheprovider', '--basetemp', str(Path(temporary) / 'pytest'),
                 *FILES, f'--junitxml={QA}/{LABEL}.xml']
    (QA / f'{LABEL}.command.json').write_text(json.dumps({
        'source_commit': SOURCE, 'cwd': str(ROOT), 'python': sys.version,
        'argv': [sys.executable, str(Path(__file__).resolve()), SOURCE, LABEL, *FILES],
        'pytest_arguments': arguments, 'test_files': test_files,
        'environment': {'PYTHONPATH': os.environ['PYTHONPATH'], 'QT_QPA_PLATFORM': 'offscreen',
                        'PYTHONDONTWRITEBYTECODE': '1', 'PATCHTRACE_ENCODING_OBSERVATIONS': str(observations)},
    }, indent=2) + '\n')
    sys.addaudithook(audit)
    outcome = int(pytest.main(arguments))
modules, drift = [], []
for name, module in sorted(sys.modules.items()):
    if not (name.startswith('patchtrace') or name == 'tools' or name.startswith('tools.')):
        continue
    if not getattr(module, '__file__', None):
        continue
    path = Path(module.__file__).resolve()
    record = {'name': name, 'path': str(path)}
    if not path.is_relative_to(ROOT):
        drift.append(name)
    else:
        raw = path.read_bytes()
        relative = path.relative_to(ROOT).as_posix()
        blob = hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest()
        record.update(relative_path=relative, sha256=hashlib.sha256(raw).hexdigest(),
                      git_blob=blob, expected_git_blob=blobs.get(relative))
        if blob != blobs.get(relative):
            drift.append(name)
    modules.append(record)
for record in test_files:
    if hashlib.sha256(Path(record['path']).read_bytes()).hexdigest() != record['sha256']:
        drift.append(record['path'])
(QA / f'{LABEL}.imports.json').write_text(json.dumps({'source_commit': SOURCE, 'modules': modules,
                                                    'drift': drift}, indent=2) + '\n')
result = outcome if not drift and not denied else 1
(QA / f'{LABEL}.exit.json').write_text(json.dumps({
    'source_commit': SOURCE, 'pytest_exit': outcome, 'exit_code': result,
    'project_tool_imports': len(modules), 'drift': drift, 'denied_attempts': denied,
    'children': children, 'seconds': time.monotonic() - started,
}, indent=2) + '\n')
raise SystemExit(result)
