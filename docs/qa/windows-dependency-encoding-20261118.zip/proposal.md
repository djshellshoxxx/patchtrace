# Windows dependency-inspection encoding proposal

## Observed cause

Preserved hosted artifacts 14470840684 (runtime) and 14471515532 (packaging)
bind source `a94495abb6117400c138eaaa0127d260c3010094`, run 44395588481 attempt 1,
Windows CPython 3.12.10. Both scanner-inspect commands use `python -I -m pip
inspect --local`, exit 2 without timeout/output limit, and preserve the same
CP1252 UnicodeEncodeError for U+1F44B. The retained stderr SHA-256 is
`9c8d5bab13d580f90abd73417ffd68363ec7a855ff703a1e5f8492156c1c072f`.

The currently inspected canonical tool is pinned to local source
`3e0d4695b6e2b94ba1eddeba3a2a31b78fe9f657`. The hosted Git object is unavailable
locally; no fetch occurred and no unsupported byte-equality claim is made.
The actual hosted command prefix matches the current command construction.
Current run_logged strips PYTHON variables and captures binary stdout/stderr;
it does not cause the producer's encoding choice. Official Python documentation
and retained local interpreter observations establish the -I/-X semantics.

## Minimal owned source change

Add one canonical Python option tuple `('-I', '-X', 'utf8')` and use it for
every directly generated Python command in tools/dependency_security.py:
pip_install, audit_argv, static_argv, bootstrap_commands and commands. The flag
precedes `-m`/`-c`; it occurs once. This covers installer/inventory/check/identity
and scanner output consistently on both supported platforms. It retains
isolation and the existing environment filter rather than relying on an ignored
environment setting. UTF-8 mode also sets Python's documented text defaults;
this is scoped to the helper's isolated subprocesses.

No scanner version, installer dependency, audit exclusion, suppression, source
guard, output cap, raw-byte handling, or acceptance rule changes. The validator
already reconstructs exact canonical argv, so altered/missing flags cannot
qualify a current receipt. Historical failed output remains readable and is not
relabeled successful. No workflow or native process code is in this slice.

Proposed ownership: tools/dependency_security.py, one focused encoding test file,
the existing dependency-security specification and QA. New branch
`codex/dependency-utf8-20261118` can reuse the completed clean core worktree,
preserving its existing branch at b9041430, after root chooses the baseline.
No product edit has been made.

## Exact bounded reproduction and acceptance

The external test_encoding_boundary.py yields four failures and one positive
on the current source in 0.25 seconds. Three failures identify missing explicit
UTF-8 in the runtime/packaging/static canonical plans. The fourth runs the
actual bounded run_logged capture with the canonical inspection prefix and an
authored CP1252-default producer; Unicode output fails and remains raw evidence.
The positive uses exactly one explicit flag and preserves emoji, CJK and accented
JSON with isolated=1 and ignore_environment=1. Wrong command provenance refuses.
No pip, package installer or network audit is executed by these controls.

After specification/regression commit, the source change should turn those
controls green and retain tests for full raw Unicode bytes, unwanted Python
environment isolation, canonical flag presence/order, old/altered argv refusal,
nonzero raw failure retention and existing bootstrap/closure/scanner failures.
Run only the focused encoding and related dependency-security/bootstrap gates
with exact tool imports; hosted Windows scans remain the native acceptance gate.

All original hosted receipts and executed child stdout/stderr/process receipts
remain. Two preliminary harness failures are separate: invalid empty selected
dependency groups, then an incorrect duplicate -X override assumption. The final
model uses the current prefix untouched and one explicit candidate flag. Those
setup corrections are not product findings. The portable model does not claim
to execute native pip or reproduce the Rich call stack; the actual hosted trace
supplies that observation. See primary-notes.md and the exact command/source
receipts for documentation versions and source limits.
