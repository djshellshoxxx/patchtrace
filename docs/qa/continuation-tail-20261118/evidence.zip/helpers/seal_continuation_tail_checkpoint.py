"""Retain the exact qualified tail, original failures and bounded completion ledger."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
SOURCE = '068513a72e8a1412ce3960d3024c462d68d51376'
TREE = '2183dcf3b9cfee268c3ebb163ad9f3e9e928e10f'
BASE = '740869debb111f8edbef33899316e4c75e6fdf7a'
MAIN = '9c411ca3d7b47f950be5f0c6f01b3c54184554c6'
QA = ROOT / 'qa/continuation-tail-integration'
DEST = REPO / 'docs/qa/continuation-tail-20261118'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE
assert not git('status', '--porcelain') and not DEST.exists()
gate = json.loads((QA / 'combined-exit.json').read_text())
assert gate['exit'] == 0 and gate['source_after'] == SOURCE and not gate['status_after']
assert gate['imported_source_count'] == 552 and not gate['foreign_imports'] and not gate['imported_source_drift']
assert gate['old_public_observations_unchanged'] and not gate['temp_retained']
counts = Counter()
omitted = []
for case in ET.parse(QA / 'combined.xml').getroot().findall('.//testcase'):
    skip = case.find('skipped')
    kind = 'failed' if case.find('failure') is not None else 'errors' if case.find('error') is not None else (
        'expected_failures' if skip is not None and skip.get('type') == 'pytest.xfail' else
        'skipped' if skip is not None else 'passed')
    counts[kind] += 1
    if skip is not None:
        omitted.append(dict(classname=case.get('classname'), test=case.get('name'), kind=kind, reason=skip.get('message')))
assert dict(counts) == {'passed': 6356, 'skipped': 18, 'expected_failures': 3}
owners = json.loads((QA / 'source-preservation-068513a7.json').read_text())
assert len(owners['files']) == 101 and owners['all_changed_paths_owned']
for path, record in owners['files'].items():
    assert sha((REPO / path).read_bytes()) == record['sha256']
lint = json.loads((QA / 'ruff-receipts.json').read_text())
strict = json.loads((QA / 'strict-sites-comparison.json').read_text())
assert lint[0]['exit'] == 0 and lint[1]['exit'] == 1 and lint[1]['findings'] == 80
assert strict['same_path_code_selected_statement_multiset']
fresh = json.loads((QA / 'fresh-before-publication.json').read_text())
readbacks = {row['path']: json.loads(row['value']['structuredContent']['content']) for row in fresh['reads']}
assert readbacks['branches/main']['commit']['sha'] == MAIN
for number in (304, 307, 316):
    assert readbacks[f'pulls/{number}']['state'] == 'open' and not readbacks[f'pulls/{number}']['merged']
for number in (304, 307):
    subprocess.run(['git', '-C', str(REPO), 'merge-base', '--is-ancestor', readbacks[f'pulls/{number}']['head']['sha'], SOURCE], check=True)
assert readbacks['pulls/316']['head']['sha'] == '14efc52369146f4a638b7d688208736a05321bc0'

note = f'''# Verified continuation tail — 2026-11-18

## Exact candidate and acceptance boundary

Clean source **`{SOURCE}`**, tree **`{TREE}`**, passes **6,356 tests**, with
**18 explicit skips, three existing expected failures, zero unexpected failures
and zero errors**, in **385.72 seconds** (388.64 seconds wrapper wall time).
The reviewed selection contains 215 files and 6,377 collected cases. All 552
imported PatchTrace modules came from this checkout with matching bytes; no
foreign editable installation or post-run source drift was observed. All 101
changed source/test/tool/workflow/schema files since actual PR316 `55f3d074`
equal an independently reviewed owner's bytes. No production conflict required
manual reconciliation.

This is a scoped candidate regression milestone. It does not replace full
Linux/Windows, repeated Qt, native engine, frozen ZIP/installer/Linux package,
complete dependency/security or reproducibility acceptance. The separate strict
S scan still fails on 80 unchanged path/code/selected-statement sites. Ordinary
configured Ruff over `src tests tools` passes. No scanner suppression, weakened
assertion or runner deselection was introduced.

## Fresh repository state and integration

At `{fresh['at']}`, canonical main was **`{MAIN}`**. PR304 remained open at
`d8c02caea407f6d323eecd636735849c1eb31a2d`; PR307 remained open at
`58fc130631f602b6e907bb054d30c21d810551d4`. Both exact heads are ancestors of
this local candidate. PR316 remained open at actual remote
`14efc52369146f4a638b7d688208736a05321bc0`, whose tree equals preceding local
checkpoint `{BASE}`. The tail adds 44 attributed local commits. Remote object
reconstruction verifies each exact tree and preserves the reviewed local SHA in
its message; original author/history and source patches are retained here.
Branch advancement and its final readback are separate publication receipts.

No PR was merged or closed, no branch deleted, no remote history rewritten, and
no tag, release or deployment created. Every tail integration message carries
`[no release]`. Main acceptance remains blocked. Existing #304 full-suite/package
results remain historical and cannot qualify this newer tree.

## Delivered and independently reviewed slices

| Slice | Result on this candidate | Original source / evidence |
| --- | --- | --- |
| Saved advisory scope | Finite saved coverage is validated before derived mutations, all selected recovery journals and inventory selection. Current global admission remains authoritative; changed native counterevidence changes context identity. Valid legacy cached receipts remain readable. | `a7f6c9c4`; [scope packet](../kb-saved-scope-20261118.md), root 99-check replay and exact 200-member source/archive review |
| A/A failure classification | Nonempty `not_byte_identical` in A/A exit0/1 survives shard persistence, merge provenance and CLI as a failure; other command/status semantics remain intact. | `9bd17bbe`; [A/A packet](../aa-shard-classification-20261118/README.md), original public failure and independent review retained |
| Optional COFF masking API | The source-layer symbol mask consumes unquoted COFF `?` names completely. The normal mutation factory does not wire this optional check. | `ce093ec5`; [COFF packet](../coff-mask-compatibility-20261118.md) and [caller erratum](../semantic-disposition-batch5-caller-erratum-20261118.md) |
| Static bootstrap artifact retention | The strict scanner upload includes its existing text bootstrap receipts. No scan rule or installation behavior changed. | `7adcecd7`; older hosted artifact omission and actual pattern coverage retained; no new hosted-upload pass claimed |
| Windows source observations | Path and descriptor views compare compatible physical metadata; complete descriptor ChangeTime survives the final tree pass in both consumers. Stable dependency receipt reads use the compatible comparison while retaining same-view checks. | `80df2735`; [Windows packet](../windows-source-stat-20261118/README.md), original independent final-write/receipt failures and CPython3.12.10 source retained |
| PW02 pure contracts | Versioned identities, raw-name/collision rules, container ownership, ASCII-only selected basename and shared bounded accounting are implemented, with generated schemas. | `64583964`; [contracts](../autonomous-ci-20261118/pw02-contracts/README.md), [ASCII correction](../autonomous-ci-20261118/pw02-ascii-selection/README.md), unchanged independent Kelvin-sign probe |
| Immutable action references | 178 mutable uses in 21 workflows now name 11 commits resolved from their same canonical refs; eight already immutable uses remain unchanged. All 22 raw/YAML workflow objects match after reference substitution alone. | `3b3c3d63`, test-only `f6cc9a18`; [action packet](../workflow-action-pins-20261118.md), root 23-object API and 61-snapshot archive review |

These are bounded implementation claims. PW02 has no native stage, FDI decoder,
worker, CLI, package store or project admission wired by this source. Its pure
records cannot establish observed native I/O, signature authenticity or a usable
Windows decoder. The optional COFF check has authored assembly evidence, not a
real compiler or native accuracy acceptance. A/A classification does not change
frozen research outcomes. Saved-scope/global-revision policy and current Support
semantics remain intact.

## Complete original focal branch partition

The independently checked fifth, sixth and seventh semantic packets finish all
**131 original branch-name focal dispositions**; zero of that original set remain
unselected. Exact tips, ancestry, patch/caller proof and the known same-tip alias
are retained. This is not a statement that every entire branch is integrated or
every feature is complete. Broad-tip research/native/platform residue, incomplete
developer workflows and the Phase2 reference-package contract remain open.

Batch5's optional COFF caller description was corrected through a separately
attributed erratum; its original archive was not rewritten. Batch6 and batch7
retain all historical fixture/import/policy failures and explicit compiler/real-
launcher deselections. Their historical counts do not add to this combined gate.
The [batch7 ledger](../../plans/autonomous-consolidation-20261118/semantic-disposition-batch7.md)
is the final original-partition record.

## Preserved failures and exact-source evidence

Original saved-scope widening/missing-coverage failures, revision-key aliasing,
inventory preflight omission, A/A reporting failures, COFF compatibility failures,
the Unicode Kelvin selector failure, Windows final-descriptor/receipt failures
and mutable-action policy failures remain immutable in their source packets.
Intermediate author/reviewer fixture mistakes, collection errors and obsolete
test expectations are classified separately; no historical receipt became a
new pass. The missed Tier R mutable-tag assertion was changed to require full
40-hex commits, retaining its existing exact MSVC pin and all other assertions.

The coordinator's initial action verifier over-scoped its historical body check
to an already dispositioned license-policy test. Its refusal is retained. The
corrected verifier checks the four original repair probes actually claimed
unchanged; every current repository policy test still ran. The saved-scope root
archive verifier's initial flattened-snapshot path assumption is likewise
retained and corrected without changing any test or source assertion.

The original public saved-scope probe and its historical helper were copied
byte-for-byte to a fresh observation directory. The original R2 and A/A probes
retain identical source bytes; only their observation destinations are redirected.
Every preserved original/author/previous observation hash still matches afterward.
The historical-index legacy-CSAF replay remains separately pinned because it
deliberately imports an old implementation under the project namespace; the
current-source import guard was not waived. Current committed compatibility
controls ran in the combined selection.

## Guarded execution and omitted acceptance

The retained wrapper installs inherited Linux network denial before pytest import
or collection, confirms no inherited socket descriptors, restricts Git transports
to local files, and owns a fresh system temporary directory outside any Git tree.
The guarded network events were hostname reads plus one denied AF_UNIX creation;
856 audited process invocations came from the inspected local fixture/CLI/Git
scope. This is a test-execution boundary, not a native product sandbox claim.
The owned temporary tree was removed only after successful verification.

Sixteen of the 18 skips require native Windows: directory junction, six Job/
launcher checks, existing-object sharing, and eight new source/receipt stat
observations. The other two are the optional colorspacious oracle and the denied
AF_UNIX destination-kind capability. Real BinDiff acceptance explicitly reports
BLOCKED because no executable is provisioned. The duplicate-ZIP warning is the
hostile-input fixture's expected construction warning.

The three expected failures are CODEX5 dependency hash closure, CODEX6 cached
engine verification and CODEX14 Linux full frozen CLI smoke. Separate repairs
for the latter two exist after this frozen source and are undergoing independent
integration review; they are not counted as green here. Full dependency lock
coverage remains a distinct design/qualification task.

## Hosted evidence remains on its actual older source

The [hosted14ef packet](../hosted-pr316-14ef-20261118/README.md) records the actual
PR preview `5ed108355f2626c9867782832c76b1c438c51281`, whose tree equals14ef.
Linux BinDiff passed seven authored native controls and preserved the same
ordinary/no-network semantic digest. That small fixture does not establish real
driver accuracy. Windows BinDiff and both dependency profiles stopped at the
generic source guard before native compilation or scanning. Strict scanning
completed with 80 findings; its bootstrap text artifact was absent on that older
tree. The specific Windows stat-field cause was not logged, so the relationship
to the now-repaired metadata semantics remains an inference pending native rerun.
All 34 archive members, five source snapshots, raw log strings and original
artifact hashes were independently checked. None qualifies this new candidate.

## Continuing assigned work and release status

Cache verification, full Linux smoke wiring and the independently reproduced
directory-publication import-purity defect have separate source/QA handoffs.
The package team has a concrete parent-directed suspended-child transfer and
held-reader design; the next assigned slices are portable worker-grant accounting
and neutral core reader/checkpoint propagation. Original operation deadlines,
SQLite caller-thread ownership and committed-project retention remain required.
Native transfer, rooted sharing, FDI, durable package provenance/reconciliation
and the actual frozen pair journey are still pending. The Phase2 reference
contract and complete installer/hash-lock map continue independently.

Frozen L1 remains 73 pass / six fail / eight excluded out of87. L2 ground truth
and the original http-parser miss remain separate research work. L3 source,
permission and executable binary evidence remain unverified. No beta-ready,
calibrated-accuracy, main-merge or release-ready classification is made.
'''

payloads = {'checkpoint-note.md': note.encode(),
            'combined-counts.json': (json.dumps(dict(counts=counts, explicit_unverified=omitted), indent=2) + '\n').encode()}
directories = [
    ('combined', QA),
    ('coff-root-review', ROOT / 'qa/coff-mask-root-review'),
    ('batch5-root-review', ROOT / 'qa/semantic-disposition-batch5-root-review'),
    ('batch6-root-review', ROOT / 'qa/semantic-disposition-batch6-root-review'),
    ('batch7-root-review', ROOT / 'qa/semantic-disposition-batch7-root-review'),
    ('static-root-review', ROOT / 'qa/static-scan-receipt-root-review'),
    ('scope-root-review', ROOT / 'qa/kb-saved-scope-root-review'),
    ('pw02-root-review', ROOT / 'qa/pw02-contracts-root-review'),
    ('action-root-review', ROOT / 'qa/action-pins-root-review'),
    ('hosted-root-review', ROOT / 'qa/hosted-14ef-root-review'),
]
for label, directory in directories:
    assert directory.is_dir(), directory
    for path in sorted(directory.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            payloads[label + '/' + path.relative_to(directory).as_posix()] = path.read_bytes()
for name, path in (
    ('initial-pw02-design.zip', ROOT / 'qa/pw02-local-package-design/evidence.zip'),
    ('pw02-independent-first.zip', ROOT / 'qa/pw02-contracts-independent.zip'),
    ('pw02-independent-ascii.zip', ROOT / 'qa/pw02-ascii-independent.zip'),
):
    payloads['independent-packets/' + name] = path.read_bytes()
for name in ('cache-final-focused.command.json', 'cache-final-focused.log', 'cache-final-focused.xml',
             'tier-action-policy-corrected.command.json', 'tier-action-policy-corrected.log',
             'tier-action-policy-corrected.xml'):
    payloads['missed-action-neighbor/' + name] = (ROOT / 'qa/corpus-archive-cache' / name).read_bytes()
for name in ('prepare_continuation_tail_scope.py', 'run_continuation_tail_gate.py', 'continuation_offline_pytest.py',
             'full_batch_receipt.py', 'replay_r2_tail.py', 'replay_aa_shard.py', 'verify_continuation_tail_sources.py',
             'scan_continuation_tail.py', 'verify_action_pins_tail.py', 'verify_semantic_tail.py',
             'verify_scope_and_hosted_tail.py', 'verify_pw02_contracts_tail.py', 'cleanup_completed_tail_worktrees.py',
             'seal_continuation_tail_checkpoint.py', 'build_publication.py',
             'publish_continuation_tail_objects.mjs', 'publish_continuation_tail_objects_v2.mjs'):
    payloads['helpers/' + name] = (ROOT / 'ops' / name).read_bytes()
for path in git('diff', '--name-only', BASE, SOURCE, '--', 'src', 'tests', 'tools', '.github', 'docs/schemas', 'docs/specs').decode().splitlines():
    payloads['candidate-source/' + path] = git('show', SOURCE + ':' + path)
payloads['integration/44-commit-history.txt'] = git('log', '--reverse', '--format=fuller', BASE + '..' + SOURCE)
payloads['integration/source-delta.patch'] = git('diff', BASE, SOURCE, '--', 'src', 'tests', 'tools', '.github', 'docs/schemas', 'docs/specs')
tail = {BASE, *git('rev-list', BASE + '..' + SOURCE).decode().splitlines()}
resolutions = [json.loads(line) for line in (ROOT / 'qa/followup-integration/record-resolutions.jsonl').read_text().splitlines()]
selected = [row for row in resolutions if row['head'] in tail]
payloads['integration/append-conflict-records.json'] = (json.dumps(selected, indent=2) + '\n').encode()
payloads['publication/preceding-map.json'] = (ROOT / 'qa/continuation-publication/objects.json').read_bytes()

DEST.mkdir(parents=True, exist_ok=False)
archive = DEST / 'evidence.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(payloads.items()):
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(set(z.namelist())) == len(payloads) and z.testzip() is None
    for name, data in payloads.items():
        assert z.read(name) == data
raw = archive.read_bytes()
manifest = dict(source=SOURCE, tree=TREE, sealed_utc=datetime.now(timezone.utc).isoformat(),
                archive=archive.name, archive_bytes=len(raw), archive_sha256=sha(raw),
                payloads=[dict(path=name, bytes=len(data), sha256=sha(data)) for name, data in sorted(payloads.items())])
with (DEST / 'manifest.json').open('x') as stream:
    json.dump(manifest, stream, indent=2)
    stream.write('\n')
with (DEST / 'README.md').open('x') as stream:
    stream.write(note + f'\n## Sealed archive\n\n{len(payloads)} verified payloads; {len(raw):,} bytes. SHA-256: `{sha(raw)}`.\n')
hosted = REPO / 'docs/qa/hosted-pr316-14ef-20261118'
hosted.mkdir(exist_ok=False)
for name in ('README.md', 'review.json', 'manifest.json', 'evidence.zip'):
    shutil.copyfile(ROOT / 'qa/hosted-14ef-receipt-review' / name, hosted / name)

additions = {
    'docs/plans/patchtrace-completion-matrix.md': f'''

## Verified continuation tail — 2026-11-18, source068513a7

Actual source `{SOURCE}` passes6,356 selected tests,18 explicit skips and three
known CODEX expected failures (215 files,385.72s). All552 imported project modules
and101 changed owner paths are pinned. Strict S remains80 unchanged findings;
full/platform/native/package/security final G remains open. Main stays `{MAIN}`.
[Complete checkpoint](../qa/continuation-tail-20261118/README.md).

| Feature / bounded scope | Current state | Completion | Concrete remaining work | Source | Dependencies | Tests | Security | Owner | Acceptance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Saved advisory-scope admission | Implemented and independently reviewed on candidate | D,R:50% | Representative real-source/native journey and final gates; preserve current documented recovery limits | a7f6c9c4, PR316 | Existing global index, coverage identity, caller-thread SQLite | Original failures, author2604/one native skip, root99, actual combined gate | Scope validation before approvals, inventory and all selected recovery writes | CVE/KB + root | Stable finite scope and admission-sensitive context after reopen; J/G |
| Local-package pure contracts and budgets | Bounded preparatory slice implemented; no native intake caller | D,R:50% for this slice | Serial worker grants, native stage/FDI, held reader and durable provenance composition |64583964, PR316| Existing acquisition errors; generated schemas | Original157/6 boundary failures and Kelvin red retained; corrected284 and independent281+19 per-source invocations; actual combined | ASCII-only selection, graph ownership, reserve-before-write, bounded names/counts/time | CI + security | Native and representative journey separate; no capability claim from records |
| Whole local MSU/CAB fallback (PW02) | Partial implementation; no working package-to-project route | None:0% of whole-feature milestones | Implement and qualify native decoder/worker/stage, existing KB/core path, durable linkage and frozen journey | Current contracts + separate joint design | Qualified Windows lane and explicit local inputs | Portable contracts only; native/frozen route absent | No target execution, retained locks, deadline and committed-project preservation required | CI + CVE/KB | Full specified package-to-project route before whole-feature D/R/J/G credit |
| A/A classification and optional COFF compatibility | Reviewed developer/research mechanics | D,R:50% for each bounded slice | Native compiler/rebuild/accuracy qualification and final applicable gates |9bd17bbe,ce093ec5| Existing shard/store/merge and optional source-layer check | Original public failures and actual combined regression | Preserve other statuses, full counterevidence and optional-caller boundary | Research + root | No frozen-outcome or product-accuracy credit from authored fixtures |
| Immutable workflow action references | Implemented reference-only repair | D,R:50% | Exact-source hosted behavior; dependency lock closure; other CI defects and final gates |3b3c3d63,f6cc9a18|23 canonical API objects; existing workflow policy|430/three known xfails at owner source; actual combined|178 mutable uses pinned; triggers/permissions/secrets/scripts unchanged|CI + root|Hosted and final qualification, not static checks alone |
| Windows source observation guards | Portable source repair independently reviewed | D,R:50% | Eight native Windows observations, actual scanner/BinDiff/package reruns |80df2735|CPython path/descriptor semantics; existing source verification|240/8 native skips, independent44 and252/8; actual combined|Final same-view ChangeTime and complete receipt checks retained|CI + root|Native Windows and final-source G; old hosted generic failure cause remains inferred |

All131 original reconciliation branch names now have a focal disposition; zero
remain unselected in that original partition. Whole-branch residue and research/
native/platform work remain. This count is not a feature percentage. The separate
cache/smoke/purity handoffs and next package work are absent from this frozen
candidate. Historical rows above remain attributed to their own dates/sources.
''',
    'docs/plans/autonomous-consolidation-20261118/consolidation-ledger.md': f'''

## Verified44-commit continuation tail — 2026-11-18

Candidate `{SOURCE}`, tree `{TREE}`, contains the reviewed saved-scope, A/A,
optional COFF, bootstrap artifact, Windows observation, package-contract and
action-pin slices plus semantic batches5/6/7. All101 owner paths retain exact
reviewed bytes. Combined215-file gate:6,356 pass,18 skips,three known xfails,
zero unexpected failures/errors. Full/security/native/platform G is incomplete.
All131 original focal dispositions are recorded; no whole-branch closure follows.
Fresh main `{MAIN}`; #304 d8c02cae and #30758fc1306 remain open and are verified
ancestors of this local candidate; #31614ef remains open before append publication.
No merges/closures/releases. [Checkpoint](../../qa/continuation-tail-20261118/README.md).
''',
    'docs/qa.md': f'''

## [CONTINUATION-TAIL-20261118]

Exact source `{SOURCE}`:215 files,6,356 passed,18 skipped,three known CODEX
expected failures,zero unexpected failures/errors in385.72s.552 project imports
pinned;101 owner paths exact; original observations unchanged. Normal Ruff passes;
strict S remains80 identical sites and fails. Main merge/native/platform/package/
full final acceptance remains blocked. [Sealed checkpoint](qa/continuation-tail-20261118/README.md)
and [older-source hosted14ef](qa/hosted-pr316-14ef-20261118/README.md).
''',
    'tasks/todo.md': '''

### [CONTINUATION-TAIL-20261118]

- [x] Independently verify and integrate semantic batches5/6/7; all131 original focal tips dispositioned, broader residue explicit.
- [x] Port reviewed saved-scope, A/A, optional COFF, artifact retention, Windows observations, PW02 pure contracts and immutable action references.
- [x] Verify101 owner paths and215-file current gate:6,356 pass/18 skips/three known expected failures;552 source imports; preserve original failures and observations.
- [x] Retain unchanged strict80 diagnostics, primary Windows semantics and independently checked older-source hosted14ef packet.
- [ ] Finish append-only PR316 publication with exact remote tree/parent/ref readback; no main merge.
- [ ] Independently review/integrate cache verification, full Linux smoke and directory-publication import-purity handoffs.
- [ ] Complete portable worker-grant and neutral core reader/checkpoint slices, then native stage/FDI/supervisor and existing KB propagation/durable package linkage.
- [ ] Reconcile Phase2 reference contracts and complete approved platform/profile dependency hash-lock design and implementation.
- [ ] Obtain complete actual-candidate full/Linux/Windows/Qt/native/frozen/package/security/reproducibility gates; no beta/release readiness yet.
'''
}
for name, text in additions.items():
    with (REPO / name).open('a') as stream:
        stream.write(text)
print(json.dumps(dict(source=SOURCE, members=len(payloads), archive_bytes=len(raw), archive_sha256=sha(raw),
                      append_conflict_receipts=len(selected), main=MAIN)))
