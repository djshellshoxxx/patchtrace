"""Independently check the sealed action-reference-only repair, without running actions."""
from __future__ import annotations

import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

import yaml

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
BASE = 'c7d3f25858cfefbacbd8ea4022b3d13e1e2aed2a'
SOURCE = '3b3c3d6346c644f04a2e69d9835f147652436535'
QA = 'a6c966f53f1d554619f87cb9bd4ae5f43902e947'
ARCHIVE = ROOT / 'qa/workflow-action-pins.zip'
EXPECTED = '06102fd31bbcb169981f05040dae25f6d043a9198e9e119f3b6f435041ddff76'
OUT = ROOT / 'qa/action-pins-root-review/archive-and-source-review.json'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def blob(ref, path):
    return git('show', f'{ref}:{path}')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def api(result):
    assert not result.get('isError'), result
    return json.loads(result['structuredContent']['content'])


assert not OUT.exists()
assert sha(ARCHIVE.read_bytes()) == EXPECTED
assert ARCHIVE.read_bytes() == blob(QA, 'docs/qa/workflow-action-pins-20261118.zip')
with zipfile.ZipFile(ARCHIVE) as z:
    assert z.testzip() is None
    names = z.namelist()
    assert len(names) == len(set(names)) == 98
    manifest = json.loads(z.read('manifest.json'))
    assert {r['path'] for r in manifest['files']} == set(names) - {'manifest.json'}
    for row in manifest['files']:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['path']
    assert manifest['source'] == SOURCE and manifest['baseline'] == BASE
    assert manifest['source_tree'] == git('rev-parse', SOURCE + '^{tree}').decode().strip()
    snapshots = json.loads(z.read('source-snapshots.json'))
    for row in snapshots:
        data = z.read(row['archive_path'])
        assert data == blob(row['source'], row['path']), row
        assert sha(data) == row['sha256']
        assert git('rev-parse', row['source'] + ':' + row['path']).decode().strip() == row['git_blob']
    assert len(snapshots) == 61
    mapping = json.loads(z.read('action-pin-only-proof.json'))['mapping']
    references = json.loads((ROOT / 'qa/action-pins-root-review/canonical-api-rereads.json').read_text())
    assert len(references['plan']) == 11 and len(references['results']) == 22
    replies = {}
    for response in references['results']:
        assert response['status'] == 'fulfilled'
        item = response['value']
        replies[item['old'], item['kind']] = api(item['result'])
    codex_tag = api(json.loads((ROOT / 'qa/action-pins-root-review/codex-annotated-tag-reread.json').read_text())['result'])
    for row in references['plan']:
        commit = replies[row['old'], 'commit']
        ref = replies[row['old'], 'ref']['object']
        assert commit['sha'] == row['commit_sha'] and commit['tree']['sha'] == row['tree']
        if ref['type'] == 'tag':
            assert row['old'] == 'openai/codex-action@v1'
            assert ref['sha'] == codex_tag['sha']
            ref = codex_tag['object']
        assert ref['type'] == 'commit' and ref['sha'] == commit['sha']
        assert mapping[row['old']] == row['old'].split('@')[0] + '@' + commit['sha']

    workflow_paths = git('ls-tree', '-r', '--name-only', BASE, '.github/workflows').decode().splitlines()
    assert len(workflow_paths) == 22
    changed, counts, immutable = [], Counter(), []
    uses = re.compile(rb'(?m)(^\s*(?:-\s*)?uses:\s*)([^\s#]+)')

    def mapped_yaml(value):
        if isinstance(value, dict):
            return {k: mapping.get(v, v) if k == 'uses' and isinstance(v, str) else mapped_yaml(v)
                    for k, v in value.items()}
        if isinstance(value, list):
            return [mapped_yaml(v) for v in value]
        return value

    file_proofs = []
    for path in workflow_paths:
        before, after = blob(BASE, path), blob(SOURCE, path)

        def replace(match):
            old = match[2].decode()
            if old in mapping:
                counts[old] += 1
                return match[1] + mapping[old].encode()
            assert re.fullmatch(r'[\w./-]+@[0-9a-f]{40}', old), old
            immutable.append(old)
            return match[0]

        assert uses.sub(replace, before) == after, path
        assert mapped_yaml(yaml.safe_load(before)) == yaml.safe_load(after), path
        if before != after:
            changed.append(path)
        file_proofs.append(dict(path=path, before_sha256=sha(before), after_sha256=sha(after)))
    assert len(changed) == 21 and sum(counts.values()) == 178 and len(immutable) == 8
    assert set(git('diff', '--name-only', '51160492b66d5952c1c9b3c78fd4e337b8d4d38c',
                   '2d8ef3f5fa30d06a8e3c90ba69d67b9944005908').decode().splitlines()) == set(changed)

    assertion_proofs = []
    required_original_probes = {'test_remote_actions_are_immutable', 'test_pip_downloads_require_hashes',
                                'test_corpus_cache_does_not_skip_verification',
                                'test_linux_package_runs_full_cli_smoke'}
    for path in ('tests/test_codex_pkg_workflows.py', 'tests/test_codex_pkg_packaging.py'):
        original = ast.parse(z.read('original/' + Path(path).name))
        current = ast.parse(blob(SOURCE, path))
        old_tests = {n.name: n for n in original.body if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')}
        new_tests = {n.name: n for n in current.body if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')}
        for name in old_tests.keys() & new_tests.keys() & required_original_probes:
            old_body = ast.dump(ast.Module(body=old_tests[name].body, type_ignores=[]))
            new_body = ast.dump(ast.Module(body=new_tests[name].body, type_ignores=[]))
            assert old_body == new_body, (path, name)
            assertion_proofs.append(dict(path=path, test=name, body_sha256=sha(old_body.encode())))
    assert {row['test'] for row in assertion_proofs} == required_original_probes

    junit = {}
    for name in names:
        if not name.endswith('.xml'):
            continue
        root = ET.fromstring(z.read(name))
        cases = root.findall('.//testcase')
        result = Counter()
        for case in cases:
            skip = case.find('skipped')
            key = 'failed' if case.find('failure') is not None else 'errors' if case.find('error') is not None else (
                'expected_failures' if skip is not None and skip.get('type') == 'pytest.xfail' else
                'skipped' if skip is not None else 'passed')
            result[key] += 1
        junit[name] = dict(result)
    assert junit['action-neighbors-final.xml'] == {'passed': 430, 'expected_failures': 3}
    assert junit['original-four-red.xml'] == {'failed': 4}
    assert junit['original-four-after-action-pins.xml'] == {'passed': 1, 'failed': 3}

receipt = dict(source=SOURCE, source_tree=manifest['source_tree'], qa=QA, baseline=BASE,
               archive_sha256=EXPECTED, archive_bytes=ARCHIVE.stat().st_size,
               archive_members=len(names), git_snapshots_verified=len(snapshots),
               root_canonical_api_objects_verified=23, replacements=dict(counts),
               unchanged_immutable_uses=immutable, workflows=file_proofs,
               raw_only_reference_substitutions=True, yaml_only_reference_substitutions=True,
               original_assertion_bodies=assertion_proofs, junit=junit,
               independent_review='Full spec and neighboring assertion migrations read; runtime behavior not executed.',
               later_test_only_followup='f6cc9a18b1bcaf851faa5fe36032412f3c6f2626 reviewed separately; missed Tier R mutable-tag expectation',
               hosted_runtime_native_release_acceptance=False)
with OUT.open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps({k: receipt[k] for k in ('source','archive_members','git_snapshots_verified',
                                         'root_canonical_api_objects_verified','yaml_only_reference_substitutions')}))
