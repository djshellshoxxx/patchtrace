"""Select the union of already reviewed offline controls and preserve probe bytes."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = ROOT / 'qa/continuation-tail-integration'
SOURCE = '068513a72e8a1412ce3960d3024c462d68d51376'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


assert subprocess.check_output(['git', '-C', str(REPO), 'rev-parse', 'HEAD'], text=True).strip() == SOURCE
assert not subprocess.check_output(['git', '-C', str(REPO), 'status', '--porcelain'], text=True).strip()
destination = OUT / 'selected-nodes.json'
assert not destination.exists()
old_path = ROOT / 'qa/continuation-r2-integration/selected-nodes.json'
nodes = set(json.loads(old_path.read_text())['node_files'])
inputs = [
    ('qa/kb-saved-scope/final-committed-affected.command.json', 'command'),
    ('qa/pw02-local-packages/ascii-selection/final-provenance.json', 'pytest_argv'),
    ('qa/aa-shard-classification/affected-command.json', 'argv'),
    ('qa/coff-mask-root-review/focused-command.json', 'argv'),
    ('qa/windows-source-stat/final-observation-affected-command.json', 'argv'),
    ('qa/workflow-action-pins/action-neighbors-final.command.json', 'argv'),
]
provenance = {str(old_path.relative_to(ROOT)): dict(sha256=digest(old_path),
                                                   files=sorted(nodes))}
for name, key in inputs:
    path = ROOT / name
    document = json.loads(path.read_text())
    files = sorted({value for value in document[key] if value.startswith('tests/') and value.endswith('.py')})
    assert files
    nodes.update(files)
    provenance[name] = dict(sha256=digest(path), files=files)

public_root = OUT / 'external-saved-public'
public_root.mkdir(exist_ok=False)
copy_records = []
for relative, expected in (
    ('test_saved_scope_public.py', 'cf2f3320e7eaab89a2e38d8a71724e2de67f6270c3a6c4c154fa2f56218fcb5c'),
    ('historical/kbscope/tests/test_kbc_saved_scope.py', 'baa5b56e0c238f74b91c71706abb9a7161cd616f51f1a53a8a1b6ed13a97f0a9'),
):
    original = ROOT / 'qa/semantic-disposition-batch5' / relative
    target = public_root / relative
    assert digest(original) == expected
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(original.read_bytes())
    assert digest(target) == expected
    copy_records.append(dict(original=str(original), target=str(target), sha256=expected,
                             bytes=target.stat().st_size, identical=True))
external = [
    ROOT / 'qa/semantic-disposition-batch5/test_aa_shard_public.py',
    ROOT / 'qa/coff-mask-review/test_coff_boundaries_portable.py',
    public_root / 'test_saved_scope_public.py',
    ROOT / 'qa/kb-saved-scope-root-review/test_native_admission_context_identity.py',
    ROOT / 'qa/kb-saved-scope/test_inventory_saved_scope_preflight_review.py',
    ROOT / 'qa/pw02-contracts-independent/test_package_independent.py',
    ROOT / 'qa/pw02-contracts-independent/test_package_ascii_selection.py',
]
nodes.update(str(path) for path in external)
files = []
for node in sorted(nodes):
    path = Path(node) if Path(node).is_absolute() else REPO / node
    assert path.is_file()
    files.append(dict(node=node, sha256=digest(path), bytes=path.stat().st_size))
preserved = {}
for directory in (ROOT / 'qa/semantic-disposition-batch5/saved-scope-public',
                  ROOT / 'qa/kb-saved-scope/external-final/saved-scope-public',
                  ROOT / 'qa/kb-saved-scope-root-review/public-final/saved-scope-public'):
    preserved.update({str(path): digest(path) for path in sorted(directory.glob('*.json'))})
document = dict(source=SOURCE, node_files=sorted(nodes), source_receipts=provenance,
                exact_selected_file_bytes=files, unchanged_public_probe_copies=copy_records,
                preserved_public_observations=preserved,
                selection='Union of prior reviewed108-file scope, saved-scope96 repository files, '
                          'package/source-stat/A-A/COFF/workflow controls, and seven reviewed external probe files. '
                          'No tests or assertions deselected by the runner.',
                separately_pinned_evidence=[dict(
                    path='qa/kb-saved-scope/test_legacy_csaf_coverage_review.py',
                    reason='Deliberately imports a historical index implementation under the patchtrace namespace. '
                           'Its retained source-specific compatibility replay remains separate; the generic current-source '
                           'import guard is not waived. Current committed legacy fixtures remain in this gate.')],
                execution_review='New external probes are pure/authored; workflow tests parse source. '
                                 'CLI/recovery children execute current repository code on authored temporary fixtures. '
                                 'Git children use only owned local repositories; inherited network denial and file-only Git apply. '
                                 'No downloaded tools, corpus targets, external analyzers or paid workflows are launched.')
with destination.open('x') as stream:
    json.dump(document, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(source=SOURCE, selected_files=len(nodes), original_probe_copies=len(copy_records))))
