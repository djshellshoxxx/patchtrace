"""Keep normal lint and the unsuppressed static security result as separate receipts."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = ROOT / 'qa/continuation-tail-integration'
SOURCE = '068513a72e8a1412ce3960d3024c462d68d51376'
BEFORE = 'ae0b1660e0cc71c51698d70a685ceeb646619184'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE and not git('status', '--porcelain')
assert not (OUT / 'ruff-receipts.json').exists()
records = []
for label, flags in [('normal', ['src', 'tests', 'tools']),
                     ('strict', ['--isolated', '--select', 'S', '--ignore-noqa', '--no-cache',
                                 '--no-respect-gitignore', '--output-format', 'json', 'src'])]:
    command = [sys.executable, '-m', 'ruff', 'check', *flags]
    started = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(command, cwd=REPO, capture_output=True, timeout=120)
    for kind, data in [('stdout', result.stdout), ('stderr', result.stderr)]:
        with (OUT / f'ruff-{label}.{kind}').open('xb') as stream:
            stream.write(data)
    row = dict(source=SOURCE, argv=command, cwd=str(REPO), exit=result.returncode, started_utc=started,
               stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),
               stderr_sha256=hashlib.sha256(result.stderr).hexdigest())
    if label == 'strict':
        current = json.loads(result.stdout)
        row.update(findings=len(current), by_rule=dict(Counter(item['code'] for item in current)))
    records.append(row)
with (OUT / 'ruff-receipts.json').open('x') as stream:
    json.dump(records, stream, indent=2)
    stream.write('\n')


def selected_sites(rows, ref):
    sites = Counter()
    for row in rows:
        path = Path(row['filename']).relative_to(REPO).as_posix()
        lines = git('show', ref + ':' + path).decode().splitlines(keepends=True)
        start, end = row['location'], row['end_location']
        selected = lines[start['row'] - 1:end['row']]
        if len(selected) == 1:
            text = selected[0][start['column'] - 1:end['column'] - 1]
        else:
            selected[0] = selected[0][start['column'] - 1:]
            selected[-1] = selected[-1][:end['column'] - 1]
            text = ''.join(selected)
        sites[path, row['code'], text] += 1
    return sites


prior = json.loads((ROOT / 'qa/continuation-r2-integration/ruff-strict.stdout').read_text())
left, right = selected_sites(prior, BEFORE), selected_sites(current, SOURCE)
comparison = dict(before=BEFORE, after=SOURCE, before_count=len(prior), after_count=len(current),
                  same_path_code_selected_statement_multiset=left == right,
                  added=[dict(path=p, code=c, statement=s, count=n) for (p,c,s),n in (right-left).items()],
                  removed=[dict(path=p, code=c, statement=s, count=n) for (p,c,s),n in (left-right).items()],
                  strict_scan_still_fails=records[-1]['exit'] != 0)
with (OUT / 'strict-sites-comparison.json').open('x') as stream:
    json.dump(comparison, stream, indent=2)
    stream.write('\n')
assert git('rev-parse', 'HEAD').decode().strip() == SOURCE and not git('status', '--porcelain')
print(json.dumps(dict(normal_exit=records[0]['exit'], strict_exit=records[1]['exit'],
                      findings=len(current), same_sites=left == right)))
assert records[0]['exit'] == 0
