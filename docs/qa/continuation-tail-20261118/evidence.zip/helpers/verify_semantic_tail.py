"""Independently verify an append-only semantic audit packet and its Git proofs."""
from __future__ import annotations

import argparse
import datetime as dt
import functools
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument('batch', type=int)
parser.add_argument('source')
parser.add_argument('previous_source')
parser.add_argument('archive_sha256')
args = parser.parse_args()
root = Path('/workspace/scratch/c7a9e8d98848')
repo = root / 'patchtrace'


@functools.lru_cache(maxsize=None)
def git(*argv: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(repo), *argv], stderr=subprocess.DEVNULL)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def object_bytes(ref, path):
    return git('show', f'{ref}:{path}')


def contains(ref, path, needle):
    try:
        return needle.encode() in object_bytes(ref, path)
    except subprocess.CalledProcessError:
        return False


path = f'docs/plans/autonomous-consolidation-20261118/semantic-disposition-batch{args.batch}.json'
ledger = json.loads(object_bytes(args.source, path))
previous = json.loads(object_bytes(args.previous_source, path.replace(f'batch{args.batch}', f'batch{args.batch - 1}')))
baseline = ledger['comparison_source']
archive = root / f'qa/semantic-disposition-batch{args.batch}-sealed.zip'
assert sha(archive.read_bytes()) == args.archive_sha256
assert git('rev-parse', f'{baseline}^{{tree}}').decode().strip() == ledger['comparison_tree']
changed = git('diff', '--name-only', baseline, args.source).decode().splitlines()
assert all(name.startswith(('docs/', 'tasks/')) for name in changed), changed
proofs, history, parents, branches = 0, 0, 0, 0
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    manifest = json.loads(z.read('evidence-manifest.json'))
    assert set(z.namelist()) == set(manifest) | {'evidence-manifest.json'}
    for name, row in manifest.items():
        data = z.read(name)
        assert len(data) == row['bytes'] and sha(data) == row['sha256'], name
    current = json.loads(z.read('current-source-manifest.json'))
    original = json.loads(z.read('historical-source-manifest.json'))
    for row in current + original:
        ref = row.get('source', row.get('tip'))
        data = object_bytes(ref, row['path'])
        retained = row.get('retained', 'current-source/' + row['path'])
        assert data == z.read(retained), retained
        assert len(data) == row['bytes'] and sha(data) == row['sha256'], retained
        assert git('rev-parse', f"{ref}:{row['path']}").decode().strip() == row['blob']
    for branch in ledger['branches']:
        assert branch['tip'] == branch['inventory_tip'] and branch['tip_matches_inventory']
        assert git('merge-base', baseline, branch['tip']).decode().strip() == branch['merge_base']
        assert git('rev-list', '--left-right', '--count', baseline + '...' + branch['tip']).decode().strip() == branch['ahead_behind_baseline']
        assert branch['whole_branch_closed'] is False
        branches += 1
        for proof in branch['replacement_proofs']:
            name, needle = proof['path'], proof['needle']
            data = object_bytes(baseline, name)
            assert sha(data) == proof['current_sha256']
            assert git('rev-parse', f'{baseline}:{name}').decode().strip() == proof['current_blob']
            found = [n for n, line in enumerate(data.decode().splitlines(), 1) if needle in line]
            assert found == proof['current_lines'], (name, needle)
            for revision in proof['history']:
                ref = revision['sha']
                assert contains(ref, name, needle) == revision['needle_present_in_commit']
                ancestor = subprocess.run(['git', '-C', str(repo), 'merge-base', '--is-ancestor', ref, baseline]).returncode == 0
                assert ancestor == revision['is_ancestor_of_comparison']
                actual_parents = git('show', '-s', '--format=%P', ref).decode().strip().split()
                recorded_parents = revision['parent_presence']
                assert actual_parents == [p['sha'] for p in recorded_parents]
                for parent in recorded_parents:
                    assert contains(parent['sha'], name, needle) == parent['needle_present']
                    parents += 1
                if actual_parents:
                    assert contains(actual_parents[0], name, needle) == revision['needle_present_in_first_parent']
                history += 1
            proofs += 1
    totals = {}
    for name, execution in ledger['executions'].items():
        if 'xml' not in execution:
            continue
        cases = ET.fromstring(z.read(execution['xml'])).findall('.//testcase')
        counts = dict(passed=0, failed=0, errors=0, skipped=0, expected_failures=0)
        for case in cases:
            skipped = case.find('skipped')
            field = ('failed' if case.find('failure') is not None else
                     'errors' if case.find('error') is not None else
                     'expected_failures' if skipped is not None and skipped.get('type') == 'pytest.xfail' else
                     'skipped' if skipped is not None else 'passed')
            counts[field] += 1
        assert all(counts[key] == execution.get(key, 0) for key in counts), (name, counts, execution)
        totals[name] = counts
prior_remaining = {(row['branch'], row['tip']) for row in previous['still_unselected_original_tips']}
selected = {(row['branch'], row['tip']) for row in ledger['branches']}
remaining = {(row['branch'], row['tip']) for row in ledger['still_unselected_original_tips']}
assert len(selected) == len(ledger['branches']) and not selected & remaining
assert selected | remaining == prior_remaining
denominator = ledger['selection_denominator']
assert denominator['original_needs_reconciliation_tips'] == 131
assert denominator['selected_this_batch'] == len(selected)
assert denominator['still_unselected'] == len(remaining)
assert denominator['cumulatively_selected'] == 131 - len(remaining)
result = {'reviewed_at': dt.datetime.now(dt.timezone.utc).isoformat(), 'source': args.source,
          'comparison': baseline, 'archive_bytes': archive.stat().st_size,
          'archive_sha256': args.archive_sha256, 'members_verified': len(manifest) + 1,
          'current_source_snapshots_git_equal': len(current), 'original_source_snapshots_git_equal': len(original),
          'replacement_proofs_verified': proofs, 'history_entries_verified': history,
          'parent_presence_verified': parents, 'tips_merge_bases_and_ahead_behind_verified': branches,
          'cumulative_selected': denominator['cumulatively_selected'], 'unselected': len(remaining),
          'original_denominator_preserved_through_prior_verified_packet': True,
          'junit_results_verified': totals, 'docs_only_delta': changed, 'blocking_findings': []}
out = root / f'qa/semantic-disposition-batch{args.batch}-root-review'
out.mkdir(exist_ok=True)
with (out / 'archive-and-ledger-review.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result, indent=2))
