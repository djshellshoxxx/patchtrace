"""Run the fixed reviewed candidate selection with network denial before collection."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
SOURCE = '068513a72e8a1412ce3960d3024c462d68d51376'
OUT = ROOT / 'qa/continuation-tail-integration/combined'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


assert git('rev-parse', 'HEAD') == SOURCE and not git('status', '--porcelain')
scope_path = ROOT / 'qa/continuation-tail-integration/selected-nodes.json'
scope = json.loads(scope_path.read_text())
assert scope['source'] == SOURCE
for row in scope['exact_selected_file_bytes']:
    path = Path(row['node']) if Path(row['node']).is_absolute() else REPO / row['node']
    assert digest(path) == row['sha256']
assert not os.environ.get('PATCHTRACE_BINDIFF'), 'Live external BinDiff is outside this offline scope'
for suffix in ('-command.json', '-exit.json', '-collection.json', '-offline-guard.json', '.xml', '.log'):
    assert not Path(str(OUT) + suffix).exists()
owned = Path(tempfile.mkdtemp(prefix='patchtrace-continuation-tail-'))
assert not any((path / '.git').exists() for path in (owned, *owned.parents))
env = dict(os.environ,
    PYTHONPATH=os.pathsep.join(map(str, [REPO / 'src', REPO / 'tests', REPO, ROOT / 'ops'])),
    QT_QPA_PLATFORM='offscreen', QT_SCALE_FACTOR='1',
    GIT_ALLOW_PROTOCOL='file', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null',
    GIT_TERMINAL_PROMPT='0', PT_REVIEW_ROOT=str(REPO),
    PT_REVIEW_RECORD=str(OUT) + '-pin-interception.json',
    PATCHTRACE_OFFLINE_GUARD_RECEIPT=str(OUT) + '-offline-guard.json',
    PATCHTRACE_BATCH_COLLECTION_RECEIPT=str(OUT) + '-collection.json',
    PATCHTRACE_AA_ROOT=str(REPO), PATCHTRACE_AA_OUTPUT=str(OUT.parent / 'aa-observations'),
    PATCHTRACE_COFF_REVIEW_ROOT=str(REPO), PATCHTRACE_SCOPE_REVIEW_ROOT=str(REPO),
    PATCHTRACE_SCOPE_REVIEW_OUTPUT=str(OUT.parent / 'native-admission'))
command = [sys.executable, str(ROOT / 'ops/continuation_offline_pytest.py'), '-q', '-ra',
           '-p', 'full_batch_receipt', '-p', 'replay_r2_tail', '-p', 'replay_aa_shard',
           *scope['node_files'], '--basetemp=' + str(owned / 'pytest'), '--junitxml=' + str(OUT) + '.xml']
context = dict(source=SOURCE, tree=git('rev-parse', 'HEAD^{tree}'), argv=command, cwd=str(REPO),
               environment={key: value for key, value in env.items() if key in {
                   'PYTHONPATH', 'QT_QPA_PLATFORM', 'QT_SCALE_FACTOR', 'GIT_ALLOW_PROTOCOL',
                   'GIT_CONFIG_NOSYSTEM', 'GIT_CONFIG_GLOBAL', 'GIT_TERMINAL_PROMPT',
                   'PT_REVIEW_ROOT', 'PT_REVIEW_RECORD', 'PATCHTRACE_AA_ROOT', 'PATCHTRACE_AA_OUTPUT',
                   'PATCHTRACE_COFF_REVIEW_ROOT', 'PATCHTRACE_SCOPE_REVIEW_ROOT', 'PATCHTRACE_SCOPE_REVIEW_OUTPUT'}},
               owned_system_temp=str(owned), started_utc=datetime.now(timezone.utc).isoformat(),
               timeout_seconds=900, scope_sha256=digest(scope_path),
               helper_sha256={path.name: digest(path) for path in [Path(__file__),
                   ROOT / 'ops/continuation_offline_pytest.py', ROOT / 'ops/full_batch_receipt.py',
                   ROOT / 'ops/replay_r2_tail.py', ROOT / 'ops/replay_aa_shard.py']})
with Path(str(OUT) + '-command.json').open('x') as stream:
    json.dump(context, stream, indent=2)
    stream.write('\n')
started = time.monotonic()
try:
    with Path(str(OUT) + '.log').open('x') as stream:
        result = subprocess.run(command, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=900)
    code = result.returncode
except subprocess.TimeoutExpired:
    code = 124
collection_path = Path(str(OUT) + '-collection.json')
collection = json.loads(collection_path.read_text()) if collection_path.exists() else {}
foreign = [dict(module=name, path=row['path']) for name, row in collection.get('final_sources', {}).items()
           if not Path(row['path']).is_relative_to(REPO / 'src')]
drift = [row['path'] for row in collection.get('final_sources', {}).values()
         if digest(row['path']) != row['sha256']]
preserved = {path: digest(path) for path in scope['preserved_public_observations']}
preserved_unchanged = preserved == scope['preserved_public_observations']
receipt = dict(exit=code, elapsed=time.monotonic() - started, source_after=git('rev-parse', 'HEAD'),
               status_after=git('status', '--porcelain'), foreign_imports=foreign,
               imported_source_drift=drift, imported_source_count=len(collection.get('final_sources', {})),
               preserved_public_observations=preserved, old_public_observations_unchanged=preserved_unchanged,
               owned_system_temp=str(owned), temp_retained=True)
valid = receipt['source_after'] == SOURCE and not receipt['status_after'] and not foreign and not drift and preserved_unchanged
if code == 0 and valid:
    shutil.rmtree(owned)
    receipt['temp_retained'] = False
with Path(str(OUT) + '-exit.json').open('x') as stream:
    json.dump(receipt, stream, indent=2)
    stream.write('\n')
print(json.dumps({key: value for key, value in receipt.items() if key != 'preserved_public_observations'}))
print('\n'.join(Path(str(OUT) + '.log').read_text().splitlines()[-48:]))
assert valid, 'Source identity or preserved observation integrity failed'
raise SystemExit(code)
