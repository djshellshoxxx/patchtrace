"""Prepare local Git object descriptions for reviewed REST publication; no network writes."""
import json
import subprocess
import sys
from pathlib import Path

repo, output, *refs = sys.argv[1:]


def git(*args):
    return subprocess.check_output(['git', '-C', repo, *args])


commits = []
for ref in refs:
    sha = git('rev-parse', ref).decode().strip()
    parents = git('show', '-s', '--format=%P', sha).decode().strip().split()
    parent = parents[0]
    elements = []
    for path in git('diff', '--name-only', parent, sha).decode().splitlines():
        entry = git('ls-tree', sha, '--', path).decode()
        if not entry:
            elements.append({'path': path, 'mode': '100644', 'type': 'blob', 'sha': None})
            continue
        mode, kind, blob = entry.split('\t')[0].split()
        data = git('cat-file', 'blob', blob)
        item = {'path': path, 'mode': mode, 'type': kind, 'git_blob_sha': blob}
        try:
            item['content'] = data.decode('utf-8')
        except UnicodeDecodeError:
            item['binary_blob_sha'] = blob
            exported = Path(output).parent / 'publication-blobs' / blob
            exported.parent.mkdir(parents=True, exist_ok=True)
            exported.write_bytes(data)
            item['local_file'] = str(exported)
        elements.append(item)
    commits.append({'local_sha': sha, 'parents': parents,
                    'tree': git('rev-parse', sha + '^{tree}').decode().strip(),
                    'parent_tree': git('rev-parse', parent + '^{tree}').decode().strip(),
                    'message': git('show', '-s', '--format=%B', sha).decode().strip(),
                    'elements': elements})
Path(output).write_text(json.dumps(commits), encoding='utf-8')
print(json.dumps([{'local_sha': c['local_sha'], 'tree': c['tree'],
                   'files': len(c['elements'])} for c in commits]))
