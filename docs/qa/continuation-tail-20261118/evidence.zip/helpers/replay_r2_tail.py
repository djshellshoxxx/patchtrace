"""Redirect only the unchanged R2 probe's observations to this new candidate packet."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ORIGINAL = ROOT / 'qa/semantic-disposition-batch4/test_r2_product_surfaces_v3.py'
OUTPUT = ROOT / 'qa/continuation-tail-integration/product-surfaces'
EXPECTED = '37fa19d6c288b1892d9567ddeee7cae35d74c721a73a01247629db6e373b30c4'
PRESERVED = (ORIGINAL.parent / 'product-surfaces-v3',
             ROOT / 'qa/r2-evidence-retention/current-product-surfaces',
             ROOT / 'qa/r2-evidence-retention/green-product-surfaces',
             ROOT / 'qa/continuation-r2-integration/product-surfaces')
BEFORE = None


def observed():
    return {str(path): hashlib.sha256(path.read_bytes()).hexdigest()
            for directory in PRESERVED for path in sorted(directory.glob('*.json'))}


def pytest_collection_modifyitems(items):
    global BEFORE
    assert hashlib.sha256(ORIGINAL.read_bytes()).hexdigest() == EXPECTED
    BEFORE = observed()
    OUTPUT.mkdir(exist_ok=False)
    found = [item for item in items if Path(item.module.__file__).resolve() == ORIGINAL]
    assert len(found) == 5
    for item in found:
        item.module.EVIDENCE = OUTPUT


def pytest_sessionfinish():
    after = observed()
    assert after == BEFORE, 'Preserved baseline or previous observation bytes changed'
    with (OUTPUT.parent / 'r2-observations-integrity.json').open('x') as stream:
        json.dump(dict(probe_sha256=EXPECTED, before=BEFORE, after=after, unchanged=after == BEFORE), stream, indent=2)
        stream.write('\n')
