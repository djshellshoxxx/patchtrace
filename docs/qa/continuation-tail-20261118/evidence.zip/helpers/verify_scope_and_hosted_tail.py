"""Coordinator byte/source/receipt review; no archived code or native payload execution."""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/c7a9e8d98848')
REPO = ROOT / 'patchtrace'


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', '-C', str(REPO), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def sealed(path, manifest, expected):
    data = path.read_bytes()
    assert sha(data) == expected
    z = zipfile.ZipFile(io.BytesIO(data))
    assert z.testzip() is None
    rows = {r['path']: r for r in manifest['files']}
    assert len(z.namelist()) == len(set(z.namelist())) == len(rows)
    assert set(z.namelist()) == set(rows)
    for name, row in rows.items():
        payload = z.read(name)
        assert len(payload) == row['bytes'] and sha(payload) == row['sha256'], name
    return z, rows


def counts(data):
    result = dict(passed=0, failed=0, errors=0, skipped=0, expected_failures=0)
    for case in ET.fromstring(data).findall('.//testcase'):
        skipped = case.find('skipped')
        key = ('failed' if case.find('failure') is not None else
               'errors' if case.find('error') is not None else
               'expected_failures' if skipped is not None and skipped.get('type') == 'pytest.xfail' else
               'skipped' if skipped is not None else 'passed')
        result[key] += 1
    return result


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'receipt': str(path), **value}))


scope_dir = ROOT / 'security-residual-qa/docs/qa'
scope_manifest = json.loads((scope_dir / 'kb-saved-scope-20261118.manifest.json').read_text())
scope_zip = scope_dir / 'kb-saved-scope-20261118.evidence.zip'
scope_hash = '24cae1eba2811e53551cbb23b96162d39c1525151dd986c2936291c63db1d9d2'
z, rows = sealed(scope_zip, scope_manifest, scope_hash)
scope_source = 'a7f6c9c41b3772dc33a787e100097c085389a594'
assert scope_manifest['source'] == scope_source
snapshots = []
prefixes = {'baseline-source/': 'ae0b1660e0cc71c51698d70a685ceeb646619184',
            'final-source/': '60d8006358dc82a49a42e57eaaac548d4706359f',
            'corrected-source/': 'cc408c390ec9c9f8e7b907f7c2d61d06e17e77f8',
            'release-source/': scope_source}
for prefix, source in prefixes.items():
    for name in z.namelist():
        if not name.startswith(prefix) or name == 'baseline-source/fixture-originals.json':
            continue
        path = name[len(prefix):]
        if prefix == 'final-source/':
            assert path in {'context.py', 'index.py', 'saved_scope.py', 'service.py'}
            path = 'src/patchtrace/kbcorrelation/' + path
        actual = git('show', source + ':' + path)
        assert actual == z.read(name), name
        snapshots.append({'path': name, 'source': source, 'sha256': sha(actual)})
release = json.loads(z.read('release-source.json'))
assert release['source'] == scope_source
assert release['tree'] == git('rev-parse', scope_source + '^{tree}').decode().strip()
for row in release['files']:
    data = git('show', scope_source + ':' + row['path'])
    assert len(data) == row['bytes'] and sha(data) == row['sha256']
    assert row['blob'] == git('rev-parse', scope_source + ':' + row['path']).decode().strip()
verification = json.loads(z.read('final-verification.json'))
for row in verification['originals']:
    data = Path(row['path']).read_bytes()
    assert sha(data) == row['sha256'] and row['unchanged']
    assert any(v['sha256'] == row['sha256'] for v in rows.values()), row['path']
caller = json.loads(z.read('final-caller-audit.json'))
assert caller['source'] == scope_source
for path, digest in caller['source_hashes'].items():
    assert sha(git('show', scope_source + ':' + path)) == digest
xml = {name: counts(z.read(name)) for name in z.namelist() if name.endswith('.xml')}
assert xml['final-committed-affected.xml'] == dict(passed=2604, failed=0, errors=0, skipped=1, expected_failures=0)
assert xml['historical-at-final.xml'] == dict(passed=41, failed=3, errors=0, skipped=0, expected_failures=0)
assert xml['public-baseline.xml'] == dict(passed=1, failed=2, errors=0, skipped=0, expected_failures=0)
root_review = ROOT / 'qa/kb-saved-scope-root-review'
root_counts = counts((root_review / 'final-focused.xml').read_bytes())
assert root_counts == dict(passed=99, failed=0, errors=0, skipped=0, expected_failures=0)
exit_data = json.loads((root_review / 'final-focused-exit.json').read_text())
assert exit_data['exit'] == 0 and not exit_data['foreign_imports'] and not exit_data['imported_source_drift']
assert not git('diff', scope_source, 'feb8472928f827a7b5c64c68304703d9e6f5da52', '--', 'src', 'tests', 'tools', '.github')
write(root_review / 'archive-and-source-review.json', {
    'at': datetime.now(timezone.utc).isoformat(), 'source': scope_source, 'archive_sha256': scope_hash,
    'archive_bytes': scope_zip.stat().st_size, 'payloads_verified': len(rows),
    'git_snapshots_verified': len(snapshots), 'release_blob_identities_verified': len(release['files']),
    'immutable_originals_verified': len(verification['originals']), 'caller_source_hashes_verified': len(caller['source_hashes']),
    'all_junit_results': xml, 'root_review': root_counts, 'root_imports': exit_data['imported_source_count'],
    'blocking_findings': [], 'limits': ['Authored offline service/CLI checks; native Windows sharing remains unexecuted.',
       'Historical unsafe supersession expectations remain three explicit failures, not acceptance requirements.',
       'Month-only historical identity and generic recovery operation isolation retain the documented boundaries.']})

hosted = ROOT / 'qa/hosted-14ef-receipt-review'
hosted_manifest = json.loads((hosted / 'manifest.json').read_text())
hosted_hash = '3b9641775b52c9d84f1a07193ed1603e51ee05566105f2cbd104a5302c8f5c1f'
hz, hrows = sealed(hosted / 'evidence.zip', hosted_manifest, hosted_hash)


def api(name):
    return json.loads(json.loads(hz.read('api/' + name + '.json'))['raw_content'])


source, preview = api('source-commit'), api('preview-commit')
assert source['sha'] == '14efc52369146f4a638b7d688208736a05321bc0'
assert preview['sha'] == '5ed108355f2626c9867782832c76b1c438c51281'
assert [p['sha'] for p in preview['parents']] == ['9c411ca3d7b47f950be5f0c6f01b3c54184554c6', source['sha']]
assert source['tree']['sha'] == preview['tree']['sha'] == git('rev-parse', '740869debb111f8edbef33899316e4c75e6fdf7a^{tree}').decode().strip()
assert '[no release]' in source['message']
fresh = json.loads((ROOT / 'qa/continuation-tail-integration/fresh-source-preview-readback.json').read_text())
for label, saved in [('source', source), ('preview', preview)]:
    current = json.loads(fresh[label]['structuredContent']['content'])
    assert current['sha'] == saved['sha'] and current['tree']['sha'] == saved['tree']['sha']
hsources = []
for name in hz.namelist():
    prefix = 'source-tree-b93/'
    if name.startswith(prefix):
        path = name[len(prefix):]
        assert hz.read(name) == git('show', '740869debb111f8edbef33899316e4c75e6fdf7a:' + path)
        hsources.append(path)
logs = []
for name in hz.namelist():
    if name.startswith('logs/') and name.endswith('.json'):
        envelope = json.loads(hz.read(name))
        raw = envelope['raw_content'].encode()
        assert raw == hz.read(name[:-5] + '.log') and preview['sha'].encode() in raw
        logs.append({'job_id': envelope['job_id'], 'sha256': sha(raw),
                     'source_guard_refusal': b'tracked file changed at open' in raw})
metadata = {a['id']: a for run in [44377335166, 44377335068] for a in api('artifacts-' + str(run))['artifacts']}
artifacts = []
for name in hz.namelist():
    if not (name.startswith('artifacts/') and name.endswith('.zip')):
        continue
    identity = int(Path(name).stem.removeprefix('artifact-'))
    raw = hz.read(name)
    item = metadata[identity]
    assert len(raw) == item['size_in_bytes'] and 'sha256:' + sha(raw) == item['digest']
    with zipfile.ZipFile(io.BytesIO(raw)) as az:
        assert az.testzip() is None and len(az.namelist()) == len(set(az.namelist()))
        record = {'artifact_id': identity, 'bytes': len(raw), 'sha256': sha(raw), 'members': az.namelist()}
        if 'static.stdout' in az.namelist():
            findings = json.loads(az.read('static.stdout'))
            process = json.loads(az.read('static.process.json'))
            assert len(findings) == 80 and process['exit_code'] == 1
            record['static_findings'] = dict(Counter(row['code'] for row in findings))
            record['bootstrap_text_present'] = 'bootstrap-pip.txt' in az.namelist()
        if 'bindiff.json' in az.namelist():
            report = json.loads(az.read('bindiff.json'))
            assert report['status'] == 'passed' and report['mocked'] is False
            assert len(report['checks']) == 7 and all(c['status'] == 'passed' for c in report['checks'].values())
            digest = report['checks']['end_to_end']['semantic_sha256']
            assert digest == report['checks']['no_network']['semantic_sha256'] == '77f36f7aac14a6e321c2c6aba9e0c7e3ca6cdba3f690fc18d188ca987b88e181'
            record['synthetic_native_checks'] = 7
            record['ordinary_and_denied_semantic_sha256'] = digest
        if 'verdict.json' in az.namelist():
            record['verdict'] = json.loads(az.read('verdict.json'))
        artifacts.append(record)
write(ROOT / 'qa/hosted-14ef-root-review/archive-and-source-review.json', {
    'at': datetime.now(timezone.utc).isoformat(), 'source': source['sha'], 'preview': preview['sha'],
    'tree': source['tree']['sha'], 'archive_sha256': hosted_hash, 'members_verified': len(hrows),
    'git_source_snapshots_verified': len(hsources), 'fresh_api_source_and_preview_equal': True,
    'original_log_deliveries_verified': logs, 'original_api_digest_verified_artifacts': artifacts,
    'qualification': 'Historical PR-preview evidence only; Windows source guard and static scanner remain failed at this source.',
    'limits': ['No canonical release-source, new candidate, actual real-driver accuracy, Windows native or packaging acceptance.',
               'Generic source-guard logs omit offending path and stat fields; Windows API cause remains a separately supported inference.']})
