"""Verify all immutable PW02 design/author/reviewer packets without executing them."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/c7a9e8d98848')
REPO = ROOT / 'patchtrace'


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', '-C', str(REPO), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def counts(raw):
    result = dict(passed=0, failed=0, errors=0, skipped=0)
    for case in ET.fromstring(raw).findall('.//testcase'):
        key = ('failed' if case.find('failure') is not None else
               'errors' if case.find('error') is not None else
               'skipped' if case.find('skipped') is not None else 'passed')
        result[key] += 1
    return result


author = ROOT / 'pw02-local-packages/docs/qa/autonomous-ci-20261118'
packets = [
    ('design', ROOT / 'qa/pw02-local-package-design/evidence.zip', ROOT / 'qa/pw02-local-package-design/manifest.json',
     'f1682ef246205723226d8b1ef3cf5a3e16cc003162bb98f3377db9302e84b1b4',
     'source-5bbb/', '5bbb925694b89ddc77e2aae1ea36c9f563c7760d'),
    ('author-first', author / 'pw02-contracts/evidence.zip', author / 'pw02-contracts/manifest.json',
     'f739c4f81f7203e2d9332532c0334c796998308548b606eae164ee46acacd121',
     'source-70849637/', '7084963767d031e08ded1c2c90ca6f4fa9a783ec'),
    ('independent-first', ROOT / 'qa/pw02-contracts-independent.zip', ROOT / 'qa/pw02-contracts-independent/manifest.json',
     '7b0ab0f3a7ef6cdf00527ac9c04f99d6ef4f0c40cc8eab8f0825a39550c34cb0',
     'source-c5027aff/', 'c5027aff98e02844e45902d76e87981962b770bb'),
    ('author-ascii', author / 'pw02-ascii-selection/evidence.zip', author / 'pw02-ascii-selection/manifest.json',
     '2dff72c0571cd205c74508a45342e2a84d06996c36668b6f84d7ef38f93b0f4e',
     'source-64583964/', '645839646a68815ee1822ee61039af42d583903a'),
    ('independent-ascii', ROOT / 'qa/pw02-ascii-independent.zip', ROOT / 'qa/pw02-ascii-independent/manifest.json',
     '706facac4413312265763b66bd90142a7360496107bd7f1bf1ab56be418f2df2',
     'source-64583964/', '645839646a68815ee1822ee61039af42d583903a'),
]
results = []
for label, archive, manifest_path, digest, prefix, source in packets:
    assert sha(archive.read_bytes()) == digest, label
    manifest = json.loads(manifest_path.read_text())
    payloads = manifest.get('files', manifest.get('members', manifest))
    rows = {r['path']: r for r in payloads} if isinstance(payloads, list) else payloads
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist()))
        added_manifest = {'manifest.json'} if 'manifest.json' in z.namelist() and 'manifest.json' not in rows else set()
        assert set(z.namelist()) == set(rows) | added_manifest, label
        if added_manifest:
            assert z.read('manifest.json') == manifest_path.read_bytes()
        snapshots = []
        for name, row in rows.items():
            raw = z.read(name)
            assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], (label, name)
            if name.startswith(prefix):
                path = name[len(prefix):]
                assert raw == git('show', source + ':' + path), (label, path)
                snapshots.append(path)
        junit = {name: counts(z.read(name)) for name in z.namelist() if name.endswith('.xml')}
        if label == 'author-first':
            assert junit['final.xml'] == dict(passed=273, failed=0, errors=0, skipped=0)
            assert junit['red.xml'] == dict(passed=110, failed=157, errors=0, skipped=0)
            assert junit['edge-red.xml'] == dict(passed=267, failed=6, errors=0, skipped=0)
        if label == 'independent-first':
            assert junit['ascii-basename-assertions.xml'] == dict(passed=2, failed=1, errors=0, skipped=0)
            assert junit['author-affected.xml'] == dict(passed=273, failed=0, errors=0, skipped=0)
            assert junit['independent-controls.xml'] == dict(passed=16, failed=0, errors=0, skipped=0)
        if label == 'author-ascii':
            assert junit['final.xml'] == dict(passed=284, failed=0, errors=0, skipped=0)
            assert junit['red-assertions.xml'] == dict(passed=9, failed=2, errors=0, skipped=0)
        if label == 'independent-ascii':
            assert junit['final-affected.xml'] == dict(passed=281, failed=0, errors=0, skipped=0)
            assert junit['unchanged-external.xml'] == dict(passed=19, failed=0, errors=0, skipped=0)
        if label.startswith('author-'):
            provenance = json.loads(z.read('final-provenance.json'))
            assert provenance['head'] == source and provenance['exit_code'] == 0
            assert not provenance['denied_attempts']
        results.append({'label': label, 'archive': str(archive), 'sha256': digest,
                        'bytes': archive.stat().st_size, 'members_verified': len(z.namelist()),
                        'git_source': source, 'git_snapshots_verified': len(snapshots), 'junit': junit})
original = ROOT / 'qa/pw02-contracts-independent/test_package_ascii_selection.py'
assert sha(original.read_bytes()) == 'a6940bb6a42a006192deeb62f9d66faf0cf57e170b26918e8e5beb78cfcdfcfd'
assert original.read_bytes() == (ROOT / 'qa/pw02-ascii-independent/test_package_ascii_selection.py').read_bytes()
assert not git('diff', '645839646a68815ee1822ee61039af42d583903a',
               'dc4ebf9ccf04abc284ffe334b858c6d39047b68d', '--', 'src', 'tests', 'tools', '.github')
out = ROOT / 'qa/pw02-contracts-root-review'
out.mkdir(exist_ok=True)
record = {'at': datetime.now(timezone.utc).isoformat(), 'source': '645839646a68815ee1822ee61039af42d583903a',
          'packets': results, 'original_ascii_probe_unchanged': True,
          'blocking_findings': [], 'limits': ['Pure contracts/path/budget/platform slice only; no production caller wired.',
              'Constructed metadata is not evidence of actual decoder or reverified PE observations.',
              'Native Windows FDI, owned staging, service/CLI integration and frozen journey remain open.']}
with (out / 'archive-and-source-review.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
