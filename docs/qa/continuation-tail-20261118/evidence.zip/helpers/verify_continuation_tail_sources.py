"""Account for every source/test/tool/workflow/schema change since actual PR 316."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
BASE = '55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
PATHS = ('src', 'tests', 'tools', '.github', 'pyproject.toml', 'docs/schemas')
EXPECTED_SOURCE = '068513a72e8a1412ce3960d3024c462d68d51376'
OWNERS = {
    'attempt-diagnostics': ('36e14051a4d36f5c66df0186f037a4905b01bf05', '7b4402a0d78dfd33852a79585a82374ce365104e'),
    'named-superseded': (BASE, '51f33d5a0f0e7e48868ff184a54635ff92606f96'),
    'directory-publication': ('3faf436a', '843dfec72dcb5751e53d01f217263771dd6d65d2'),
    'highlighter': ('3faf436a', '2bf86c883d4d9185f1fb845a7083f73c5541f342'),
    'pin-fixture': ('3faf436a', 'e4ee7ca4b8178db159b0edf16e2afbf59363b4a8'),
    'synthetic-f8': ('3faf436a', '316b0f12fd0180a597366bdec80fa768bdc59fe6'),
    'windows-bindiff': ('7023c3ad', '857a78e93dd8072c8517c58a31ff14941ce16e8b'),
    'r2-retention': ('3faf436a', '8f0864277d29d3d77a22ee8b30cede7146aa0c9b'),
    'coff-compatibility': ('d5d995d6f5c76d4cb2cba7424a997ac9850c6135', 'ce093ec56260944869fa28e12c26c79eb1dd4c78'),
    'aa-classification': ('740869debb111f8edbef33899316e4c75e6fdf7a', '9bd17bbecb54f5a3de05d235a1617a3d2f196883'),
    'static-receipt-upload': ('740869debb111f8edbef33899316e4c75e6fdf7a', '7adcecd72e7476746819e30937dfc3ca09c01f1e'),
    'saved-scope': ('ae0b1660e0cc71c51698d70a685ceeb646619184', 'a7f6c9c41b3772dc33a787e100097c085389a594'),
    'pw02-pure-contracts': ('7d2c6662fa789976427b632a7c96dd0d2b365f0e', '645839646a68815ee1822ee61039af42d583903a'),
    'windows-source-stat': ('c7d3f25858cfefbacbd8ea4022b3d13e1e2aed2a', '80df2735ea9001b7ba5f9aacf95614f280e51948'),
    'immutable-action-references': ('c7d3f25858cfefbacbd8ea4022b3d13e1e2aed2a', '3b3c3d6346c644f04a2e69d9835f147652436535'),
    'tier-action-policy': ('693d0bc79762cec84f10764cdb9713568aa2792b', 'f6cc9a18b1bcaf851faa5fe36032412f3c6f2626'),
}


def git(*args: str) -> str:
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()


def blob(ref: str, path: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(REPO), 'show', ref + ':' + path])


assert git('rev-parse', 'HEAD') == EXPECTED_SOURCE
assert not git('status', '--porcelain')
subprocess.run(['git', '-C', str(REPO), 'merge-base', '--is-ancestor', BASE, 'HEAD'], check=True)
claims = {}
for owner, (start, end) in OWNERS.items():
    for path in git('diff', '--name-only', start, end, '--', *PATHS).splitlines():
        claims.setdefault(path, []).append((owner, end))
changed = set(git('diff', '--name-only', BASE, 'HEAD', '--', *PATHS).splitlines())
assert changed == set(claims), {'unowned': sorted(changed-set(claims)), 'unexpected': sorted(set(claims)-changed)}
files = {}
for path, owners in sorted(claims.items()):
    actual = blob('HEAD', path)
    matching = [owner for owner, ref in owners if actual == blob(ref, path)]
    assert matching, (path, owners)
    assert actual == (REPO / path).read_bytes()
    files[path] = dict(owners=owners, matching_owners=matching, bytes=len(actual),
                       sha256=hashlib.sha256(actual).hexdigest(), git_blob=git('rev-parse', 'HEAD:' + path))
source = git('rev-parse', 'HEAD')
receipt = dict(source=source, tree=git('rev-parse', 'HEAD^{tree}'), base=BASE,
               base_is_ancestor=True, all_changed_paths_owned=True, files=files,
               manual_production_conflict_resolutions=0)
out = ROOT / 'qa/continuation-tail-integration' / ('source-preservation-' + source[:8] + '.json')
assert not out.exists()
out.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(dict(source=source, tree=receipt['tree'], reviewed_paths=len(files),
                     all_owner_bytes_preserved=True)))
