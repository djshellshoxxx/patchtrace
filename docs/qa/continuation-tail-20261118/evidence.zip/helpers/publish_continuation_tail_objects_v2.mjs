// Same publication semantics; independently read immutable binary chunks in batches.
(async function () {
  const plan=load("tailPublicationPlan"), map=load("tailPublicationMap"), blobs=load("tailPublicationBlobs"), rows=load("tailPublicationRows");
  const start=rows.length, end=Math.min(start+(load("tailPublicationBatchLimit")??8),plan.length);
  function body(r) {
    if(r.isError) throw Error(JSON.stringify(r));
    let d=r.structuredContent;
    if(d && typeof d.content==="string") {try {d=JSON.parse(d.content);}catch{}}
    if(d?.sha)return d;
    for(const item of r.content??[])if(item.type==="text"){try{const p=JSON.parse(item.text);if(p.sha)return p;}catch{}}
    throw Error("Unrecognized Git object response: "+JSON.stringify(r).slice(0,1200));
  }
  for(let i=start;i<end;i++) {
    const c=plan[i], parent=map[c.parents[0]];
    if(!parent || c.parents.length!==1 || !c.message.includes("[no release]")) throw Error("Invalid chain "+i);
    const elements=[];
    for(const e of c.elements) {
      if(e.type!=="blob")throw Error("Unsupported tree entry");
      if(e.binary_blob_sha) {
        const expected=e.binary_blob_sha;
        if(!/^[a-f0-9]{40}$/.test(expected))throw Error("Invalid blob id");
        if(!blobs[expected]) {
          const path="/workspace/scratch/c7a9e8d98848/ops/publication-blobs/"+expected;
          if(e.local_file!==path)throw Error("Unexpected local binary path");
          const m=await tools.exec_command({cmd:`python -c 'import json,hashlib; d=open("${path}","rb").read(); print(json.dumps({"bytes":len(d),"git_blob":hashlib.sha1(b"blob "+str(len(d)).encode()+b"\\0"+d).hexdigest(),"sha256":hashlib.sha256(d).hexdigest()}))'`,max_output_tokens:1000});
          if(m.exit_code!==0)throw Error("Cannot inspect binary");
          const meta=JSON.parse(m.output); if(meta.git_blob!==expected)throw Error("Local binary identity drift");
          const chunks=[];
          for(let group=0;group<meta.bytes;group+=98304*8) {
            const jobs=[];
            for(let offset=group;offset<Math.min(meta.bytes,group+98304*8);offset+=98304) {
              const length=Math.min(98304,meta.bytes-offset);
              jobs.push({offset,length,promise:tools.exec_command({cmd:`python -c 'import sys,base64; f=open("${path}","rb"); f.seek(${offset}); sys.stdout.write(base64.b64encode(f.read(${length})).decode("ascii"))'`,max_output_tokens:120000})});
            }
            const results=await Promise.allSettled(jobs.map(j=>j.promise));
            for(let k=0;k<results.length;k++) {
              const result=results[k], j=jobs[k];
              if(result.status!=="fulfilled" || result.value.exit_code!==0 || result.value.output.length!==4*Math.ceil(j.length/3))throw Error("Binary chunk incomplete at "+j.offset);
              chunks.push(result.value.output);
            }
          }
          const created=body(await tools.mcp__codex_apps__github_create_blob({repository_full_name:"djshellshoxxx/patchtrace",encoding:"base64",content:chunks.join("")}));
          if(created.sha!==expected)throw Error("Created binary identity mismatch");
          blobs[expected]=created.sha; store("tailPublicationBlobs",blobs);
        }
        elements.push({path:e.path,mode:e.mode,type:"blob",sha:blobs[expected]});
      } else if(typeof e.content==="string") elements.push({path:e.path,mode:e.mode,type:"blob",content:e.content});
      else throw Error("Unsupported deletion or empty element");
    }
    const tree=body(await tools.mcp__codex_apps__github_create_tree({repository_full_name:"djshellshoxxx/patchtrace",base_tree_sha:c.parent_tree,tree_elements:elements}));
    if(tree.sha!==c.tree)throw Error("Tree identity mismatch at "+c.local_sha);
    const commit=body(await tools.mcp__codex_apps__github_create_commit({repository_full_name:"djshellshoxxx/patchtrace",parent_sha:parent,tree_sha:c.tree,message:c.message+"\n\nReviewed local commit: "+c.local_sha+"\nOriginal author and source history retained in the candidate QA archive."}));
    map[c.local_sha]=commit.sha;
    rows.push({local_sha:c.local_sha,remote_sha:commit.sha,tree:c.tree,remote_parent:parent,local_parent:c.parents[0],created_utc:new Date().toISOString()});
    store("tailPublicationMap",map);store("tailPublicationRows",rows);
  }
  const record={base_remote:"14efc52369146f4a638b7d688208736a05321bc0",binary_blobs:blobs,commit_map:map,commits:rows,ref_updated:false};
  const path="/workspace/scratch/c7a9e8d98848/qa/continuation-tail-publication/objects-"+String(rows.length).padStart(3,"0")+".json";
  const payload=JSON.stringify(record,null,2)+"\n";
  await tools.apply_patch("*** Begin Patch\n*** Add File: "+path+"\n"+payload.split("\n").slice(0,-1).map(line=>"+"+line).join("\n")+"\n*** End Patch");
  text({created_this_batch:rows.length-start,total_created:rows.length,planned:plan.length,last:rows.at(-1),ref_updated:false});
})()
