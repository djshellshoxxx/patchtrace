"""Remove only inspected, completed branch-backed checkouts; preserve support data."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import shutil
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/c7a9e8d98848')
OUT = ROOT / 'qa/continuation-tail-integration/cleanup'
NAMES = ('static-scan-receipt', 'ci-review', 'engine-review', 'report-review',
         'codetext-window-guard', 'cvrf-freshness', 'saved-search',
         'named-superseded', 'r2-evidence-retention', 'windows-bindiff-network')
OUT.mkdir(parents=True, exist_ok=False)

def git(path, *args):
    return subprocess.check_output(['git', '-C', str(path), *args], text=True).strip()

rows = []
support = {}
before_free = shutil.disk_usage(ROOT).free
for name in NAMES:
    path = ROOT / name
    assert path.is_dir() and not path.is_symlink()
    assert not git(path, 'status', '--porcelain=v1', '--untracked-files=all')
    branch = git(path, 'symbolic-ref', 'HEAD')
    head = git(path, 'rev-parse', 'HEAD')
    assert branch.startswith('refs/heads/') and git(ROOT / 'patchtrace', 'rev-parse', branch) == head
    ignored = git(path, 'ls-files', '--others', '--ignored', '--exclude-standard').splitlines()
    for rel in ignored:
        parts = Path(rel).parts
        assert '__pycache__' in parts or parts[0] in ('.hypothesis', '.pytest_cache', '.ruff_cache'), (name, rel)
        p = path / rel
        assert p.is_file() and not p.is_symlink(), p
        if '__pycache__' not in parts:
            data = p.read_bytes()
            support[f'{name}/{rel}'] = data
    rows.append({'worktree': str(path), 'branch': branch, 'head': head,
                 'ignored_files': ignored, 'status': 'clean', 'branches_preserved': True})

manifest = {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
            for name, data in support.items()}
archive = OUT / 'completed-test-support.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED) as z:
    for name, data in sorted(support.items()):
        z.writestr(name, data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(manifest)
    for name, row in manifest.items():
        data = z.read(name)
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']

preflight = {'at': datetime.now(timezone.utc).isoformat(), 'worktrees': rows,
             'support': manifest, 'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
             'disk_free_before': before_free,
             'disposable_data': 'Only reproducible __pycache__ bytecode is omitted from support archive.'}
(OUT / 'preflight.json').write_text(json.dumps(preflight, indent=2) + '\n')
results = []
for row in rows:
    path = Path(row['worktree'])
    assert not git(path, 'status', '--porcelain=v1', '--untracked-files=all')
    assert git(path, 'rev-parse', 'HEAD') == row['head']
    result = subprocess.run(['git', '-C', str(ROOT / 'patchtrace'), 'worktree', 'remove', str(path)],
                            capture_output=True, text=True, check=False)
    record = {'worktree': str(path), 'exit': result.returncode,
              'stdout': result.stdout, 'stderr': result.stderr,
              'branch_head_after': git(ROOT / 'patchtrace', 'rev-parse', row['branch'])}
    results.append(record)
    (OUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    assert record['branch_head_after'] == row['head']
    assert result.returncode == 0, record
receipt = {'at': datetime.now(timezone.utc).isoformat(), 'completed': len(results),
           'disk_free_before': before_free, 'disk_free_after': shutil.disk_usage(ROOT).free,
           'support_files_retained': len(manifest),
           'archive_sha256': preflight['archive_sha256'], 'branch_heads_unchanged': True,
           'no_force_or_branch_deletion': True}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
