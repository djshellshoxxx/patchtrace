# Hosted CI checkpoint — 2026-11-02 09:32 UTC

Read-only snapshot. Current commits and synthetic merge trees are bound in `current-0932.json.gz`; no approval, merge, workflow dispatch, review-thread resolution or scanner suppression was performed. This is an additive checkpoint after the immutable 09:05 archive and hosted-Linux delta, not a replacement for their original logs. Cancellation and skipped review states are not passing gates.

| PR | Current head | Tree | Current gate evidence |
| --- | --- | --- | --- |
| 151 | `9c468bc75077484c1780305d7cc927b30fd0bc8b` | `7841c1bea17657c0085015c429520d12a01c823b` | QA `41416413045` still running; Linux Qt 2/4 completed 8,700 passes. Native PR/push runs each 4/5 passed with one still running. Sonar passed. Current CodeRabbit review has a substantive post-link-cleanup finding described below. |
| 152 (draft) | `51a9b4af02acb6078f8e06028aa4374eb381766f` | `47e5221f4209d2a2ce3846a37171aa22f35a13e7` | Linux full passed 19,314 tests; Windows full and 3 Qt jobs still running. Linux Qt 3/4 passed 8,580 and 4/4 passed 8,760. Both native five-variant runs, both wheels probes and live unified Linux/Windows passed. Live rizin and corpus remain deliberately blocked by `rz-diff-orientation-unverified`. Sonar failed with saved annotations. Draft remains outside merge consideration. |
| 153 | `6f923758efb57e3f19a43b5b1d2c1ba8319e1823` | `99031dd843ea50b22a73c2eb1f5904f1c062ae49` | New QA `41418774232` queued/running. Native PR `41418774144` all five passed; push `41418767357` two passed, one running, two queued. Sonar passed. CodeRabbit check `125189273603` explicitly skipped: “Review paused.” Prior-head full QA was cancelled and does not qualify this head. |
| 157 | `bb98bae3cf0a3b6a38a298a14186d7f4e1c9c151` | `ba2e53eae575956b60a4adcea7decfb85b065d3d` | Linux full passed 18,581 tests. Linux Qt 2/4, 3/4, 4/4 passed 8,700 / 9,640 / 9,060 repetitions. Windows full, Windows Qt, Linux Qt 1/4 remain running. Corpus succeeded, zero failing cases. Current Sonar suite `112234018741` remains queued with no check runs; no current Sonar pass. Native workflow is outside the actual changed-path trigger scope, as separately recorded. |

## Current review boundaries

PR 151 CodeRabbit review `5734146359`, submitted 09:02:35 on exact `9c468bc7`, includes an outside-diff finding at `verified_backup.py:270–288`: a target published with `os.link` can remain after `_remember` returns false. The reviewer claims later discovery may trust it for history pruning and suggests removing only the inode-owned target. This has been relayed for source/contract verification; the report alone does not prove the claim or approve the proposed cleanup. URL: https://github.com/djshellshoxxx/patchtrace/pull/151#pullrequestreview-5734146359 .

PR 153's context-identity and malformed-field diagnostic threads are now resolved. The current automated review was skipped, not approved. Older revision-order-policy comments remain open; the saved isolated namespace control disproves the namespace-construction crash claim. No invented date ordering was introduced by this audit.

PR 157's order-key and credit-completion findings are resolved; the latest CodeRabbit body only requests documentation spacing, for which no CI reset is justified. Older long-name/retention-policy findings remain contract review items. The earlier Sonar failure comment is not treated as a current-head analysis result while its current suite is queued.

## Local/hosted same-tree inventory and test dependency review

The original hosted PR 152 Linux JUnit is hash-verified in the previous delta. Same-tree comparison with local `4a82fd3` found 35 locally passing workflow-contract tests replaced by three hosted module skips because `yaml` was absent. Exact inventories are included here. The local AF_UNIX failure passed on hosted Linux; the root's isolated standard-library control separately attributes local EPERM to the host. The original local failure is preserved, with no skipped or weakened test.

The independently reviewed pending change adds only `PyYAML>=6,<7` to the `dev` optional dependency list and updates its comment. The existing QA, Qt and package install steps already include the dev extra. All runtime dependencies, existing constraints and all workflow files are unchanged. Review receipt records exact file hashes and baseline `eccfb8d587f94e927f857fad248531a002ecc36c`. Root owns the existing 35-test validation; this reviewer did not duplicate that run or edit source.

## Preserved cancelled runs

Newly saved originals for prior PR 153 head `9ae5731c` are jobs `125175485017` (Linux) and `125175485065` (Windows). Both were cancelled on publication of `6f923758`. The Windows log records KeyboardInterrupt; neither supplies a completed full-suite gate. Earlier cancelled-head evidence remains in the 09:05 archive.

No slice has all current applicable gates plus substantive review findings settled at this snapshot.
