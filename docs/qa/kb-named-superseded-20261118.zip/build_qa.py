"""Seal the authored warning-repair evidence without changing any prior raw result."""
from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import re
import subprocess
from xml.etree import ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/c7a9e8d98848/named-superseded')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/named-superseded')
SOURCE = '51f33d5a0f0e7e48868ff184a54635ff92606f96'
BASE = '55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
assert not subprocess.check_output(['git', 'diff', SOURCE, '--', 'src', 'tests'], cwd=ROOT)

gates = []
for label in ['red', 'red-corrected', 'historical-red', 'focused-green', 'affected', 'historical-green']:
    suite = ET.parse(OUT / (label + '.xml')).getroot().find('testsuite')
    counts = {key: int(suite.attrib[key]) for key in ['tests', 'failures', 'errors', 'skipped']}
    counts['passed'] = counts['tests'] - counts['failures'] - counts['errors'] - counts['skipped']
    summary = (OUT / (label + '.log')).read_text().splitlines()[-1]
    gates.append({'id': label, **counts, 'summary': summary,
                  'pytest_seconds': float(re.search(r' in ([0-9.]+)s$', summary)[1]),
                  'junit_seconds': float(suite.attrib['time']),
                  'command': json.loads((OUT / (label + '-command.json')).read_text())})
receipt = {'source': SOURCE, 'tree': subprocess.check_output(['git', 'rev-parse', SOURCE + '^{tree}'],
                                                          cwd=ROOT, text=True).strip(),
           'base': BASE, 'branch': 'codex/kb-named-superseded-20261118',
           'spec_test_commit': '58e45dd60dd272bd342551509aa1cdab7c61ae42',
           'fixture_correction_commit': '1f3d4e4fc69b2a4cc63c543c07a29fa3249b6d36',
           'created_at': datetime.now(UTC).isoformat(), 'gates': gates,
           'historical_control_sha256': '5933280cb0f685f2ec129750aecb4a1859c67ed0de178ef4b1f358711d05a665',
           'initial_red_classification': {'actual_index_omission': 9, 'socket_guard_preceded_ssl_import': 9,
                                          'existing_status_label_abbreviates_text': 2},
           'independent_review': 'Pending root; author results alone do not authorize publication or merge.',
           'limits': ['32 new cases are included in the 411-case gate; historical controls overlap and are not additive.',
                      'Desktop scope-file selection is not implemented. The existing presenter receives a real scoped Outcome through an injected executor.',
                      'Synthetic/adversarial inputs and an existing factual projection are local controls, not native/live/provider compatibility.',
                      'No schema, source admission, native revision ordering, status, exit code, acquisition or target execution changed.']}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')

payloads = {}
for path in sorted(OUT.rglob('*')):
    if not path.is_file() or path.name == 'manifest.json':
        continue
    if any(part in {'__pycache__', '.pytest_cache'} for part in path.relative_to(OUT).parts):
        continue
    if path.name.endswith(('.pyc', '.lock', '-wal', '-shm')):
        continue
    payloads[path.relative_to(OUT).as_posix()] = path.read_bytes()
manifest = {'source': SOURCE, 'files': {name: {'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                                      for name, data in payloads.items()}}
manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
(OUT / 'manifest.json').write_bytes(manifest_bytes)
archive = ROOT / 'docs/qa/kb-named-superseded-20261118.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, data in {**payloads, 'manifest.json': manifest_bytes}.items():
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        bundle.writestr(info, data)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for name, expected in manifest['files'].items():
        data = bundle.read(name)
        assert len(data) == expected['size'] and hashlib.sha256(data).hexdigest() == expected['sha256']
sha = hashlib.sha256(archive.read_bytes()).hexdigest()
text = f'''# Explicitly selected superseded sources — authored QA (2026-11-18)

Source: `{SOURCE}`; tree: `{receipt['tree']}`.
Base: actual published PR #316 `{BASE}`.
Branch: `codex/kb-named-superseded-20261118`.

## Result and behavior

The two-file source change restores a bounded explanation for an explicitly
selected older source whose matching rows are withheld. `index._lookup` derives
the named sources from superseded rows **after product filtering** and only for
`provided_files`/`mixed` explicit document IDs. `_warnings` emits one deterministic
`NAMED_SUPERSEDED` line: the first five distinct full source IDs in lexical order,
then the exact remaining count. Existing source IDs are validated 64-character
lowercase hexadecimal digests. With five IDs and a maximum supported-platform
source count, the fixed wording is 485 characters, below the existing 500-character
retained-warning cap.

`service._search_outcome` uses the displayed product's named warning, carries it
into JSON and `Outcome.text`, and omits the incorrect ordinary negative sentence
only when this explanation applies. Status, exit codes, active rows, cards,
coverage, source admission, native ambiguity and conflict handling are unchanged.
The generic CLI writer and desktop source have no edits.

This selectively recovers B2-C1 from the frozen semantic batch, without importing
the old implementation. The batch-2 observation at `3be3af16` remains historical;
this later repair does not rewrite its original failure or disposition window.

## Source and test chronology

| Snapshot | Content |
|---|---|
| `58e45dd60dd272bd342551509aa1cdab7c61ae42` | Specification and 32 new behavioral controls before source edits |
| `1f3d4e4fc69b2a4cc63c543c07a29fa3249b6d36` | Fixture-only correction before source edits: initialize SSL before the no-socket fixture, and inspect the full details pane while preserving the existing abbreviated status label |
| `{SOURCE}` | Two approved production files, 13 insertions / 4 deletions |

The first run is retained unchanged: **20 failed / 12 passed** (1.37 s).
Nine failures reached the actual index omission; nine hit the test's socket-class
guard before stdlib SSL initialized; two wrongly expected the deliberately
abbreviated status label to retain full text. Those eleven harness expectations
were corrected explicitly. No production behavior was changed to satisfy them.
The corrected source-baseline run is **18 failed / 14 passed** (2.08 s), with
zero collection/setup errors; every remaining failure identifies the explanation
omission. Its exact files and both test snapshots are archived.

## Qualification

| Invocation | Actual result | Scope |
|---|---|---|
| `red-corrected` | 18 failed / 14 passed, 2.08 s | Corrected new controls against unchanged PR #316 production code |
| `historical-red` | 1 failed, 0.37 s | Byte-for-byte original historical named-source control against unchanged production code |
| `focused-green` | 32 passed, 1.89 s | Initial working-tree source repair; dirty state and exact production hashes are recorded |
| `affected` | 411 passed / 0 skipped, 15.67 s | Clean exact source `{SOURCE[:8]}`, 15 current files |
| `historical-green` | 1 passed, 0.30 s | Same unchanged historical node, separate invocation |
| Actual headless CLI | 8 calls passed; exits 0, 4, 4, 4, 4, 0, 4, 0 | Import, named KB/CVE JSON/text, named active source, cached old and cached CVE controls |
| Whole Ruff / whitespace | Passed | `ruff check src tests tools`; `git diff --check 55f3d074 51f33d5a` |

The 411-case gate includes the 32 new controls and current index, scope, service,
CLI, end-to-end, original bugfix, native revision, card provenance, CVRF, CSAF,
investigation service/dialog and **global tooltip registry sweep**. Absolute
`PYTHONPATH` pins the worktree's source/tests; Qt is offscreen. The actual child
CLI calls assert no PySide6 module is imported and retain every stdout/stderr and
exit. Durations above are the terminal pytest summaries; JSON separately retains
JUnit durations. Overlapping invocations are not additive coverage or completion.

The desktop control exercises the existing real dialog and worker ownership with
a real scoped service result. Its injected executor supplies the file scope;
the desktop dialog itself does not expose a new scope-file control. The bounded
status label and full plain-text details pane keep their existing limits.
No native/manual GUI, live provider, network, target or packaged acceptance is claimed.

## Preserved historical evidence

Original control file:
`tests/test_kbc_bugfixes_20261029.py` from historical tip
`798e11ef345ed7a7a65508a466eaf77ee85ef77c`, node
`test_kbc12_a_named_superseded_file_says_its_hit_is_not_counted`.
Full-file SHA-256:
`5933280cb0f685f2ec129750aecb4a1859c67ed0de178ef4b1f358711d05a665`.

The archive includes this exact file, its original batch-2 red/output observations,
the new-baseline red and source green, all new initial/corrected tests, four
source/spec/test snapshots, complete production/spec-test diffs, exact command
records, JUnit, Ruff, raw CLI outputs and authored temporary workspace inputs.
The original batch-2 packet remains independently sealed at its own comparison
source and is not overwritten.

## Archive and remaining gates

[Sealed evidence](kb-named-superseded-20261118.zip): **{len(payloads) + 1} members**,
**{archive.stat().st_size:,} bytes**. SHA-256:
`{sha}`.

Every payload size and SHA-256 is in `manifest.json`; archive integrity and every
member hash were verified after reopening it. Python caches and transient SQLite
lock/WAL/SHM files are excluded. Source/tests are unchanged from `{SOURCE[:8]}`.

Root's independent review is pending at this authored checkpoint. Integration,
exact combined/hosted qualification and any release/platform/package/manual gates
remain separate. This receipt supplies no whole-branch closure, native acceptance
or product-completion percentage.
'''
(ROOT / 'docs/qa/kb-named-superseded-20261118.md').write_text(text)
print(json.dumps({'archive': str(archive), 'members': len(payloads) + 1, 'bytes': archive.stat().st_size,
                  'sha256': sha, 'source': SOURCE, 'gates': [{k: g[k] for k in
                    ['id', 'passed', 'failures', 'errors', 'skipped']} for g in gates]}, indent=2))
