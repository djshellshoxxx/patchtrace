"""Actual headless CLI observation on the source-pinned warning candidate; authored data only."""
from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

ROOT = Path('/workspace/scratch/c7a9e8d98848/named-superseded')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/named-superseded/cli')
ORIGINAL = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch2/named-superseded-cli-final')
SOURCE = '51f33d5a0f0e7e48868ff184a54635ff92606f96'
PYTHON = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip() == SOURCE
OUT.mkdir(exist_ok=True)
for name in ['older.json','newer.json','old-scope.json','new-scope.json']:
    shutil.copyfile(ORIGINAL / name, OUT / name)
ids = {name:json.loads((OUT / (name+'-scope.json')).read_text())['doc_ids'][0] for name in ['old','new']}
guard = ("import sys,socket,ssl; "
         "socket.create_connection=lambda *a,**k: (_ for _ in ()).throw(AssertionError('network')); "
         "from patchtrace.cli import main; code=main(sys.argv[1:]); "
         "assert not any(n.startswith('PySide6') for n in sys.modules); sys.exit(code)")
common_old = ['--offline','--scope-file',str(OUT/'old-scope.json')]
commands = [
    ('import',['index','import',str(OUT/'older.json'),str(OUT/'newer.json'),'--json'],0),
    ('named-old-json',['search','KB5099001',*common_old,'--json'],4),
    ('named-old-text',['search','KB5099001',*common_old],4),
    ('named-cve-json',['search','CVE-2099-0001',*common_old,'--json'],4),
    ('named-cve-text',['search','CVE-2099-0001',*common_old],4),
    ('named-new-json',['search','KB5099002','--offline','--scope-file',str(OUT/'new-scope.json'),'--json'],0),
    ('cached-old-json',['search','KB5099001','--offline','--json'],4),
    ('cached-cve-json',['search','CVE-2099-0001','--offline','--json'],0),
]
env=dict(os.environ,PYTHONPATH=str(ROOT/'src'))
records=[]
for label,args,expected in commands:
    command=[PYTHON,'-c',guard,'kb',*args,'--workspace',str(OUT/'workspace')]
    result=subprocess.run(command,cwd=ROOT,env=env,capture_output=True,text=True,timeout=30)
    (OUT/(label+'.stdout')).write_text(result.stdout)
    (OUT/(label+'.stderr')).write_text(result.stderr)
    records.append({'label':label,'command':command,'exit_code':result.returncode,'expected_exit':expected,
                    'stdout':label+'.stdout','stderr':label+'.stderr'})
(OUT/'commands.json').write_text(json.dumps({'source':SOURCE,'cwd':str(ROOT),'env':{'PYTHONPATH':env['PYTHONPATH']},
                                           'commands':records},indent=2)+'\n')
for record in records:
    assert record['exit_code']==record['expected_exit'],record
    assert (OUT/record['stderr']).read_text()=='',record
for label in ['named-old-json','named-cve-json']:
    result=json.loads((OUT/(label+'.stdout')).read_text())
    assert result['status']=='unavailable' and result['result']['edges']==result['result']['cards']==[]
    warnings=[w for w in result['warnings'] if w.startswith('NAMED_SUPERSEDED:')]
    assert len(warnings)==1 and ids['old'] in warnings[0] and len(warnings[0])<=500
    assert result['warnings']==result['result']['warnings']
    text=(OUT/(label.replace('-json','-text')+'.stdout')).read_text()
    assert warnings[0] in text and 'these documents do not list it' not in text
for label in ['named-new-json','cached-old-json','cached-cve-json']:
    result=json.loads((OUT/(label+'.stdout')).read_text())
    assert not any(w.startswith('NAMED_SUPERSEDED:') for w in result['warnings'])
    assert len(result['result']['edges'])==(0 if label=='cached-old-json' else 1)
receipt={'source':SOURCE,'completed_at':datetime.now(UTC).isoformat(),'commands':records,'document_ids':ids,
         'input_sha256':{name:hashlib.sha256((OUT/name).read_bytes()).hexdigest() for name in
                         ['older.json','newer.json','old-scope.json','new-scope.json']},
         'result':'All eight actual headless calls preserve status/evidence and show the selected-old explanation. '
                  'Active and cached positives/negatives retain prior behavior. No target, native engine or network used.'}
(OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Eight actual headless CLI calls passed; exits',','.join(str(record['exit_code']) for record in records))
