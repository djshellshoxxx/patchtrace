from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('/workspace/scratch/c7a9e8d98848/named-superseded')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/named-superseded')
PYTHON = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
label = sys.argv[1]
files = sys.argv[2:] or ['tests/test_kbc_named_superseded.py', 'tests/test_ui_kbc_named_superseded.py']
command = [PYTHON, '-m', 'pytest', '-q', *files, '--junitxml=' + str(OUT / (label + '.xml'))]
env = dict(os.environ, PYTHONPATH=str(ROOT / 'src') + os.pathsep + str(ROOT / 'tests'), QT_QPA_PLATFORM='offscreen')
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
record = {'source': head, 'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=ROOT, text=True).strip(),
          'command': command, 'cwd': str(ROOT), 'env': {k:env[k] for k in ('PYTHONPATH','QT_QPA_PLATFORM')},
          'started_at': datetime.now(UTC).isoformat(),
          'production_sha256': {name:hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in
             ['src/patchtrace/kbcorrelation/index.py','src/patchtrace/kbcorrelation/service.py']},
          'worktree_status': subprocess.check_output(['git','status','--short'],cwd=ROOT,text=True)}
(OUT / (label + '-command.json')).write_text(json.dumps(record, indent=2) + '\n')
with (OUT / (label + '.log')).open('w') as output:
    completed = subprocess.run(command, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT)
record.update(exit_code=completed.returncode, completed_at=datetime.now(UTC).isoformat())
(OUT / (label + '-command.json')).write_text(json.dumps(record, indent=2) + '\n')
print('\n'.join((OUT / (label + '.log')).read_text().splitlines()[-24:]))
print('exit_code',completed.returncode)
