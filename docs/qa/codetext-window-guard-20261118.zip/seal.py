"""Seal the narrow code-highlighter repair with exact-source failures and repeated-scale limits."""
from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/c7a9e8d98848/codetext-window-guard')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/codetext-window-guard')
BASE = '3faf436a3b11c69220641a167cf424e7f4060839'
SPEC = '367953e9ea6e7f0c837b01b01b6354c3b930c71f'
SOURCE = '2bf86c883d4d9185f1fb845a7083f73c5541f342'
HISTORICAL = 'c7fb422c750f1d0e5591277b91492874afd79af7'
NAME = 'codetext-window-guard-20261118'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def raw(sha, path):
    return subprocess.check_output(['git', 'show', sha + ':' + path], cwd=ROOT)

assert git('rev-parse', 'HEAD') == SOURCE
assert not git('status', '--porcelain', '--', 'src', 'tests', 'tools', '.github')
assert git('diff', '--name-only', BASE, SOURCE, '--', 'src').splitlines() == ['src/patchtrace/ui_codetext.py']
assert raw(BASE, 'src/patchtrace/ui_codetext.py') == raw(SPEC, 'src/patchtrace/ui_codetext.py')
historical = OUT / 'historical-controls/test_ui_codetext.py'
assert historical.read_bytes() == raw(HISTORICAL, 'tests/test_ui_codetext.py')
assert hashlib.sha256(historical.read_bytes()).hexdigest() == '238abb33cad9ff066f73564c97ee1215e514735c17aa62ea26a4e39d8f5721e3'

phases = {}
for name in ('red', 'historical-red', 'working-green', 'normal', 'high-dpi', 'historical-green'):
    command = json.loads((OUT / (name + '-command.json')).read_text())
    root = ET.parse(OUT / (name + '.xml')).getroot()
    cases = list(root.iter('testcase'))
    failures = sum(case.find('failure') is not None for case in cases)
    errors = sum(case.find('error') is not None for case in cases)
    skips = [{'test': case.attrib['name'], 'message': node.attrib.get('message', '')}
             for case in cases for node in case.findall('skipped')]
    summary = re.findall(r'(?:\d+ (?:failed|passed|skipped|error|errors)(?:, )?)+ in [\d.]+s',
                         (OUT / (name + '.log')).read_text())[-1]
    phases[name] = {'source': command['source'], 'tree': command['tree'],
                    'product_source_sha256': command['product_source_sha256'],
                    'working_diff': bool(command['working_diff']), 'tests': len(cases),
                    'passed': len(cases) - failures - errors - len(skips),
                    'failed': failures, 'errors': errors, 'skips': skips, 'summary': summary,
                    'junit_seconds': command['suites'][0]['time'],
                    'command_receipt': name + '-command.json'}
assert (phases['red']['failed'], phases['red']['passed']) == (6, 1)
assert (phases['historical-red']['failed'], phases['historical-red']['passed']) == (1, 2)
for name in ('normal', 'high-dpi'):
    assert phases[name]['source'] == SOURCE and not phases[name]['working_diff']
    assert phases[name]['passed'] == 804 and len(phases[name]['skips']) == 1
    assert phases[name]['failed'] == phases[name]['errors'] == 0
assert phases['historical-green']['passed'] == 3 and not phases['historical-green']['failed']
assert phases['working-green']['working_diff']

normal = json.loads((OUT / 'normal-command.json').read_text())
current_paths = set(normal['test_file_sha256']) | {
    'src/patchtrace/ui_codetext.py', 'src/patchtrace/codetext_view.py',
    'src/patchtrace/codetext/model.py', 'src/patchtrace/gui/qt/codediff.py',
    'docs/specs/program-e/WBQ-integration-plan.md', 'docs/modules.md',
}
manifest = {}
for label, sha, paths in [
    ('baseline', BASE, ['src/patchtrace/ui_codetext.py']),
    ('spec-test-first', SPEC, ['tests/test_codetext_window_dispatch.py', 'docs/specs/program-e/WBQ-integration-plan.md']),
    ('source', SOURCE, sorted(current_paths)),
    ('historical', HISTORICAL, ['src/patchtrace/ui_codetext.py']),
]:
    for path in paths:
        data = raw(sha, path)
        dest = OUT / 'snapshots' / label / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        manifest[str(dest.relative_to(OUT))] = {'source': sha, 'path': path,
                                               'git_blob': git('rev-parse', sha + ':' + path),
                                               'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
(OUT / 'source-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(OUT / 'source.patch').write_text(git('diff', BASE, SOURCE, '--', 'src', 'tests', 'docs/modules.md',
                                     'docs/specs/program-e/WBQ-integration-plan.md') + '\n')

# Preserve the original inventory-window contrary observation under its own source identity.
prior = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch3')
for name in ('historical-codetext-command.json', 'historical-codetext-red.log',
             'historical-codetext-red.xml', 'codetext-historical-manifest.json'):
    dest = OUT / 'inventory-window-red' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes((prior / name).read_bytes())

validation = subprocess.run(['git', 'diff', '--check'], cwd=ROOT, text=True, capture_output=True)
assert validation.returncode == 0
(OUT / 'diff-check.log').write_text(validation.stdout + validation.stderr)
receipt = {'contract': 'patchtrace-codetext-dispatch-qa/1', 'prepared_utc': datetime.now(UTC).isoformat(),
           'base': BASE, 'spec_tests': SPEC, 'source': SOURCE, 'source_tree': git('rev-parse', SOURCE + '^{tree}'),
           'historical': HISTORICAL, 'phases': phases,
           'ruff': json.loads((OUT / 'ruff-command.json').read_text()),
           'qt_scale_observation': json.loads((OUT / 'qt-scale-observation.json').read_text()),
           'production_changed_paths': ['src/patchtrace/ui_codetext.py'], 'diff_check_exit': validation.returncode,
           'independent_review': 'pending root at this author checkpoint',
           'limits': ['same nine files executed twice, not additive unique coverage',
                      'existing optional colorspacious validation oracle skipped in both runs',
                      'no final full suite, Windows, native timing, frozen package or manual acceptance',
                      'the report agent separately owns a reported existing combined-registration tooltip collision; this guard does not fix or qualify that broader state'],
           'remote_mutations': False}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
(OUT / 'README.md').write_text('''# Code-highlighter dispatch guard evidence

Base 3faf436a; spec/tests 367953e9; source 2bf86c88. Production scope is one method,
CodeHighlighter.highlightBlock. Full exact SHAs/tree/commands/hashes are in
receipt.json. Source snapshots/patch retain the baseline, spec-first and fixed
source; historical-controls/test_ui_codetext.py is byte-for-byte from c7fb422c.

Six of seven new cases fail on unchanged production code, with the unexpected
window-access failure-boundary positive already passing. The original historical
selection has one failure/two positives. Both original logs/XML remain unchanged.
working-green is explicitly a pre-source-commit working-tree check, not relabeled
as a clean source commit. Final normal and 2x offscreen gates each pass 804 / skip 1;
the unchanged historical three-node replay passes. Overlapping cases are not added.
The optional colorspacious oracle is absent; the skip is not native acceptance.
Separate actual Qt observations confirm device-pixel ratios 1.0 and 2.0.

The fixed callback refuses absent-model, failed-session and outside-window calls
before controller.spans and leaves default block state untouched. Checks and all
span/format work remain inside the existing exception handler. Controller.spans
retains its own checks, and Qt naturally clears the character formats of an
explicitly rehighlighted out-of-window block. There is no document scan, callback
suppression claim, UI seam/cap change, native benchmark or broad historical port.

inventory-window-red/ preserves the earlier batch 3 failure at 55f3 separately from
the same immutable test replay at the 3679 precursor. Root independent review and
final integration are separate. The reported F8 combined-registration tooltip
collision is owned by the report agent, not this slice. No new tips or exemptions
were added, and the current global sweep is in both nine-file gates.

evidence-manifest.json records every other member's size and SHA256. seal.py
reopens the written ZIP and verifies all members. No caches or bytecode are kept.
''')

exclude = {'evidence-manifest.json', 'archive.json', 'seal.log'}
files = sorted(p for p in OUT.rglob('*') if p.is_file() and p.name not in exclude
               and '__pycache__' not in p.parts and '.pytest_cache' not in p.parts and p.suffix != '.pyc')
members = {str(p.relative_to(OUT)): {'bytes': p.stat().st_size,
                                   'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in files}
(OUT / 'evidence-manifest.json').write_text(json.dumps(members, indent=2) + '\n')
archive = ROOT / 'docs/qa' / (NAME + '.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for path in files + [OUT / 'evidence-manifest.json']:
        bundle.write(path, str(path.relative_to(OUT)))
with zipfile.ZipFile(archive) as bundle:
    assert set(bundle.namelist()) == set(members) | {'evidence-manifest.json'}
    assert bundle.testzip() is None
    for name, info in members.items():
        data = bundle.read(name)
        assert len(data) == info['bytes'] and hashlib.sha256(data).hexdigest() == info['sha256'], name
sealed = {'path': str(archive.relative_to(ROOT)), 'members': len(members) + 1,
          'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()}
(OUT / 'archive.json').write_text(json.dumps(sealed, indent=2) + '\n')

text = f'''# Code-highlighter dispatch guard — source and QA receipt

Source **`{SOURCE}`**, tree `{receipt['source_tree']}`, repairs the missing
historical window guard identified by semantic batch 3. Base:
`{BASE}`. Spec/tests-first commit: `{SPEC}`. No remote mutation occurred.

## Change and reason

Qt invokes `highlightBlock` for many document blocks during bulk text installation.
The callback previously called `controller.spans` for every one and repeatedly
set the unchanged block state. The controller correctly rejected off-window
formatting, but the helper dispatch still scaled with the document.

The sole production change is `src/patchtrace/ui_codetext.py::CodeHighlighter.highlightBlock`
(seven added/two removed lines). It returns before dispatch if there is no current
model, the session has failed or the block lies outside that side’s window. It
leaves default block state at `-1` and uses the captured row for valid dispatch.
All checks/span/format work stay inside the existing exception boundary; failures
still retain text, emit one notice and detach on the next event-loop turn.
The controller’s own checks, visible-window margin, model-before-text ordering,
font/mark/selection behavior, UI seam and existing caps remain.

The WBQ contract now distinguishes Qt block callbacks from Python span dispatch.
It explicitly avoids a native timing claim or a requirement to globally clear
previously visited rows on every scroll. The module index maps the seven new
behavior cases, including all three colors/marks combinations, no-model mode,
failure-before-detach, explicit out-of-window rehighlight and unexpected window
access failure. No new module, tooltip, exemption or schema was added.

## Exact-source verification

| Phase | Source/state | Actual result | Pytest summary time |
|---|---|---|---|
| Seven new behavior cases before production change | `367953e9` | 6 failed, 1 passed; 0 setup errors | 0.82 s |
| Three unchanged historical nodes before change | `367953e9` | 1 failed, 2 passed; 0 setup errors | 0.55 s |
| Focused working-tree implementation check | `367953e9` plus retained source diff | 7 passed | 0.68 s |
| Nine affected current files, normal offscreen scale | `2bf86c88` | 804 passed, 1 skipped; 0 failures/errors | 47.74 s |
| Same nine files, 2x offscreen scale | `2bf86c88` | 804 passed, 1 skipped; 0 failures/errors | 48.73 s |
| Unchanged historical three-node replay | `2bf86c88` | 3 passed; 0 skips | 0.58 s |

The repeated scale runs and historical overlaps are not additive coverage or
completion credit. Exact command JSON, raw logs/XML and distinct JUnit durations
are retained. Absolute `PYTHONPATH` pins the active worktree; Python is
`/workspace/scratch/3a6632a6e5ff/venv/bin/python`. Both runs include the actual
global tooltip registry sweep, pane integrations, token/mark/palette tests and
existing scrolling/font/state controls. A separate Qt 6.12.0 observation confirms
`QT_SCALE_FACTOR=1/2` produced actual offscreen device-pixel ratios 1.0/2.0.

The sole skip is `test_simulation_equals_colorspacious_when_it_is_installed`:
“the validation oracle is optional and not a dependency.” It remains a skip,
not a new color-simulation/native acceptance claim. Whole normal Ruff over
`src tests tools` and `git diff --check` pass. No final full-repository/native
Windows/package/manual benchmark ran.

## Immutable historical evidence

Historical tip: `{HISTORICAL}`. The complete
`tests/test_ui_codetext.py` is retained byte-for-byte (16,911 bytes), SHA-256
`238abb33cad9ff066f73564c97ee1215e514735c17aa62ea26a4e39d8f5721e3`.
Selected nodes are `test_bulk_load_skips_span_dispatch_outside_the_window`,
`test_windowed_highlighter_formats_only_the_window` and
`test_scroll_updates_window_within_budget`. The repaired replay reaches and
passes the historical call-count/state checks that the original failure did
not reach. The original batch 3 red at 55f3 and fresh precursor red at 3679 are
preserved under distinct source identities. No old assertion was weakened.

## Sealed packet and boundaries

[Full receipt archive]({NAME}.zip): **{sealed['members']} members**,
**{sealed['bytes']:,} bytes**, SHA-256
**`{sealed['sha256']}`**. Every member was reopened and matched to its
size/SHA-256 manifest after sealing. The packet includes exact baseline,
spec-first/current/historical source snapshots, the complete production diff,
all failures/positives, actual scale observations, commands and checker output.

Root independent review/selective integration is pending at this author checkpoint.
The report agent separately owns a reported pre-existing combined-registration
tooltip collision reached by the F8 journey; this guard neither repairs that
broader state nor claims its qualification. Later combined/full/platform gates
must use their own source. No native timing, Qt callback-count bound, release,
branch closure or product-completion percentage is inferred from these passes.
'''
(ROOT / 'docs/qa' / (NAME + '.md')).write_text(text)

def append(path, marker, body):
    old = path.read_text()
    if marker in old:
        old = old.split(marker, 1)[0]
    path.write_text(old.rstrip() + '\n\n' + marker + '\n\n' + body.strip() + '\n')

append(ROOT / 'docs/qa.md', '## [CODETEXT-WINDOW-DISPATCH-20261118]', '''
Source `2bf86c883d4d9185f1fb845a7083f73c5541f342` adds the missing early
highlighter model/session/window guard, inside the existing failure boundary.
Spec/tests precede source; the original six failing/one positive and unchanged
historical one failing/two positive controls remain. The same nine-file affected
gate passes 804 with one optional colorspacious skip at normal scale and at actual
2x offscreen scale; unchanged historical replay passes three separately. Whole Ruff/diff pass. These are
overlapping source/Qt checks, not additive or native/package acceptance. Root
review and actual combined/full/platform gates remain separate.
[Source and sealed evidence](qa/codetext-window-guard-20261118.md).
''')
append(ROOT / 'tasks/todo.md', '### [CODETEXT-WINDOW-DISPATCH-20261118]', '''
- [x] Specify the dispatch boundary and preserve original current/historical failing controls before source changes.
- [x] Repair only CodeHighlighter.highlightBlock, keeping the fail-closed boundary and controller validation.
- [x] Pin source 2bf86c88; run identical normal/2x nine-file gates (804 passed/one optional skip each), unchanged historical three-node replay and whole Ruff/diff.
- [x] Seal exact source snapshots, failure/positive receipts, actual device-pixel ratios and archive hashes.
- [ ] Root independent review and selective integration with attributed source history.
- [ ] Final combined/full/platform/native/manual/package gates; separate F8 tooltip collision remains owned by its author.
''')
print(json.dumps({'source': SOURCE, 'archive': sealed, 'phases': phases}, indent=2))
