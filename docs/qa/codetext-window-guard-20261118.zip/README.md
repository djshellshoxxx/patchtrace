# Code-highlighter dispatch guard evidence

Base 3faf436a; spec/tests 367953e9; source 2bf86c88. Production scope is one method,
CodeHighlighter.highlightBlock. Full exact SHAs/tree/commands/hashes are in
receipt.json. Source snapshots/patch retain the baseline, spec-first and fixed
source; historical-controls/test_ui_codetext.py is byte-for-byte from c7fb422c.

Six of seven new cases fail on unchanged production code, with the unexpected
window-access failure-boundary positive already passing. The original historical
selection has one failure/two positives. Both original logs/XML remain unchanged.
working-green is explicitly a pre-source-commit working-tree check, not relabeled
as a clean source commit. Final normal and 2x offscreen gates each pass 804 / skip 1;
the unchanged historical three-node replay passes. Overlapping cases are not added.
The optional colorspacious oracle is absent; the skip is not native acceptance.
Separate actual Qt observations confirm device-pixel ratios 1.0 and 2.0.

The fixed callback refuses absent-model, failed-session and outside-window calls
before controller.spans and leaves default block state untouched. Checks and all
span/format work remain inside the existing exception handler. Controller.spans
retains its own checks, and Qt naturally clears the character formats of an
explicitly rehighlighted out-of-window block. There is no document scan, callback
suppression claim, UI seam/cap change, native benchmark or broad historical port.

inventory-window-red/ preserves the earlier batch 3 failure at 55f3 separately from
the same immutable test replay at the 3679 precursor. Root independent review and
final integration are separate. The reported F8 combined-registration tooltip
collision is owned by the report agent, not this slice. No new tips or exemptions
were added, and the current global sweep is in both nine-file gates.

evidence-manifest.json records every other member's size and SHA256. seal.py
reopens the written ZIP and verifies all members. No caches or bytecode are kept.
