"""Retain exact source, environment, invocation and raw outcomes for the guard slice."""
from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/c7a9e8d98848/codetext-window-guard')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/codetext-window-guard')
PYTHON = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
label, scale, *selection = sys.argv[1:]

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

assert selection
files = {str(Path(item.split('::')[0])) for item in selection}
identities = {}
for name in files:
    path = Path(name) if Path(name).is_absolute() else ROOT / name
    assert path.is_file(), path
    identities[name] = hashlib.sha256(path.read_bytes()).hexdigest()
environment = {'PYTHONPATH': str(ROOT / 'src') + ':' + str(ROOT / 'tests'),
               'QT_QPA_PLATFORM': 'offscreen', 'QT_SCALE_FACTOR': scale}
cmd = [PYTHON, '-m', 'pytest', '-q', *selection, '--junitxml=' + str(OUT / (label + '.xml'))]
receipt = {'source': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
           'product_source_sha256': hashlib.sha256((ROOT / 'src/patchtrace/ui_codetext.py').read_bytes()).hexdigest(),
           'working_diff': git('diff', '--', 'src', 'tests'), 'command': cmd, 'cwd': str(ROOT),
           'environment': environment, 'test_file_sha256': identities,
           'started_utc': datetime.now(UTC).isoformat()}
(OUT / (label + '-command.json')).write_text(json.dumps(receipt, indent=2) + '\n')
start = time.monotonic()
with (OUT / (label + '.log')).open('w') as log:
    process = subprocess.run(cmd, cwd=ROOT, env=os.environ | environment,
                             stdout=log, stderr=subprocess.STDOUT, check=False)
receipt.update(exit_code=process.returncode, wall_seconds=time.monotonic() - start,
               finished_utc=datetime.now(UTC).isoformat())
if (OUT / (label + '.xml')).is_file():
    root = ET.parse(OUT / (label + '.xml')).getroot()
    receipt['suites'] = [suite.attrib for suite in root.iter('testsuite')]
(OUT / (label + '-command.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'label': label, 'source': receipt['source'], 'exit_code': process.returncode,
                  'suites': receipt.get('suites')}, indent=2))
print('\n'.join((OUT / (label + '.log')).read_text().splitlines()[-15:]))
raise SystemExit(process.returncode)
