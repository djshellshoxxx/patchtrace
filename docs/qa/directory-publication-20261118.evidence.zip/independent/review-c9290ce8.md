# Independent directory publication review: c9290ce8

## Disposition

One bounded contract defect requires repair: Windows directory reparse metadata
passes the source-stage check. The Linux no-replacement implementation and both
public call paths passed the independent collision/error controls described
below. Native Windows execution remains unverified.

Reviewed source: `c9290ce82b3f1f2463c56c69f5853cb795f70f2c`, tree
`6057df5c999ba412cc24e18a7d51997d4aaf72bc`. The detached worktree is
`/workspace/scratch/c7a9e8d98848/directory-publication-review` and remains clean.
The specification/test precursor is
`b781aae7f0e377857c73b8806ad4c52aa6e52e5d`. No source was edited by this reviewer.

## Inspected scope

Read the complete new `src/patchtrace/directory_publication.py`, both production
integration diffs, and the surrounding `ProjectService.backup` persistence and
`install_offline_bundle` staging, error and cleanup paths. Read the new contract,
module-index entry and all 34 authored controls. The source delta introduces a
single shared publisher and keeps the existing private names as imports.

The API validates absolute, distinct sibling paths and rejects embedded NUL
before converting paths to native strings. Linux uses libc `renameat2` with
`RENAME_NOREPLACE`; unsupported platforms/symbols and syscall errors propagate
without an overwriting fallback. Windows dispatches to `os.rename`. The helper
does not reserve or delete a destination. Existing caller cleanup remains
limited by the explicitly documented stable-parent/private-stage assumptions;
this review does not extend those assumptions into rooted-handle protection.

## Finding: source directory reparse refusal

At the source check in `directory_publication.py`, `stat.S_ISDIR(stage.lstat().st_mode)`
does not establish the promised ordinary-directory/source-link refusal on
Windows. In CPython v3.12.14, `_Py_attribute_data_to_stat` marks actual symlinks
with `S_IFLNK`; other directory reparse points, including junctions, can retain
`S_IFDIR`. Their reparse identity is available in `st_file_attributes` and
`st_reparse_tag`.

The independent controls inject this documented stat-result shape for a
junction and a generic directory reparse point. Both reach `_native_move`
without refusal. An ordinary-directory metadata positive still succeeds. This
is a reproduced portable validation defect supported by the exact interpreter
source; it is not an observed native Windows exploit or a Linux no-replacement
failure. The callers create their own stages, so the finding does not invalidate
the narrower destination-preservation results.

Recommended repair: retain the single `lstat` result and refuse reparse-point
attributes along with non-directory mode. Preserve the positive ordinary
directory behavior, add a portable metadata regression and a native Windows
junction control, and rerun the unchanged independent controls on the exact
repaired source. Root accepted this scope and owns the repair.

Primary sources read:

- CPython v3.12.14 `Python/fileutils.c`:
  https://github.com/python/cpython/blob/v3.12.14/Python/fileutils.c
- Python 3.12 `os.stat`, `os.lstat`, Windows stat-result attributes and rename:
  https://docs.python.org/3.12/library/os.html#os.stat
  https://docs.python.org/3.12/library/os.html#os.rename
- Linux `renameat2` flags/error semantics:
  https://man7.org/linux/man-pages/man2/rename.2.html
- Microsoft directory-move and replacement flags:
  https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-movefileexw

## Independent controls and actual results

The corrected independent module contains 21 cases. It produced **18 passed,
2 failed and 1 skipped**, in 0.30 seconds reported by pytest. The two failures
are the reparse-refusal controls above. The skip is an explicit unavailable
AF_UNIX socket-creation capability (`EPERM`); the destination socket case is
unverified rather than passed.

The passing controls include:

- Both actual public paths, with a foreign empty destination created at the
  libc call boundary, followed either by the real no-replace syscall or an
  injected `ENOSPC`. All four cases preserve the held foreign directory FD's
  link count and identity, the original input bytes and expected stage cleanup.
- Both ordinary public backup/install operations with inert authored data.
- Existing FIFO, dangling-link and empty-directory preservation.
- Six concurrent native Linux publishers: exactly one succeeds and every losing
  stage retains its own bytes.
- Native `EXDEV`, `ENOSYS`, `EINVAL`, `EOPNOTSUPP`, `EINTR` and missing-errno
  failure propagation with no retry/replace/copy fallback. Missing errno is
  translated to `EIO`.
- Ordinary Windows-shaped directory metadata and shared production aliases.

The initial run also executed all 34 authored controls unchanged, all of which
passed. That run's independent subset had 15 passes, three failures and three
fixture setup errors. The three setup errors were the review fixture attempting
to write a sidecar before creating its `exports` directory; the extra failure
was denied AF_UNIX socket creation. The fixture now creates that directory
within its service-close scope and labels the missing socket capability as an
unverified skip. No product assertion was changed.

Both initial and corrected raw logs/XML, command/environment/source records,
the initial probe source, and the frozen corrected probe are retained. The
corrected probe is 9,088 bytes, SHA-256
`821adaf139289250acbade0ff36b0a46bea741c2e6c38062739f9df0e1d45da0`.
Absolute source `PYTHONPATH` points to the detached review tree. No target or
runtime payload was executed and no network operation was part of these tests.

## Remaining limits

The root-owned affected gate and broader spec-registry correction are separate
evidence. This review does not claim a full-suite result. Linux filesystem and
libc behavior were exercised here; Windows dispatch mocks and metadata controls
do not qualify native Windows rename, junction creation, permissions or cleanup.
The original pre-repair reservation-hook probes remain preserved by root and
were not relabeled as passing tests of the replacement syscall.

No remote mutation, publication, release, deployment, workflow dispatch or tag
was performed. A corrected exact source must be independently re-reviewed
before this finding can be closed.
