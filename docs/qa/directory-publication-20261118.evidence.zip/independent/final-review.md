# Independent disposition: directory publication repair

**Accepted within the documented stable-parent/private-stage boundary.** No
remaining blocking finding was found at source
`843dfec72dcb5751e53d01f217263771dd6d65d2`, tree
`96e12cdf58bbf9dc740bde29c475071b181395f8`. Native Windows qualification is still
pending. No production source was edited by this reviewer.

The initial source review and corrected failure evidence remain in
`review-c9290ce8.md` and `corrected-review.*`. The root-owned repair's precursor
is `038707c994070dab6c384a5d473729e7ef6ea088`; the final delta retains one `lstat`
result and refuses the reparse-point attribute as well as non-directory mode.
The follow-up spec, both portable regressions, native junction control and
complete production delta were inspected. The existing Windows no-replace
dispatch and Linux syscall behavior are unchanged by this follow-up.

The independent probe remains byte-for-byte unchanged after its documented
fixture correction: 9,088 bytes, SHA-256
`821adaf139289250acbade0ff36b0a46bea741c2e6c38062739f9df0e1d45da0`.
Its two original reparse failures now pass. All 20 executable independent
controls passed; the AF_UNIX destination case remains an explicit capability
skip because the host refuses socket creation with `EPERM`.

The exact repaired-source replay, together with the authored directory module,
reported **56 passed and 2 skipped in 0.53 seconds**. There are 36 authored passes
and 20 independent passes. The second skip is the newly authored native Windows
junction test. No skip is credited as acceptance. The raw command, absolute
source `PYTHONPATH`, SHA/tree, test hash, log, JUnit and exit status are retained
in `repaired-843dfec7-*` / `repaired-843dfec7.log` / `repaired-843dfec7.xml`.

The passing native Linux controls establish destination identity/link-count
preservation through both actual public paths on late collision and injected
native error, complete ordinary publication, preservation of existing FIFO and
link/directory leaves, six concurrent publishers with one winner, and explicit
native-error propagation without weakening fallback. Simulated Windows metadata
controls establish input refusal only; they do not establish Windows junction,
permission, rename or cleanup compatibility.

The first review's three fixture setup errors, the denied socket-creation
failure, its initial probe source, and the corrected two-failure run are all
preserved. The reviewer corrected only creation of the authored sidecar directory
and explicit classification of the missing AF_UNIX capability; the product
assertions were unchanged. The root-owned original reservation-hook red probes
and broad affected gate remain separate receipts and were not relabeled.

The sealed `evidence.zip` and `manifest.json` bind the original/repaired source
snapshots, independent controls and every raw receipt. All members were reopened,
CRC-checked, checked for duplicate paths, and revalidated by size and SHA-256.
The detached review worktree remains clean. No remote mutation, release, tag,
deployment, workflow dispatch or target/runtime execution occurred.
