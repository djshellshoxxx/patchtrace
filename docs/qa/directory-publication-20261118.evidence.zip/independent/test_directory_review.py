"""Independent controls against the pinned directory publication candidate.

All payloads are authored inert bytes. No runtime/target payload is executed.
Windows metadata controls are simulated and confer no native Windows credit.
"""
from __future__ import annotations

import ctypes
import errno
import hashlib
import os
import socket
import stat
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Barrier
from types import SimpleNamespace

import pytest
from test_offline_bundle import RUNTIME_ID, make_bundle

from patchtrace import directory_publication as publisher
from patchtrace import offline_bundle, persistence
from patchtrace.service import ProjectService


@pytest.fixture(params=['backup', 'runtime'])
def operation(request, tmp_path):
    if request.param == 'backup':
        service = ProjectService.sample(tmp_path / 'project')
        destination = tmp_path / 'saved-project'
        source = service.root / 'project.sqlite3'
        try:
            (service.root / 'exports').mkdir()
            (service.root / 'exports' / 'review.txt').write_bytes(b'independent inert backup evidence')
            yield lambda: service.backup(destination), destination, source
        finally:
            service.close()
    else:
        archive = make_bundle(tmp_path)
        plan = offline_bundle.inspect_offline_bundle(archive)
        destination = tmp_path / 'runtimes' / RUNTIME_ID
        yield lambda: offline_bundle.install_offline_bundle(plan, destination.parent), destination, archive


@pytest.mark.parametrize('failure', [False, True], ids=['real-collision', 'native-error'])
def test_actual_public_paths_preserve_late_foreign_directory_fd(operation, monkeypatch, failure):
    perform, destination, original = operation
    before = hashlib.sha256(original.read_bytes()).hexdigest()
    real_native = ctypes.CDLL(None, use_errno=True).renameat2
    real_native.argtypes = (ctypes.c_int, ctypes.c_char_p, ctypes.c_int, ctypes.c_char_p, ctypes.c_uint)
    real_native.restype = ctypes.c_int
    held = []
    calls = []

    def inject_at_native_boundary(srcfd, src, dstfd, dst, flags):
        calls.append((srcfd, src, dstfd, dst, flags))
        assert Path(os.fsdecode(dst)) == destination
        assert not os.path.lexists(destination)
        assert flags == 1 and srcfd == dstfd == -100
        destination.mkdir()
        held.append(os.open(destination, os.O_RDONLY | os.O_DIRECTORY))
        if failure:
            ctypes.set_errno(errno.ENOSPC)
            return -1
        return real_native(srcfd, src, dstfd, dst, flags)

    monkeypatch.setattr(publisher.ctypes, 'CDLL', lambda *a, **kw: SimpleNamespace(renameat2=inject_at_native_boundary))
    try:
        with pytest.raises((OSError, offline_bundle.OfflineBundleError)):
            perform()
        assert len(calls) == len(held) == 1
        fd_stat, leaf_stat = os.fstat(held[0]), destination.lstat()
        assert fd_stat.st_nlink > 0
        assert (fd_stat.st_dev, fd_stat.st_ino) == (leaf_stat.st_dev, leaf_stat.st_ino)
        assert not list(destination.iterdir())
        assert hashlib.sha256(original.read_bytes()).hexdigest() == before
        assert not list(destination.parent.glob('.patchtrace-backup-*'))
        assert not list(destination.parent.glob('.install-*'))
        assert not list(destination.parent.glob('.runtime-*.lock'))
    finally:
        for descriptor in held:
            os.close(descriptor)


def test_actual_public_ordinary_paths_publish_complete_output(operation):
    perform, destination, original = operation
    before = hashlib.sha256(original.read_bytes()).hexdigest()
    perform()
    assert destination.is_dir()
    assert hashlib.sha256(original.read_bytes()).hexdigest() == before
    if (destination / 'project.sqlite3').exists():
        assert (destination / 'exports' / 'review.txt').read_bytes() == b'independent inert backup evidence'
    else:
        assert (destination / 'payload/python/python.exe').read_bytes() == b'fake-python-executable'
        assert (destination / 'manifest.json').is_file()


@pytest.mark.parametrize('kind', ['fifo', 'socket', 'dangling-link', 'empty-directory'])
def test_all_observed_destination_kinds_survive_native_refusal(tmp_path, kind):
    source = tmp_path / 'source'
    source.mkdir()
    (source / 'evidence').write_bytes(b'original stage')
    target = tmp_path / 'target'
    sock = None
    if kind == 'fifo':
        os.mkfifo(target)
    elif kind == 'socket':
        try:
            sock = socket.socket(socket.AF_UNIX)
        except PermissionError as exc:
            pytest.skip(f'Native AF_UNIX capability denied on this host; destination kind unverified: {exc}')
        sock.bind(str(target))
    elif kind == 'dangling-link':
        target.symlink_to(tmp_path / 'absent')
    else:
        target.mkdir()
    old = target.lstat()
    try:
        with pytest.raises(FileExistsError):
            publisher.publish_directory_no_replace(source, target)
        new = target.lstat()
        assert (old.st_dev, old.st_ino, old.st_mode) == (new.st_dev, new.st_ino, new.st_mode)
        assert (source / 'evidence').read_bytes() == b'original stage'
    finally:
        if sock is not None:
            sock.close()


def test_six_concurrent_native_publishers_preserve_five_losers(tmp_path):
    target = tmp_path / 'target'
    sources = []
    for i in range(6):
        source = tmp_path / f'stage-{i}'
        source.mkdir()
        (source / 'identity').write_text(str(i))
        sources.append(source)
    barrier = Barrier(6)

    def run(i):
        barrier.wait(timeout=10)
        try:
            publisher.publish_directory_no_replace(sources[i], target)
        except FileExistsError:
            return False
        return True

    with ThreadPoolExecutor(max_workers=6) as executor:
        winners = list(executor.map(run, range(6)))
    assert sum(winners) == 1
    winner = winners.index(True)
    assert (target / 'identity').read_text() == str(winner)
    for i, source in enumerate(sources):
        if i == winner:
            assert not source.exists()
        else:
            assert (source / 'identity').read_text() == str(i)


@pytest.mark.parametrize('code', [errno.EXDEV, errno.ENOSYS, errno.EINVAL, errno.EOPNOTSUPP, errno.EINTR, 0])
def test_errno_and_uncertain_native_failure_never_fall_back(tmp_path, monkeypatch, code):
    source = tmp_path / 'source'
    source.mkdir()
    target = tmp_path / 'target'
    calls = []

    def failed(*args):
        calls.append(args)
        ctypes.set_errno(code)
        return -1

    monkeypatch.setattr(publisher.ctypes, 'CDLL', lambda *a, **kw: SimpleNamespace(renameat2=failed))
    monkeypatch.setattr(publisher.os, 'rename', lambda *a, **kw: pytest.fail('overwriting fallback'))
    monkeypatch.setattr(publisher.os, 'replace', lambda *a, **kw: pytest.fail('replacing fallback'))
    with pytest.raises(OSError) as caught:
        publisher.publish_directory_no_replace(source, target)
    assert caught.value.errno == (code or errno.EIO)
    assert caught.value.filename == str(source) and caught.value.filename2 == str(target)
    assert len(calls) == 1 and source.is_dir() and not os.path.lexists(target)


@pytest.mark.parametrize('attributes,tag', [(0x410, 0xA0000003), (0x410, 0x80000042)])
def test_windows_directory_reparse_metadata_is_refused_before_native_move(tmp_path, monkeypatch, attributes, tag):
    """CPython reports junction/other directory reparse points as S_IFDIR, not S_IFLNK."""
    source = tmp_path / 'source'
    source.mkdir()
    target = tmp_path / 'target'
    original_lstat = Path.lstat
    native_calls = []

    def lstat(path):
        if path == source:
            return SimpleNamespace(st_mode=stat.S_IFDIR | 0o700,
                                   st_file_attributes=attributes, st_reparse_tag=tag)
        return original_lstat(path)

    monkeypatch.setattr(Path, 'lstat', lstat)
    monkeypatch.setattr(publisher, '_native_move', lambda *args: native_calls.append(args))
    with pytest.raises((OSError, ValueError)):
        publisher.publish_directory_no_replace(source, target)
    assert not native_calls and source.exists() and not target.exists()


def test_plain_directory_metadata_with_no_reparse_flag_remains_accepted(tmp_path, monkeypatch):
    source = tmp_path / 'source'
    source.mkdir()
    target = tmp_path / 'target'
    original_lstat = Path.lstat

    def lstat(path):
        if path == source:
            return SimpleNamespace(st_mode=stat.S_IFDIR | 0o700,
                                   st_file_attributes=0x10, st_reparse_tag=0)
        return original_lstat(path)

    monkeypatch.setattr(Path, 'lstat', lstat)
    publisher.publish_directory_no_replace(source, target)
    assert target.is_dir() and not source.exists()


def test_existing_private_names_share_one_production_implementation():
    assert persistence._publish_no_replace is publisher.publish_directory_no_replace
    assert offline_bundle._publish_no_replace is publisher.publish_directory_no_replace
