"""Current-source backup reservation ownership probes; authored local projects only."""
import os
from pathlib import Path

import pytest

from patchtrace import persistence
from patchtrace.service import ProjectService


@pytest.mark.skipif(os.name == 'nt', reason='POSIX empty-directory replacement semantics')
@pytest.mark.parametrize('publication_failure', [False, True], ids=['replace-success','rename-failure'])
def test_concurrent_foreign_empty_destination_is_preserved(tmp_path, monkeypatch, publication_failure):
    service = ProjectService.sample(tmp_path / 'source')
    destination = tmp_path / 'backup'
    rename = persistence.os.rename
    held = []
    observed = {}

    def replace_reserved_directory(stage, target):
        if Path(target) != destination:
            return rename(stage, target)
        # The public path held an empty reservation. A separate owner replaces it
        # immediately before publish, after the helper's admission operation.
        os.rmdir(target)
        os.mkdir(target)
        held.append(os.open(target, os.O_RDONLY | os.O_DIRECTORY))
        observed['foreign'] = os.fstat(held[-1])
        if publication_failure:
            raise OSError('authored publication failure')
        return rename(stage, target)

    monkeypatch.setattr(persistence.os, 'rename', replace_reserved_directory)
    try:
        before = (service.root / 'project.sqlite3').read_bytes()
        try:
            service.backup(destination)
        except (OSError, ValueError):
            pass
        assert (service.root / 'project.sqlite3').read_bytes() == before
        assert held, 'the actual backup publication did not reach the probe seam'
        assert os.fstat(held[0]).st_nlink > 0, 'the foreign destination directory was unlinked'
        assert destination.exists() and destination.stat().st_ino == observed['foreign'].st_ino
    finally:
        service.close()
        for descriptor in held:
            os.close(descriptor)


def test_ordinary_backup_still_publishes_complete_project(tmp_path):
    source = ProjectService.sample(tmp_path / 'source')
    try:
        destination = source.backup(tmp_path / 'backup')
        restored = ProjectService.open(destination)
        try:
            assert restored.project.id == source.project.id
            assert restored.project.artifacts == source.project.artifacts
        finally:
            restored.close()
    finally:
        source.close()
