"""Actual offline installer with inert authored text payloads; no runtime execution."""
import os
from pathlib import Path

import pytest
from test_offline_bundle import RUNTIME_ID, make_bundle

from patchtrace import offline_bundle


@pytest.mark.skipif(os.name == 'nt', reason='POSIX empty-directory replacement semantics')
@pytest.mark.parametrize('publication_failure', [False, True], ids=['replace-success', 'rename-failure'])
def test_foreign_runtime_destination_survives_publication(tmp_path, monkeypatch, publication_failure):
    plan = offline_bundle.inspect_offline_bundle(make_bundle(tmp_path))
    root = tmp_path / 'runtimes'
    destination = root / RUNTIME_ID
    rename = offline_bundle.os.rename
    held = []
    observed = {}

    def replace_reserved_directory(stage, target):
        if Path(target) != destination:
            return rename(stage, target)
        os.rmdir(target)
        os.mkdir(target)
        held.append(os.open(target, os.O_RDONLY | os.O_DIRECTORY))
        observed['foreign'] = os.fstat(held[-1])
        if publication_failure:
            raise OSError('authored publication failure')
        return rename(stage, target)

    monkeypatch.setattr(offline_bundle.os, 'rename', replace_reserved_directory)
    try:
        try:
            offline_bundle.install_offline_bundle(plan, root)
        except offline_bundle.OfflineBundleError:
            pass
        assert held, 'the actual runtime publication did not reach the probe seam'
        assert os.fstat(held[0]).st_nlink > 0, 'the foreign runtime directory was unlinked'
        assert destination.exists() and destination.stat().st_ino == observed['foreign'].st_ino
    finally:
        for descriptor in held:
            os.close(descriptor)


def test_normal_offline_install_retains_only_verified_inert_payloads(tmp_path):
    plan = offline_bundle.inspect_offline_bundle(make_bundle(tmp_path))
    result = offline_bundle.install_offline_bundle(plan, tmp_path / 'runtimes')
    assert result.python_executable.read_bytes() == b'fake-python-executable'
    assert result.manifest_path.read_bytes() == plan.manifest_bytes
