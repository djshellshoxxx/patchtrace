"""Exact-checkpoint, single-attempt local verification. Never edits product source."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import subprocess
import time

ROOT=Path('/workspace/scratch/142cb233d750')
REPO=ROOT/'wt-full'
OUT=ROOT/'full-verification-f005c66-20261101'
PYTHON=ROOT/'full-venv/bin/python'
EXPECTED='f005c6674e0d7e7e151668494bb9c5a299f2635b'
ENV=dict(os.environ)
removed={k:ENV.pop(k,None) for k in ('PYTHONPATH','PYTHONHOME','PYTEST_ADDOPTS','PYTEST_DISABLE_PLUGIN_AUTOLOAD')}
ENV.update(QT_QPA_PLATFORM='offscreen',PATCHTRACE_LIVE_STATUS_DIR=str(OUT/'live-status'))

def now(): return datetime.now(timezone.utc).isoformat()
def source():
    return {'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
            'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=REPO,text=True).strip(),
            'status':subprocess.check_output(['git','status','--porcelain'],cwd=REPO,text=True).splitlines()}
def write(name,value):
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n')
def run(name,args,*,cwd=REPO):
    logfile=OUT/(name+'.log')
    receipt=OUT/(name+'.json')
    if logfile.exists() or receipt.exists(): raise RuntimeError('Refusing to overwrite '+name)
    entry={'argv':[str(a) for a in args],'cwd':str(cwd),'started_utc':now(),'source_before':source()}
    write(name+'.running.json',entry)
    start=time.monotonic()
    with logfile.open('xb') as log:
        result=subprocess.run(entry['argv'],cwd=cwd,env=ENV,stdout=log,stderr=subprocess.STDOUT,check=False)
    entry.update(returncode=result.returncode,ended_utc=now(),elapsed_seconds=time.monotonic()-start,
                 source_after=source(),log_sha256=hashlib.sha256(logfile.read_bytes()).hexdigest())
    write(name+'.json',entry)
    (OUT/(name+'.running.json')).unlink()
    print(json.dumps({'step':name,'returncode':result.returncode,'elapsed_seconds':entry['elapsed_seconds']}),flush=True)
    return entry

initial=source()
assert initial['commit']==EXPECTED and not initial['status'],initial
write('run-environment.json',{'started_utc':now(),'source':initial,'explicit_environment':{
    'QT_QPA_PLATFORM':ENV['QT_QPA_PLATFORM'],'PATCHTRACE_LIVE_STATUS_DIR':ENV['PATCHTRACE_LIVE_STATUS_DIR']},
    'removed_test_python_overrides':{k:v for k,v in removed.items() if v is not None},
    'temp_environment':{k:ENV.get(k) for k in ('TMPDIR','TMP','TEMP')},
    'policy':'one full serial attempt; no retries, suppressions or source edits'})
steps=[]
steps.append(run('pip-check',[PYTHON,'-m','pip','check']))
steps.append(run('ruff',[PYTHON,'-m','ruff','check','src','tests','tools']))
steps.append(run('protobuf-runtime',[PYTHON,'tools/check_protobuf_runtime.py']))
generated=OUT/'general-schema-generated'
generated.mkdir()
steps.append(run('general-schema-generation',[PYTHON,REPO/'tools/generate_schemas.py'],cwd=generated))
checked=[]
drift=[]
for p in sorted((generated/'docs/schemas').rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(generated)
    actual=hashlib.sha256(p.read_bytes()).hexdigest()
    expected=REPO/rel
    wanted=hashlib.sha256(expected.read_bytes()).hexdigest() if expected.is_file() else None
    checked.append({'path':str(rel),'generated_sha256':actual,'committed_sha256':wanted})
    if actual!=wanted:drift.append(str(rel))
write('general-schema-drift.json',{'checked':checked,'drift':drift,'passed':bool(checked) and not drift})
print(json.dumps({'step':'general-schema-drift','files':len(checked),'drift':drift}),flush=True)
steps.append(run('kbc-schema-check',[PYTHON,'tools/generate_kbc_schemas.py','--check']))
assert source()==initial,source()
steps.append(run('pytest-full',[PYTHON,'-m','pytest','-q','--junitxml='+str(OUT/'pytest-junit.xml')]))
write('verification-summary.json',{'source':initial,'completed_utc':now(),'steps':steps,
                                  'general_schema_passed':bool(checked) and not drift,'final_source':source()})
print(json.dumps({'completed_utc':now(),'full_returncode':steps[-1]['returncode'],'source':source()}),flush=True)
