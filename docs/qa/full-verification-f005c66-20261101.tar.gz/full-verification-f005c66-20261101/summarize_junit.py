"""Summarize preserved JUnit without rerunning or reclassifying failures."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent
raw=(ROOT/'pytest-junit.xml').read_bytes()
xml=ET.fromstring(raw)
counts=Counter()
nonpass=[]
for case in xml.iter('testcase'):
    status='passed'
    detail=None
    for tag in ('error','failure','skipped'):
        child=case.find(tag)
        if child is not None:
            status='xfailed' if tag=='skipped' and child.attrib.get('type')=='pytest.xfail' else tag
            detail={'attributes':child.attrib,'text':child.text or ''}
            break
    counts[status]+=1
    if status!='passed':
        nonpass.append({'node':case.attrib.get('classname','')+'::'+case.attrib.get('name',''),
                        'status':status,'duration':case.attrib.get('time'), 'detail':detail})
summary={'junit_sha256':hashlib.sha256(raw).hexdigest(),'suites':[s.attrib for s in xml.iter('testsuite')],
         'counts':dict(counts),'all_nonpassing_cases':nonpass,
         'classification':'raw JUnit status only; host versus product diagnosis is separate'}
(ROOT/'pytest-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'counts':dict(counts),'nonpassing_cases':len(nonpass),'junit_sha256':summary['junit_sha256']},indent=2))
