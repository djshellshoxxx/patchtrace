# PR 153 — terminal hosted evidence for 6f923758

Head `6f923758efb57e3f19a43b5b1d2c1ba8319e1823`, tree `99031dd843ea50b22a73c2eb1f5904f1c062ae49`; synthetic merge `c07f2a3c3b456a7269e7b0794b909b0eea743db0` has the identical tree on accepted main25.

All Actions children of QA `41418774232`, native PR `41418774144` and native push `41418767357` are terminal success. Release/release-gate skipped in PR scope. Sonar and Snyk succeeded. Current CodeRabbit check `125189273603` explicitly skipped: Review paused.

**Not merge qualified:** root reports a substantive field-attribution finding, with author repair and independent review required. That internal review boundary is separate from the configured CI results and the published GitHub review data captured here. No old result qualifies different repaired source. Three older GitHub threads remain open: two revision-policy concerns and the namespace-construction claim previously disproved by the isolated control. No scanner suppression or review-thread mutation was performed.

| Gate | Original job | Result |
| --- | --- | --- |
| Linux full + Ruff | 125189228194 | 18,578 passed, 47 skipped, 7 xfailed, 1 warning; 1522.82s. Ruff passed. |
| Windows full + Ruff | 125189228346 | 18,545 passed, 81 skipped, 6 xfailed, 1 warning; 2599.63s. Ruff passed. |
| Linux Qt 1/4 | 125189228584 | 10,100 passed; 2143.26s. |
| Linux Qt 2/4 | 125189228853 | 8,700 passed; 1610.36s. |
| Linux Qt 3/4 | 125189228415 | 9,640 passed; 1311.46s. |
| Linux Qt 4/4 | 125189228824 | 9,060 passed; 1750.28s. |
| Windows Qt | 125189228363 | 9,375 passed; 2293.26s. |
| Windows package checks | 125189228346 | Frozen A1–A4 and optional-dependency self-test, portable checksum/clean extraction, installer registration/runtime/self-test and non-destructive uninstall succeeded. |
| Linux package | 125214641788 | Build/upload succeeded. |
| Ubuntu 24.04 smoke | 125215912657 | Artifact/tar checksum and both offscreen and xcb/Xvfb frozen self-tests succeeded. |
| Ubuntu 22.04 smoke | 125215912865 | Same checksum and both frozen self-test modes succeeded. |
| Native acceptance | Both five-variant runs | All ten jobs succeeded, including the applicable offline analysis, no-adjacent-PDB, raw-cache byte identity and plain-Ghidriff cached-PDB error reproduction steps. Conditional matrix skips retained in original child metadata. |

Both original JUnit ZIP digests were independently verified. Each JUnit contains 18,632 child cases, zero failures/errors: Linux 18,578 passed +54 skip/xfail; Windows 18,545 passed +87 skip/xfail. In each leg five individual workflow checks skipped because yaml was absent (four test_ci_summary checks and test_tier_r_shard::test_workflow_structure_and_pins); exact node names are in the artifact receipts. The central dev-extra correction is outside this head.

All package artifacts and inner packages were independently downloaded and hashed against their shipped checksum files. Binaries are excluded from this compact evidence archive.

| Package | Bytes | Computed SHA-256 matching shipped checksum |
| --- | ---: | --- |
| `PatchTrace-0.1.0-windows-x64.zip` | 65,527,685 | `32eb3d5d29e6dbe982363fea0d7b7159bf154ccda8d3cc24bf78b883525db0bb` |
| `PatchTrace-Windows-x64-Setup.exe` | 64,343,866 | `2685aae2de1ab9ad1281d8e046faeae4195175d21561d8502da8c47e08a73c3a` |
| `PatchTrace-0.1.0-linux-x86_64.tar.gz` | 94,419,481 | `2a4139405a785938e2d0399e11ac24a293ff6ce860e22a62687486a6e470ffbd` |

Outer Windows artifact13132192443:129,215,827 bytes, SHA-256 `3ab993b1141844cd005adefc07698bd120efb6bfaa54d49d31454ad2195cac3e`. Outer Linux artifact13132850512:93,838,772 bytes, SHA-256 `7a750640d50ddac52739826c82d5a52b44e16cc0206bde49beb92cedc6a9033c`. Detailed JSON receipts preserve original artifact/head metadata, member names and recomputed hashes.

Read-only audit: no source edits, reruns, dispatches, approvals, merges or review-thread mutations.
