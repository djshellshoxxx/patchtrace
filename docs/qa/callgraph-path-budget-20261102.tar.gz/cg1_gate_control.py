"""Read-only counters around the one authorized existing large-graph gate."""
import json
from pathlib import Path
import time

from patchtrace.callgraph import algo

records = []
original_simple = algo.simple_paths
original_shortest = algo._shortest
original_reach = algo.reach
current = []


def simple(graph, src, dst, *args, **kwargs):
    item = {'nodes': graph.n, 'edges': graph.edge_count, 'phases': []}
    records.append(item)
    current.append(item)
    started = time.perf_counter()
    try:
        result = original_simple(graph, src, dst, *args, **kwargs)
        item.update(paths=len(result.paths), path_lengths=[len(p) - 1 for p in result.paths],
                    truncated=result.truncated, valid_paths=all(len(set(path)) == len(path) and all(graph.has_edge(a, b) for a, b in zip(path, path[1:])) for path in result.paths))
        return result
    finally:
        item['query_elapsed_seconds'] = time.perf_counter() - started
        current.pop()


def phase(original, name):
    def wrapped(graph, *args, **kwargs):
        if not isinstance(graph, algo._PathGraph):
            return original(graph, *args, **kwargs)
        before = graph.examined
        item = {'phase': name}
        current[-1]['phases'].append(item)
        try:
            result = original(graph, *args, **kwargs)
            if name == 'shortest_distance':
                item['distance_returned'] = result
            return result
        except algo._PathBudgetExhausted:
            item['exhausted'] = True
            raise
        finally:
            item['examined'] = graph.examined - before
            current[-1]['total_examined'] = graph.examined
    return wrapped


def pytest_sessionstart(session):
    algo.simple_paths = simple
    algo._shortest = phase(original_shortest, 'shortest_distance')
    algo.reach = phase(original_reach, 'reverse_reach')


def pytest_sessionfinish(session, exitstatus):
    Path('/workspace/scratch/142cb233d750/reviews-resume/cg1-budget-refined-gate.json').write_text(
        json.dumps({'exitstatus': exitstatus, 'source': algo.__file__, 'queries': records}, indent=2) + '\n')
