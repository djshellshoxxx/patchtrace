"""Moderate real normalized-callgraph probe; operation counts only, no timing claim."""
from collections import Counter, defaultdict
import json

from callgraph_graph_support import snapshot
from patchtrace.callgraph import algo, paths
from patchtrace.callgraph.csr import CSRGraph
from patchtrace.callgraph.limits import PATH_VISIT_BUDGET
from patchtrace.callgraph.query import find_node


def probe(k=6, dead=800):
    names = ['src', *[f'A{i}' for i in range(k)], *[f'B{i}' for i in range(k)],
             'hub', *[f'dead{i}' for i in range(dead)], 'z', 'dst']
    edges = ([('src', f'A{i}') for i in range(k)]
             + [(f'A{i}', f'B{j}') for i in range(k) for j in range(k)]
             + [(f'B{i}', 'hub') for i in range(k)]
             + [('hub', f'dead{i}') for i in range(dead)]
             + [('hub', 'src'), ('src', 'z'), ('z', 'dst')])
    calls = defaultdict(list)
    for source, target in edges:
        calls[source].append(target)

    def mutate(raw):
        raw['functions'] = {'added': [
            {'name': name, 'fullname': name, 'address': f'{0x1000 + i * 16:x}',
             'calling': [], 'called': calls[name]}
            for i, name in enumerate(names)], 'modified': [], 'deleted': []}
        raw['matches'] = {'name_matches': {}, 'address_matches': {}}

    snap = snapshot('no_matches', mutate)
    src, dst = (find_node(snap, 'newer', name).id for name in ('src', 'dst'))
    counts = defaultdict(Counter)
    phase = ['find_paths_subgraph']
    originals = CSRGraph.successors, CSRGraph.predecessors, algo.shortest_distance, algo.reach, paths.simple_paths

    class ObservedRow:
        def __init__(self, row):
            self.row = row

        def __iter__(self):
            for value in self.row:
                counts[phase[0]]['edge_yields'] += 1
                yield value

    def observed_access(original):
        def access(graph, node):
            row = original(graph, node)
            counts[phase[0]]['row_calls'] += 1
            counts[phase[0]]['copied_edge_items'] += len(row)
            return ObservedRow(row)
        return access

    def in_phase(original, name):
        def wrapped(*args, **kwargs):
            before, phase[0] = phase[0], name
            try:
                return original(*args, **kwargs)
            finally:
                phase[0] = before
        return wrapped

    def cancel():
        counts[phase[0]]['cancel_calls'] += 1
        return False

    try:
        CSRGraph.successors = observed_access(originals[0])
        CSRGraph.predecessors = observed_access(originals[1])
        algo.shortest_distance = in_phase(originals[2], 'shortest_distance')
        algo.reach = in_phase(originals[3], 'reverse_reach')
        paths.simple_paths = in_phase(originals[4], 'path_enumeration')
        found = paths.find_paths(snap, 'newer', src, dst, cancel)
    finally:
        CSRGraph.successors, CSRGraph.predecessors, algo.shortest_distance, algo.reach, paths.simple_paths = originals
    return {'k': k, 'dead_successors': dead, 'graph_nodes': snap.newer.graph.n,
            'graph_edges': snap.newer.graph.edge_count, 'configured_budget': PATH_VISIT_BUDGET,
            'path_labels': [[found.labels[node] for node in path] for path in found.paths],
            'truncated': found.truncated, 'phase_counts': dict(counts)}


if __name__ == '__main__':
    print(json.dumps([probe(6, 400), probe(6, 800)], indent=2))
