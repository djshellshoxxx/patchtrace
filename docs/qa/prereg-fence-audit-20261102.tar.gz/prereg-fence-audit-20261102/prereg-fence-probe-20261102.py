"""Bounded read-only probe of #154's actual fence-regex call paths.

Run from the exact checkout with PYTHONPATH=src and this script's directory
added after the checkout itself. Only constructed temporary QA/protocol bytes
are read. No corpus, evaluation, external engine, or target binary is used.
Wall time is descriptive evidence; no timing threshold decides correctness.
"""
from __future__ import annotations

import hashlib
import json
import platform
import subprocess
import sys
import tempfile
import time
from pathlib import Path

sys.path.insert(0, str(Path.cwd()))
from tools.calibration import prereg_gate as gate


class ObserveFence:
    def __init__(self, pattern):
        self.pattern = pattern
        self.calls = 0
        self.max_length = 0
        self.newline_arguments = 0

    def match(self, value):
        self.calls += 1
        self.max_length = max(self.max_length, len(value))
        self.newline_arguments += '\n' in value
        assert '\n' not in value, 'the caller passed a nonterminal-newline candidate'
        return self.pattern.match(value)


def constructed_cases(size, char, record, false_record):
    marker = char * size
    other = '~' if char == '`' else '`'
    for indent in range(4):
        prefix = ' ' * indent
        yield f'closed-indent-{indent}', f'{prefix}{marker} info\n{false_record}\n{prefix}{marker}\t \n{record}\n'
    yield 'short-closer', f'{marker}\n{false_record}\n{marker[:-1]}\n{false_record}\n{marker}\n{record}\n'
    yield 'mixed-closer', f'{marker}\n{other * size}\n{false_record}\n{marker}\n{record}\n'
    yield 'closer-nonspace-suffix', f'{marker}\n{marker}suffix\n{false_record}\n{marker}\n{record}\n'
    yield 'four-space-indented', f'    {marker}\n    {false_record}\n    {marker}\n{record}\n'
    yield 'tab-indented', f'\t{marker}\n\t{false_record}\n\t{marker}\n{record}\n'
    yield 'literal-comment-inside', f'{marker}\n<!--\n{false_record}\n{marker}\n{record}\n'
    yield 'comment-before-fence', f'<!-- comment -->\n{marker}\n{false_record}\n{marker}\n{record}\n'
    yield 'comment-closes-before-fence', f'<!-- comment\n-->\n{marker}\n{false_record}\n{marker}\n{record}\n'
    # A tilde after a same-line removed comment reaches the second regex call.
    if char == '~':
        yield 'visible-fragment-fence', f'<!-- comment -->{marker}\n{false_record}\n{marker}\n{record}\n'
    # The nonterminal newline that forces raw-regex backtracking is split here.
    yield 'raw-regex-control-through-parser', f'{marker}\n!\n{false_record}\n{marker}\n{record}\n'


def main():
    original = gate._FENCE
    observed = ObserveFence(original)
    gate._FENCE = observed
    results = []
    with tempfile.TemporaryDirectory(prefix='prereg-fence-audit-') as name:
        root = Path(name)
        protocol = root / 'protocol.md'
        qa = root / 'qa.md'
        protocol.write_bytes(b'constructed protocol, not a real preregistration\n')
        sha = hashlib.sha256(protocol.read_bytes()).hexdigest()
        record = f'| C9-PREREG-v1 | {sha} |'
        false_record = f'| C9-PREREG-v1 | {"0" * 64} |'
        for size in (1_000, 10_000, 100_000, 1_000_000):
            for char in ('`', '~'):
                for label, document in constructed_cases(size, char, record, false_record):
                    qa.write_text(document, encoding='utf-8', newline='')
                    before = observed.calls
                    start = time.perf_counter_ns()
                    selected = gate.select(protocol, qa)
                    elapsed = time.perf_counter_ns() - start
                    assert selected.sha == sha and selected.rehearsal_sha is None
                    results.append({'case': label, 'marker': char, 'size': size,
                                    'document_chars': len(document), 'elapsed_ns': elapsed,
                                    'regex_calls': observed.calls - before, 'selected_expected_sha': True})
        # Exercise all str.splitlines boundaries directly, avoiding text-mode
        # newline translation as an explanation for the observed invariant.
        separators = ('\n', '\r', '\r\n', '\v', '\f', '\x1c', '\x1d', '\x1e', '\x85', '\u2028', '\u2029')
        for separator in separators:
            for char in ('`', '~'):
                marker = char * 100_000
                document = separator.join((marker, false_record, marker, record))
                assert list(gate._visible_lines(document)) == [record]
        # Constant-work rejection before the first run and <3 marker negatives.
        for line in (' ' * 4 + '~' * 1_000_000, 'x' + '~' * 1_000_000,
                     '~~' + 'x' * 1_000_000, ''):
            assert original.match(line) is None
    gate._FENCE = original
    raw_controls = []
    for char in ('`', '~'):
        for size in (1_000, 2_000, 4_000, 8_000):
            direct_input = char * size + '\n!'
            start = time.perf_counter_ns()
            match = original.match(direct_input)
            elapsed = time.perf_counter_ns() - start
            assert match is None
            raw_controls.append({'marker': char, 'size': size, 'elapsed_ns': elapsed,
                                 'result': 'no match', 'reachable_at_actual_call_sites': False})
    result = {
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
        'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], text=True).strip(),
        'source_sha256': hashlib.sha256(Path(gate.__file__).read_bytes()).hexdigest(),
        'python': platform.python_version(), 'platform': platform.platform(),
        'actual_select_cases': results, 'splitlines_cases': 22,
        'observed_fence_regex_calls': observed.calls,
        'max_observed_regex_argument_length': observed.max_length,
        'observed_newline_arguments': observed.newline_arguments,
        'raw_regex_quadratic_controls': raw_controls,
        'conclusion': 'Direct raw regex has quadratic rejecting inputs; those require a nonterminal LF excluded at both current call sites. No reachable fence-regex super-linear case found; no production source repair or suppression applied.',
    }
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
