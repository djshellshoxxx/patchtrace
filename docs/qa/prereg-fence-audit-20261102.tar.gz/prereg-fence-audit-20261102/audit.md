# Preregistration fence regex audit — 2026-11-02

Exact PR #154 source: `f27d23a80ee49573ccca54cdf036427f57eebb2a`, tree
`8ef0a587631bd830ddb44f6a1fdaf1f698ab0f9b`. Source file SHA-256:
`30e1f275dfe1f731b8e65aeed0939fc46e0971ce1b7f5e1008563ca3e918d992`.
No production code, test, spec, dependency, pin, workflow or frozen protocol was
changed. This audit used constructed temporary QA/protocol documents only; no
real corpus or locked evaluation was opened. No GitHub mutation was performed.

## Finding and reachability

Sonar warning `AaGXQElGeRS3ER4AhK9_` flags
`_FENCE = re.compile(r'^ {0,3}(`{3,}|~{3,})(.*)$')` at
`tools/calibration/prereg_gate.py:16` as potentially super-linear. The regex in
isolation does have a quadratic rejecting case: a long backtick/tilde run,
followed by a nonterminal LF and another character. The suffix cannot cross the
LF, so the engine repeatedly gives characters back from the first group.

Source inspection finds exactly two uses, at lines 82 and 111, both inside
`_visible_lines`. Its loop iterates `text.splitlines()`; the first match receives
that physical line, and the second receives only concatenated substrings of the
same line after comment/code handling. Neither argument can contain LF. With LF
absent, once the first group consumes at least three fence characters, `(.*)$`
consumes the remainder and succeeds on its first attempt. Failure before that
point only revisits the fixed zero-to-three leading spaces and the two marker
alternatives. Thus the warned quadratic backtracking shape is not reachable at
either current call site. This reasoning is limited to `_FENCE`; it is not a
claim about every operation in the parser.

No source repair is justified by this bounded investigation. No scanner
suppression or false-positive designation was applied. The separate generic
`qa_path` traversal annotation supplies no authority-boundary trace, and no
restriction was invented. The published Sonar C-security gate remains failed
pending an authorized, evidence-based disposition or demonstrated source defect.

## Executed evidence

`prereg-fence-probe-20261102.py` is a reproducible diagnostic, not a production
module. On Python 3.12.14 / Linux it passed 108 actual `select()` cases across
1,000 / 10,000 / 100,000 / 1,000,000 marker characters, plus 22 direct
`_visible_lines()` cases covering every `str.splitlines()` boundary with both
markers. Cases cover zero-to-three-space fences, four-space/tab indentation,
short/mixed/suffixed non-closers, literal comments inside code, comments before
fences, second-call visible-fragment tilde fences, and the raw-regex failure
shape routed through the parser. All selected the expected single visible
record; hidden synthetic records stayed excluded.

An instrumented wrapper observed **466 regex calls**, maximum argument length
**1,000,016**, with **zero arguments containing LF**. Single-pass timing samples
are descriptive, not correctness thresholds or best-of reruns:

| Input | 1,000 markers | 10,000 | 100,000 | 1,000,000 |
|---|---:|---:|---:|---:|
| Actual selection, backtick fence | 0.104 ms | 0.393 ms | 3.629 ms | 35.393 ms |
| Actual selection, tilde fence after removed comment | 0.096 ms | 0.649 ms | 5.235 ms | 54.145 ms |

The direct raw-regex rejecting control grew from 3.076 ms at 1,000 backticks to
191.976 ms at 8,000; the corresponding input through the real parser took
32.720 ms even with 1,000,000 backticks. Complete raw samples and source/runtime
binding are retained in `prereg-fence-probe-20261102.json`.

Existing tests were run against the unchanged exact head:

```sh
QT_QPA_PLATFORM=offscreen PYTHONPATH=src /workspace/scratch/142cb233d750/venv/bin/python -m pytest -q tests/test_train_prereg_selection.py tests/test_prereg_tools.py tests/test_prereg_constants.py
```

Exit **0**, **138 passing test indicators**, no failures. The repository's quiet
configuration omits the summary line; the original log is retained. This was a
focused parser regression check, not a new full-suite, Windows or packaging run.
`git diff --check` passed and the isolated worktree stayed clean. Full exact-head
QA and the outstanding Sonar gate are recorded separately in the CI receipt.

Reproduce the diagnostic from the exact checkout:

```sh
PYTHONPATH=src /workspace/scratch/142cb233d750/venv/bin/python /workspace/scratch/142cb233d750/reconciliation/prereg-fence-audit-20261102/prereg-fence-probe-20261102.py
```

An initial probe with the system interpreter lacked `patchtrace` on its import
path and stopped before executing cases. The recorded successful run used the
project virtual environment and explicit `PYTHONPATH=src`. The script's unused
lint comment was removed after execution; its executable statements are the
same. No production edit or hidden retry was used to obtain passing results.
