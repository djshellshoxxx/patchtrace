"""MAT-ANCHOR for the IR deltas (SPEC-31 05 s2.5, review R-08, S3). Pure.

A semantic delta seen by the first channel (C2, the bytes group) is promoted to `material` only when a second channel
of ANOTHER data group observes the SAME change; any other difference does not count:

| delta                          | anchored by                                                                           |
|--------------------------------|---------------------------------------------------------------------------------------|
| callee, call-added/removed     | C4 differs by exactly that callee pair; else C6 shows the call; else BinDiff flag C     |
| constant, struct-offset        | C6 shows the old -> new literal pair (a constant-only edit stays `review` without C6) |
| comparison, condition          | C6 shows a changed relational or logical operator                                      |
| data-ref                       | C6 shows the datum label change between two MAPPED data tokens                         |
| string                         | C6 shows the changed string literal (C5 is in the bytes group and never anchors)       |
| block-added/removed with a     | C3 block or edge counts differ; else BinDiff flag G                                    |
| store or call                  |                                                                                        |

`register-only`, `address-only`, `frame`, `eh`, `cfg` and `unknown` are never anchored: they stay `review`.
"""
from __future__ import annotations

import re
from collections import Counter
from collections.abc import Callable, Mapping
from collections.abc import Set as AbstractSet
from dataclasses import dataclass
from functools import cached_property

from ..contracts import BLOCK_CLASSES, Delta
from . import CALL_CLASSES
from .irchannels import IrPair
from .operands import CallTarget, DeltaInfo
from .pseudo import Canon

_FIELD_OFFSET = re.compile(r'(?:^|_)0x([0-9a-fA-F]+)$')
MASKS = (0xFF, 0xFFFF, 0xFFFFFFFF, 0xFFFFFFFFFFFFFFFF)


@dataclass(frozen=True)
class AnchorInputs:
    states: Mapping[str, str]
    pair: IrPair
    canon_old: Canon | None
    canon_new: Canon | None
    bindiff_flags: tuple[str, ...] | None
    identity: Callable[[str, CallTarget | None], str | None]    # a callee as the canonical text names it
    data_token: Callable[[str, int], str | None]

    # One pair can carry thousands of deltas: every set and multiset difference below is built once per pair.
    @cached_property
    def leftovers(self) -> tuple[frozenset[CallTarget], frozenset[CallTarget]]:
        return frozenset(self.pair.leftovers[0]), frozenset(self.pair.leftovers[1])

    @cached_property
    def calls_diff(self) -> tuple[Counter, Counter]:
        return _removed_added(self.canon_old.calls, self.canon_new.calls)

    @cached_property
    def numbers_diff(self) -> tuple[Counter, Counter]:
        # Project typed literals (`#N:suffix`, canon 2) to their machine value before subtraction: a suffix-only swap
        # must not invent a numeric value change for a materiality anchor; C5/C6 equality keeps the type hints (R8).
        return _removed_added(_values(self.canon_old.numbers), _values(self.canon_new.numbers))

    @cached_property
    def tokens_diff(self) -> tuple[Counter, Counter]:
        return _removed_added(self.canon_old.tokens, self.canon_new.tokens)

    @cached_property
    def offsets_diff(self) -> tuple[set[int], set[int]]:
        """Struct offsets spelled as `field_0x..` names among the removed and the added canonical tokens."""
        removed, added = self.tokens_diff
        return _offsets(removed), _offsets(added)

    @cached_property
    def strings_diff(self) -> tuple[Counter, Counter]:
        return _removed_added(self.canon_old.strings, self.canon_new.strings)

    @cached_property
    def operators_changed(self) -> bool:
        return (Counter(self.canon_old.relational) != Counter(self.canon_new.relational)
                or Counter(self.canon_old.logical) != Counter(self.canon_new.logical))


def _values(numbers: tuple) -> tuple:
    return tuple(t.partition(':')[0] if t.startswith('#') else t for t in numbers)


def _removed_added(old: tuple, new: tuple) -> tuple[Counter, Counter]:
    return Counter(old) - Counter(new), Counter(new) - Counter(old)


def _literal_forms(value: int) -> set[str]:
    """How the decompiler may spell a machine constant: as is, negated (it prints `x - 7` for `add x, -7`) and as
    the unsigned view of every operand width."""
    forms = {value, -value, *(value & mask for mask in MASKS)}
    return {f'#{v}' for v in forms}


def _offsets(counter: Counter) -> set[int]:
    found = set()
    for token in counter:
        match = _FIELD_OFFSET.search(token)
        if match is not None:
            found.add(int(match.group(1), 16))
    return found


def _shows(counter: Counter, value: int | None, offsets: AbstractSet[int] = frozenset()) -> bool:
    if value is None:
        return True
    return bool(_literal_forms(value) & counter.keys()) or value in offsets


def _call_anchor(delta: Delta, info: DeltaInfo, inp: AnchorInputs) -> str | None:
    old_target, new_target = info.tokens
    states = inp.states
    if delta.channel != 'C4' and states.get('C4') == 'differs' and (old_target or new_target) \
            and (old_target is None or old_target in inp.leftovers[0]) \
            and (new_target is None or new_target in inp.leftovers[1]):
        return 'C4'
    if states.get('C6') == 'differs' and inp.canon_old is not None and inp.canon_new is not None:
        removed, added = inp.calls_diff
        ids = (inp.identity('older', old_target), inp.identity('newer', new_target))
        if (ids[0] is not None and ids[0] in removed) or (ids[1] is not None and ids[1] in added):
            return 'C6'
    if states.get('C8') == 'differs' and inp.bindiff_flags is not None and 'C' in inp.bindiff_flags:
        return 'C8'
    return None


def _c6_texts(inp: AnchorInputs) -> tuple[Canon, Canon] | None:
    if inp.states.get('C6') == 'differs' and inp.canon_old is not None and inp.canon_new is not None:
        return inp.canon_old, inp.canon_new
    return None


def anchor_for(delta: Delta, info: DeltaInfo, inp: AnchorInputs) -> str | None:
    """The second channel (another data group, in state `differs`) that shows the same change, or None."""
    cls = delta.cls
    if cls in CALL_CLASSES:
        return _call_anchor(delta, info, inp)
    if cls in BLOCK_CLASSES:
        if not info.effect:
            return None
        if inp.pair.counts_differ and inp.states.get('C3') == 'differs':
            return 'C3'
        return 'C8' if inp.states.get('C8') == 'differs' and inp.bindiff_flags and 'G' in inp.bindiff_flags else None
    if _c6_texts(inp) is None:
        return None
    if cls in ('constant', 'struct-offset'):
        if info.values == (None, None):
            return None
        removed, added = inp.numbers_diff
        offsets_old, offsets_new = inp.offsets_diff if cls == 'struct-offset' else (frozenset(), frozenset())
        return 'C6' if _shows(removed, info.values[0], offsets_old) and _shows(added, info.values[1], offsets_new) \
            else None
    if cls in ('comparison', 'condition'):
        return 'C6' if inp.operators_changed else None
    if cls == 'data-ref':
        token_old = inp.data_token('older', info.data[0]) if info.data[0] is not None else None
        token_new = inp.data_token('newer', info.data[1]) if info.data[1] is not None else None
        if token_old is None or token_new is None:
            return None
        removed, added = inp.tokens_diff
        return 'C6' if token_old in removed and token_new in added else None
    if cls == 'string':
        removed, added = inp.strings_diff
        return 'C6' if _string_shown(removed, info.strings[0]) and _string_shown(added, info.strings[1]) else None
    return None


def _string_shown(literals: Counter, prefix: str | None) -> bool:
    if prefix is None:
        return True
    if not prefix:
        return False
    for literal in literals:
        text = literal[1:-1].replace('\\"', '"') if len(literal) >= 2 else literal
        if text.startswith(prefix) or (text and prefix.startswith(text)):   # an empty text never matches
            return True
    return False
