"""Optional rz-diff secondary engine (SPEC-11): probe, supervised run and strict JSON parser.

stdout (the JSON document) and stderr (diagnostics) are captured independently with
`run_process(separate_streams=True)`, so diagnostics written on success cannot corrupt the
document. Stdout that is still not strict JSON is an error rather than salvaged: a
partially recovered match list would look complete. The parser works on the captured bytes
(SPEC-11 section 10): they are decoded strictly and they are what the digest covers.
"""
from __future__ import annotations

import hashlib
import re
import tempfile
import threading
from collections.abc import Callable, Mapping
from pathlib import Path

from ..jobs import run_process
from ..persistence import strict_json
from .contracts import (
    RZDIFF_LIMITATIONS,
    Capability,
    SecondaryError,
    SecondaryMatch,
    SecondaryMatchSet,
    to_milli,
)

MIN_VERSION = (0, 9, 0)
TESTED_SERIES = '0.9.'  # the only series with live evidence; the unified adapter flags the same boundary
STDOUT_LIMIT = 64 * 1024 * 1024
STDERR_TAIL = 2 * 1024 * 1024
DEFAULT_TIMEOUT = 1800
TIMEOUT_RANGE = (60, 86_400)
PROBE_TIMEOUT = 30
TYPES = frozenset({'COMPLETE', 'PARTIAL', 'UNLIKE'})
ENTRY_KEYS = frozenset({'similarity', 'type', 'original', 'modified'})
SIDE_KEYS = frozenset({'addr', 'name', 'size'})
_VERSION = re.compile(r'^rz-diff ([0-9]{1,9})\.([0-9]{1,9})\.([0-9]{1,9})\b')
SINGLETON_KIND = 'rzdiff-singleton-ownership'
# Shown truncated to 200 characters by the evidence view, so the whole text stays below that.
SINGLETON_MESSAGE = ('rz-diff result not stored: it lists at most one newer-side function, and for that shape rz-diff '
                     'can swap older and newer sides without a trace. The pair itself may be fine; use another '
                     'engine for it.')
NO_FUNCTIONS_KIND = 'no-functions'
# rz-diff numbers its two positional files; file0 is the retained native form, file1 follows the same message.
_NO_FUNCTIONS = re.compile(r'No functions found in file([01])')
_SIDES = {'0': 'older', '1': 'newer'}


def parse_version(text: str) -> tuple[str, tuple[int, int, int]] | None:
    for line in text.splitlines():
        if (match := _VERSION.match(line.strip())) and all(len(g) <= 9 for g in match.groups()):
            numbers = tuple(int(g) for g in match.groups())
            return '.'.join(match.groups()), numbers  # type: ignore[return-value]
    return None


def probe(executable: Path, env: Mapping[str, str], cancel: threading.Event | None = None,
          runner: Callable = run_process) -> Capability:
    """Never installs anything; an unrecognised or old version is `unsupported`, not an error."""
    path = str(executable)
    with tempfile.TemporaryDirectory(prefix='patchtrace-rzprobe-') as cwd:
        try:
            result = runner([path, '-v'], cwd=Path(cwd), env=env, cancel=cancel or threading.Event(),
                            timeout_seconds=PROBE_TIMEOUT, log_limit=64 * 1024)
        except (OSError, ValueError) as exc:
            return Capability(engine='rz-diff', supported=False, version=None, path=path, supports_json=False,
                              reason=f'cannot run rz-diff: {exc}')
    if result.reason or result.returncode != 0:
        return Capability(engine='rz-diff', supported=False, version=None, path=path, supports_json=False,
                          reason=f'rz-diff -v failed ({result.reason or result.returncode})')
    parsed = parse_version(result.log_tail)
    if parsed is None:
        return Capability(engine='rz-diff', supported=False, version=None, path=path, supports_json=False,
                          reason='rz-diff -v printed no recognisable version')
    text, numbers = parsed
    if numbers < MIN_VERSION:
        return Capability(engine='rz-diff', supported=False, version=text, path=path, supports_json=False,
                          reason=f'rz-diff {text} is older than 0.9.0')
    return Capability(engine='rz-diff', supported=True, version=text, path=path, supports_json=True)


def untested_version(version: str) -> bool:
    return not version.startswith(TESTED_SERIES)


def captured_stdout(result) -> bytes | str:
    """The exact bytes `jobs.run_process` captured; the lossy text only for a runner that kept no bytes."""
    data = getattr(result, 'log_bytes', None)
    return result.log_tail if data is None else data


def _fail(message: str) -> SecondaryError:
    return SecondaryError('PT-SECONDARY-INPUT', message)


def _text_and_bytes(stdout: str | bytes) -> tuple[str, bytes]:
    """JSON text and the bytes the digest covers. Bytes are decoded strictly: nothing is replaced."""
    if len(stdout) > STDOUT_LIMIT:  # for text a cheap first check; its UTF-8 size is checked below
        raise SecondaryError('PT-SECONDARY-LIMIT', 'rz-diff output exceeds 64 MiB')
    if isinstance(stdout, bytes):
        try:
            return stdout.decode('utf-8'), stdout
        except UnicodeDecodeError as exc:
            raise _fail(f'rz-diff output is not valid UTF-8 at byte offset {exc.start}') from None
    try:
        data = stdout.encode('utf-8')
    except UnicodeEncodeError:
        raise _fail('rz-diff output is not valid UTF-8') from None
    if len(data) > STDOUT_LIMIT:
        raise SecondaryError('PT-SECONDARY-LIMIT', 'rz-diff output exceeds 64 MiB')
    return stdout, data


def _side(value, index: int, label: str) -> tuple[int, str] | None:
    if value is None:
        return None
    if not isinstance(value, dict) or set(value) != SIDE_KEYS:
        raise _fail(f'entry {index}: {label} must be null or an object with addr, name, size')
    addr, name, size = value['addr'], value['name'], value['size']
    if isinstance(addr, bool) or not isinstance(addr, int) or not 0 <= addr < 2**64:
        raise _fail(f'entry {index}: {label}.addr is not an unsigned 64-bit integer')
    if not isinstance(name, str):
        raise _fail(f'entry {index}: {label}.name is not a string')
    if isinstance(size, bool) or not isinstance(size, int) or size < 0:
        raise _fail(f'entry {index}: {label}.size is not a non-negative integer')
    return addr, name


def parse_output(stdout: str | bytes, version: str, older_sha256: str, newer_sha256: str) -> SecondaryMatchSet:
    text, data = _text_and_bytes(stdout)
    if not text.strip():
        raise _fail('rz-diff produced no output')
    try:
        document = strict_json(text)
    except ValueError:
        raise _fail('rz-diff output is not valid strict JSON') from None
    if not isinstance(document, list):
        raise _fail('rz-diff output is not a JSON array')
    matches = []
    newer_functions: set[int] = set()
    for index, entry in enumerate(document):
        if not isinstance(entry, dict) or set(entry) != ENTRY_KEYS:
            raise _fail(f'entry {index}: expected keys similarity, type, original, modified')
        if not isinstance(entry['type'], str) or entry['type'] not in TYPES:
            raise _fail(f'entry {index}: unknown type {entry["type"]!r}')
        try:
            milli, text = to_milli(entry['similarity'], f'entry {index}: similarity')
        except SecondaryError as exc:
            raise _fail(exc.message) from None
        older = _side(entry['original'], index, 'original')
        newer = _side(entry['modified'], index, 'modified')
        if older is None and newer is None:
            raise _fail(f'entry {index}: both sides are null')
        if newer is not None:
            newer_functions.add(newer[0])
        matches.append(SecondaryMatch(
            engine='rz-diff', engine_version=version,
            older_address=older[0] if older else None, newer_address=newer[0] if newer else None,
            older_name=older[1] if older else None, newer_name=newer[1] if newer else None,
            similarity_milli=milli, similarity_text=text, confidence_milli=None, confidence_text=None,
            flags=(), algorithm='levenshtein-bytes', match_type=entry['type']))
    if matches and len(newer_functions) <= 1:
        # SPEC-11 section 9: rizin 0.9.1 swaps the sides when the older file has one function, and the output
        # cannot show whether it did. Refused, never swapped back: a swap would corrupt every ordinary result.
        raise SecondaryError('PT-SECONDARY-ORIENTATION', SINGLETON_MESSAGE, kind=SINGLETON_KIND)
    return SecondaryMatchSet(engine='rz-diff', engine_version=version, older_sha256=older_sha256,
                             newer_sha256=newer_sha256,
                             file_sha256=hashlib.sha256(data).hexdigest(),
                             matches=tuple(matches), limitations=RZDIFF_LIMITATIONS)


def run_rzdiff(capability: Capability, older: Path, newer: Path, older_sha256: str, newer_sha256: str, *,
               env: Mapping[str, str], cancel: threading.Event, timeout_seconds: int = DEFAULT_TIMEOUT,
               runner: Callable = run_process) -> SecondaryMatchSet:
    if not capability.supported or capability.version is None:
        raise SecondaryError('PT-SECONDARY-UNSUPPORTED', capability.reason or 'rz-diff is not supported')
    if isinstance(timeout_seconds, bool) or not isinstance(timeout_seconds, int) or \
            not TIMEOUT_RANGE[0] <= timeout_seconds <= TIMEOUT_RANGE[1]:
        raise SecondaryError('PT-SECONDARY-INPUT', 'timeout must be an integer between 60 and 86400 seconds')
    older, newer = Path(older).resolve(), Path(newer).resolve()
    for item in (older, newer):
        if not item.is_file():
            raise SecondaryError('PT-SECONDARY-INPUT', f'artifact {item.name} is not a readable file')
    argv = list(rzdiff_argv(capability.path, older, newer))
    with tempfile.TemporaryDirectory(prefix='patchtrace-rzdiff-') as cwd:
        # One byte over the limit lets truncation be detected rather than silently parsed; max_output_bytes
        # stops a flood there instead of at the deadline (SPEC-28 §9.3).
        result = runner(argv, cwd=Path(cwd), env=env, cancel=cancel, timeout_seconds=timeout_seconds,
                        log_limit=STDOUT_LIMIT + 1, separate_streams=True, stderr_limit=STDERR_TAIL,
                        max_output_bytes=STDOUT_LIMIT)
    if result.reason == 'cancelled':
        raise SecondaryError('PT-SECONDARY-CANCEL', 'rz-diff was cancelled')
    if result.reason == 'timeout':
        raise SecondaryError('PT-SECONDARY-RUN', f'rz-diff exceeded the {timeout_seconds} s timeout')
    if result.reason == 'output-limit':
        raise SecondaryError('PT-SECONDARY-LIMIT', 'rz-diff output exceeds 64 MiB', kind='output-limit')
    if result.reason:
        raise SecondaryError('PT-SECONDARY-RUN', f'rz-diff stopped: {result.reason}')
    return interpret(result.returncode, captured_stdout(result), result.stderr_tail, capability.version,
                     older_sha256, newer_sha256)


def rzdiff_argv(executable: str, older: Path, newer: Path) -> tuple[str, ...]:
    """Flags frozen for rizin 0.9.x (SPEC-28 C2 re-verifies them on the pinned release)."""
    return (executable, '-C', '-j', '-t', 'functions', str(older), str(newer))


def interpret(returncode: int, output: str | bytes, stderr_tail: str, version: str, older_sha256: str,
              newer_sha256: str, stdout_limit: int = STDOUT_LIMIT) -> SecondaryMatchSet:
    """Turn a finished rz-diff process (no cancel/timeout) into a strict match set.

    `output` is the captured stdout bytes, or the lossy text of a runner that kept no bytes."""
    exact = isinstance(output, bytes)
    if returncode != 0:
        shown = stderr_tail or (output.decode('utf-8', errors='replace') if exact else output)
        tail = shown.encode('utf-8')[-STDERR_TAIL:].decode('utf-8', errors='replace')
        raise SecondaryError('PT-SECONDARY-RUN', f'rz-diff exited with {returncode}: {tail}')
    if len(output if exact else output.encode('utf-8')) > stdout_limit:
        raise SecondaryError('PT-SECONDARY-LIMIT', 'rz-diff output exceeds 64 MiB')
    if not exact and '\ufffd' in output:  # lossy text: this may stand for a byte that was replaced
        raise SecondaryError('PT-SECONDARY-INPUT', 'rz-diff output is not valid UTF-8')
    if not output.strip() and (found := _NO_FUNCTIONS.search(stderr_tail)):
        raise SecondaryError(
            'PT-SECONDARY-INPUT', f'rz-diff reported no functions in the {_SIDES[found.group(1)]} file, so it '
            'compared nothing. rz-diff may not support this file; use another engine for this pair.',
            kind=NO_FUNCTIONS_KIND)
    return parse_output(output, version, older_sha256, newer_sha256)


def ambiguous_stored_ownership(match_set: SecondaryMatchSet) -> bool:
    """Apply the parser's ownership boundary to historical normalized sets without mutating them."""
    if match_set.engine != 'rz-diff' or not match_set.matches:
        return False
    first = None
    for row in match_set.matches:
        if row.newer_address is not None:
            if first is None:
                first = row.newer_address
            elif row.newer_address != first:
                return False
    return True
