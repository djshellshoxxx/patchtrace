"""One bounded offline shared gate for the inspected batch6 replacement scopes."""
from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import os
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
OUT = Path(__file__).resolve().parent
PY = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
BASE = '55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
files = ['test_' + name + '.py' for name in (
    'backend_java_version', 'unified_corpus_workflow',
    'kb_crash_injection_protocol', 'kb_cvrf_fixture_import', 'kb_fixture_encoding', 'kb_fixture_properties',
    'kb_metadata_fixture_boundaries', 'kb_offline_fixture_import', 'kb_raw_adversarial_inputs',
    'kb_synthetic_fixture_corpus', 'kb_update_relationships',
    'unified_fixture_fusion_properties', 'unified_fixture_gate_u1', 'unified_fixture_gate_u2',
    'unified_fixture_gate_u3', 'unified_fixture_gate_u4', 'unified_fixture_gate_u5',
    'unified_fixture_gate_u6', 'unified_fixture_gate_u7', 'unified_fixture_read_model_golden',
    'unified_fixture_statistics', 'unified_fixture_timing', 'unified_synthetic_pairs', 'unified_synthetic_pe',
    'unified_live_force_identical', 'unified_live_native_failure_details', 'unified_live_pairs_r1',
    'unified_gate_eval', 'unified_rb01_harness',
)]
selected = []
deselected = ['tests/test_unified_rb01_harness.py::' + node for node in (
    'test_the_engine_image_of_a_mutant_module_exports_every_candidate',
    'test_the_path_nuisance_pair_labels_every_function_the_same_function',
)]
all_files = sorted({'tests/' + p for p in files} | {s.split('::')[0] for s in selected})
command = [PY, '-m', 'pytest', '-q', '-ra', *('tests/' + p for p in files), *selected,
           *('--deselect=' + p for p in deselected), '--junitxml=' + str(OUT / 'current-affected.xml')]
env = {**os.environ, 'PYTHONPATH': str(ROOT / 'src') + ':' + str(ROOT / 'tests'),
       'QT_QPA_PLATFORM': 'offscreen'}
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
assert git('rev-parse', 'HEAD') == BASE
assert not git('diff', '--', 'src', 'tests', 'tools', '.github')
metadata = dict(source=BASE, source_tree=git('rev-parse', 'HEAD^{tree}'),
                started_utc=datetime.now(UTC).isoformat(), cwd=str(ROOT), command=command,
                environment={k: env[k] for k in ('PYTHONPATH', 'QT_QPA_PLATFORM')},
                test_files=all_files, selected_nodes=selected, explicit_deselections=deselected,
                excluded_network_fixture='tests/test_build_backend_bundle.py::test_cli_build_refuses_a_pin_with_a_placeholder_with_a_clear_exit_code (not selected)',
                limits='Offline synthetic/fake-runner mechanics only; no compiler, native engine, target execution, network, Windows package or manual acceptance. System-temp fixtures, no custom basetemp.',
                test_file_sha256={p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in all_files})
assert not (OUT / 'current-affected.log').exists()
with (OUT / 'current-affected.log').open('x') as log:
    run = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
metadata.update(exit_code=run.returncode, finished_utc=datetime.now(UTC).isoformat())
if (OUT / 'current-affected.xml').exists():
    xml = ET.parse(OUT / 'current-affected.xml').getroot()
    metadata['junit_suites'] = [s.attrib for s in xml.iter('testsuite')]
    metadata['nonpasses'] = [dict(node=c.get('classname') + '::' + c.get('name'),
                                kind=child.tag, message=child.get('message'))
                           for c in xml.iter('testcase') for child in c
                           if child.tag in ('failure', 'error', 'skipped')]
(OUT / 'current-command.json').write_text(json.dumps(metadata, indent=2) + '\n')
print('exit', run.returncode, 'files', len(all_files))
print('\n'.join((OUT / 'current-affected.log').read_text().splitlines()[-35:]))
