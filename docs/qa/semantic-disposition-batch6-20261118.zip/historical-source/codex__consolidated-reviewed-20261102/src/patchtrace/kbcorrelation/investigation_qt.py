"""Offline investigation dialog; worker requests contain no widgets or SQLite objects."""
from __future__ import annotations

import time
from dataclasses import replace
from functools import partial
from pathlib import Path

from PySide6.QtWidgets import (
    QCheckBox,
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLineEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from ..gui.qt.labels import PlainLabel, SafeTextView
from ..gui.qt.tasks import TaskRunner
from ..gui.text import sanitize_text
from ..gui.tips import apply_tip, register_tips
from ..tooltips import TooltipEntry
from .investigation_service import InvestigationRequest, InvestigationResult, execute_request
from .store import default_workspace

SOURCE = 'Local advisory workspace and inspected local PE files; no online acquisition is performed.'
DESCRIPTIONS = {
    'workspace': 'Directory containing the local advisory workspace.',
    'source': 'Local supported advisory document to import.',
    'lead': 'KB or CVE identifier to search in the stored documents.',
    'scope': 'Explicit product, architecture and release used for this comparison.',
    'older': 'Older local AMD64 PE binary; its bytes are inspected and never executed.',
    'newer': 'Newer local AMD64 PE binary; its bytes are inspected and never executed.',
    'destination': 'New or empty directory outside the currently open project.',
    'name': 'Name for the new comparison project.',
    'same_component': 'Explicitly confirm differently named files represent the same component.',
    'import': 'Import the chosen local advisory into the workspace.',
    'search': 'Search stored advisory documents without accessing the network.',
    'preview': 'Inspect the chosen local pair and display its hashes and limitations.',
    'create': 'Create a separate project using exactly the current pair preview.',
    'cancel': 'Cancel pending work, or retain a project whose commit already started.',
    'close': 'Close the investigation without replacing the currently open project.',
    'details': 'Plain-text coverage, source evidence, pair hashes and operation results.',
    'status': 'Current local investigation status.',
    'browse_workspace': 'Choose the local advisory workspace directory.',
    'browse_source': 'Choose a local advisory JSON or compressed JSON file.',
    'browse_older': 'Choose the older local binary.',
    'browse_newer': 'Choose the newer local binary.',
    'browse_destination': 'Choose a parent directory for a new comparison folder.',
}
TIPS = {f'kb.investigation.{key}': TooltipEntry(text, 'Keeps the local investigation explicit and inspectable.',
                                             'Local operation only; target binaries are not run.', SOURCE)
        for key, text in DESCRIPTIONS.items()}


class InvestigationDialog(QDialog):
    def __init__(self, parent=None, *, workspace=None, tasks=None, on_created=None, current_project=None,
                 execute=execute_request, notice=None):
        super().__init__(parent)
        register_tips(TIPS)
        self.setWindowTitle('Investigate KB/CVE · offline')
        self.resize(920, 760)
        self.tasks = tasks if tasks is not None else TaskRunner(self)
        self._own_tasks = tasks is None
        self._execute, self._on_created, self._notice = execute, on_created, notice
        self._current_project = Path(current_project) if current_project is not None else None
        self._channel = f'kb.investigation.{id(self)}'
        self._generation, self._closed = 0, False
        self._pending = None
        self._pending_token = None
        self._preview = None
        self._investigation_id = None
        self._cancel_create, self._close_after_create = False, False
        root = QVBoxLayout(self)
        heading = PlainLabel('Import an advisory, search a KB/CVE and choose a product. Preview local older/newer '
                             'files before creating a separate comparison. Nothing is downloaded or executed.',
                             wrap=True)
        root.addWidget(heading)
        form = QFormLayout()
        self.fields = {}
        self.buttons = {}
        values = {'workspace': str(workspace if workspace is not None else default_workspace()),
                  'source': '', 'lead': '', 'older': '', 'newer': '', 'destination': '', 'name': 'KB comparison'}
        for key, title in (('workspace', 'Advisory workspace'), ('source', 'Advisory file'), ('lead', 'KB/CVE'),
                           ('older', 'Older local binary'), ('newer', 'Newer local binary'),
                           ('destination', 'New project directory'), ('name', 'Project name')):
            field = self.fields[key] = QLineEdit(values[key])
            self._tip(field, key)
            row = QWidget()
            layout = QHBoxLayout(row)
            layout.setContentsMargins(0, 0, 0, 0)
            layout.addWidget(field, 1)
            if key in {'workspace', 'source', 'older', 'newer', 'destination'}:
                button = self._button('browse_' + key, 'Browse…')
                button.clicked.connect(lambda _checked=False, k=key: self._browse(k))
                layout.addWidget(button)
            if key in {'source', 'lead'}:
                action = 'import' if key == 'source' else 'search'
                button = self._button(action, 'Import advisory' if action == 'import' else 'Search locally')
                if action == 'search':
                    button.clicked.connect(self._search_new)
                else:
                    button.clicked.connect(lambda: self._submit(self._request('import')))
                layout.addWidget(button)
            form.addRow(title, row)
            field.textChanged.connect(lambda _text, k=key: self._edited(k))
        self.scope = QComboBox()
        self._tip(self.scope, 'scope')
        self.scope.addItem('Choose a product explicitly', None)
        self.scope.currentIndexChanged.connect(self._scope_changed)
        form.insertRow(3, 'Product / architecture / release', self.scope)
        self.same_component = QCheckBox('I confirm that differently named files are the same component')
        self._tip(self.same_component, 'same_component')
        self.same_component.toggled.connect(lambda _: self._invalidate())
        form.addRow(self.same_component)
        root.addLayout(form)
        actions = QHBoxLayout()
        for key, title in (('preview', 'Preview local pair'), ('create', 'Create and open comparison'),
                           ('cancel', 'Cancel operation'), ('close', 'Close')):
            actions.addWidget(self._button(key, title))
        self.buttons['preview'].clicked.connect(lambda: self._submit(self._request('preview')))
        self.buttons['create'].clicked.connect(self._create)
        self.buttons['cancel'].clicked.connect(self.cancel_operation)
        self.buttons['close'].clicked.connect(self.reject)
        root.addLayout(actions)
        self.details = SafeTextView('Local investigation details', wrap=True)
        self._tip(self.details, 'details')
        root.addWidget(self.details, 1)
        self.status = PlainLabel('Local files only. No comparison has been created.', wrap=True)
        self._tip(self.status, 'status')
        root.addWidget(self.status)
        self._enable()

    @staticmethod
    def _tip(widget, key):
        widget.setObjectName('kb.investigation.' + key)
        widget.setAccessibleName(DESCRIPTIONS[key])
        apply_tip(widget, 'kb.investigation.' + key)

    def _button(self, key, text):
        button = QPushButton(text)
        self._tip(button, key)
        self.buttons[key] = button
        return button

    def _browse(self, key):
        if key in {'workspace', 'destination'}:
            value = QFileDialog.getExistingDirectory(self, 'Choose a directory', self.fields[key].text())
            if value and key == 'destination':
                value = str(Path(value) / time.strftime('kb-comparison-%Y%m%d-%H%M%S'))
        else:
            value, _ = QFileDialog.getOpenFileName(self, DESCRIPTIONS[key], self.fields[key].text())
        if value:
            self.fields[key].setText(value)

    def _request(self, operation):
        def path(key):
            value = self.fields[key].text().strip()
            return Path(value).expanduser() if value else None
        return InvestigationRequest(operation, path('workspace') or default_workspace(), source=path('source'),
                                    lead=self.fields['lead'].text().strip(), investigation_id=self._investigation_id,
                                    scope_id=self.scope.currentData(), older=path('older'), newer=path('newer'),
                                    destination=path('destination'), name=self.fields['name'].text().strip(),
                                    current_project=self._current_project,
                                    confirm_same_component=self.same_component.isChecked())

    def _edited(self, key):
        self._invalidate()
        if key in {'workspace', 'lead'}:
            self._investigation_id = None
            self._set_scopes([], None)
            self._enable()

    def _invalidate(self):
        self._preview = None
        if self._pending is not None and self._pending.operation != 'create':
            self._generation += 1
            self.tasks.cancel(self._channel)
            self._pending = None
            self._pending_token = None
        self._enable()

    def _set_scopes(self, scopes, selected):
        self.scope.blockSignals(True)
        self.scope.clear()
        self.scope.addItem('Choose a product explicitly', None)
        for scope in scopes:
            text = ' · '.join(str(scope.get(k) or 'unknown') for k in
                              ('display_name', 'architecture', 'release', 'mapping'))
            self.scope.addItem(sanitize_text(text, 500), scope['scope_id'])
        index = self.scope.findData(selected) if selected else 0
        self.scope.setCurrentIndex(max(0, index))
        self.scope.blockSignals(False)

    def _scope_changed(self):
        self._invalidate()
        if self._investigation_id and self.scope.currentData():
            self._submit(self._request('search'))

    def _search_new(self):
        self._preview = None
        self._submit(replace(self._request('search'), investigation_id=None, scope_id=None))

    def _enable(self):
        busy = self._pending is not None
        for field in self.fields.values():
            field.setEnabled(not busy)
        self.scope.setEnabled(not busy and self._investigation_id is not None)
        self.same_component.setEnabled(not busy)
        for button in self.buttons.values():
            button.setEnabled(not busy)
        self.buttons['cancel'].setEnabled(busy)
        self.buttons['close'].setEnabled(True)
        pair_ready = self._investigation_id is not None and self.scope.currentData() is not None
        self.buttons['preview'].setEnabled(not busy and pair_ready
                                          and bool(self.fields['older'].text() and self.fields['newer'].text()))
        self.buttons['create'].setEnabled(not busy and self._preview is not None
                                         and bool(self.fields['destination'].text().strip()))

    def _submit(self, request):
        if self._closed or self._pending is not None:
            return
        if not self.fields['workspace'].text().strip():
            self.status.setText('Choose an advisory workspace directory before continuing.')
            return
        self._generation += 1
        generation = self._generation
        self._pending = request
        self._cancel_create, self._close_after_create = False, False
        self.status.setText({'import': 'Importing local advisory…', 'search': 'Searching stored documents…',
                             'preview': 'Inspecting local pair…', 'create': 'Creating separate comparison…'}
                            [request.operation])
        self._enable()
        # The worker owns only immutable plain request data and a pure function.
        execute = self._execute
        def work(token, _report):
            return execute(request, token)
        self._pending_token = self.tasks.submit(
            self._channel, work, partial(self._loaded, generation, request), partial(self._failed, generation))

    def _loaded(self, generation, request, result: InvestigationResult):
        if self._closed or generation != self._generation:
            return
        self._pending = None
        self._pending_token = None
        self.status.setText(('' if result.success else f'{result.error_code or "PT-KBC-INPUT"}: ') + result.text)
        text = result.text
        if result.success and request.operation == 'import':
            self._investigation_id, self._preview = None, None
            self._set_scopes([], None)
        elif result.success and request.operation == 'search':
            self._preview = None
            self._investigation_id = result.data.get('investigation_id')
            self._set_scopes(result.data.get('scopes', ()), request.scope_id)
            refs = [ref for edge in result.data.get('edges', ()) for ref in edge.get('refs', ())]
            text += '\n' + '\n'.join(f'Source {r.get("doc_id", "unknown")} {r.get("pointer", "")}' for r in refs)
        elif result.success and request.operation == 'preview':
            self._preview = (request, result)
            pair = result.data.get('pair', {})
            text += (f'\nProduct: {self.scope.currentText()}\nOlder SHA-256: {pair.get("older_sha256")}\n'
                     f'Newer SHA-256: {pair.get("newer_sha256")}\nLineage: {pair.get("lineage_state")}\n'
                     f'Fix boundary: {pair.get("fix_boundary")}\nLimits: {", ".join(pair.get("reason_codes", ()))}')
        elif request.operation == 'create' and result.project_path is not None:
            self._preview = None
            if not result.success or self._cancel_create or self._close_after_create or self._on_created is None:
                prefix = result.text + '\n' if not result.success else ''
                text = prefix + f'Project retained without opening: {result.project_path}'
                self.status.setText(text)
                if self._notice:
                    self._notice(text)
            elif self._on_created:
                try:
                    self._on_created(result.project_path)
                except Exception:
                    text = f'Project retained, but could not be opened: {result.project_path}'
                    self.status.setText(text)
                    if self._notice:
                        self._notice(text)
                else:
                    self._closed = True
                    self._shutdown()
                    super().accept()
            if self._close_after_create:
                self._closed = True
                self._shutdown()
                super().reject()
        elif not result.success:
            self._preview = None
        self.details.setPlainText(text)
        self._enable()
        if request.operation == 'create' and self._close_after_create and not self._closed:
            if self._notice:
                self._notice(self.status.full_text())
            self._closed = True
            self._shutdown()
            super().reject()

    def _failed(self, generation, failure):
        if self._closed or generation != self._generation:
            return
        self._pending, self._preview = None, None
        self._pending_token = None
        self.status.setText(f'{failure.code}: {failure.exception_class} stopped the local operation. Previous results remain.')
        self._enable()
        if self._close_after_create:
            if self._notice:
                self._notice(self.status.full_text())
            self._closed = True
            self._shutdown()
            super().reject()

    def _create(self):
        if self._preview is None:
            return
        request, result = self._preview
        request = replace(request, operation='create', expected_pair_id=result.data['pair']['pair_id'],
                          expected_revision=result.data['investigation_revision'])
        self._submit(request)

    def cancel_operation(self):
        if self._pending is not None and self._pending.operation == 'create':
            self._cancel_create = True
            # Keep the generation current: cancellation must not discard a committed
            # project path or the acknowledgement that no project was created.
            if self._pending_token is not None:
                self._pending_token.set()
            self.status.setText('Cancelling local project creation; any completed project will be retained, not opened.')
            return
        self._generation += 1
        self.tasks.cancel(self._channel)
        self._pending, self._preview = None, None
        self._pending_token = None
        self.status.setText('Cancelled. Previous results remain available.')
        self._enable()

    def _shutdown(self):
        if self._own_tasks:
            self.tasks.shutdown()

    def reject(self):
        if self._pending is not None and self._pending.operation == 'create':
            self._close_after_create = True
            self.cancel_operation()
            return
        self.cancel_operation()
        self._closed = True
        self._shutdown()
        super().reject()
