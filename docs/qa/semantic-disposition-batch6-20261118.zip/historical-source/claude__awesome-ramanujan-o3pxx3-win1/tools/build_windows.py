"""Build an auditable, replaceable-DLL Windows desktop distribution."""
from __future__ import annotations

import importlib.metadata
import json
import shutil
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
# Pure shared helpers; importing build_linux runs no build.
import check_windows_exe  # noqa: E402
import windows_icon  # noqa: E402
import windows_version_info  # noqa: E402
from build_linux import (  # noqa: E402
    attach_backend,
    check_archive_size,
    full_archive_name,
    parse_args,
    sha256_file,
)

PROTOBUF_PIN = '7.36.2'
# SPEC-10b §2/§9: BinExport2 notices; build refuses to publish without them.
BINEXPORT_NOTICES = [f'protobuf-{PROTOBUF_PIN}/LICENSE', 'binexport-2bff7af/LICENSE',
                     'binexport-2bff7af/binexport2.proto', 'binexport-2bff7af/PROVENANCE.txt']
# SPEC-31 s9: the unified engine's MD index re-expresses BinDiff v8 (Apache-2.0); the notice ships with the package.
BINDIFF_NOTICES = ['bindiff-v8-aecc14d/LICENSE', 'bindiff-v8-aecc14d/PROVENANCE.txt']
# SPEC-31 03 s3: the Ghidra extractor script runs in the user's external Python, so it travels as a data file.
EXTRACTOR_SCRIPT = 'patchtrace/unified/extract/ghidra_script.py'
# SPEC-53 GHR-2: the Ghidriff launcher also runs in the user's external Python, so it is a data file too.
LAUNCHER_SCRIPT = 'patchtrace/ghidriff_launch/ptlaunch.py'


def _installed(name):
    try:
        importlib.metadata.distribution(name)
    except importlib.metadata.PackageNotFoundError:
        return False
    return True


def require_upb_protobuf():
    """Fail before freezing if the pinned protobuf is absent or would run as the pure-Python fallback."""
    from google.protobuf.internal import api_implementation
    if importlib.metadata.version('protobuf') != PROTOBUF_PIN or api_implementation.Type() != 'upb':
        raise RuntimeError(f'protobuf {PROTOBUF_PIN} with the upb backend is required '
                           "(pip install --only-binary=:all: -e '.[dev]')")


def pyinstaller_command(root: Path, icon: Path, version_file: Path) -> list[str]:
    return [sys.executable, '-m', 'PyInstaller', '--noconfirm', '--clean',
            # Console subsystem so headless commands return output and exit codes to the
            # invoking shell; the bootloader hides a console the process owns (double-click),
            # leaving an inherited terminal attached (PyInstaller >= 6, SPEC-05 §3.2).
            '--onedir', '--console', '--hide-console', 'hide-early', '--name', 'PatchTrace',
            # SPEC-52 WIN-1: file icon and version resource (no manifest: PyInstaller's default asInvoker one stays).
            '--icon', str(icon), '--version-file', str(version_file),
            '--exclude-module', 'PySide6.QtWebEngineCore',
            '--exclude-module', 'PySide6.QtWebEngineQuick',
            '--exclude-module', 'PySide6.QtWebEngineWidgets',
            '--exclude-module', 'PySide6.QtPdf',
            '--exclude-module', 'PySide6.QtPdfWidgets',
            '--additional-hooks-dir', str(root / 'tools' / 'pyinstaller_hooks'),
            '--paths', str(root / 'src'),
            str(root / 'tools' / 'desktop_entry.py')]


def main(argv=None):
    args = parse_args(argv)
    if sys.platform != 'win32':
        raise SystemExit('Build on Windows: PyInstaller cannot cross-compile the Windows runtime.')
    root = Path(__file__).resolve().parents[1]
    require_upb_protobuf()
    resources = root / 'build' / 'windows-resources'
    fields = windows_version_info.fields_for_build(args.version, root=root)
    version_file = windows_version_info.write(fields, resources / 'version-info.txt')
    icon = resources / 'PatchTrace.ico'
    icon.write_bytes(windows_icon.pack_ico(windows_icon.render_frames()))
    subprocess.run(pyinstaller_command(root, icon, version_file), cwd=root, check=True)
    package = root / 'dist' / 'PatchTrace'
    shutil.copy2(root / 'LICENSE', package / 'LICENSE.txt')
    shutil.copy2(root / 'README.md', package / 'README.md')
    shutil.copytree(root / 'docs', package / 'docs', dirs_exist_ok=True)
    notices = package / 'licenses'
    notices.mkdir(exist_ok=True)
    versions = {'Python': sys.version.split()[0], 'PatchTrace': fields.label, 'PatchTrace commit': fields.commit}
    bundled_notices = root / 'third_party' / 'notices'
    required = ['qtbase-6.12.0/LICENSES/LGPL-3.0-only.txt',
                'pyside-setup-6.12.0/LICENSES/LGPL-3.0-only.txt',
                'pyinstaller-6.22.3/COPYING.txt', 'README.md',
                'qtbase-6.12.0/attributions/README.md',
                'pyside-setup-6.12.0/sources/PySide6-licensecomment.txt']
    required += [f'openssl-{version}/{name}'
                 for version in ['3.0.16', '3.5.5']
                 for name in ['LICENSE.txt', 'ACKNOWLEDGEMENTS.md']]
    required += [f'{module}-6.12.0/LICENSES/{name}.txt'
                 for module in ['qtbase', 'pyside-setup']
                 for name in ['GPL-2.0-only', 'GPL-3.0-only', 'Qt-GPL-exception-1.0']]
    required += BINEXPORT_NOTICES + BINDIFF_NOTICES
    if any(not (bundled_notices / item).is_file() for item in required):
        raise RuntimeError('Pinned third-party notices are missing; refusing to publish distribution')
    if len(list((bundled_notices / 'qtbase-6.12.0/attributions').glob('*.html'))) != 49:
        raise RuntimeError('Qt Core/GUI/Network attribution set is incomplete')
    shutil.copytree(bundled_notices, notices / 'upstream', dirs_exist_ok=True)
    for name in ['PySide6', 'PySide6_Essentials', 'PySide6_Addons', 'PySide6_WebEngine', 'PySide6_Pdf', 'shiboken6', 'pydantic',
                 'pydantic_core', 'PyInstaller', 'annotated-types', 'typing_extensions', 'typing-inspection',
                 'protobuf', *[n for n in ('rapidfuzz', 'yara-x', 'iced-x86') if _installed(n)]]:
        dist = importlib.metadata.distribution(name)
        versions[name] = dist.version
        files = dist.files
        if not files:
            raise RuntimeError(f'{name}: no installed file list; cannot copy its licenses')
        for file in files:
            if any(word in file.name.lower() for word in ['license', 'copying', 'notice']):
                source = Path(dist.locate_file(file))
                if source.is_file():
                    target = notices / name / str(file).replace('../', '_')
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(source, target)
    # Python redistribution notice accompanies the bundled interpreter.
    py_license = Path(sys.base_prefix) / 'LICENSE.txt'
    if not py_license.is_file():
        raise RuntimeError('Python redistribution license is missing')
    shutil.copy2(py_license, notices / 'Python-LICENSE.txt')
    (package / 'dependency-versions.json').write_text(json.dumps(versions, indent=2), encoding='utf-8')
    inventory = sorted(str(path.relative_to(package)).replace('\\', '/')
                       for path in package.rglob('*') if path.is_file())
    unexpected = [item for item in inventory
                  if Path(item).suffix.lower() in {'.dll', '.pyd', '.exe', '.pak'}
                  and any(name in Path(item).name.lower() for name in
                          ['webengine', 'pdf', 'virtualkeyboard', 'qt6quick', 'qt6qml'])]
    if unexpected:
        raise RuntimeError(f'Unexpected unused WebEngine/PDF binaries collected: {unexpected}')
    # A missing upb extension means a silent pure-Python protobuf fallback (85x memory): never publish that.
    if not any(item.startswith(('google/_upb/_message.', '_internal/google/_upb/_message.')) for item in inventory):
        raise RuntimeError('google/_upb/_message extension missing from the frozen package')
    # The extractor script must be in the package and byte-identical to the source tree's copy.
    packaged = [item for item in inventory if item.endswith('/' + EXTRACTOR_SCRIPT)]
    if len(packaged) != 1 or (package / packaged[0]).read_bytes() != (root / 'src' / EXTRACTOR_SCRIPT).read_bytes():
        raise RuntimeError('Extractor script data file is missing or differs from the source tree')
    packaged = [item for item in inventory if item.endswith('/' + LAUNCHER_SCRIPT)]
    if len(packaged) != 1 or (package / packaged[0]).read_bytes() != (root / 'src' / LAUNCHER_SCRIPT).read_bytes():
        raise RuntimeError('Ghidriff launcher data file is missing or differs from the source tree')
    (package / 'file-inventory.json').write_text(json.dumps(inventory, indent=2), encoding='utf-8')
    subprocess.run([str(package / 'PatchTrace.exe'), '--self-test'], timeout=60, check=True)
    # Read the built file back with PatchTrace's own PE reader: the release must name the commit it came from.
    issues = check_windows_exe.problems(check_windows_exe.read_resources(package / 'PatchTrace.exe'),
                                        fields.label, fields.commit)
    if issues:
        raise RuntimeError('; '.join(issues))
    # Frozen headless smoke: help must reach stdout and exit 0 without Qt.
    cli = subprocess.run([str(package / 'PatchTrace.exe'), 'rank', '--help'], timeout=60,
                         capture_output=True, text=True)
    if cli.returncode != 0 or 'usage:' not in cli.stdout:
        raise RuntimeError(f'Frozen CLI smoke failed ({cli.returncode}): {cli.stderr[-500:]}')
    archive = Path(shutil.make_archive(str(root / 'dist' / f'PatchTrace-{args.version}-windows-x64'),
                                     'zip', root_dir=root / 'dist', base_dir='PatchTrace'))
    archive.with_suffix('.zip.sha256').write_bytes(f'{sha256_file(archive)}  {archive.name}\n'.encode('ascii'))
    print(archive)
    if args.full:  # the lite smoke above is unchanged; backend/ is attached after it
        attach_backend(package, args.backend_payload, version=args.version, platform_key='windows', root=root,
                       allow_internal_symlinks=False, release=args.release)
        full = Path(shutil.make_archive(str(root / 'dist' / full_archive_name(args.version, 'windows')[:-4]),
                                        'zip', root_dir=root / 'dist', base_dir='PatchTrace'))
        check_archive_size(full)
        full.with_suffix('.zip.sha256').write_bytes(f'{sha256_file(full)}  {full.name}\n'.encode('ascii'))
        print(full)

if __name__ == '__main__':
    main()
