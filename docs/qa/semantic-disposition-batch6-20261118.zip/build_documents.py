"""Build a source-pinned, honest selected-scope disposition checkpoint."""
from collections import Counter
from datetime import UTC, datetime
from functools import lru_cache
from pathlib import Path
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET

R = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
Q = Path(__file__).parent
B = '55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
PRIOR = '82d4ea017cd936b793dd8adfd50343a05df5629a'
P = R / 'docs/plans/autonomous-consolidation-20261118'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=R)

@lru_cache(None)
def blob(ref, path):
    return git('show', ref + ':' + path)

def load(name):
    return json.loads((Q / name).read_text())

def append_to_frozen(path, text):
    """Idempotent owned-doc addition on the frozen source branch."""
    path.write_text(blob(B, str(path.relative_to(R))).decode() + text)

snapshot = load('snapshot.json')
decisions = {r['branch']: r for r in load('dispositions.json')['branches']}
proofs = {r['branch']: r['proofs'] for r in load('replacement-provenance.json')['branches']}
symbols = {r['branch']: r['symbols'] for r in load('symbol-comparison.json')['branches']}
prior = json.loads(blob(PRIOR, 'docs/plans/autonomous-consolidation-20261118/semantic-disposition-batch5.json'))
assert git('rev-parse', 'HEAD').decode().strip() == B
assert not git('diff', '--', 'src', 'tests', 'tools', '.github')

branches = []
for raw in snapshot['branches']:
    name = raw['branch']
    row = {**raw, **decisions[name], 'replacement_proofs': proofs[name], 'symbols': symbols[name]}
    for field in ('current_paths', 'current_specs', 'current_tests'):
        assert all((R / p).is_file() for p in row[field]), (name, field)
    row['net_production_delta_paths'] = [p for p in row['changed_paths'] if p.startswith(('src/', 'tools/'))]
    row['missing_current_production_paths'] = [p['path'] for p in row['source_projection']
                                             if p['state'] == 'missing_current' and p['path'].startswith(('src/', 'tools/'))]
    row['whole_branch_closed'] = False
    branches.append(row)
selected = {r['branch'] for r in branches}
remaining = [r for r in prior['still_unselected_original_tips'] if r['branch'] not in selected]
assert len(branches) == 20 and len(remaining) == 11
assert len({r['tip'] for r in branches}) == 20
assert all(r['tip_matches_inventory'] for r in branches)

def execution(label):
    xml = ET.parse(Q / (label + '.xml')).getroot()
    cases = list(xml.iter('testcase'))
    failed = sum(c.find('failure') is not None for c in cases)
    errors = sum(c.find('error') is not None for c in cases)
    skipped = sum(c.find('skipped') is not None for c in cases)
    text = (Q / (label + '.log')).read_text()
    seconds = re.findall(r'in (\d+\.\d+)s', text)
    return {'source': B, 'passed': len(cases) - failed - errors - skipped,
            'failed': failed, 'errors': errors, 'skipped': skipped,
            'summary_seconds': float(seconds[-1]) if seconds else None,
            'junit_seconds': sum(float(n.get('time', 0)) for n in xml.iter('testsuite')),
            'command': 'current-command.json' if label == 'current-affected' else label + '.command.json',
            'log': label + '.log', 'xml': label + '.xml'}

runs = {label: execution(label) for label in ('current-affected', 'historical-java', 'historical-unified-initial', 'historical-unified-collection')}
runs['current-affected'].update(files=29, explicit_deselections=load('current-command.json')['explicit_deselections'])
history = []
for label in ('historical-java', 'historical-unified-initial', 'historical-unified-collection'):
    for c in ET.parse(Q / (label + '.xml')).getroot().iter('testcase'):
        failure, error = c.find('failure'), c.find('error')
        state = 'failure' if failure is not None else 'error' if error is not None else 'passed'
        if state == 'failure':
            kind = 'historical_fixture_lineage_defect'
            meaning = 'The historical helper creates one lineage. Actual evaluator requires30 and correctly returns insufficient-data. Current canonical fixture supplies30 independent scripted project lineages; no threshold was relaxed.'
        elif state == 'error':
            kind = 'historical_fixture_argument_binding'
            meaning = 'Original positional Hypothesis arguments leave timestamp as an unresolved pytest fixture; the current named timestamp/padding strategies resolve collection. No production parser assertion ran in this node.'
        else:
            kind = 'retained_control'
            meaning = 'Original unchanged authored control passes against the exact current implementation and helper bytes.'
        history.append({'invocation': label, 'node': c.get('classname') + '::' + c.get('name'),
                        'outcome': state, 'classification': kind, 'meaning': meaning,
                        'message': (failure if failure is not None else error).get('message') if state != 'passed' else None})
assert len(history) == 22
(Q / 'historical-result-disposition.json').write_text(json.dumps({'source': B, 'nodes': history}, indent=2) + '\n')

prior_refs = []
for batch, commit, archive_sha in [(4, '4f71b811dbd1555ce5cb6cffe062dddc3bb801e5', '7b7951f095362015f3df825500dcbf31c23c12d1299181bc0faeaf62d02e60d3'),
                                    (5, PRIOR, 'e6b63e2b7f39b85bb18790761fe8ff8ce11f65fdc82626590bf2c67cc1f02b16')]:
    folder = Q.parent / f'semantic-disposition-batch{batch}'
    original = json.loads((folder / 'ledger.json').read_text())
    assert original['comparison_source'] == B
    prior_refs.append({'batch': batch, 'checkpoint': commit, 'archive_sha256': archive_sha,
                       'comparison_source': B, 'current_gate': original['executions']['current-affected'],
                       'command_sha256': hashlib.sha256((folder / 'current-command.json').read_bytes()).hexdigest(),
                       'meaning': 'Prior same-source observation reused only for named inherited scopes; not newly run or additive.'})
(Q / 'prior-evidence-references.json').write_text(json.dumps(prior_refs, indent=2) + '\n')

current_paths = {'AGENTS.md', 'docs/modules.md'}
for row in branches:
    current_paths.update(row['current_paths'] + row['current_specs'] + row['current_tests'])
    current_paths.update(p['path'] for p in row['replacement_proofs'])
current_paths.update(load('current-command.json')['test_files'])
current_paths.update(row['path'] for row in load('historical-control-source.json')['helper_comparison'])
current_paths.update(p['path'] for row in branches for p in row['source_projection']
                     if p['base_blob'] is not None and p['path'].startswith(('src/', 'tools/')))
current_manifest = []
for path in sorted(current_paths):
    raw = blob(B, path)
    target = Q / 'current-source' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    current_manifest.append({'path': path, 'source': B, 'blob': git('rev-parse', B + ':' + path).decode().strip(),
                             'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
(Q / 'current-source-manifest.json').write_text(json.dumps(current_manifest, indent=2) + '\n')
historical_manifest = []
for row in branches:
    paths = {p['path'] for p in row['source_projection'] if p['tip_blob'] is not None}
    for path in sorted(paths):
        raw = blob(row['tip'], path)
        rel = 'historical-source/' + row['branch'].replace('/', '__') + '/' + path
        target = Q / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(raw)
        historical_manifest.append({'branch': row['branch'], 'tip': row['tip'], 'path': path, 'retained': rel,
                                    'blob': git('rev-parse', row['tip'] + ':' + path).decode().strip(),
                                    'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
(Q / 'historical-source-manifest.json').write_text(json.dumps(historical_manifest, indent=2) + '\n')

ledger = {
    'schema': 'patchtrace-semantic-disposition/1', 'batch': 6, 'prepared_at_utc': datetime.now(UTC).isoformat(),
    'comparison_source': B, 'comparison_tree': snapshot['comparison_tree'],
    'comparison_identity': 'Actual PR316 source frozen at assignment. Later published 14efc/source ae0b and accepted repairs are separately attributed, never relabeled as 55f3.',
    'inventory_observed_at': snapshot['inventory_observed_at'], 'inventory_source_sha256': snapshot['inventory_source_sha256'],
    'remote_refresh': snapshot['remote_refresh'],
    'previous_batches': prior['previous_batches'] + [{'batch': 5, 'checkpoint': PRIOR, 'selected': 20, 'comparison': B,
                                                     'caller_erratum': '62338862b751eb863005ca557265e60d2a422a6f'}],
    'selection_denominator': {'original_needs_reconciliation_tips': 131, 'previously_selected': 100,
                             'selected_this_batch': 20, 'source_bearing_this_batch': 14,
                             'fixture_or_test_only_this_batch': 6, 'cumulatively_selected': 120,
                             'still_unselected': 11,
                             'meaning': 'Selected inspected scopes only. No whole-branch closure, product percentage or additive test completion score.'},
    'classification_counts': dict(Counter(r['classification'] for r in branches)),
    'new_confirmed_product_defects': [],
    'decision_criteria': ['Inspect exact patch, current code, actual caller, contract and meaningful controls.',
                          'Use byte/AST/patch/parent evidence to locate retained scopes, not branch names.',
                          'Retain every executed historical failure/error; distinguish fixture defects from product behavior.',
                          'Keep inherited 79/85-path and research/native/platform residue open.'],
    'executions': runs, 'prior_same_source_evidence': prior_refs,
    'historical_result_disposition': 'historical-result-disposition.json',
    'overlap': load('overlap.json'), 'source_manifest_count': len(current_manifest),
    'historical_source_manifest_count': len(historical_manifest),
    'branches': branches, 'still_unselected_original_tips': remaining,
}
(Q / 'ledger.json').write_text(json.dumps(ledger, indent=2) + '\n')
P.mkdir(parents=True, exist_ok=True)
(P / 'semantic-disposition-batch6.json').write_text(json.dumps(ledger, indent=2) + '\n')

lines = ['# Semantic branch disposition, batch six', '',
         f'Frozen comparison: **`{B}`**, tree `{snapshot["comparison_tree"]}`. Later root continuation and published PR316 changes remain separately attributed.', '',
         'This batch inspects all fourteen remaining tips with net production-source deltas and six related fixture/test tips. No new product defect was confirmed. Retained composition, exact aliases, stronger current guards, historical fixture corrections and broad inherited residue are recorded separately.', '',
         '**120 of 131 original reconciliation tips now have selected-scope entries; 11 remain unselected.** This count is not a product percentage or whole-branch disposition. No source, test, workflow, remote ref or branch was merged or deleted.', '',
         '[Machine-readable ledger](semantic-disposition-batch6.json) · [Exact-source QA and archive](../../qa/semantic-disposition-batch6-20261118.md).', '',
         '| Branch | Exact tip | Selected scope |', '|---|---|---|']
for row in branches:
    lines.append(f'| `{row["branch"]}` | `{row["tip"]}` | {row["focus"]} |')
lines += ['', '## Qualification and historical controls', '',
          'The fresh current gate passed **173 cases across 29 files in 7.14 seconds**, with two explicit compiler-backed deselections and zero skipped/failed/error cases. It covers bounded Java probing, KB fixture imports, synthetic unified fixtures, authored GT-01 harness behavior, source-root measurement and workflow parsing. The helper Python process and ZIP-permission snippet are authored controls; compared images and native engines were not executed.', '',
          'The exact old Java controls pass six cases. Initial unified originals retain one assertion failure, six positives and one setup error; the collection-fix originals retain seven positives and one setup error. The failed gate had one lineage rather than the required thirty. Both PE variants bind timestamp as a nonexistent pytest fixture; current named strategies fix this. All 22 original nodes are individually classified. The five helper files for each historical fixture tip are byte-identical to current source.', '',
          'Sealed batch4/batch5 exact55 receipts are referenced for inherited replay/protocol, branding, offline-runtime and build/session scopes. They are prior observations, not reruns or additive totals. Rule-specific controls requiring YARA-X were inspected but not run. The two native compiler cases, actual Windows packages, live source acquisition, native engine scoring, hosted workflows and manual acceptance remain open.', '',
          'The batch-five COFF caller correction is carried forward: the probe exercises an exported optional developer API directly. The factory calls apply_case without extra_check; no normal factory/CLI wiring is claimed.', '', '## Per-tip dispositions', '']
for index, row in enumerate(branches, 1):
    lines += [f'### {index}. `{row["branch"]}`', '',
              f'**{row["classification"].replace("_", " ")}.**', '',
              '**Historical delta:** ' + row['historical_behavior'], '',
              '**Current behavior:** ' + row['current_behavior'], '',
              '**Actual caller evidence:** ' + row['caller_evidence'], '',
              'Current source: ' + ', '.join('`' + p + '`' for p in row['current_paths']) + '.', '',
              'Contract: ' + ', '.join('`' + p + '`' for p in row['current_specs']) + '.', '',
              'Control map: ' + ', '.join('`' + p + '`' for p in row['current_tests']) + '.', '',
              'Qualification: ' + '; '.join(row['verification']) + '.', '',
              '**Selective decision:** ' + row['recommendation'], '',
              '**Residual scope:** ' + row['residue'], '']
lines += ['## Remaining original tips', '', '| Branch | Exact frozen tip |', '|---|---|']
for row in remaining:
    lines.append(f'| `{row["branch"]}` | `{row["tip"]}` |')
lines += ['', '## Evidence boundary', '',
          'The JSON retains merge bases, ahead/behind, git-cherry patch equivalence, all changed paths, current/historical file blobs, AST comparisons, full parent-aware replacement history and exact scoped overlap. Archived original source/test bytes are hashed. These are proofs for the stated focus; broad checkpoint residue and source-free handoff obligations remain explicit. No blanket branch closure, release claim, native qualification or remote action is authorized by this ledger.', '']
md = '\n'.join(lines)
(Q / 'ledger.md').write_text(md)
(P / 'semantic-disposition-batch6.md').write_text(md)
summary = '''
## Semantic branch disposition batch6 — frozen actual 55f3 comparison

Twenty additional original tips have bounded focal dispositions: fourteen with
net production-source deltas and six fixture/test-only tips. Cumulative selection
is 120/131; eleven remain unselected. No new product defect was confirmed. This is
not whole-branch closure or a product completion percentage. The fresh 29-file gate
passed 173 cases with two explicit compiler deselections. Original Java 6 pass and
unified fixture 1 fail/6 pass/1 error then 7 pass/1 error are retained and explained;
current canonical controls pass without relaxing lineage or parser requirements.
Prior exact 55f3 receipts for inherited scopes are referenced, never counted twice.
Broad 79/85-path consolidation/research/native/platform residue remains open.
See [batch6](autonomous-consolidation-20261118/semantic-disposition-batch6.md).
'''
append_to_frozen(R / 'docs/plans/patchtrace-completion-matrix.md', summary)
append_to_frozen(P / 'consolidation-ledger.md', summary.replace('(autonomous-consolidation-20261118/semantic-disposition-batch6.md)', '(semantic-disposition-batch6.md)'))
append_to_frozen(R / 'tasks/todo.md', '\n### Semantic disposition batch6 (2026-11-18)\n\n- [x] Inspect 20 distinct original tips against frozen 55f3, preserving exact source/ancestry/caller and fixture evidence.\n- [x] Preserve 22 original historical outcomes and the 173-pass bounded current gate with two compiler deselections.\n- [ ] Complete the remaining 11 original focal dispositions; keep broad research/native/platform obligations open.\n- [ ] Root independent review and selective docs integration; no whole-branch closure or remote changes.\n')
append_to_frozen(R / 'docs/qa.md', '\n### Semantic disposition batch6 (2026-11-18, frozen 55f3 source)\n\nTwenty focal records; fresh 173 passed/2 compiler deselections across 29 files. Exact historical Java 6 pass; unified originals 1 fail/6 pass/1 setup error and 7 pass/1 setup error, all classified as retained controls or fixture defects. Prior same-source observations are referenced separately. See [receipt](qa/semantic-disposition-batch6-20261118.md). No native/compiler/target/network/Windows/manual gate.\n')
(Q / 'document-validation.json').write_text(json.dumps({'baseline': B, 'selected': 20, 'remaining': 11,
                                                       'source_snapshots': len(current_manifest),
                                                       'historical_snapshots': len(historical_manifest),
                                                       'proofs': sum(len(x) for x in proofs.values()),
                                                       'historical_nodes': len(history),
                                                       'current_paths_valid': True,
                                                       'product_delta': False}, indent=2) + '\n')
print((Q / 'document-validation.json').read_text())
