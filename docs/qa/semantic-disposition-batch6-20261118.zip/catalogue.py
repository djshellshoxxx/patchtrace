"""Read-only candidate routing for the remaining31 frozen tips, prior to semantic selection."""
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC,datetime
from pathlib import Path
import hashlib,json,subprocess
ROOT=Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
OUT=Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch6')
BASE='55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
PRIOR='82d4ea017cd936b793dd8adfd50343a05df5629a'
def git(*args):return subprocess.check_output(['git',*args],cwd=ROOT,text=True)
prior=git('show',PRIOR+':docs/plans/autonomous-consolidation-20261118/semantic-disposition-batch5.json')
remaining=json.loads(prior)['still_unselected_original_tips']
assert len(remaining)==31
base_paths=set(git('ls-tree','-r','--name-only',BASE,'--','src','tools').splitlines())
def capture(row):
 name,tip=row['branch'],row['tip']
 fetched=git('rev-parse','refs/remotes/origin/'+name).strip()
 assert fetched==tip,(name,tip,fetched)
 mb=git('merge-base',BASE,tip).strip()
 paths=git('diff','--name-only',mb,tip,'--','src','tools').splitlines()
 logs=git('log','--no-merges','--format=%H %s',BASE+'..'+tip,'--','src','tools').splitlines()
 return {'branch':name,'tip':tip,'merge_base':mb,'changed_source_paths':paths,
         'missing_current_paths':[p for p in paths if p not in base_paths],
         'unique_source_commits':logs}
with ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(capture,remaining))
result={'baseline':BASE,'prior_checkpoint':PRIOR,'prior_json_sha256':hashlib.sha256(prior.encode()).hexdigest(),
        'observed_at':datetime.now(UTC).isoformat(),'purpose':'Routing only; no semantic classification inferred.',
        'branches':rows}
(OUT/'catalogue.json').write_text(json.dumps(result,indent=2)+'\n')
for row in rows:
 print(row['branch'],len(row['changed_source_paths']),len(row['unique_source_commits']),row['tip'])
 print('  paths:',', '.join(row['changed_source_paths'][:12]))
 print('  missing:',', '.join(row['missing_current_paths'][:10]))
 for line in row['unique_source_commits'][:3]:print('  '+line)
