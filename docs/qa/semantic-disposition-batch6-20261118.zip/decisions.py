"""Authored semantic findings from actual patches, callers, contracts and controls."""
from pathlib import Path
import json

Q = Path(__file__).parent
D = {}

def add(name, classification, focus, historical, current, caller, paths, specs, tests, verification, recommendation, residue):
    D[name] = dict(classification=classification, focus=focus, historical_behavior=historical,
                   current_behavior=current, caller_evidence=caller, current_paths=paths,
                   current_specs=specs, current_tests=tests, verification=verification,
                   recommendation=recommendation, residue=residue)

backend_contract = ['docs/specs/ghidriff-timeout-progress.md']
live_contract = ['docs/specs/unified-engine/08-evaluation.md', 'docs/specs/known-answer-corpus.md']
live_tests = ['tests/test_unified_live_pairs_r1.py', 'tests/test_unified_live_force_identical.py',
              'tests/test_unified_live_native_failure_details.py']

for name, historical in [
    ('chatgpt/java-probe-boundaries-20261016', 'Adds six authored Java-version retry/cancellation/missing-runtime controls on the prior bounded implementation.'),
    ('chatgpt/java-probe-ci-fix-20261016', 'Only reorders threading and SimpleNamespace imports in the existing retry regression; it contains no production delta.'),
]:
    add(name, 'retained_test_scope', 'Bounded Java runtime-version probing', historical,
        'The actual backend tries 15 then 30 seconds only after the first timeout with no cancellation; other failures, missing Java and unparsable versions yield unknown. Current tests preserve the six behaviors with a closure-fixture correction.',
        '_open_raw_cache calls _java_version, stores unverified for unknown and constructs its runtime fingerprint from the result. The tests replace run_process; no Java process was run.',
        ['src/patchtrace/backend.py', 'tests/test_backend_java_version.py'], backend_contract,
        ['tests/test_backend_java_version.py'],
        ['current-affected', 'historical-java: exact 09bb original, 6 passed', 'source projection and current caller proof'],
        'No production or test port needed for this scope.',
        'The source-free branch does not establish live JVM startup performance, Windows runtime discovery or native engine acceptance.')

add('chatgpt/kb-fixtures-1', 'retained_with_fixture_corrections', 'Offline synthetic KB corpus and fixture boundaries',
    'Adds 13 fixture/document files, crash injection helper, performance plan and nine test files; no src/tools delta. Some tests request an unregistered no_sockets fixture, a nonexistent scenario or a confusable value the raw fixture does not contain.',
    'All underlying synthetic corpus blobs and the crash helper are retained. Current fixtures explicitly register no_sockets, construct the unknown type99 case, exercise BOM refusal and CRLF import, admit the deliberately empty fictional CSAF inventory, and use a real confusable-KB fixture. The old synthetic bytes are preserved.',
    'Current fixture tests call actual import_bytes/parse_cvrf with sockets refused. The crash helper tests its own named checkpoints; it does not attach injection hooks to a missing production sidecar.',
    ['src/patchtrace/kbcorrelation/sources/importer.py', 'src/patchtrace/kbcorrelation/sources/cvrf.py',
     'tests/kb_crash_harness.py', 'tests/fixtures/kb/CONTRACT_CONFLICTS.md'],
    ['docs/specs/kb-cve/31-A-contracts-identity.md'],
    ['tests/test_kb_cvrf_fixture_import.py', 'tests/test_kb_fixture_encoding.py', 'tests/test_kb_fixture_properties.py',
     'tests/test_kb_offline_fixture_import.py', 'tests/test_kb_raw_adversarial_inputs.py',
     'tests/test_kb_synthetic_fixture_corpus.py', 'tests/test_kb_crash_injection_protocol.py',
     'tests/test_kb_metadata_fixture_boundaries.py', 'tests/test_kb_update_relationships.py'],
    ['current-affected', 'all branch fixture/source projection and historical-to-current test diff inspected'],
    'Keep the corrected current fixture registrations and actual boundary checks. No old fixture regression should be ported.',
    'Fictional rows do not establish vendor accuracy, acquisition, complete crash recovery or real update-package applicability. The historical performance plan remains a plan.')

for name, historical, verification in [
    ('chatgpt/unified-fixtures-1', 'Adds authored PE/assembler, pair, nuisance, statistics and G-U1..G-U7 fixtures. Corrected G-U6 and PE variants were left under ignored -2 filenames while canonical tests remained defective.',
     ['historical-unified-initial: 1 failed, 6 passed, 1 setup error', 'g_u6-observations.json: one lineage is insufficient']),
    ('chatgpt/unified-fixture-collection-fix-20261016', 'Moves the corrected thirty-lineage G-U6 and explicit Hypothesis fixture-health policy into canonical test names and deletes the duplicate -2 files. Positional Hypothesis arguments still leave timestamp interpreted as a pytest fixture.',
     ['historical-unified-collection: 7 passed, 1 setup error', 'g_u6-observations.json: thirty scripted lineages pass']),
]:
    add(name, 'retained_with_fixture_corrections', 'Collected synthetic unified-engine fixtures', historical,
        'Current canonical G-U6 uses thirty distinct project/lineage labels and preserves the 20% reduction and thirty-lineage requirements. Current PE property test also uses named timestamp/padding strategies, resolving the still-broken positional argument binding. Required helper bytes for these original replays are identical at historical and current sources.',
        'The fixture gate calls actual rowgates.g_u6 on authored OutcomeRows; the PE test reads generated bytes through VerifiedArtifactReader/read_pe_tables and never executes them. A passing scripted gate is not observed engine accuracy.',
        ['tools/unified/rowgates.py', 'tests/test_unified_fixture_gate_u6.py', 'tests/test_unified_synthetic_pe.py',
         'tests/unified_support/gate_inputs.py', 'tests/unified_support/synthetic_pe.py'], live_contract,
        ['tests/test_unified_fixture_gate_u6.py', 'tests/test_unified_synthetic_pe.py',
         'tests/test_unified_fixture_fusion_properties.py', 'tests/test_unified_fixture_statistics.py',
         'tests/test_unified_fixture_timing.py', 'tests/test_unified_synthetic_pairs.py'],
        ['current-affected', *verification, 'historical-control-source.json and exact helper equivalence'],
        'No fixture port needed. Keep the named-strategy correction and canonical tests; retain original failures as fixture defects.',
        'No actual engine, compiler, corpus power estimate or native speed result. The old duplicate filenames are not missing product features.')

for name, historical in [
    ('chatgpt/lbl31-windows-qa-fixes-20261016-a', 'Adds quoted COFF masking and a duplicated default-sort fast path, and inherits output retention plus training-artifact transfer. Its handoff records real historical Windows failures but no new current execution.'),
    ('chatgpt/unified-sort-perf-qa-20261016', 'The leaf changes only the sort timing test to best-of-three at the same 0.20-second threshold. Despite its name, its merge-base-to-tip source delta contains no read_model.py change; the six source paths are inherited mutation/output/shard/transfer work.'),
]:
    add(name, 'retained_foundation_partial_research', 'Quoted COFF and default-sort QA with inherited replay work', historical,
        'Current quoted operands and function boundaries are retained. Current sort implementation differs from the duplicated historical fast path, but the exact old order and 100k-row threshold controls passed in sealed batch5 at this same55 baseline. Current output store has stronger verified-credit/bounded replay. training_artifacts.py and shard train-job transfer remain absent.',
        'ui_unified invokes read_model.sort_rows for displayed row indices; tools/unified/bench.py also benchmarks it. make_masked_body_check is an exported optional developer API exercised directly in batch5; the actual factory calls apply_case without extra_check, and no non-test caller of the optional check was found. evaluate retains normalized outputs; train.load_outputs validates managed credit.',
        ['src/patchtrace/unified/read_model.py', 'tools/calibration/mutations/engine.py',
         'tools/calibration/tier_r/output_store.py', 'tools/calibration/train.py', 'tools/calibration/tier_r/shard.py'],
        live_contract + ['docs/specs/unified-engine/07-ui-and-cli.md'],
        ['tests/test_unified_read_model.py', 'tests/test_tier_r_output_persistence.py', 'tests/test_tier_r_credited_replay.py'],
        ['prior exact55 batch5 current-affected and historical-sort; not rerun/additive here',
         'prior optional-API COFF proof with attributed caller erratum62338862', 'actual tip patch and source projection'],
        'Do not port the duplicate sort block. The known unquoted optional-API defect has separate approved repair ownership. Transfer remains a separately designed developer workflow.',
        'Historical Windows test reports and current synthetic timing are not Windows native qualification. No claim that the optional COFF check is installed in normal factory/CLI acceptance.')

add('claude/access-test-1791773355', 'exact_alias_of_inspected_tip', 'Offline runtime importer and private JDK alias',
    'Exact same commit and complete src/tools/tests/workflow tree as access-test-noprefix already inspected in batch5; access marker add/remove commits do not leave a product artifact.',
    'The verified offline bundle validator/importer, bounded runtime discovery, JAVA_HOME_OVERRIDE environment and desktop import hook are retained with later safety improvements.',
    'Desktop import_offline_bundle and runtime_cli call the real importer; backend environment uses the selected private JDK. Exact tip identity is proven, not inferred from the access-test name.',
    ['src/patchtrace/offline_bundle.py', 'src/patchtrace/runtime_discovery.py', 'src/patchtrace/backend.py',
     'src/patchtrace/runtime_cli.py', 'src/patchtrace/ui.py'],
    ['docs/specs/offline-backend-installer.md'],
    ['tests/test_runtime_discovery_bundle.py', 'tests/test_runtime_discovery.py'],
    ['overlap.json exact tip726a371a identity', 'prior exact55 batch4/batch5 offline controls; no duplicate test credit'],
    'No additional selective port for this alias.',
    'The directory-publication reservation defect found in batch3 and later root repair remain separately attributed. This alias does not qualify a native installed bundle or approve licenses.')

for name, history, current in [
    ('claude/awesome-ramanujan-o3pxx3-win1', 'Introduces the Windows version resource/icon generators, app icon, PyInstaller data hook and bounded PE checker.',
     'Three of eight changed source files are exact; the rest are retained through stricter full commit IDs, exact version/PNG checks, complete resources, exclusive adjacent staging and the current console/subprocess policy.'),
    ('claude/ws-a-20261104', 'Integrates strict Windows identity/resource checks and exclusive staging, plus the packaged desktop mark for both builders. It explicitly removes a frozen .gitattributes hunk into historical evidence.',
     'All nine changed production source paths are byte-identical to frozen55, including the Linux and Windows builder hooks. The retained original mark and PyInstaller hook are exact.'),
]:
    add(name, 'retained_focal_scope', 'Packaged desktop and executable identity', history, current,
        'build_windows.main writes the version resource and icon used by its PyInstaller command; check_windows_exe.main reads the produced PE without executing it. __main__ installs the application icon. This is source wiring plus synthetic resource evidence.',
        ['tools/build_windows.py', 'tools/build_linux.py', 'tools/check_windows_exe.py',
         'tools/windows_version_info.py', 'tools/windows_icon.py', 'src/patchtrace/__main__.py', 'src/patchtrace/app_icon.py'],
        ['docs/specs/windows-acceptance-and-milestone-builds.md'], ['tests/test_windows_build_resources.py'],
        ['source/AST projection; exact nine-file ws-a comparison in overlap.json',
         'prior exact55 batch5 Windows resource gate; no fresh Windows execution'],
        'No source port needed. Keep stricter current resource checks and exclusive staging.',
        'No installer, Explorer icon, signed publisher, native PE build or Windows GUI/manual acceptance here. Historical reports are not new gates.')

for name, history in [
    ('claude/live-harness-infra-20261111', 'Integrates GT-01 raw-result persistence before unified extraction, isolated extraction work, failed-output diagnostics and opt-in native identical-image controls. Workflow hunks restore archived executable bits and add EGL dependencies.'),
    ('codex/essential-combined-verification-20261030', 'Combines the same GT-01 lineage with reviewed synthetic KB fixture reconciliation and a docs-only combined-verification leaf. It is not a new native run in this inventory.'),
]:
    add(name, 'retained_focal_scope', 'Honest native-harness completion and failure semantics', history,
        'Current live_pairs commits completed backend evidence before unified extraction, uses isolated extraction work, refuses an identical shortcut as native execution, forces no-cache A/A only in the harness and preserves bounded/redacted failures. Backend validates the opt-in flag and retains distinct input names. Linux workflow restores ZIP executable bits and includes libegl1.',
        'live_pairs.main passes selected labels to analyse_pair; analyse_pair configures run_comparison, checks completion, applies analysis then extracts. The controlled backend test executes only an authored Python stand-in, not Ghidra or target bytes. The ZIP test executes only the fixed Python permission-restoration snippet on synthetic files.',
        ['tools/unified/live_pairs.py', 'src/patchtrace/backend.py', '.github/workflows/unified-live-gates.yml'],
        live_contract, live_tests,
        ['current-affected', 'prior exact55 batch4 GT-01 source lineage', 'actual patches and caller/config guards'],
        'No selective GT-01 port needed for these paths.',
        'Real Ghidriff extraction, pinned runtime installation, live gates, native engine accuracy, hosted workflow execution and platform behavior remain unqualified here. Broader KB consolidation scope stays separately recorded.')

add('claude/live-proof-20261111', 'retained_focal_scope', 'Recorded source roots and honest live-gate measurement',
    'Adds native root-spelling normalization, retained passed/resolved build roots, exported planted candidates, asymmetric empty-inventory refusal and G-U2 unpaired outcome accounting, on top of GT-01.',
    'Five of eight source paths are exact. Current build retains the same source_dirs behavior with stronger receipt publication; labeler additionally refuses both-empty inventories and does not promote ambiguous unchanged controls. Backend differences are later retained guards.',
    '_build_in records source_dirs in BuildResult; factory.Session.side includes source_dirs in its key and labeler.analyze passes them to debuginfo.inventory. Mutation templates place EXPORT in base and mutated functions; evaluator reports unpaired verdicts without counting hits/leakage. These actual callers were inspected.',
    ['tools/calibration/tier_r/build.py', 'tools/calibration/tier_r/factory.py',
     'tools/calibration/tier_r/debuginfo.py', 'tools/calibration/tier_r/labeler.py',
     'tools/unified/mutations/templates.py', 'tools/unified/evaluators.py', 'tools/unified/gates_u.py'],
    live_contract, ['tests/test_unified_rb01_harness.py', 'tests/test_unified_gate_eval.py'],
    ['current-affected with two explicit compiler deselections', 'overlap.json exact five-file comparison', 'current source and caller proof'],
    'No source port needed. Preserve the stronger empty-inventory and provenance guards.',
    'Authored path strings, DWARF text and template exports do not qualify actual PDB/DWARF compiler output, disassembly discovery or real native recall. No compiler was invoked.')

broad = ('Broad inherited snapshot remains partial: saved-scope and R2 witness/report omissions at frozen55, '
         'missing research/transfer/benchmark helpers, historical creation/retry/UI variants and native rz-diff '
         'orientation evidence. Previously reported directory/highlighter/F8/named-source/UI repairs and later '
         'COFF/A-A/saved-scope work must be attributed to their own source, never retroactively to55. '
         'This focal disposition does not close the 79/85-path checkpoint or all missing symbols.')

for name, history in [
    ('codex/consolidated-reviewed-20261102', 'Five-parent merge retains actual integration, replay/schema, preregistration and main ancestry. Its 79-path source delta is a broad inherited checkpoint rather than one independent feature.'),
    ('codex/consolidation-evidence-20261102', 'Docs/evidence leaf over6e82; every src/tools/workflow byte is identical to that reviewed checkpoint. It records historical failures, reconciliation, pending native/package work and research proposals.'),
]:
    add(name, 'retained_composition_with_open_residue', 'Checkpoint replay/protocol composition and preserved ancestry', history,
        'The replay/schema and preregistration slices are retained together: current managed replay verifies report credit and metadata, and training CLI validates complete visible protocol identity before inputs. Twenty-six changed source files are exact to this tip; the rest are explicitly not wholesale-equivalent.',
        'train._run calls PG.select before _inputs, while train.load_outputs uses read_credited_outputs. These are production CLI/data-path calls. The checkpoint title and historical pass counts are not evidence that unrelated GUI, matching, creation or research deltas were integrated.',
        ['tools/calibration/train.py', 'tools/calibration/prereg_gate.py', 'tools/calibration/tier_r/output_store.py',
         'tools/calibration/tier_r/report_schemas.py'],
        live_contract + ['docs/specs/calibration-corpus-and-model.md'],
        ['tests/test_train_prereg_selection.py', 'tests/test_tier_r_credited_replay.py', 'tests/test_tier_r_credit_completion.py'],
        ['prior exact55 batch5 replay/protocol gate', 'overlap.json actual merge parents and evidence-leaf source equality',
         'complete changed-path/AST residue inventory'],
        'Retain the scoped replay/protocol composition and evidence, with no wholesale merge or closure recommendation.', broad)

for name, history in [
    ('codex/consolidation-integrity-20261103', 'Four-parent merge adds six production paths over44c320e3: rule export-name preflight, content-identity rescoring, nonregular input refusal, malformed sidecar handling, complete build receipts, source/build-bound session cache and ambiguous control handling.'),
    ('codex/rzdiff-164-investigation', 'Only new leaf content is the bounded PR164 orientation handoff; src/tools/workflow bytes are identical to b58bb53d. It documents conditional singleton inversion, an old ambiguous replay and missing source/runtime access, explicitly without a new implementation or native acceptance.'),
]:
    add(name, 'retained_integrity_with_open_residue', 'Rule/build integrity and explicit native quarantine obligations', history,
        'Current code retains the six-path integrity slice, strengthens bounded receipt reuse and atomic compatibility publication, adds source_dirs to the session key, caps hashed files, preserves equal-second decision ordering and uses strict JSON for sidecars. Production rz-diff singleton orientation quarantine remains. The historical research observation helper is absent; it cannot authorize unquarantine.',
        'rules.cli._test uses matrix.rescored on cache reuse, RuleStore.tests invokes _inline through _read, and rule export.write validates the basename before file publication. _build_in calls persist_build_record; factory.Session.side keys actual analyses by build and source context. No native YARA-X or rz-diff run was selected for this batch.',
        ['src/patchtrace/rules/export.py', 'src/patchtrace/rules/matrix.py', 'src/patchtrace/rules/store.py',
         'src/patchtrace/rules/cli.py', 'src/patchtrace/secondary/rzdiff.py', 'tools/calibration/tier_r/build.py',
         'tools/calibration/tier_r/factory.py', 'tools/calibration/tier_r/labeler.py'],
        live_contract + ['docs/specs/yara-x-rule-workflow.md'],
        ['tests/test_tier_r_build_receipts_r1.py', 'tests/test_tier_r_session_provenance_r1.py',
         'tests/test_tier_r_label_promotion_r1.py', 'tests/test_rules_matrix.py', 'tests/test_rules_store.py', 'tests/test_rules_export.py'],
        ['prior exact55 batch4/batch5 authored build/provenance controls',
         'six-path integrity patch and current stronger replacements inspected; rule-specific native controls not rerun',
         'overlap.json and original-rzdiff-164-investigation.md'],
        'No port of the older weaker integrity implementations. Keep native quarantine; any producer/witness work requires its separate accepted design and platform gates.', broad)

add('codex/corpus-output-main-20261101', 'retained_composed_scope', 'Merged normalized-output and replay-schema lineage',
    'The actual merged parent contains the exact reviewed replay/schema src/tools/workflow bytes of ca411e77. Five of its six source-delta files are exact at55; train.py also gained the separate preregistration gate.',
    'Managed output credit, bounded engine metadata/schema, completed output publication and faithful replay are retained. Current training input path combines replay integrity with preregistration-before-input access.',
    'evaluate writes retained outputs before report credit; train.load_outputs uses read_credited_outputs, refuses duplicates and visible symbols, and labels legacy loading unverified. No branch-merge title is used as the proof.',
    ['tools/calibration/tier_r/output_store.py', 'tools/calibration/tier_r/evaluate.py',
     'tools/calibration/tier_r/contracts.py', 'tools/calibration/tier_r/report_schemas.py', 'tools/calibration/train.py'],
    live_contract + ['docs/specs/calibration-corpus-and-model.md'],
    ['tests/test_tier_r_credited_replay.py', 'tests/test_tier_r_credit_completion.py', 'tests/test_tier_r_output_stat_compat.py'],
    ['overlap.json exact ca411/874 source equivalence', 'prior exact55 batch5 current replay gate'],
    'No source port needed for this composed replay scope.',
    'Research artifact transfer, final protected-corpus training and native observed prediction accuracy are separate unfinished/ungated scopes.')

add('codex/training-prereg-identity-20261101', 'retained_composed_scope', 'Merged protocol identity guard',
    'Actual f27d23a8/9b9452b4 parent merge; all src/tools/workflow bytes equal9b9452b4. The guard parses an unambiguous visible complete Markdown row and exact LF protocol digest before CLI inputs.',
    'prereg_gate.py is byte-identical to the tip; train.py incorporates the separate stronger managed-output reader and bounded shared engine-version contract. The public run_training library still requires an already validated SHA from its caller.',
    'train._run calls PG.select before _inputs and refuses protocol smoke outside explicit rehearsal. This is an identity guard, not owner approval or a single-use final-look authorization service.',
    ['tools/calibration/prereg_gate.py', 'tools/calibration/train.py'],
    ['docs/specs/calibration-corpus-and-model.md'], ['tests/test_train_prereg_selection.py'],
    ['overlap.json exact9b945/dfe source equivalence', 'prior exact55 batch5 protocol controls and classified historical mismatches'],
    'Keep current composed identity and replay guards; no source port needed.',
    'Missing historical owner-signoff/final-run orchestration remains separate. No protected corpus access, training run, accuracy claim or approval was exercised.')

add('fix/windows-posix-mingw-workflow-20261115', 'retained_test_scope', 'POSIX path semantics in the Linux MinGW workflow assertion',
    'Only changes the test to PurePosixPath for the Linux workflow path while tests run on Windows. No workflow or production path changes occur.',
    'The complete test file is byte-identical to the tip and retains the exact pinned win32 MinGW variant requirement. The current offline workflow parsing tests pass on Linux.',
    'The test reads the existing corpus workflow YAML and checks its Linux path with POSIX semantics; it does not install or run MinGW.',
    ['tests/test_unified_corpus_workflow.py', '.github/workflows/unified-corpus.yml'],
    ['docs/specs/unified-engine/08-evaluation.md'], ['tests/test_unified_corpus_workflow.py'],
    ['current-affected', 'overlap.json byte-identical entire test file'],
    'No source, workflow or test port needed.',
    'This assertion correction alone is not a hosted Windows/MinGW gate, compiler build or proof that all workflow proposals were integrated.')

selected = [r['branch'] for r in json.loads((Q / 'snapshot.json').read_text())['branches']]
assert len(D) == len(selected) == 20 and set(D) == set(selected)
(Q / 'dispositions.json').write_text(json.dumps({'branches': [{'branch': n, **D[n]} for n in selected]}, indent=2) + '\n')
