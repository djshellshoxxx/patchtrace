"""Exact-source SQLite publication/adoption probe. Synthetic projects; no target execution."""
import hashlib
import json
import os
from pathlib import Path
import sqlite3
import tempfile

from patchtrace import persistence, verified_backup as V
from patchtrace.enrichment.storage import EnrichmentStore
from patchtrace.service import ProjectService
from test_prune_backup import CURRENT, FUTURE, _generations


def row_ids(connection, table):
    key = 'id' if table == 'enrichment_entries' else 'sequence'
    return {row[0] for row in connection.execute(f'SELECT {key} FROM {table}')}


def read_copy(path, table):
    with sqlite3.connect(path) as db:
        return {'integrity': db.execute('PRAGMA integrity_check').fetchall(),
                'project_id': V.live_project_id(db),
                'snapshot': db.execute(V.SNAPSHOT_SHA).fetchone()[0],
                'rows': sorted(row_ids(db, table))}


def retention(root, prior=False):
    V.forget_all()
    with ProjectService.sample(root) as service:
        store = EnrichmentStore(service.store)
        _generations(store, 10)
        before = row_ids(service.store.connection, 'enrichment_entries')
        previous = V.write_verified_backup(root, service.store.connection, 'retention') if prior else None
        previous_bytes = previous.read_bytes() if previous else None
        original_link, published = os.link, []

        def link_then_mutate(source, target, **kwargs):
            result = original_link(source, target, **kwargs)
            with sqlite3.connect(target) as db:
                db.execute('DELETE FROM enrichment_entries')
            published.append(Path(target))
            return result

        os.link = link_then_mutate
        try:
            if prior:
                try:
                    V.write_verified_backup(root, service.store.connection, 'retention')
                except V.BackupError as exc:
                    first_result = str(exc)
            else:
                first_result = store.apply_retention(CURRENT, started=FUTURE)
        finally:
            os.link = original_link
        failed = published[0]
        failed_bytes = failed.read_bytes()
        failure_copy = read_copy(failed, 'enrichment_entries')
        after_failure = row_ids(service.store.connection, 'enrichment_entries')
        V.forget_all()
        adopted = V.find_verified_backup(root, 'retention', project_id=service.project.id,
                                         require_tables=('enrichment_entries',))
        later_result = store.apply_retention(CURRENT, started=FUTURE)
        after_later = row_ids(service.store.connection, 'enrichment_entries')
        return {'prior_valid_backup': bool(prior), 'first_result': first_result,
                'before_rows': len(before), 'after_failure_rows': len(after_failure),
                'failure_kept_rows': before == after_failure, 'failed_path': str(failed),
                'failed_copy': failure_copy, 'adopted_failed_copy': adopted == failed,
                'later_deleted': later_result, 'after_later_rows': len(after_later),
                'deleted_ids': sorted(before - after_later),
                'deleted_rows_present_in_failed_copy': sorted((before - after_later) & set(failure_copy['rows'])),
                'failed_bytes_preserved': failed.read_bytes() == failed_bytes,
                'failed_sha256': hashlib.sha256(failed_bytes).hexdigest(),
                'prior_bytes_preserved': previous.read_bytes() == previous_bytes if previous else None}


def history_after_reopen(root):
    V.forget_all()
    keep = persistence.HISTORY_KEEP
    try:
        with ProjectService.sample(root) as service:
            persistence.HISTORY_KEEP = 2
            original_link, published = os.link, []

            def link_then_mutate(source, target, **kwargs):
                result = original_link(source, target, **kwargs)
                with sqlite3.connect(target) as db:
                    db.execute('DELETE FROM history')
                published.append(Path(target))
                return result

            os.link = link_then_mutate
            try:
                for name in ('first', 'second', 'third'):
                    candidate = service.project.model_copy(deep=True)
                    candidate.name = name
                    service.project = service.store.save(candidate)
            finally:
                os.link = original_link
            before = row_ids(service.store.connection, 'history')
            failed = published[0]
            failure_copy = read_copy(failed, 'history')
            session_blocked = service.store._prune_blocked
        V.forget_all()
        with ProjectService.open(root) as service:
            candidate = service.project.model_copy(deep=True)
            candidate.name = 'after reopen'
            service.project = service.store.save(candidate)
            after = row_ids(service.store.connection, 'history')
            return {'failed_path': str(failed), 'failed_copy': failure_copy,
                    'first_session_prune_blocked': session_blocked, 'before_reopen': sorted(before),
                    'after_reopen_save': sorted(after), 'deleted_ids': sorted(before - after),
                    'deleted_rows_present_in_failed_copy': sorted((before - after) & set(failure_copy['rows']))}
    finally:
        persistence.HISTORY_KEEP = keep


if __name__ == '__main__':
    evidence = Path(tempfile.mkdtemp(prefix='storage-postlink-', dir='/workspace/scratch/142cb233d750/reviews-resume'))
    results = {'source': V.__file__, 'evidence_root': str(evidence),
               'retention': retention(evidence / 'retention'),
               'retention_with_prior': retention(evidence / 'retention-prior', prior=True),
               'history_reopen': history_after_reopen(evidence / 'history')}
    print(json.dumps(results, indent=2))
