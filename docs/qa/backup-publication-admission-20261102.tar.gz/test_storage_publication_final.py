"""PR #151: a failed publication must not authorize a later prune, including after restart."""
from __future__ import annotations

import os
import sqlite3
from pathlib import Path

import pytest
from test_prune_backup import CURRENT, FUTURE, _generations

from patchtrace import persistence
from patchtrace import verified_backup as V
from patchtrace.enrichment.storage import EnrichmentStore
from patchtrace.service import ProjectService


@pytest.fixture
def service(tmp_path):
    V.forget_all()
    with ProjectService.sample(tmp_path / 'project') as result:
        yield result
    V.forget_all()


def _rows(db, table='enrichment_entries'):
    key = 'id' if table == 'enrichment_entries' else 'sequence'
    return {row[0] for row in db.execute(f'SELECT {key} FROM {table}')}


def _save(service, name):
    candidate = service.project.model_copy(deep=True)
    candidate.name = name
    service.project = service.store.save(candidate)


def _mutate_after_link(monkeypatch, table='enrichment_entries', observe=None):
    original = os.link
    published = []

    def link_then_change(source, target, **kwargs):
        result = original(source, target, **kwargs)
        if observe is not None:
            observe(Path(source), Path(target))
        with sqlite3.connect(target) as db:
            db.execute(f'DELETE FROM {table}')
            assert db.execute('PRAGMA integrity_check').fetchall() == [('ok',)]
        published.append((Path(source), Path(target), Path(target).read_bytes()))
        return result

    monkeypatch.setattr(os, 'link', link_then_change)
    return published


def test_valid_but_changed_publication_never_adopts_after_restart_or_deletes_rows(service, monkeypatch):
    store = EnrichmentStore(service.store)
    _generations(store, 10)
    before = _rows(service.store.connection)
    snapshot_sha = service.store.connection.execute(V.SNAPSHOT_SHA).fetchone()[0]
    with monkeypatch.context() as changes:
        published = _mutate_after_link(changes)
        assert store.apply_retention(CURRENT, started=FUTURE) == 0
        assert _rows(service.store.connection) == before
        V.forget_all()
        assert V.find_verified_backup(service.root, 'retention', project_id=service.project.id,
                                      snapshot_sha=snapshot_sha, require_tables=('enrichment_entries',)) is None
        assert store.apply_retention(CURRENT, started=FUTURE) == 0
        assert _rows(service.store.connection) == before
    assert len(published) == 2
    for stage, final, data in published:
        assert stage.read_bytes() == final.read_bytes() == data
        assert final not in V._candidates(service.root, 'retention')
    # Once a fresh complete copy can be made, the real public retention operation works.
    assert store.apply_retention(CURRENT, started=FUTURE) == 8
    accepted = V.find_verified_backup(service.root, 'retention', project_id=service.project.id,
                                      require_tables=('enrichment_entries',))
    assert accepted not in {final for _, final, _ in published}
    with sqlite3.connect(accepted) as db:
        assert _rows(db) == before


def test_history_after_reopen_keeps_every_row_when_new_publication_still_fails(service, monkeypatch):
    monkeypatch.setattr(persistence, 'HISTORY_KEEP', 2)
    published = _mutate_after_link(monkeypatch, table='history')
    _save(service, 'first failed prune')
    _save(service, 'same session remains blocked')
    before = _rows(service.store.connection, 'history')
    assert service.store._prune_blocked
    root = service.root
    service.close()
    V.forget_all()
    with ProjectService.open(root) as reopened:
        _save(reopened, 'after restart')
        assert before < _rows(reopened.store.connection, 'history')
        assert reopened.store.load().name == 'after restart'
    assert len(published) == 2
    assert all(stage.read_bytes() == final.read_bytes() == data for stage, final, data in published)


def test_newer_failed_publication_does_not_hide_an_earlier_valid_backup(service, monkeypatch):
    store = EnrichmentStore(service.store)
    _generations(store, 10)
    earlier = V.write_verified_backup(service.root, service.store.connection, 'retention')
    earlier_bytes = earlier.read_bytes()
    published = _mutate_after_link(monkeypatch)
    with pytest.raises(V.BackupError, match='changed during publication'):
        V.write_verified_backup(service.root, service.store.connection, 'retention')
    V.forget_all()
    assert V.find_verified_backup(service.root, 'retention', project_id=service.project.id,
                                  require_tables=('enrichment_entries',)) == earlier
    assert store.apply_retention(CURRENT, started=FUTURE) == 8
    assert earlier.read_bytes() == earlier_bytes
    stage, final, data = published[0]
    assert stage.read_bytes() == final.read_bytes() == data


def test_reader_does_not_admit_a_publication_before_its_final_validation(service, monkeypatch):
    store = EnrichmentStore(service.store)
    _generations(store, 10)
    observations = []

    def observe(stage, final):
        observations.append(V.find_verified_backup(service.root, 'retention', project_id=service.project.id,
                                                    require_tables=('enrichment_entries',)))

    _mutate_after_link(monkeypatch, observe=observe)
    assert store.apply_retention(CURRENT, started=FUTURE) == 0
    assert observations == [None]


@pytest.mark.parametrize('replace_stage', [False, True])
def test_foreign_final_and_stage_replacements_are_preserved_and_not_adopted(service, monkeypatch, replace_stage):
    original = os.link
    replacements = []

    def link_then_replace(stage, final, **kwargs):
        result = original(stage, final, **kwargs)
        final = Path(final)
        before = final.read_bytes()
        final.unlink()
        final.write_bytes(before)
        with sqlite3.connect(final) as db:
            db.execute('DELETE FROM history')
            assert db.execute('PRAGMA integrity_check').fetchall() == [('ok',)]
        if replace_stage:
            Path(stage).unlink()
            Path(stage).write_bytes(b'foreign staging evidence')
        replacements.append((Path(stage), final, final.read_bytes()))
        return result

    monkeypatch.setattr(os, 'link', link_then_replace)
    with pytest.raises(V.BackupError, match='changed during publication'):
        V.write_verified_backup(service.root, service.store.connection, 'history-prune')
    stage, final, replaced_bytes = replacements[0]
    assert final.read_bytes() == replaced_bytes
    assert stage.exists()
    if replace_stage:
        assert stage.read_bytes() == b'foreign staging evidence'
    V.forget_all()
    assert final not in V._candidates(service.root, 'history-prune')
    assert V.find_verified_backup(service.root, 'history-prune', project_id=service.project.id) is None


def test_staging_cleanup_failure_cannot_make_pending_name_eligible(service, monkeypatch):
    original = Path.unlink

    def cannot_remove_stage(path, *args, **kwargs):
        if path.name.endswith('.sqlite3.part'):
            raise PermissionError('retained staging name')
        return original(path, *args, **kwargs)

    monkeypatch.setattr(Path, 'unlink', cannot_remove_stage)
    final = V.write_verified_backup(service.root, service.store.connection, 'history-prune')
    assert final.is_file()
    V.forget_all()
    assert V.find_verified_backup(service.root, 'history-prune', project_id=service.project.id) is None


def test_successful_publication_removes_only_its_stage_and_keeps_normal_reuse(service):
    directory = service.root / 'backups'
    directory.mkdir(exist_ok=True)
    unrelated = directory / 'project-pre-history-prune-older-attempt.sqlite3.part'
    unrelated.write_bytes(b'prior interrupted evidence')
    final = V.write_verified_backup(service.root, service.store.connection, 'history-prune')
    assert list(directory.glob('*.part')) == [unrelated]
    assert unrelated.read_bytes() == b'prior interrupted evidence'
    V.forget_all()
    assert V.find_verified_backup(service.root, 'history-prune', project_id=service.project.id) == final
    assert V.trusted_backup(service.root, 'history-prune', project_id=service.project.id) == final
