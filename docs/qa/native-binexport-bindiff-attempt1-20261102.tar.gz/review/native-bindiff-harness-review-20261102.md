# Independent native recovery harness review — 2026-11-02

No blocking source-review findings for this bounded authored QA harness. Native execution remains a separate coordinator-controlled step.

- Reviewer: `/root/msrc_recover`; author: `/root/output_windows`.
- Base: `1367889d549a4db290b669df4ed97ac20b553428`.
- Reviewed head: `25c4114db1ee518a695372597473163e51eb1861`.
- Tree: `4efdf4cca7a429784c6886357c3670139bc0299e`.
- Clean isolated checkout: `/workspace/scratch/142cb233d750/wt-native-harness-review`.

The five-file range and exact production acceptance/scheduler/process interfaces were reviewed. The Java script checks the imported program SHA-256, calls the packaged exporter with its verified identical false defaults, keeps failed stages, and publishes by exclusive hardlink. The driver refuses existing session roots, pins source/import/tool identities, uses explicit Java and private environment paths, bounds processes/logs, and delegates execution to production containment. C3 still uses exact role/hash with `accept_unbound=False`; its temporary logging wrapper delegates unchanged arguments and restores the runner even on exceptions. Swapped accepted inputs are checked with pure `bind_pair` before the adapter is constructed. The planned wrong-hash control uses actual C3. No argv executes either target DLL.

Raw retention claims are appropriately limited: original exports, Ghidra projects, receipts and bounded logs stay in the fresh session; clean-exit BinDiff output is preserved by production before importer validation. Interrupted partial BinDiff databases remain rejected/discarded under the existing production policy. The unsigned/unverified trust statuses and acceptance gates are unchanged.

Fresh independent checks:

- Author's safe selection rerun: **11 passed in 0.73 s**.
- Four additional safe controls: **4 passed in 0.53 s**. These use a harmless Python child for real timeout/log retention; reject a wrong source head before reading tools; reject a nested C3 wrapper while restoring the original runner; and reject a symlink output without touching prior evidence.
- Default preflight with no `--run`: **setup-checked**, `native_executed=false`; source/import binding and configured tool/archive/script/input digests passed.
- Changed-file Ruff, range whitespace checks and unchanged production `src/tools` comparison passed.

The JSON sibling binds SHA-256 values for every changed file, the production interfaces, independent control source, and preflight output. Review artifacts are in `reviews-msrc/`.

No compiler, JVM, Ghidra, exporter, BinDiff or target was executed. Java compatibility remains source-reviewed only; there is no compilation claim. Native negative controls and actual exporter/BinDiff outcomes await explicit coordinator release. This is neither full-suite/Windows/Tier-R/Tier-W/signed-oracle/G-U/release acceptance nor a GitHub APPROVE event. Any source rebase or harness edit must be rebound and reviewed before execution; this receipt is limited to the pinned commit range.
