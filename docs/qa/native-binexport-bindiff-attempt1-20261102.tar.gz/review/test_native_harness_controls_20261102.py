"""Independent guard controls only: harmless Python children, no compiler/Java/BinDiff/target execution."""
import importlib.util
import json
import sys
from pathlib import Path

import pytest

CHECKOUT = Path('/workspace/scratch/142cb233d750/wt-native-harness-review')
SPEC = importlib.util.spec_from_file_location('native_independent', CHECKOUT / 'docs/qa/native-bindiff-harness-20261102.py')
H = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(H)


def test_real_timeout_keeps_bounded_pretermination_streams_and_exact_argv(tmp_path):
    session = H.Session(tmp_path / 'run', {})
    argv = [sys.executable, '-u', '-c', 'import time,sys;print("started");print("diagnostic",file=sys.stderr);time.sleep(10)']
    result = session.run(argv, cwd=tmp_path, env={}, cancel=session.cancel, timeout_seconds=0.2,
                         log_limit=4096, separate_streams=True, stderr_limit=4096)
    assert result.reason == 'timeout'
    with pytest.raises(RuntimeError, match='reason=timeout'):
        H.require_clean(result, 'constructed timeout')
    saved = json.loads((session.root / 'receipt.json').read_bytes())['processes'][0]
    assert saved['argv'] == argv and saved['reason'] == 'timeout'
    assert saved['elapsed_seconds'] < 5
    assert (session.root / 'process-01.stdout').read_bytes() == b'started\n'
    assert (session.root / 'process-01.stderr').read_bytes() == b'diagnostic\n'


def test_source_mismatch_refuses_before_reading_tool_root(tmp_path):
    with pytest.raises(ValueError, match='repository head differs'):
        H.setup(tmp_path / 'nonexistent-tools', '0' * 40)
    assert list(tmp_path.iterdir()) == []


def test_nested_c3_wrapper_refuses_without_losing_outer_or_production_runner(tmp_path):
    first = H.Session(tmp_path / 'first', {})
    second = H.Session(tmp_path / 'second', {})
    original = H.binexport_run.run_process
    with H.record_c3(first):
        with pytest.raises(ValueError, match='already substituted'):
            with H.record_c3(second):
                pytest.fail('nested runner override admitted')
        assert H.binexport_run.run_process == first.run
    assert H.binexport_run.run_process is original is H.run_process


def test_export_guard_refuses_symlink_without_following_destination(tmp_path):
    out = tmp_path / 'out'
    out.mkdir()
    outside = tmp_path / 'previous-evidence'
    outside.write_bytes(b'keep')
    (out / 'output.BinExport').symlink_to(outside)
    assert H.export_guard(out) == 'output-unexpected'
    assert outside.read_bytes() == b'keep'
