"""Retain exact local branch evidence; do not mutate or fetch remote refs."""
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch4')
BASE = '55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
NAMES = ['chatgpt/semantic-analysis-r3-20261030', 'chatgpt/ue-r3-retain-decompiled-20261016', 'claude/funny-feynman-d2m0b5', 'claude/gallant-knuth-8gxuzd', 'codex/r2-unified-matching-research-20261030', 'research/r8-deep-uncertainty-20261030', 'codex/tier-w-fetch-20261015', 'fix/remediation-a58defa8-139db0', 'fix/remediation-b1ab7332-a8fac4', 'consolidate/research-r7-20261104', 'claude/affectionate-galileo-bqd3tw', 'claude/instance-c-research', 'repair/gt01-consolidated-native-evidence-20261030', 'repair/gt01-native-identical-controls-20261030', 'repair/gt01-unified-live-gates-20261030', 'codex/gt01-extraction-recovery-20261030', 'codex/r1-ground-truth-research-20261030', 'feat/verified-offline-runtime-bundle', 'security/offline-bundle-no-overwrite-20261013', 'haiku/cli-help-suppress-20261027']


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True)


def tree(sha):
    return {
        line.split('\t', 1)[1]: line.split()[2]
        for line in git('ls-tree', '-r', sha, '--', 'src', 'tests', 'tools').splitlines()
    }


inventory_path = ROOT / 'docs/plans/autonomous-consolidation-20261118/branch-inventory.json'
inventory = json.loads(inventory_path.read_text())
rows = {row['branch']: row for row in inventory['branches']}
prs = {row['number']: row for row in inventory['pull_requests']}
batch1 = json.loads((ROOT / 'docs/plans/autonomous-consolidation-20261118/semantic-disposition-batch1.json').read_text())
batch2 = json.loads(git('show', '1a07861f3d54dde6fce0bbd3c79fc772295c92ac:docs/plans/autonomous-consolidation-20261118/semantic-disposition-batch2.json'))
batch3 = json.loads(git('show', 'aa90efbb8238d58817489377f05dc52af7f1e239:docs/plans/autonomous-consolidation-20261118/semantic-disposition-batch3.json'))
previous = {row['branch'] for row in batch1['branches'] + batch2['branches'] + batch3['branches']}
assert len(previous) == 60
base_tree = tree(BASE)


def capture(name):
    old = rows[name]
    assert old['classification'] == 'needs_reconciliation', name
    assert name not in previous, name
    sha = git('rev-parse', 'refs/remotes/origin/' + name).strip()
    mb = git('merge-base', BASE, sha).strip()
    paths = git('diff', '--name-only', mb, sha).splitlines()
    sources = [p for p in paths if p.startswith(('src/', 'tools/'))]
    tests = [p for p in paths if p.startswith('tests/')]
    source_tree = tree(sha)
    projection = [
        {
            'path': p,
            'tip_blob': source_tree.get(p),
            'base_blob': base_tree.get(p),
            'state': (
                'identical' if source_tree.get(p) == base_tree.get(p) else
                'missing_current' if p not in base_tree else
                'deleted_at_tip' if p not in source_tree else 'different'
            ),
        }
        for p in sources + tests
    ]
    label = name.replace('/', '__')
    patch = git('diff', '--binary', mb, sha, '--', 'src', 'tests', 'tools')
    (OUT / (label + '.patch')).write_text(patch)
    between = git('diff', '--binary', BASE, sha, '--', *sources) if sources else ''
    (OUT / (label + '.current-comparison.patch')).write_text(between)
    return {
        'branch': name, 'tip': sha,
        'inventory_tip': old['head_sha'], 'tip_matches_inventory': sha == old['head_sha'],
        'inventory_classification': old['classification'], 'merge_base': mb,
        'ahead_behind_baseline': git('rev-list', '--left-right', '--count', BASE + '...' + sha).strip(),
        'patch_equivalence': git('cherry', BASE, sha).splitlines(),
        'unique_log': git('log', '--no-merges', '--format=%H %s', BASE + '..' + sha).splitlines(),
        'pull_requests': [prs[p['number']] for p in old['pull_requests']],
        'changed_paths': paths, 'source_projection': projection,
        'branch_patch': {'file': label + '.patch', 'sha256': hashlib.sha256(patch.encode()).hexdigest()},
        'current_comparison_patch': {
            'file': label + '.current-comparison.patch',
            'sha256': hashlib.sha256(between.encode()).hexdigest(),
        },
    }


with ThreadPoolExecutor(max_workers=4) as pool:
    captured = list(pool.map(capture, NAMES))
result = {
    'schema': 'patchtrace-semantic-disposition-input/1',
    'captured_at_utc': datetime.now(UTC).isoformat(),
    'comparison_base': BASE, 'comparison_tree': git('rev-parse', BASE + '^{tree}').strip(),
    'inventory_source_sha256': hashlib.sha256(inventory_path.read_bytes()).hexdigest(),
    'inventory_observed_at': inventory['observed_at_utc'],
    'classification_denominator': 131, 'previously_selected': len(previous),
    'selected_count': len(captured), 'not_selected_after_this_batch': 131-len(previous)-len(captured),
    'remote_refresh': 'Local fetched refs cross-checked against frozen inventory. No new REST observation or remote mutation.',
    'branches': captured,
}
(OUT / 'snapshot.json').write_text(json.dumps(result, indent=2) + '\n')
for row in captured:
    different = [x['path'] for x in row['source_projection'] if x['path'].startswith(('src/', 'tools/')) and x['state'] != 'identical']
    missing = [x['path'] for x in row['source_projection'] if x['state'] == 'missing_current']
    same = sum(x['path'].startswith(('src/', 'tools/')) and x['state'] == 'identical' for x in row['source_projection'])
    print(row['branch'], row['tip'], f'identical_source={same} differing_source={len(different)} missing={len(missing)}')
    print('  current differences:', ', '.join(different))
    print('  missing:', ', '.join(missing))
    print('  unique commits:', *row['unique_log'][:6], sep='\n    ')
