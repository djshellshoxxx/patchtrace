"""Independent current public/manual and persisted-cap evidence. Authored inputs only."""
from __future__ import annotations

import contextlib
import io
import json
from pathlib import Path

import pytest
from unified_read_support import publish, request
from unified_s0_fixtures import make_project

from patchtrace import cli
from patchtrace.unified import pipeline, read_model, store
from patchtrace.unified.contracts import Atom
from patchtrace.unified.fusion import arbiter

EVIDENCE = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch4/product-surfaces')
EVIDENCE.mkdir(exist_ok=True)


@pytest.mark.parametrize('kind', ['split', 'merged', 'ambiguous'])
def test_public_manual_correction_explain_and_desktop_detail_identify_analyst(kind, tmp_path):
    service = make_project(tmp_path / 'project')
    try:
        matches = [m for m in service.project.matches if m.older and m.newer]
        first, second = matches[:2]
        older = [first.older[0].id] + ([second.older[0].id] if kind == 'merged' else [])
        newer = [first.newer[0].id] + ([] if kind == 'merged' else [second.newer[0].id])
        service.correct_match(first.id, older, newer, kind, 'Authored analyst group for branch disposition')
        report = pipeline.run_unified(service, pipeline.UnifiedOptions(
            isolate=False, use_ir=False, decompile=False, sources=('manual',)))
        assert report.status in ('complete', 'partial')
        captured = read_model.request_from_service(service)
        assert captured.loaded.state == 'current'
        store.verify_result_dir(captured.loaded.directory)
        vm = read_model.load_unified(captured)
        assert len(vm.rows) == 1
        row = vm.rows[0]
        detail = read_model.row_detail(vm, row)
        record = read_model.records_for(vm, [row])[row.row_id].match
        assert record.support == ()
        assert record.decision == ('ambiguous' if kind == 'ambiguous' else 'matched')
        assert f'manual-group:{kind}' in record.hints
        root = service.root
    finally:
        service.close()
    out, err = io.StringIO(), io.StringIO()
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        code = cli.main(['unified', 'explain', str(root), '--row', row.row_id, '--json'])
    doc = json.loads(out.getvalue())
    assert code == 0 and doc['result']['state'] == 'current'
    assert doc['result']['detail'] == detail
    (EVIDENCE / f'manual-{kind}.json').write_text(json.dumps({
        'construction': 'ProjectService.correct_match -> run_unified manual-only S0 -> strict store verification -> desktop view model -> close/reopen through cli.main unified explain',
        'cli_exit': code, 'cli_document': doc, 'desktop_detail': detail, 'stderr': err.getvalue(),
    }, indent=2) + '\n')
    assert 'analyst correction' in detail.lower() and kind in detail
    assert 'Independent tier B evidence' not in detail


def _atom(step='ExactMnemonicsFunctionHasher', cls='E-BODY', *, source='ghidriff', ref=None):
    return Atom(source=source, step=step, tier='B', cardinality='1:1', cls=cls,
                older_rva=0x1000, newer_rva=0x1800, ref=ref)


@pytest.mark.parametrize('copies', [1, 70])
def test_verified_capped_row_detail_retains_the_acceptance_evidence_classes(copies, tmp_path):
    atoms = [*(_atom(ref=f'body-{i:03}') for i in range(copies)),
             _atom('StringsRefsHasher', 'E-DATA', ref='data-witness'),
             _atom('P08-mnemonic-seq', source='pt-bytes', ref='body-witness')]
    [decided] = arbiter.decide(atoms, [])
    row = arbiter.to_match(decided, {}, 'a' * 64, 'b' * 64)
    loaded = publish(tmp_path / 'result', [row])
    store.verify_result_dir(loaded.directory)
    vm = read_model.load_unified(request(loaded))
    assert vm.state == 'U3' and vm.rows[0].decision == 'matched'
    detail = read_model.row_detail(vm, vm.rows[0])
    persisted = list(store.read_rows(loaded.directory, loaded.manifest))[0]
    (EVIDENCE / f'cap-{copies}.json').write_text(json.dumps({
        'construction': 'Manufactured registered atoms -> arbiter -> strict result writer/verifier -> desktop view model/detail. This proves persistence/presentation reachability; it is not a native-engine corpus claim.',
        'row': persisted.model_dump(mode='json'), 'desktop_detail': detail,
    }, indent=2) + '\n')
    assert {a.cls for a in persisted.atoms} == {'E-BODY', 'E-DATA'}
