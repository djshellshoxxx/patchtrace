# Evidence document preflight corrections

The first document-path check identified one authoring typo: the retained RB01
template module is tools/unified/mutations/templates.py, not the guessed
tools/calibration/tier_r/templates.py. The actual source projection supplied the
correct path. No source/test behavior was changed.

The first document-builder invocation stopped at Python parsing before any
document/source-snapshot write: three adjacent text expressions lacked the plus
before the backtick variable Q. The exact initial script is retained as
build_documents-initial.py. The corrected script completed and validated all
source/spec/test paths, original test bytes, source pins and XML counts. This is
a document-generation preflight error, not a product-test failure or repair.
