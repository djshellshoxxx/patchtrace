"""Offline runtime bundle verifier / installer contract tests.

Tiny text payloads test only ZIP isolation and transaction semantics, not an
operational Python, Java, Ghidra or Ghidriff runtime.
"""
from __future__ import annotations

import hashlib
import json
import os
import struct
import threading
import zipfile
from pathlib import Path

import pytest

from patchtrace import offline_bundle
from patchtrace.offline_bundle import (
    OfflineBundleError,
    inspect_offline_bundle,
    install_offline_bundle,
)

RUNTIME_ID = 'ghidra-12.0.4-ghidriff-4f5d895-windows-amd64'
FILES = {
    'python/python.exe': b'fake-python-executable',
    'ghidra/Ghidra/application.properties': b'application.version=12.0.4',
    'jdk/bin/java.exe': b'fake-java-executable',
    'LICENSES/NOTICE.txt': b'Test stub licenses - not redistributable runtime',
}


def make_bundle(tmp_path, files=None, *, extra_members=(), manifest_override=None):
    data = dict(FILES if files is None else files)
    manifest = {
        'format': 'patchtrace-offline-runtime',
        'schema_version': 1,
        'runtime_id': RUNTIME_ID,
        'platform': 'windows',
        'architecture': 'amd64',
        'python': 'python/python.exe',
        'ghidra': 'ghidra',
        'java': 'jdk',
        'versions': {'python': '3.12.10', 'ghidra': '12.0.4', 'jdk': '25',
                     'ghidriff_revision': '4f5d895fcbb1eacd65efd81145922c15bb7e741d'},
        'files': [
            {'path': name, 'size': len(data[name]), 'sha256': hashlib.sha256(data[name]).hexdigest()}
            for name in sorted(data)
        ],
    }
    if manifest_override:
        manifest = manifest_override(manifest)
    archive = tmp_path / 'runtime.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as out:
        out.writestr('manifest.json', json.dumps(manifest))
        for path, blob in data.items():
            out.writestr('payload/' + path, blob)
        for name, blob in extra_members:
            out.writestr(name, blob)
    return archive


def test_inspect_valid_bundle_without_executing_stub_tools(tmp_path, monkeypatch):
    bundle = make_bundle(tmp_path)
    monkeypatch.setattr('subprocess.run', lambda *args, **kwargs: pytest.fail('Must never execute'))
    plan = inspect_offline_bundle(bundle)
    assert plan.runtime_id == RUNTIME_ID
    assert plan.file_count == 4
    assert plan.total_bytes == sum(map(len, FILES.values()))
    assert len(plan.sha256) == 64


def test_atomic_install_retains_files_and_is_usable_from_paths(tmp_path):
    bundle = make_bundle(tmp_path)
    plan = inspect_offline_bundle(bundle)
    root = tmp_path / 'Program Files with spaces' / 'runtimes'
    installed = install_offline_bundle(plan, root)
    assert installed.root == root / RUNTIME_ID
    assert installed.python_executable.read_bytes() == FILES['python/python.exe']
    assert (installed.ghidra_dir / 'Ghidra' / 'application.properties').read_bytes().startswith(b'application')
    assert installed.java_home.joinpath('bin', 'java.exe').is_file()
    assert (installed.root / 'manifest.json').is_file()
    assert list(root.glob('.install-*')) == []
    assert not list(root.glob('.runtime-*.lock'))


@pytest.mark.parametrize('member', [
    'payload/../escape', 'payload/./ignored', 'payload/C:/Windows/file',
    'payload/python\\danger', 'payload/CON.txt', 'payload/file:stream',
    'payload/trailing. ', 'other-dir/evil',
])
def test_rejects_malicious_archive_entries(tmp_path, member):
    bundle = make_bundle(tmp_path, extra_members=[(member, b'malicious')])
    with pytest.raises(OfflineBundleError, match='PT-OFFLINE'):
        inspect_offline_bundle(bundle)


def test_rejects_duplicate_zip_entries(tmp_path):
    bundle = make_bundle(tmp_path, extra_members=[('payload/python/python.exe', b'overwritten')])
    with pytest.raises(OfflineBundleError):
        inspect_offline_bundle(bundle)


def test_rejects_hash_mismatch_and_missing_components(tmp_path):
    bundle = make_bundle(tmp_path, files={**FILES, 'LICENSES/NOTICE.txt': b'changed'},
                         manifest_override=lambda m: {
                             **m, 'files': [{**f, 'sha256': '0' * 64}
                                            if f['path'] == 'LICENSES/NOTICE.txt' else f
                                            for f in m['files']]})
    with pytest.raises(OfflineBundleError, match='hash'):
        inspect_offline_bundle(bundle)
    bundle = make_bundle(tmp_path, files={k: v for k, v in FILES.items() if not k.startswith('jdk/')})
    with pytest.raises(OfflineBundleError):
        inspect_offline_bundle(bundle)


def test_external_sha_is_checked(tmp_path):
    bundle = make_bundle(tmp_path)
    with pytest.raises(OfflineBundleError, match='SHA-256'):
        inspect_offline_bundle(bundle, expected_sha256='f' * 64)
    correct = hashlib.sha256(bundle.read_bytes()).hexdigest()
    assert inspect_offline_bundle(bundle, expected_sha256=correct).sha256 == correct


def test_cancel_before_install_leaves_previous_runtimes_alone(tmp_path):
    plan = inspect_offline_bundle(make_bundle(tmp_path))
    root = tmp_path / 'runtimes'
    root.mkdir()
    existing = root / 'existing'
    existing.mkdir()
    (existing / 'marker').write_text('retain')
    cancel = threading.Event()
    cancel.set()
    with pytest.raises(OfflineBundleError, match='cancel'):
        install_offline_bundle(plan, root, cancel=cancel)
    assert (existing / 'marker').read_text() == 'retain'
    assert not (root / RUNTIME_ID).exists()
    assert not list(root.glob('.install-*'))


def test_idempotence_no_overwrite_and_lock_not_stolen(tmp_path):
    plan = inspect_offline_bundle(make_bundle(tmp_path))
    root = tmp_path / 'runtimes'
    install_offline_bundle(plan, root)
    marker = root / RUNTIME_ID / 'marker.txt'
    marker.write_text('analyst data')
    with pytest.raises(OfflineBundleError, match='already installed'):
        install_offline_bundle(plan, root)
    assert marker.read_text() == 'analyst data'

    second = tmp_path / 'second' / 'runtimes'
    second.mkdir(parents=True)
    lock = second / f'.runtime-{RUNTIME_ID}.lock'
    lock.write_text('other process')
    with pytest.raises(OfflineBundleError, match='lock'):
        install_offline_bundle(plan, second)
    assert lock.read_text() == 'other process'


def test_detects_archive_replacement_after_inspection(tmp_path):
    archive = make_bundle(tmp_path)
    plan = inspect_offline_bundle(archive)
    archive.write_bytes(archive.read_bytes() + b'changed after inspection')
    root = tmp_path / 'runtimes'
    with pytest.raises(OfflineBundleError, match='changed'):
        install_offline_bundle(plan, root)
    assert not (root / RUNTIME_ID).exists()


def test_rejects_symlinked_install_root(tmp_path):
    plan = inspect_offline_bundle(make_bundle(tmp_path))
    real = tmp_path / 'real'
    real.mkdir()
    link = tmp_path / 'linked'
    try:
        link.symlink_to(real, target_is_directory=True)
    except (OSError, NotImplementedError):
        pytest.skip('Symlink creation not permitted')
    with pytest.raises(OfflineBundleError, match='symbolic'):
        install_offline_bundle(plan, link)
    assert not list(real.iterdir())


def test_rejects_corrupt_json_and_non_windows_manifest(tmp_path):
    archive = make_bundle(tmp_path, manifest_override=lambda m: {**m, 'platform': 'linux'})
    with pytest.raises(OfflineBundleError):
        inspect_offline_bundle(archive)
    archive = tmp_path / 'bad.zip'
    archive.write_bytes(b'not zip data')
    with pytest.raises(OfflineBundleError):
        inspect_offline_bundle(archive)


def test_producer_does_not_modify_source_and_creates_installable_bundle(tmp_path):
    from patchtrace.offline_bundle import build_offline_bundle

    source = tmp_path / 'payload'
    for relative, value in FILES.items():
        path = source / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(value)
    archive = tmp_path / 'output.zip'
    versions = {'python': '3.12.10', 'ghidra': '12.0.4', 'jdk': '25',
                'ghidriff_revision': '4f5d895fcbb1eacd65efd81145922c15bb7e741d'}
    build_offline_bundle(source, RUNTIME_ID, versions, archive)
    plan = inspect_offline_bundle(archive)
    assert plan.runtime_id == RUNTIME_ID
    assert install_offline_bundle(plan, tmp_path / 'installed').python_executable.read_bytes() == FILES['python/python.exe']


def test_cancellation_during_extraction_removes_stage_and_lock(tmp_path):
    plan = inspect_offline_bundle(make_bundle(tmp_path))
    cancel = threading.Event()
    root = tmp_path / 'runtimes'
    events = []
    def stop_after_first_file(message):
        events.append(message)
        cancel.set()

    with pytest.raises(OfflineBundleError, match='cancel'):
        install_offline_bundle(plan, root, cancel=cancel, event=stop_after_first_file)
    assert events
    assert not (root / RUNTIME_ID).exists()
    assert not list(root.iterdir())


def test_rejects_case_insensitive_member_collision(tmp_path):
    archive = make_bundle(tmp_path, extra_members=[('payload/PYTHON/python.exe', b'collision')])
    with pytest.raises(OfflineBundleError, match='colliding'):
        inspect_offline_bundle(archive)


def test_rejects_windows_device_name_runtime_id(tmp_path):
    archive = make_bundle(tmp_path, manifest_override=lambda m: {**m, 'runtime_id': 'CON'})
    with pytest.raises(OfflineBundleError, match='runtime ID'):
        inspect_offline_bundle(archive)


def test_rejects_symlink_member(tmp_path):
    archive = make_bundle(tmp_path)
    # Rebuild ZIP using identical manifest but a Unix symbolic-link mode for a payload file.
    with zipfile.ZipFile(archive) as original:
        contents = [(info.filename, original.read(info.filename)) for info in original.infolist()]
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as dest:
        for name, data in contents:
            info = zipfile.ZipInfo(name)
            info.compress_type = zipfile.ZIP_DEFLATED
            if name == 'payload/python/python.exe':
                info.create_system = 3
                info.external_attr = 0o120777 << 16
            dest.writestr(info, data)
    with pytest.raises(OfflineBundleError, match='symlink'):
        inspect_offline_bundle(archive)


def test_insufficient_disk_space_is_reported_before_install(tmp_path, monkeypatch):
    from collections import namedtuple

    from patchtrace import offline_bundle

    plan = inspect_offline_bundle(make_bundle(tmp_path))
    usage = namedtuple('usage', ['total', 'used', 'free'])
    monkeypatch.setattr(offline_bundle.shutil, 'disk_usage', lambda _: usage(100, 100, 0))
    root = tmp_path / 'runtimes'
    with pytest.raises(OfflineBundleError, match='disk space'):
        install_offline_bundle(plan, root)
    assert not root.exists()


def test_producer_is_byte_deterministic_across_distinct_destinations(tmp_path):
    from patchtrace.offline_bundle import build_offline_bundle

    source = tmp_path / 'payload'
    for name, content in FILES.items():
        path = source / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(content)
    versions = {'python': '3.12.10', 'ghidra': '12.0.4', 'jdk': '25',
                'ghidriff_revision': '4f5d895fcbb1eacd65efd81145922c15bb7e741d'}
    a = build_offline_bundle(source, RUNTIME_ID, versions, tmp_path / 'a.zip')
    b = build_offline_bundle(source, RUNTIME_ID, versions, tmp_path / 'b.zip')
    assert a.read_bytes() == b.read_bytes()


# Regressions from the 2026-10-12 security review of the installer.

def test_cancellation_is_reported_as_pt_cancel_not_rejection(tmp_path):
    from patchtrace.offline_bundle import OfflineBundleCancelled
    plan = inspect_offline_bundle(make_bundle(tmp_path))
    cancel = threading.Event()
    cancel.set()
    with pytest.raises(OfflineBundleCancelled, match=r'^PT-CANCEL:'):
        install_offline_bundle(plan, tmp_path / 'runtimes', cancel=cancel)
    with pytest.raises(OfflineBundleCancelled):
        inspect_offline_bundle(make_bundle(tmp_path), cancel=cancel)


@pytest.mark.parametrize('suffix', ['..'])
def test_rejects_non_normalized_install_root(tmp_path, suffix):
    plan = inspect_offline_bundle(make_bundle(tmp_path))
    (tmp_path / 'inner').mkdir()
    root = tmp_path / 'inner' / suffix
    with pytest.raises(OfflineBundleError, match='normalized'):
        install_offline_bundle(plan, root)
    assert not (tmp_path / RUNTIME_ID).exists()


def test_rejects_filesystem_root_and_os_directory(tmp_path, monkeypatch):
    plan = inspect_offline_bundle(make_bundle(tmp_path))
    with pytest.raises(OfflineBundleError, match='root'):
        install_offline_bundle(plan, Path(tmp_path.anchor))
    system = tmp_path / 'fake-windows'
    system.mkdir()
    monkeypatch.setenv('WINDIR', str(system))
    with pytest.raises(OfflineBundleError, match='operating-system'):
        install_offline_bundle(plan, system / 'runtimes')
    assert not (system / 'runtimes').exists()


def test_corrupt_deflate_stream_is_a_pt_offline_error(tmp_path):
    archive = make_bundle(tmp_path, files={**FILES, 'LICENSES/NOTICE.txt': b'N' * 4096})
    data = bytearray(archive.read_bytes())
    with zipfile.ZipFile(archive) as zf:
        info = zf.getinfo('payload/LICENSES/NOTICE.txt')
    start = info.header_offset + 30 + len(info.filename.encode()) + len(info.extra)
    for i in range(start, start + min(8, info.compress_size)):
        data[i] ^= 0xFF
    archive.write_bytes(bytes(data))
    with pytest.raises(OfflineBundleError, match='PT-OFFLINE'):
        inspect_offline_bundle(archive)


@pytest.mark.parametrize('member', ['payload/x/COM¹.txt', 'payload/x/LPT³', 'payload/CONIN$',
                                    'payload/x/CONOUT$.log', 'payload/x/NUL .txt'])
def test_rejects_extended_windows_device_names(tmp_path, member):
    with pytest.raises(OfflineBundleError):
        inspect_offline_bundle(make_bundle(tmp_path, extra_members=[(member, b'x')]))


def test_cleanup_failure_keeps_original_reason(tmp_path, monkeypatch):
    from patchtrace import offline_bundle
    plan = inspect_offline_bundle(make_bundle(tmp_path))
    cancel = threading.Event()
    monkeypatch.setattr(offline_bundle.shutil, 'rmtree', lambda *_a, **_k: (_ for _ in ()).throw(OSError('locked')))
    with pytest.raises(OfflineBundleError) as caught:
        install_offline_bundle(plan, tmp_path / 'runtimes', cancel=cancel, event=lambda _m: cancel.set())
    message = str(caught.value)
    assert message.startswith('PT-CANCEL:') and 'staging cleanup failed at' in message


@pytest.mark.skipif(os.name == 'nt', reason='POSIX os.replace semantics')
def test_publish_does_not_replace_directory_created_after_check(tmp_path, monkeypatch):
    from patchtrace import offline_bundle
    plan = inspect_offline_bundle(make_bundle(tmp_path))
    root = tmp_path / 'runtimes'
    real = offline_bundle._publish_no_replace

    def intruder(stage, destination):
        destination.mkdir()
        return real(stage, destination)

    monkeypatch.setattr(offline_bundle, '_publish_no_replace', intruder)
    with pytest.raises(OfflineBundleError):
        install_offline_bundle(plan, root)
    assert (root / RUNTIME_ID).is_dir() and not any((root / RUNTIME_ID).iterdir())
    assert not list(root.glob('.install-*'))


def test_plan_and_installed_runtime_expose_parsed_manifest(tmp_path):
    plan = inspect_offline_bundle(make_bundle(tmp_path))
    assert plan.manifest['runtime_id'] == RUNTIME_ID
    installed = install_offline_bundle(plan, tmp_path / 'runtimes')
    assert installed.manifest == plan.manifest
    assert installed.manifest_path.read_bytes() == plan.manifest_bytes
    assert installed.python_executable == installed.root / plan.python_relative


def test_producer_does_not_overwrite_archive_created_during_publish(tmp_path, monkeypatch):
    from patchtrace import offline_bundle

    source = tmp_path / 'payload'
    for name, content in FILES.items():
        target = source / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
    destination = tmp_path / 'publish.zip'
    versions = {'python': '3.12.10', 'ghidra': '12.0.4', 'jdk': '25',
                'ghidriff_revision': '4f5d895fcbb1eacd65efd81145922c15bb7e741d'}
    real_link = offline_bundle.os.link

    def competing_publisher(src, dst, *args, **kwargs):
        destination.write_bytes(b'other publisher')
        return real_link(src, dst, *args, **kwargs)

    monkeypatch.setattr(offline_bundle.os, 'link', competing_publisher)
    with pytest.raises(FileExistsError):
        offline_bundle.build_offline_bundle(source, RUNTIME_ID, versions, destination)
    assert destination.read_bytes() == b'other publisher'
    assert not list(tmp_path.glob('.offline-pack-*'))


# ---- TB-10: the entry count is read from the end-of-central-directory record before zipfile opens the archive ----

EOCD = struct.Struct('<4s4H2LH')
EOCD_SIGNATURE = b'PK\x05\x06'


def _split_at_eocd(archive):
    data = archive.read_bytes()
    at = data.rfind(EOCD_SIGNATURE)
    return data[:at], list(EOCD.unpack_from(data, at))


def _declare(archive, total, comment=b''):
    """Rewrite the end record so that it declares `total` entries (and carries `comment`)."""
    head, fields = _split_at_eocd(archive)
    fields[3] = fields[4] = total
    fields[7] = len(comment)
    archive.write_bytes(head + EOCD.pack(*fields) + comment)
    return archive


def _as_zip64(archive, total, *, prefix=b'', extensible=b''):
    """Rewrite the end of a small archive the way zipfile writes a ZIP64 one, declaring `total` entries.

    `prefix` is data prepended to the whole file (the locator offset is then short by its length) and
    `extensible` is a ZIP64 extensible data sector, which separates the record from its locator.
    """
    head, fields = _split_at_eocd(archive)
    directory_size, directory_offset = fields[5], fields[6]
    record = struct.pack('<4sQ2H2L4Q', b'PK\x06\x06', 44 + len(extensible), 45, 45, 0, 0, total, total,
                         directory_size, directory_offset)
    locator = struct.pack('<4sLQL', b'PK\x06\x07', 0, len(head), 1)
    end = EOCD.pack(EOCD_SIGNATURE, 0, 0, 0xFFFF, 0xFFFF, 0xFFFFFFFF, 0xFFFFFFFF, 0)
    archive.write_bytes(prefix + head + record + extensible + locator + end)
    return archive


def _forbid_zipfile(monkeypatch):
    def constructed(*args, **kwargs):
        raise AssertionError('zipfile.ZipFile was constructed before the member cap was enforced')
    monkeypatch.setattr(offline_bundle.zipfile, 'ZipFile', constructed)


OVER_CAP = offline_bundle.MAX_MEMBERS + 2
DECLARED_OVER_CAP = {
    'plain': lambda archive: _declare(archive, OVER_CAP),
    'comment': lambda archive: _declare(archive, OVER_CAP, b'release note'),
    'longest-comment': lambda archive: _declare(archive, OVER_CAP, b'c' * 0xFFFF),
    'zip64': lambda archive: _as_zip64(archive, OVER_CAP),
    'zip64-huge': lambda archive: _as_zip64(archive, 2**40),
    'zip64-prefixed': lambda archive: _as_zip64(archive, OVER_CAP, prefix=b'stub' * 64),
    'zip64-extensible-data': lambda archive: _as_zip64(archive, OVER_CAP, extensible=b'e' * 32),
    'saturated-without-zip64': lambda archive: _declare(archive, 0xFFFF),
}


@pytest.mark.parametrize('rewrite', list(DECLARED_OVER_CAP.values()), ids=list(DECLARED_OVER_CAP))
def test_declared_entry_count_over_the_cap_is_refused_before_zipfile_opens(tmp_path, monkeypatch, rewrite):
    archive = rewrite(make_bundle(tmp_path))
    _forbid_zipfile(monkeypatch)
    with pytest.raises(OfflineBundleError, match='PT-OFFLINE: ZIP contains too many entries'):
        inspect_offline_bundle(archive)


def test_archive_with_more_real_entries_than_the_cap_is_refused_before_zipfile_opens(tmp_path, monkeypatch):
    archive = make_bundle(tmp_path, extra_members=[(f'payload/extra/{index}', b'x') for index in range(8)])
    monkeypatch.setattr(offline_bundle, 'MAX_MEMBERS', 8)  # 13 real entries against a cap of 8 + manifest
    _forbid_zipfile(monkeypatch)
    with pytest.raises(OfflineBundleError, match='PT-OFFLINE: ZIP contains too many entries'):
        inspect_offline_bundle(archive)


def test_zip64_archive_written_by_zipfile_is_refused_before_zipfile_opens(tmp_path, monkeypatch):
    # 65,537 members force zipfile itself to write the ZIP64 record and locator (synthetic empty members).
    archive = tmp_path / 'many.zip'
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_STORED) as out:
        for index in range(0x10001):
            out.writestr(f'payload/{index:05d}', b'')
    assert EOCD.unpack(archive.read_bytes()[-EOCD.size:])[4] == 0xFFFF  # the 16-bit field is saturated
    assert offline_bundle._declared_zip_entries(archive) == 0x10001
    _forbid_zipfile(monkeypatch)
    with pytest.raises(OfflineBundleError, match='PT-OFFLINE: ZIP contains too many entries'):
        inspect_offline_bundle(archive)


@pytest.mark.parametrize('zip64', [False, True], ids=['plain', 'zip64'])
def test_under_declared_entry_count_is_refused_before_open(tmp_path, monkeypatch, zip64):
    # The count is attacker-controlled: independently walk headers before ZipFile allocates ZipInfo objects.
    archive = make_bundle(tmp_path, extra_members=[(f'payload/extra/{index}', b'x') for index in range(8)])
    archive = _as_zip64(archive, 1) if zip64 else _declare(archive, 1)
    monkeypatch.setattr(offline_bundle, 'MAX_MEMBERS', 8)
    assert offline_bundle._declared_zip_entries(archive) == 1
    _forbid_zipfile(monkeypatch)
    with pytest.raises(OfflineBundleError, match='PT-OFFLINE: ZIP contains too many entries'):
        inspect_offline_bundle(archive)


HONEST = {
    'plain': lambda archive: archive,
    'comment': lambda archive: _declare(archive, 5, b'release note'),
    'longest-comment': lambda archive: _declare(archive, 5, b'c' * 0xFFFF),
    'comment-ends-in-nul': lambda archive: _declare(archive, 5, b'note\x00\x00'),
    'zip64': lambda archive: _as_zip64(archive, 5),
    'zip64-prefixed': lambda archive: _as_zip64(archive, 5, prefix=b'stub' * 64),
}


@pytest.mark.parametrize('rewrite', list(HONEST.values()), ids=list(HONEST))
def test_honest_bundle_is_never_refused_by_the_entry_count_precheck(tmp_path, monkeypatch, rewrite):
    archive = rewrite(make_bundle(tmp_path))
    monkeypatch.setattr(offline_bundle, 'MAX_MEMBERS', 4)  # four payload files + manifest is exactly the cap
    with zipfile.ZipFile(archive) as reference:
        assert offline_bundle._declared_zip_entries(archive) == len(reference.infolist()) == 5
    plan = inspect_offline_bundle(archive)
    assert plan.file_count == 4 and plan.runtime_id == RUNTIME_ID


UNREADABLE_END = {
    'empty': b'',
    'shorter-than-a-record': b'PK\x05\x06',
    'no-signature': b'not a zip archive ' * 8192,
    'record-cut-short': b'x' * 64 + b'PK\x05\x06' + b'\x00' * 10 + b'tail',
}


@pytest.mark.parametrize('content', list(UNREADABLE_END.values()), ids=list(UNREADABLE_END))
def test_unreadable_end_record_is_left_to_zipfile(tmp_path, content):
    # The pre-check never invents a refusal: what it cannot parse keeps the existing zipfile error.
    archive = tmp_path / 'broken.zip'
    archive.write_bytes(content)
    assert offline_bundle._declared_zip_entries(archive) is None
    with pytest.raises(OfflineBundleError, match=r'PT-OFFLINE: cannot read or verify offline ZIP \(BadZipFile\)'):
        inspect_offline_bundle(archive)


_SATURATED_END = EOCD.pack(EOCD_SIGNATURE, 0, 0, 0xFFFF, 0xFFFF, 0, 0, 0)
ZIP64_WITHOUT_RECORD = {
    'locator-past-the-end': struct.pack('<4sLQL', b'PK\x06\x07', 0, 2**40, 1) + _SATURATED_END,
    'locator-without-record': b'y' * 56 + struct.pack('<4sLQL', b'PK\x06\x07', 0, 0, 1) + _SATURATED_END,
}


@pytest.mark.parametrize('content', list(ZIP64_WITHOUT_RECORD.values()), ids=list(ZIP64_WITHOUT_RECORD))
def test_zip64_locator_without_a_record_is_left_to_zipfile(tmp_path, content):
    # A locator promises a ZIP64 record, so the saturated 16-bit count is not a count. How zipfile words its own
    # refusal of such a file differs between CPython patch levels; only "not the member-count refusal" is stable.
    archive = tmp_path / 'broken.zip'
    archive.write_bytes(content)
    assert offline_bundle._declared_zip_entries(archive) is None
    with pytest.raises(OfflineBundleError, match='PT-OFFLINE: ') as refused:
        inspect_offline_bundle(archive)
    assert 'too many entries' not in str(refused.value)


def test_missing_archive_has_no_declared_entry_count(tmp_path):
    assert offline_bundle._declared_zip_entries(tmp_path / 'absent.zip') is None


def test_central_directory_size_is_bounded_before_zipfile_allocation(tmp_path, monkeypatch):
    archive = make_bundle(tmp_path)
    monkeypatch.setattr(offline_bundle, 'MAX_CENTRAL_DIRECTORY_BYTES', 1)
    _forbid_zipfile(monkeypatch)
    with pytest.raises(OfflineBundleError, match='central directory exceeds size limit'):
        inspect_offline_bundle(archive)


def test_preflight_accepts_legacy_zip64_end_location(tmp_path, monkeypatch):
    archive = _as_zip64(make_bundle(tmp_path), 5, prefix=b'stub' * 64)
    original = zipfile._EndRecData
    def legacy(stream):
        end = original(stream)
        stream.seek(end[zipfile._ECD_LOCATION])
        if stream.read(4) == b'PK\x06\x06':
            end[zipfile._ECD_LOCATION] += 76
        return end
    monkeypatch.setattr(zipfile, '_EndRecData', legacy)
    offline_bundle._preflight_zip_directory(archive, None)
