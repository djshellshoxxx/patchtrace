"""Seal and independently re-read the exact batch4 packet. No product edits."""
from pathlib import Path
import hashlib
import json
import os
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch4')
PLAN = ROOT / 'docs/plans/autonomous-consolidation-20261118'
QA = ROOT / 'docs/qa'
NAME = 'semantic-disposition-batch4-20261118'
BASE = '55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
Q = chr(96)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

ledger = json.loads((PLAN / 'semantic-disposition-batch4.json').read_text())
assert ledger['comparison_source'] == BASE
assert len(ledger['branches']) == 20 and len(ledger['still_unselected_original_tips']) == 51
assert len({r['branch'] for r in ledger['branches']}) == len({r['tip'] for r in ledger['branches']}) == 20
assert not git('diff', BASE, '--', 'src', 'tests', 'tools', '.github')
assert not git('status', '--porcelain', '--', 'src', 'tests', 'tools', '.github')
validation = subprocess.run(['git', 'diff', '--check'], cwd=ROOT, text=True, capture_output=True)
(OUT / 'diff-check.log').write_text(validation.stdout + validation.stderr)
assert validation.returncode == 0
document_check = dict(comparison_source=BASE, comparison_tree=git('rev-parse', BASE+'^{tree}'),
    selected=20, previously_selected=60, original_reconciliation_tips=131, still_unselected=51,
    all_exact_tips_match_inventory=all(r['tip_matches_inventory'] for r in ledger['branches']),
    all_source_spec_test_paths_exist=all((ROOT/p).is_file() for r in ledger['branches']
        for p in r['current_paths']+r['specs']+['tests/'+t for t in r['tests']]),
    no_product_test_tool_workflow_edits=True, diff_check_exit=0,
    original_historical_bytes_verified='build_documents.py checks every historical test against git show and its frozen SHA256',
    archive_check='Every member is reopened after creation, hashed and size-checked against evidence-manifest.json.')
assert document_check['all_exact_tips_match_inventory'] and document_check['all_source_spec_test_paths_exist']
(OUT/'document-validation.json').write_text(json.dumps(document_check, indent=2)+'\n')
(OUT/'ledger.json').write_bytes((PLAN/'semantic-disposition-batch4.json').read_bytes())
(OUT/'ledger.md').write_bytes((PLAN/'semantic-disposition-batch4.md').read_bytes())
(OUT/'README.md').write_text('''# Semantic disposition batch4 — frozen evidence

Comparison source: 55f3d0742f7d4cf32357a42b8b1cc76d85875e71, tree
11a0c1598764ebd3fd8d3b540377aa52e949f88a (actual published PR316).
No product/test/tool/workflow edits or remote mutation are included.

ledger.json/md hold all 20 exact-tip decisions, patch and caller evidence,
classification criteria, source history and the 51 still-unselected original tips.
snapshot.json holds merge bases, ahead/behind, git cherry patch-equivalence,
changed paths and source blobs. The branch .patch files are merge-base-to-tip;
.current-comparison.patch files compare current source with the old tip.
symbol-comparison.json is structural evidence, not standalone semantic acceptance.
replacement-provenance.json retains actual code needles and full merge history
with parent presence. current-source/ and historical-source/ preserve exact bytes
with separate SHA256/size/blob manifests. Historical missing paths are not filled
into the current product tree.

The 42-file current gate passed 1,017 cases with zero skips/failures/errors, two
explicitly deselected native compiler RB01 cases and one expected duplicate-ZIP
warning, 27.27 seconds. No full/native/network/Windows/package/manual acceptance
is claimed. Absolute current PYTHONPATH and offscreen Qt were used; tmp_path is
normal system temporary storage, with no custom basetemp beneath Git. The known
uninjected backend-pin network fixture was not selected.

Original R2 test bytes are unchanged: historical replay 74 failed/6 passed.
historical-result-disposition.json classifies every node rather than treating all
failures as product defects. Actual lost B+B atoms and manual Decision attribution
are independently reproduced through verified persistence/view-model and actual
reopened CLI. Support remains the current per-component max-pool inventory.
The valid-entry subset of the unchanged CFG oracle passes 60 seeds; original
entry=n failures remain retained. Historical R3/R8 has 44 positives. UE-R3 has
134 positives and one changed-contract assertion excluding a retained failed-side
decomp record. Overlapping positives and branch test mappings are not additive.

The authored public-surface probe versions and all logs/XML remain unchanged:
v1 4 failed/1 passed, including three incorrect RunReport setup assertions;
v2 3 failed/2 passed after correcting setup, but with an overly broad ambiguous
attribution assertion; v3 4 failed/1 passed with the actual Decision-line check.
Complete current CLI JSON and desktop detail are retained. The manufactured cap
input proves persistence/presentation reachability, not native corpus incidence.
Root assigned a separate mirror-safe R2 repair to another owner; no repair credit
is granted here. The historical source symlinks only routed child Python imports
to the frozen current source during replay; symlinks and their targets are not
followed when archiving.

proof-preflight.md and document-preflight.md preserve routing/document authoring
corrections separately from all unchanged product-test failures. No test receipt
was relabeled green. Eighty of 131 original reconciliation tips now have selected
scopes; 51 remain unselected, and broad branch/research/native residue stays open.
Known directory/UI/named-source/highlighter/F8 continuation fixes are separately
attributed, not new batch4 findings or repairs at this baseline.

evidence-manifest.json records every other member's size and SHA256. The seal
script reopens and verifies each ZIP member. Cache/bytecode, symlinks and ephemeral
project databases are excluded. Independent docs review/integration is root-owned.
''')

excluded = {'evidence-manifest.json', 'seal-result.json', 'seal.log'}
files = []
for parent, dirs, names in os.walk(OUT, followlinks=False):
    dirs[:] = sorted(d for d in dirs if d not in {'__pycache__', '.pytest_cache'} and not (Path(parent)/d).is_symlink())
    for name in sorted(names):
        path = Path(parent)/name
        if name in excluded or name.endswith('.pyc') or path.is_symlink():
            continue
        assert path.is_file()
        files.append(path)
files.sort()
manifest = {str(p.relative_to(OUT)): dict(bytes=p.stat().st_size, sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files}
(OUT/'evidence-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
archive = QA/(NAME+'.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for path in files+[OUT/'evidence-manifest.json']:
        bundle.write(path, str(path.relative_to(OUT)))
with zipfile.ZipFile(archive) as bundle:
    assert set(bundle.namelist()) == set(manifest)|{'evidence-manifest.json'}
    assert bundle.testzip() is None
    for name, entry in manifest.items():
        data = bundle.read(name)
        assert len(data) == entry['bytes'] and hashlib.sha256(data).hexdigest() == entry['sha256'], name
metadata = dict(source=BASE, archive=str(archive.relative_to(ROOT)), members=len(manifest)+1,
    bytes=archive.stat().st_size, sha256=hashlib.sha256(archive.read_bytes()).hexdigest(), verified_members=len(manifest)+1)
(OUT/'seal-result.json').write_text(json.dumps(metadata, indent=2)+'\n')

receipt = f'''# Semantic disposition batch4: source-pinned QA

This docs-only checkpoint inspects 20 exact original source-bearing tips against
actual published PR316 **{Q}{BASE}{Q}**, tree
{Q}11a0c1598764ebd3fd8d3b540377aa52e949f88a{Q}. The [scoped ledger](../plans/autonomous-consolidation-20261118/semantic-disposition-batch4.md)
and [complete machine-readable inventory](../plans/autonomous-consolidation-20261118/semantic-disposition-batch4.json)
retain exact ancestry, patch equivalence, current replacements/callers, test maps,
remaining tips and limitations. No product source was changed.

## Sealed archive

[Evidence archive]({NAME}.zip): **{metadata['members']} members**, **{metadata['bytes']:,} bytes**,
SHA-256 **{Q}{metadata['sha256']}{Q}**. Every member was reopened, size-checked and
SHA256-checked; evidence-manifest.json lists every other member. The archive holds
complete source patches, code/AST and ancestral proofs, exact current/historical
source/spec/test bytes, original failure controls, command JSON, logs and XML.
Symlinks, caches, bytecode and ephemeral project databases are excluded.

## Actual pinned executions

| Invocation | Passed | Failed | Skipped / errors | Summary time | JUnit time |
|---|---:|---:|---|---:|---:|
| Current shared 42-file gate | 1,017 | 0 | 0 / 0 | 27.27 s | 27.264 s |
| Original unchanged R3/R8 tests | 44 | 0 | 0 / 0 | 1.25 s | 1.256 s |
| Original unchanged UE-R3 tests | 134 | 1 | 0 / 0 | 5.61 s | 5.615 s |
| Original unchanged R2 tests | 6 | 74 | 0 / 0 | 1.76 s | 1.679 s |
| Same historical CFG oracle, valid entries only | 60 | 0 | 0 / 0 | 0.28 s | 0.191 s |
| Authored public-surface v1 | 1 | 4 | 0 / 0 | 0.43 s | 0.361 s |
| Authored public-surface v2 | 2 | 3 | 0 / 0 | 0.56 s | 0.492 s |
| Authored public-surface v3 | 1 | 4 | 0 / 0 | 0.53 s | 0.462 s |

The current gate explicitly deselects two compiler-backed RB01 nodes:
{Q}test_the_engine_image_of_a_mutant_module_exports_every_candidate{Q} and
{Q}test_the_path_nuisance_pair_labels_every_function_the_same_function{Q}.
They are unexecuted, not passing or skipped. The warning is the intentional
duplicate ZIP member fixture. The known uninjected backend-pin network fixture
was not selected. Commands use {Q}/workspace/scratch/3a6632a6e5ff/venv/bin/python{Q},
absolute PYTHONPATH to this worktree's src/tests and offscreen Qt. System temporary
fixtures were used; no custom basetemp under Git. Shared tests, repeated branch
mappings and historical neighbors are not added into a success/completion score.

## Confirmed R2 behavior and preserved contrary evidence

The original fusion file is retained from
{Q}b3ceb8b30d7a83da5e22c231c3b8c28179246816{Q}, 11,292 bytes, SHA-256
{Q}b545602a001c206f608800c034412023abfe79a79d84d8a59e34b6b5b22cab68{Q}.
The other original hashes are in historical-tests.json. All 74 failures are
classified by exact node in historical-result-disposition.json:

| Category | Failed cases | Meaning |
|---|---:|---|
| Lost B+B cross-class atom witness | 1 | Confirmed at the actual 64-atom cap |
| Manual split/merged/ambiguous Decision attribution | 3 | Confirmed in actual service/persistence/CLI/desktop detail |
| Support indexes as corroborating witness | 2 | Conflicts with current SPEC-31/05 §1.1 per-component max-pool inventory |
| Custom cap=2 | 1 | Distinct tiny-limit boundary; current retains three mandatory atoms |
| Old leftover representation | 2 | Superseded by explicit A-29 step/native/exclusion contract |
| Malformed direct Correspondence ID/RVA | 3 | Internal guard residue; no admitted production route established |
| Invalid CFG entry=n | 60 | Actual ingest supplies 0<=entry<n; valid-entry oracle positives are separate |
| Old matching-policy token | 2 | Current registry/config policy is different; no blanket cache-policy rollback |

The external v3 probe SHA-256 is
{Q}37fa19d6c288b1892d9567ddeee7cae35d74c721a73a01247629db6e373b30c4{Q}.
Manual cases use actual ProjectService.correct_match, run_unified, strict result
verification and desktop read-model detail, then close/reopen through CLI unified
explain --json. CLI exits zero and agrees with the desktop text: split/merged
falsely describe independent B evidence despite empty support; ambiguous omits
analyst attribution on the Decision line. Full JSON/detail is retained. The cap
case persists manufactured registered evidence, verifies it and displays the
stored row; it proves the publication/presentation path, not native incidence.
The below-cap witness positive remains green.

Probe authoring chronology is retained: v1's three manual cases initially failed
an incorrect RunReport setup assertion; v2 corrected it but accepted ambiguous
attribution anywhere in the detail; v3 checks the actual Decision line. All three
probe versions and original receipts remain unchanged. No product change caused
these result differences. The complete historical UE-R3 replay has one separate
changed-contract mismatch: current source retains the failed newer-side decomp
status that the old assertion omits, with 134 historical positives intact.

Root assigned a separate narrow R2 witness/manual-attribution repair to
report_evidence_review from continuation 3faf436a. Current Support semantics,
mirror orbits, strongest opposition and cache/channel/proof versions must survive.
No repair acceptance is granted at this frozen source.

## Validation and remaining scope

All exact tips match the original inventory; document/source/spec/test paths,
historical byte hashes, source pins and XML counts validate. git diff --check
passes, and src/tests/tools/.github have no diff from the frozen source. Read-only
proof-needle and document-builder preflight corrections are separately retained;
they are not product failures or fixes. No broad suite was rerun for docs only.

Fifteen focal scopes are retained, one R7 prototype is retained, one older adapter
relaxation is superseded by stricter admission, and Tier W saved-plan/CLI and R1
research orchestration remain incomplete. Known directory/UI/named-source/
highlighter/F8 repairs belong to later continuation and are not new findings or
baseline fixes. Root reported unpublished source 5bbb9256 during sealing; its
gate/source results are not credited here.

No fresh remote/hosted observation, full historical/integrated suite, network or
live acquisition/provider, native engine, target execution, compiler corpus,
Windows, frozen package or manual/screen-reader acceptance ran. Eighty of 131
original reconciliation tips now have selected-scope entries; 51 remain
unselected, with broader research/native/package residue open. No feature
percentage, whole-branch closure, merge or release follows. Independent docs
review and selective integration remain root-owned.
'''
(QA/(NAME+'.md')).write_text(receipt)
print(json.dumps(metadata, indent=2))
