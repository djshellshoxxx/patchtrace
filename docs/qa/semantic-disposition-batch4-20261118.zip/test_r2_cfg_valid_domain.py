"""Separate current-caller-domain check; the original historical invalid-entry tests remain unchanged/red."""
from __future__ import annotations
import importlib.util
import random
from pathlib import Path
import pytest
from patchtrace.unified.ir import cfg

path = Path(__file__).parent / 'historical/r2/tests/test_r2_cfg_performance.py'
spec = importlib.util.spec_from_file_location('frozen_r2_cfg_oracle', path)
original = importlib.util.module_from_spec(spec)
spec.loader.exec_module(original)

@pytest.mark.parametrize('seed', range(60))
def test_current_ingest_entry_domain_agrees_with_original_vertex_removal_oracle(seed):
    rng = random.Random(seed)
    n = rng.randrange(1, 35)
    density = rng.choice((0.02, 0.12, 0.5))
    succ = [[v for v in range(n) if rng.random() < density] for _ in range(n)]
    if seed % 3 == 0:
        for u in range(n - 1):
            succ[u].append(u + 1)
    if seed % 4 == 0:
        for row in succ:
            row.extend(row[:2])
    for entry in range(n):
        assert cfg.count_back_edges(n, succ, entry) == original._oracle(succ, entry)
