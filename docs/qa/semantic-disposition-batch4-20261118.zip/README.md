# Semantic disposition batch4 — frozen evidence

Comparison source: 55f3d0742f7d4cf32357a42b8b1cc76d85875e71, tree
11a0c1598764ebd3fd8d3b540377aa52e949f88a (actual published PR316).
No product/test/tool/workflow edits or remote mutation are included.

ledger.json/md hold all 20 exact-tip decisions, patch and caller evidence,
classification criteria, source history and the 51 still-unselected original tips.
snapshot.json holds merge bases, ahead/behind, git cherry patch-equivalence,
changed paths and source blobs. The branch .patch files are merge-base-to-tip;
.current-comparison.patch files compare current source with the old tip.
symbol-comparison.json is structural evidence, not standalone semantic acceptance.
replacement-provenance.json retains actual code needles and full merge history
with parent presence. current-source/ and historical-source/ preserve exact bytes
with separate SHA256/size/blob manifests. Historical missing paths are not filled
into the current product tree.

The 42-file current gate passed 1,017 cases with zero skips/failures/errors, two
explicitly deselected native compiler RB01 cases and one expected duplicate-ZIP
warning, 27.27 seconds. No full/native/network/Windows/package/manual acceptance
is claimed. Absolute current PYTHONPATH and offscreen Qt were used; tmp_path is
normal system temporary storage, with no custom basetemp beneath Git. The known
uninjected backend-pin network fixture was not selected.

Original R2 test bytes are unchanged: historical replay 74 failed/6 passed.
historical-result-disposition.json classifies every node rather than treating all
failures as product defects. Actual lost B+B atoms and manual Decision attribution
are independently reproduced through verified persistence/view-model and actual
reopened CLI. Support remains the current per-component max-pool inventory.
The valid-entry subset of the unchanged CFG oracle passes 60 seeds; original
entry=n failures remain retained. Historical R3/R8 has 44 positives. UE-R3 has
134 positives and one changed-contract assertion excluding a retained failed-side
decomp record. Overlapping positives and branch test mappings are not additive.

The authored public-surface probe versions and all logs/XML remain unchanged:
v1 4 failed/1 passed, including three incorrect RunReport setup assertions;
v2 3 failed/2 passed after correcting setup, but with an overly broad ambiguous
attribution assertion; v3 4 failed/1 passed with the actual Decision-line check.
Complete current CLI JSON and desktop detail are retained. The manufactured cap
input proves persistence/presentation reachability, not native corpus incidence.
Root assigned a separate mirror-safe R2 repair to another owner; no repair credit
is granted here. The historical source symlinks only routed child Python imports
to the frozen current source during replay; symlinks and their targets are not
followed when archiving.

proof-preflight.md and document-preflight.md preserve routing/document authoring
corrections separately from all unchanged product-test failures. No test receipt
was relabeled green. Eighty of 131 original reconciliation tips now have selected
scopes; 51 remain unselected, and broad branch/research/native residue stays open.
Known directory/UI/named-source/highlighter/F8 continuation fixes are separately
attributed, not new batch4 findings or repairs at this baseline.

evidence-manifest.json records every other member's size and SHA256. The seal
script reopens and verifies each ZIP member. Cache/bytecode, symlinks and ephemeral
project databases are excluded. Independent docs review/integration is root-owned.
