"""Author the 20 inspected focal dispositions; no product or test source edits."""
import json
from pathlib import Path

OUT = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch4')
ROWS = []
UE = 'docs/specs/unified-engine/'

def add(branch, classification, focus, historical, current, callers, paths, tests, specs, recommendation, residue):
    ROWS.append(dict(branch=branch, classification=classification, focus=focus,
                     historical_behavior=historical, current_behavior=current,
                     caller_evidence=callers, current_paths=paths, tests=tests,
                     specs=specs, recommendation=recommendation, residue=residue))

add('chatgpt/semantic-analysis-r3-20261030', 'retained_focal_scope',
    'IR cosmetic proof requires EH evidence and rejects register changes',
    'The two production changes prevent pseudo-code equality from proving an IR-backed cosmetic change when unwind evidence is unavailable, and prevent changed registers from being hidden by equal pseudo code. The non-IR S0 fallback remains weaker and explicitly decompiler-relative; COS-PSEUDO moves to version 2.',
    'verdict.judge requires EH equal/absent when ev.ir exists and only rejects EH differs in S0. The current PROOF_BLOCKERS includes register-only, replacing the older separate pseudo blocker. Registry retains COS-PSEUDO/2. The complete historical verdict test bytes are identical to current and pass in the separate R3/R8 replay.',
    'FactsContext collects IR and S0 evidence and invokes verdict.judge; the result feeds persisted ChangeFacts and Unified read-model materiality. This proof does not turn absence of IR into evidence of unchanged code.',
    ['src/patchtrace/unified/facts/verdict.py', 'src/patchtrace/unified/facts/channels.py', 'src/patchtrace/unified/registry.py'],
    ['test_unified_verdict_ir.py'], [UE+'05-fusion-and-noise.md'],
    'No selective product port indicated for these guards; preserve the stronger shared blocker and current proof registry.',
    'The branch also contains semantic-method, experiment and R4 handoff documents. Their native corpus precision, solver feasibility and end-to-end CVE locality claims are not accepted by these synthetic tests.')

add('chatgpt/ue-r3-retain-decompiled-20261016', 'retained_focal_scope',
    'Persist and validate decompiled text for the paired code view',
    'The older compute.retain_decompiled_text helper writes successful decompilation records into a result part; pair_text validates the part identity and the store rejects duplicate/foreign records.',
    'Responsibility moved to pipeline._decompile and _store_decomp. Every validated result status is retained, including an explicit failed side, with bounded publication and restoration of the previous manifest when publication fails. RowCodeSource caches by part sha256/bytes/records; store._Deep checks ownership, duplicates, strict JSON, status/text consistency and text bounds. Removing the old helper name is not removal of the behavior.',
    'pipeline invokes _store_decomp after the decompiler result, and RowCodeSource reads the verified decomp part for the desktop paired-text channel. The unchanged historical three-file replay is 134 passed/1 failed: its one-sided assertion expects no newer record, while current source deliberately retains newer=(failed,None). Current-source equivalents pass.',
    ['src/patchtrace/unified/pipeline.py', 'src/patchtrace/unified/pair_text.py', 'src/patchtrace/unified/store.py', 'src/patchtrace/unified/read_model.py'],
    ['test_unified_pair_text.py', 'test_unified_wire_refacts.py', 'test_unified_store.py'],
    [UE+'02-data-model.md', UE+'07-ui-and-cli.md'],
    'Keep current pipeline/status-preserving implementation. Do not restore the older omission of failed-side status or replace the recoverable result-generation store.',
    'No native decompiler run, frozen package code view or manual high-DPI acceptance was performed. The old failing assertion is preserved as a changed-contract mismatch, not silently corrected.')

add('claude/funny-feynman-d2m0b5', 'retained_focal_scope',
    'Conservative DATA-MAP consensus, alignment and IR-only leftovers',
    'The 20-source-path delta adds stationary-claim blocking, symmetric consensus for explained swaps, at least two voters including the function floor, leave-one-out consensus, cached blocking, conservative instruction alignment and key/manual/IR-only integration fixes.',
    'Fourteen of the 20 changed production/tool files are byte-identical. datamap retains stationary blocking and cached vote checks; align retains the bounded conservative mapping. The six different files include newer mirror-cap, pipeline and source-identity improvements rather than absence of the inspected algorithms. Current leftovers follow the later A-29 fixed step and exclusions.',
    'FactsContext builds the DATA-MAP explanation before classifying mapped operands; IR-backed alignment is also consumed by the paired code view. compute.run_ladder and sources.ladder_output feed IR-only rows through the normal arbiter/persistence path.',
    ['src/patchtrace/unified/facts/datamap.py', 'src/patchtrace/unified/facts/align.py', 'src/patchtrace/unified/compute.py', 'src/patchtrace/unified/sources/ladder.py'],
    ['test_unified_followup_datamap.py', 'test_unified_fct_datamap.py', 'test_unified_followup_align.py', 'test_unified_followup_ironly.py', 'test_unified_followup_orientation.py', 'test_unified_followup_keys.py', 'test_unified_ir_pe_tables.py'],
    [UE+'04-matching-pipeline.md', UE+'05-fusion-and-noise.md'],
    'No wholesale merge or selective replacement of these focal implementations. Preserve newer identity and mirror-cap changes.',
    'The DATA-MAP module explicitly retains limitations around multiple-function retargets and unreferenced swaps. These controls establish implementation behavior, not real native accuracy or broad completion of the 20-path checkpoint.')

add('claude/gallant-knuth-8gxuzd', 'retained_focal_scope',
    'Manual/IR cache identity, timeout partials and PE scope evidence',
    'Manual corrections must affect the result key even when the manual source is deselected; IR identity includes the key rather than content digest alone. Timeout/P19 partial results cannot satisfy a reusable result cache. PE scope-table parsing distinguishes GS-cookie metadata from a scope count.',
    'Six of nine changed source files are byte-identical. compute always derives manual_digest_of, keys carries ir_older_key/ir_newer_key, and store.is_timeout_partial excludes timeout partials. The PE parser fix is retained. Current compute/pipeline additionally carry newer budget, Diaphora and digest behavior.',
    'compute builds config/result identity before cache lookup and uses the verified IR manifest keys. pipeline checks a loaded result for timeout-partial authority before reuse. PE table metadata feeds the IR unwind channel and the cosmetic guard.',
    ['src/patchtrace/unified/compute.py', 'src/patchtrace/unified/keys.py', 'src/patchtrace/unified/store.py', 'src/patchtrace/unified/ir/pe_tables.py'],
    ['test_unified_followup_keys.py', 'test_unified_ir_pe_tables.py', 'test_unified_store.py'],
    [UE+'02-data-model.md', UE+'03-extraction.md', UE+'05-fusion-and-noise.md'],
    'No port required for the inspected identity and cache guards; retain the newer composite configuration.',
    'This does not accept native PE corpus coverage, large cache behavior or unrelated UI/packaging work on the historical checkpoint.')

add('codex/r2-unified-matching-research-20261030', 'confirmed_selective_omission',
    'Lost B+B witness atoms and manual group Decision attribution',
    'The branch added cap witness retention, manual group explanations, ladder boundary guards, linear CFG processing and a separate matching-policy cache token, plus six research runners and historical regressions.',
    'Current cap reservation preserves per-component support and strongest contest/mirror orbits, but can drop the E-DATA atom which made a B+B decision valid before the 64-atom cut. Manual split/merged rows with support=() receive a false automatic B explanation; ambiguous manual groups lose analyst attribution on the Decision line. Current Support is intentionally a per-component max-pool inventory, not the witness classes. Later A-29 leftovers and arbiter=2 policy supersede other historical assertions.',
    'The authored cap control persists manufactured registered atoms through ResultWriter, strict verify and the desktop read model. The manual controls use ProjectService.correct_match, actual run_unified, store verification, row_detail and reopened CLI unified explain --json; CLI and desktop agree on the incorrect Decision line. The CFG invalid-entry controls call below the actual ingest boundary, which constructs entry within range(n).',
    ['src/patchtrace/unified/fusion/arbiter.py', 'src/patchtrace/unified/read_text.py', 'src/patchtrace/unified/read_model.py', 'src/patchtrace/unified/compute.py', 'src/patchtrace/unified/sources/ladder.py', 'src/patchtrace/unified/ir/cfg.py', 'src/patchtrace/unified/ir/ingest.py', 'src/patchtrace/unified/registry.py', 'src/patchtrace/unified/limits.py'],
    ['test_unified_fusion.py', 'test_unified_fusion_mirror.py', 'test_unified_fusion_properties.py', 'test_unified_irx_cfg.py', 'test_unified_ir_graph.py', 'test_unified_followup_ironly.py'],
    [UE+'02-data-model.md', UE+'04-matching-pipeline.md', UE+'05-fusion-and-noise.md', UE+'07-ui-and-cli.md'],
    'Root assigned report_evidence_review a separate narrow mirror-safe witness and manual-attribution repair from continuation 3faf436a. Preserve Support max-pooling, current mirror orbits and cache/channel/proof versions; use an arbiter-only policy increment if the cap behavior changes. No historical whole-branch port.',
    'All 74 historical failures remain classified individually in the packet: four directly assert confirmed omissions, two support-only expectations conflict with current contract, one custom cap=2 boundary remains separate, two leftover representations conflict with A-29, three direct malformed Correspondence controls lack a proven admitted production route, 60 invalid CFG-entry cases lie outside the validated caller domain, and two old cache-token expectations are superseded. Six historical runners/eight test files are missing; native graph/decompiler experiments are unqualified. The persisted cap probe proves manufactured-input behavior, not native corpus incidence.')

add('research/r8-deep-uncertainty-20261030', 'retained_focal_scope',
    'Type-sensitive C literals and opaque numeral collision resistance',
    'Canonical literals retain suffix/radix/type distinctions, guard floats and octal forms, and preserve full SHA-256 plus length for hostile numerals that cannot be parsed. Canonicalizer version moves to 2; a compile-only ICF probe was added.',
    'The opaque-number implementation has the same AST. Current numeric canonicalization retains typed literals and adds signed-bound/radix checks for signed L/LL overflow. canon=2 remains registered. The complete historical literal tests and R3 verdict tests pass together in a separate unchanged 44-case replay.',
    'pseudo.normalize feeds C5/C6 channels; the canonicalizer version participates in registry/config identity. The ICF probe is a research harness and is absent from the current tree; no product caller depends on it.',
    ['src/patchtrace/unified/facts/pseudo.py', 'src/patchtrace/unified/facts/channels.py', 'src/patchtrace/unified/registry.py'],
    ['test_r8_literal_types.py', 'test_unified_verdict_ir.py'], [UE+'05-fusion-and-noise.md'],
    'Retain the stricter current canonicalizer; no product port indicated. Reconsider the optional ICF probe only as a separately reviewed research runner.',
    'Unknown numeral semantics stay opaque; no language-complete C evaluator or semantic-equivalence proof is claimed. ICF/compiler/native uncertainty experiments were not executed.')

add('codex/tier-w-fetch-20261015', 'partially_retained_incomplete_workflow',
    'Bounded exact-consent fetch library retained; saved plan/CLI orchestration absent',
    'The older three-file patch adds FetchInput/Exclusion/Item/Plan contracts, strict plan loading, canonical saved plans and reconfirmed binary/PDB execution. It adds 697 source lines but no new tests.',
    'Current plan_binaries, consent_for, disk preflight, fetch_binary and fetch_pdb independently retain exact-URL consent, quarantine/x64/hash validation and CodeView/MSF/GUID/age verification. SymbolTransport retains throttle/size/redirect checks and a chained ledger. The historical saved-plan contracts and high-level save/read/execute orchestration are absent. No tier_w.__main__ or tier_w.cli exists.',
    'The module index explicitly labels this a library API and assigns fetch-plan/fetch adapters to LBL-25. run_local.cli_available detects the missing CLI and run_pipeline returns BLOCKED before stage execution. Authored fake-opener library and blocked/dry-run orchestration controls pass; no live acquisition was attempted.',
    ['tools/calibration/tier_w/contracts.py', 'tools/calibration/tier_w/fetch.py', 'tools/calibration/tier_w/transport.py', 'tools/calibration/tier_w/run_local.py', 'tools/calibration/tier_w/__init__.py'],
    ['test_tier_w_fetch.py', 'test_tier_w_run_local.py'],
    ['docs/specs/tier-w-local-corpus.md', 'docs/specs/program-e/LBL-integration-plan.md'],
    'Keep the bounded fetch library; record the exact saved-plan and developer CLI workflow as incomplete. Any recovery needs a current contract/caller design and tests, not a direct port of incompatible old imports.',
    'No product consent bypass is demonstrated. Microsoft acquisition, actual PDB identity, Windows tools, local-only corpus privacy and LBL-25 end-to-end qualification remain open.')

add('fix/remediation-a58defa8-139db0', 'retained_focal_scope',
    'Score against bounded accepted function alternatives',
    'Expected positives may supply an accept list; scoring finds the best rank among the primary function and accepted alternatives rather than penalizing an equivalent representative.',
    'cases validation retains a list of at most eight names with a 200-character name bound and rejects accept for no_change. scoring constructs primary plus alternatives and chooses the best hit rank. The current expression is refactored but implements the inspected behavior.',
    'The qualification runner loads cases through the validator before score_case; invalid or unverified truth does not gain accuracy credit merely from an alternate-name match. Current scoring/case tests exercise multiple aliases and invalid contracts.',
    ['tools/research_qualification/cases.py', 'tools/research_qualification/scoring.py'],
    ['test_research_qualification_cases.py', 'test_research_qualification_scoring.py'],
    ['docs/specs/known-answer-corpus.md', 'docs/specs/multi-engine-evidence-calibration.md'],
    'No selective port needed; retain bounded alternative names and current truth-admission rules.',
    'These are scoring mechanics, not a new precision/recall result. Real labeled truth, lineage independence and engine coverage remain separate gates.')

add('fix/remediation-b1ab7332-a8fac4', 'superseded_by_stricter_current',
    'Research adapters now require strict code and native identity',
    'Despite its commit wording, the Ghidriff patch permits non-code records when their ratio is below 1.0. The Rizin patch relaxes nested-name and top-level fallback parsing.',
    'Current Ghidriff admission is explicitly if not fresh or code not in diff_type: continue. Native identity/source bounds are checked before records contribute. Current Rizin native JSON requires a bare array and validates names, addresses and both image identities; legacy flat/text input is explicitly unverified. Reinstating the old conditions would weaken current admission.',
    'The adapters feed research qualification observations, which are scored only under admitted truth and source identity. Current dedicated Ghidriff/Rizin identity regressions exercise foreign/stale/malformed and valid native records alongside general adapter tests.',
    ['tools/research_qualification/adapters/ghidriff.py', 'tools/research_qualification/adapters/rizin.py'],
    ['test_research_qualification_adapters.py', 'test_research_qualification_ghidriff_identity.py', 'test_research_qualification_rizin_identity.py'],
    ['docs/specs/multi-engine-evidence-calibration.md', UE+'06-adapters.md'],
    'Do not port the historical relaxation. Retain the stricter current source-code and identity checks.',
    'The pre-existing adapter identity repairs are already tracked, not new batch4 findings. No native Ghidriff/Rizin invocation or broad compatibility acceptance ran.')

add('consolidate/research-r7-20261104', 'retained_research_prototype',
    'Bounded offline slicing and guard-to-sink candidate motifs',
    'Three pure research tools implement bounded slicing, candidate guard-to-sink pattern assessment and a small benchmark driver.',
    'All three tool files are byte-identical to the tip. MAX_INPUT_OPS=4096 and budget/cancel/unknown outcomes remain. Scope facts are caller assertions; pattern assessment keeps control-dependence-not-verified and returns candidate/not-observed/inconclusive without proving dominance or a vulnerability.',
    'The current module index explicitly identifies historical R7 research recovery. The callers are the research bench and tests; no production extractor or analyst-facing pipeline calls the prototype.',
    ['tools/research/r7/slicer.py', 'tools/research/r7/patterns.py', 'tools/research/r7/bench.py'],
    ['test_r7_patterns.py', 'test_r7_slicing.py'],
    ['docs/research/advanced-analysis-r7/02-acceptance-and-roadmap.md', UE+'13-remaining-work-plan.md'],
    'No port needed for the retained prototype. Any production bridge needs a distinct admitted input/uncertainty design and acceptance plan.',
    'This is not completed CVE locality, program slicing, dataflow, CWE detection or native precision acceptance. The bench/native target journey was not run.')

add('claude/affectionate-galileo-bqd3tw', 'retained_focal_scope',
    'RB01 source-path provenance and conservative ground-truth labels',
    'Normalize raw/resolved/verbatim Windows source paths without accepting a filesystem root, carry BuildResult.source_dirs, reject same-source pairs without a project function, export synthetic candidates and distinguish unpaired observations.',
    'Four of seven source files are byte-identical, including path normalization, evaluator, gate and template changes. Current build/labeler/live harness retain the focal changes and add later ambiguity and provenance handling.',
    'Tier R BuildResult.source_dirs travels into factory/session identity and labeler source resolution. Gate evaluators report unpaired samples separately from hits/leaks. The current authored gate/RB01 controls pass; two compiler-backed RB01 cases are explicitly deselected.',
    ['tools/calibration/tier_r/debuginfo.py', 'tools/calibration/tier_r/build.py', 'tools/calibration/tier_r/labeler.py', 'tools/unified/evaluators.py', 'tools/unified/gates_u.py', 'tools/unified/mutations/templates.py'],
    ['test_unified_gate_eval.py', 'test_unified_rb01_harness.py'],
    ['docs/specs/calibration-corpus-and-model.md', UE+'08-evaluation.md'],
    'No selective port indicated; preserve later ambiguity checks and exact provenance.',
    'The synthetic module export and path-nuisance pair compiler cases were not run. No fresh compiler build, true native source labeling or published gate result is claimed.')

add('claude/instance-c-research', 'retained_focal_scope',
    'Fail closed on missing benchmark ticks and incomplete parity output',
    'A benchmark must fail when ladder tick counts are missing, and md-dump must not report success merely because an interrupted or output-limited native process exits zero.',
    'parity.py is byte-identical. Its exit is successful only when the process exit is zero and there is no reason. Current bench validation is stricter: ticks must be a real nonnegative int, excluding bool; missing/invalid ticks fail.',
    'The benchmark gate reads the ladder counters before emitting a result; the parity CLI formats the process reason and returns a nonzero code for timeout, cancellation or output-limit. The selected tests use authored process results.',
    ['tools/unified/bench.py', 'tools/unified/parity.py'],
    ['test_unified_bench.py', 'test_unified_parity.py'], [UE+'08-evaluation.md'],
    'No port needed; retain current stricter tick validation.',
    'No actual md-dump/BinDiff/native throughput run or Windows G-U5 performance acceptance. A passing fake-result control does not qualify the engine boundary.')

add('repair/gt01-consolidated-native-evidence-20261030', 'retained_focal_scope',
    'Persist completed raw runs before unified analysis and retain failure detail',
    'The live harness must apply a completed engine run before requesting Unified analysis, reject unintended identical shortcuts, and preserve bounded native diagnostics rather than emit opaque failures.',
    'live_pairs.analyse_pair retains service.apply_analysis before unified and bounded redacted failure detail plus a failures sidecar. Current code adds per-pair extraction work and cache-bypass improvements. The older text is therefore not byte-identical, but the ordered operation survives.',
    'The harness creates a project, imports pair inputs, applies the engine result, then calls the Unified path. A failing orientation records its bounded reason without erasing successful raw results; authored fake-engine tests exercise the ordering.',
    ['tools/unified/live_pairs.py'],
    ['test_unified_live_pairs.py', 'test_unified_live_pairs_r1.py', 'test_unified_live_native_failure_details.py'],
    [UE+'08-evaluation.md'],
    'No selective port needed for these harness repairs; retain newer work-directory and cache handling.',
    'The branch name says native evidence; this execution is synthetic only. Historical native logs do not establish the frozen current source or a complete GT-01 acceptance run.')

add('repair/gt01-native-identical-controls-20261030', 'retained_focal_scope',
    'Explicit native identical-image controls without weakening ordinary shortcut',
    'Introduce a strict boolean force_identical_diff option, use --force-diff for the explicit A/A harness, disable cache refresh, and keep distinct older/newer private basenames so the native diff runs.',
    'BackendConfig retains force_identical_diff=False and strict validation. The native harness sets force/no_cache/refresh=False and the backend appends --force-diff only for the explicit option. Ordinary product identical inputs still take the existing shortcut.',
    'live_pairs constructs the special BackendConfig for its authored control; backend command construction propagates the flag while private input preparation preserves the original checksums.',
    ['src/patchtrace/backend.py', 'tools/unified/live_pairs.py'],
    ['test_unified_live_force_identical.py', 'test_unified_live_pairs.py'],
    [UE+'08-evaluation.md', UE+'03-extraction.md'],
    'No port required; keep the special harness option distinct from the product default.',
    'Current tests inspect fake process calls and byte identity. They are not a successful real engine A/A run or proof that the native engine honors the flag.')

add('repair/gt01-unified-live-gates-20261030', 'retained_focal_scope',
    'Live gate apply-before-unified ordering and Linux Qt dependency',
    'Repair raw-run persistence ordering and native failure details in live_pairs, and install libegl1 before the Linux Qt-related gate.',
    'The current live harness keeps the ordering and bounded sidecar behavior. The workflow still includes libegl1. Newer harness setup/failure-isolation changes are retained.',
    'The checked workflow invokes the live harness; local workflow contract tests assert the required package and ordering. No new hosted run was queried or started in this batch.',
    ['tools/unified/live_pairs.py', '.github/workflows/unified-live-gates.yml'],
    ['test_unified_live_pairs.py', 'test_unified_live_native_failure_details.py', 'test_unified_live_workflow.py'],
    [UE+'08-evaluation.md'],
    'No selective port indicated; keep current workflow/harness implementation.',
    'Source/workflow inspection and synthetic tests do not qualify hosted jobs, EGL rendering on another platform or native live gates.')

add('codex/gt01-extraction-recovery-20261030', 'retained_focal_scope',
    'Per-pair extraction roots and actionable bounded backend failure detail',
    'Prevent CaseSide collisions across orientation runs by allocating per-project extraction work; isolate pair failures and include useful bounded process/output-path diagnostic markers.',
    'Current live_pairs uses service.root/extraction-work, commits completed raw runs and collects independent failures. Backend output-limit, unsafe-output-path and output-check-failed reasons remain, with current phrasing; failure sidecar diagnostics are capped at 65,536 bytes and redacted.',
    'Each harness orientation creates its own project/service and extraction directory. Backend errors are carried through analyse_pair into aggregate rows and the sidecar; the fake native-failure/R1 tests exercise this path.',
    ['src/patchtrace/backend.py', 'tools/unified/live_pairs.py'],
    ['test_unified_live_pairs_r1.py', 'test_unified_live_native_failure_details.py', 'test_unified_live_pairs.py'],
    [UE+'03-extraction.md', UE+'08-evaluation.md'],
    'No selective port needed for the inspected recovery behavior.',
    'No actual Ghidra extraction/cache-failure recovery, native child cleanup or Windows output path qualification. Broader process containment is outside this focal review.')

add('codex/r1-ground-truth-research-20261030', 'partially_retained_research_workflow',
    'Build/session truth provenance retained; multi-profile research runners absent',
    'Add immutable hashed build receipts, bind Session.side to complete build/source provenance, leave ambiguous unchanged labels unchecked, repair live-pair handling, and add four multi-profile research orchestration modules.',
    'persist_build_record retains per-build receipts, idempotent content verification and compatibility view. Session.side identity includes recipe/source/source_dirs/root/debug hash. Ambiguous truth remains unchecked. The research_audit/build/observers/pilot modules are absent from current source. The historical build runner records blocked combinations and completed matrix receipts independently; these are not supplied by the retained primitives alone.',
    'Current Tier R factory uses the retained build record and expanded session key before assigning labels. Dedicated R1 receipt/session/label tests are hermetic. The missing modules were separate developer research runners, not a production UI or CLI admission path.',
    ['tools/calibration/tier_r/build.py', 'tools/calibration/tier_r/factory.py', 'tools/calibration/tier_r/labeler.py', 'tools/unified/live_pairs.py'],
    ['test_tier_r_build_receipts_r1.py', 'test_tier_r_session_provenance_r1.py', 'test_tier_r_label_promotion_r1.py', 'test_unified_live_pairs_r1.py'],
    ['docs/specs/calibration-corpus-and-model.md', UE+'08-evaluation.md'],
    'Retain the provenance primitives and record the absent research workflow separately. A future selective recovery needs review of the full matrix/holdout/report behavior and current build boundaries.',
    'This disposition does not exhaustively qualify all four missing runners, the real corpus/build matrix, held-out accuracy or native pilot receipts. No compiler/target execution occurred.')

add('feat/verified-offline-runtime-bundle', 'retained_focal_scope',
    'Strict offline runtime archive validation and explicit installation',
    'Introduce strict manifest/inventory/hash checks, bounded ZIP extraction, Windows path/casefold/device-name refusal, disk/cancel handling, deterministic producer and explicit desktop setup.',
    'Current public validate_manifest and preflight ZIP directory checks preserve and strengthen the inspected verifier, including bounded central-directory inspection. install_offline_bundle is reused by the headless runtime CLI. The older private helper names and initial UI seam have newer replacements. The separate directory reservation race was already confirmed in batch3 and is not a new omission.',
    'runtime_cli validates and calls the existing offline installer; tools/make_offline_bundle calls the same producer. Synthetic bundle/Linux/CLI controls exercise validation, cancel, install and archive identity. The desktop setup wiring was inspected in batch3, not newly accepted by this batch.',
    ['src/patchtrace/offline_bundle.py', 'src/patchtrace/runtime_cli.py', 'src/patchtrace/cli_commands/runtime.py', 'tools/make_offline_bundle.py'],
    ['test_offline_bundle.py', 'test_offline_bundle_linux.py', 'test_runtime_cli.py'],
    ['docs/specs/offline-backend-installer.md', 'docs/specs/program-e/BUNDLE-runtime-policy-spec.md', 'docs/specs/cli-profile-doctor-runtime.md'],
    'No wholesale historical port. Preserve current strict archive verification; keep the already root-owned directory publication repair separately attributed to later continuation source.',
    'No real runtime execution, frozen standalone installer, Windows filesystem or full transaction-race acceptance. The pinned source still contains the known directory helper defect, so retained focal validation is not overall installer completion.')

add('security/offline-bundle-no-overwrite-20261013', 'retained_focal_scope',
    'No-overwrite publication of the produced archive file',
    'Change the producer publication from os.replace to os.link so an archive appearing at the destination during construction is preserved.',
    'The producer still links the exclusive staged archive to the destination and cleans its owned stage. test_producer_does_not_overwrite_archive_created_during_publish passes. The installer directory helper is a different operation and retains the separately known reservation issue in the frozen baseline.',
    'produce_offline_bundle is reached by the standalone packaging tool; its file-publication path is distinct from install_offline_bundle directory placement. Source and tests distinguish the two.',
    ['src/patchtrace/offline_bundle.py', 'tools/make_offline_bundle.py'],
    ['test_offline_bundle.py', 'test_offline_bundle_linux.py'],
    ['docs/specs/offline-backend-installer.md'],
    'No port for the retained archive-file guard. Do not infer installer directory safety from this older security branch.',
    'Current synthetic Linux archive collision behavior is qualified; Windows/network filesystem behavior and root-owned later directory repair are outside this execution.')

add('haiku/cli-help-suppress-20261027', 'retained_focal_scope',
    'Keep internal worker parseable without help-list leakage',
    'The old helper edits argparse private choice metadata to hide the internal BinExport worker while retaining its parser.',
    'Current registration omits the help keyword for _binexport-worker. This avoids the SUPPRESS placeholder and public choice listing without mutating argparse internals. The hidden worker remains accepted and dispatched.',
    'secondary.cli_binexport registers the internal parser and dispatches the --request to the worker entry. test_secondary_help checks the public help text and parse/dispatch behavior.',
    ['src/patchtrace/secondary/cli_binexport.py'], ['test_secondary_help.py'],
    ['docs/specs/cli-profile-doctor-runtime.md', UE+'06-adapters.md'],
    'Keep the simpler current parser construction; no private-argparse helper port needed.',
    'This is help/dispatch behavior only; no worker native extraction, packaged CLI or external tool compatibility acceptance.')

(OUT / 'dispositions.json').write_text(json.dumps(ROWS, indent=2) + '\n')
print(len(ROWS))
