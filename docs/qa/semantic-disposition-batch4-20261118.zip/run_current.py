"""Run the bounded current-source gate with exact source and artifact receipts."""
from datetime import UTC, datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch4')
PYTHON = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
BASE = '55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
FILES = '''test_unified_verdict_ir.py test_unified_pair_text.py test_unified_wire_refacts.py test_unified_store.py test_unified_followup_keys.py test_unified_followup_align.py test_unified_followup_datamap.py test_unified_followup_ironly.py test_unified_followup_orientation.py test_unified_fct_datamap.py test_unified_ir_pe_tables.py test_unified_irx_cfg.py test_unified_ir_graph.py test_unified_fusion.py test_unified_fusion_mirror.py test_unified_fusion_properties.py test_r8_literal_types.py test_tier_w_fetch.py test_tier_w_run_local.py test_research_qualification_scoring.py test_research_qualification_cases.py test_research_qualification_adapters.py test_research_qualification_ghidriff_identity.py test_research_qualification_rizin_identity.py test_r7_patterns.py test_r7_slicing.py test_unified_gate_eval.py test_unified_rb01_harness.py test_unified_bench.py test_unified_parity.py test_unified_live_pairs.py test_unified_live_pairs_r1.py test_unified_live_force_identical.py test_unified_live_native_failure_details.py test_unified_live_workflow.py test_tier_r_build_receipts_r1.py test_tier_r_session_provenance_r1.py test_tier_r_label_promotion_r1.py test_offline_bundle.py test_offline_bundle_linux.py test_runtime_cli.py test_secondary_help.py'''.split()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

assert git('rev-parse', 'HEAD') == BASE
assert not git('status', '--porcelain', '--', 'src', 'tests', 'tools')
paths = ['tests/' + name for name in FILES]
assert all((ROOT / path).is_file() for path in paths)
environment = {'PYTHONPATH': str(ROOT / 'src') + ':' + str(ROOT / 'tests'),
               'QT_QPA_PLATFORM': 'offscreen'}
deselected = ['tests/test_unified_rb01_harness.py::test_the_engine_image_of_a_mutant_module_exports_every_candidate', 'tests/test_unified_rb01_harness.py::test_the_path_nuisance_pair_labels_every_function_the_same_function']
command = [PYTHON, '-m', 'pytest', '-q', '-ra', *paths, *('--deselect=' + node for node in deselected),
           '--junitxml=' + str(OUT / 'current-affected.xml')]
receipt = {
    'source': BASE, 'tree': git('rev-parse', 'HEAD^{tree}'), 'cwd': str(ROOT),
    'command': command, 'environment': environment,
    'started_utc': datetime.now(UTC).isoformat(),
    'test_files': {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest() for path in paths},
    'explicit_deselections': {node: 'Native compiler/build matrix outside the assigned offline source disposition scope' for node in deselected},
    'qualification_scope': 'Authored deterministic source/offscreen regression controls. No live provider, network acquisition, target or native engine execution, Windows or package acceptance.',
}
(OUT / 'current-command.json').write_text(json.dumps(receipt, indent=2) + '\n')
start = time.monotonic()
with (OUT / 'current-affected.log').open('w') as log:
    result = subprocess.run(command, cwd=ROOT, env=os.environ | environment,
                            stdout=log, stderr=subprocess.STDOUT, check=False)
receipt.update(exit_code=result.returncode, finished_utc=datetime.now(UTC).isoformat(),
               wall_seconds=time.monotonic() - start)
if (OUT / 'current-affected.xml').is_file():
    root = ET.parse(OUT / 'current-affected.xml').getroot()
    receipt['junit_suites'] = [suite.attrib for suite in root.iter('testsuite')]
    receipt['skips'] = [
        {'test': case.attrib, 'reason': node.attrib, 'detail': node.text}
        for case in root.iter('testcase') for node in case.findall('skipped')
    ]
receipt['final_product_source_status'] = git('status', '--porcelain', '--', 'src', 'tests', 'tools')
(OUT / 'current-command.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'exit_code': result.returncode, 'files': len(paths),
                  'wall_seconds': receipt['wall_seconds'],
                  'junit_suites': receipt.get('junit_suites'), 'skips': receipt.get('skips')}, indent=2))
print('\n'.join((OUT / 'current-affected.log').read_text().splitlines()[-12:]))
raise SystemExit(result.returncode)
