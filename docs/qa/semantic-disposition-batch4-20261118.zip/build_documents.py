"""Build the read-only batch4 checkpoint from retained inspection and real receipts."""
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch4')
PLAN = ROOT / 'docs/plans/autonomous-consolidation-20261118'
BASE = '55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
PRIOR = 'aa90efbb8238d58817489377f05dc52af7f1e239'
Q = chr(96)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def raw(sha, path):
    return subprocess.check_output(['git', 'show', sha + ':' + path], cwd=ROOT)

def read(name):
    return json.loads((OUT / name).read_text())

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def codes(values):
    return ', '.join(Q + str(v) + Q for v in values)

def append_section(path, marker, body):
    old = path.read_text()
    if marker in old:
        old = old.split(marker, 1)[0].rstrip() + '\n'
    path.write_text(old.rstrip() + '\n\n' + marker + '\n\n' + body.strip() + '\n')

snapshot = read('snapshot.json')
catalogue = read('catalogue.json')
decisions = read('dispositions.json')
proofs = {r['branch']: r['proofs'] for r in read('replacement-provenance.json')['branches']}
structural = {r['branch']: r for r in read('symbol-comparison.json')['branches']}
inputs = {r['branch']: r for r in snapshot['branches']}
prior = json.loads(raw(PRIOR, 'docs/plans/autonomous-consolidation-20261118/semantic-disposition-batch3.json'))
assert snapshot['comparison_base'] == BASE
assert len(decisions) == 20 and len(inputs) == 20
assert set(inputs) == {r['branch'] for r in decisions}
assert set(inputs) <= {r['branch'] for r in prior['still_unselected_original_tips']}
remaining = [r for r in prior['still_unselected_original_tips'] if r['branch'] not in inputs]
assert len(remaining) == 51 and len({r['tip'] for r in inputs.values()}) == 20
assert not git('diff', BASE, '--', 'src', 'tests', 'tools', '.github')
assert not git('status', '--porcelain', '--', 'src', 'tests', 'tools', '.github')
assert hashlib.sha256((PLAN / 'branch-inventory.json').read_bytes()).hexdigest() == snapshot['inventory_source_sha256']
counts = Counter(r['classification'] for r in decisions)
assert counts == dict(retained_focal_scope=15, confirmed_selective_omission=1,
                      partially_retained_incomplete_workflow=1, superseded_by_stricter_current=1,
                      retained_research_prototype=1, partially_retained_research_workflow=1)

current = read('current-command.json')
assert current['source'] == BASE and current['exit_code'] == 0
assert len(current['test_files']) == 42 and len(current['explicit_deselections']) == 2
assert current['junit_suites'][0]['tests'] == '1017'
assert current['junit_suites'][0]['failures'] == current['junit_suites'][0]['skipped'] == '0'
for row in decisions:
    for path in row['current_paths'] + row['specs'] + ['tests/' + t for t in row['tests']]:
        assert (ROOT / path).is_file(), (row['branch'], path)
    assert set('tests/' + t for t in row['tests']) <= set(current['test_files'])

for item in read('historical-tests.json')['tests']:
    data = (OUT / item['retained_path']).read_bytes()
    assert data == raw(item['source_commit'], item['path'])
    assert hashlib.sha256(data).hexdigest() == item['sha256'] and len(data) == item['bytes']
assert hashlib.sha256((OUT / 'test_r2_product_surfaces_v3.py').read_bytes()).hexdigest() == '37fa19d6c288b1892d9567ddeee7cae35d74c721a73a01247629db6e373b30c4'

summaries = {
    'current-affected': (1017, 0, 27.27),
    'historical-r3-r8': (44, 0, 1.25),
    'historical-ue-r3': (134, 1, 5.61),
    'historical-r2': (6, 74, 1.76),
    'r2-valid-cfg': (60, 0, .28),
    'r2-product-surfaces': (1, 4, .43),
    'r2-product-surfaces-v2': (2, 3, .56),
    'r2-product-surfaces-v3': (1, 4, .53),
}
executions = {}
for label, (passed, failed, seconds) in summaries.items():
    tree = ET.parse(OUT / (label + '.xml')).getroot()
    suite = tree.find('testsuite')
    assert int(suite.get('tests')) == passed + failed
    assert int(suite.get('failures')) == failed
    assert suite.get('errors') == suite.get('skipped') == '0'
    command = 'current-command.json' if label == 'current-affected' else label + '.command.json'
    executions[label] = dict(source=BASE, passed=passed, failed=failed, errors=0, skipped=0,
                             summary_seconds=seconds, junit_seconds=float(suite.get('time')),
                             command=command, log=label+'.log', xml=label+'.xml')
executions['current-affected'].update(files=42, explicitly_deselected=current['explicit_deselections'])
executions['r2-product-surfaces']['interpretation'] = 'Initial authored probe: three manual cases failed an incorrect RunReport setup assertion; the cap failure and below-cap positive reached behavior. Original bytes/logs retained.'
executions['r2-product-surfaces-v2']['interpretation'] = 'Corrected RunReport status assertion. Ambiguous case passed an overbroad whole-detail assertion; split/merged and cap remained red.'
executions['r2-product-surfaces-v3']['interpretation'] = 'Decision-line assertion corrects the overly broad attribution check. Three public manual cases and the persisted cap case fail; below-cap positive passes. No product edit.'

def classify_r2(case):
    name = case.get('name')
    module = case.get('classname').rsplit('.', 1)[-1]
    failure = case.find('failure')
    if failure is None:
        return 'passed_historical_control', 'Unchanged historical positive passed on the frozen current source.'
    if module == 'test_r2_cfg_performance':
        return 'invalid_internal_entry_domain', 'The loop reaches entry=n and current tin[entry] raises IndexError. The production ingest caller first returns for empty records and constructs 0<=entry<n. The separate same-oracle valid-entry replay passes all 60 seeds.'
    if module == 'test_r2_cache_version':
        return 'superseded_cache_token_expectation', 'The historical MATCH_POLICY_VERSION is absent. Current registry arbiter=2 and channel/proof versions remain config-bound; do not replace them with the historical payload. Any new witness repair needs its own narrow version bump.'
    if name == 'test_atom_cap_retains_the_cross_class_witness_of_an_accepted_match':
        return 'confirmed_lost_atom_witness', 'The actual 64-atom result retains only E-BODY although E-DATA justified B+B acceptance. Independently persisted and displayed in the v3 external probe.'
    if name in ('test_support_indexes_identify_the_actual_corroborating_classes', 'test_cap_preserves_acceptance_witness_and_strong_contest_together'):
        return 'support_inventory_contract_mismatch', 'The failing assertion requires support indexes to be mutually corroborating classes. Current SPEC-31/05 section1.1 explicitly defines per-component max-pool inventory. The latter case retains its strong contest before failing that support-only assertion.'
    if name.startswith('test_manual_group_explanation_identifies_the_analyst_decision'):
        return 'confirmed_manual_decision_attribution', 'Current Decision text ignores manual-group hints. Split/merged falsely describe automatic B evidence; ambiguous loses analyst attribution. Actual service/persistence/CLI/desktop v3 flow confirms all three.'
    if name == 'test_insufficient_atom_cap_rejects_instead_of_erasing_the_contest':
        return 'custom_tiny_cap_boundary_residue', 'Historical test expects a typed rejection at atoms_per_row=2; current keeps three mandatory support/contest atoms. This is a distinct custom-limit boundary, not proof of default-cap contest loss; no external CLI exposes this value.'
    if name.startswith('test_ladder_leftovers_are_source_specific_unknown_observations'):
        return 'superseded_leftover_representation', 'Fails first at fixture-hint propagation. Current A-29 emits fixed step leftover with the reason as native text and deliberately excludes imports/externals. Do not restore the older unmatched naming/behavior wholesale.'
    if name.startswith('test_ladder_leftover_fid_outside_verified_reader_is_rejected') or name == 'test_ladder_leftover_foreign_rva_is_rejected':
        return 'direct_correspondence_guard_residue', 'Malformed direct internal Correspondence input either aliases the last item, raises IndexError rather than UnifiedError, or admits a foreign RVA. Current compute constructs it through run_ladder over the same verified ReaderSide; a production admitted-input route was not established.'
    raise AssertionError((module, name))

historical_cases = []
for case in ET.parse(OUT / 'historical-r2.xml').getroot().iter('testcase'):
    category, explanation = classify_r2(case)
    failure = case.find('failure')
    historical_cases.append(dict(module=case.get('classname').rsplit('.', 1)[-1], node=case.get('name'),
                                 result='failed' if failure is not None else 'passed', category=category,
                                 explanation=explanation,
                                 failure_message=None if failure is None else failure.get('message')))
assert sum(c['result']=='failed' for c in historical_cases) == 74
write_json(OUT / 'historical-result-disposition.json', dict(source=BASE, historical_source='b3ceb8b30d7a83da5e22c231c3b8c28179246816',
    category_counts=dict(Counter(c['category'] for c in historical_cases)), cases=historical_cases,
    ue_r3_failure='One unchanged historical assertion excludes an explicit failed newer-side decomp record; current status-preserving pipeline intentionally retains it. 134 neighbors pass.'))

branches = []
for row in decisions:
    mapped = structural[row['branch']]['symbols']
    a, b = inputs[row['branch']]['ahead_behind_baseline'].split()
    branches.append(inputs[row['branch']] | row | dict(
        source_proofs=proofs[row['branch']], structural_summary=dict(Counter(x['status'] for x in mapped)),
        behind_comparison_commits=int(a), ahead_of_comparison_commits=int(b),
        qualification='One shared 42-file current gate; listed tests are subsets, not additive per-branch runs. Separate original/external receipts are explicitly enumerated.',
        whole_branch_closed=False, remote_action_authorized=False))

result = dict(schema='patchtrace-semantic-disposition/1', batch=4, prepared_at_utc=datetime.now(UTC).isoformat(),
    comparison_source=BASE, comparison_tree=snapshot['comparison_tree'],
    comparison_identity='Actual published PR316 source at assignment; later continuation repairs do not relabel this source.',
    inventory_observed_at=snapshot['inventory_observed_at'], inventory_source_sha256=snapshot['inventory_source_sha256'],
    remote_refresh=snapshot['remote_refresh'],
    previous_batches=[
        dict(batch=1, checkpoint='8148ff0fada34e3adff893a3d68f0bce1ffc6e0f', selected=20, comparison='ac789497597fba3cb87696990d171a7a27024fca'),
        dict(batch=2, checkpoint='1a07861f3d54dde6fce0bbd3c79fc772295c92ac', selected=20, comparison='3be3af166897fc2376dc64850edc66485273dea1'),
        dict(batch=3, checkpoint=PRIOR, selected=20, comparison=BASE)],
    selection_denominator=dict(original_needs_reconciliation_tips=131, previously_selected=60,
        selected_this_batch=20, cumulatively_selected=80, still_unselected=51,
        meaning='Counts of inspected selected scopes, not closed branches, completed milestones or a product percentage'),
    classification_counts=dict(counts),
    decision_criteria=[
        'Read the merge-base-to-tip source patch, actual current implementation, callers, contracts and tests.',
        'Use exact file/AST identity only as structural evidence; record moved replacements with real guard/caller proof.',
        'Keep complete historical bytes and original contrary results; classify current contract differences and input-domain limits explicitly.',
        'Record exact merge bases, ahead/behind, git cherry patch-equivalence, source blobs and ancestral replacement history.',
        'Retained focal scope never closes broader research/native/package residue or authorizes merging/deleting a branch.'],
    executions=executions, historical_r2_disposition='historical-result-disposition.json',
    known_later_work=dict(comparison_unchanged=BASE,
        root_reported_continuation='5bbb9256 (root-reported current unpublished source; not executed or credited here)',
        already_known=['named-source warnings', 'UI attempt-persistence/false-kept diagnostics', 'directory publication reservation ownership',
                       'code-highlighter dispatch guard', 'F8 packaged KB synthetic journey and tooltip collision'],
        separate_new_repair='R2 witness/manual attribution assigned to report_evidence_review from 3faf436a; no repair credit at the frozen comparison'),
    limitations=['No source, product test, tool or workflow edits; original branch inventory unchanged.',
        'No fresh remote/PR/check observation, historical full suite or final integrated full suite.',
        'No network/provider/acquisition, native engine, target execution, compiler corpus, Windows, frozen package or manual/screen-reader acceptance.',
        'The selected 42-file gate explicitly deselects two native compiler RB01 cases; no skipped cases are represented as passing.',
        'The UI evidence uses the actual shared desktop view model/detail plus CLI, not a native widget/manual screen acceptance claim.',
        'R2 direct malformed Correspondence and tiny custom cap boundaries remain separate unresolved scope; absent research runners are not blanket product failures.'],
    branches=branches, still_unselected_original_tips=remaining)
write_json(PLAN / 'semantic-disposition-batch4.json', result)

source_paths = {'AGENTS.md', 'docs/modules.md', 'pyproject.toml', 'tests/conftest.py',
                'tests/unified_read_support.py', 'tests/unified_s0_fixtures.py'} | set(current['test_files'])
for row in branches:
    source_paths.update(row['current_paths'] + row['specs'])
    source_paths.update(p['path'] for p in row['source_projection'] if p.get('base_blob'))
source_manifest = {}
for path in sorted(source_paths):
    data = raw(BASE, path)
    dest = OUT / 'current-source' / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    source_manifest[path] = dict(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data), git_blob=git('rev-parse', BASE+':'+path))
write_json(OUT / 'current-source-manifest.json', dict(source=BASE, tree=snapshot['comparison_tree'], files=source_manifest))
historical_manifest = []
for row in branches:
    label = row['branch'].replace('/', '__')
    for item in row['source_projection']:
        if not item.get('tip_blob'):
            continue
        path = item['path']
        data = raw(row['tip'], path)
        dest = OUT / 'historical-source' / label / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        historical_manifest.append(dict(branch=row['branch'], tip=row['tip'], path=path,
            retained_path=str(dest.relative_to(OUT)), git_blob=item['tip_blob'], bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
write_json(OUT / 'historical-source-manifest.json', dict(note='Exact tip bytes; complete patch files additionally preserve removed and changed lines.', files=historical_manifest))

labels = dict(retained_focal_scope='Retained focal scope', confirmed_selective_omission='Confirmed selective omission',
    partially_retained_incomplete_workflow='Partially retained; workflow incomplete',
    superseded_by_stricter_current='Superseded by stricter current admission', retained_research_prototype='Retained research prototype',
    partially_retained_research_workflow='Partially retained research workflow')
lines = ['# Semantic branch disposition — batch 4', '',
    f'Comparison: **{Q}{BASE}{Q}**, tree {Q}{snapshot["comparison_tree"]}{Q}, actual published PR #316.', '',
    'This read-only batch inspects 20 distinct source-bearing tips from the 71 left unselected after '
    'batch 3. Fifteen focal scopes are retained; one branch contains confirmed witness/manual-attribution '
    'omissions; one older adapter relaxation is superseded by stricter current admission; one bounded '
    'research prototype is retained; and two developer/research workflows remain partly absent.', '',
    '[Complete exact-tip ledger](semantic-disposition-batch4.json) · '
    '[Sealed QA and original failures](../../qa/semantic-disposition-batch4-20261118.md).', '',
    '## Observation, selection and limits', '',
    f'The original inventory was observed at {Q}{snapshot["inventory_observed_at"]}{Q}. Local fetched refs '
    'were checked against those frozen tips; no fresh GitHub/PR/check state is claimed. Each source patch '
    'was read against its actual merge base, then compared with current definitions, caller boundaries, '
    'contracts and tests. Full merge history records ancestral code needles and parent presence. File/AST '
    'identity supports the result but is not treated as semantic acceptance by itself.', '',
    'The remaining narrow KB/CVE-labelled leaves have no actual src/tools delta; selection therefore '
    'prioritizes source-bearing matching, acquisition and analyst-support harness scopes. Names alone '
    'did not establish value or equivalence. Broad consolidation and native research residue remains open.', '',
    '**80 of 131 original reconciliation tips now have selected-scope entries; 51 remain unselected.** '
    'These are scope-selection counts, not completed branches or a feature percentage. The original '
    'inventory is unchanged, every branch is preserved, and no whole-branch closure is authorized.', '',
    'Later named-source/UI diagnostics, directory-publication, highlighter and F8 repairs belong to '
    'separate continuation source. Root reported unpublished continuation 5bbb9256 during sealing; '
    'its source, gate results and fixes are not relabeled as part of this 55f3 comparison.', '',
    '## Twenty exact tips', '', '| Branch | Exact tip | Scoped outcome |', '|---|---|---|']
for row in branches:
    lines.append(f'| {Q}{row["branch"]}{Q} | {Q}{row["tip"]}{Q} | {labels[row["classification"]]}: {row["focus"]} |')
lines += ['', '## Source-level dispositions', '']
for i, row in enumerate(branches, 1):
    ancestors = []
    for proof in row['source_proofs']:
        for h in proof['history']:
            if h['needle_present_in_commit'] and not h['needle_present_in_first_parent'] and h['sha'] not in ancestors:
                ancestors.append(h['sha'])
    prs = ', '.join('#'+str(p['number']) for p in row['pull_requests']) or 'none mapped'
    lines += [f'### {i}. {Q}{row["branch"]}{Q}', '',
              f'**{labels[row["classification"]]}.** Frozen PR mapping: {prs}.', '',
              '**Historical delta:** '+row['historical_behavior'], '',
              '**Current behavior:** '+row['current_behavior'], '',
              '**Caller evidence:** '+row['caller_evidence'], '',
              'Current source: '+codes(row['current_paths'])+'.', '',
              'Contract: '+codes(row['specs'])+'.', '',
              'Ancestral introduction/replacement records: '+(codes(ancestors) or 'exact current blob/source proof recorded in JSON')+
              '. The JSON records exact needles, lines, blobs, all-parent presence and merge-base/ahead-behind/patch-equivalence evidence.', '',
              'Current test map: '+codes('tests/'+t for t in row['tests'])+
              '. These are subsets of the same 42-file gate, not additional per-branch runs.', '',
              '**Selective decision:** '+row['recommendation'], '', '**Residual scope:** '+row['residue'], '']

lines += ['## B4-C1 — R2 witness and manual-attribution omission', '',
    'The complete original fusion test file from b3ceb8b30d7a83da5e22c231c3b8c28179246816 is '
    'retained byte-for-byte (11,292 bytes), SHA-256 '+
    Q+'b545602a001c206f608800c034412023abfe79a79d84d8a59e34b6b5b22cab68'+Q+'. '
    'The unchanged three-file historical R2 invocation produces 74 failures and six positives. '
    'It is not a count of 74 admitted product defects.', '',
    '| Historical failed category | Cases | Disposition |', '|---|---:|---|',
    '| Lost cross-class witness at actual 64-atom cap | 1 | Confirmed; independent strict persistence/desktop detail probe reproduces it |',
    '| Manual split/merged/ambiguous Decision attribution | 3 | Confirmed through actual correction, Unified run, verified store and reopened CLI/desktop detail |',
    '| Support indexes required to be witness classes | 2 | Conflicts with current per-component max-pool contract, SPEC-31/05 §1.1 |',
    '| Custom cap=2 expected rejection | 1 | Current retains three mandatory atoms; separate custom-limit boundary, no default-cap contest-loss claim |',
    '| Historical leftover step/hint expectation | 2 | Later A-29 deliberately defines step leftover, reason as native text and import/external exclusion |',
    '| Malformed direct Correspondence ID/RVA | 3 | Internal boundary residue; admitted production route not established |',
    '| CFG oracle includes entry=n | 60 | Invalid internal entry; actual ingest constructs valid range. Same oracle over valid entries passes all 60 seeds |',
    '| Historical matching-policy cache token | 2 | Replaced by current registry/config versions; no old cache-policy relaxation |', '',
    'Every original node/result/failure message is classified in historical-result-disposition.json. '
    'The accepted current Support definition is distinct from keeping the actual B+B evidence in the '
    'row atoms. Root assigned a separate narrow repair to report_evidence_review from 3faf436a, whose '
    'relevant production bytes were checked identical to 55f3. Preserve mirror-orbit truncation, strongest '
    'contest and per-component Support; no wholesale historical arbiter port.', '',
    'The external v3 probe has four failures and one below-cap positive. Its SHA-256 is '+
    Q+'37fa19d6c288b1892d9567ddeee7cae35d74c721a73a01247629db6e373b30c4'+Q+'. '
    'Manual cases use ProjectService.correct_match → run_unified → strict result verification → desktop '
    'read-model detail → close/reopen through actual CLI unified explain --json. Split/merged falsely '
    'describe independent B evidence despite empty support; ambiguous loses manual attribution on the '
    'Decision line. Complete CLI JSON/detail is retained. The cap case persists manufactured registered '
    'atoms and demonstrates presentation reachability, not incidence in native engine data.', '',
    'Probe chronology remains explicit: v1 had three wrong RunReport setup assertions (four failures/one '
    'positive overall); v2 corrected status=ok/result_status and had three failures/two positives but '
    'accepted ambiguous attribution anywhere in the detail; v3 restricts that assertion to the Decision '
    'line and exposes all three manual cases. All versions, logs and XML are immutable. None of these '
    'probe corrections changed product source.', '',
    '## Qualification and unverified gates', '',
    '| Invocation at frozen 55f3 | Actual result | Pytest summary | JUnit suite |', '|---|---|---:|---:|']
for label, e in executions.items():
    lines.append(f'| {label} | {e["passed"]} passed / {e["failed"]} failed / 0 skipped / 0 errors | {e["summary_seconds"]:.2f} s | {e["junit_seconds"]:.3f} s |')
lines += ['', 'The current gate executes 42 files and explicitly deselects two compiler-backed RB01 cases: '+
    Q+'test_the_engine_image_of_a_mutant_module_exports_every_candidate'+Q+' and '+Q+
    'test_the_path_nuisance_pair_labels_every_function_the_same_function'+Q+'. The lone warning is the '
    'intentional duplicate ZIP-name negative fixture. Commands use the shared Python with absolute '
    'PYTHONPATH to this worktree and normal system temporary fixtures; the uninjected backend-pin '
    'network fixture is excluded. No custom basetemp beneath Git was used.', '',
    'The UE-R3 historical mismatch preserves an explicit failed decompile-side status in current source; '
    'the older assertion expects only the successful side. Current behavior tests pass. Historical '
    'positives, repeated per-branch maps and the valid-domain CFG rerun are not added to an aggregate '
    'success count or completion score.', '',
    'No historical full suite, final integrated full suite, real network/provider/acquisition, target or '
    'native engine, compiler corpus, Windows, frozen package or manual/screen-reader acceptance ran. '
    'No source changes, merge, remote mutation or branch closure occurred. Independent review/selective '
    'integration of this docs checkpoint remains root-owned.', '']
(PLAN / 'semantic-disposition-batch4.md').write_text('\n'.join(lines))

append_section(PLAN / 'consolidation-ledger.md', '## Semantic reconciliation batch 4 — 2026-11-18', '''
The fourth scoped batch compares 20 further original source-bearing tips with actual
PR316 55f3d0742f7d4cf32357a42b8b1cc76d85875e71. Fifteen focal scopes are retained,
one research prototype is retained, one old adapter relaxation is superseded by
stricter current admission, and two developer/research workflows remain incomplete.
The R2 branch has a confirmed lost B+B atom witness and incorrect manual group
Decision attribution; root assigned the separate narrow repair to report_evidence_review.

The current 42-file source-pinned offline gate passes 1,017 cases, with zero skips
and two explicitly deselected compiler-backed controls. Original R2 74-fail/6-pass
results remain fully classified; only four directly assert the confirmed omissions.
Current per-component Support, A-29 leftovers and mirror-safe policy must survive.
Actual persisted/view-model and reopened CLI probes confirm the bounded omissions.
The original UE-R3 one-fail/134-pass mismatch preserves a current failed-side status.

Eighty of 131 original reconciliation tips now have selected-scope entries; 51
remain unselected, and broader branch/native/package/research residue stays open.
These are selection counts, not a feature percentage or whole-branch closure.
Already known directory/UI/named-source/highlighter/F8 repairs belong to later
continuation source and are not relabeled as new findings or baseline fixes.
[Exact-tip ledger](semantic-disposition-batch4.md), [complete JSON](semantic-disposition-batch4.json),
and [sealed QA](../../qa/semantic-disposition-batch4-20261118.md) retain the evidence.
''')
append_section(ROOT / 'docs/plans/patchtrace-completion-matrix.md', '## Semantic batch 4 scope update — 2026-11-18', '''
This read-only assessment is pinned to published PR316 55f3d074. Twenty further
selected scopes bring the original branch-tip denominator to 80 selected / 51
unselected out of 131; no feature percentage or completed-branch credit follows.

| Scope | Evidence at the frozen source | Remaining acceptance |
|---|---|---|
| Fifteen retained focal scopes and one stricter adapter replacement | Actual patch/caller/source proof; shared 42-file gate, 1,017 passed, zero skipped | Broader branch residue and final native/platform/package/manual gates |
| R2 witness and manual attribution | Original failures plus strict persisted detail and reopened CLI controls; four v3 failures/one positive | Separately owned mirror-safe cap/manual explanation repair and independent acceptance; preserve current Support semantics |
| Tier W acquisition developer workflow | Bounded exact-consent fetch library and explicit missing-CLI BLOCKED path | Saved plan and CLI orchestration, current contracts, real local-only corpus acceptance |
| R1 research orchestration | Immutable build receipts/session identity/truth guards retained | Four missing research runners; full matrix/holdout review and real native ground truth |
| R7 prototype | Three exact tool files and bounded pure controls | Production extractor/analyst bridge, verified control dependence and native accuracy remain unbuilt/unqualified |

The known directory publication, UI diagnostics, named-source, highlighter and F8
follow-ons remain separately attributed. [Detailed ledger](autonomous-consolidation-20261118/semantic-disposition-batch4.md)
and [QA packet](../qa/semantic-disposition-batch4-20261118.md) preserve all original
failures, explicit deselections, current contract mismatches and scope limits.
''')
append_section(ROOT / 'docs/qa.md', '## [SEMANTIC-DISPOSITION-BATCH4-20261118]', '''
Read-only 20-tip batch at actual PR316 55f3d074: 15 retained focal scopes, one
confirmed selective R2 omission, one stricter adapter replacement, one retained
research prototype and two incomplete developer/research workflows. Current gate:
42 files, 1,017 passed, zero failures/errors/skips, two explicit compiler-case
deselections, 27.27 s. Separate historical R2 replay: 74 failed/6 passed; every
failure classified, with no old Support/CFG/cache policy relaxation. Final external
public/persisted R2 controls: four failed/one positive. Original probe setup and
assertion corrections remain transparent. UE-R3 historical replay: one changed-
contract mismatch/134 passed; R3/R8: 44 passed; valid-domain CFG oracle: 60 passed.
No additive counting, source edit, native/network run, remote mutation or whole-
branch closure. Cumulative selected scope: 80 of 131; 51 unselected plus broader
residue. [Source pins, original bytes, commands and archive](qa/semantic-disposition-batch4-20261118.md).
''')
append_section(ROOT / 'tasks/todo.md', '### [SEMANTIC-DISPOSITION-BATCH4-20261118]', '''
- [x] Inspect 20 more exact original source-bearing tips at published PR316 55f3d074 with source/caller/contract/ancestry proof.
- [x] Retain exact historical tests and every failure; run bounded current 42-file gate (1,017 passed, two compiler deselections, zero skips).
- [x] Confirm the R2 witness/manual-attribution omission through strict persistence, desktop view model and actual reopened CLI; hand off to separately assigned repair owner.
- [x] Distinguish historical Support, A-29, invalid-entry and cache-token expectations from admitted product behavior; preserve originals unchanged.
- [ ] Independently review/selectively retain this docs checkpoint; no whole-branch closure or remote changes.
- [ ] Complete separate mirror-safe R2 witness/manual attribution repair and independent acceptance without broad historical policy rollback.
- [ ] Design and qualify any future Tier W saved-plan/CLI and R1 research-runner recovery using current ownership/contracts.
- [ ] Inspect the remaining 51 original tips and broader checkpoint/research/native/package residue.
- [ ] Complete actual final-source full/platform/native/package/manual gates; synthetic source checks are not that acceptance.
''')
print(json.dumps(dict(selected=20, classifications=dict(counts), remaining=51,
    current_source_files=len(source_manifest), historical_source_files=len(historical_manifest)), indent=2))
