"""Classify exact observed historical failures without treating all as current defects."""
from collections import Counter
import json
from pathlib import Path
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
BASE = '55f3d0742f7d4cf32357a42b8b1cc76d85875e71'


def classify(label, name, message):
    if label == 'historical-kbscope':
        if name.startswith('test_unselected_newer_same_month') or name.startswith('test_explicit_file_search_selects_older'):
            return ('superseded_revision_policy_conflict', 'Historical test requires the named older snapshot to remain authoritative. Current global active-revision admission withholds it. Do not restore a restricted index that resurrects superseded or withdrawn evidence.')
        if name.startswith('test_saved_scope_bounds_components_attached_context_and_raw_sources'):
            if name.endswith('[cached]'):
                return ('confirmed_cached_scope_growth', 'Fails when the later bundle key changes after an unrelated cached document is added. The separate public service/import/export/reopened CLI probe confirms an extra CVE while retained coverage still names January only.')
            return ('confirmed_whole_corpus_context_digest', 'Scoped displayed cards and sources pass, then the final assertion observes the whole-index edge_set_digest instead of the January-only selected document digest.')
        if name.startswith('test_invalid_saved_scope_fails_before_any_service_write'):
            if 'PT-KBC-INPUT' in message:
                return ('typed_refusal_code_mismatch', 'Missing selected source is refused before the test reaches its post-call write checks, but current PT-KBC-INPUT differs from historical PT-KBC-SCOPE. This is not proof of trusted evidence or a successful mutation.')
            if 'ValidationError' in message:
                return ('untranslated_invalid_coverage_exception', 'Malformed saved JSON raises Pydantic ValidationError instead of a domain error. The historical assertion stops there; it does not establish zero writes before the exception. Pre-mutation validation is separately required.')
            assert 'DID NOT RAISE' in message, (label, name, message)
            return ('saved_coverage_validation_not_enforced', 'The requested operation returns instead of the required coverage-domain refusal. Products/pairs are read-only; do not infer a write from every node. The separate missing-coverage components public probe confirms actual revision and database mutation.')
        if name == 'test_direct_context_builder_uses_saved_scope_for_lookups_sources_and_digest':
            return ('confirmed_direct_builder_scope_growth', 'Direct build_bundle receives retained coverage but scope=None and includes the newly cached February CVE. Pure caller boundary needs the same coverage resolver.')
        if name == 'test_empty_cached_scope_stays_empty_and_pair_only_still_attaches':
            return ('confirmed_empty_cached_scope_growth', 'Fails at the first assertion because an initially empty cached search gains a later CVE. The later pair-only positive is not reached; current pair-only compatibility requires separate positives.')
        if name == 'test_newly_available_month_requires_repeat_search_without_changing_saved_coverage':
            return ('selected_month_inspection_drift_not_refused', 'A previously absent requested month becomes available and components returns without the required repeat-search refusal. The historical post-call database assertion is not reached.')
        if name == 'test_corrupt_captured_scope_blocks_repair_before_attempt_or_project_writes':
            return ('untranslated_repair_coverage_exception', 'Repair raises raw Pydantic ValidationError. The historical later database/project equality assertions are not reached; repair preflight must precede mark_interrupted and any attempt/journal writes.')
        if name == 'test_direct_context_builder_refuses_missing_scope_for_advisory_lead':
            return ('direct_builder_missing_coverage_not_refused', 'Direct advisory build_bundle accepts no saved search coverage. Manual file/pair-only contexts remain a separate compatible path.')
    if label == 'historical-coff':
        if name.endswith('[True]'):
            return ('obsolete_branch_target_spelling', 'Quoted RIP masking achieves equal bodies; only the final tuple spelling fails because current branch-target normalization emits jmp T instead of historical jmp emit.')
        if name.endswith('[False]'):
            return ('confirmed_unquoted_coff_symbol_false_change', 'Unquoted COFF symbol prefixes survive masking and differ across data-only literals. The separate current make_masked_body_check fake-producer probe confirms acceptance, with quoted/no-body/immediate-change neighbors.')
    if label in ('historical-cards', 'historical-recipe'):
        if name == 'test_workflow_structure_and_pins':
            return ('stricter_workflow_pin_mismatch', 'First failure expects @v tags for every action; current msvc-dev-cmd uses an immutable verified commit. No hosted execution or tag-policy rollback is warranted.')
        if name == 'test_evaluation_uses_real_cli_engines_option':
            return ('cli_option_spelling_compatibility', 'Current sharder emits --engine; the current argparse parser accepts it as the unambiguous abbreviation of --engines. The separate parser observation checks the actual emitted argument vector; canonical spelling would be cleanup, not a demonstrated execution failure.')
        if name.startswith('test_training_'):
            return ('missing_training_artifact_workflow', 'Current workflow has no train job and no historical artifact-transfer module. Existing normalized output credit/replay is retained, but a shard artifact-transfer plus dispatch-only training workflow needs a new bounded design.')
        if name.startswith('test_nonidentical_aa_rebuild'):
            return ('missing_card_control_grammar_masks_aa_assertion', 'Fails first because there are no aa-card cases. This original test does not reach its A/A classification assertion. A separate supported aa:<suite> persisted-shard/merge probe confirms the actual current A/A failure omission.')
        if name in ('test_recipe_probes_reject_conflicting_commits_for_one_project_ref', 'test_recipe_probes_reject_missing_pin_metadata', 'test_recipe_probe_refuses_microsoft_derived_pin_with_innocent_card_id'):
            return ('recipe_plan_metadata_guard_residue', 'Current card planning filters recipe presence, case ID and license but does not implement the historical per-ref/pin inspection. The unchanged control proves plan admission only; it does not establish acquisition/execution, which have separate strict catalogue guards. Keep with a separately designed recipe-control workflow.')
        return ('missing_recipe_control_workflow', 'Current shard grammar supports card, suite, authored aa/noise and mutation. The historical per-card-side aa-card/noise-card enumeration/fetch/dedup behavior is absent. No native recipe execution is claimed or authorized.')
    if label == 'historical-prereg':
        if "has no attribute '_execute_training'" in message:
            return ('absent_final_wrapper_injection_seam', 'Original test fails while installing a stand-in for an absent private training wrapper, before its behavior runs. Current source separately confirms the final-locked-test wrapper is unimplemented; this is not proof that protected corpus input was read.')
        if "no attribute 'verified'" in message:
            return ('changed_protocol_selection_shape', 'Current Selection carries sha and rehearsal_sha, with no verified flag. Protocol identity behavior has separate current tests; do not equate identity verification with owner approval or a final look.')
        if 'require_signoff' in message:
            return ('absent_owner_signoff_wrapper', 'Current protocol-identity selector has no require_signoff argument; explicit owner/final-look permission is outside its documented scope. Historical final-run workflow remains incomplete.')
        if 'Regex pattern did not match' in message:
            return ('stricter_protocol_error_text', 'Current selector refuses the missing/malformed visible QA row with a stricter unambiguous-row message. Only the old error substring differs.')
    raise AssertionError((label, name, message))


rows = []
for label in ('historical-kbscope', 'historical-coff', 'historical-cards', 'historical-recipe', 'historical-prereg', 'historical-sort'):
    for case in ET.parse(OUT / (label + '.xml')).getroot().iter('testcase'):
        assert case.find('error') is None and case.find('skipped') is None
        failure = case.find('failure')
        name = case.get('name')
        message = failure.get('message', '') if failure is not None else None
        category, explanation = classify(label, name, message) if failure is not None else (
            'passed_historical_control', 'Unchanged original control passes on the frozen current source; reused cases are not additive completion evidence.')
        rows.append(dict(invocation=label, module=case.get('classname').rsplit('.', 1)[-1], node=name,
                         result='failed' if failure is not None else 'passed', category=category,
                         explanation=explanation, failure_message=message))
assert sum(r['result'] == 'failed' for r in rows if r['invocation'] == 'historical-kbscope') == 40
result = dict(comparison_source=BASE,
              claim='Historical mismatches are categorized by their first actual failing assertion; later assertions are not credited as exercised.',
              category_counts=dict(Counter(r['category'] for r in rows)), cases=rows)
(OUT / 'historical-result-disposition.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result['category_counts'], indent=2))
