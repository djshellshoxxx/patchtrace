"""Build a docs-only disposition checkpoint from exact source proofs and real receipts."""
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
OUT = Path(__file__).resolve().parent
PLAN = ROOT / 'docs/plans/autonomous-consolidation-20261118'
BASE = '55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
PRIOR = '4f71b811dbd1555ce5cb6cffe062dddc3bb801e5'
Q = chr(96)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def raw(sha, path):
    return subprocess.check_output(['git', 'show', sha + ':' + path], cwd=ROOT)


def read(name):
    return json.loads((OUT / name).read_text())


def write(path, document):
    path.write_text(json.dumps(document, indent=2) + '\n')


def append(path, title, body):
    text = path.read_text()
    if title in text:
        text = text.split(title, 1)[0].rstrip()
    path.write_text(text.rstrip() + '\n\n' + title + '\n\n' + body.strip() + '\n')


def code(values):
    return ', '.join(Q + str(v) + Q for v in values)


snapshot = read('snapshot.json')
dispositions = read('dispositions.json')
proofs = {r['branch']: r['proofs'] for r in read('replacement-provenance.json')['branches']}
structural = {r['branch']: r for r in read('symbol-comparison.json')['branches']}
inputs = {r['branch']: r for r in snapshot['branches']}
prior = json.loads(raw(PRIOR, 'docs/plans/autonomous-consolidation-20261118/semantic-disposition-batch4.json'))
remaining = [r for r in prior['still_unselected_original_tips'] if r['branch'] not in inputs]
assert len(dispositions) == len(inputs) == len({r['tip'] for r in inputs.values()}) == 20
assert len(remaining) == 31 and set(inputs) <= {r['branch'] for r in prior['still_unselected_original_tips']}
assert snapshot['comparison_base'] == BASE
assert not git('diff', BASE, '--', 'src', 'tests', 'tools', '.github')
assert not git('status', '--porcelain', '--', 'src', 'tests', 'tools', '.github')
assert hashlib.sha256((PLAN / 'branch-inventory.json').read_bytes()).hexdigest() == snapshot['inventory_source_sha256']
current = read('current-command.json')
assert current['source'] == BASE and current['exit_code'] == 0 and len(current['test_files']) == 34
assert current['junit_suites'][0]['tests'] == '1131' and current['junit_suites'][0]['skipped'] == '2'
assert current['junit_suites'][0]['failures'] == current['junit_suites'][0]['errors'] == '0'
for row in dispositions:
    for path in row['current_paths'] + row['specs'] + ['tests/' + t for t in row['tests']]:
        assert (ROOT / path).is_file(), (row['branch'], path)
    assert set('tests/' + t for t in row['tests']) <= set(current['test_files'])
for item in read('historical-tests.json')['tests']:
    data = (OUT / item['retained_path']).read_bytes()
    assert data == raw(item['source_commit'], item['path'])
    assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256']
for name, digest in {
    'test_saved_scope_public.py': 'cf2f3320e7eaab89a2e38d8a71724e2de67f6270c3a6c4c154fa2f56218fcb5c',
    'test_coff_masking_public.py': '2de761cb9e3b57eae2f2a39ebec9c7a540ce3fdc3d8449afbf68407f939be44c',
    'test_aa_shard_public.py': '4d5f1d9a1e513d4385c5548a61cc96a754decd34ad00ad53cd00f547b229f6e6',
}.items():
    assert hashlib.sha256((OUT / name).read_bytes()).hexdigest() == digest

summaries = {
    'current-affected': (1129, 0, 1, 1, 16.01),
    'historical-kbscope': (4, 40, 0, 0, 1.09),
    'historical-coff': (6, 2, 0, 0, .35),
    'historical-cards': (53, 12, 0, 0, .71),
    'historical-recipe': (52, 13, 0, 0, .67),
    'historical-prereg': (3, 17, 0, 0, .59),
    'historical-sort': (2, 0, 0, 0, 1.23),
    'saved-scope-public': (1, 2, 0, 0, .51),
    'coff-mask-public': (3, 1, 0, 0, .29),
    'aa-shard-public': (1, 2, 0, 0, .38),
}
executions = {}
for label, (passed, failed, skipped, xfailed, seconds) in summaries.items():
    suite = ET.parse(OUT / (label + '.xml')).getroot().find('testsuite')
    assert int(suite.get('tests')) == passed + failed + skipped + xfailed
    assert int(suite.get('failures')) == failed and int(suite.get('skipped')) == skipped + xfailed
    assert suite.get('errors') == '0'
    assert float(re.findall(r'in ([0-9.]+)s', (OUT / (label + '.log')).read_text())[-1]) == seconds
    executions[label] = dict(source=BASE, passed=passed, failed=failed, errors=0, skipped=skipped,
        xfailed=xfailed, summary_seconds=seconds, junit_seconds=float(suite.get('time')),
        command='current-command.json' if label == 'current-affected' else label + '.command.json',
        log=label + '.log', xml=label + '.xml')
executions['current-affected'].update(files=34, explicit_deselections=current['explicit_deselections'],
    nonpasses=current['nonpasses'], warnings='Six deliberate LegacyOutputWarning observations in unverified-legacy replay controls; no native evidence.')
branches = []
for row in dispositions:
    old = inputs[row['branch']]
    behind, ahead = old['ahead_behind_baseline'].split()
    branches.append(old | row | dict(source_proofs=proofs[row['branch']],
        structural_summary=dict(Counter(s['status'] for s in structural[row['branch']]['symbols'])),
        behind_comparison_commits=int(behind), ahead_of_comparison_commits=int(ahead),
        qualification='The current test map is a subset of one shared 34-file gate, not an additive branch run. Exact original/external receipts are separate.',
        whole_branch_closed=False, remote_action_authorized=False))
counts = dict(Counter(r['classification'] for r in branches))
result = dict(schema='patchtrace-semantic-disposition/1', batch=5, prepared_at_utc=datetime.now(UTC).isoformat(),
    comparison_source=BASE, comparison_tree=snapshot['comparison_tree'],
    comparison_identity='Actual published PR316 comparison frozen at assignment; later continuation source and accepted repairs are not relabeled.',
    inventory_observed_at=snapshot['inventory_observed_at'], inventory_source_sha256=snapshot['inventory_source_sha256'],
    remote_refresh=snapshot['remote_refresh'], previous_batches=prior['previous_batches'] + [dict(
        batch=4, checkpoint=PRIOR, selected=20, comparison=BASE)],
    selection_denominator=dict(original_needs_reconciliation_tips=131, previously_selected=80,
        selected_this_batch=20, cumulatively_selected=100, still_unselected=31,
        meaning='Counts of selected inspected scopes, not whole branches, completed milestones or product percentages.'),
    classification_counts=counts, decision_criteria=[
        'Inspect merge-base-to-tip source, current implementation, reachable callers, current specs and meaningful controls.',
        'Keep exact SHA/blob/AST/patch-equivalence and all-parent source history as structural evidence, not name-based semantic proof.',
        'Preserve original tests and failed assertions; distinguish policy evolution, inactive/private test seams, spelling differences and confirmed public behavior.',
        'Retained focal scope never closes inherited research/native/package residue or permits branch deletion/merge.'],
    executions=executions, historical_result_disposition='historical-result-disposition.json',
    saved_scope_design='saved-scope-design.md',
    known_later_work=dict(comparison_unchanged=BASE,
        attribution='Root continuation has separately reviewed directory publication, named-source/UI diagnostics, highlighter, F8 and R2 repairs; none is newly discovered or retested as current here.',
        c_off='Root assigned COFF repair separately; reviewer reported ce093ec56260944869fa28e12c26c79eb1dd4c78 after this frozen red. No repair credit in batch5.',
        saved_scope='Root assigned report_evidence_review service/context/index/pure-helper repair from later ae0b1660; approved attach preflight covers current and captured journal revisions before generic repair.'),
    limitations=[
        'No product/test/tool/workflow source writes, remote mutation, merge or whole-branch closure.',
        'No fresh remote branch/PR/check observation; initial inventory tips remain the denominator.',
        'No historical/full integrated suite, native engine/compiler/target, network/provider/acquisition, real Windows package or manual acceptance.',
        'Current gate retains one Windows-only skip, one pre-existing CODEX-14 xfail and four explicit compiler/native/toolchain deselections.',
        'Old month-only coverage does not record exact historical source revisions; proposed repair only promises detectable drift checks plus current admission.',
        'The broad 83/89-source-path consolidation tips retain uninspected semantic residue outside each stated focus.'],
    branches=branches, still_unselected_original_tips=remaining)
write(PLAN / 'semantic-disposition-batch5.json', result)

source_paths = {'AGENTS.md', 'docs/modules.md', 'pyproject.toml', 'tests/conftest.py',
                'tests/kbc_k5_support.py', 'tests/kbc_k3_support.py', 'tests/kbc_k1_support.py',
                'tests/kbc_k4a_support.py'} | set(current['test_files'])
for row in branches:
    source_paths.update(row['current_paths'] + row['specs'])
    source_paths.update(p['path'] for p in row['source_projection'] if p.get('base_blob'))
source_manifest = {}
for path in sorted(source_paths):
    data = raw(BASE, path)
    target = OUT / 'current-source' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    source_manifest[path] = dict(sha256=hashlib.sha256(data).hexdigest(), bytes=len(data),
                                 git_blob=git('rev-parse', BASE + ':' + path))
write(OUT / 'current-source-manifest.json', dict(source=BASE, tree=snapshot['comparison_tree'], files=source_manifest))
historical_manifest = []
for row in branches:
    paths = {p['path'] for p in row['source_projection'] if p.get('tip_blob')}
    paths.update(p for p in row['changed_paths'] if p.startswith(('docs/specs/', '.github/workflows/'))
                 and subprocess.run(['git', 'cat-file', '-e', row['tip'] + ':' + p], cwd=ROOT,
                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0)
    for path in sorted(paths):
        data = raw(row['tip'], path)
        target = OUT / 'historical-source' / row['branch'].replace('/', '__') / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        historical_manifest.append(dict(branch=row['branch'], tip=row['tip'], path=path,
            retained_path=str(target.relative_to(OUT)), git_blob=git('rev-parse', row['tip'] + ':' + path),
            bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
write(OUT / 'historical-source-manifest.json', dict(note='Exact tip bytes, including changed historical specs/workflows. Full patch files preserve broader deltas; copying a path is not semantic acceptance.', files=historical_manifest))

labels = {
    'retained_focal_scope': 'Retained focal scope', 'confirmed_selective_omission': 'Confirmed selective omission',
    'partially_retained_confirmed_omission': 'Retained foundation; confirmed narrow omission',
    'partially_retained_incomplete_workflow': 'Partially retained; workflow proposal incomplete',
    'partially_retained_research_workflow': 'Partially retained research workflow',
    'partially_retained_ci_workflow': 'Partially retained CI workflow',
    'superseded_by_stricter_current': 'Superseded by stricter current parser',
}
lines = ['# Semantic branch disposition — batch 5', '',
    f'Frozen comparison: **{Q}{BASE}{Q}**, tree {Q}{snapshot["comparison_tree"]}{Q}; actual PR316.', '',
    'This docs-only batch inspects 20 distinct source-bearing original tips selected from the 51 left after '
    'batch4. It confirms three narrow omissions through public current interfaces: saved advisory scope, '
    'unquoted COFF mutation acceptance and A/A failure propagation. Related/inherited branches are not '
    'counted as separate defects. Typed configuration, research final-run/recipe/transfer orchestration '
    'and part of the Windows CI proposal remain incomplete scopes.', '',
    '[Complete machine-readable ledger](semantic-disposition-batch5.json) · '
    '[Sealed exact source and QA](../../qa/semantic-disposition-batch5-20261118.md).', '',
    '## Basis and limits', '',
    f'The original remote inventory observation is {Q}{snapshot["inventory_observed_at"]}{Q}; these are '
    'local fetched-tip comparisons, with no fresh remote/check claim. Each entry records its merge base, '
    'ahead/behind, git cherry patch equivalence, complete changed paths, source blobs, structural comparison, '
    'current caller/spec proof and all-parent ancestral needle history. Copied source is inventory evidence; '
    'only each stated focus is semantically disposed.', '',
    '**100 of 131 original reconciliation tips have selected-scope entries; 31 remain unselected.** '
    'This is not a product percentage or whole-branch completion. The original inventory and branches '
    'are preserved. Broad 83/89-path checkpoint residue is explicit. Later directory, named-source/UI, '
    'highlighter, F8, R2 and follow-up COFF/saved-scope work remains separately attributed.', '',
    '## Twenty exact tips', '', '| Branch | Exact tip | Scoped disposition |', '|---|---|---|']
for row in branches:
    lines.append(f'| {Q}{row["branch"]}{Q} | {Q}{row["tip"]}{Q} | {labels[row["classification"]]}: {row["focus"]} |')
lines += ['', '## Source-level dispositions', '']
for i, row in enumerate(branches, 1):
    origins = []
    for proof in row['source_proofs']:
        for h in proof['history']:
            if h['needle_present_in_commit'] and not h['needle_present_in_first_parent'] and h['sha'] not in origins:
                origins.append(h['sha'])
    lines += [f'### {i}. {Q}{row["branch"]}{Q}', '', '**' + labels[row['classification']] + '.**', '',
        '**Historical delta:** ' + row['historical_behavior'], '', '**Current behavior:** ' + row['current_behavior'], '',
        '**Reachable caller evidence:** ' + row['caller_evidence'], '',
        'Current source: ' + code(row['current_paths']) + '.', '', 'Contract: ' + code(row['specs']) + '.', '',
        'Selected ancestral introduction/replacement records: ' + (code(origins[:5]) or 'exact current blob proofs in JSON') +
        '. Full all-parent needle history, current lines/blobs/SHA256 and merge/patch data are in the JSON.', '',
        'Current test map: ' + code('tests/' + p for p in row['tests']) +
        '. These map to one shared 34-file gate; seven selected nodes and four explicit deselections are listed in its command receipt.', '',
        '**Selective decision:** ' + row['recommendation'], '', '**Residual scope:** ' + row['residue'], '']

lines += ['## Preserved failures and follow-up boundaries', '',
    'The complete original saved-scope file has 40 failures/4 positives. Every node is classified in '
    'historical-result-disposition.json: three tests require superseded revisions to remain authoritative '
    'and conflict with current admission; two missing-source cases already refuse under PT-KBC-INPUT; '
    'four malformed coverage cases raise raw Pydantic exceptions, including repair. Twenty-three '
    'operation nodes return without the expected coverage refusal. Their later write assertions are '
    'not reached; only the separate missing-coverage public probe establishes the actual revision3→5 '
    'mutation. Scoped-digest/cached/direct/empty/month-drift failures are recorded separately.', '',
    'Saved-scope public proof uses actual service reopen, components, local synthetic pair import, '
    'context export and reopened CLI explain. January-only coverage remains while two CVEs are shown '
    'after February is imported. Root assigned a separate repair to report_evidence_review. The '
    'accepted design validates current and selected journal-body revisions before generic repair '
    'mutates attempts; retains global active/withdrawn/ambiguity admission; uses finite cached IDs '
    'including empty; and scopes only newly derived edge digests. Existing month coverage cannot '
    'reconstruct exact historical revision IDs. Pair/file-only flows and old serialized contexts stay compatible.', '',
    'COFF original replay is 2 failures/6 positives. The quoted case first reaches equal masked bodies '
    'then fails only the obsolete jmp emit spelling; current branch normalization is jmp T. The '
    'unquoted case exposes surviving question-mark prefixes. The public fake-producer acceptance '
    'check has 1 failure/3 positives (quoted, real immediate change and unavailable body). Root assigned '
    'a separate narrow grammar repair, with no native compiler claim.', '',
    'Card and recipe replays retain 12/13 failures and 53/52 positives respectively. They distinguish '
    'missing per-card-side case grammar and transfer/train jobs, unimplemented pin-plan guards, '
    'stronger immutable action pins and CLI spelling. The actual sharder --engine argv for all three '
    'engines is accepted by the current --engines parser; no execution bug is inferred from that old '
    'spelling assertion. Historical A/A tests stop before classification because aa-card is absent. '
    'The separate supported aa:<suite> probe writes/reloads/merges actual shard JSON and confirms '
    'two failures/one unchanged positive: nonidentical A/A is omitted from failing_cases. The proposed '
    'repair is A/A-only and must preserve generic findings/noise/mutation behavior.', '',
    'The old preregistration file retains 17 failures/3 positives; eleven fail on an absent private '
    'injection seam before behavior runs, three on an old result field, two on stricter refusal text '
    'and one on an absent owner-signoff argument. Current protocol identity remains independently '
    'tested; final-use approval is explicitly unimplemented. Original default-sort equivalence and '
    '100k-row budget controls both pass, so the missing duplicate fast path is not a confirmed defect.', '',
    '## Actual qualification', '', '| Invocation | Passed | Failed | Skipped | Xfailed | Summary / JUnit seconds |',
    '|---|---:|---:|---:|---:|---|']
for label, r in executions.items():
    lines.append(f'| {label} | {r["passed"]} | {r["failed"]} | {r["skipped"]} | {r["xfailed"]} | {r["summary_seconds"]:.2f} / {r["junit_seconds"]:.3f} |')
lines += ['', 'The current 34-file gate has four explicit compiler/native/toolchain deselections, a Windows-only '
    'runtime-path skip and the existing CODEX-14 Linux full-CLI xfail. Six warnings are deliberate unverified '
    'legacy replay observations. No uninjected backend-pin network fixture was selected. Normal system '
    'temporary fixtures and absolute frozen-source PYTHONPATH were used. All historical originals remain '
    'byte-identical; repeated branch maps and overlapping historical positives are not additive totals.', '',
    'No native/compiler/target/network/provider/acquisition, Windows package, hosted CI, manual GUI, '
    'full integrated suite, merge, deletion or remote mutation was performed. Independent docs review '
    'and selective integration remain root-owned.', '']
(PLAN / 'semantic-disposition-batch5.md').write_text('\n'.join(lines))

body = '''Batch5 inspects 20 further exact source-bearing original tips against frozen actual PR316
55f3d0742f7d4cf32357a42b8b1cc76d85875e71. Current-source gate: 1,129 passed,
one Windows-only skip, one existing CODEX-14 xfail, four explicit compiler/native
deselections. Original historical failures are retained and individually classified.

Confirmed narrow omissions: saved advisory scope/digest (public reopened CLI and
actual missing-coverage mutation), unquoted COFF false-change acceptance (fake
producer) and A/A failures omitted from merged shard provenance (persisted public
flow). COFF and saved-scope repairs have separate root-assigned ownership; no
repair credit is included here. Typed config, final-run/recipe/transfer research
workflows and part of the Windows CI proposal remain incomplete, with native and
platform gates explicit. Earlier continuation repairs are separately attributed.

100 of 131 original reconciliation tips now have selected scopes; 31 remain
unselected. These counts do not close whole branches or estimate feature completion.
See [batch5 ledger](semantic-disposition-batch5.md) and the exact JSON/archive.
'''
append(PLAN / 'consolidation-ledger.md', '## Semantic reconciliation batch 5 — 2026-11-18', body)
append(ROOT / 'docs/plans/patchtrace-completion-matrix.md', '## Semantic disposition checkpoint 5 — 2026-11-18',
    body.replace('[batch5 ledger](semantic-disposition-batch5.md)', '[batch5 ledger](autonomous-consolidation-20261118/semantic-disposition-batch5.md)'))
append(ROOT / 'tasks/todo.md', '## Semantic disposition batch 5 — 2026-11-18', '''
- [x] Inspect 20 further exact original source tips against frozen PR316 55f3; retain original probes, failures, source/ancestry proofs and broad residue.
- [x] Classify all 44 historical saved-scope nodes and hand approved narrow design/evidence to its separate owner.
- [x] Record current 34-file gate: 1,129 pass, one Windows-only skip, one CODEX-14 xfail, four explicit native/compiler deselections.
- [ ] Independently review and selectively retain the docs-only batch5 checkpoint (root-owned).
- [ ] Continue the 31 unselected original tips; no whole-branch closure or native/manual/package acceptance is implied.
- [ ] Track separate COFF/saved-scope repairs and proposed A/A-only failure propagation; retain configuration/final-run/recipe/transfer/Windows-CI residue.
''')
print('Prepared batch5:', counts, 'remaining', len(remaining), 'current sources', len(source_manifest), 'historical sources', len(historical_manifest))
