"""Twenty source-inspected focal dispositions; no production edits or whole-branch closure."""
from pathlib import Path
import json

OUT = Path(__file__).resolve().parent
SNAP = json.loads((OUT / 'snapshot.json').read_text())
ROWS = []
KA = 'docs/specs/known-answer-corpus.md'
CAL = 'docs/specs/calibration-corpus-and-model.md'
WIN = 'docs/specs/windows-acceptance-and-milestone-builds.md'
KB = 'docs/specs/program-e/KB-integration-plan.md'
UE = 'docs/specs/unified-engine/'


def add(number, category, focus, old, current, callers, paths, tests, specs, port, residue):
    ROWS.append(dict(branch=SNAP['branches'][number - 1]['branch'], classification=category, focus=focus,
                     historical_behavior=old, current_behavior=current, caller_evidence=callers,
                     current_paths=paths, tests=['test_' + t + '.py' for t in tests], specs=specs,
                     recommendation=port, residue=residue))


add(1, 'partially_retained_incomplete_workflow', 'Shared typed configuration and build provenance proposal',
    'The source delta adds PatchTraceConfig/ConfigOrigin/CliRunReport contracts, five-layer configuration with dotted get/set/unset, schema/example generation, source digest/build-info helpers and source ZIP/dirty-tree build handling. The branch adds libraries and specification scaffolding; the claimed CLI commands are not a complete implemented current interface.',
    'Current config.py and buildinfo.py, their model types and old tests are absent. Current SPEC-07 enrichment-cli/1 and modular project/compare/doctor/runtime entrypoints implement a different explicit contract. Per-panel bounded QSettings are not the proposed shared configuration layer. Windows builds already use console+hide-early, exact version/commit resources, read-back verification, notices and full-payload provenance; that does not replace the proposed source ZIP/build-info JSON or clean-tree gate.',
    'Current __main__/cli dispatch reaches Qt-free project/compare/doctor modules; the source-pinned CLI gate exercises actual subprocess entrypoints with synthetic inputs/fake backend. build_windows derives VersionFields and checks the frozen PE resources before packaging. Historical check_version_output treated unsupported or non-JSON provenance as warnings, so it must not replace stricter current verification.',
    ['src/patchtrace/__main__.py', 'src/patchtrace/cli.py', 'src/patchtrace/cli_commands/project.py', 'src/patchtrace/cli_commands/compare.py', 'tools/build_windows.py', 'tools/windows_version_info.py', 'tools/check_windows_exe.py'],
    ['cli', 'project_cli', 'compare_cli', 'doctor_cli', 'windows_build_resources'],
    ['docs/specs/cli-umbrella.md', 'docs/specs/cli-project-compare.md', WIN],
    'Keep the current CLI/PE identity contract. Record the typed shared config and fuller source provenance workflow as incomplete proposals requiring their own compatible design; do not copy old models/exit contracts wholesale.',
    'No full CLI equivalence, environment migration, native Windows build, source archive or final packaging acceptance is established. Old config behavior is source-inspected only, with no current production caller.')

add(2, 'retained_focal_scope', 'Extern linkage definitions and mutation usage validation',
    'The small source change finds definitions inside extern linkage blocks, returns usage for an unknown mutation operator, and refreshes the site screenshot helper.',
    'csrc.py and render_screenshots.py are exact current blobs. cmd_mutate validates OPERATORS before constructing a session, while the rest of the CLI contains newer retained-output/report-credit behavior.',
    'Source.locate/by_name is consumed by mutation planning and source inventory; cmd_mutate reaches the guarded CLI dispatcher. Current csrc tests and the unknown-operator CLI control pass. The real compiler and toolchain-probe nodes are explicitly deselected.',
    ['tools/calibration/tier_r/csrc.py', 'tools/calibration/tier_r/cli.py', 'tools/site/render_screenshots.py'],
    ['tier_r_csrc', 'tier_r_eval_cli'], [KA],
    'No port needed for these focal guards. Retain the current CLI output ownership semantics.',
    'Screenshot helper byte identity is not a current visual/browser acceptance run; native compiler mutation and actual engine runs remain unqualified.')

add(3, 'partially_retained_confirmed_omission', 'Normalized output retention, COFF masking and default sorting',
    'LBL31 bundles exclusive normalized output retention, shard artifact transfer/training orchestration, whole quoted/unquoted RIP-reference masking, function-boundary stops and a fast default sort. The old sort patch contains a duplicated fast-path block and must not be copied indiscriminately.',
    'Current OutputStore/evaluate/CLI/train use stronger bounded strict report-credit retention and managed replay. Function boundaries and quoted symbols are retained. Unquoted COFF question-mark symbol prefixes remain unmasked: the exact historical test and independent public acceptance probe reproduce a false semantic-change acceptance. The special default sort fast path is absent, but both original stable-order and 100k-row budget controls pass on current source. training_artifacts.py and the shard train-job transfer workflow are absent.',
    'make_masked_body_check is the apply_case extra acceptance check; the fake producer supplies actual assembly to it without executing a compiler. evaluate retains each normalized result before credit; train.load_outputs verifies managed reports. Read-model sort_rows is used by desktop row selection; original sort control tests current behavior rather than AST equality.',
    ['tools/calibration/mutations/engine.py', 'tools/calibration/tier_r/output_store.py', 'tools/calibration/tier_r/evaluate.py', 'tools/calibration/tier_r/cli.py', 'tools/calibration/tier_r/shard.py', 'tools/calibration/train.py', 'src/patchtrace/unified/read_model.py'],
    ['tier_r_output_persistence', 'tier_r_credited_replay', 'tier_r_credit_completion', 'tier_r_output_stat_compat', 'tier_r_eval_report', 'unified_read_model', 'tier_r_shard'],
    [KA, CAL, UE + '07-ui-and-cli.md'],
    'Root assigned the narrow COFF grammar repair separately. Keep current output-credit/replay and sorting; no measured sort omission warrants a port. Treat training transfer as a separately designed dev workflow.',
    'Historical COFF invocation is 2 failures/6 positives: only the unquoted equality failure is a new defect; the quoted failure is old jmp emit spelling versus current jmp T. No real Windows compiler or native body-equivalence claim. Broader training/native historical failures remain unqualified.')

add(4, 'partially_retained_research_workflow', 'Protocol identity versus single-use final-run wrapper',
    'The branch adds QA-row protocol selection, explicit owner-signoff checks and an exclusive final-locked-test receipt around training, with a rehearsal path. It also inherits LBL31 transfer work.',
    'Current prereg_gate validates exact LF bytes against one visible unambiguous complete Markdown row, then train._run rejects verified-protocol smoke before _inputs. Rehearsal remains a placeholder identity. Current selection intentionally has no verified flag/require_signoff and no _execute_training/final-locked-test wrapper. The module index explicitly calls this identity validation, not approval or a final look.',
    'train._run invokes PG.select before _inputs; current tests include actual small constructed reports and input-access traps. The exact historical file has 17 failures/3 positives: eleven fail while installing an absent private injection seam, three on the old Selection shape, two only on stricter error text and one on absent require_signoff. None proves a protected dataset was accessed.',
    ['tools/calibration/prereg_gate.py', 'tools/calibration/train.py', 'tools/calibration/tier_r/output_store.py'],
    ['train_prereg_selection', 'tier_r_credited_replay'], [CAL, KA],
    'Keep the stricter visible-row identity gate. A single-use final-run/owner-signoff wrapper remains a separate unfinished developer workflow and cannot be implied by identity validation.',
    'No locked corpus, model fit on real data, owner approval, final evaluation or artifact-transfer acceptance was exercised. Historical private seams are not restored merely to make old tests pass.')

for number, wording in ((5, 'a combined whole quoted RIP-symbol regex'), (6, 'a separate quoted-symbol normalization helper')):
    add(number, 'retained_focal_scope', 'Quoted COFF RIP symbols and function-body boundaries',
        'This branch implements ' + wording + ' while retaining local-label and branch-target normalization and explicit COFF function/data boundary stops. Both historical variants still use the restricted unquoted symbol class.',
        'Current _ASM_SYMBOL accepts the whole quoted operand, and _masked_function_asm stops at .Lfunc_end, .seh_endproc, .cfi_endproc, .def, .section, .data, .text or a subsequent function label. An absent private helper in one variant is a refactoring difference. Quoted data-only masking, five original boundary controls, unavailable-body refusal and real-immediate-change positive are exercised. The separate unquoted omission belongs to the broader LBL31 source above, not a newly lost behavior from these quoted-only leaves.',
        'The current factory passes make_masked_body_check into semantic mutation acceptance. The unchanged original controls plus authored fake-producer public check reach this boundary without a compiler.',
        ['tools/calibration/mutations/engine.py', 'tools/calibration/tier_r/factory.py', 'tools/calibration/tier_r/output_store.py'],
        ['tier_r_output_persistence', 'tier_r_credited_replay', 'tier_r_eval_cli'], [KA],
        'No separate port of either quoted-only implementation. Root owns a single narrow unquoted repair; keep current branch/immediate semantics and the newer output store.',
        'Both tips inherit absent training_artifacts/shard-transfer work; that broad residue remains open. The branch names do not establish all COFF/native compatibility. Native compiler output was not generated here.')

add(7, 'confirmed_selective_omission', 'A/A failure credit and per-card side controls',
    'The branch adds aa-card/noise-card side cases, pinned-source fetch ordering, deduplication across shared card revisions and hard failure when A/A reports nonidentical bytes, even with return code zero.',
    'Current sharding retains deterministic bounded case plans, authored-suite A/A/noise and aggregate-only output, but has no per-card-side grammar. Its _classify maps return code 1 to findings; merged failing_cases includes failed/timeout/blocked only. A supported authored aa:<suite> control confirms that nonidentical A/A is persisted as ok/findings and omitted from failure provenance.',
    'The authored public probe runs current make_plan -> run_shard(fake producer) -> write_shard/reload -> merge: two failures (rc0+findings and normal cmd_aa rc1+findings), one unchanged-rebuild positive. Historical original A/A controls fail first on absent aa-card enumeration, so are not counted as direct proof of the classification defect. SPEC-32 section9 requires same-source/same-flags A/A byte identity.',
    ['tools/calibration/tier_r/shard.py', 'tools/calibration/tier_r/cli.py', 'tools/calibration/tier_r/factory.py'],
    ['tier_r_shard', 'tier_r_eval_cli'], [KA],
    'Propose a separate small A/A-only failure classification/propagation repair with persisted shard and merge checks; preserve generic mutation/noise findings. Per-card recipe controls require a separate current plan/caller design.',
    'Original replay is 12 failures/53 positives. The failure list separately includes absent training workflow, an obsolete @v pin expectation and a --engine spelling check that the actual current parser accepts. No compiler, source fetch or native reproducibility evidence.')

add(8, 'partially_retained_research_workflow', 'Recipe-pin A/A/noise enumeration and metadata guards',
    'The branch expands recipe controls to both pins, deduplicates identical project/ref revisions, rejects ref-to-commit collisions/missing metadata and scans refs for hidden Microsoft-derived material before planning.',
    'Current _cards filters buildable recipe/project/license and IDs, then current grammar accepts card/suite/authored aa/noise/mutate. The per-card-side recipe probes and their pin-collision/ref validation are absent. Original tests reproduce plan admission without those guards; they do not prove acquisition or execution because factory/catalogue parsing has its own validation.',
    'Exact original fake-runner replay is 13 failures/52 positives. Current run_shard/merge tests retain deterministic partitions, input validation, aggregate-only material, failed/timeout/block handling and strict merge. The parser observation replays all three emitted --engine vectors through the real current parser successfully.',
    ['tools/calibration/tier_r/shard.py', 'tools/calibration/tier_r/cli.py', 'tools/calibration/tier_r/factory.py', 'tools/calibration/tier_r/contracts.py'],
    ['tier_r_shard', 'tier_r_eval_cli'], [KA, CAL],
    'Keep this as incomplete developer recipe-control orchestration. Recover only after a strict current source-pin/plan design, with no native execution or broad historical transfer port. The A/A classification guard has its own smaller candidate.',
    'Missing recipe plan checks are not claimed as an established source-download bypass. The old workflow train job and transfer module are also absent; native builds/licensed-source acquisition and real corpus acceptance remain separate.')

add(9, 'retained_focal_scope', 'Report-bound normalized output replay and bounded metadata',
    'The consolidation leaf requires successful report credit before managed replay, retains uncredited reports on publication failure, validates normalized output before serialization and propagates bounded name/version metadata into training schemas.',
    'Five of six source files are exact current bytes: CLI, contracts, evaluate, output_store and report_schemas. train.py differs for the newer protocol selection layer, while EngineRun.version still uses the shared maximum and managed output loading still verifies completed report credits. Separate same-API timestamp checks preserve Windows ctime compatibility without accepting mutation.',
    'evaluate finalizes completion/credits only after exact-byte verification; CLI publishes the report exclusively; train.load_outputs rejects invalid managed credit before feature/ranking. Current retention, credit-completion, replay, stat-compatibility and report tests pass together.',
    ['tools/calibration/tier_r/cli.py', 'tools/calibration/tier_r/contracts.py', 'tools/calibration/tier_r/evaluate.py', 'tools/calibration/tier_r/output_store.py', 'tools/calibration/tier_r/report_schemas.py', 'tools/calibration/train.py'],
    ['tier_r_output_persistence', 'tier_r_credit_completion', 'tier_r_credited_replay', 'tier_r_output_stat_compat', 'tier_r_eval_report'], [KA, CAL],
    'No selective source port needed. Retain current report-credit ownership and explicit unverified legacy compatibility.',
    'Constructed providers and models do not establish native adapter compatibility, real calibration accuracy or platform packaging. Stronger generic directory publication remains separately owned continuation work.')

add(10, 'retained_focal_scope', 'Visible complete protocol row and bounded fence-prefix parsing',
    'The leaf replaces substring SHA discovery with complete table cells, preserves escapes/comments/fences and uses only a bounded fence marker prefix. It integrates protocol verification before training input access.',
    'prereg_gate.py is an exact current blob. train._run retains its PG.select call before _inputs, with newer bounded replay integration elsewhere in the file.',
    'The current train_prereg_selection suite tests hidden/fenced/escaped/commented rows, malformed/multiple SHA cells, refusal before reading rows, rehearsal placeholders and actual small report generation.',
    ['tools/calibration/prereg_gate.py', 'tools/calibration/train.py'], ['train_prereg_selection'], [CAL],
    'No port needed for the inspected parser/ordering behavior. Preserve the explicit separation between protocol identity and a final-use approval wrapper.',
    'No final evaluation is authorized or performed by this gate; broad modeling/native corpus work remains unqualified.')

add(11, 'superseded_by_stricter_current', 'Earlier visible-row and inline-code preregistration repair',
    'This earlier repair recognizes visible column-zero rows and avoids misinterpreting comments inside inline code.',
    'Current parser additionally requires complete SHA cells, handles escaped pipe/backtick syntax, refuses unsupported multiline inline code, and orders fence/indent handling before row visibility. The later 9b945 exact current implementation supersedes this older parser rather than omitting it.',
    'PG.select is called before train._inputs; current refusal/visibility/report tests pass. Actual source diff shows stricter _table_cells and _opening_backticks logic, not inferred equivalence from the remediation name.',
    ['tools/calibration/prereg_gate.py', 'tools/calibration/train.py'], ['train_prereg_selection'], [CAL],
    'Do not port the weaker old parser. Retain current complete-cell/escape/visibility behavior.',
    'The absent single-use final-run wrapper is separately documented and is not repaired by either parser leaf.')

add(12, 'partially_retained_research_workflow', 'Retain completed research-build matrix on receipt write failure',
    'The final commit preserves a completed build matrix under the error receipt when exclusive receipt publication raises, instead of discarding the matrix. It inherits four R1 research harness modules and build/factory/label provenance work.',
    'The four research_audit/build/observers/pilot modules are absent, as already identified in batch4. The final receipt-preservation behavior therefore has no current production caller. Current build.persist_build_record, factory source_dirs and authored label logic retain the separately reviewed foundation, with stronger publication behavior.',
    'Current Session.build persists a validated build record and carries source directories into side analysis. The offline build-receipt controls pass. Historical main at 8c9 explicitly adds receipt=None and embeds the completed receipt only after build_pilot returns; no historical build was executed.',
    ['tools/calibration/tier_r/build.py', 'tools/calibration/tier_r/factory.py', 'tools/calibration/tier_r/labeler.py', 'tools/unified/live_pairs.py'],
    ['tier_r_build_receipts_r1'], [KA, UE + '08-evaluation.md'],
    'If the R1 research runner is reintroduced under a separate approved design, retain this completed-matrix failure receipt. No current production port or wholesale research merge.',
    'This is the same broader R1 absence first recorded in batch4 with one additional leaf-level failure-preservation fix. Compiler/tool probing, native labels, real matrix results and receipt race safety were not qualified here.')

add(13, 'retained_focal_scope', 'Rizin native callback uses the API size_t signature',
    'The unique final source change replaces int len with size_t len on the RzIOReadAt callback in the native harness.',
    'Current read_bytes and the newer read_distinct callback both use size_t. The retained boundary control and singleton producer patch are exact old blobs; current harness adds stricter native matrix/I-O coverage validation and immutable receipts.',
    'native_control assigns read_bytes/read_distinct to the actual API read_at slot. Python native_evidence validates authored output matrices, wrong exits, partial output and output ownership. Those fake/pure controls pass; the C compile-and-execute oracle is explicitly deselected.',
    ['tools/rzdiff/native_control.c', 'tools/rzdiff/native_evidence.py', 'tools/rzdiff/patch_producer.py', 'tools/rzdiff/boundary_control.c', 'src/patchtrace/secondary/rzdiff.py'],
    ['rzdiff_native_evidence', 'rzdiff_io_evidence', 'rzdiff_producer_patch'], ['docs/specs/secondary-engine.md', UE + '06-adapters.md'],
    'No port required for callback signature. Preserve the current production singleton quarantine and dual source-identity patch checks.',
    'The broad 89-path checkpoint includes many previous-batch features and absent research helpers. Only this callback plus producer/receipt boundary is semantically disposed here; no native ABI/library build or quarantine release claim.')

add(14, 'retained_focal_scope', 'Pinned singleton producer ownership correction and bounded harness',
    'The historical producer patch swaps singleton unmatched ownership into the requested A/B orientation; the harness uses pinned source and isolates boundary/native API compile commands from application fixtures.',
    'singleton-ownership.patch and boundary_control.c are exact current blobs. patch_producer.corrected now requires both the pinned Git blob and SHA256, with usedforsecurity=False for Git SHA1 compatibility. Current production parse still refuses singleton orientation where the raw source cannot substantiate ownership; a local producer patch is not automatically trusted application evidence.',
    'The CLI patch path verifies source before generating corrected bytes; fake/pure refusal tests cover unverifiable source, SHA1-only authority and security-disabled SHA1 compatibility. Native evidence tests verify output and exit-status agreement without calling native code.',
    ['tools/rzdiff/patch_producer.py', 'tools/rzdiff/singleton-ownership.patch', 'tools/rzdiff/boundary_control.c', 'tools/rzdiff/native_evidence.py', 'src/patchtrace/secondary/rzdiff.py'],
    ['rzdiff_producer_patch', 'rzdiff_native_evidence', 'rzdiff_io_evidence'], ['docs/specs/secondary-engine.md', UE + '06-adapters.md'],
    'Retain current producer/source checks and runtime quarantine; no selective whole-branch merge.',
    'Native compiled matrix, concurrency/real I-O observations, ABI compatibility and the 89-path inherited consolidation remain broader unqualified residue. No compiler, upstream source acquisition or target was executed.')

add(15, 'confirmed_selective_omission', 'Saved KB advisory scope and selected-document context identity',
    'The broad checkpoint introduces saved coverage validation and a restricted index before later KB lookups/context. It also carries earlier creation/F8/raw/callgraph/UI/research changes already addressed or classified in previous batches.',
    'Current _stored_scope returns None for cached or absent coverage; ReverseIndex._select ignores cached doc_ids; build_bundle derives its key from all active edges. The actual public flow gains a February CVE after a January-only saved search and still displays the old coverage. Missing coverage lets components advance revision 3 to 5. Month/file/mixed selected displays remain scoped but whole-corpus digest changes. Current global active/withdrawn/ambiguous source admission must not be weakened by the historical restricted-index approach.',
    'The unchanged 44-node original scope file is 40 failures/4 positives, all classified. The authored public test uses actual reopened service, components, local synthetic pair import, context export and reopened CLI explain: 2 failures/1 positive. Direct builder and repair boundaries are separately traced; generic repair mutates attempts before context_for, requiring service preflight of current and journalled revisions.',
    ['src/patchtrace/kbcorrelation/service.py', 'src/patchtrace/kbcorrelation/context.py', 'src/patchtrace/kbcorrelation/index.py', 'src/patchtrace/kbcorrelation/contracts.py', 'src/patchtrace/kbcorrelation/sources/scope.py', 'src/patchtrace/kbcorrelation/recovery.py'],
    ['kbc_scope', 'kbc_scope_retained', 'kbc_index', 'kbc_context', 'kbc_service'], [KB, 'docs/specs/kb/advisory-revision-and-snapshot-identity-spec.md'],
    'Root assigned a separate spec/test-first repair to report_evidence_review: service/context/index plus pure helper. Preserve finite cached IDs including empty, validate key/body/recomputed coverage identity before mutations, keep full-index admission, scope new derived edge digests and preserve old serialized contexts. Approved concrete design is saved-scope-design.md.',
    'Three historical tests require authoritative superseded snapshots and must not be restored. Existing month coverage does not capture exact historical revision IDs; only detectable drift is covered by the narrow design. All 83 source paths are mechanically inventoried, not semantically closed. Previous directory/named/UI/highlighter/F8/R2 fixes remain separately attributed.')

add(16, 'partially_retained_ci_workflow', 'Windows build/validation job split and release-note asset provenance',
    'The leaf separates Windows package build from validation of downloaded uploaded bytes, keeps per-PR gates, narrows cancellation to superseded PRs, pins release actions and adds Setup.exe to release-note asset hashes. Its installer checksum helper writes LF bytes.',
    'package_windows_installer.py is exact current bytes and LF sidecars are retained. Current qa-windows still uses the earlier OS matrix, builds/smokes/installs before upload, and does not use the proposed separate Windows package/validate jobs. Release re-verifies portable and Setup hashes, but milestone_notes.ASSET_NAMES lists only the versioned ZIP and Linux archive, so the old Setup note entry is not retained. The original CI scheduling/provenance proposal is only partly incorporated.',
    'qa-windows invokes build_windows, frozen_smoke, portable and installer checks, then uploads those files. The release step downloads/re-hashes Setup and portable bytes. Current package-manifest, release-gate and milestone-note unit controls pass; they do not assert the missing historical DAG or Setup asset note.',
    ['tools/package_windows_installer.py', 'tools/milestone_notes.py', '.github/workflows/qa-windows.yml'],
    ['windows_installer_manifest', 'milestone_notes', 'release_gate', 'codex_pkg_packaging'], [WIN],
    'Keep current hash verification. Record the unretained Windows job split/cancellation policy and Setup asset-note entry for a separate CI design; preserve required gate names and actual current action pins. No wholesale old workflow port.',
    'This source inspection does not prove a bad shipped artifact or measure CI speed. Hosted/native Windows validation and CODEX-14 Linux full CLI acceptance remain open; existing xfail is retained.')

add(17, 'retained_focal_scope', 'Strict backend manifest and explicit release license-policy gate',
    'The branch validates the backend payload, enumerates the allowed GPL-family components and preserves a refusal when any required release approval is pending. It records the repository owner approval for Temurin while keeping withdrawn-approval negatives.',
    'Current pin/checker/builders retain explicit license-policy validation, reject undeclared GPL payload, require resolved release hashes and verify the complete manifest tree before attachment. Newer component versions/pins and stricter placeholder/symlink/path rules account for source differences. No new licensing determination or approval is made by this review.',
    'build_windows reuses build_linux.attach_backend; that checks manifest_problems/license_problems and release pending status before copying. Four explicitly selected FakeWorld builder controls and current pin/full-variant tests pass. The known uninjected CLI placeholder network fixture and real pip/build nodes are not selected.',
    ['tools/check_backend_pin.py', 'tools/backend_pin.json', 'tools/build_backend_bundle.py', 'tools/build_linux.py', 'tools/build_windows.py'],
    ['backend_pin', 'backend_pin_strict_20261105', 'build_full_variants', 'codex_pkg_packaging', 'build_backend_bundle'], ['docs/specs/program-e/BUNDLE-runtime-policy-spec.md', 'docs/specs/offline-backend-installer.md'],
    'No selective port indicated for the inspected policy/manifest boundary. Preserve current exact pins and refusal states.',
    'Fake component builds do not prove actual third-party/native compatibility, a legal compliance conclusion or completed distribution acceptance. The package/native gates remain explicit.')

add(18, 'retained_focal_scope', 'Per-user Windows setup, safe uninstall manifest and portable alias',
    'The tip adds pinned NSIS setup packaging, repository-anchored path components, portable/installed smoke scripts and a canonical Portable.zip alias with verified SHA256.',
    'Both PowerShell validation scripts are exact current blobs. Current NSIS helper retains repository-root path handling and explicit bundled-file-only uninstall commands with literal dollar escaping, nonrecursive directory removal and symlink refusal; Setup checksum now uses explicit LF bytes. Release creates and checks the canonical Portable.zip alias from the verified versioned ZIP.',
    'qa-windows invokes package_windows_installer after building the frozen distribution and runs both PowerShell validators. Unit manifest controls verify user-created files are outside uninstall deletion and path escaping. Workflow references are source evidence only, not an executed Windows acceptance claim.',
    ['tools/package_windows_installer.py', 'tools/test_windows_installer.ps1', 'tools/test_windows_portable.ps1', '.github/workflows/qa-windows.yml'],
    ['windows_installer_manifest', 'codex_pkg_packaging'], [WIN, 'docs/specs/windows-release-signing-policy.md'],
    'No port needed for focal setup/alias behavior. Retain current checksum and uninstall safeguards.',
    'No NSIS compiler, installer, SmartScreen/signing, rollback, uninstall or native Windows GUI execution occurred here. Source equivalence cannot close those gates.')

add(19, 'retained_focal_scope', 'Exact executable/icon identity and exclusive resource staging',
    'The source delta generates deterministic icon/version resources, checks PE resource identity, preserves the owner mark bytes, hides only an owned console and uses exclusive adjacent temporary staging for resource generation.',
    'Eight of nine production/tool files are exact current blobs, including __main__, app_icon/mark, Windows icon/version/readback helpers, PyInstaller icon hook and build_linux. build_windows differs due later dependency/payload checks, while retaining console hide-early and exact read-back verification. Temp resource writers retain exclusive adjacent files and explicit cleanup.',
    'build_windows derives the version/commit quad, writes icon/version resources, freezes, then check_windows_exe.problems validates exact fields and nonempty language-bound icon data. Current synthetic PE/resource/Qt controls pass; no native executable was launched.',
    ['src/patchtrace/__main__.py', 'src/patchtrace/app_icon.py', 'src/patchtrace/resources/patchtrace-mark.svg', 'tools/build_windows.py', 'tools/check_windows_exe.py', 'tools/windows_icon.py', 'tools/windows_version_info.py'],
    ['windows_build_resources', 'build_full_variants'], [WIN, 'docs/specs/windows-release-signing-policy.md'],
    'No selective port needed. Preserve current strict PE identity and resource publication behavior.',
    'Synthetic PE decoding and Qt asset construction do not establish Explorer icon cache, native high-DPI appearance, signed publisher identity or real Windows packaging acceptance.')

add(20, 'retained_focal_scope', 'Verified offline runtime import and private JDK discovery',
    'Despite its temporary access-test name, the real source-bearing history imports a verified offline runtime, discovers installed private layouts, configures Java without global environment mutation and rejects archive collision/device/traversal hazards.',
    'Current runtime discovery remains bounded and non-executing; installed layouts are discovered with explicit precedence. backend build_child_env/_environment pins the selected private Java bin and JAVA_HOME_OVERRIDE and clears conflicting inherited settings. Offline import uses strict shared manifest/tree verification and the desktop TaskRunner preview/consent/install flow. The removed access-test marker is not treated as the behavior.',
    'RuntimeDialog.discover_existing and import_offline_bundle call the current bounded discovery/import helpers; installed configuration is applied only after a successful verified install. Current runtime discovery and doctor controls pass. Broader manifest/publication code is also retained by source comparison with the prior batch4 offline-runtime disposition.',
    ['src/patchtrace/runtime_discovery.py', 'src/patchtrace/backend.py', 'src/patchtrace/backend_bundle.py', 'src/patchtrace/offline_bundle.py', 'src/patchtrace/ui.py', 'tools/make_offline_bundle.py'],
    ['runtime_discovery', 'runtime_discovery_bundle', 'doctor_cli', 'build_full_variants'], ['docs/specs/runtime-discovery.md', 'docs/specs/offline-backend-installer.md', 'docs/specs/program-e/BUNDLE-runtime-policy-spec.md'],
    'No new product port for the inspected discovery/private-JDK behavior. Keep the separately reviewed newer directory-publication fix distinct from this frozen comparison.',
    'The other remaining access-test alias has the same Git tip and is not counted as inspected in this batch. Its later disposition must explicitly cross-reference this proof. Native JDK/Ghidriff compatibility and actual frozen desktop setup remain unqualified.')

assert len(ROWS) == 20
(OUT / 'dispositions.json').write_text(json.dumps(ROWS, indent=2) + '\n')
print('Wrote', len(ROWS), 'scoped dispositions')
