# SPEC-31 / 08 Evaluation: gates, corpora, parity harness, tests, performance

Status (2026-10-14, slice S6a built; docs/modules.md [S6a:corpus-gates]): the Tier R catalogue (`tools/unified/corpus`: recipes for libpng, Lua and mbedTLS beside SPEC-32's zlib, release cards, source digests), the A/A pairs P0, P1 and P2, and the 12 planted-mutant classes (`tools/unified/mutations`) are built ON the SPEC-32 factory (`../known-answer-corpus.md`), not as a second factory. The G-U5 bench (`tools/unified/bench.py`), the dispatch-only advisory workflow `unified-corpus.yml` and the gate-report skeleton (`tools/unified/gates_u.py`, `gate-report/1`) exist. Pending: G-U1, G-U2, G-U4, G-U6 and G-U7 need the S3 verdicts; G-U3 also needs the IR-to-ladder adapter (its BinDiff oracle part is blocked on the pin); G-U5 and G-U8 are evaluated from what exists and stay pending on S3 and S4 (and the Windows run). Not built: P1 nuisance variants other than link order (ICF toggle, timestamp, GUID, path need a link-flag field on the SPEC-32 `BuildSpec`), the mutant classes `moved-rva-call` and `try-scope`, sqlite (its tree needs generated sources), single-commit CVE-fix pairs. The header below says every gate must pass before the flag defaults on while U-05 (00-decisions) names G-U1..G-U6; the gate report follows U-05 and reports all eight. The `features/2` text of A-07 is `12-features2-proposal.md`.

Status (2026-10-15, slice S6b): the evaluators of G-U1, G-U2 and G-U4 are built (`tools/unified/evaluators.py` over `unified-outcomes/1`, written by `tools/unified/live_pairs.py`), the G-U8 UI-policy check names its S4 tests, and `unified-live-gates.yml` runs the pipeline live on Linux and Windows over the same image bytes. G-U3, G-U6 and G-U7 stay pending (adapter and pinned BinDiff, SPEC-32 evaluation core, rows with atoms); no gate has run live yet.

Status (2026-10-15, slice S6c): all of G-U1..G-U7 have evaluators over `unified-outcomes/1`; no gate has run live yet, so none has a verdict on real data. G-U1 gained the P1 nuisance variants (`BuildSpec.nuisance`: `icf`, `timestamp`, `guid`, `path`, beside link order; the gate stays `pending` for any kind with no pair in the manifest). G-U4 gained the 3-build chain (P1 chains `corpus aa` builds from A, B, C; release triples count once the catalogue has a third version) and the COS-PSEUDO cross-tier check. G-U3 (`rowgates.g_u3`): precision >= 99.5 % with a lineage-cluster lower bound >= 99.0 % (fewer than 30 lineages is `insufficient-data`), 0 truth-contradicted tier-A pairs and Ghidriff exact pairs matched or contested on A/A, per-pass table with `demote`; its BinDiff oracle part is not run, so a G-U3 whose data pass reports `blocked` and the flag decision cannot become ready until `tools/bindiff_pin.json` is provisioned. G-U6 compares per legacy tool (only Ghidriff `modified` is wired; BinDiff and rz-diff are reported as not supplied). G-U7 counts rows supported by exactly two tier-B atoms per (component pair, evidence-class pair) and reports classes under 30 rows as `insufficient-data`, which keeps the gate from passing. `gates_u --inputs DIR` assembles the single report (status, numbers and intervals per gate, the O2 decision line) that the dispatch-only `unified-live-gates.yml` writes after a Linux and Windows run of the pairs and of every mutant class, a bench report and the G-U8 tests of both systems. The frozen-smoke attestation is not produced by that workflow, so G-U8 stays `insufficient-data` there.

Rule (AGENTS.md): mocked/fake tests are never live evidence; live and corpus results are recorded in `docs/qa.md` in their own table with OS, tool versions, input hashes and run URL. Gate targets marked [inf] are proposals to preregister before the first locked run (method: `../calibration-corpus-and-model.md` s2, s4, s9: lineage-grouped splits, cluster bootstrap B = 2000). Owner slice S6 (corpus, harness), every slice owns its unit tests.

## 1. Gates (all must pass before the feature flag defaults to ON, U-05)

G-U1 requires coverage of every labelled older and newer RVA in each outcome, bound to the manifest's label digest.
The manifest records the unique expected RVAs per side; aliases share one RVA, and merged/group rows cover all of
their endpoints. Row counts alone cannot establish coverage. Missing endpoints, a label-digest mismatch, or a legacy
manifest without endpoint coverage metadata make the data insufficient; an observed verdict violation still fails.

| Gate | Question | Metric and threshold | Data | First slice able to run it |
|---|---|---|---|---|
| G-U1 A/A null | does the engine invent changes? | X vs X: 100 % `unchanged`, 0 contested, 0 one-sided; P0 (same commit rebuilt): 0 `material`, `review` <= 0.1 % of rows [inf]; P1 nuisance (link order, `/ORDER`, `/OPT:ICF` toggle, timestamp/GUID/path): 0 `material` | Tier R A/A recipes (s2) | S3 (S0b for X vs X) |
| G-U2 planted mutations | does it see real changes, and never hide them? | leakage into `cosmetic`/`unchanged` = 0 (every hit is a normaliser bug and becomes a fixture); recall (`material` or `review`) >= 95 % per class with >= 20 mutants per class [inf]; frame-only and trace-arg mutants must land in `review` (never cosmetic) | classes: constant, comparison operator, bound (`<`/`<=`), signedness (`jl`/`jb`), removed check, swapped callee (same shape), struct offset, added block; review additions (each targets a hole the draft had, R-01..R-04, R-07, R-16): swap to an EXISTING global with the same instruction shape, index-register swap inside an address operand, then/else successor swap, identical bytes at a moved RVA whose relative call now reaches another function, added `__try` scope (scope table only), buffer resize (frame only) | S3 |
| G-U3 L1 precision and parity | are `matched` pairs right? | Tier R truth: matched-pair precision >= 99.5 %, cluster-CI lower bound >= 99.0 % [inf]; 0 truth-contradicted tier-A pairs on A/A; per-pass precision table (a pass with CI lower < 98 % is demoted one tier); BinDiff oracle when installed: MD index equal to 12 decimals on >= 99.9 % of functions with `n_bb` >= 5 (R02 s14 G1), >= 98 % agreement on BinDiff tier A/B pairs (G2); Ghidriff: every SymbolsHash/ExactBytes pair of an A/A run is `matched` or contested with a recorded reason | Tier R, oracles | S2 |
| G-U4 metamorphic | is it deterministic and symmetric? | byte-identical `manifest.json` (minus `created_utc`) for: two runs, Linux vs Windows CI, input record permutation; swap older/newer -> mirrored rows (older-only <-> newer-only, same matched set); 3-build chain: cosmetic(A,B) and cosmetic(B,C) never with material(A,C) on P1 chains; a cheap-tier semantic delta never coexists with `COS-PSEUDO` | synthetic IR + Tier R | S0b / S3 |
| G-U5 performance | does it fit a 60k-function image on a laptop? | L-35 targets on generated IR (10k, 60k, 250k functions) and on the largest Tier R pair; Windows frozen run included; failures trigger B-05/B-06 | `tools/unified/bench.py` | S2 / S5 |
| G-U6 noise vs legacy | is it worth it? | `material` false leads >= 20 % fewer than the best single legacy output (Ghidriff `modified`, BinDiff flags != 0, rz-diff non-identical) at non-decreasing planted recall (R05 s7) [inf] | Tier R planted + A/A | S3 |
| G-U7 independence assumption | is narrowed A-IND-1 safe? | per (component pair, evidence-class pair): error rate of rows `matched` via B+B must not exceed the error rate of tier-A rows by more than 2x (cluster CI); a failing class pair is joined by configuration (no code change); classes with < 30 B+B rows are reported `insufficient-data`, never assumed safe | Tier R | S3 |
| G-U8 integrity and safety | did we break anything? | primary snapshot SHA unchanged by unified runs; old-reader test; schema drift CI; no socket opened during a full unified run (`sys.addaudithook` on `socket.connect` in tests); extractor script AST has no network/subprocess imports; tooltips, accessibility, banned words; frozen smoke | CI | every slice |

## 2. Corpora (no Microsoft binaries in the repository, ever)

| Tier | Content | Truth | Location |
|---|---|---|---|
| Unit | hand-built IR tables (`tests/unified_ir_builder.py`), hand-assembled x86-64 byte snippets with documented encodings (cosmetic: RIP-displacement shift, global moved, block reorder with jcc inversion, thunk insertion; material: constant, comparison, callee, struct offset; review: frame-only, register rename, unmapped global), synthetic Ghidriff JSON and secondary sets | exact by construction | `tests/fixtures/unified/` |
| Live probe pairs | clang `--target=x86_64-pc-windows-msvc` + `lld-link /dll /noentry /nodefaultlib` C pairs and `nasm -f win64` functions (MSVC-style RVA jump table), the recipe the review used (11-review-log s2); runs on Linux and Windows CI with no MSVC | source | CI artifact only |
| CI fixture | `tests/fixtures/old.c` / `new.c` built to a DLL pair in CI (MinGW / clang-cl), as for live-rizin | source | CI artifact only |
| Tier R | zlib 1.3 -> 1.3.1 (R03 measured: 138 functions, 81 byte-identical, 51 address-noise-only, 3 genuine changes + 1 padding variant), libpng, sqlite, lua, mbedTLS adjacent tags and CVE-fix commits; clang-cl, mingw-w64, MSVC on Windows runners; PDB kept for truth, engines run symbols-hidden (SPEC-28 calibration s5.2) | debug info + source token diff of each function (L2: edited / induced / unchanged) | recipes + expected SHA-256 in `tools/unified/corpus/`; binaries only as CI artifacts |
| A/A | P0 same commit rebuilt (`/Brepro` where available), P1 nuisance flags, P2 stress (`/O1 /O2 /Ob /GL /Gy`, clang levels) expected `induced`, reported not gated | rebuild = no semantic change | same |
| Tier W (local only) | Winbindex pairs via `acquisition/`; anchors from R05 s1: ntoskrnl 10.0.22621.1344 -> 1413 (CVE-2023-23420), afd.sys 10.0.22621.1028 -> 1415 (CVE-2023-21768) | PDB names (symbols-hidden runs), manual adjudication | `PATCHTRACE_CALIB_ROOT`; results recorded by hash in `docs/qa.md`; corpus guard of `tools/calibration/corpus.py` reused |
Anchor acceptance on Tier W (reported, not CI): the patched function lands in `material` or top-10 `review`; each Ghidriff non-code `modified` row gets a recorded reclassification (R05 s0.2).

## 3. Labels and leakage
Function identity truth per `calibration-corpus-and-model.md` s5 (symbols-hidden rule, ICF/static-name pitfalls from `../../research/phase-c/matching-calibration-ground-truth.md` s3); L2 labels `unchanged-bytes | cosmetic | edited | induced | unknown` (R05 s7). Splits and intervals are by lineage; thresholds (demotions, G-U7 switch) are chosen on dev lineages only and frozen before any locked evaluation.

## 4. Parity harness (`tools/unified/parity.py`, dev only)
Inputs: one project with a unified result, optional `.BinDiff` + `bindiff --md_index` dumps (produced only by this dev tool with its own argv; product argv keeps `--md_index` forbidden, C-21), Ghidriff raw JSON. Output `parity-report.json` (deterministic): per pass: pairs, agreement with each oracle, disagreements listed by RVA pair with both provenances; MD index comparison histogram (exact / differs at 1e-12 / missing); Ghidriff pairs not reproduced, grouped by `match_types`; BinDiff pairs not reproduced, grouped by algorithm. Use: G-U3, and diagnosing parity drift (troubleshooting T-14). Ghidra-parity bonus: the extractor's optional Ghidra hasher values (03 s4) must induce the same equivalence classes as `h0` (ExactBytes) and `h3` (ExactInstructions) on every function (`test_live_h3_matches_ghidra_exact_instructions`, live only).

## 5. Red/green test list per module (unit tests are pure and fast; live tests are separate workflows)

| Module | Tests (red first, then green) |
|---|---|
| contracts / keys / limits | schema round trip and strictness; invalid examples of 02 s8 rejected; `result_key` changes with each input (parametrised over every payload field); swapped orientation -> different key; limits digest stable |
| store | publish requires verified parts; crash between dir move and row publish leaves an orphan removed by the next publish; retention keeps L-32 and never touches other kinds; `test_unified_rows_survive_enrichment_retention`; `test_old_reader_ignores_unified_kinds`; missing sidecar -> U6 not a crash |
| addressing | VA/RVA/auto/mixed; `EXTERNAL:` keys; address outside image dropped and counted |
| extract/runner, ir/* | 03 s10 list |
| sources/* | 06 s9 list |
| ladder/* | 04 s9 list |
| fusion/* | 05 s1.4 list |
| facts/* | 05 s3 table tests; 05 s2.7 DATA-MAP tests; `test_constant_only_patch_is_review_ranked_first`; `test_constant_only_patch_promoted_only_with_anchored_c6`; `test_cos_addr_requires_tier_a_targets`; `test_unchanged_requires_target_consistency`; `test_then_else_swap_not_cosmetic`; `test_material_needs_anchored_second_channel` (an unrelated C6 difference never promotes); `test_scope_table_change_blocks_unchanged`; alignment cap -> review |
| pipeline / worker | `test_unified_run_never_mutates_project_snapshot`; `test_cancel_keeps_previous_result`; `test_worker_output_is_validated_before_publish`; `test_asymmetric_ir_falls_back_to_s0`; partial status propagation |
| read_model / ui_unified / cli | 07 s11 list |
| security (01 s9) | `test_no_network_during_unified_run` (audit hook), `test_children_get_absolute_argv_and_private_cwd`, `test_script_copied_to_empty_dir`, `test_paths_to_ghidra_have_no_dot_components`, `test_hostile_names_never_rendered_as_rich_text` |
| prerequisites (DONE) | P1 `test_concurrent_run_process_calls_do_not_cross_pipes_or_leak_threads` (tests/test_binexport_isolation.py: 8 short children beside an 8 s child finish in < 7 s, outputs never cross); P2 `test_raw_ghidra_external_locations_are_skipped_not_fatal` (tests/test_nway_graph.py, ce108cd); follow-up P2b `test_nway_external_skips_are_counted` |
Parametrised ids stay short (a 64 MiB parameter id once stalled the Windows console for 18 minutes, docs/qa.md).

## 6. Performance harness (`tools/unified/bench.py` + marked tests)
Generated IR at 10k / 60k / 250k functions with realistic degree distributions (power-law callers, 1-5 % changed functions, 0.5 % duplicates) measures: ingest time and RSS (fresh process), ladder time per stage, facts time for N changed pairs, read-model build, `data()` call counts for first paint/sort/filter at 10k and 100k rows. Gate: L-35 with 5x wall-clock slack on CI, exact call-count gates (C6 method). Windows numbers come from the Windows CI runner and the frozen EXE; they are recorded, never extrapolated from Linux. Baseline from the review's scratch prototypes [own, Linux, 2.1 GHz vCPU; not CI evidence]: ingest 28.9 s / 304 MiB and ladder core 0.4 s at 60k functions; the extractor's JPype dump (68-70 us per instruction) is the largest cost, so `bench_extract` on the live fixture is part of G-U5.

GT12 harness completion (2026-11-01): `facts` measures context construction plus channel collection and judgement
for 5,000 distinct changed pairs over real ingested, synthetic x86-64 IR; input generation and ingest are recorded
separately. `read_model` loads strict persisted rows and facts at 10k/100k, with varied names, changes and source
cells; build time is informational (L-35 has no separate read-model budget). `ui_calls` loads that same varied model
before timing the production Qt table's model assignment through actual viewport paint, then sort and selective
filter through paint. First-paint/sort/filter time gates apply at 100k only, with the existing 5x slack; at 10k and
100k each operation has the C6 exact ceiling `floor(7 * visible cells * 1.2) + 20` and cross-size call growth is
checked. Offscreen paints are synthetic Linux/Qt observations, not Windows, display-server latency or scrolling
acceptance. Missing required stage/size measurements remain explicit in `pending`; implementing a stage does not
make an unrun measurement pass. Every generated measurement, including a failed child, retains its seed and
requested instruction count for replay. Small smoke sizes remain informational. No L-35 value changes.

## 7. CI placement

| Workflow | Runs | Counts as |
|---|---|---|
| `qa-windows.yml` (existing; Linux + Windows) | all unit tests, ruff, schema drift, frozen smoke incl. `unified --help` and `unified _worker --self-check` | automated evidence |
| `live-unified.yml` (new, dispatch + path filter) | extraction on the CI fixture DLL pair with Ghidra 12.0.4 (Windows + Linux), determinism across OSes, parity vs Ghidriff | live evidence (qa.md table) |
| `unified-corpus.yml` (new, dispatch/nightly) | Tier R builds, A/A, planted mutations, G-U1..G-U7 report | corpus evidence (report SHA in qa.md) |
| `unified-live-gates.yml` (dispatch only, advisory) | the whole pipeline on Tier R, A/A and every mutant class on Linux and Windows over the same image bytes, bench and G-U8 tests of both systems, then `gates_u --inputs` | live evidence: `gate-report/1` SHA and run URL in qa.md |
| `live-bindiff.yml` (existing) | adds MD dumps for G-U3 when a pinned BinDiff is provisioned | blocked until the pin exists (qa.md) |

## 8. Dev-only artifacts of the evaluation tools (slice S6a)
Strict pydantic models, deterministic JSON (sorted keys, LF, no timestamps), never shipped, never read by `src/`. Corpus building reuses the SPEC-32 factory (`../known-answer-corpus.md`); these contracts are the SPEC-31 view on top of it.

| Contract | Tool | Content |
|---|---|---|
| `unified-corpus-pins/1` | `tools/unified/corpus/pins.json`, `catalogue.py` | per case-card id, the SHA-256 of the old and the new pinned source tree (lines `<file sha256>  <path>` of every regular file, sorted, symlinks never followed, `.git` and the fetch receipt left out); toolchain independent; `fetch` reports `PT-UC-PIN` on a difference. Image hashes are not pinned: they differ per compiler version and live in the reports |
| `unified-corpus-manifest/1` | `tools/unified/corpus/manifest.py` | facts per label document, no threshold: role (`release`, `cve-fix`, `control`, `P0`, `P1`, `P2`, `mutation`), the gates it feeds, image digests, label digest, function counts, `x_vs_x` (the two images are the same bytes), for a mutant its class, planted function and accepted verdicts; `ignored` (strata that belong to SPEC-32 alone) and `pending` (work that cannot be built yet, with the reason) are listed, never dropped; `manifest_sha256` |
| `bench-report/1` | `tools/unified/bench.py` | one row per (stage, size): seconds, fresh-process peak RSS, counts, gates and checks; L-35 with 5x time slack and none on memory, only at defined sizes (ladder 10k/60k, ingest and worker memory 60k, facts 5k, UI 100k); `read_model` timings informational; missing required facts/read/UI sizes stay `pending`; gate units `s`, `ms`, `bytes`; environment records source commit and tracked dirtiness; `counts_sha256` excludes timings/RSS and includes fixture digests and observed Qt calls (compare on the same Qt/platform configuration) |
| `gate-report/1` | `tools/unified/gates_u.py` | one row per gate with a status, reasons, what it needs and observed facts; statuses: `pass` and `fail` are verdicts on data, `insufficient-data` means the data cannot decide, `pending` means a slice that is not built, `blocked` means something outside the code (a pinned BinDiff, a Windows runner); inputs with their SHA-256; `flag.decision_ready` is true only when G-U1..G-U6 pass (U-05); `report_sha256` |

Rules: a gate that cannot run is never `pass`; a skipped required test is `blocked`, not a pass; G-U8 maps each of its checks to named tests (the tool's test keeps the names real); the planted-mutant classes are `tools/unified/mutations/classes.py`, tied to the G-U2 row by a test; the report is advisory (exit 0) unless `--strict`. JSON Schemas for these four contracts are not generated.


## GT-01 native A/A gate: opt-in identical-input comparison (2026-10-30)

The normal application preserves its existing identical-hash shortcut and reports
`identical`, not a completed analysis. The dev-only unified-live-gates harness may
opt into a **genuine native** Ghidriff comparison when the labelled older/newer
images have exactly equal SHA-256. In that case it disables cached raw analysis,
passes the pinned Ghidriff `--force-diff` switch, and gives the copied images
side-distinct basenames without changing their bytes. Distinct basenames are
required by the observed Ghidra ProgramDB transaction failure in R1 PR #128
(`docs/research/ground-truth-corpus/results/native-aa-control.md`).

An A/A result can enter the acceptance denominator only after actual successful
native exit, raw JSON ownership validation, two valid retained GZF/IR sides,
ProjectService completed-run persistence, unified result generation, and proper
orientation checks. A skipped, unsupported, failed or cancelled attempt remains
explicitly excluded, not a synthetic unchanged proof. Empty `modified` lists
do not automatically prove unchanged source semantics. Pin and verify Linux and
Windows runs and G-U1..G-U8 at the exact commit before GT-01 acceptance.

Each pair/orientation owns its extraction staging workspace. An ingest or IR
placement failure may retain partial staging for diagnosis, but must not make a
later independent comparison fail because of a leftover staging directory.
