# SPEC-31-F: Transactional Workflow, Desktop/CLI Integration, Recovery and Migrations

Status: developer-ready implementation workflow. Parent [SPEC-31](../kb-cve-correlation-and-acquisition.md). Depends on 31-A/B/C/D; E is optional. Owner: service/UX integrator. Preserve existing src/patchtrace/cli.py, service.py, persistence.py, ui.py, ui acquisition dialog, tooltips.py.

## F1. Measured existing integration points

At 2026-10-14 main inspection: ProjectService.create(older:Path,newer:Path,name:str,root:Path) creates one normal project; ProjectService.open, backup, _commit, swap_orientation already own lifecycle. The project SQLite and snapshots are under patchtrace.persistence.ProjectStore; enrichment.storage.EnrichmentStore coordinates additive derived data with guard/revision checks. src/patchtrace/ui.py already contains an AcquisitionDialog for SPEC-08 that performs filename -> Winbindex search -> explicit old/new -> consented download and creates project on GUI thread. DO NOT duplicate that dialog's worker machinery or present it as unimplemented. New kbcorrelation widget should either embed/reuse an extracted common acquisition controller or launch existing dialog prepopulated through a carefully reviewed additive interface; never copy its transport code.

Existing src/patchtrace/cli.py command names 'acquire', 'correlate', 'rank', 'flags', 'series' must retain argument semantics/exit status. Add nested 'kb' command by delegating into kbcorrelation.cli. src/patchtrace/tooltips.py apply_tooltip provides semantic what/why/source/status text. Register all new interactive controls except those exempted by established tooltip policy.

## F2. State transition table (complete acceptance subset)

A transition is allowed only when preconditions match current immutable investigation revision, and the resulting event includes plan digest and source evidence ids.

NEW + parse_valid -> IDENTIFIER_PARSED; invalid -> unchanged + PT-KBC-INPUT.
IDENTIFIER_PARSED + cached_lookup -> METADATA_READY|METADATA_PARTIAL|NOT_OBSERVED; network request without consent -> unchanged + PT-KBC-CONSENT.
METADATA_PARTIAL + provider_failure -> still metadata partial (never replace already valid results); resume/retry -> new revision.
METADATA_READY + ambiguous products -> NEEDS_PRODUCT; exact verified user selection -> PRODUCT_SELECTED.
PRODUCT_SELECTED + no credible file -> NEEDS_FILENAME; with file candidate(s) -> COMPONENTS_READY.
COMPONENTS_READY + no compatible pair -> NEEDS_OLDER|NEEDS_NEWER|LINEAGE_BLOCKED; else PAIRS_CANDIDATE.
PAIRS_CANDIDATE + unambiguous selected pair -> DOWNLOAD_PLAN_READY; a tie -> NEEDS_PAIR_SELECTION.
DOWNLOAD_PLAN_READY + exact consent -> ACQUIRING; stale plan or consent mismatch -> unchanged + PT-KBC-STALE/CONSENT.
ACQUIRING + both final verified files -> VERIFIED_PAIR; one direct 404 -> PARTIAL_ACQUISITION; delta base unavailable -> NEEDS_BASE.
VERIFIED_PAIR + confirmed project path + create success -> PROJECT_CREATED. Failure -> VERIFIED_PAIR and error, preserving staged verified bytes if retention policy permits.
PROJECT_CREATED + run started by explicit user action -> COMPARISON_PENDING; completed -> ANALYZED.
ANALYZED + E0 context -> CORRELATED_PARTIAL or CORRELATED; E1 unavailable never blocks E0.
Any active stage + cancellation -> previous committed snapshot plus CANCELLED attempt record, no advancing revision.

Event reducer pure: reduce(snapshot,event)->new_snapshot|KbError. Side effects run outside reducer and propose events containing operation generation ID; generation mismatch or closed Qt window discards late result. Serialize stage transitions on single writer and enforce expected_revision optimistic compare and exclusive project lock at commit. If a crash occurs, mark attempt interrupted, preserve last verified revision; startup never auto-fetches or runs Ghidriff.

## F3. Storage layout and transaction detail

Global cache: content-addressed raw official metadata snapshots and reverse-index tables in app-writable cache (not directly exposed as project blobs). Project attached context: kb_investigations, kb_investigation_revisions, kb_project_links, kb_analyst_decisions, kb_attempts and kb_derived_assessments are additive tables in existing ProjectStore database OR a documented service-managed extension with identical lock and backup semantics; choose one after auditing current ProjectStore. Do not create an independent uncoordinated second SQLite writer.

Every mutation:
(1) check lock, project UUID/revision/hash and feature schema;
(2) validate all source/evidence foreign keys and immutable bytes;
(3) BEGIN IMMEDIATE transaction;
(4) insert next immutable investigation revision plus source snapshot refs and attempt status;
(5) update one current pointer with expected prior revision;
(6) COMMIT; use atomic rename for separately staged raw objects;
(7) after commit notify UI, never before.
On fail roll back, leaving prior current pointer untouched. SQLite DDL must be explicitly transactional (existing enrichment tests found a historical DDL atomicity issue). Backup before first extension schema write, follow ProjectStore.backup conventions and inclusion of source blobs in backup/export. On restored project with missing external cache, source pointers degrade to 'missing source bytes', no phantom verification.

An investigation started from a KB or CVE retains the exact `Coverage` from its explicit search.
All later product, component, CVE/card, KB/fixed-build, pair and attached-context selection uses that
coverage's finite `SearchScope`; it must not fall back to the currently loaded corpus. A saved
`cached_corpus` scope means its saved `doc_ids`, including an empty set. A newer document outside
those IDs must neither add evidence nor suppress a selected older revision. Active revision selection
is computed inside the selected document set. Explicit month/file/mixed selectors retain their
respective bounds. Preserve the saved coverage objects in the report, rather than silently replacing
them with newly computed coverage.

Before downstream decisions, revision advances, acquisition completion, project creation or context
repair, require the referenced coverage record to be readable, identity-consistent and unambiguous.
Missing/invalid/contradictory scope, unavailable selected source bytes, or changed inspected-label
availability returns `PT-KBC-SCOPE` with a repeat-search instruction and no operation writes.
An explicit repeat search may replace the saved scope through the existing revision flow. A local
pair-only investigation without advisory coverage remains supported and yields no advisory evidence.

Cache key: (operation, normalized request, source connector versions, raw snapshot digests, product alias version, input project SHA/revision, rules and engine versions when relevant). No sharing derived assessments across projects unless artifact hashes and all relevant context match. Source cache may be reused offline without granting previously used network consent.

## F4. Consent rules and preview protocol

Network consent has exact operation IDs and URLs/host restrictions, expiry/in-memory scope, and may be revoked by cancel. Rendering a plan never triggers DNS. Discovery request and binary acquisition are separate consent steps. UI must show all planned known requests; if index traversal dynamically discovers new URLs, return NEEDS_ADDITIONAL_CONSENT with explicit new plan, unless user explicitly authorized a bounded same-host template+range operation. Never broaden grants silently. --offline blocks all calls including update/telemetry checks in the feature. Use existing networking abstractions and approved retry/redirect logic; do not add unrestricted urllib calls to providers.

Plan example shape:
~~~json
{
  "contract": "kbcorrelation/1",
  "plan_sha": "<64-lowercase-hex-of-canonical-plan>",
  "operation": "fetch-source-document",
  "exact_urls": ["https://api.msrc.microsoft.com/sug/v2.0/en-US/vulnerability/CVE-2099-10001"],
  "allowed_hosts": ["api.msrc.microsoft.com"],
  "expected_project_revision": null,
  "expires_at": "2099-02-01T12:00:00+00:00",
  "reason": "User requested this synthetic CVE"
}
~~~
Replace placeholder hash with real calculated value in code fixtures. The sample illustrates schema only.

## F5. CLI grammar, JSON and exit mapping

Add 'kb' parser beneath current argparse subcommand tree with actions search, import, components, pairs, plan, acquire, attach, explain, export. Avoid nested duplicate --json declarations and argument shadowing. Search never implicitly fetches. Preserve current correlate as CVE-context-only. Use current CLI numeric exit-code meanings by inspecting tests before new command mapping; do not reinterpret code 3/4.

Command intent:
~~~text
patchtrace kb search KB5000001 --offline --json
patchtrace kb search KB5000001 --plan --json
patchtrace kb components <investigation-id> --product <scope-id> --json
patchtrace kb pairs <investigation-id> --product <scope-id> --file exampledrv.sys --json
patchtrace kb plan <investigation-id> --pair <pair-id> --json
patchtrace kb acquire <investigation-id> --pair <pair-id> --project <path> --consent-hosts <hosts> --json
patchtrace kb attach <project-path> --investigation <investigation-id> --json
patchtrace kb explain <project-path> --cve CVE-2099-10001 --json
~~~
All KB/CVE identifiers and paths above synthetic; placeholders explicitly documentation notation. --json stdout exactly one contract-versioned object; stderr progress only. Stable sort and Unicode-safe encoding. No credentials, local absolute paths or provider payloads in default JSON unless explicit data-inclusion option. Help examples and every argparse code path get subprocess golden tests.

## F6. GUI composition and reuse

Implement kbcorrelation/ui_model.py pure view models + ui_kbcorrelation.py dialog. Open from Investigation menu (two-line import/action hook) and existing-project context command. Stepper pages: Search/Coverage; Product rows; Component candidates; Version pair; Consent/Acquisition; Evidence/Report. Pages never become disabled solely because later optional engines are missing. Show source's last checked date and incomplete coverage directly beside KB results. All identity labels include architecture/release/build and provenance; keyboard can select rows and copy exact hashes.

One confirmation for proposed old/new plan explicitly lists: product/release/arch, KB and CVE links, file hashes, source URLs, intervening known updates, candidate provenance tier and ability to decline. Use existing AcquisitionDialog by a shared service/controller if possible; actual ProjectService.create remains on owning GUI thread, never QThread. After create, popup expected mechanisms only from validated local source facts and versioned rules; never from raw HTML/unsanitized advisory. User action launches comparison, not dialog construction.

Use worker lifecycle patterns from existing ui.py Worker and _release_thread, with generation counter + strong cancellation + close semantics. Prevent cross-thread QWidget mutation and SQLite use. New standard tooltip ids for all actionable controls in source select, product select, file candidate, pair, analyze, export and navigation. Text-only status plus accessible name (not color-only). Verify high-DPI and long product strings, translations/Unicode payloads, keyboard-only.

## F7. Staleness and upgrade tests

Invalidation triggers: newer KB advisory revision, source index coverage change affecting selection, product alias map update, changed source metadata, changed selected build or hash, project swap/reimport, match correction, analysis-run replacement or rule update. Raw evidence retained; old evidence no longer navigates into new run. Export stale history with explicit reasons.

Tests: quit while network pending, close dialog and reopen before worker response, cancel during second SHA verification, stale project revision between plan and commit, SourceRecord not found after cache prune, backup restore on clean machine with no global cache, Qt offscreen HTML-looking advisory text, multiple attached investigations, reanalysis while panel open, old project without KB tables, schema version too new, rollback on disk full. Existing acquisition search GUI continues to work unchanged.

## F8. Native frozen build gate

On Windows release ZIP: login-free metadata-only/offline replay, documented consented sources, search with ambiguity and partial data, import known old/new PE, create normal project, load and reopen, compare via configured supported engine or import fixture, show candidate view and export. Smoke includes dependency metadata, tooltip registry coverage, content-addressed snapshot copies, stale-state persistence, DPI and non-ASCII filesystem paths. Separate tests for Windows DLL/signature behavior and PA30 reconstruction; do not label them validated from Linux unit tests alone.

The packaged `--self-test` runs a constructed offline journey through the actual
investigation dialog, current-project candidate panel, persistence and export APIs.
Its generated advisory, PE bytes and identity-bound imported comparison are labeled
synthetic; it never imports the repository's `tests` package or executes those PE
inputs. It checks absent coverage, explicit ambiguous-product selection, preview
binding, creation/adoption, source-snapshot identity, candidate display, exports,
Unicode paths, tooltip/accessibility names, and stale advisory state after reopen.
The frozen smoke driver requires its successful completion marker, rather than
accepting construction of an idle dialog. This supplies reproducible automated
coverage only: a source run is not a frozen Windows result, and neither replaces
the remaining real-source, native-engine, DLL/signature, PA30 or human DPI/usability
acceptance evidence.

The self-test owns one top-level Qt application event loop. Timer-owned continuations yield between actions
and while awaiting worker completion; manual event pumping, sleep polling and nested event loops are forbidden.
Intermediate window closes must not quit the application. Step timeout or exception closes owned windows and
workers, restores the isolated workspace environment and the prior last-window quit policy, and propagates
failure outside the Qt callback. The success marker is emitted only after terminal journey success. Invocation
from a non-GUI thread or an already-running event loop is rejected before creating the scratch workspace.

## Acquisition completion identity (2026-10-31 essential repair)

A consented index acquisition must bind completion to the exact product scope and investigation revision used to build its plan, including an explicit `--product` that differs from the saved selection. Reopen the workspace under its existing lock and compare the captured revision before committing a scope selection or attaching project context. A concurrent revision change returns `PT-KBC-STALE`; it must not create or attach a project or overwrite the newer investigation. Initially unselected and previously other-architecture investigations must persist the explicitly selected preview scope on successful completion. Keep preview acquisition plan identity distinct from any conservative local/manual verification pair identity; do not silently claim they are the same or promote index-only lineage. Retain provenance connecting acquisition plan and attached verified bytes. Reuse existing history/transaction and failure-preservation contracts; no schema change unless explicitly required and amended first.

Acquisition response provenance extends the existing `acquisition` object with `scope_id`, `source_pair_id` (previewed index pair), and `verified_pair_id` (conservative inspected local pair). Retain an `acquisition-pair-binding` analyst decision using the existing decision record, carrying prior/next pair identifiers and a reason with plan SHA, scope, exact older/newer SHA and conservative verification grade. This does not equate index lineage with verified lineage. Re-inspected staged file hashes must equal the captured acquisition plan before any selection/attachment mutation.

## Essential offline desktop investigation completion (2026-10-31)

Expose a parented modal `InvestigationDialog` from the existing MainWindow Project menu. It imports a local supported advisory, searches a KB/CVE, requires explicit product scope, previews older/newer local files and creates/opens a new comparison through the existing KB service. No network/acquire controls or implicit fetches are added. The existing KB read-only evidence dock remains available. The dialog must retain the current open project on error, stale preview or cancel; refuse destination reuse of the current project; only adopt the new project on the GUI thread through a parent callback. Use the existing per-task worker-created isolated-project port (as with the new-project workflow), superseding any earlier instruction to create that isolated database on the GUI thread. No SQLite/service object crosses threads.

Qt-free `InvestigationRequest`/`InvestigationResult` immutable dataclasses capture plain paths/IDs/options; `execute_request(request,cancel,service_factory=None)` runs local import/search/preview/create with a task-local service. Public `KbService.import_pair` adds optional `expected_revision=None`; dry-run returns `investigation_revision`. Create must supply both previewed pair ID and investigation revision and compare under existing transaction/CAS boundaries before mutation; defaults preserve current CLI compatibility. Dialog controls invalidate preview when inputs/scope/confirmation change, render bounded plain text, provide explicit same-component confirmation when needed (default false), and use module-owned tooltip/accessibility names. Task completion checks cancellation/generation/current parent state before adoption. Cancellation is cooperative before commit; if a project is already committed, preserve it and clearly report its path rather than claiming rollback or silently adopting it after close.

Create cancellation retains the token returned by `TaskRunner.submit` and sets it without superseding the task's generation. The result/error callback must still arrive so the dialog can acknowledge precommit cancellation or report a committed project path. `KbService.import_pair(..., cancel=None)` accepts an optional Qt-free cancellation predicate, checked before and between local file inspections and again after read-only validation, immediately before the first investigation mutation. The desktop service supplies its token's `is_set`. A cancellation observed at these checkpoints returns `PT-KBC-CANCEL`, with no destination project and no investigation revision advance. Once the mutation phase starts, complete or report its existing recovery result; do not assert rollback. Cancel and Close both signal cancellation, keep pending-create controls disabled until acknowledgement, and never adopt a returned project after cancellation. Closing waits for the acknowledgement so retained paths are reported.

New-only desktop creation uses a GUI-specific project port/factory in `wiring.py` that invokes `ProjectService.create` directly and never resumes an existing database. The normal CLI port keeps its existing resume behavior. A destination populated by another creator after preview/empty-directory checks must be refused under ProjectStore's exclusive create/lock semantics, without adding context or adopting that project. Do not treat a preflight directory check as an exclusive creation claim.

The MainWindow remains a feature-free thin seam within the existing GUI line budget: its investigation factory delegates to PanelHost, which owns dialog construction and completion callbacks over its TaskRunner. No direct KB feature import or feature-specific callback implementation belongs in ui.py. Generic transactional project adoption remains a MainWindow responsibility. Existing architecture tests/ceilings are retained unchanged.
