# PatchTrace beta architecture (SPEC-01, schema v1)

## Objective and decisions
PatchTrace is a local Windows 11 x64 desktop for static PE AMD64 patch comparison, manual review and optional evidence-linked hypotheses. Older/newer is selected explicitly. No target binary is executed. Python 3.12 + PySide6 separates desktop from a pure Python domain layer and Ghidriff CLI process. Ghidra/Java/Ghidriff are external analysis dependencies; the desktop ZIP bundles Python and Qt. AI is optional. SQLite stores validated JSON snapshots and append-only revisions in transactions; immutable copied inputs and raw analysis outputs accompany the database. Qt widgets provide keyboard accessibility and scalable plain-text code views. JSON schemas are generated from strict Pydantic models. Upstream schemas are accepted only through an adapter.

DEC-01: avoid embedding Java in GUI. DEC-02: use supported CLI, preserve raw outputs, do not fork matching. DEC-03: implement a Diffalayze-inspired bounded interpretation flow, reuse conceptual staging with attribution rather than importing its acquisition/execution workflow. Exact reuse awaits source investigation. DEC-04: Ollama localhost and OpenAI-compatible HTTPS endpoints through standard library HTTP; credentials session-only, never persisted. DEC-05: preserve all beta requirements in traceability even if runtime verification is blocked. Never call an unverified path complete.

## Dependency graph
```mermaid
flowchart TD
    UI[Desktop] --> Service[Project service]
    Service --> Domain[Versioned contracts]
    Service --> Store[SQLite snapshots]
    Service --> Jobs[Worker lifecycle]
    Jobs --> Backend[Ghidriff adapter]
    Service --> Interpret[Context and interpretation]
    Interpret --> Providers[HTTP providers]
    Backend --> Domain
    Interpret --> Domain
    Store --> Domain
    Service --> Reports[Report export]
```

Build order: contracts → ingestion/persistence/normalization → backend/jobs and context/providers/reports → service → desktop → packaging/acceptance.

## Interfaces and ownership
Generic project creation first prepares both immutable input copies and validates
the initial database snapshot in a private temporary directory. Input validation,
partial copy, interruption or initial snapshot failure must not mutate the chosen
destination, including an existing empty directory. Only a complete staged project
may acquire the destination project lock and publish its fixed artifact paths and
first snapshot. Each artifact is created exclusively; a file already present is
reused only after verifying its identity, exact content and PE structure, never
overwritten. Incomplete publication bytes are retained if their ownership/content
cannot be proven. Existing committed databases remain refused; existing snapshotless
database retry compatibility remains under the existing exclusive lock.

On later publication failure, cleanup runs before releasing that lock and removes
only completed files created by this attempt whose recorded filesystem identities
and content versions still match. A replaced root/path, pre-existing artifact,
unknown file or committed first snapshot is preserved. The kernel lock file is
retained under the existing lock contract; no unlink-after-unlock cleanup or
recursive deletion of a user-selected root is permitted. Such later failures can
leave a failed-attempt directory for service retry; the GUI's nonempty-directory
guard is unchanged, and an explicit validated GUI recovery route is separate work.
Destination database initialization follows the same rule even before the service
receives a store: close SQLite, verify the owned root/lock/database identities and
snapshotless state, clean up while locked, then release the lock in all cases.
The held lock descriptor supplies the lock identity; the named lock path must
continue to match that descriptor before publication or cleanup.

Explicit incomplete-creation retry is a separate service operation. It stages both
inputs privately, then acquires the existing regular 4-KiB project lock without
creating it or rewriting its bytes. Before any database recycling, validation
under that held lock permits only `.patchtrace.lock`, an optional `project.sqlite3`,
and an optional `artifacts` directory. All lexical ancestors and entries must be
ordinary nonlinked/non-reparse paths; regular files must have one hard link.
Lexical components before `..` remain visible for these checks: normalization is
allowed only after recording their identities, which are checked again under the
held lock before the read-only validator runs.
Artifacts may contain at most the two exact staged-input SHA-256 `.bin` names;
every existing file must match its staged size/hash and pass complete static PE
validation. Nothing is adopted by a directory glob or a recovery receipt.

An existing retry database is limited to 1 MiB, opened read-only/immutable, and
must have version 1, the exact generated empty snapshot/history/SQLite-sequence
schema, no other schema objects or rows, and a successful bounded integrity check.
Zero-byte, malformed, committed, foreign-schema and sidecar-bearing databases are
refused by this explicit route; legacy direct-service abandoned-database behavior
is unchanged. Entry sets, identities and content versions are rechecked before
validation returns. Validation failure or cancellation during preparation or validation leaves
all destination bytes unchanged and releases the lock. Successful validation may
recycle only that validated snapshotless database and exclusively create missing
artifacts, reusing complete matching files without overwriting them. The replacement
database path is also created exclusively; a newly appeared file is never adopted
or overwritten, and retry never authorizes deleting SQLite sidecars. Cancellation
after a committed first snapshot retains the project without adopting it.

Domain models are immutable by convention except project aggregate changes in the service. UUID identifiers are assigned by PatchTrace. Every model forbids extra fields. Database loads validate schema versions and relationships before use. Workers return values to UI thread through queued signals; only service transactions change project state. One active job per window, one writer per project through exclusive lock file. No module imports UI except UI. Cancellation is cooperative for providers and process-tree termination for analysis; delivered remote data cannot be recalled. Logs omit credentials and are capped.

Project directory: `project.sqlite3`, `.patchtrace.lock`, `artifacts/{sha256}.bin`, `runs/{run_id}/raw/`, `exports/`. Relative artifact paths cannot escape root. Each DB commit stores current validated aggregate plus history. Backup uses SQLite backup API and copied artifact/run files. Interrupted runs are marked failed on load. Future schema versions fail closed; v1 needs no legacy migration. Migrations require backup and explicit ordered transforms, never reinterpret future data.

## Ingestion and worker contracts
`inspect_artifact(path, side, root) -> Artifact`: regular readable PE file, 1 GiB maximum, DOS header, bounded PE offset, machine 0x8664, PE32+ magic. Hash during copy in chunks; source size/mtime before and after must agree, otherwise delete staging. Atomic rename after flush. Original untouched. Identical SHA-256 pairs are valid and may skip analysis with explicit identical status. Optional symbols are deferred from automated loading, can be recorded as analyst documents.

`normalize_ghidriff(raw, project, run_id) -> list[FunctionMatch]`: handle modified/added/deleted functions from pinned known output; require recognizable function structure; reject unknown schema rather than silently empty. Missing code/address/assembly is represented explicitly. Raw source hashes and backend metadata accompany run. Upstream percentages are uncalibrated match metrics, never vulnerability probability. Manual split/merge/ambiguous relations use multiple function IDs. Equality of addresses never establishes a match.

`diff_hunks(older, newer, match_id)` aligns original text using half-open line ranges. Up to 2000 lines per side, use exact SequenceMatcher alignment with popularity filtering disabled. From 2001 through 10000 lines, enable popularity filtering to bound repeated-line matching work; alignment is a display aid, never binary correspondence evidence. Above 10000 lines on either side, use a linear common-prefix/common-suffix scan and represent the remaining middle as one replace/insert/delete region. Equality regions must always contain identical original lines. `alignment_strategy` exposes the selected strategy so the desktop can disclose coarse large-region alignment; no assembly or missing code is invented.

`run_comparison(config, project, cancel_event, on_event) -> AnalysisResult`: shell=False, absolute executable path and argv; Python `-m ghidriff` only for configured external interpreter. Timeout 3600 seconds default. Output bounded to 100 MiB JSON and 2 MiB log tail. New unique run directory, no cache use until keyed by hashes/version/settings. On failure raw output quarantined, prior results preserved. Working and normalization-failure directories use `runs/quarantine-<canonical-UUID>` without dot-prefixed elements; older existing `.quarantine-*` directories are left untouched for backward compatibility. Before invoking Ghidriff, validate every component in the resolved `--output-path` (including project ancestors) because Ghidra refuses components whose names start with `.`. Reject an unsafe path with a specific PT-BACKEND error, rather than silently renaming or moving the analyst's project. On Windows, reject output paths 240 characters or longer with guidance to relocate the project under a shorter path; nested Ghidra project paths may impose stricter practical limits. Spaces and OneDrive directories without a dot-prefixed component remain permitted; pass paths as individual argv elements and do not rely on shell quoting. Use Ghidriff's separately supported `--project-location` and `--gzfs-path` options for a fresh private temporary workspace outside the case directory; Python's TemporaryDirectory lifecycle must remove this scratch after the contained process exits, both on success and error. Only raw comparison output (JSON/Markdown), analysis.log, and failure metadata belong under the case. Never delete previously completed case outputs. Default Ghidriff symbols remain under raw/symbols until a separately reviewed versioned cache is designed. `BackendConfig.allow_symbol_downloads` is a backwards-compatible opt-in bool (default false). When false, pass pinned Ghidriff's supported `--no-symbols` CLI flag; when true, leave upstream symbol behavior available. UI labels must communicate that this flag disables Ghidriff symbol processing, potentially affecting function naming and match quality. Record the choice in per-run provenance as `allow_symbol_downloads` plus `symbol_policy` (`disabled` or `online`) and `ghidra_settings` (`isolated-per-run`). Every Ghidriff child runs with `XDG_CONFIG_HOME` pointing at a fresh directory inside the private scratch workspace. Ghidra resolves its user settings directory from the `application.settingsdir` property, then `XDG_CONFIG_HOME` on every platform, then %APPDATA%/~/.config (ApplicationUtilities.getDefaultUserSettingsDir). Isolation prevents a symbol-server configuration persisted by an earlier manual or symbol-enabled Ghidriff run (PdbPlugin preferences) from being consulted: Ghidriff `setup_project()` (PyPI 1.0.0 and pinned commit 4f5d895) calls `get_pdb(allow_remote=False)` under `--no-symbols` and raises `FileExistsError` ("Symbols are disabled, but the symbol is already downloaded") whenever that persisted local store already holds a matching PDB. Isolation also stops symbol-enabled runs from writing symbol-server configuration into the analyst's global Ghidra preferences. The analyst's PDB caches and global settings are never read, modified or deleted. Ghidriff's `--jvm-args` is not used because PyPI ghidriff 1.0.0 declares it `nargs='?'` and iterates the string character by character (later upstream commits use `append`); the environment variable works with both. SPEC-53 now offers a PatchTrace-owned launcher for local PDB mode: it forces an empty Ghidra symbol-server list, stages only identity-matched PDBs per run, and keys the raw cache by staged-PDB digest. This is configuration evidence, not an OS-level air-gap guarantee; GHR-5 remains unverified. If the FileExistsError still occurs (for example a PDB beside the analysed copy), diagnostics classify it as a cached-symbol conflict without echoing the path. This is not a guarantee of whole-system network isolation because Ghidra extensions and other processes are outside this flag's control. Offline mode performs no intentional dependency downloads by PatchTrace; air-gapped users still require local compatible tools. Reject nonboolean flag values to avoid unintended network behavior. A crash may leave an abandoned OS temp directory to be handled by system cleanup. Scratch removal after a run is retried a bounded number of times; if it still fails (for example antivirus or a lingering Java child holding a file), the run keeps its real status and a warning names the leftover path — cleanup failure never turns a completed analysis into a failed one. User binaries and prior run files are preserved if preflight rejects a path. On Windows create subprocess suspended, attach to kill-on-close Job Object, then resume; fail if containment unavailable. POSIX process group kill. Never claim process isolation is a sandbox. Default memory/thread settings are forwarded only if verified supported. No invented hard memory cap.

`BackendConfig.retain_gzf: bool = False` (SPEC-31 A-01c, D-05; a non-bool is a configuration error). When true AND the Ghidriff process exited 0 without a stop reason AND the run was not cancelled, `run_comparison` calls `unified.extract.retain.retain_run_gzfs` BEFORE the private scratch is removed: exactly two regular, non-symlink `*.gzf` files whose names equal `<artifact file name>-<sha1[:6] of the artifact>.gzf` and whose total size is within L-36 (4 GiB) are moved into `quarantine/unified/gzf/{older,newer}.gzf` (renamed with the run directory by `publish()`) and `settings["gzf"]` records `{name, sha256, bytes}` per side. Any other layout, any I/O error or the flag off retains nothing; a warning event is emitted and the run is never failed or altered. argv, the raw-cache fingerprint and the settings of a run with the flag off are unchanged (regression test). A raw-cache hit runs no Ghidriff and therefore retains nothing.

## Context and interpretation contracts
`build_context(project, match_ids, max_chars=24000) -> AnalysisContext`: deterministic changed functions first then available caller/callee records, explicitly record unavailable references; assign evidence IDs to exact code side/function/line ranges. Bound total characters and record omitted/truncated data. Conservative token estimate ceil(UTF-8 bytes/3), a budgeting estimate rather than provider tokenizer equivalence. Context digest covers exact serialized payload, artifact hashes, run and matches. UI preview is exact request context. User starts each transmission explicitly. Remote HTTPS only; local mode loopback only, reject URL credentials/fragments and IPv4-mapped IPv6 literals (SPEC-41 R11). No tools or command execution. Timeout 120 seconds, which also ends a blocked connect or read; response cap 2 MiB (SPEC-41 R13, R14); no automatic retry of sent requests.

`interpret(context, provider) -> InterpretationRun`: instruct provider to distinguish observed changes, uncertainty, ordinary fixes, alternatives, support/counterevidence and proposed verification. Strict JSON response; one malformed response fails visibly and raw response remains quarantined in run. Every transport error becomes a `PT-PROVIDER` message with fixed text (SPEC-41 R33). Validate every cited evidence ID against exact context, including function/run/artifact ownership. Model confidence labels qualitative, review status starts unreviewed. No inferred CVE/severity/affected versions: a finding that names a CVE, CWE or CVSS claim absent from the context is dropped, the run keeps its other findings with a note, and a run whose findings are all dropped fails (SPEC-41 R29; severity and exploitability wording is not screened). Analyst conclusion is separately entered text.

## Findings and invalidation
Reanalysis, orientation swap, manual match change or settings change increments project revision and marks previous contexts, findings and annotations stale. Raw runs retained. Evidence navigation checks stale and run ID before jumping. Match override records original IDs, selected new IDs, timestamp and reason; can revert using history. Review accepted/rejected/needs-review states do not imply validation. Notes and bookmarks have analyst origin. Imports verify relationships, bounded size and schema; no pickle/eval. The shared strict JSON loader (`persistence.strict_json`) also bounds nesting at `MAX_JSON_DEPTH` = 128 arrays/objects and rejects lone surrogate escapes, both as PT-SCHEMA before anything is staged; secondary-engine parsers (rz-diff, BinDiff) apply the same loader and treat version strings beyond `int()` digit limits as unrecognised. `ingestion.safe_path` refuses NUL, components over 255 UTF-8 bytes, unencodable components and filesystem errors as PT-STORAGE, never a raw `OSError`. PE base-relocation blocks are checked against `MAX_RELOCS` before they are walked (2026-10-30, hostile-input sweep).

## Reports
`export_project(project, format, destination, include_code=False, include_notes=True) -> ExportManifest`: stable ID ordering, JSON v1, Markdown escaped text and HTML escaped values with no network assets/scripts. Default excludes code and raw provider text. Include hashes/run versions, current/stale status, unknowns and limitations. Redact absolute source paths by default. Write to sibling temporary then replace. Failure leaves prior report intact. An existing destination whose bytes differ is first kept beside it as `<stem>.previous-<sha256[:8]><suffix>` (created exclusively, never overwritten, skipped when identical; an existing backup must be a regular non-symlink file with exactly the expected bytes before reuse, otherwise export is refused; a failed backup aborts the export before the replace and removes its own incomplete file when possible); an existing file larger than the report cap is refused, not read or replaced (2026-10-28). Manifest records SHA-256, selected finding IDs, flags and schema version. Reports derive only from persisted project snapshots.

## Error taxonomy
PT-INPUT invalid/unreadable/changed/oversize/incompatible input; PT-SCHEMA unknown or malformed contract; PT-BACKEND missing/version/execution/timeout; use the pure `diagnostics.describe_backend_exit(code, sanitized_log_tail)` classifier for a *known* runtime failure (Ghidra dot-prefixed workspace, incompatible Java bytecode/JDK, missing Ghidriff module, Java heap exhaustion, full disk, permissions), and preserve original exit code and full bounded analysis log; unknown failures keep the generic error. Fixed category strings must not echo untrusted or secret-containing log text. PT-CANCEL cancellation; PT-PROVIDER transport/status/malformed/ungrounded; PT-STORAGE lock/corruption/disk-full; PT-EXPORT write failure. UI retains previous committed data, gives actionable message and recovery control. No silent empty success.


### Backend output rejection diagnostics (GT-01, 2026-10-30)

Keep the combined 100 MiB JSON ceiling and path guards. A failed output check must retain a distinct fixed reason marker in the PT-BACKEND error and quarantined failure.txt: `[output-limit]` for oversized combined JSON (include the byte ceiling), `[unsafe-output-path]` for a rejected path, and `[output-check-failed]` for unreadable output. Apply the same classification to a guard stop during execution and a rejection found after process exit. Cancellation and timeout keep their existing precedence. Preserve partial diagnostic artifacts and prior completed runs; never import rejected JSON as a completed result.
## Essential safety continuation: report destinations (2026-10-31)

Project-backed report writes use `ProjectService.export_report` and pass `project_root` to `reports.export_project`. The optional root argument preserves the standalone renderer API used for previews; it does not infer project ownership. Before creating directories, staging or backups, project-backed export refuses any destination inside the project except its `exports/` subtree, and refuses registered artifact/raw evidence paths even if they occur there. Protect the database, WAL/SHM, lock, run/evidence/backup/sidecar stores through this rule. Resolve parent aliases for ownership checks; reject existing aliases to protected evidence. Preserve the existing final-symlink refusal and previous-report backup semantics. Ordinary external destinations and non-evidence files in `exports/` remain supported. GUI export must use the service-owned route; preview stays a throwaway standalone rendering. Refusal preserves project/evidence bytes, creates no report/backup/staging files, and leaves the project reopenable. This adds no wire-schema change and is not an OS-level filesystem sandbox.

`ProjectService.export_report` renders and checks ownership against a loaded committed snapshot, leaving an unsaved mutable in-memory aggregate untouched. Existing-destination alias checks are bounded to registered artifacts/raw evidence and fixed database/companion/lock paths; never recursively enumerate an entire project on the GUI export path. Namespace checks protect other project-owned internal stores without an unbounded file walk.

Committed report reads are non-mutating: `ProjectStore.load(*, recover_interrupted=True)` retains existing default startup recovery, while service export uses `recover_interrupted=False`. Export must neither mark queued/running records failed nor publish recovery/history changes, including when a destination is refused; normal reopen recovery remains unchanged.

Project adoption in MainWindow retains the original open service until the incoming project renders and recent-project state updates successfully. On failure, restore the original service/preferences/view, close the unsuccessful incoming service, and leave its directory available for retry. A KB creation completion must report retained-path/open failure rather than silently replacing the parent on failed rendering.

The generic adoption implementation is isolated in `gui.qt.project_adoption.adopt_project(window, service)`; MainWindow.set_service delegates without adding feature imports or exceeding its established line budget. The existing rollback/ownership contract remains unchanged.
