# SPEC-11: Secondary engine — Rizin rz-diff (Phase 3d)

Status: developer-ready contract, 2026-10-12. Contract version `secondary-engine/1`. Verified facts: `../research/phase3/rizin.md` (rizin v0.9.1 @ c3a90e9, LGPL-3.0-only; run locally on two afd.sys builds).

## 1. Outcome and boundaries

Optionally run rz-diff on the project's artifact pair to obtain a second, independent function-match set. Ghidriff remains the default and primary engine; both evidence sets are kept; disagreements stay explicit. rz-diff is an external, user-installed tool (official Windows/Linux builds exist); PatchTrace does not bundle it.

## 2. Capability probe

`rz-diff -v` (version line) must report ≥ 0.9.0; otherwise `unsupported` with the observed version. Detection never installs anything. Capability record: `{engine: 'rz-diff', version, path, supports_json: true}`.

2026-11-01 safety amendment: the known affected 0.9.1 producer is **unsupported until a verified orientation
witness is available**. Its singleton matching branch reverses `original`/`modified`; the ordinary branch
retains argument order, and the output omits the exact recovered input0 cardinality selecting the branch.
The retained #131 recordings include identical JSON bytes with opposite side semantics. JSON shape/row
counts, names, exports, ProgramIR or Ghidriff function counts are not that witness. No global swap is allowed.
The observed version is retained with a user-readable orientation diagnosis, before scheduler cache lookup.
This is a partial safety quarantine, not completion of native orientation acceptance; workflow pins remain unchanged.

## 3. Invocation and parsing

`rz-diff -C -j -t functions <older> <newer>` with argv list (no shell), cwd = private temp, stdout bounded at 64 MiB, stderr tail 2 MiB, wall-clock timeout default 1,800 s (configurable 60–86,400), process-tree kill on cancel/timeout (existing `jobs.run_process`). Exit 0 = ran; non-zero = error with stderr tail. Stdout must parse as a strict JSON array of objects `{similarity: number 0..1, type: 'COMPLETE'|'PARTIAL'|'UNLIKE', original: {addr:int, name:str, size:int}|null, modified: {…}|null}`; empty/invalid output is an error even with exit 0. Addresses are unsigned VAs.

Nonempty, structurally valid 0.9.1 output is rejected as `PT-SECONDARY-ORIENTATION`, kind
`rz-diff-orientation-unverified`, with its exact stdout SHA-256; it is never normalized into guessed side-owned
matches or converted to a successful empty set. Empty stdout retains `PT-SECONDARY-INPUT`. Retained stored
sets/raw evidence are preserved. Active unified/reconciliation/evidence/calibration consumers quarantine known
affected sets/reports: no matching vote, contest, numeric feature or engine-only endpoint link; explicit
not-comparable/unsupported orientation warning with original version/raw digest. Unified input provenance stays
in the manifest and makes the result partial; the matching-policy version invalidates pre-quarantine caches.
Historical recorded replay is regression evidence only, not a fresh native run. The pinned live gate honestly
fails while this producer has no witness. Next bounded work is a verified same-version preflight of the exact
pre-serialization recovered input0 list, using approved tools, or a verified upstream side-semantics repair.

## 4. Records

`SecondaryMatch` from SPEC-10 with `engine: 'rz-diff'`, `similarity_milli` = `round(similarity*1000)` (upstream text preserved), `algorithm: 'levenshtein-bytes'`, `confidence_milli: null`, `flags: ()`. Functions are mapped to PatchTrace/Ghidra functions **by address only** (rz-diff names are `fcn.*` without PDB). Unmatched sides (`original` or `modified` null) become one-sided records.

## 5. Interpretation limits (shown in UI/exports)

> SPEC-31 amendment A-17 (2026-10-14): in the SPEC-31 unified engine every rz-diff row is tier-W evidence (never accepting), flagged `non-exclusive` when its newer endpoint is shared by two or more rows (rizin 0.9.1 keeps the last candidate and never consumes B), and its similarity never selects, ranks or decides: it is carried as upstream text only.

Similarity is raw-byte Levenshtein: not semantic, sensitive to relocations and address shifts; no per-match confidence; no symbol names. Agreement with Ghidriff is not independent proof or a probability. Resource guidance: ~90 s and ~235 MB for two small drivers on 4 cores; large binaries can take hours — the default timeout bounds this.

## 6. Acceptance

Parser tests from a trimmed real rz-diff JSON output and synthetic malformed variants (non-array, wrong types, missing keys, similarity > 1, exit 0 with empty stdout); probe version parsing; timeout/cancel via fake child; address mapping and one-sided records; reconciliation display shared with SPEC-10. Live (recorded, optional): Linux CI job installing the pinned rizin release and diffing the compiled fixture DLLs.


## 7. Parser-boundary hardening (2026-10-29)

The public output parser enforces the same 64 MiB UTF-8 byte ceiling as the process
adapter, before JSON decoding. It uses the project's strict JSON loader: duplicate
keys, non-finite values, unpaired surrogate escapes and excessive nesting are
`PT-SECONDARY-INPUT`, never a Python exception or an unpersistable accepted result.
The recorded output digest remains the SHA-256 of the original UTF-8 stdout bytes;
valid Unicode names and escaped surrogate pairs retain their exact text.

Version components use one to nine ASCII decimal digits each. Malformed or oversized
versions make the capability probe unsupported, without integer-conversion errors.
This bounds parsing only; versions accepted by the existing ≥ 0.9.0 policy keep
that policy and the unified adapter's untested-version limitation.
