"""One bounded offline shared gate for the inspected batch5 replacement scopes."""
from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import os
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
OUT = Path(__file__).resolve().parent
PY = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
BASE = '55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
files = ['test_' + name + '.py' for name in (
    'tier_r_csrc', 'tier_r_eval_cli', 'tier_r_output_persistence', 'tier_r_credited_replay',
    'tier_r_credit_completion', 'tier_r_output_stat_compat', 'tier_r_eval_report', 'tier_r_shard',
    'tier_r_build_receipts_r1', 'train_prereg_selection', 'unified_read_model',
    'kbc_scope', 'kbc_scope_retained', 'kbc_index', 'kbc_context', 'kbc_service',
    'rzdiff_native_evidence', 'rzdiff_io_evidence', 'windows_build_resources',
    'windows_installer_manifest', 'milestone_notes', 'release_gate', 'build_full_variants',
    'backend_pin', 'backend_pin_strict_20261105', 'runtime_discovery', 'runtime_discovery_bundle',
    'codex_pkg_packaging', 'cli', 'project_cli', 'compare_cli', 'doctor_cli',
)]
selected = ['tests/test_rzdiff_producer_patch.py::' + node for node in (
    'test_unverifiable_source_refused', 'test_git_blob_identity_alone_cannot_authorize_source',
    'test_git_object_id_works_when_security_sha1_is_disabled',
)] + ['tests/test_build_backend_bundle.py::' + node for node in (
    'test_notice_states_the_licence_policy_honestly', 'test_release_build_refuses_pending_licence_approval',
    'test_release_build_passes_once_every_listed_component_is_approved',
    'test_gpl_directory_kept_by_a_bad_pin_is_refused',
)]
deselected = ['tests/test_tier_r_eval_cli.py::' + node for node in (
    'test_mutate_plants_builds_and_labels_a_tiny_suite_pair',
    'test_real_suite_end_to_end_manifest_and_annotation',
    'test_toolchain_reports_profiles_and_blocked_rzdiff',
)] + ['tests/test_rzdiff_native_evidence.py::test_native_coverage_oracle_rejects_contradictory_unmatched']
all_files = sorted({'tests/' + p for p in files} | {s.split('::')[0] for s in selected})
command = [PY, '-m', 'pytest', '-q', '-ra', *('tests/' + p for p in files), *selected,
           *('--deselect=' + p for p in deselected), '--junitxml=' + str(OUT / 'current-affected.xml')]
env = {**os.environ, 'PYTHONPATH': str(ROOT / 'src') + ':' + str(ROOT / 'tests'),
       'QT_QPA_PLATFORM': 'offscreen'}
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
assert git('rev-parse', 'HEAD') == BASE
assert not git('diff', '--', 'src', 'tests', 'tools', '.github')
metadata = dict(source=BASE, source_tree=git('rev-parse', 'HEAD^{tree}'),
                started_utc=datetime.now(UTC).isoformat(), cwd=str(ROOT), command=command,
                environment={k: env[k] for k in ('PYTHONPATH', 'QT_QPA_PLATFORM')},
                test_files=all_files, selected_nodes=selected, explicit_deselections=deselected,
                excluded_network_fixture='tests/test_build_backend_bundle.py::test_cli_build_refuses_a_pin_with_a_placeholder_with_a_clear_exit_code (not selected)',
                limits='Offline synthetic/fake-runner mechanics only; no compiler, native engine, target execution, network, Windows package or manual acceptance. System-temp fixtures, no custom basetemp.',
                test_file_sha256={p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in all_files})
with (OUT / 'current-affected.log').open('w') as log:
    run = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
metadata.update(exit_code=run.returncode, finished_utc=datetime.now(UTC).isoformat())
if (OUT / 'current-affected.xml').exists():
    xml = ET.parse(OUT / 'current-affected.xml').getroot()
    metadata['junit_suites'] = [s.attrib for s in xml.iter('testsuite')]
    metadata['nonpasses'] = [dict(node=c.get('classname') + '::' + c.get('name'),
                                kind=child.tag, message=child.get('message'))
                           for c in xml.iter('testcase') for child in c
                           if child.tag in ('failure', 'error', 'skipped')]
(OUT / 'current-command.json').write_text(json.dumps(metadata, indent=2) + '\n')
print('exit', run.returncode, 'files', len(all_files))
print('\n'.join((OUT / 'current-affected.log').read_text().splitlines()[-35:]))
