# Batch5 frozen semantic evidence

Comparison source: actual PR316 55f3d0742f7d4cf32357a42b8b1cc76d85875e71,
tree 11a0c1598764ebd3fd8d3b540377aa52e949f88a. ledger.json/md contain the 20
scoped decisions and 31 unselected original tips. Complete patches/snapshot,
AST support and all-parent source-needle histories are retained. Source manifests
hash exact current/historical bytes, including historical specs/workflows.

The current 34-file gate is 1,129 passed, one Windows skip, one CODEX-14 xfail,
four explicit native/compiler/toolchain deselections, 16.01s. Six warnings are
deliberate legacy-replay observations. No source/tests/tools/workflows were edited.
No compiler/native/target/network/provider/acquisition, actual Windows package,
hosted/manual or integrated full-suite acceptance was performed. The known
uninjected backend-pin network fixture and real pip/build tests were not selected.

Original historical tests are byte-identical: saved scope 40 failed/4 passed;
COFF 2/6; cards 12/53; recipe 13/52; prereg 17/3; sort 0/2. Every executed
historical node is classified. Original private-seam, stronger pin, old error/
spelling and superseded-revision expectations are not all current defects.
Actual current parser observation accepts all three emitted --engine vectors.

Public proofs retain exact raw observations and commands/logs/XML: saved scope
2 failed/1 passed (persisted/reopened CLI), COFF 1/3 (acceptance with fake assembly),
A/A 2/1 (supported cases through persisted shard/merge). saved-scope-design.md
records its separately assigned repair; COFF is also separately assigned. A/A
is a proposed narrow slice. No future repair changes this baseline evidence.

Proof-preflight notes retain the relative-target hash failure before pytest and
document/fixture routing corrections. Original failed probes/results were never
edited. Worktree name remains batch4 after approved reuse; source pins are exact.
Overlapping tests and repeated branch maps are not additive completion credit.
All original branches remain preserved; no whole-branch closure or merge credit.
Evidence-manifest.json lists every other member's size/SHA256. seal.py reopens
every member. Caches, bytecode, symlinks and ephemeral project DBs are excluded.
