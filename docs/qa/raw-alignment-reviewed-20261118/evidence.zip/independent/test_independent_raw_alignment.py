"""Independent authored controls for the e4506666 paired-window desktop candidate."""
from __future__ import annotations

import hashlib
import threading

import pytest
from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QApplication

from patchtrace import ui_raw_alignment
from patchtrace.gui.qt.tasks import TaskFailure
from patchtrace.service import ProjectService
from patchtrace.ui import MainWindow


@pytest.fixture
def reviewed_window(qtbot, tmp_path):
    service = ProjectService.sample(tmp_path / 'independent-project')
    window = MainWindow(service, QSettings(str(tmp_path / 'independent.ini'), QSettings.Format.IniFormat))
    qtbot.addWidget(window)
    window.show()
    window.mode.setCurrentIndex(3)
    qtbot.waitUntil(lambda: window._current_inspection() is not None, timeout=10000)
    yield window
    window.close()


@pytest.mark.parametrize('mode', [3, 4], ids=['hex', 'binary'])
@pytest.mark.parametrize('swap', [False, True], ids=['original', 'swapped'])
def test_copy_roundtrips_unequal_unaligned_physical_offsets(reviewed_window, qtbot, mode, swap):
    window = reviewed_window
    if swap:
        window.service.swap_orientation()
        window.refresh()
        qtbot.waitUntil(lambda: window._current_inspection() is not None, timeout=10000)
    window.mode.setCurrentIndex(mode)
    controller = window.raw_alignment
    offsets = {'older': 0x1F9, 'newer': 0x20F}
    for side, offset in offsets.items():
        controller.offsets[side].setText(f'0x{offset:x}')
    controller.size.setValue(64)
    controller.toggle.setChecked(True)
    qtbot.waitUntil(lambda: controller.result is not None, timeout=10000)
    assert not window.previous_diff.isEnabled() and not window.next_diff.isEnabled()
    assert not window.hunk_list.isEnabled()
    for side, offset in offsets.items():
        artifact = next(item for item in window.project.artifacts if item.side == side)
        data = (window.service.root / artifact.relative_path).read_bytes()
        expected = data[offset:offset + 64]
        window.copy_code(side)
        copied = QApplication.clipboard().text()
        assert copied.startswith(f'PatchTrace project {window.project.id} / revision {window.project.revision}\n')
        assert f'{side}: {artifact.name}\n' in copied
        assert f'Artifact SHA-256: {hashlib.sha256(data).hexdigest()}\n' in copied
        header, _, body = copied.partition('# PatchTrace raw bytes:')[2].partition('\n')
        assert f'file offset 0x{offset:x}..0x{offset + len(expected):x}' in header
        assert f'SHA-256 {hashlib.sha256(expected).hexdigest()}' in header
        assert 'display-only gap' not in copied and '[equal' not in copied and '[unresolved' not in copied
        recovered = bytearray()
        for line in body.splitlines():
            tokens = line.split('|', 1)[0].split()
            assert int(tokens[0], 16) == offset + len(recovered)
            recovered.extend(int(token, 16 if mode == 3 else 2) for token in tokens[1:])
        assert bytes(recovered) == expected


def test_revision_change_rejects_copy_and_old_callbacks_before_refresh(reviewed_window, qtbot):
    window = reviewed_window
    controller = window.raw_alignment
    controller.toggle.setChecked(True)
    qtbot.waitUntil(lambda: controller.result is not None, timeout=10000)
    old_result, generation, key = controller.result, controller.generation, controller._key()
    old_status = controller.status.text()
    old_revision = window.project.revision
    match = window.current_match()
    window.service.correct_match(match.id, [f.id for f in match.older], [f.id for f in match.newer],
                                 match.category, 'Independent revision invalidation control')
    assert window.project.revision > old_revision
    assert window.current_match().id == match.id
    QApplication.clipboard().setText('revision sentinel')
    window.copy_code('older')
    assert QApplication.clipboard().text() == 'revision sentinel'
    assert controller.copy_text('older') is None
    controller._failed(TaskFailure('LateOldRevision'), generation, key)
    controller._ready(old_result, generation, key)
    assert controller.status.text() == old_status
    window.render_match()
    assert controller.result is None
    qtbot.waitUntil(lambda: controller.result is not None, timeout=10000)
    assert controller.result is not old_result
    window.copy_code('older')
    assert f'/ revision {window.project.revision}\n' in QApplication.clipboard().text()


def test_late_worker_error_cannot_replace_newer_result(reviewed_window, qtbot, monkeypatch):
    window = reviewed_window
    controller = window.raw_alignment
    real_build = ui_raw_alignment.build_alignment_view
    started, release, finished = threading.Event(), threading.Event(), threading.Event()
    requests = []

    def first_failure(request, cancel):
        requests.append(request)
        if len(requests) == 1:
            started.set()
            assert release.wait(10), 'independent worker release timed out'
            finished.set()
            raise ValueError('authored late failure from obsolete window')
        return real_build(request, cancel)

    monkeypatch.setattr(ui_raw_alignment, 'build_alignment_view', first_failure)
    try:
        controller.toggle.setChecked(True)
        qtbot.waitUntil(started.is_set, timeout=10000)
        old_token = controller.tasks._tokens[controller.CHANNEL]
        controller.offsets['older'].setText('1f9')
        controller.size.setValue(64)
        controller.request()
        assert old_token.is_set()
        qtbot.waitUntil(lambda: controller.result is not None, timeout=10000)
        current_result, current_status = controller.result, controller.status.text()
        assert '0x1f9' in current_result.older.caption
        release.set()
        qtbot.waitUntil(finished.is_set, timeout=10000)
        qtbot.waitUntil(lambda: not any(task.channel == controller.CHANNEL
                                       for task in controller.tasks._running), timeout=10000)
        assert controller.result is current_result
        assert controller.status.text() == current_status
        assert controller.copy_text('older') == current_result.older.copy_text
    finally:
        release.set()
