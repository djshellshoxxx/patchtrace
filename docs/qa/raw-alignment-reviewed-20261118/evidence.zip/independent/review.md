# Independent paired raw-window desktop review — 2026-11-18

## Decision and reviewed source

No blocking finding was identified in the reviewed desktop recovery. This is a
source review and local deterministic/offscreen qualification of the paired
raw-window adapter. It does not establish native/manual GUI acceptance, native
engine accuracy, platform packaging, or a combined integration head's gates.

| Identity | Exact commit or location |
| --- | --- |
| Integration baseline | `ed4557257cde90a2c10bd81d1d0d469886c84687` |
| Specification/test-first precursor | `640baa22103dbedbdde7016a8180bea804e5a2b4` |
| Reviewed implementation | `e4506666edefbbc22419ff97874e3edc599f94e7` |
| Author's QA tip | `413cd6cc14c9d75212c6552b23fe76bce304d9c5` |
| Detached, unchanged review checkout | `/workspace/scratch/c7a9e8d98848/raw-alignment-review` |
| Independent evidence directory | `/workspace/scratch/c7a9e8d98848/qa/raw-alignment-independent` |
| Interpreter | `/workspace/scratch/3a6632a6e5ff/venv/bin/python` |
| Explicit subprocess source pin | `PYTHONPATH=/workspace/scratch/c7a9e8d98848/raw-alignment-review/src` |
| GUI environment | `QT_QPA_PLATFORM=offscreen` |

The author worktree was read only. No production source was edited and no remote
operation was performed. The independent tests live outside both source trees.
The reviewed worktree remained clean at the implementation SHA throughout.

## Findings by contract

- **Cancellation and stale results:** the controller's generation and complete
  context checks augment the existing task runner's cancellation generation.
  The context includes project root/ID and side hashes, inspection identity,
  revision, match ID, representation, toggle state, offsets and window size.
  The author tests exercise replacement, hiding, closing and actual application
  quit; an additional control confirms that a cancelled real worker's late error
  cannot replace a newer successful result or its status/copy eligibility.
- **Revision and selection:** the added persisted correction control keeps the
  same match ID while advancing the project revision. Before the GUI refresh,
  copy and old callbacks already fail the dynamic context check. After refresh,
  a new result carries the current revision. Existing tests cover match changes,
  project replacement, inspection changes and orientation changes.
- **Physical offsets and copy provenance:** four independent controls reconstruct
  bytes from actual clipboard text at unequal non-page-aligned offsets in Hex and
  Binary, before and after a persisted orientation swap. The reconstructed bytes,
  per-row offsets, window SHA-256, full artifact SHA-256, side label, project ID
  and revision agree with independently read synthetic project artifacts. Code
  hunk controls remain disabled in paired raw mode. Display-only gaps and span
  headings are absent from copied bytes. Existing tests cover Ctrl+C and the
  context-menu route, EOF, bounds and ambiguity.
- **Thread and source boundaries:** workers receive the frozen request containing
  verified readers and scalar values. Reader locking and bounded backend work
  remain in the existing implementation. Project service, SQLite and Qt stay on
  the GUI side of the work closure. The source-pinned real CLI subprocess passes
  its guard against importing `PySide6` or `patchtrace.ui` modules.
- **UI module constraints and accessibility coverage:** `ui.py` has 3,071 lines;
  the unchanged test ceiling is 3,077. Fixed-offset widget construction moved to
  the adapter without changing its behavior. The host-seam tests and whole
  tooltip sweep pass with their existing assertions and exemptions unchanged.
  The author's actual 960×740 offscreen screenshot was inspected; its wrapped
  ambiguity/EOF summary is visible. This observation is not assistive-technology
  or native manual acceptance.
- **Scope:** the row model and alignment backend, persistence/schema contracts,
  and global tooltip/host-seam tests are unchanged from the baseline. The source
  diff is limited to the module index, byte representation specification, main
  window glue, new controller and focused UI tests.

## Actual verification

| Independent invocation | Result | Evidence |
| --- | --- | --- |
| Author's 182-test affected selection plus actual headless CLI child | **183 passed in 32.97 s** | `affected.log`, `affected.xml` |
| Six additional authored controls described above | **6 passed in 3.06 s** | `test_independent_raw_alignment.py`, `independent.log`, `independent.xml` |
| Whole repository Ruff | **Passed** | `ruff.log` |
| Whitespace and unchanged review checkout | **Passed** | `source-context.json` |
| Author receipt archive, source and image integrity | **Passed** | `source-context.json` |

The author archive's nine raw log/JUnit files, its archive SHA-256 and size, all
seven source hashes and the screenshot SHA-256 match its manifest. The preserved
red run is an actual missing-`raw_alignment` failure. The intermediate failure
shows the quit subprocess importing the old shared editable checkout and failing
to import the new module. The later source-pinning test correction preserves the
assertion. The independently repeated selection explicitly pins every normal
child process to this detached review tree.

The two independent selections contain different tests; the author's earlier
runs overlap and are not additional independent evidence. No new failing source
case was found, so this review does not include a production repair or red/green
repair claim. No target binary or native analysis engine was executed.

## Reproduction commands

From `/workspace/scratch/c7a9e8d98848/raw-alignment-review`, use the interpreter and
absolute environment shown in the identity table for both pytest commands:

```sh
python -m pytest -q \
  tests/test_ui_raw_alignment.py \
  tests/test_raw_alignment_view.py \
  tests/test_representation_alignment.py \
  tests/test_tooltips.py \
  tests/test_gui_host_seam.py \
  tests/test_ui.py \
  tests/test_preflight_overview.py \
  tests/test_ui_inspection_signing.py \
  tests/test_audit116_stale_inspection_failure.py \
  tests/test_cli.py::test_headless_entry_never_imports_qt \
  --tb=short --junitxml=/workspace/scratch/c7a9e8d98848/qa/raw-alignment-independent/affected.xml

python -m pytest -q \
  /workspace/scratch/c7a9e8d98848/qa/raw-alignment-independent/test_independent_raw_alignment.py \
  --tb=short --junitxml=/workspace/scratch/c7a9e8d98848/qa/raw-alignment-independent/independent.xml

python -m ruff check src tests tools
git diff --check
```

`source-context.json` records source hashes, an actual child process's import
paths and JUnit counts. `manifest.json` hashes every independent receipt and the
authored test source. A combined actual-head full-suite/hosted run, native Windows
packaging, native manual visual/keyboard/accessibility checks and broader
performance acceptance remain the integrating owner's separate gates.
