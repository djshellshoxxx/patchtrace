"""External deterministic staging ownership controls; authored projects only."""
from __future__ import annotations

from pathlib import Path

import pytest
from test_pilot_store import make

from patchtrace.pilot import store
from patchtrace.service import ProjectService

TOKEN = '0123456789abcdef'


def test_existing_stage_directory_survives_failed_mkdir(tmp_path, monkeypatch):
    with ProjectService.sample(tmp_path / 'project') as service:
        assessment, config = make(service)
        staged = service.root / 'intelligence' / 'pilot' / f'tmp-{TOKEN}'
        staged.mkdir(parents=True)
        marker = staged / 'other-operation-evidence.json'
        marker.write_bytes(b'{"owner":"another authored operation"}\n')
        before = {p.relative_to(staged).as_posix(): p.read_bytes() for p in staged.rglob('*') if p.is_file()}
        monkeypatch.setattr(store.secrets, 'token_hex', lambda size: TOKEN)
        with pytest.raises(FileExistsError):
            store.stage(service.root, assessment, config)
        assert staged.is_dir(), 'stage cleanup deleted a directory whose mkdir failed'
        assert {p.relative_to(staged).as_posix(): p.read_bytes() for p in staged.rglob('*') if p.is_file()} == before


def test_failed_owned_stage_write_removes_only_its_new_directory(tmp_path, monkeypatch):
    with ProjectService.sample(tmp_path / 'project') as service:
        assessment, config = make(service)
        expected = service.root / 'intelligence' / 'pilot' / f'tmp-{TOKEN}'
        sibling = expected.parent / 'retained-evidence'
        sibling.mkdir(parents=True)
        marker = sibling / 'evidence.json'
        marker.write_bytes(b'authored retained bytes')
        monkeypatch.setattr(store.secrets, 'token_hex', lambda size: TOKEN)
        real_write = store._write
        calls = []
        def fail_second(path: Path, data: bytes):
            calls.append(path.name)
            if len(calls) == 2:
                raise OSError('authored second sidecar write failure')
            return real_write(path, data)
        monkeypatch.setattr(store, '_write', fail_second)
        with pytest.raises(OSError, match='authored second'):
            store.stage(service.root, assessment, config)
        assert len(calls) == 2 and not expected.exists()
        assert marker.read_bytes() == b'authored retained bytes'
