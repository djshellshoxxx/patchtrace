# Independent S110 exception-boundary review

Pinned source: `36e14051a4d36f5c66df0186f037a4905b01bf05`. No repository source changed. No target/native engine execution.

## Confirmed finding

`ui_evidence.py::EvidenceController._engine_finished` suppresses errors while saving failed/cancelled/timeout engine attempts. Three authored controls use a real sample project, actual `EnrichmentStore` publication, and `PRAGMA query_only=ON` to force SQLite refusal. All reach the missing-persistence-diagnostic assertion: no attempt row exists, the run object has been stripped from the controller outcome, and the displayed message contains only the engine failure. An ordinary writable-store control passes and stores one attempt. Result: **3 failures / 1 positive / 0 setup errors**, 1.72 s. Failure remains failure; this is not a trusted-match admission or false-success finding.

The retained probe is unchanged. A narrow follow-up should disclose that the failed attempt record could not be saved, preserve useful bounded failure details, leave existing sets intact, and keep owner-thread and stale-project guards. It must not convert an unsuccessful engine into success or mask its primary reason.

## Other inspected boundaries

| Site | Evidence and limit |
|---|---|
| `src/patchtrace/jobs.py:413` (`notify_progress`) | Observation only: primary supervision, ProcessResult and captured output are independent; an observer exception cannot mark a failed child successful. |
| `src/patchtrace/netutil.py:68` (`worker`) | Cleanup of a late abandoned response only. The caller already received Cancelled; no late successful value is published. Cleanup may fail to close a resource; this is not a success/authentication fallback. |
| `src/patchtrace/secondary/scheduler.py:99` (`emit`) | Observation-only EngineEvent callback. Typed EngineOutcome is returned independently and persistence uses on_outcome, whose ordinary-path error propagates. |
| `src/patchtrace/secondary/scheduler.py:239` (`run_engines`) | Best-effort delivery while an existing BaseException is already unwinding. Completed delivery failures may remain unpersisted, but the primary error propagates; no successful overall return. No atomic durable-outcome guarantee proven. |
| `src/patchtrace/service.py:69` (`_rollback_creation`) | Cleanup only after create raised BaseException. Unknown snapshot state is retained, owned-file removal is guarded, the original exception is reraised. Closing failure may retain lock/resources; it does not authorize project success. |
| `src/patchtrace/service.py:74` (`_rollback_creation`) | Cleanup only after create raised BaseException. Unknown snapshot state is retained, owned-file removal is guarded, the original exception is reraised. Closing failure may retain lock/resources; it does not authorize project success. |
| `src/patchtrace/ui_engine_setup.py:137` (`_save`) | Optional setup presentation/config path persistence (SETTING_OPEN/SETTING_PATH); does not admit input, persist evidence or grant network consent. A failed write leaves the existing configured path until a later successful write. |
| `src/patchtrace/ui_evidence.py:579` (`_save`) | Optional filter/hide_agreed/show_index presentation preferences. Does not change matching evidence, provenance or engine completion. |
| `src/patchtrace/ui_evidence.py:1229` (`_engine_finished`) | CONFIRMED persistence diagnostic omission: failed/cancelled/timeout run publication can raise; the exception is swallowed and the full EngineRun is then dropped from outcomes. The engine status stays failed/cancelled/timeout. No new trusted match set and no false success observed. |
| `src/patchtrace/unified/extract/ghidra_script.py:320` (`probe_versions`) | Optional version probe preserves explicit unknown defaults. Does not invent a supported version, execute a target, or admit new matching evidence. |
| `src/patchtrace/unified/extract/ghidra_script.py:324` (`probe_versions`) | Optional version probe preserves explicit unknown defaults. Does not invent a supported version, execute a target, or admit new matching evidence. |
| `src/patchtrace/unified/extract/ghidra_script.py:783` (`run`) | Project.close cleanup after return/error from bounded extraction and program hash check. It does not bypass the primary hash/read/extraction status; native cleanup behavior not tested. |
| `src/patchtrace/unified/extract/ghidra_script.py:853` (`_write_decomp`) | Decompiler.dispose cleanup after per-function status/code collection. Failed disposal does not alter recorded per-function statuses; output write failure still propagates. Native disposal not tested. |

These are source-based classifications, not blanket security closure. Swallowed cleanup errors may leave resources or attempted-delivery records unavailable; native cleanup and total resource accounting are not qualified by this review. The scheduler retains its primary exception on interrupted delivery. Optional settings persistence does not guarantee a future reopen will remember the selection.
