"""Authored read-only review controls: actual SQLite publication, no engine execution."""
from pathlib import Path

import pytest
from qt_support import join_gui_threads, main_window, settings  # noqa: F401

from patchtrace.enrichment.storage import EnrichmentStore
from patchtrace.secondary.evidence_panel_service import RunRequest, latest_run
from patchtrace.secondary.evidence_view import EngineOutcomeView
from patchtrace.secondary.runs import EngineRun


def attempt(window, status):
    controller = window.panels.controller('evidence')
    project = window.service.project
    current = latest_run(project)
    sides = {a.side: a.sha256 for a in project.artifacts}
    controller.run_generation += 1
    controller.run_request = RunRequest(
        project.id, project.revision, controller.run_generation, ('rz-diff',), 1, 60,
        Path('older'), Path('newer'), sides['older'], sides['newer'], current.id)
    record = EngineRun(
        run_id='review-attempt-' + status, engine='rz-diff', engine_version='0.9.1',
        executable_path_sha256=None, argv_digest='a' * 64,
        older_sha256=sides['older'], newer_sha256=sides['newer'], orientation='older->newer',
        cache_key='b' * 64, status=status, error_code='PT-SECONDARY-RUN', returncode=3,
        started_utc='2026-11-18T12:00:00Z', duration_ms=1, stderr_tail='',
        output_sha256=None, match_set_id=None)
    view = EngineOutcomeView('rz-diff', status, version='0.9.1', error_code='PT-SECONDARY-RUN',
                             message='authored engine failure', run=record,
                             run_id=record.run_id, started_utc=record.started_utc)
    return controller, view


def rows(window):
    return EnrichmentStore(window.service.store).entries(kind='engine-run')


def test_normal_failed_attempt_is_retained(main_window):
    controller, view = attempt(main_window, 'failed')
    controller._engine_finished(view, controller.run_generation)
    assert len(rows(main_window)) == 1
    assert controller.outcomes['rz-diff'].status == 'failed'


@pytest.mark.parametrize('status', ['failed', 'cancelled', 'timeout'])
def test_failed_attempt_storage_failure_is_reported(main_window, status, monkeypatch):
    controller, view = attempt(main_window, status)
    messages = []
    original = controller.panel.set_run_status

    def capture(message):
        messages.append(message)
        original(message)

    monkeypatch.setattr(controller.panel, 'set_run_status', capture)
    connection = main_window.service.store.connection
    connection.execute('PRAGMA query_only=ON')
    try:
        controller._engine_finished(view, controller.run_generation)
        assert rows(main_window) == []
        assert controller.outcomes['rz-diff'].status == status
        assert controller.outcomes['rz-diff'].run is None
        assert any('could not store' in m.lower() or 'not saved' in m.lower() for m in messages), messages
    finally:
        connection.execute('PRAGMA query_only=OFF')
