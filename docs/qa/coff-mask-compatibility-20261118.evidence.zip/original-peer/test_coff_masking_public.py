"""Source-layer acceptance with an authored assembly producer; no compiler/target execution."""
from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

import pytest

from tools.calibration.mutations import engine

EVIDENCE = Path(__file__).parent/'coff-mask-public'
EVIDENCE.mkdir(exist_ok=True)


@pytest.mark.parametrize(('quoted', 'code_changes'), [(True, False), (False, False), (False, True)])
def test_source_layer_rejects_data_only_relocation_name_changes(monkeypatch, quoted, code_changes):
    emitted = []

    def fake_compile(argv, *, cwd, timeout):
        text = (Path(cwd)/'m.c').read_text()
        changed = 'hello!' in text
        symbol = '??_C@_06GANFPHOD@hello?$CB?$AA@' if changed else '??_C@_05CJBACGMB@hello?$AA@'
        if quoted:
            symbol = '"'+symbol+'"'
        number = 2 if changed and code_changes else 1
        assembly = f'shout:\nmovl ${number}, %edx\nleaq {symbol}(%rip), %rcx\njmp emit\n.seh_endproc\n'
        (Path(cwd)/'_masked.s').write_text(assembly)
        emitted.append(assembly)
        return SimpleNamespace(returncode=0)

    monkeypatch.setattr(engine, 'run_tool', fake_compile)
    before = {'m.c': 'void emit(char*); void shout(void) { emit("hello"); }'}
    after = {'m.c': 'void emit(char*); void shout(void) { emit("hello!"); }'}
    candidate = SimpleNamespace(file='m.c', function='shout', operator='string-literal')
    check = engine.make_masked_body_check(before, SimpleNamespace(path=lambda name:'authored-clang'))
    rejection = check(candidate, after)
    (EVIDENCE/f'quoted-{quoted}-code-{code_changes}.json').write_text(json.dumps(dict(
        quoted=quoted, code_changes=code_changes, emitted_assembly=emitted, rejection=rejection,
        meaning='The injected producer models the emitted assembly shape. This is source-layer acceptance behavior, not native compiler compatibility.'), indent=2)+'\n')
    assert rejection == (None if code_changes else 'masked body unchanged')


def test_unavailable_body_remains_rejected(monkeypatch):
    monkeypatch.setattr(engine, 'run_tool', lambda *a, **kw: SimpleNamespace(returncode=1))
    check = engine.make_masked_body_check({'m.c':'void shout(void) {}'}, SimpleNamespace(path=lambda name:'authored-clang'))
    reason = check(SimpleNamespace(file='m.c',function='shout',operator='string-literal'), {'m.c':'void shout(void) {}'})
    assert reason == 'masked body not comparable (function not emitted at -O2)'
