"""Retain unique, source-pinned local checks; no native/compiler test node is selected here."""
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('/workspace/scratch/c7a9e8d98848/security-residual-qa')
QA = Path(__file__).resolve().parent
PYTHON = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
FILES = ('tools/calibration/mutations/engine.py', 'tools/calibration/mutations/contracts.py',
         'tools/calibration/tier_r/bodyhash.py', 'tools/calibration/tier_r/factory.py',
         'tests/test_mutations_coff_compatibility.py', 'docs/specs/known-answer-corpus.md')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True)


def hashes():
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in FILES}


label, *arguments = sys.argv[1:]
assert label.replace('-', '').isalnum()
assert not (QA / (label + '.log')).exists(), 'Do not overwrite retained receipts'
status = git('status', '--porcelain')
assert status == '', status
env = dict(os.environ, PYTHONPATH=str(ROOT / 'src') + ':' + str(ROOT / 'tests') + ':' + str(ROOT),
           QT_QPA_PLATFORM='offscreen', PATCHTRACE_COFF_REVIEW_ROOT=str(ROOT))
command = [PYTHON, '-m', 'pytest', '-q', *arguments, '--junitxml=' + str(QA / (label + '.xml'))]
imported = subprocess.check_output([PYTHON, '-c',
    'from pathlib import Path; from tools.calibration.mutations import engine; print(Path(engine.__file__).resolve())'],
    cwd=ROOT, env=env, text=True).strip()
assert imported == str(ROOT / 'tools/calibration/mutations/engine.py')
context = {'head': git('rev-parse', 'HEAD').strip(), 'branch': git('branch', '--show-current').strip(),
           'status': status, 'cwd': str(ROOT), 'argv': command, 'imported_engine': imported,
           'environment': {k: env[k] for k in ('PYTHONPATH', 'QT_QPA_PLATFORM', 'PATCHTRACE_COFF_REVIEW_ROOT')},
           'sha256': hashes()}
(QA / (label + '-context.json')).write_text(json.dumps(context, indent=2) + '\n')
started = time.monotonic()
with (QA / (label + '.log')).open('w') as output:
    result = subprocess.run(command, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=120)
receipt = {'returncode': result.returncode, 'elapsed_seconds': time.monotonic() - started,
           'status_after': git('status', '--porcelain'), 'sha256_after': hashes()}
(QA / (label + '-exit.json')).write_text(json.dumps(receipt, indent=2) + '\n')
assert receipt['sha256_after'] == context['sha256'] and receipt['status_after'] == ''
print(json.dumps({'label': label, 'head': context['head'], 'returncode': result.returncode,
                  'elapsed_seconds': receipt['elapsed_seconds']}))
print((QA / (label + '.log')).read_text()[-6000:])
raise SystemExit(result.returncode)
