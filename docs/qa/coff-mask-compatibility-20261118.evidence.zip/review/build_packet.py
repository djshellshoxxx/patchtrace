import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

ROOT = Path('/workspace/scratch/c7a9e8d98848/security-residual-qa')
QA = Path(__file__).resolve().parent
PEER = QA.parent / 'semantic-disposition-batch5'
SOURCE = 'ce093ec56260944869fa28e12c26c79eb1dd4c78'
NAME = 'coff-mask-compatibility-20261118'
DEST = ROOT / 'docs/qa'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
payloads = { 'review/' + p.relative_to(QA).as_posix(): p.read_bytes()
             for p in sorted(QA.rglob('*')) if p.is_file() and '__pycache__' not in p.parts }
for name in ('coff-mask-public.command.json', 'coff-mask-public.log', 'coff-mask-public.xml',
             'historical-coff.command.json', 'historical-coff.log', 'historical-coff.xml',
             'test_coff_masking_public.py', 'historical/coff/tests/test_mutations_more.py'):
    payloads['original-peer/' + name] = (PEER / name).read_bytes()
for path in sorted((PEER / 'coff-mask-public').glob('*.json')):
    payloads['original-peer/' + path.relative_to(PEER).as_posix()] = path.read_bytes()
source_manifest = json.loads((QA / 'source-manifest.json').read_text())
for item in source_manifest['files']:
    content = (ROOT / item['path']).read_bytes()
    assert hashlib.sha256(content).hexdigest() == item['sha256']
    payloads['source/' + item['path']] = content
for name in ('tools/calibration/tier_r/factory.py', 'tools/calibration/tier_r/bodyhash.py'):
    payloads['source/' + name] = (ROOT / name).read_bytes()
payloads['README.md'] = (DEST / (NAME + '.md')).read_bytes()
archive = DEST / (NAME + '.evidence.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as retained:
    for name, content in sorted(payloads.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        retained.writestr(info, content)
manifest = {'source': SOURCE, 'baseline': source_manifest['baseline'], 'archive': archive.name,
            'archive_bytes': archive.stat().st_size,
            'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'payloads': [{'path': n, 'bytes': len(c), 'sha256': hashlib.sha256(c).hexdigest()}
                         for n, c in sorted(payloads.items())]}
(DEST / (NAME + '.manifest.json')).write_text(json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as retained:
    assert sorted(retained.namelist()) == sorted(payloads)
    for item in manifest['payloads']:
        content = retained.read(item['path'])
        assert len(content) == item['bytes'] and hashlib.sha256(content).hexdigest() == item['sha256']
print(json.dumps({'source': SOURCE, 'payloads': len(payloads), 'bytes': manifest['archive_bytes'],
                  'sha256': manifest['archive_sha256']}))
