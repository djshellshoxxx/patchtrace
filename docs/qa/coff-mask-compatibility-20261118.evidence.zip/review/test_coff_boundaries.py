"""Independent authored assembly boundary controls. No compiler or target is run."""
from pathlib import Path
from types import SimpleNamespace

import pytest

from tools.calibration.mutations import contracts as C
from tools.calibration.mutations import engine

ROOT = Path('/workspace/scratch/c7a9e8d98848/security-residual-qa')
assert Path(engine.__file__).resolve() == ROOT / 'tools/calibration/mutations/engine.py'
OLD_SYMBOL = '??_C@_05CJBACGMB@hello?$AA@'
NEW_SYMBOL = '??_C@_06GANFPHOD@hello?$CB?$AA@'
BEFORE = {'m.c': 'void emit(char*); void shout(void) { emit("hello"); }'}
AFTER = {'m.c': BEFORE['m.c'].replace('"hello"', '"hello!"')}
CHAIN = SimpleNamespace(path=lambda name: 'authored-clang')


def install(monkeypatch, before, after):
    def authored_assembly(argv, *, cwd, timeout):
        changed = 'hello!' in Path(cwd, 'm.c').read_text()
        instructions = after if changed else before
        Path(cwd, '_masked.s').write_text('shout:\n' + '\n'.join(instructions) + '\n.seh_endproc\n')
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(engine, 'run_tool', authored_assembly)
    return engine.make_masked_body_check(BEFORE, CHAIN)


@pytest.mark.parametrize('name,before,after,equal', [
    ('unquoted-coff', [f'leaq {OLD_SYMBOL}(%rip), %rcx'], [f'leaq {NEW_SYMBOL}(%rip), %rcx'], True),
    ('unquoted-coff-plus', [f'leaq {OLD_SYMBOL}+4(%rip), %rcx'],
     [f'leaq {NEW_SYMBOL}+8(%rip), %rcx'], True),
    ('unquoted-coff-minus', [f'leaq {OLD_SYMBOL}-4(%rip), %rcx'],
     [f'leaq {NEW_SYMBOL}-8(%rip), %rcx'], True),
    ('quoted-coff-minus', [f'leaq "{OLD_SYMBOL}"-4(%rip), %rcx'],
     [f'leaq "{NEW_SYMBOL}"-8(%rip), %rcx'], True),
    ('plain-symbol-addend', ['leaq old_name+4(%rip), %rcx'], ['leaq new_name-8(%rip), %rcx'], True),
    ('local-rip-symbol', ['leaq .L.str1(%rip), %rcx'], ['leaq .L.str2(%rip), %rcx'], True),
    ('branch-target', ['jmp old_target'], ['jmp new_target'], True),
    ('call-target', ['callq old_target'], ['callq new_target'], True),
    ('branch-opcode', ['je .LBB0_1'], ['jne .LBB0_2'], False),
    ('instruction-opcode', ['movl $1, %edx'], ['addl $1, %edx'], False),
    ('immediate', ['movl $1, %edx'], ['movl $2, %edx'], False),
    ('register', ['movl $1, %edx'], ['movl $1, %r8d'], False),
    ('non-rip-offset', ['movl 4(%rcx), %eax'], ['movl 8(%rcx), %eax'], False),
    ('rip-base', ['movl old_name(%rip), %eax'], ['movl old_name(%rcx), %eax'], False),
])
def test_masked_body_keeps_the_existing_instruction_and_address_boundary(monkeypatch, name, before, after, equal):
    check = install(monkeypatch, before, after)
    candidate = SimpleNamespace(file='m.c', function='shout', operator='string-literal')
    observed = check(candidate, AFTER)
    assert observed == ('masked body unchanged' if equal else None), (name, observed)


def test_unquoted_symbol_only_difference_does_not_reject_a_cosmetic_case(monkeypatch):
    check = install(monkeypatch, [f'leaq {OLD_SYMBOL}(%rip), %rcx'], [f'leaq {NEW_SYMBOL}(%rip), %rcx'])
    candidate = SimpleNamespace(file='m.c', function='shout', operator='ws-comment')
    # The producer is authored. This checks the equality branch of the source-layer policy;
    # it does not claim a real cosmetic compiler mutation generates these names.
    assert check(candidate, AFTER) is None


def test_apply_case_records_rejection_from_the_optional_source_layer_check(monkeypatch):
    check = install(monkeypatch, [f'leaq {OLD_SYMBOL}(%rip), %rcx', 'jmp emit'],
                    [f'leaq {NEW_SYMBOL}(%rip), %rcx', 'jmp emit'])
    base = C.SourceRef(suite='_review/coff', version='authored-1', license_spdx='MIT')
    with pytest.raises(engine.NoMutationSite) as rejected:
        engine.apply_case(BEFORE, 'string-literal', seed=3, base=base, checker=lambda files, rel: None,
                          target=('m.c', 'shout'), extra_check=check)
    assert [item.reason for item in rejected.value.rejected] == ['masked body unchanged']
