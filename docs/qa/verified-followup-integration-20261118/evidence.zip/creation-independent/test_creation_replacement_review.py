"""Independent replacement at the abandoned-database admission boundary."""
import sqlite3

import pytest

from patchtrace import persistence
from patchtrace.sample import synthetic_pe
from patchtrace.service import ProjectService


def test_verified_empty_database_cannot_authorize_deleting_a_replacement(tmp_path, monkeypatch):
    root = tmp_path / 'case'
    persistence.ProjectStore(root, create=True).close()
    path = root / 'project.sqlite3'
    foreign = tmp_path / 'foreign.sqlite3'
    with sqlite3.connect(foreign) as db:
        db.execute('CREATE TABLE notes (value TEXT)')
        db.execute('INSERT INTO notes VALUES (?)', ('independent retained record',))
    foreign_bytes = foreign.read_bytes()
    checked = persistence._abandoned_creation
    changed = []

    def replacement(candidate):
        accepted = checked(candidate)
        assert accepted
        foreign.replace(candidate)
        changed.append(candidate)
        return accepted

    monkeypatch.setattr(persistence, '_abandoned_creation', replacement)
    pair = tmp_path / 'old.dll', tmp_path / 'new.dll'
    for number, p in enumerate(pair):
        p.write_bytes(synthetic_pe(number))
    with pytest.raises(ValueError):
        with ProjectService.create(*pair, 'must preserve replacement', root):
            pass
    assert changed == [path]
    assert path.read_bytes() == foreign_bytes
