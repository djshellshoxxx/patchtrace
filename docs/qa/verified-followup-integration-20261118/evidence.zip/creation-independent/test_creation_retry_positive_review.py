"""Independent transaction interruption and literal URI-name controls."""
from pathlib import Path

import pytest

from patchtrace import persistence
from patchtrace import service as services
from patchtrace.sample import synthetic_pe
from patchtrace.service import ProjectService


def pair(tmp_path):
    paths = tmp_path / 'old.dll', tmp_path / 'new.dll'
    for number, path in enumerate(paths):
        path.write_bytes(synthetic_pe(number))
    return paths


@pytest.mark.parametrize('retry', [False, True])
def test_literal_uri_characters_survive_create_save_and_reopen(tmp_path, retry):
    root = tmp_path / 'spaces # percent% query? snowman\u2603'
    sources = pair(tmp_path)
    if retry:
        root.mkdir()
        (root / 'project.sqlite3').touch()
    with ProjectService.create(*sources, 'literal path', root) as service:
        identity = service.project.id
        assert service.root == root
    with ProjectService.open(root) as service:
        assert service.project.id == identity
        assert service.project.name == 'literal path'
    assert not (tmp_path / 'spaces ').exists()


@pytest.mark.parametrize('zero', [False, True])
def test_interrupted_retry_keeps_original_file_and_releases_owner(tmp_path, monkeypatch, zero):
    root = tmp_path / 'retry'
    persistence.ProjectStore(root, create=True).close()
    path = root / 'project.sqlite3'
    if zero:
        path.write_bytes(b'')
    before = path.read_bytes(), path.stat().st_ino
    sources = pair(tmp_path)
    inspect = services.inspect_artifact

    def stop(*args, **kwargs):
        raise KeyboardInterrupt('authored cancellation')

    monkeypatch.setattr(services, 'inspect_artifact', stop)
    with pytest.raises(KeyboardInterrupt):
        ProjectService.create(*sources, 'interrupted', root)
    assert (path.read_bytes(), path.stat().st_ino) == before
    monkeypatch.setattr(services, 'inspect_artifact', inspect)
    with ProjectService.create(*sources, 'retry succeeds', root) as service:
        assert service.project.name == 'retry succeeds'
    assert not any(p.suffix == '.sqlite3' for p in Path(tmp_path).iterdir())
