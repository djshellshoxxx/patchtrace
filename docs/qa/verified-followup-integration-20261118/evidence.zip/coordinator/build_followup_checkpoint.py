"""Seal reviewed follow-up evidence and append its current qualification state."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/c7a9e8d98848')
REPO = ROOT / 'followup-integration'
SOURCE = '3be3af166897fc2376dc64850edc66485273dea1'
MAIN = '9c411ca3d7b47f950be5f0c6f01b3c54184554c6'
DEST = REPO / 'docs/qa/verified-followup-integration-20261118'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save_json(path, value):
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2) + '\n')


assert git('rev-parse', 'HEAD') == SOURCE
assert not git('status', '--porcelain')
assert '[no release]' in git('show', '-s', '--format=%B', 'HEAD')
source_tree = git('rev-parse', 'HEAD^{tree}')
proof = json.loads((ROOT / 'qa/followup-integration/source-preservation-3be3af16.json').read_text())
assert proof['source_sha'] == SOURCE and proof['source_tree'] == source_tree
gate = ROOT / 'qa/followup-integration/combined-3be3af16'
outcome = json.loads(gate.with_name(gate.name + '-exit.json').read_text())
assert outcome == {'source': SOURCE, 'exit_code': 0}
xml = ET.parse(gate.with_suffix('.xml')).getroot()
suites = list(xml.iter('testsuite'))
assert sum(int(s.get('failures', 0)) + int(s.get('errors', 0)) for s in suites) == 0
total = sum(int(s.get('tests', 0)) for s in suites)
skipped = sum(int(s.get('skipped', 0)) for s in suites)
passed = total - skipped
assert skipped == 3 and passed == 1770, (total, skipped, passed)
assert all(s.get('type') == 'pytest.xfail' for s in xml.iter('skipped'))

# These are observations of a prior source, never acceptance for SOURCE.
native = {
    'source_head': 'd8c02caea407f6d323eecd636735849c1eb31a2d',
    'actual_checkout': 'f756d7f151857755c993ebeb95f7a27e1487b9d4',
    'checkout_tree': 'ee85c94f12c8c52952ca0ced7b0f481e0ef2d674',
    'source_identity_receipt': 'prior-native/source-proof.json',
    'qa_run': 44319420711,
    'linux': {'job': 134854287281, 'passed': 22874, 'skipped': 50, 'xfailed': 6,
              'artifact': 14442796311, 'seconds_from_log': 2037.36},
    'windows': {'job': 134854286667, 'passed': 22796, 'skipped': 129, 'xfailed': 5,
                'artifact': 14445155029, 'seconds_from_log': 3509.0},
    'qt': {'windows': {'job': 134854287353, 'iterations': 5, 'passed': 10150},
           'linux': {'iterations': 20, 'shards': [
               {'job': 134854287484, 'passed': 12200},
               {'job': 134854287523, 'passed': 10580},
               {'job': 134854287414, 'passed': 8980},
               {'job': 134854287654, 'passed': 8840}]}},
    'packages': {
        'windows': {'artifact': 14443299723, 'bytes': 136239385,
                    'sha256': 'db365335f39fa2a3ddd25cf37644ff6b092580c484d6ead13b26e5cbffc3496f',
                    'proof': 'Hosted checksum/extraction/self-test and NSIS 3.13 install/registration/uninstall logs; root did not download/re-hash large package.'},
        'linux': {'artifact': 14443794808, 'bytes': 97047671,
                  'sha256': '6f5057dcfe0592c433a51be1d04a0351899301cd2fdde8d976e857bacb9ca547',
                  'job': 134934095247, 'smoke_jobs': [134941232165, 134941232477],
                  'proof': 'Hosted artifact and tarball checksum, executable, offscreen and XCB/Xvfb smoke logs on Ubuntu 22.04 and 24.04; root did not download/re-hash large package.'}},
    'unified': {'run': 44319418139, 'windows_job': 134854104868,
                'linux_job': 134881469509, 'windows_artifact': 14437941349,
                'linux_artifact': 14445347226, 'cross_os_content_equal': True,
                'extract_script_sha256': '3901f3a8c369b3350b98566a46666258f9b2c79a1704f7fcdad2a64c502de49e',
                'scope': 'Two recorded fixture pairs; own analysis/GZF/Ghidriff retention equality; hm is intentionally coarser and refines, not full class equality. Not independent CVE accuracy.'},
    'bindiff_windows': {'job': 134854104769, 'artifact': 14438536883,
                        'job_conclusion': 'success', 'artifact_status': 'blocked',
                        'reason': 'no_network currently implemented only with Linux unshare; no effective Windows denial evidence'},
    'compiler_sweep': {'run': 44319417948, 'merge_job': 134894828258,
                       'artifact': 14444079607, 'job_conclusion': 'success',
                       'artifact_status': 'warning', 'engine': 'rz-diff',
                       'version': '0.9.1', 'attempted': 11, 'completed': 5, 'failed': 6,
                       'reason': 'Six tiny synthetic AA/mutation/noise/authored pairs report no functions in the older input. A separate byte-identical source-only case is skipped. Aggregate smoke metrics are not calibrated production accuracy.'},
}
save_json(ROOT / 'qa/followup-checkpoint/native-review.json', native)

history = []
for commit in git('rev-list', '--reverse', '--first-parent', 'b41d6631..HEAD').splitlines():
    history.append({'sha': commit, 'parents': git('show', '-s', '--format=%P', commit).split(),
                    'tree': git('rev-parse', commit + '^{tree}'),
                    'message': git('show', '-s', '--format=%B', commit)})
save_json(ROOT / 'qa/followup-integration/integration-history.json', history)

payload = {}
for source, prefix in [
    (ROOT / 'qa/followup-integration', 'integration'),
    (ROOT / 'qa/followup-checkpoint', 'hosted'),
    (ROOT / 'qa/current-native', 'prior-native'),
]:
    for p in sorted(source.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and not p.name.endswith('.pyc'):
            payload[prefix + '/' + p.relative_to(source).as_posix()] = p.read_bytes()
for p in sorted((ROOT / 'qa/creation-schema').glob('root-*')):
    if p.is_file():
        payload['creation-independent/' + p.name] = p.read_bytes()
for name in ['test_creation_replacement_review.py', 'test_creation_retry_positive_review.py',
             'creation-replacement-red.log', 'creation-replacement-red.xml']:
    p = ROOT / 'qa' / name
    assert p.is_file(), p
    payload['creation-independent/' + name] = p.read_bytes()
for name in ['verify_followup_sources.py', 'resolve_record_appends.py', 'build_followup_checkpoint.py']:
    payload['coordinator/' + name] = (ROOT / 'ops' / name).read_bytes()
assert all(not n.startswith('/') and '..' not in Path(n).parts for n in payload)
DEST.mkdir(parents=True, exist_ok=False)
archive = DEST / 'evidence.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, data in sorted(payload.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        z.writestr(info, data, compresslevel=9)
archive_data = archive.read_bytes()
manifest = {
    'schema': 'patchtrace-followup-checkpoint/1', 'source_sha': SOURCE,
    'source_tree': source_tree, 'main_observed': MAIN,
    'github_capture': '2026-11-18 16:43:56 UTC (08:43:56 America/Los_Angeles)',
    'archive': archive.name, 'archive_bytes': len(archive_data),
    'archive_sha256': sha(archive_data), 'member_count': len(payload),
    'members': [{'path': n, 'bytes': len(b), 'sha256': sha(b)} for n, b in sorted(payload.items())],
}
save_json(DEST / 'manifest.json', manifest)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist()) == set(payload)
    for m in manifest['members']:
        b = z.read(m['path'])
        assert len(b) == m['bytes'] and sha(b) == m['sha256']

readme = f'''# Reviewed follow-up integration checkpoint — 2026-11-18

The reviewed follow-up candidate combines the actual published heads of PRs
#308–#315 with the retained #304/#307 chain, then selectively ports the scanner,
project-retry and two callgraph repairs. **Canonical main remains `{MAIN}`.**
No main merge, PR closure, remote branch deletion, release, tag or deployment
occurred. Qualification remains open; this is not a beta-ready declaration.

## Source and independent verification

- Branch: `codex/verified-followup-integration-20261118`.
- Tested integration source: **`{SOURCE}`**.
- Tested tree: **`{source_tree}`**.
- Base: actual published #314, `b41d6631e679ad2777d248fa087ea71582a5bf63`;
  it retains actual #313, #307 and #304 ancestors.
- Combined selected gate: **1,770 passed / three existing expected failures**.
  The exact command, absolute current-source `PYTHONPATH`, offscreen setting,
  log, JUnit and exit code are in `integration/combined-3be3af16*`.
- The earlier combined source `7023c3ad` passed 1,744 with the same three xfails;
  predecessor `ff4f8360` passed 1,025 with three xfails. These are different
  source-pinned selections, not additive unique coverage or a full-suite pass.
- Normal `python -m ruff check src tests tools` passes at `36e14051`, whose
  source/test/tool/workflow bytes equal the tested source. Path QA was the only
  later change. Archived QA copies are not normal lint scope.
- Independent source-preservation verification accounts for all **75** changed
  source/test/tool/workflow files relative to published #307. Every file matches
  a reviewed owner, except the explicitly reviewed combined `ui.py` hunks for
  raw navigation and environment defaults. Actual published parent ancestry is
  checked. No manual production-code conflict resolution was needed.

The three expected failures remain the existing CODEX action-pinning, pip-hash
and corpus-cache requirements. They have not been disabled or reclassified.
The new source still needs full Linux/Windows, repeated Qt, native, package,
dependency and security qualification. Prior source results do not satisfy it.

## Published PRs preserved

The latest REST observation at **08:43:56 PST on November 18** retains main at
the SHA above and lists 62 open PRs. That is a later PR observation, not a
replacement for the original complete 307-branch/297-PR inventory.

| PR | Exact published head | Scope / current disposition |
|---|---|---|
| [#304](https://github.com/djshellshoxxx/patchtrace/pull/304) | `d8c02caea407f6d323eecd636735849c1eb31a2d` | Reviewed CVE consolidation and native publication/chronology repairs; still open and blocked by acceptance semantics and later repairs. |
| [#307](https://github.com/djshellshoxxx/patchtrace/pull/307) | `58fc130631f602b6e907bb054d30c21d810551d4` | Retained KB sources/identity; includes actual #304 and original #307 history; still open, current full/platform checks incomplete. |
| [#308](https://github.com/djshellshoxxx/patchtrace/pull/308) | `92a411bf02fc8beb00b7a148e39db2bf68efa061` | Strings no-clobber publication. |
| [#309](https://github.com/djshellshoxxx/patchtrace/pull/309) | `3c9d3f074481b2f609330fa49ab9019eb6637849` | Bounded paired physical-offset desktop navigation. |
| [#310](https://github.com/djshellshoxxx/patchtrace/pull/310) | `26558cd0723aa5fa6d883f2935ad3c43cef94a86` | Saved/recent searches and delayed-Build intent repair. |
| [#311](https://github.com/djshellshoxxx/patchtrace/pull/311) | `09b032f205f4ffa1838bef56007ebdb7a2308420` | Primary-child environment minimization by default. |
| [#312](https://github.com/djshellshoxxx/patchtrace/pull/312) | `573829f33c84e9b2d53ba51ebd7f699e39f406fe` | Fail-closed source/run/native/security/release qualification. |
| [#313](https://github.com/djshellshoxxx/patchtrace/pull/313) | `a4061979547ef88855fbdb085228a42c3be21603` | Bounded retained advisory reads. |
| [#314](https://github.com/djshellshoxxx/patchtrace/pull/314) | `b41d6631e679ad2777d248fa087ea71582a5bf63` | Current retained-CVRF/Leads/report context plus SQLite type/row budgets. |
| [#315](https://github.com/djshellshoxxx/patchtrace/pull/315) | `23fbe4a54880319f62f40f3196794f85b6cdaec5` | Parser-level manifest DTD refusal. |

Actual #308, #309, #310, #311, #312 and #315 heads are merge parents of this
candidate, and #313 is retained through #314. The separate local/remote commit
mapping for #309–#315 is archived in `hosted/publication-mapping-complete.json`.
All integration messages retain the literal `[no release]` hold. No older PR is
closed as superseded before its valuable behavior is verified in canonical main.

## New reviewed slices

| Slice | Independent evidence and source | Implemented boundary / remaining limits |
|---|---|---|
| Scanner provenance | `b61e1593`; 128 root checks, original five identity contradictions retained | Complete inventories, interpreter/native-environment ownership, installation-report issuers, raw outputs and explicit refusals. Initial actual scans remain failed evidence. |
| Explicit bootstrap repair | `0c004b68`; 160 independent checks; author affected 631 / three existing xfails | Fresh ensurepip inventory and exact hashed pip-only 25.0.1→26.3 transition. Actual Linux runtime17/packaging32 audits include pip and report zero advisories/skips/fixes. Static remains79; Windows/current-integrated scans are unverified. |
| Incomplete-project schema and replacement refusal | `8b3c6472`; root236 affected and five additional controls | Refuse foreign views/triggers/columns and companions; use verified retries in place; validate the actual connected database; rollback preserves retry bytes/inodes. Root's original replacement-data-loss failure is retained. Arbitrary noncooperating namespace races and native Windows are not claimed solved. |
| Callgraph cap truth | `2c69c4ad`; root464 affected and six unchanged historical controls | Deduplicate roots before caps; carry omissions through query, JSON/DOT, CLI and Calls state. Synthetic CLI/Qt journey preserved exact omitted counts and unchanged database bytes. |
| Shared callgraph path budget | `f0b0eb02`; root490 affected/oracle checks and17 unchanged historical controls | One adjacency budget across discovery/reverse/enumeration; lazy CSR; cancellation; valid canonical witness retained after later exhaustion. Authored finite oracle and five real headless CLI invocations remain synthetic source evidence. |

The source/QA commits are selectively ported with original attribution. Their
sealed packets were independently checked for archive size, SHA-256, duplicate
names, CRC and every member hash. The two creation packets retain34/32 members;
semantic batch1 has74; cap88; bootstrap239; path67. The scanner's prior298-member
archive remains unchanged. Counts above describe separate overlapping gates,
not added test coverage or a product completion percentage.

The broader reviewed security changes retained through #308–#315 also include
exclusive strings publication, bounded advisory reads, SQLite storage-class
and16MiB metadata limits, parser-recognized DTD rejection, current-evidence
revalidation, minimized child environments, and release-source/artifact proof.
Their original reproducers and independent reviews remain in the linked QA
records. The manifest issue was internal-entity expansion through a text-screen
bypass; no external-entity exploit is asserted. Environment minimization is not
a network sandbox. Existing primary memory/output and wider TOCTOU questions
remain separate security work.

## Hosted #304 qualification: source and limits

The inspected jobs checked out GitHub merge preview
`f756d7f151857755c993ebeb95f7a27e1487b9d4`. Its tree
`ee85c94f12c8c52952ca0ced7b0f481e0ef2d674` equals actual #304's tree, with
main and #304 as parents. Raw logs, API observations, source proof and reviewed
artifact hashes are retained. This source identity does **not** transfer to
#307 or this newer integration candidate.

| Gate | Current-session observed result at #304 | Qualification scope |
|---|---|---|
| Full Linux QA | 22,874 passed;50 skipped;6 xfailed;2,037.36s | JUnit and raw log checked. Skips remain unverified. |
| Full Windows QA | 22,796 passed;129 skipped;5 xfailed;3,509s | JUnit and raw log checked. Platform/native/optional skips retained. |
| Publication prerequisite | Linux108 pass/2 native-Windows skips; Windows107 pass/3 Linux-specific skips | The native Windows replacement tests actually ran. |
| Repeated Qt | Windows5 iterations:10,150 passes. Linux20 iterations across4 shards:12,200/10,580/8,980/8,840 passes | Repeated executions, not unique-test totals or manual accessibility acceptance. |
| Windows portable/installer | Hosted ZIP checksum/extraction/dependency/self-test and NSIS3.13 installation, registration, frozen Qt and non-destructive uninstall pass | Large package was not independently downloaded/rebuilt by root. |
| Linux package | Build and Ubuntu22.04/24.04 artifact/tarball checksums, offscreen and XCB/Xvfb self-tests pass | Large package was not independently downloaded/rebuilt by root. |
| Rizin fixtures | Real0.9.1 on Linux and Windows,30/322 fixture matches | Fixture compatibility only; not CVE/function accuracy. |
| Ghidriff | Clean and seeded-store variants return0; raw cache hit verified; plain upstream cached-PDB case reproduces expected FileExistsError | Expected negative is not a successful comparison. Some runtime JVM identities remain unverified. |
| Unified extraction | Two fixture pairs pass repeated/GZF/retained-Ghidriff checks on Windows/Linux; Linux logs assert same content digests across OS | Extract script hash matches source. hm is intentionally coarser and refines; no full class-equality or calibrated-accuracy claim. |
| BinDiff | Linux native fixture passes; Windows job is green but its artifact is **blocked** on no_network | Windows effective network denial must be implemented and demonstrated. Provisioning trust evidence also remains limited. |
| Compiler sweep | Job green; artifact **warning**, only5 of11 Rizin pairs completed,6 no-functions failures | Synthetic AA/mutation/noise/authored failures preserved; separate identical-source card skipped. No promotion of research metrics. |

At08:43:56 PST all31 #304 check records are completed:28 success and3 skipped
(release, release-gate and MSVC advisory). The native artifacts above explain
why this is not full acceptance. #307 still has full/Qt work in progress and
one queued native job; duplicated earlier native-run records are kept separate.

The two full-QA artifacts were independently downloaded, hashed and CRC-checked.
`hosted/qa-artifact-review.json` retains every skipped/xfail reason, including
missing optional tools/dependencies, opposite-platform checks and unavailable
native producer inputs. Native artifact status and actual runtime contents take
precedence over the green check badge. Package hashes in `hosted/native-review.json`
are corroborated by hosted logs/API metadata, not falsely labeled root rehashes.

## Branch audit and remaining product work

The frozen mechanical inventory covers307 branches and297 PRs. Semantic batch1
reviews20 of131 unresolved tips:17 scoped behaviors are retained, while three
broad checkpoint tips retain unreviewed residue. The remaining111 tips require
semantic inspection; batch2 is assigned on this candidate. Neither counts nor
empty GitHub review lists constitute approval or completion.

Representative live CVE→approved advisory→KB/product/build→verified binary pair
→native functions→analyst review remains incomplete. Retained CVRF context now
has correct freshness/uncertainty/report behavior, but it does not turn a changed
function into a proved vulnerability fix. Real approved acquisition, PW-02 local
MSU/CAB extraction, complete packaged KB/F8 journey, explicit partial-project
recovery UI, manual/native desktop journeys, extraction metadata and the
remaining security/native/resource qualification remain open.

Frozen research is unchanged: L1 remains73 PASS/6 FAIL/0 BLOCKED/8 excluded of87;
L2 retains the original native http-parser MISS/FAIL; L3 CVE-2022-34718 remains
metadata-only with facts unverified. Current fixture or smoke receipts do not
replace these outcomes or establish predictive accuracy.

## Preserved coordination failures

The first local merge `194be690` accidentally committed conflict markers in two
documentation append files after a resolver assertion failed. Append-only
repair `04f2845b` retained both document sections; no production file was involved,
no test acceptance or publication used the unresolved tree, and no history was
rewritten. Later append conflicts were inspected and resolved with explicit
success checks. `integration/record-resolutions.jsonl` preserves each side and
stage hashes. This checkpoint records the error rather than concealing it.

The earlier selection preflight named two absent test files and stopped before
pytest; its explicitly post hoc note remains archived. Root's initial path
review hit a duplicate module-basename collection error; unchanged historical
controls then ran separately. The old cap expectation that omitted neighbours
were complete was corrected after its retained failing run, while exact visible
counts and below-cap positives remained. The initial scanner full attempt
ended137 after14 progress dots without JUnit; cause is unestablished and no full
pass is claimed. Original scans and ineffective proxy controls are also retained.

## Continuing assignments and acceptance

- Integration coordinator: publish this reviewed candidate append-only, obtain
  actual-head full/platform/native/package/scanner evidence, and merge to main
  only when its applicable gates and independent review permit it.
- Integration worker: next bounded semantic batch from the111 unreviewed tips;
  explicit preservation/port/quarantine decisions, with no blanket closure.
- CI/native worker: Windows BinDiff effective-denial design and evidence,
  preserving the original blocked artifact and avoiding assumed child isolation.
- Security reviewer: source-specific disposition of all79 strict diagnostics,
  with independent guards and reproducers before any repair. Raw findings and
  scanner policy remain intact; no suppression-based pass.
- Product/research follow-ons: approved source acquisition, complete CVE/KB
  analyst journeys, native compiler/identity limitations and frozen-failure
  investigations remain separate eligible workstreams.

The completion matrix retains named D/R evidence for these narrow deliveries;
no final G or whole-product percentage is inferred. No release is authorized.

## Retained packet

`evidence.zip`: **{len(payload):,} members**, **{len(archive_data):,} bytes**,
SHA-256 **`{sha(archive_data)}`**. `manifest.json` records exact sizes/hashes for
every member. All archive CRCs and member hashes were verified. Source/command
records and raw outcomes are complete in the packet; links to predecessor QA
remain in the repository. This documentation append will have its own commit;
only the tested source above is credited with the selected local gate.
'''
(DEST / 'README.md').write_text(readme)

appendices = {
    'docs/qa.md': f'''\n## [VERIFIED-FOLLOWUP-INTEGRATION-20261118]\n\nCombined source `{SOURCE}` preserves actual published #304/#307 and #308–#315 ancestry, plus reviewed scanner/bootstrap, project-retry and callgraph repairs. The selected current-source gate passes **1,770 cases with three existing expected failures**; all75 changed source/test/tool/workflow files have reviewed ownership. Whole normal Ruff passes on identical code bytes. No full/platform/native/package acceptance transfers from another source. Fresh #304 hosted full suites and packages pass, but Windows BinDiff remains blocked inside its green job and compiler sweep is partial5/11. Main remains `{MAIN}`; no PR merge/closure or release occurred. The checkpoint retains all original failures, source/parent mapping, independent reviews, raw hosted logs/artifacts and remaining assignments. [Complete checkpoint](qa/verified-followup-integration-20261118/README.md).\n''',
    'tasks/todo.md': '''\n### [VERIFIED-FOLLOWUP-INTEGRATION-20261118]\n\n- [x] Combine actual reviewed #308–#315 heads with the preserved #304/#307 chain, preserving append-only attribution and all prior evidence.\n- [x] Integrate independently accepted scanner provenance/bootstrap, schema/replacement refusal, callgraph cap truth and shared path budget repairs; 1,770 selected combined checks pass with three existing expected failures.\n- [x] Verify all75 changed source/test/tool/workflow file owners and independently verify sealed evidence archives; record and correct the initial documentation-conflict error append-only.\n- [x] Inspect actual #304 Linux/Windows full QA, repeated Qt, native and package receipts; distinguish green checks from blocked/partial native outcomes.\n- [ ] Publish reviewed follow-up candidate and obtain its own complete exact-head full/platform/native/package/dependency/security gates before main integration.\n- [ ] Complete the remaining111 semantic tip reviews and broad checkpoint residue; do not close older PRs before canonical proof.\n- [ ] Complete Windows BinDiff effective network denial, substantive static triage, compiler/native limitations and primary resource bounds.\n- [ ] Finish representative CVE/KB acquisition/analyst journeys, PW-02, packaged F8/recovery surfaces and manual/native acceptance.\n- [ ] Preserve frozen L1/L2 failures and L3 unverified status; qualify separate experiments without editing original outcomes.\n\nCurrent evidence and assigned work: [checkpoint](../docs/qa/verified-followup-integration-20261118/README.md). Earlier unchecked milestones remain historical observations; this dated append records completed narrow integrations without claiming final production acceptance.\n''',
    'docs/plans/autonomous-consolidation-20261118/consolidation-ledger.md': f'''\n## Reviewed combined follow-up — 2026-11-18, 08:43 PST observation\n\nMain remains `{MAIN}`; all62 observed PRs remain open. Candidate `{SOURCE}` retains actual published #308–#315 ancestry and the #304/#307 chain, then selectively ports scanner/bootstrap, project-retry and two callgraph repair chains with attribution. All75 changed production/test/tool/workflow paths have reviewed ownership; the selected combined gate passes1,770 with three existing expected failures. These are local integration commits, not main merge SHAs. No superseded closure, branch deletion, release or tag occurred.\n\nThe first semantic batch's three reproduced gaps now have accepted narrow source repairs; broad checkpoint research residue, packaged F8 and explicit partial-creation recovery remain open. The remaining111 tips enter a second bounded batch. No frozen branch entry is retroactively reclassified and no branch count becomes a product-completion score. Fresh #304 full/platform/package evidence is retained separately; its Windows BinDiff artifact is blocked and compiler sweep is partial despite green jobs. Actual combined-candidate gates are still required. See the [source, histories, independent reviews and raw evidence](../../qa/verified-followup-integration-20261118/README.md).\n''',
    'docs/plans/patchtrace-completion-matrix.md': f'''\n## Combined follow-up acceptance — 2026-11-18\n\nCurrent reviewed source `{SOURCE}` combines published #308–#315, the actual #304/#307 ancestors and selectively reviewed repairs. Main remains `{MAIN}`. The selected combined gate passes1,770 with three existing expected failures; all75 changed source/test/tool/workflow paths are accounted for. This adds scoped regression evidence, not final G acceptance. Earlier rows remain their dated baseline; the following table records the updated narrow boundaries.\n\n| Feature | Current state | Completion | Remaining work | Source | Dependencies | Tests | Security | Owner | Acceptance |\n|---|---|---|---|---|---|---|---|---|---|\n| Incomplete-project retry | Narrow schema/replacement repair integrated | D,R:50% | Native Windows and complete recovery journey; final gates | `8b3c6472`, this candidate | Project lock, SQLite connection ownership | Root236 plus5 controls; combined gate | Cooperative namespace assumptions remain explicit | Security/GUI | Foreign/replaced data preserved; interrupted retries reopen safely; J/G |\n| Callgraph partial results and path work | Both narrow repairs integrated | D,R:50% | Native/manual/full/platform acceptance | `2c69c4ad`, `f0b0eb02` | Existing CSR and Calls owner | Root464 cap,490 path, unchanged historical controls; overlapping counts | Work budgets, cancellation and omission truth retained | GUI/CLI/security | Correct partial/complete outputs and bounded work on representative journey; J/G |\n| Saved/recent queries and raw-offset controls | Reviewed user surfaces integrated | D,R:50% | Representative native/manual journeys and final gates | #309/#310 | Existing project/search/task ownership | Original focused gates and combined selection | Stale delivery and unintended delayed execution refused | GUI/CLI | Stable save/run/delete and original-byte navigation through reopen/export; J/G |\n| Current CVRF/Leads/report context | Retained-context delivery integrated; full CVE journey partial | D,R:50% | Approved acquisition, native candidate/negative-control journey | #313/#314 | Shared current inputs, typed rows, retained source IDs | Root1,924 source checks plus new combined selection | BLOB/type and16MiB row budgets; stale evidence excluded | CVE/KB/security | Source facts and uncertainty survive complete investigation; J/G |\n| Dependency/security provenance | Scanner/bootstrap delivered; static/platform qualification open | D,R:50% | All79 static dispositions, native Windows and actual integrated scans | `b61e1593`, `0c004b68` | Exact installer/interpreter receipts and approved audit service | Root160 bootstrap; local17/32 complete zero-advisory inventories | Original failures retained; no package omission, ignore list or auto-fix | CI/security | Complete matching closures and substantive security acceptance on final source; J/G |\n| Release qualification and packaging | Reviewed guards integrated; new-source qualification blocked | D,R:50% | Final-source Linux/Windows/native/Qt/package/scanner evidence and reproducibility | #312, this candidate | Platform runners and native tool identities | #304 full/package results are separately scoped; new combined selected gate | Windows BinDiff blocked; compiler sweep partial; release hold retained | CI/coordinator | All applicable final gates pass, no absent/blocked evidence accepted; J/G |\n\nThe fresh #304 full suites, repeated Qt and package receipts do not provide G to this new tree. Compiler smoke5/11 and the blocked Windows BinDiff artifact remain explicit. Research outcomes and the wider CVE/acquisition/manual feature gaps are unchanged. [Detailed checkpoint, sources and remaining work](../qa/verified-followup-integration-20261118/README.md).\n''',
}
for relative, addition in appendices.items():
    p = REPO / relative
    p.write_text(p.read_text().rstrip() + '\n' + addition)
print(json.dumps({'source': SOURCE, 'tree': source_tree, 'passed': passed,
                  'xfailed': skipped, 'archive_bytes': len(archive_data),
                  'archive_sha256': sha(archive_data), 'members': len(payload)}, indent=2))
