"""Record exact integration ancestry and source preservation before qualification."""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path('/workspace/scratch/c7a9e8d98848')
repo = root / 'followup-integration'
def git(*args):
    return subprocess.check_output(['git', '-C', str(repo), *args]).decode().strip()
def blob(ref, path):
    return subprocess.check_output(['git', '-C', str(repo), 'show', ref + ':' + path])
base = '58fc130631f602b6e907bb054d30c21d810551d4'
parents = {
    '308': '92a411bf02fc8beb00b7a148e39db2bf68efa061',
    '309': '3c9d3f074481b2f609330fa49ab9019eb6637849',
    '310': '26558cd0723aa5fa6d883f2935ad3c43cef94a86',
    '311': '09b032f205f4ffa1838bef56007ebdb7a2308420',
    '312': '573829f33c84e9b2d53ba51ebd7f699e39f406fe',
    '314': 'b41d6631e679ad2777d248fa087ea71582a5bf63',
    '315': '23fbe4a54880319f62f40f3196794f85b6cdaec5',
}
claims = {}
for label, head in parents.items():
    assert subprocess.run(['git', '-C', str(repo), 'merge-base', '--is-ancestor', head, 'HEAD']).returncode == 0
    merge_base = git('merge-base', base, head)
    for path in git('diff', '--name-only', merge_base, head, '--', 'src', 'tests', 'tools', '.github/workflows', 'pyproject.toml').splitlines():
        claims.setdefault(path, []).append((label, head))
ports = {
    'scanner': ('d27464d303bd0eaca219416c261ab6ba6869177e', 'c48382a6af3562ed7fd729fba023ee96f555795a'),
    'creation': (base, 'cffbb6be9b67c8d45393e771ab4f3409af5fe493'),
    'callgraph-cap': ('ac789497597fba3cb87696990d171a7a27024fca', 'c1d1951b7972c92811aa333b4d3b3a24f3f2b6b5'),
    'bootstrap': ('c48382a6af3562ed7fd729fba023ee96f555795a', '0c004b6849c12e30eddc734f0242ec0753895eff'),
    'callgraph-path': ('c1d1951b7972c92811aa333b4d3b3a24f3f2b6b5', 'f0b0eb02617a87aea4cfe4b06079528d934d6285'),
}
for label, (start, head) in ports.items():
    for path in git('diff', '--name-only', start, head, '--', 'src', 'tests', 'tools', '.github/workflows', 'pyproject.toml').splitlines():
        claims.setdefault(path, []).append((label, head))
combined = {}
reviewed_combination = {'src/patchtrace/ui.py'}
for path, owners in sorted(claims.items()):
    actual = blob('HEAD', path)
    matching = [label for label, head in owners if blob(head, path) == actual]
    assert matching or path in reviewed_combination, (path, owners)
    combined[path] = {'owners': owners, 'matching_owners': matching, 'bytes': len(actual),
                      'sha256': hashlib.sha256(actual).hexdigest(),
                      'combined_hunk_review': path in reviewed_combination}
changed = set(git('diff', '--name-only', base, 'HEAD', '--', 'src', 'tests', 'tools', '.github/workflows', 'pyproject.toml').splitlines())
assert changed == set(claims), {'unowned': sorted(changed-set(claims)), 'missing': sorted(set(claims)-changed)}
assert not git('status', '--porcelain')
assert git('rev-parse', 'a4061979547ef88855fbdb085228a42c3be21603^{tree}') == 'a9b70ad7680fb2ef3b32bf08ab90a560668cd557'
assert subprocess.run(['git', '-C', str(repo), 'merge-base', '--is-ancestor', 'a4061979547ef88855fbdb085228a42c3be21603', 'HEAD']).returncode == 0
result = {'source_sha': git('rev-parse', 'HEAD'), 'source_tree': git('rev-parse', 'HEAD^{tree}'),
          'base': base, 'actual_parent_heads': parents, 'reviewed_ports': ports,
          'combined_ui_review': 'Raw-navigation controller/copy/render/cancel hooks from PR309 and environment label/defaults from PR311 occupy independent hunks; root read the full combined UI delta. No manual production conflict resolution.',
          'files': combined}
out = root / ('qa/followup-integration/source-preservation-' + result['source_sha'][:8] + '.json')
assert not out.exists()
out.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({'source': result['source_sha'], 'tree': result['source_tree'], 'files': len(combined),
                  'multi_owner': {p:[x[0] for x in r['owners']] for p,r in combined.items() if len(r['owners'])>1}}))
