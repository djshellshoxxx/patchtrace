"""Append a source-pinned reviewed offline gate and actual imported-module proof."""
from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

ROOT = Path('/workspace/scratch/c7a9e8d98848')
REPO = ROOT / 'semantic-disposition-batch4'
OUT = Path(__file__).resolve().parent
label, *targets = sys.argv[1:]

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

head, tree = (git('rev-parse', ref).decode().strip() for ref in ('HEAD', 'HEAD^{tree}'))
status = git('status', '--porcelain=v1')
assert not status, status
env = dict(os.environ, PYTHONPATH=':'.join(str(p) for p in (
    REPO / 'src', REPO / 'tests', REPO, ROOT / 'ops')),
    QT_QPA_PLATFORM='offscreen', PYTHONDONTWRITEBYTECODE='1',
    GIT_ALLOW_PROTOCOL='file', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null',
    PATCHTRACE_BATCH_COLLECTION_RECEIPT=str(OUT / (label + '-imports.json')),
    PATCHTRACE_OFFLINE_GUARD_RECEIPT=str(OUT / (label + '-offline-guard.json')),
    PATCHTRACE_KB_SHORT_READ_OBSERVATIONS=str(OUT / (label + '-observations')))
argv = [sys.executable, str(ROOT / 'ops/continuation_offline_pytest.py'),
        '-q', '-ra', '-p', 'no:cacheprovider', '-p', 'project_and_tools_receipt',
        *targets, '--junitxml=' + str(OUT / (label + '.xml'))]
meta = dict(head=head, tree=tree, cwd=str(REPO), argv=argv,
            started_utc=datetime.now(UTC).isoformat(), working_status=status.decode(),
            environment={key:env[key] for key in (
                'PYTHONPATH', 'QT_QPA_PLATFORM', 'PYTHONDONTWRITEBYTECODE',
                'GIT_ALLOW_PROTOCOL', 'GIT_CONFIG_NOSYSTEM', 'GIT_CONFIG_GLOBAL',
                'PATCHTRACE_BATCH_COLLECTION_RECEIPT', 'PATCHTRACE_OFFLINE_GUARD_RECEIPT',
                'PATCHTRACE_KB_SHORT_READ_OBSERVATIONS')})
for suffix in ('.log', '.xml', '.command.json', '-imports.json', '-offline-guard.json', '-source-proof.json'):
    assert not (OUT / (label + suffix)).exists(), suffix
with (OUT / (label + '.log')).open('x') as output:
    run = subprocess.run(argv, cwd=REPO, env=env, stdout=output, stderr=subprocess.STDOUT)
assert git('rev-parse', 'HEAD').decode().strip() == head and git('status', '--porcelain=v1') == status
meta.update(returncode=run.returncode, finished_utc=datetime.now(UTC).isoformat())
(OUT / (label + '.command.json')).write_text(json.dumps(meta, indent=2) + '\n')
imports = json.loads((OUT / (label + '-imports.json')).read_text())
proof = []
for name, source in imports.get('final_sources', {}).items():
    path = Path(source['path'])
    relative = path.relative_to(REPO).as_posix()
    committed = git('show', head + ':' + relative)
    expected = hashlib.sha256(committed).hexdigest()
    assert expected == source['sha256'] == hashlib.sha256(path.read_bytes()).hexdigest(), relative
    proof.append(dict(module=name, path=relative, sha256=expected))
(OUT / (label + '-source-proof.json')).write_text(json.dumps(dict(head=head, sources=proof), indent=2) + '\n')
print((OUT / (label + '.log')).read_text()[-4000:])
print('Exact imported Git modules:', len(proof))
raise SystemExit(run.returncode)
