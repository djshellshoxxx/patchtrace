# Internal KB held-input propagation — source-pinned author receipt

Baseline `9ad2ec5cdbde85155fdca3cdd88804fd8b2e1a53`; final production
`d9a939911f39f3641bd5eed97a2ce067d618856b`, tree
`2277f61c82eb8115344c1edaa287b9d60d1733ed`. This packet qualifies an additive
internal capability through the existing KB import route. It creates no CLI,
GUI or package entry point and does not qualify native Windows acquisition.
Root independent review/integration remains a separate gate.

## Source chain and actual outcomes

The earlier design pick `76e71040583187c1a460fad2298e90bd47c9543f` is equivalent
to the design already retained by root; it is excluded from the new handoff.
`history.json` and `commits/` retain the subsequent five commits in order.

| Commit / receipt | Result | Meaning |
| --- | --- | --- |
| `da968d60`, `spec-red.*` | 32 failed, 1 passed | Missing reader keywords on the original KB APIs; ordinary positional route passed. No setup or collection errors. |
| `3fee8026`, `first-source-focused.*` | 33 passed | First three-file propagation source, before short-read review. |
| `73b7de55`, `final-focused.*` | 39 passed | Adds actual saved/global admission and live-operation intent resume controls. Historical filename retained; not the final reviewed source. |
| Root unchanged `original-independent/initial.*` at `73b7de55` | 3 failed, 2 passed | Legitimate 1/17/127-byte reads lose the PE prefix and raise `PT-KBC-INPUT`; full and 4096-byte reads pass. |
| `77be0e34`, `short-prefix-spec-red.*` | 6 failed, 6 passed | New finite-prefix regression before its correction, plus ordinary injection positive. |
| `d9a93991`, `short-prefix-source-green.*` | 50 passed | Existing 39 cases plus 11 prefix controls. |
| `d9a93991`, `short-prefix-original-green.*` | 5 passed | Root probe unchanged; 49 imported modules equal committed source. Fresh observation directory. |
| `d9a93991`, `affected-source-green.*` | 300 passed, 0 skipped, 8.51 s | Exact 15-file affected gate; 99 imported project/tool modules equal committed source. |
| `d9a93991`, `final-ruff.*`, `final-diff-check.*` | Both passed | Required full `ruff check src tests tools`; baseline-to-source whitespace check. |

These invocations overlap. Their counts are not additive coverage or completion
percentages. Original commands, XML, logs and outcomes remain unedited.

## Implemented behavior and qualification

Only `kbcorrelation/service.py`, `wiring.py` and `store.py` change production.
The same original pair and checkpoint reach inspection, both complete
attachment hash passes and the existing core create API. Ordinary callers keep
their original arguments, including positional-only injected inspector,
factory, hash and core-create controls. No TypeError fallback is added.

Held loops request at most 1 MiB and refuse nonbytes or oversized replies before
hash/size progress. They retain the existing 4096-byte PE prefix across short
successful reads, including the last admissible signature boundary; headers at
or beyond 4096 remain refused. Full-input hashes and provider positive-byte
accounting remain intact. KB boundary checks use zero; the core's ordinary
verification reads own their existing positive accounting.

Real SQLite/project controls deny all selected-source pathname opens, observe
four borrowed opens per side, verify every borrow closes while original handles
remain live, then delete the inputs and reopen immutable project copies. Other
controls retain exact InputReadError identity through preapproval, attachment
hash, core-copy, save-verification and pre-COMMIT stops; no committed project is
rolled back by a newly inserted postcommit checkpoint. A live same-operation
intent can resume only with its original bound pair. An expired capability or
tampered path refuses without creating a project.

Actual saved/global admission tests retain finite selected IDs, an explicitly
empty selection, globally superseded facts, current revision/pair mismatch,
malformed coverage and ordered source-snapshot drift. `source-proof.json`
contains exact unchanged symbol-span and file proofs for existing scope,
index, approval, bundle, postcreate association and generic recovery behavior.

The final gates use normal system temp and absolute source paths. The existing
offline runner's inherited network denial was active. The five-case original
replay records no network/process events. The affected gate records 18 authored
Python child-process events for existing CLI/import/crash-recovery tests and
only local `socket.gethostname` audit events; no socket/connect events. This
execution guard is not a product sandbox or native/platform acceptance claim.

## Explicit remaining boundaries

No exposed held-origin entry point is permitted until a separate durable
facade prevents reader-less generic recovery from reopening stored package
paths. The existing `after_project_create` failure still retains a committed
project with a journal intent whose project ID is unset; the test preserves
that known boundary. No durable package provenance, expected project identity,
lease reconstruction, FDI worker, native sharing or frozen package journey is
implemented here. Postcommit context writes still load immutable project copies
without this creation checkpoint. Root owns independent review and integration.

No core, worker, model/schema, CLI, workflow, native package, remote, main or
release changes occur in the new source chain. All five commit messages retain
the literal `[no release]` hold. The sealed archive includes source bytes,
patches, complete actual outcomes and verified copies of the original root red.
