"""Seal the internal three-file propagation and preserved independent short-read red."""
from __future__ import annotations

import ast
from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/c7a9e8d98848')
R = ROOT / 'semantic-disposition-batch4'
Q = Path(__file__).resolve().parent
BASE = '9ad2ec5cdbde85155fdca3cdd88804fd8b2e1a53'
PICK = '76e71040583187c1a460fad2298e90bd47c9543f'
SOURCE = 'd9a939911f39f3641bd5eed97a2ce067d618856b'
ARCHIVE = Q.with_suffix('.zip')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=R)


def blob(ref, path):
    return git('show', ref + ':' + path)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def put(path, data):
    destination = Q / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    with destination.open('xb') as stream:
        stream.write(data)


def dump(path, value):
    put(path, (json.dumps(value, indent=2) + '\n').encode())


def symbols(content):
    found = {}
    lines = content.splitlines(keepends=True)
    def visit(nodes, prefix=''):
        for node in nodes:
            if isinstance(node, ast.ClassDef):
                visit(node.body, prefix + node.name + '.')
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                start = min([node.lineno, *[d.lineno for d in node.decorator_list]])
                data = b''.join(lines[start - 1:node.end_lineno])
                found[prefix + node.name] = (start, node.end_lineno, data, ast.dump(node, include_attributes=False))
    visit(ast.parse(content).body)
    return found


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('status', '--porcelain=v1')
tree = git('rev-parse', SOURCE + '^{tree}').decode().strip()
production = git('diff', '--name-only', BASE, SOURCE, '--', 'src').decode().splitlines()
assert production == ['src/patchtrace/kbcorrelation/' + f + '.py' for f in ('service', 'store', 'wiring')]
assert not git('diff', BASE, SOURCE, '--', 'tools', '.github', 'docs/schemas')
allowed = {
    production[0]: {'KbService.import_pair'},
    production[1]: {'_file_sha', 'ProjectAttachment.__init__', 'ProjectAttachment._begin', 'ProjectAttachment._create'},
    production[2]: {'inspect_local_file', 'RealProjectPort.__init__', 'RealProjectPort.create_project',
                    '_project_factory', 'new_project_factory'},
}
symbol_proofs, additions = [], []
for path in production:
    before, after = symbols(blob(BASE, path)), symbols(blob(SOURCE, path))
    assert not before.keys() - after.keys()
    for name in before.keys() - allowed[path]:
        old, new = before[name], after[name]
        assert old[2:] == new[2:], (path, name)
        symbol_proofs.append(dict(path=path, name=name, base_lines=list(old[:2]),
                                  source_lines=list(new[:2]), sha256=sha(new[2]), bytes=len(new[2])))
    additions.extend(dict(path=path, name=name) for name in sorted(after.keys() - before.keys()))
store_old, store_new = (blob(ref, production[1]) for ref in (BASE, SOURCE))
marker = b"        for key, sha in (('older_sha256', body['older_sha']), ('newer_sha256', body['newer_sha'])):"
tail = lambda data: data[data.index(marker):data.index(b'    # -------------------------------------------------------------------------------------------- phase two')]
assert tail(store_old) == tail(store_new)

unchanged = [
    'src/patchtrace/kbcorrelation/' + name + '.py' for name in (
        'context', 'index', 'saved_scope', 'recovery', 'pairs', 'ports', 'workflow', 'contracts',
        'inventory_selection', 'investigation_service', 'investigation_qt', 'cli', 'cli_leads', 'cli_acquire')
]
core = ['src/patchtrace/' + name + '.py' for name in ('input_readers', 'ingestion', 'service', 'persistence')]
unchanged += core + ['docs/specs/core-held-inputs.md']
for path in unchanged:
    assert blob(BASE, path) == blob(SOURCE, path), path
for path in core + ['docs/specs/core-held-inputs.md']:
    assert blob('9740860928c7911e6fa975528db1f7fa5ca1940b', path) == blob(SOURCE, path), path
dump('source-proof.json', dict(baseline=BASE, source=SOURCE, tree=tree, changed_production=production,
    existing_changed_symbols=allowed if False else {p:sorted(names) for p,names in allowed.items()},
    added_symbols=additions, unchanged_symbols=symbol_proofs,
    unchanged_paths=[dict(path=p, sha256=sha(blob(SOURCE,p))) for p in unchanged],
    core_reference='9740860928c7911e6fa975528db1f7fa5ca1940b', core_equal_files=core+['docs/specs/core-held-inputs.md'],
    after_create_success_suffix=dict(identical=True, sha256=sha(tail(store_new)), bytes=len(tail(store_new))),
    tools_workflows_schemas_unchanged=True))

original = ROOT / 'qa/kb-held-inputs-independent'
preserved = []
paths = sorted(p for p in original.rglob('*') if p.is_file() and
               (p.name == 'test_short_reader_prefix.py' or p.relative_to(original).parts[0].startswith('initial')))
for path in paths:
    data = path.read_bytes()
    member = 'original-independent/' + path.relative_to(original).as_posix()
    put(member, data)
    preserved.append(dict(original_path=str(path), path=member, bytes=len(data), sha256=sha(data)))
assert sha((original / 'test_short_reader_prefix.py').read_bytes()) == '672e1a2e13e990c1e1249d319f714ef8e91425d44fcafe63dd6fe32a3d9feee6'
dump('original-preservation.json', dict(files=preserved, original_source='73b7de55cb4ff3556f68fac616d47244626bc887'))

commits = git('rev-list', '--reverse', PICK + '..' + SOURCE).decode().splitlines()
history = []
for commit in commits:
    fields = git('show', '-s', '--format=%H%x00%T%x00%P%x00%s', commit).decode().strip().split('\0')
    assert '[no release]' in fields[3]
    paths = git('diff-tree', '--no-commit-id', '--name-only', '-r', commit).decode().splitlines()
    history.append(dict(commit=fields[0], tree=fields[1], parents=fields[2].split(), subject=fields[3], paths=paths))
    put('commits/' + commit[:8] + '.patch', git('show', '--format=fuller', '--binary', commit))
dump('history.json', dict(baseline=BASE, design_pick_excluded=PICK, source=SOURCE, commits=history))

affected = json.loads((Q/'affected-source-green.command.json').read_text())['argv']
affected = [value for value in affected if value.startswith('tests/')]
base_paths = ['AGENTS.md', 'docs/modules.md', 'pyproject.toml', *production, *unchanged]
final_paths = [*base_paths, *affected, 'docs/specs/kb-held-inputs.md', 'tests/held_input_support.py',
               'tests/conftest.py', 'tests/kbc_helpers.py', 'tests/kbc_k1_support.py',
               'tests/kbc_k3_support.py', 'tests/kbc_saved_scope_support.py']
stages = [(BASE, base_paths), (SOURCE, final_paths)]
stages.extend((item['commit'], item['paths']) for item in history[:-1])
snapshots, captured = [], set()
for ref, paths in stages:
    for path in sorted(set(paths)):
        if (ref, path) in captured:
            continue
        captured.add((ref, path))
        data = blob(ref, path)
        member = 'git/' + ref[:8] + '/' + path
        put(member, data)
        snapshots.append(dict(path=member, git_commit=ref, git_path=path, git_blob=git('rev-parse', ref+':'+path).decode().strip(),
                              bytes=len(data), sha256=sha(data)))
dump('git-snapshots.json', dict(snapshots=snapshots))

queries = [r'\binput_readers\b|\breader=', r'\.import_pair\(|ProjectAttachment\(', r'_file_sha\(|inspect_local_file\(']
searches = []
for number, pattern in enumerate(queries, 1):
    argv = ['rg', '-n', pattern, 'src/patchtrace/kbcorrelation']
    result = subprocess.run(argv, cwd=R, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    assert result.returncode == 0
    member = 'callers/' + str(number) + '.txt'
    put(member, result.stdout)
    searches.append(dict(argv=argv, cwd=str(R), source=SOURCE, path=member, sha256=sha(result.stdout)))
dump('caller-searches.json', dict(searches=searches))

outcomes = []
for path in sorted(Q.rglob('*.xml')):
    suites = list(ET.parse(path).getroot().iter('testsuite'))
    counts = {name:sum(int(suite.get(name,0)) for suite in suites) for name in ('tests','failures','errors','skipped')}
    counts['passed'] = counts['tests'] - counts['failures'] - counts['errors'] - counts['skipped']
    failed = [dict(classname=case.get('classname'), name=case.get('name'), kind=issue.tag, message=issue.get('message',''))
              for suite in suites for case in suite.findall('testcase') for issue in list(case)
              if issue.tag in ('failure','error')]
    outcomes.append(dict(path=path.relative_to(Q).as_posix(), **counts, failed_nodes=failed,
                          xml_seconds=sum(float(suite.get('time',0)) for suite in suites)))
expected = {'spec-red.xml':(1,32),'first-source-focused.xml':(33,0),'final-focused.xml':(39,0),
    'short-prefix-spec-red.xml':(6,6),'short-prefix-source-green.xml':(50,0),
    'original-independent/initial.xml':(2,3),'short-prefix-original-green.xml':(5,0),
    'affected-source-green.xml':(300,0)}
for path, counts in expected.items():
    result = next(item for item in outcomes if item['path']==path)
    assert (result['passed'],result['failures']) == counts and result['errors'] == result['skipped'] == 0
dump('outcomes.json', dict(outcomes=outcomes, counts_are_not_additive_coverage=True))
for row in snapshots:
    assert (Q/row['path']).read_bytes() == blob(row['git_commit'],row['git_path'])
for row in preserved:
    assert sha(Path(row['original_path']).read_bytes()) == row['sha256']
for label in ('affected-source-green','short-prefix-original-green'):
    imports = json.loads((Q/(label+'-source-proof.json')).read_text())
    assert imports['head']==SOURCE
    for item in imports['sources']:
        assert sha(blob(SOURCE,item['path']))==item['sha256']

files = []
for path in sorted(Q.rglob('*')):
    if path.is_file() and '__pycache__' not in path.parts and path.suffix != '.pyc':
        data = path.read_bytes()
        files.append(dict(path=path.relative_to(Q).as_posix(), bytes=len(data), sha256=sha(data)))
dump('manifest.json', dict(schema=1, baseline=BASE, source=SOURCE, tree=tree,
                           sealed_utc=datetime.now(UTC).isoformat(), files=files))
with zipfile.ZipFile(ARCHIVE,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for row in files:
        archive.write(Q/row['path'],row['path'])
    archive.write(Q/'manifest.json','manifest.json')
with zipfile.ZipFile(ARCHIVE) as archive:
    assert set(archive.namelist()) == {row['path'] for row in files}|{'manifest.json'}
    for row in files:
        data=archive.read(row['path'])
        assert len(data)==row['bytes'] and sha(data)==row['sha256']
seal=dict(baseline=BASE, source=SOURCE, tree=tree, archive=str(ARCHIVE), members=len(files)+1,
          bytes=ARCHIVE.stat().st_size,sha256=sha(ARCHIVE.read_bytes()),git_snapshots=len(snapshots),
          unchanged_symbol_proofs=len(symbol_proofs),original_preserved_files=len(preserved),source_commits=len(commits))
with Q.with_name(Q.name+'-seal.json').open('x') as stream:
    json.dump(seal,stream,indent=2)
    stream.write('\n')
print(json.dumps(seal,indent=2))
