"""Independent behavioral controls for Linux owned evidence; no native Windows claim."""
import gzip
import hashlib
import os
import sqlite3
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from threading import Barrier

import pytest

from patchtrace import owned_publication as owned
from patchtrace.kbcorrelation.store import KbcStoreError, WorkspaceStore

pytestmark = pytest.mark.skipif(not sys.platform.startswith('linux'), reason='Linux descriptor controls')


def require(expected):
    def validate(actual):
        if actual != expected:
            raise ValueError('different immutable evidence')
    return validate


@pytest.mark.parametrize('same', [True, False])
def test_independent_publishers_never_replace_each_other(tmp_path, same):
    target = tmp_path / 'object'
    barrier = Barrier(4, timeout=5)
    candidates = [b'same' if same else str(i).encode() for i in range(4)]
    def publish(data):
        barrier.wait()
        try:
            return owned.publish_bytes(target, data, validate_existing=require(data), maximum=10)
        except ValueError:
            return 'refused'
    with ThreadPoolExecutor(max_workers=4) as pool:
        futures = [pool.submit(publish, data) for data in candidates]
        outcomes = [future.result(timeout=15) for future in futures]
    assert outcomes.count(True) == 1
    assert outcomes.count(False) == (3 if same else 0)
    assert outcomes.count('refused') == (0 if same else 3)
    assert target.read_bytes() in candidates
    assert list(tmp_path.iterdir()) == [target]


def test_fifo_cannot_be_admitted_as_an_existing_regular_object(tmp_path):
    target = tmp_path / 'object'
    os.mkfifo(target)
    before = target.lstat()
    with pytest.raises(owned.OwnedPublicationError):
        owned.publish_bytes(target, b'new', validate_existing=require(b'new'), maximum=10)
    assert target.lstat().st_ino == before.st_ino


def test_replaced_parent_during_existing_read_is_refused_and_preserved(tmp_path):
    parent = tmp_path / 'objects'
    parent.mkdir()
    target = parent / 'object'
    target.write_bytes(b'evidence')
    moved = tmp_path / 'original-parent'
    def validate(actual):
        assert actual == b'evidence'
        parent.rename(moved)
        parent.mkdir()
        target.write_bytes(actual)
    with pytest.raises(owned.OwnedPublicationError):
        owned.read_bytes(target, maximum=20, validate=validate)
    assert target.read_bytes() == (moved / target.name).read_bytes() == b'evidence'


def test_leaf_loss_after_validation_is_not_treated_as_permission_to_recreate(tmp_path):
    target = tmp_path / 'object'
    target.write_bytes(b'evidence')
    def validate(actual):
        assert actual == b'evidence'
        target.unlink()
    with pytest.raises(FileNotFoundError):
        owned.publish_bytes(target, b'new', validate_existing=validate, maximum=20)
    assert not target.exists() and list(tmp_path.iterdir()) == []


def test_unsupported_anonymous_staging_fails_without_named_stage(tmp_path, monkeypatch):
    target = tmp_path / 'object'
    monkeypatch.delattr(os, 'O_TMPFILE')
    with pytest.raises(owned.OwnedPublicationError):
        owned.publish_bytes(target, b'new')
    assert list(tmp_path.iterdir()) == []


def test_database_open_uses_the_same_resolved_root_as_objects(tmp_path, monkeypatch):
    original, foreign, selected = (tmp_path / name for name in ('original', 'foreign', 'selected'))
    with WorkspaceStore(original):
        pass
    foreign.mkdir()
    selected.symlink_to(original, target_is_directory=True)
    connect = sqlite3.connect
    observed = []
    def retarget_at_connect(path, *args, **kwargs):
        observed.append(Path(path))
        selected.unlink()
        selected.symlink_to(foreign, target_is_directory=True)
        return connect(path, *args, **kwargs)
    monkeypatch.setattr(sqlite3, 'connect', retarget_at_connect)
    with WorkspaceStore(selected) as ws:
        raw = b'independent source bytes'
        digest = hashlib.sha256(raw).hexdigest()
        ws.write_object(digest, raw)
        assert ws.read_object(digest) == raw
        assert Path(ws.db.execute('PRAGMA database_list').fetchone()[2]) == original / 'kbc.sqlite3'
        assert ws.object_path(digest).is_relative_to(original)
    assert observed == [original / 'kbc.sqlite3'] and list(foreign.iterdir()) == []


def test_multimember_gzip_is_preserved_but_never_accepted(tmp_path):
    raw = b'first member'
    digest = hashlib.sha256(raw).hexdigest()
    with WorkspaceStore(tmp_path / 'workspace') as ws:
        target = ws.object_path(digest)
        target.parent.mkdir(parents=True)
        encoded = gzip.compress(raw) + gzip.compress(b'second member')
        target.write_bytes(encoded)
        before = target.stat()
        for action in (lambda: ws.read_object(digest), lambda: ws.write_object(digest, raw)):
            with pytest.raises(KbcStoreError):
                action()
        assert target.read_bytes() == encoded and target.stat().st_ino == before.st_ino
