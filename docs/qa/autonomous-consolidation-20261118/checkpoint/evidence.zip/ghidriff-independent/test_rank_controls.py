"""Independent authored controls. These do not establish native matching accuracy."""
import copy
import itertools
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from tools.research_qualification.adapters import ghidriff

ROOT = Path('/workspace/scratch/c7a9e8d98848/report-review')


def entry(name, old, new, *, changed=True):
    return {'old': {'fullname': name, 'address': old},
            'new': {'fullname': name, 'address': new},
            'diff_type': ['code'] if changed else ['address'],
            'ratio': 0.25 if changed else 1.0}


def report(rows, added=(), deleted=()):
    return json.dumps({'functions': {'modified': list(rows), 'added': list(added), 'deleted': list(deleted)}})


def test_address_namespace_is_relative_to_each_binary():
    # The numeric address of one old function may equal a different new function.
    rows = [entry('alpha', '10', '20'), entry('beta', '20', '30')]
    assert ghidriff.parse(report(rows)) == ['alpha', 'beta']


def test_canonical_key_order_does_not_make_a_false_duplicate_conflict():
    original = entry('alpha', '10', '20')
    reordered = dict(reversed(list(copy.deepcopy(original).items())))
    reordered['old'] = dict(reversed(list(reordered['old'].items())))
    assert ghidriff.parse(report([original, reordered])) == ['alpha']


def test_ambiguity_rejection_is_order_invariant_and_includes_unchanged():
    rows = [entry('target', '10', '20', changed=False), entry('target', '30', '40'),
            entry('other', '50', '60')]
    for permutation in itertools.permutations(rows):
        with pytest.raises(ValueError, match='ambiguous|conflict'):
            ghidriff.parse(report(permutation))


def test_one_sided_addresses_have_separate_binary_ownership():
    assert ghidriff.parse(report([], added=[{'fullname': 'added', 'address': '10'}],
                                deleted=[{'fullname': 'deleted', 'address': '10'}])) == ['added', 'deleted']


def test_same_side_duplicate_endpoint_cannot_gain_one_sided_credit():
    with pytest.raises(ValueError, match='ambiguous|conflict'):
        ghidriff.parse(report([entry('modified', '10', '20', changed=False)],
                             added=[{'fullname': 'unrelated-label', 'address': '20'}]))


def test_duplicate_opaque_metadata_keys_do_not_escape_strict_json():
    value = report([entry('target', '10', '20')])
    value = value.replace('"ratio": 0.25', '"ratio": 0.25, "metadata": {"x": 1, "x": 2}')
    with pytest.raises(ValueError, match='duplicate'):
        ghidriff.parse(value)


def test_decorated_markdown_retains_original_subsection_matching():
    text = '# Modified\n## @callee@12\n### @callee@12 Diff\n```diff\n-before\n+after\n```\n'
    assert ghidriff.parse(text) == ['callee']
    with pytest.raises(ValueError, match='ambiguous'):
        ghidriff.parse(text + '# Modified (No Code Changes)\n## callee\n')


def test_cli_child_loads_reviewed_source_and_refuses_without_partial_output(tmp_path):
    source = tmp_path / 'authored.json'
    source.write_text(report([entry('target', '10', '20'), entry('target', '30', '40')]), encoding='utf-8')
    env = {**os.environ, 'PYTHONPATH': str(ROOT / 'src') + os.pathsep + str(ROOT)}
    probe = subprocess.run([sys.executable, '-c',
        'from tools.research_qualification.adapters import ghidriff; print(ghidriff.__file__)'],
        cwd=ROOT, env=env, capture_output=True, text=True, timeout=15, check=True)
    assert Path(probe.stdout.strip()).resolve() == ROOT / 'tools/research_qualification/adapters/ghidriff.py'
    run = subprocess.run([sys.executable, '-m', 'tools.research_qualification', 'adapters',
                          'ghidriff', str(source), '--case', 'authored-independent'],
                         cwd=ROOT, env=env, capture_output=True, text=True, timeout=15)
    assert run.returncode == 2 and run.stdout == ''
    assert 'error:' in run.stderr and 'Traceback' not in run.stderr
