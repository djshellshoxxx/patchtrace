"""Independent authored controls; no Ghidra/Java or target binary execution."""
from __future__ import annotations

import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

import patchtrace
from patchtrace import backend
from patchtrace.backend import BackendConfig
from patchtrace.jobs import ProcessResult

ROOT = Path(os.environ['H7_REVIEW_ROOT']).resolve()
SENTINEL = 'INDEPENDENT_AUTHORED_SENTINEL'
DROP = ('GITHUB_TOKEN', 'GH_TOKEN', 'OPENAI_API_KEY', 'JAVA_TOOL_OPTIONS',
        '_JAVA_OPTIONS', 'JDK_JAVA_OPTIONS', 'PYTHONPATH', 'PYTHONHOME', 'LD_PRELOAD')


@pytest.fixture
def seeded(monkeypatch, tmp_path):
    base = {key: value for key, value in os.environ.items()
            if key.upper() in {'PATH', 'SYSTEMROOT', 'TEMP', 'TMP', 'COMSPEC', 'HOME', 'USERPROFILE'}}
    base.update({name: SENTINEL for name in DROP})
    base.update(HTTPS_PROXY=SENTINEL, SSL_CERT_FILE=SENTINEL, H7_APPROVED_MARKER=SENTINEL)
    base.pop('PATCHTRACE_CHILD_ENV', None)
    monkeypatch.setattr(backend.os, 'environ', base)
    return base


def config(tmp_path, **kwargs):
    return BackendConfig(sys.executable, str(tmp_path / 'ghidra'), **kwargs)


def test_module_provenance_is_the_detached_review_checkout():
    assert Path(patchtrace.__file__).resolve().is_relative_to(ROOT / 'src')
    assert Path(backend.__file__).resolve() == ROOT / 'src/patchtrace/backend.py'


def test_real_python_child_receives_only_authored_approved_marker(tmp_path, seeded):
    cfg = config(tmp_path, env_passthrough=('H7_APPROVED_MARKER',))
    child = backend._environment(cfg, tmp_path / 'settings')
    names = (*DROP, 'HTTPS_PROXY', 'SSL_CERT_FILE', 'H7_APPROVED_MARKER', 'PYTHONNOUSERSITE')
    script = 'import json,os;print(json.dumps({k:os.environ.get(k) for k in ' + repr(names) + '}))'
    result = subprocess.run([sys.executable, '-I', '-c', script], env=child, cwd=tmp_path,
                            check=True, capture_output=True, text=True, timeout=15)
    seen = json.loads(result.stdout)
    assert all(seen[name] is None for name in (*DROP, 'HTTPS_PROXY', 'SSL_CERT_FILE'))
    assert seen['H7_APPROVED_MARKER'] == SENTINEL
    assert seen['PYTHONNOUSERSITE'] == '1'


@pytest.mark.parametrize('probe', ['dependency', 'java'])
def test_dependency_and_jvm_probes_both_use_restricted_default(tmp_path, seeded, monkeypatch, probe):
    home = tmp_path / 'java'
    (home / 'bin').mkdir(parents=True)
    (home / 'bin' / ('java.exe' if os.name == 'nt' else 'java')).write_text('authored, never executed')
    cfg = config(tmp_path, java_home=str(home))
    calls = []

    def capture(argv, **kwargs):
        calls.append((argv, kwargs))
        text = json.dumps({'python': '3.12.14', 'available': True, 'ghidriff': 'authored', 'pyghidra': 'authored'})
        return ProcessResult(0, text if probe == 'dependency' else 'openjdk version "25.0.1"')

    monkeypatch.setattr(backend, 'run_process', capture)
    if probe == 'dependency':
        assert backend._probe_backend(cfg)['available'] is True
    else:
        assert backend._java_version(cfg) == '25.0.1'
    assert len(calls) == 1
    child = calls[0][1]['env']
    assert not set(DROP) & set(child)
    assert 'HTTPS_PROXY' not in child and 'SSL_CERT_FILE' not in child
    assert child['JAVA_HOME'] == str(home.resolve())
    assert child['JAVA_HOME_OVERRIDE'] == str(home.resolve())


def test_explicit_named_proxy_remains_a_narrow_compatibility_choice(tmp_path, seeded):
    child = backend._environment(config(tmp_path, env_passthrough=('HTTPS_PROXY',)))
    assert child['HTTPS_PROXY'] == SENTINEL
    assert 'SSL_CERT_FILE' not in child and not set(DROP) & set(child)


def test_bundle_ignores_both_full_inheritance_switches(tmp_path, seeded):
    seeded['PATCHTRACE_CHILD_ENV'] = 'inherit'
    child = backend._environment(config(tmp_path, restrict_env=False, bundle=True,
                                       java_home=str(tmp_path / 'jdk')), tmp_path / 'scratch/settings')
    assert not set(DROP) & set(child)
    assert 'H7_APPROVED_MARKER' not in child and 'HTTPS_PROXY' not in child
    assert child['TEMP'] == str(tmp_path / 'scratch')
    assert child['PYTHONDONTWRITEBYTECODE'] == '1'


@pytest.mark.parametrize('name', ['java_tool_options', 'JDK_JAVA_OPTIONS', 'pythonpath', 'LD_PRELOAD'])
def test_forbidden_named_injection_is_refused_before_a_child_exists(tmp_path, seeded, name):
    with pytest.raises(ValueError, match='forbidden'):
        backend._environment(config(tmp_path, env_passthrough=(name,)))


def test_windows_name_handling_remains_case_insensitive_pure_control(tmp_path):
    base = {'sYsTeMrOoT': r'C:\Windows', 'pAtH': r'C:\Windows\System32',
            'gItHuB_tOkEn': SENTINEL, 'jAvA_tOoL_oPtIoNs': SENTINEL}
    child = backend.build_child_env(base, config(tmp_path), None,
                                    symbol_downloads=False, for_tool='ghidra', windows=True)
    assert child['sYsTeMrOoT'] == r'C:\Windows'
    assert child['pAtH'] == r'C:\Windows\System32'
    assert not {'GITHUB_TOKEN', 'JAVA_TOOL_OPTIONS'} & {key.upper() for key in child}
