"""Read-only review probes on 9e5a5303; intended contract assertions may fail.

All projects and advisories are authored fixtures. No target or analyzer runs.
"""
from __future__ import annotations

import json
import socket
import sys
from pathlib import Path

import pytest
from kbc_k3_support import Kb
from kbc_k4a_support import analysed_project
from kev_helpers import document, entry, parse_bytes, render

from patchtrace import cli
from patchtrace.backend import BackendConfig, _environment
from patchtrace.enrichment.storage import EnrichmentStore
from patchtrace.intelligence.storage import AdvisoryStore
from patchtrace.kev import store as kev_store
from patchtrace.pilot import cli as pilot_cli
from patchtrace.pilot import store as pilot_store
from patchtrace.service import ProjectService
from patchtrace.ui_leads import load_stored

ROOT = Path('/workspace/scratch/c7a9e8d98848/cve-flow-review')
CVE = 'CVE-2099-30001'
ADVISORY = ROOT / 'tests/fixtures/pilot/synergy-1/sample-cwe125-advisory.json'


@pytest.fixture(autouse=True)
def isolated_sources(tmp_path, monkeypatch):
    monkeypatch.setattr(kev_store, 'default_kev_dir', lambda: tmp_path / 'catalog')

    def denied(*args, **kwargs):
        raise AssertionError('independent review probes must remain offline')

    for name in ('socket', 'create_connection', 'getaddrinfo'):
        monkeypatch.setattr(socket, name, denied)


@pytest.fixture
def localized_project(tmp_path, capsys):
    with ProjectService.sample(tmp_path / 'case') as service:
        advisory = AdvisoryStore(service.root, EnrichmentStore(service.store), service.project.id,
                                 service.project.revision)
        advisory.add(ADVISORY.read_bytes(), origin='local-import', uri=None, file_name=ADVISORY.name,
                     retrieved_at='2099-03-01T00:00:00Z')
        root = service.root
    assert cli.main(['pilot', 'leads', str(root), '--json']) == 0
    result = json.loads(capsys.readouterr().out)['result']
    assert result['stored'] and result['cves'][0]['cve'] == CVE
    return root, result


def loaded(service, route):
    if route == 'desktop':
        return load_stored(service, service.project).loaded
    return pilot_store.load(EnrichmentStore(service.store), pilot_cli._known(service.project))


@pytest.mark.parametrize('route', ['cli', 'desktop'])
def test_changed_function_pairing_marks_stored_localization_stale(localized_project, route):
    root, _result = localized_project
    with ProjectService.open(root) as service:
        before = loaded(service, route)
        match = next(m for m in service.project.matches if m.older and m.older[0].name == 'read_item')
        old_revision = service.project.revision
        service.correct_match(match.id, [f.id for f in match.older], [], 'unmatched',
                              'Authored review control: withdraw the prior two-sided correspondence')
        assert service.project.revision > old_revision
        assert not next(m for m in service.project.matches if m.id == match.id).newer
        after = loaded(service, route)
        assert before.state == 'current'
        assert after.assessment.revision < service.project.revision
        assert after.state == 'stale', {
            'route': route, 'stored_revision': after.assessment.revision,
            'current_revision': service.project.revision, 'state': after.state, 'changed': after.changed}


@pytest.mark.parametrize('route', ['cli', 'desktop'])
def test_replaced_advisory_marks_stored_localization_stale(localized_project, route):
    root, result = localized_project
    revised = json.loads(ADVISORY.read_bytes())
    tracking = revised['document']['tracking']
    tracking['version'] = '2'
    tracking['current_release_date'] = '2099-03-02T00:00:00.000Z'
    tracking['revision_history'].append({'date': tracking['current_release_date'], 'number': '2',
                                        'summary': 'Authored independent review revision'})
    revised['vulnerabilities'][0]['title'] = 'Authored revised advisory statement'
    with ProjectService.open(root) as service:
        advisory = AdvisoryStore(service.root, EnrichmentStore(service.store), service.project.id,
                                 service.project.revision)
        advisory.add(json.dumps(revised).encode(), origin='local-import', uri=None,
                     file_name='revised-synthetic.json', retrieved_at='2099-03-02T00:00:00Z')
        documents, warnings = advisory.advisories()
        assert not warnings and sorted((doc.facts.revision, doc.superseded) for doc in documents) == [
            ('1', True), ('2', False)]
        after = loaded(service, route)
        assert after.assessment.result_id == result['result_id']
        assert after.state == 'stale', {'route': route, 'state': after.state, 'changed': after.changed}


def test_desktop_honors_the_same_changed_kev_snapshot_as_cli(localized_project, tmp_path):
    root, _result = localized_project
    raw = render(document([entry(cveID=CVE)]))
    catalog = parse_bytes(raw)
    kev_store.KevStore(tmp_path / 'catalog').install(raw, catalog, now='2099-03-02T00:00:00Z')
    with ProjectService.open(root) as service:
        actual_cli = loaded(service, 'cli')
        actual_desktop = loaded(service, 'desktop')
        assert actual_cli.state == 'stale' and 'kev_snapshot_id' in actual_cli.changed
        assert actual_desktop.state == actual_cli.state, {
            'cli': actual_cli.state, 'desktop': actual_desktop.state, 'desktop_changed': actual_desktop.changed}


def test_cvrf_context_from_kb_route_reaches_named_pilot_localization(tmp_path, capsys):
    kb = Kb(tmp_path, capsys)
    root = analysed_project(kb, tmp_path, capsys)
    code, document_, _ = kb('leads', str(root), '--cve', 'CVE-2099-20001')
    assert code == 0 and document_['result']['groups'][0]['leads']
    assert cli.main(['pilot', 'leads', str(root), '--cve', 'CVE-2099-20001', '--json', '--dry-run']) == 0, (
        'The same analyzed project has a retained CVRF-backed KB context and function leads, '
        'but named patch-intent localization cannot consume that context.')


def test_default_offline_external_child_drops_unrelated_dummy_secrets(tmp_path, monkeypatch):
    for name in ('GH_TOKEN', 'NVD_API_KEY', 'HTTPS_PROXY'):
        monkeypatch.setenv(name, 'AUTHORED_REVIEW_SENTINEL')
    config = BackendConfig(python_executable=sys.executable, ghidra_dir=str(tmp_path / 'Ghidra'))
    assert not config.allow_symbol_downloads and not config.bundle
    child = _environment(config)
    leaked_names = [name for name in ('GH_TOKEN', 'NVD_API_KEY', 'HTTPS_PROXY')
                    if child.get(name) == 'AUTHORED_REVIEW_SENTINEL']
    assert leaked_names == [], leaked_names
