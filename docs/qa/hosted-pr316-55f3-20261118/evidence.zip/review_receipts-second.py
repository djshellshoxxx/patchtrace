"""Bounded offline review of retained GitHub receipts; executes no captured command."""
from __future__ import annotations

from collections import Counter
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import tomllib
from urllib.parse import unquote, urlsplit
import zipfile

QA = Path(__file__).resolve().parent
ROOT = QA.parents[1] / 'full-batch-path-review'
HEAD = '55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
TREE = '11a0c1598764ebd3fd8d3b540377aa52e949f88a'
PREVIEW = '872947fd8edead1f3269700375c05149fa71e9ef'


def dump(name, value):
    with (QA / name).open('x', encoding='utf-8') as handle:
        handle.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def api(name):
    return json.loads(json.loads((QA / 'api' / (name + '.json')).read_bytes())['raw_content'])


def archive(artifact_id):
    result = zipfile.ZipFile(QA / 'artifacts' / f'artifact-{artifact_id}.zip')
    infos = result.infolist()
    assert len(infos) <= 500 and sum(info.file_size for info in infos) <= 16 * 1024 * 1024
    assert len({info.filename for info in infos}) == len(infos)
    for info in infos:
        parts = PurePosixPath(info.filename)
        assert not parts.is_absolute() and not {'..', '.'}.intersection(parts.parts)
        assert not info.flag_bits & 1 and info.file_size <= 4 * 1024 * 1024
    return result


def source_proof():
    def git(*args):
        return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT)
    assert git('rev-parse', 'HEAD').decode().strip() == HEAD
    assert git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE
    assert not git('status', '--porcelain', '--untracked-files=no')
    files = ['tools/dependency_security.py', 'tools/release_qualification.py', 'tools/live_backend_check.py',
             'tools/seed_symbol_cache.py', 'tools/live_unified_check.py', 'tools/live_rzdiff_check.py',
             'tools/bindiff_pin.json', 'tools/provision_bindiff.py', 'tests/test_live_bindiff.py', 'pyproject.toml',
             'src/patchtrace/unified/extract/ghidra_script.py']
    files += ['.github/workflows/' + name + '.yml' for name in
              ('live-backend', 'live-unified', 'live-bindiff', 'live-rizin', 'optional-deps',
               'dependency-security', 'qa-windows')]
    proof = []
    for name in files:
        raw = (ROOT / name).read_bytes()
        assert raw == git('show', HEAD + ':' + name)
        target = QA / 'source-55f3' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists():
            assert target.read_bytes() == raw
        else:
            with target.open('xb') as handle:
                handle.write(raw)
        proof.append({'path': name, 'bytes': len(raw), 'sha256': digest(raw),
                      'blob': git('rev-parse', HEAD + ':' + name).decode().strip()})
    return proof


def hosted_ownership():
    scopes = [
        (44355795341, 'live-bindiff', 'final-bindiff-jobs', [134983436284]),
        (44355795281, 'live-backend', 'final-backend-jobs', [134983435670]),
        (44355795413, 'optional-deps', 'jobs-44355795413', [134983435605]),
        (44355795273, 'live-rizin', 'final-rizin-jobs', [134983435271]),
        (44355795241, 'dependency-security', 'final-scanner-jobs', [134983435409, 134983436211]),
        (44355710739, 'live-unified', 'refresh-unified-jobs', [134983127993, 135015211489]),
    ]
    result = []
    for run_id, workflow, jobs_name, reviewed in scopes:
        run = api('final-unified-run' if workflow == 'live-unified' else f'run-{run_id}')
        assert run['id'] == run_id and run['head_sha'] == HEAD and run['run_attempt'] == 1
        assert run['repository']['full_name'] == run['head_repository']['full_name'] == 'djshellshoxxx/patchtrace'
        assert run['path'] == f'.github/workflows/{workflow}.yml'
        assert run['event'] == ('push' if workflow == 'live-unified' else 'pull_request')
        if workflow == 'live-unified':
            assert run['status'] == 'completed' and run['conclusion'] == 'success'
        jobs = api(jobs_name)['jobs']
        assert len({job['id'] for job in jobs}) == len(jobs)
        for job_id in reviewed:
            job = next(job for job in jobs if job['id'] == job_id)
            assert job['run_id'] == run_id and job['run_attempt'] == 1 and job['head_sha'] == HEAD
            assert job['status'] == 'completed'
            assert job['conclusion'] == ('failure' if job_id == 134983436211 else 'success')
            failed = [step['name'] for step in job['steps'] if step['conclusion'] not in {'success', 'skipped'}]
            assert failed == (['Static security scan'] if job_id == 134983436211 else [])
            result.append({'run_id': run_id, 'job_id': job_id, 'name': job['name'], 'workflow': run['path'],
                           'event': run['event'], 'run_attempt': 1, 'conclusion': job['conclusion'],
                           'steps': [{'name': step['name'], 'conclusion': step['conclusion']} for step in job['steps']]})
    artifacts = []
    for filename in ('artifact-downloads.json', 'artifact-downloads-additional.json'):
        for saved in json.loads((QA / filename).read_bytes()):
            found = []
            for path in (QA / 'api').glob('*.json'):
                envelope = json.loads(path.read_bytes())
                if not isinstance(envelope.get('raw_content'), str):
                    continue
                document = json.loads(envelope['raw_content'])
                for row in document.get('artifacts', []):
                    if row['id'] == saved['artifact_id']:
                        found.append(row)
            assert found
            raw = (QA / 'artifacts' / f'artifact-{saved["artifact_id"]}.zip').read_bytes()
            assert len(raw) == saved['bytes'] and digest(raw) == saved['sha256']
            for row in found:
                assert row['expired'] is False and row['size_in_bytes'] == len(raw)
                assert row['digest'] == 'sha256:' + digest(raw) and row['name'] == saved['name']
                assert row['workflow_run']['head_sha'] == HEAD
                assert row['workflow_run']['repository_id'] == row['workflow_run']['head_repository_id'] == 1413730581
                assert row['workflow_run']['id'] in {scope[0] for scope in scopes}
            with archive(saved['artifact_id']) as z:
                assert z.testzip() is None
            artifacts.append({'artifact_id': saved['artifact_id'], 'name': saved['name'],
                              'run_id': found[0]['workflow_run']['id'], 'sha256': digest(raw),
                              'bytes': len(raw), 'github_digest_and_crc_verified': True})
    assert len(artifacts) == len({item['artifact_id'] for item in artifacts}) == 7
    return result, artifacts


def main():
    proof = source_proof()
    sys.path[:0] = [str(ROOT / 'src'), str(ROOT)]
    denied = []

    def no_execution(event, _args):
        if event == 'subprocess.Popen' or event in {'os.system', 'os.exec', 'os.posix_spawn', 'os.spawn'} or \
                event.startswith('socket.'):
            denied.append(event)
            raise RuntimeError('receipt-only review refused ' + event)
    sys.addaudithook(no_execution)
    from tools import dependency_security as scanner
    project = tomllib.loads((ROOT / 'pyproject.toml').read_text())
    assert Path(scanner.__file__).resolve() == ROOT / 'tools/dependency_security.py'
    assert api('final-main')['commit']['sha'] == '9c411ca3d7b47f950be5f0c6f01b3c54184554c6'
    pr = api('final-pr316')
    assert pr['state'] == 'open' and not pr['merged'] and pr['head']['sha'] == HEAD
    commit = api('preview-commit')
    assert commit['sha'] == PREVIEW and commit['tree']['sha'] == TREE
    assert {row['sha'] for row in commit['parents']} == {HEAD, '9c411ca3d7b47f950be5f0c6f01b3c54184554c6'}
    hosted_jobs, artifacts = hosted_ownership()

    job_sources = []
    for path in sorted((QA / 'logs').glob('job-*.delivery.json')):
        record = json.loads(path.read_bytes())
        lines = record['decoded_log'].splitlines()
        commits = []
        for index, line in enumerate(lines[:-1]):
            if 'log -1 --format=%H' in line:
                match = re.search(r'\b([a-f0-9]{40})$', lines[index + 1])
                if match:
                    commits.append(match.group(1))
        assert len(commits) == 1 and commits[0] in {HEAD, PREVIEW}
        expected = HEAD if record['job_id'] in {134983127993, 135015211489} else PREVIEW
        assert commits[0] == expected
        job_sources.append({'job_id': record['job_id'], 'checkout_sha': commits[0],
                            'source_kind': 'canonical push head' if expected == HEAD else 'PR merge preview',
                            'decoded_log_utf8_sha256': digest(record['decoded_log'].encode('utf-8'))})

    with archive(14455712791) as z:
        bindiff = scanner.gate.strict_json(z.read('bindiff.json'), scanner.MAX_JSON)
        provision = scanner.gate.strict_json(z.read('bindiff-provision.json'), scanner.MAX_JSON)
        assert bindiff['mocked'] is False and bindiff['status'] == provision['status'] == 'passed'
        assert len(bindiff['checks']) == 7 and all(row['status'] == 'passed' for row in bindiff['checks'].values())
        assert digest(z.read('bindiff-live.BinDiff')) == bindiff['checks']['end_to_end']['output_sha256']
        assert bindiff['checks']['end_to_end']['matches'] == bindiff['checks']['no_network']['matches'] == 20
        pin = json.loads((ROOT / 'tools/bindiff_pin.json').read_bytes())['assets']['linux']
        assert provision['sha256'] == pin['sha256'] and provision['advisory'] is False
        # provision.bytes is the aggregate extracted-file size, not the downloaded
        # archive size. The provisioning source separately validates the pin size.
        assert type(provision['bytes']) is int and provision['bytes'] > 0
        assert provision['executable_sha256'] == bindiff['checks']['probe']['executable_sha256']
        bindiff_review = {'subchecks': {key: value['status'] for key, value in bindiff['checks'].items()},
                          'matches': 20, 'raw_database_digest_matches': True,
                          'limit': 'authored synthetic fixture; original source compares counts under unshare, no complete semantic fingerprint in this receipt',
                          'extracted_file_bytes': provision['bytes'], 'archive_pin_bytes': pin['size'],
                          'pin_trust_note': provision['trust']}
    with archive(14457495243) as z:
        rizin = scanner.gate.strict_json(z.read('live-rzdiff-Linux.json'), scanner.MAX_JSON)
        assert rizin['status'] == 'passed' and rizin['mocked'] is False and rizin['errors'] == []
        assert rizin['engine_run']['status'] == 'ok' and rizin['engine_run']['error_code'] is None
        assert rizin['pin'] == rizin['rizin_version'] == '0.9.1' and rizin['match_count'] == 30
        assert all(rizin['help_flags'].values())
    with archive(14458335539) as z:
        name = next(name for name in z.namelist() if name.endswith('backend-execution.json'))
        backend = scanner.gate.strict_json(z.read(name), scanner.MAX_JSON)
        assert backend['returncode'] == 0 and backend['process_state'] == 'stopped' and backend['stop_reason'] == 'exited'
        raw_name = next(name for name in z.namelist() if name.endswith('.ghidriff.json'))
        raw = scanner.gate.strict_json(z.read(raw_name), scanner.MAX_JSON)
        log = (QA / 'logs/job-134983435670.log').read_text(encoding='utf-8-sig')
        assert 'seeded C:\\gout\\symbols\\old.pdb' in log and 'seeded C:\\gout\\symbols\\new.pdb' in log
        assert 'Known patch accepted: 1 change records' in log
        backend_review = {'execution': backend, 'raw_json_keys': sorted(raw),
                          'known_bounds_check_accepted': True, 'both_pdb_seeds_observed': True,
                          'limit': 'patchtrace-seeded-store Windows scenario only; other four matrix scenarios uncredited'}

    unified = []
    script_sha = digest((ROOT / 'src/patchtrace/unified/extract/ghidra_script.py').read_bytes())
    with archive(14454649231) as windows, archive(14458849599) as linux:
        for tag, stem in (('ci-pair', 'ci'), ('probe-pair', 'probe')):
            win = scanner.gate.strict_json(windows.read(f'live-out/live-unified-{tag}-windows.json'), scanner.MAX_JSON)
            lin = scanner.gate.strict_json(linux.read(f'live-unified-{tag}-linux.json'), scanner.MAX_JSON)
            assert win['os'] == 'Windows' and lin['os'] == 'Linux'
            assert win['script_sha256'] == lin['script_sha256'] == script_sha
            for side, filename_side in (('older', 'old'), ('newer', 'new')):
                raw = windows.read(f'fx/{stem}_{filename_side}.dll')
                a, b = win['sides'][side], lin['sides'][side]
                assert a['artifact_sha256'] == b['artifact_sha256'] == digest(raw)
                assert a['content_digest'] == b['content_digest']
                assert win['ghidriff'][side]['equals_own_analysis'] is True
                assert lin['ghidriff'][side]['equals_own_analysis'] is True
                for record in (a, b):
                    assert record['counts']['functions'] > 0 and record['counts']['mask_unlocated'] == 0
                    assert record['warnings'] == []
                    assert all(record['hashers'][key]['equal'] for key in ('h0', 'h3', 'h3x', 'hmx'))
                    assert record['hashers']['h3']['refines'] and record['hashers']['hm']['refines']
                unified.append({'pair': tag, 'side': side, 'artifact_sha256': digest(raw),
                                'content_digest': a['content_digest'], 'functions': a['counts']['functions'],
                                'windows_linux_equal': True, 'ghidriff_gzf_equals_own_analysis_both_os': True,
                                'hm_equal_windows': a['hashers']['hm']['equal'], 'hm_refinement_both_os': True})
    linux_log = (QA / 'logs/job-135015211489.log').read_text(encoding='utf-8-sig')
    assert linux_log.count('PASS L6 content_digest equals the Windows run for the same DLL bytes') == 2
    assert re.search(r'Z FAIL L[1-6]', linux_log) is None

    scans = []
    for artifact_id, profile in ((14458535146, 'runtime'), (14459695622, 'static')):
        local = QA / 'scan-files' / profile
        local.mkdir(parents=True)
        with archive(artifact_id) as z:
            for name in z.namelist():
                assert PurePosixPath(name).name == name and Path(name).suffix in {'.json', '.txt', '.stdout', '.stderr'}
                with (local / name).open('xb') as stream:
                    stream.write(z.read(name))
        context = scanner.read_json(local / 'context.json')
        assert context['source_sha'] == PREVIEW and context['source_tree'] == TREE and context['event'] == 'pull_request'
        assert context['repository'] == 'djshellshoxxx/patchtrace' and context['run_id'] == 44355795241
        assert context['run_attempt'] == 1 and context['platform'] == 'ubuntu-latest' and context['profile'] == profile
        assert context['schema'] == 1 and context['origin'] == 'github-actions'
        assert context['workflow'] == '.github/workflows/dependency-security.yml'
        assert (local / 'bootstrap-pip.txt').read_bytes() == scanner.bootstrap_requirements_text().encode()
        remote_root = Path(context['checkout'])
        identity = scanner.read_json(local / 'scanner-identity.stdout')
        remote_out = Path(identity['prefix']).parent
        plan = scanner.commands(remote_out, remote_root, project, profile)
        # The source policy uses sys.executable for initial venv creation. Compare
        # against the original host's captured/setup-logged controller, never this
        # review host's interpreter, without rewriting any captured receipt.
        for name, argv in plan.items():
            if name.endswith('-venv'):
                assert argv[0] == sys.executable
                argv = [context['controller_python']['executable'], *argv[1:]]
            if name == 'static':
                continue
            scanner.process_receipt(local, name, argv)
        controller_prefix = str(Path(context['controller_python']['executable']).parent.parent)
        own_job = 134983435409 if profile == 'runtime' else 134983436211
        assert any('pythonLocation:' in line and controller_prefix in line for line in
                   (QA / f'logs/job-{own_job}.log').read_text().splitlines())
        inspection = scanner.read_json(local / 'scanner-inspect.stdout')
        scanner.validate_interpreter(identity, scanner.python_path(remote_out, 'scanner-env'), 'Linux', inspection)
        tooling = scanner.distributions(inspection)
        for name, version in scanner.PINS.items():
            if profile != 'static' or name == 'ruff':
                assert tooling[name][0] == version
        bootstrap = scanner.bootstrap_record(local, 'scanner')
        scanner.validate_installation(inspection, identity, [scanner.read_json(local / 'scanner-install.json')],
                                      remote_root, bootstrap=bootstrap)
        assert scanner.read_json(local / 'unaudited.json') == scanner.UNAUDITED
        result = {'profile': profile, 'artifact_id': artifact_id, 'context': context,
                  'verified_process_receipts': len(plan) - (profile == 'static'),
                  'scanner_bootstrap': scanner.validate_bootstrap(bootstrap, identity),
                  'scanner_identity': identity, 'scanner_pins': {name: tooling[name][0] for name in scanner.PINS if name in tooling}}
        if profile == 'static':
            process = scanner.read_json(local / 'static.process.json')
            assert process['argv'] == plan['static'] and process['exit_code'] == 1
            assert process['timed_out'] is False and process['output_limited'] is False and process['error'] is None
            assert process['stdout_sha256'] == digest((local / 'static.stdout').read_bytes())
            assert process['stderr_sha256'] == digest((local / 'static.stderr').read_bytes())
            findings = scanner.read_json(local / 'static.stdout')
            try:
                scanner.validate_static(findings, process['exit_code'])
            except scanner.EvidenceError as error:
                result['correctly_refused'] = str(error)
            else:
                raise AssertionError('failed strict scan was admitted')
            result.update(status='failed', findings=len(findings), findings_by_rule=dict(Counter(row['code'] for row in findings)),
                          static_exit_code=process['exit_code'], no_finding_suppression=True)
        else:
            inventory = scanner.read_json(local / 'inventory.json')
            identity = scanner.read_json(local / 'profile-identity.stdout')
            inspection = scanner.read_json(local / 'profile-inspect.stdout')
            scanner.validate_interpreter(identity, scanner.python_path(remote_out, 'profile-env'), 'Linux', inspection)
            installed = scanner.distributions(inspection)
            owner, version = scanner.package_id(project['project'])
            assert installed[owner][0] == version and owner == 'patchtrace'
            scanner.require_selected(installed, scanner.selected_requirements(project, profile))
            origin = installed[owner][1]['direct_url']
            assert origin['dir_info'] == {'editable': True} and origin['url'] == remote_root.as_uri()
            assert all(name == owner or 'direct_url' not in row for name, (_, row) in installed.items())
            expected = [{'name': name, 'version': value[0]} for name, value in sorted(installed.items()) if name != owner]
            assert inventory['auditable'] == expected and inventory['selected_extras'] == ['search', 'rules']
            assert inventory['repository_owned'] == {'name': owner, 'version': version, 'origin': origin['url']}
            bootstrap = scanner.bootstrap_record(local, 'profile')
            bootstrap_proof = scanner.validate_bootstrap(bootstrap, identity)
            assert inspection['environment'] == bootstrap['after']['environment']
            reported = {'pip': bootstrap_proof['to_version']}
            for filename in ('build-install.json', 'profile-install.json'):
                report = scanner.read_json(local / filename)
                assert report['version'] == '1' and report['environment'] == inspection['environment']
                assert report['pip_version'] == inspection['pip_version'] == installed['pip'][0] == '26.3'
                for row in report['install']:
                    name, version = scanner.package_id(row['metadata'])
                    assert row['is_yanked'] is False and name not in reported and installed[name][0] == version
                    info = row['download_info']
                    if name == owner:
                        assert info['dir_info'] == {'editable': True} and info['url'] == remote_root.as_uri()
                    else:
                        parsed = urlsplit(info['url'])
                        assert parsed.scheme == 'https' and parsed.hostname == 'files.pythonhosted.org'
                        assert not parsed.username and not parsed.password and unquote(parsed.path).endswith('.whl')
                        assert re.fullmatch('[0-9a-f]{64}', info['archive_info']['hashes']['sha256'])
                    reported[name] = version
            assert set(reported) == set(installed)
            assert (local / 'audit-requirements.txt').read_text() == scanner.requirements_text(inventory)
            coverage = scanner.validate_audit(scanner.read_json(local / 'audit.stdout'), expected,
                                               scanner.read_json(local / 'audit.process.json')['exit_code'])
            result.update(status='passed', audited_distributions=coverage, vulnerabilities=0, skips=0, fixes=0,
                          profile_bootstrap=bootstrap_proof, installed_inventory=inventory,
                          limitation='Remote checkout existence cannot be re-observed locally. Hosted validation proves that check; this offline review verifies recorded origin, canonical tree, commands, installation/identity crosschecks and exact audit closure without rehoming receipts.')
        scans.append(result)

    assert not denied
    dump('review.json', {'source_head': HEAD, 'source_tree': TREE, 'merge_preview': PREVIEW,
                         'preview_tree_equals_head': True, 'source_files': proof, 'job_checkouts': job_sources,
                         'hosted_jobs': hosted_jobs, 'artifacts': artifacts,
                         'bindiff_linux': bindiff_review, 'rizin_linux': rizin, 'backend_windows_seeded_store': backend_review,
                         'unified_script_sha256': script_sha, 'unified_cross_os': unified, 'scan_reviews': scans,
                         'receipt_review_process_or_network_attempts': denied,
                         'no_later_source_qualification': True, 'no_release_qualification': True})
    print(json.dumps({'job_checkouts': job_sources, 'unified_sides_verified': len(unified),
                      'scan_profiles': [{k: row[k] for k in ('profile', 'status', 'audited_distributions', 'findings') if k in row} for row in scans]}))


if __name__ == '__main__':
    main()
