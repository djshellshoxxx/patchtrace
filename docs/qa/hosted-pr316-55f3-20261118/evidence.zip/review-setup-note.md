# Review harness setup correction

The first receipt-review execution stopped at an empty historical API envelope:
`api/main.json` contains `raw_content: null`, as do `pr316.json`,
`unknown-windows-run.json`, and `unknown-windows-job.json`. These four files are
unusable initial capture placeholders, not successful API evidence. They remain
unchanged. The failed execution is retained in `review.log` and its exact helper
in `review_receipts-first.py`. No artifact parsing or scanner validation occurred
before that stop; only the 18 read-only canonical Git source snapshots completed.

The corrected helper reads the separately retained successful `final-main.json`,
`final-pr316.json`, and `final-unified-run.json` API responses, and uses the jobs
collection for the Windows job. Existing source snapshots must compare byte for
byte on retry. Nothing in the raw hosted logs, artifacts, source, tests, or
captured scanner receipts was changed. This was a review setup error, not a
product or CI failure. An earlier interactive metadata dump hit the same empty
`unknown-windows-run` placeholder after printing the valid job/artifact data.

The `bytes` field in BinDiff's provisioning receipt is the sum of extracted
regular-file lengths, as shown in `tools/provision_bindiff.py`; it is not the
downloaded `.deb` length. That distinction was corrected in the review helper
before its first execution. The retained archive-pin size and extracted-byte
count are reported separately.

The second execution (`review-corrected.log`, helper
`review_receipts-second.py`) completed runtime receipt validation, then found a
real retention limit: the static artifact omits `bootstrap-pip.txt` because its
workflow upload patterns exclude `*.txt`. The runtime artifact includes this
input. The final review preserves the missing static input explicitly, does not
reconstruct it, and continues checking the retained static command, installer,
interpreter, JSON, hashes, and nonzero result. It never gives that failed static
profile full validation or qualification credit. The source owner was notified
of the small upload-pattern omission. No production change is part of this
read-only packet.
