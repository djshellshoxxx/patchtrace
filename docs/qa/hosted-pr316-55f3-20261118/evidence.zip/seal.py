"""Seal this read-only evidence directory; no network or child execution."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent
excluded = {'manifest.json', 'evidence.zip', 'seal.log'}
files = sorted((path for path in root.rglob('*') if path.is_file() and
                path.relative_to(root).as_posix() not in excluded and
                '__pycache__' not in path.parts), key=lambda path: path.relative_to(root).as_posix())
members = []
with zipfile.ZipFile(root / 'evidence.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for path in files:
        assert not path.is_symlink()
        raw, name = path.read_bytes(), path.relative_to(root).as_posix()
        entry = zipfile.ZipInfo(name, date_time=(1980, 1, 1, 0, 0, 0))
        entry.compress_type = zipfile.ZIP_DEFLATED
        entry.external_attr = 0o100644 << 16
        archive.writestr(entry, raw)
        members.append({'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
with zipfile.ZipFile(root / 'evidence.zip') as archive:
    assert archive.testzip() is None
    assert archive.namelist() == [row['path'] for row in members]
    for row in members:
        raw = archive.read(row['path'])
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
        assert (root / row['path']).read_bytes() == raw
raw = (root / 'evidence.zip').read_bytes()
manifest = {
    'schema': 1, 'sealed_utc': datetime.now(timezone.utc).isoformat(),
    'source_head': '55f3d0742f7d4cf32357a42b8b1cc76d85875e71',
    'source_tree': '11a0c1598764ebd3fd8d3b540377aa52e949f88a',
    'pr_preview': '872947fd8edead1f3269700375c05149fa71e9ef',
    'archive': 'evidence.zip', 'archive_bytes': len(raw),
    'archive_sha256': hashlib.sha256(raw).hexdigest(),
    'member_count': len(members), 'member_bytes': sum(row['bytes'] for row in members),
    'all_members_crc_size_sha256_verified': True, 'members': members,
    'no_source_commit_created': True,
    'limits': ['Not full release/merge qualification', 'No attribution to later integration source',
               'Static scan failed with 81 findings and omits bootstrap-pip.txt in uploaded evidence',
               'QA/Qt and several native/dependency scenarios incomplete at captured final status'],
}
with (root / 'manifest.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
print(json.dumps({key: value for key, value in manifest.items() if key != 'members'}, sort_keys=True))
