"""Retain the reviewed per-site source reasoning; does not change scanner policy."""
from __future__ import annotations

import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/c7a9e8d98848/security-contract-triage')
mapped = json.loads((HERE / 'selected-source-map.json').read_text())

ASSERTIONS = {
    'callgraph/delta.py': (
        'Imported callee/caller strings become Entry tuples from strict FunctionRecord models.',
        '_old_changes/_new_changes call _change only while iterating a concrete label; every branch supplies '
        'that label as older or newer. The assertion narrows the union for the helper. FunctionRecord rejects '
        'None in callees under normal and optimized Python. A direct unsupported call to _change(None,None) '
        'would violate this caller invariant; this disposition does not promise validation for that call.',
        'delta.py:60-78,86-120; project_input.py:60-62; models.py:57-69', 'assertions_core'),
    'callgraph/minimap_qt.py': (
        'The GUI reads a minimap of local graph points and viewport geometry.',
        'model refreshes when absent; refresh either returns with an existing model or assigns build_minimap '
        'before returning. That pure builder returns a MinimapModel or raises. The assertion does not gate '
        'point admission or navigation ownership.',
        'minimap_qt.py:47-68; minimap.py:build_minimap', 'assertions_qt'),
    'enrichment/wil.py': (
        'Authored/imported decompiler-like text is scanned for lexical feature gates.',
        '_scan retains a _Gate on a _Site only when gate.body is non-None; otherwise it sets gate=None. '
        '_qualifying_hunk calls _region only for a retained site gate. The frozen internal gate is the '
        'producer invariant; optimization does not admit empty/unmatched/semicolon bodies for WIL scoring.',
        'wil.py:115-178,207-210,237-247', 'assertions_core'),
    'kbcorrelation/panel_qt.py': (
        'The assertion compares two module-defined UI column lists.',
        'COLUMNS is built from five fixed literals and COLUMN_NAMES is a source-defined display contract. '
        'No imported label, model response or user query supplies either count.',
        'panel_qt.py:46-53', 'assertions_qt'),
    'kbcorrelation/store.py': (
        'Attach/recovery reads an investigation revision from the local workspace.',
        '_begin explicitly refuses absent/noncurrent/non-BYTES_VERIFIED revisions before attach work. '
        '_cas assumes that stored investigation still exists. If it disappears, removing the assertion '
        'still encounters current.revision before reduce/append_revision, rather than permitting a CAS. '
        'The transactional append_revision independently verifies next revision/parent and compares '
        'expected current state in an UPDATE predicate. Error formatting for a corrupt missing revision '
        '(AssertionError versus AttributeError under -O) is not a validation-bypass conclusion.',
        'store.py:414-444,446-459,594-598,677-690', 'assertions_core'),
    'secondary/bindiff_probe.py': (
        'The configured helper path is inspected before an optional capability runner is called.',
        'check_path returns (None, failure report) on every invalid branch; its sole success returns '
        '(resolved Path, None). probe_report returns failure before the assertion. The assertion narrows '
        'that internal tuple result. A runner was injected for the external positive; no helper was executed.',
        'bindiff_probe.py:106-127,139-158', 'assertions_bindiff'),
    'secondary/bindiff_run.py': (
        'The execution wrapper imports a preserved output only after a clean runner result.',
        'execute returns missing kept_path/output_sha256 only for cancelled/timeout; run_bindiff raises '
        'both before the assertion. Every other non-clean stop, nonzero status and invalid output shape '
        'raises. Success follows snapshot rehash, one regular output, size check, hash and preserve. '
        'The hardened importer then checks schema, pair and output hash independently of assert.',
        'bindiff_run.py:183-276,303-318', 'assertions_bindiff'),
    'ui_series.py': (
        'The series GUI displays results emitted by the local loader.',
        'on_loaded assigns the LoadedSeries before _show_view; on_failed constructs a failed LoadedSeries. '
        'cancel_load dispatches to on_failed when absent and otherwise shows the retained model; requery '
        'requires loaded not None and no worker. The assertion is not an evidence/navigation admission gate.',
        'ui_series.py:284-316,328-335', 'assertions_qt'),
    'unified/ladder/passes.py': (
        'The assertion compares the source-defined pass tuple to its dictionary index.',
        'P00/PASSES use fixed unique pass IDs. PASS_BY_ID is constructed from them, and the assertion has no '
        'side effects. No IR record or caller configuration supplies these source constants.',
        'passes.py:355-381', 'assertions_core'),
}

SQL = {
    'diaphora/sqlite_guard.py': (
        'External SQLite results plus table requests to a fixed-shape snapshot reader.',
        'SCHEMA[table] lookup and _check precede SQL, so unknown identifiers fail before execution. Column '
        'names come from the same fixed SCHEMA; the row limit is bound. Private read-only snapshot plus '
        'authorizer also denies writes, attachments and reads through views/triggers.',
        'sqlite_guard.py:33-40,50-66,94-97,108-122', 'sql_diaphora'),
    'enrichment/storage.py': (
        'Stored row identifiers selected for derived-result retention.',
        'The only formatted pieces are question-mark lists generated from lengths. IDs, kinds and row '
        'content are SQLite parameters; DERIVED_KINDS is a source tuple. _delete verifies a backup and '
        'restricts both ID and kind in the same transaction.',
        'storage.py:66,308-313,350-370', 'sql_retention'),
    'kbcorrelation/inventory_store.py': (
        'Imported CSV/support metadata, hashed raw objects, lookups and pagination.',
        'Table identifiers are docs plus fixed INVENTORY_TABLE/SUPPORT_TABLE from _TABLES. Public add/get/list '
        'wrappers pass these literals to private helpers. Import IDs, sizes, bodies, SHA values and page '
        'bounds are parameters; _budget concatenates fixed SELECT grammar over that fixed table list. '
        'Public ID/pagination validation remains explicit. _write_raw still contains its fixed-table '
        'SELECT in the current source; the earlier provisional trace incorrectly described it as removed.',
        'inventory_store.py:44-46,222-231,257-264,330-380,407,428,448,451-470,482-537', 'sql_workspace'),
    'kbcorrelation/store.py': (
        'Advisory dictionary names and user KB/CVE lookup values.',
        '_dictionary is called from add_document with only kbs/cves/products literal table names; values '
        'are bound. Its SELECT uses the same fixed table. Public edges_for_kb/edges_for_cve pass only '
        'kbs.name=?/cves.name=? as grammar and bind the caller lookup text. Private helper table/where '
        'arguments are trusted internal grammar, not a public arbitrary-SQL interface.',
        'store.py:319-327,342-363', 'sql_workspace'),
    'persistence.py': (
        'History rows selected for pruning by the retention algorithm.',
        'The formatted fragment contains only a question-mark per selected sequence. The sequence values '
        'are bound; the history schema declares an INTEGER PRIMARY KEY. A verified history backup is '
        'required before this pruning branch. No caller data supplies table/column/WHERE grammar.',
        'persistence.py:34-35,604-644; tests/test_history_bound.py', 'affected history tests'),
    'pilot/store.py': (
        'Pilot result IDs checked in backups and selected for retention deletion.',
        '_holds and delete_results generate only question-mark lists. All IDs are bound; deletion also '
        'binds KIND and the fixed pilot-result prefix LIKE pattern, with an explicit startswith filter '
        'before backup/deletion. Authored literal SQL-looking IDs delete only their own permitted rows.',
        'pilot/store.py:383-436', 'sql_retention'),
    'project_cli.py': (
        'The headless project summary reads stored enrichment kinds.',
        'The sole interpolated value is source constant DERIVED_KIND_LIMIT=64. The query takes no caller '
        'table, column, limit or predicate string. Grouped row values are output data.',
        'project_cli.py:26,191-203', 'sql_retention and affected CLI tests'),
    'search/segment.py': (
        'Local function/name/code/text documents are inserted into a derived search segment.',
        '_rows chooses table names from fixed names. _insert indexes a fixed columns mapping before '
        'formatting the FTS statement; an unknown nonempty table cannot pass that lookup. Placeholders '
        'come from row width and all document text is bound through executemany.',
        'segment.py:160-181,192-199', 'sql_search'),
    'search/service.py': (
        'Analyst search text, enum filters, names, addresses and hashes over local search segments.',
        'DOC_COLUMNS/NAME_KINDS are constants. _fetch callers use only fts_name/tri_name/fts_code/fts_text; '
        '_in is called only with d.kind/d.side and binds values. Branch-built predicates use fixed '
        'd.value_sha/d.rva/d.subject grammar and placeholder counts. MATCH expressions, filter values '
        'and limits are bound. Query parsing separately quotes FTS words/phrases and validates filters; '
        'this review does not confuse SQL parameterization with unconstrained FTS-language safety.',
        'service.py:53-54,71-95,109-175,182-240; query.py:25-34,parse_query,match_words', 'sql_search'),
    'unified/ir/ingest.py': (
        'Strict JSONL IR function rows become private SQLite staging rows.',
        '_Tables.flush iterates six fixed table/row attribute pairs. Formatted marks contain only question '
        'marks from tuple width; every name, alias, constant, blob and reference value is bound.',
        'ingest.py:154-161', 'sql_ir'),
    'unified/ir/reader.py': (
        'An admitted IR database is read into a FunctionTable.',
        'select is assembled only from fid, fixed FN_COLUMNS, name, aliases, import_key and eh. The table '
        'and order are fixed fn/fid. Stored function names and aliases never become SQL syntax.',
        'reader.py:29-31,287-312', 'sql_ir'),
    'unified/ir/schema.py': (
        'IR table rows are streamed for content identity.',
        'COLUMNS[table] and _ORDER[table] are fixed mappings accessed before SQL. Unknown identifiers raise '
        'KeyError; the public helper does not accept an arbitrary table or ordering expression.',
        'schema.py:61-80,170-179', 'sql_ir'),
    'unified/store.py': (
        'Unified result IDs checked in backups and deleted by its retention path.',
        '_trusted/delete_own generate placeholder lists only. IDs/kinds are bound; delete_own explicitly '
        'requires a nonempty subset of UNIFIED_KINDS and then deletes only that kind after a verified '
        'backup. A caller cannot turn a supplied kind into SQL grammar.',
        'unified/store.py:758-779,823-851', 'sql_retention'),
}

rows = []
for original in mapped['rows']:
    short = original['path'].removeprefix('src/patchtrace/')
    boundary, reason, guards, controls = (ASSERTIONS if original['rule'] == 'S101' else SQL)[short]
    row = original | {'classification': 'false-positive-at-reviewed-production-boundary',
                      'input_boundary': boundary, 'reason': reason, 'guard_evidence': guards,
                      'control_group': controls, 'source_changed': False,
                      'scanner_suppressed': False}
    rows.append(row)
out = {'review_source': mapped['source'], 'detector_source': mapped['detector_source'],
       'detector_sha256': mapped['detector_sha256'],
       'scope': 'Nine S101 and 34 S608 rows only; source-flow disposition, not a blanket security verdict.',
       'counts': {'S101': 9, 'S608': 34, 'confirmed_defects_in_this_slice': 0, 'remaining_diagnostics': 36},
       'rows': rows}
must_count = len(rows) == 43 and sum(r['rule'] == 'S608' for r in rows) == 34
if not must_count:
    raise RuntimeError('incomplete selected-site coverage')
(HERE / 'dispositions.json').write_text(json.dumps(out, indent=2) + '\n')
print('43 per-site dispositions retained')
