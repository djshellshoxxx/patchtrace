"""External review: compare explicit authored-data oracles with and without assertions."""
from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path

import pytest

ROOT = Path('/workspace/scratch/c7a9e8d98848/security-contract-triage')
PYTHON = Path('/workspace/scratch/3a6632a6e5ff/venv/bin/python')
HERE = Path(__file__).resolve().parent
CASES = ('assertions_core', 'assertions_qt', 'assertions_bindiff', 'sql_retention',
         'sql_workspace', 'sql_search', 'sql_ir', 'sql_diaphora')


@pytest.mark.parametrize('case', CASES)
def test_normal_and_optimized_keep_the_authored_boundary(case, tmp_path):
    results = []
    for optimized in (False, True):
        mode = 'optimized' if optimized else 'normal'
        command = [str(PYTHON), *(['-O'] if optimized else []), str(HERE / 'contract_probe.py'), case,
                   str(tmp_path / mode)]
        env = os.environ | {'PYTHONPATH': os.pathsep.join((str(ROOT / 'src'), str(ROOT / 'tests'))),
                            'PT_REVIEW_ROOT': str(ROOT), 'QT_QPA_PLATFORM': 'offscreen'}
        env.pop('PYTHONOPTIMIZE', None)
        ran = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True, timeout=30, check=False)
        prefix = HERE / f'{case}-{mode}'
        prefix.with_suffix('.stdout').write_text(ran.stdout)
        prefix.with_suffix('.stderr').write_text(ran.stderr)
        prefix.with_suffix('.process.json').write_text(json.dumps({'command': command, 'returncode': ran.returncode,
            'cwd': str(ROOT), 'PYTHONPATH': env['PYTHONPATH'], 'QT_QPA_PLATFORM': env['QT_QPA_PLATFORM']}, indent=2)+'\n')
        assert ran.returncode == 0, ran.stderr
        result = json.loads(ran.stdout)
        assert result['optimize'] == int(optimized)
        assert result['source_root'] == str(ROOT) and result['source_files']
        results.append(result)
    assert results[0]['result'] == results[1]['result']
    assert results[0]['source_files'] == results[1]['source_files']
