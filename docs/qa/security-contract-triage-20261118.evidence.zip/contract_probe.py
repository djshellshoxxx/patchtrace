"""External authored-data controls. No product monkeypatch, network, or tool execution.

Run under normal Python and -O. All checks are explicit so optimization cannot
remove the review oracle. The injected BinDiff runner only writes authored SQLite.
"""
from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import sys
import threading
import time
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(os.environ['PT_REVIEW_ROOT']).resolve()
WORK = Path(sys.argv[2]).resolve()
WORK.mkdir(parents=True, exist_ok=True)
PAYLOAD = "sentinel'); DELETE FROM enrichment_entries; --"


def must(condition, reason):
    if not condition:
        raise RuntimeError(reason)


def audit(event, _args):
    if event in {'subprocess.Popen', 'os.system', 'os.exec', 'socket.connect',
                 'socket.connect_ex', 'socket.getaddrinfo'}:
        raise RuntimeError(f'forbidden external activity: {event}')


sys.addaudithook(audit)


def refused(call, expected):
    try:
        call()
    except expected as exc:
        return getattr(exc, 'code', type(exc).__name__)
    raise RuntimeError('expected refusal did not occur')


def assertions_core():
    from callgraph_delta_support import analysis
    from test_enrichment_wil import mv

    from patchtrace.enrichment.wil import analyze
    from patchtrace.kbcorrelation.contracts import InvestigationRevision, Lead
    from patchtrace.kbcorrelation.store import AttachRequest, ProjectAttachment, WorkspaceStore
    from patchtrace.kbcorrelation.workflow import Event
    from patchtrace.models import FunctionRecord
    from patchtrace.unified.ladder.passes import PASSES, PASS_BY_ID, pass_table_digest
    from pydantic import ValidationError

    shape = {}
    for name in ('svc_pair', 'hostile_names'):
        _snap, deltas = analysis(name)
        changes = [c for d in deltas for c in d.changes]
        must(changes and all(c.older_label is not None or c.newer_label is not None for c in changes),
             'an admitted callee change lacked both labels')
        shape[name] = sorted((c.cls, c.older_label, c.newer_label) for c in changes)
    refused(lambda: FunctionRecord(artifact_id='a', run_id='r', name='f', callees=[None]), ValidationError)
    old = 'void f() {\n  a(1);\n}'
    gated = 'void f() {\n  if (Feature_42) {\n    a(2);\n  }\n}'
    positive = analyze(mv(old, gated))
    must(len(positive) == 1 and positive[0].qualifies, 'enclosed WIL positive did not qualify')
    bad_bodies = ('if (Feature_42) ;', 'if (Feature_42) {', 'if (Feature_42) {}')
    for body in bad_bodies:
        must(not any(t.qualifies for t in analyze(mv(old, body))), 'bodyless WIL gate qualified')

    inv = '00000000-0000-4000-8000-0000000000e1'
    rev = InvestigationRevision(investigation_id=inv, revision=1,
                                lead=Lead(kind='file', value='example.sys', raw='example.sys'), state='NEW')
    class NeverProject:
        def __getattr__(self, name):
            raise RuntimeError(f'project port unexpectedly used: {name}')
    with WorkspaceStore(WORK / 'workspace') as ws:
        attachment = ProjectAttachment(ws, NeverProject())
        request = AttachRequest(rev, 'b' * 64, '/unused-old', '/unused-new', 'a' * 64, 'b' * 64,
                                str(WORK / 'unused-project'))
        absent = attachment.attach(request)
        must(absent.status == 'error' and absent.issues[0].code == 'PT-KBC-STALE',
             'missing current revision reached project creation')
        must(not ws.journal_ops(), 'refused attach wrote a journal operation')
        ws.create_investigation(rev)
        for kind, fields in (('lead_parsed', {}), ('pair_proposed', {'outcome': 'PAIR_PROPOSED', 'pair_id': 'b' * 64}),
                             ('pair_approved', {}), ('bytes_verified', {'parsed': True, 'both_sides': True})):
            rev = ws.apply(rev, Event(kind, rev.revision, **fields))
        body = attachment._cas('review-op', {'revision': rev.model_dump(mode='json')},
                               'project_created', flag='cas_created', both_sides=True)
        current = ws.current_revision(inv)
        must(current is not None and current.revision == rev.revision + 1 and body['cas_created'],
             'valid CAS producer invariant failed')
        cas_state = current.state
    must(all(PASS_BY_ID[p.id] is p for p in PASSES), 'fixed ladder table lost unique identities')
    return {'callees': shape, 'wil': [positive[0].kind, len(bad_bodies)], 'cas': cas_state,
            'pass_count': len(PASSES), 'pass_digest': pass_table_digest()}


def assertions_qt():
    from PySide6.QtWidgets import QApplication

    from patchtrace.callgraph.minimap_qt import MinimapWidget
    from patchtrace.gui.qt.canvas import GraphCanvas
    from patchtrace.kbcorrelation.panel_qt import COLUMNS, COLUMN_NAMES
    from patchtrace.ui_series import SeriesTab

    app = QApplication.instance() or QApplication([])
    canvas = GraphCanvas()
    widget = MinimapWidget(canvas)
    must(widget.model is not None, 'initial minimap model missing')
    widget.set_points({'authored': (10.0, 20.0)}, 'authored')
    must(len(widget.model.dots) == 1, 'minimap producer did not return a model')
    widget.clear()
    must(widget.model is not None and not widget.model.dots, 'empty minimap model missing')
    must(len(COLUMNS) == len(COLUMN_NAMES) == 5, 'fixed KB column shapes disagree')
    tab = SeriesTab(WORK / 'missing-series.json')
    deadline = time.monotonic() + 5
    while tab.loaded is None and time.monotonic() < deadline:
        app.processEvents()
    must(tab.loaded is not None and tab.view.state == 'failed', 'failed series producer left no view')
    tab.requery()
    tab.cancel_load()
    must(tab.view.state == 'failed', 'series requery/cancel changed failure into ready')
    tab.close()
    widget.close()
    canvas.close()
    app.processEvents()
    return {'minimap': 'empty-model-present', 'columns': len(COLUMNS), 'series': tab.view.state}


def assertions_bindiff():
    from bindiff_builder import build
    from test_bindiff_inputs import accepted

    from patchtrace.secondary import bindiff_probe, bindiff_run
    from patchtrace.secondary.bindiff_inputs import bind_pair
    from patchtrace.secondary.contracts import Capability, SecondaryError

    calls = []
    def probe_runner(argv, **_kwargs):
        calls.append(argv[1:])
        text = 'BinDiff 8 (@authored)' if argv[-1] == '--version' else ' '.join(bindiff_probe.REQUIRED_OPTIONS)
        return SimpleNamespace(reason=None, returncode=0, log_tail=text, stderr_tail='')
    for path in (None, 'relative-bindiff', WORK / 'missing-bindiff', WORK):
        report = bindiff_probe.probe_report(path, runner=probe_runner, use_cache=False)
        must(not report.capability.supported, 'invalid probe path admitted')
    must(not calls, 'invalid probe path reached runner')
    executable = WORK / 'bindiff'
    executable.write_bytes(b'authored inert file: never executed')
    supported = bindiff_probe.probe_report(executable, runner=probe_runner, use_cache=False)
    must(supported.capability.supported and len(calls) == 2, 'valid tuple path failed probe control')
    pair = bind_pair(accepted(WORK, 'old', 'a' * 64), accepted(WORK, 'new', 'b' * 64), 'a' * 64, 'b' * 64)
    cap = Capability(engine='bindiff', supported=True, version='8', path=str(executable), supports_json=False)
    outcomes = {}
    for mode in ('cancelled', 'timeout', 'missing', 'malformed', 'wrong-pair', 'ok'):
        def runner(_argv, *, cwd, **_kwargs):
            out = cwd.parent / 'out' / bindiff_run.EXPECTED_NAME
            if mode == 'malformed':
                out.write_bytes(b'authored non-sqlite output')
            elif mode in ('wrong-pair', 'ok'):
                build(out, hashes=('c' * 64, 'b' * 64) if mode == 'wrong-pair' else ('a' * 64, 'b' * 64))
            return SimpleNamespace(reason=mode if mode in ('cancelled', 'timeout') else None,
                                   returncode=0, log_tail='', stderr_tail='')
        try:
            result = bindiff_run.run_bindiff(cap, pair, WORK / mode, 'a' * 64, 'b' * 64,
                                             cancel=threading.Event(), runner=runner)
        except SecondaryError as exc:
            outcomes[mode] = exc.kind
        else:
            outcomes[mode] = len(result.match_set.matches)
    must(outcomes == {'cancelled': 'cancelled', 'timeout': 'timeout', 'missing': 'output-missing',
                      'malformed': 'output-invalid', 'wrong-pair': 'output-pair-mismatch', 'ok': 2},
         f'BinDiff return-shape validation changed: {outcomes}')
    return {'probe_invalid': 4, 'probe_calls': calls, 'runs': outcomes}


def sql_retention():
    from patchtrace.enrichment.storage import EnrichmentStore, Guard
    from patchtrace.pilot import store as pilot
    from patchtrace.project_cli import _derived
    from patchtrace.service import ProjectService
    from patchtrace.unified import store as unified
    from patchtrace.unified.limits import UnifiedError

    service = ProjectService.sample(WORK / 'project')
    try:
        store = EnrichmentStore(service.store)
        run = next(r for r in service.project.runs if r.raw_sha256)
        guard = Guard(service.project.id, run.id, run.raw_sha256, 'c' * 64)
        def put(kind, ident):
            return store.publish(kind, guard, guard, service.project.revision, 'complete', {'review': ident}, ident)
        put('cve-snapshot', 'foreign-sentinel')
        put('ranking', PAYLOAD)
        put('ranking', 'ranking-sentinel')
        must(PAYLOAD in store._derived_rows(), 'retention selection lost literal ID')
        store._delete([PAYLOAD])
        must([e.id for e in store.entries('ranking')] == ['ranking-sentinel'], 'derived deletion broadened')
        pointer = 'pilot-result:' + PAYLOAD
        put('patch-intent', pointer)
        put('patch-intent', 'pilot-result:sentinel')
        must(pilot.delete_results(store, [pointer, 'foreign-sentinel']) == 1, 'pilot deletion crossed prefix/kind')
        pilot_backup = next((service.root / 'backups').glob('project-pre-pilot-retention-*.sqlite3'))
        must(pilot._holds(pilot_backup, [pointer]), 'pilot backup lost literal ID')
        must(not pilot._holds(pilot_backup, ["' OR 1=1 --"]), 'pilot backup query broadened')
        put('unified-result', PAYLOAD)
        put('unified-result', 'unified-sentinel')
        refused(lambda: unified.delete_own(store, [PAYLOAD], kinds=["unified-result') OR 1=1 --"]), UnifiedError)
        must(unified.delete_own(store, [PAYLOAD, 'foreign-sentinel']) == 1, 'unified deletion crossed kind')
        copies = list((service.root / 'backups').glob('project-pre-unified-*.sqlite3'))
        must(copies and any(unified._trusted(p, service.project.id, [PAYLOAD]) for p in copies),
             'unified backup lost literal ID')
        must(not unified._trusted(copies[-1], service.project.id, ["' OR 1=1 --"]), 'unified backup query broadened')
        must([e.id for e in store.entries('cve-snapshot')] == ['foreign-sentinel'], 'foreign row was deleted')
        counts = _derived(service.store.connection)
        must(counts['ranking']['entries'] == counts['patch-intent']['entries'] == counts['unified-result']['entries'] == 1,
             'literal deletion removed sentinel rows')
        must(service.store.load().id == service.project.id, 'retention changed project identity')
        return {'remaining': {k: counts[k]['entries'] for k in ('ranking', 'patch-intent', 'unified-result', 'cve-snapshot')}}
    finally:
        service.close()


def sql_workspace():
    from kbc_k1_support import import_fixture
    import kbc_helpers

    from patchtrace.kbcorrelation import inventory_store as inventory
    from patchtrace.kbcorrelation.inventory_contracts import InventoryContext
    from patchtrace.kbcorrelation.store import KbcStoreError, WorkspaceStore

    with WorkspaceStore(WORK / 'workspace') as ws:
        doc = import_fixture('cvrf-2099-Feb.json')
        ws.add_document(doc, kbc_helpers.read_fixture_bytes('cvrf-2099-Feb.json'))
        before = len(ws.edges_for_kb(kbc_helpers.KB_CLIENT))
        must(before > 0, 'workspace positive lookup missing')
        for text in ("' OR 1=1 --", 'x; DROP TABLE edges; --', '" UNION SELECT 1 --'):
            must(ws.edges_for_kb(text) == ws.edges_for_cve(text) == (), 'lookup input became SQL syntax')
        ids = ws._dictionary(ws.db, 'products', {PAYLOAD})
        must(PAYLOAD in ids and ws.db.execute('SELECT name FROM products WHERE id=?', (ids[PAYLOAD],)).fetchone()[0] == PAYLOAD,
             'dictionary value was not stored literally')
        raw = (b"File name,File version,File size,Architecture\r\nexample.dll,1.2.3.4,128,x64\r\n"
               b"quote';DROP TABLE docs;--.dll,1.2.3.4,128,x64\r\n")
        first, added = inventory.add_inventory(ws, raw, InventoryContext(kb='KB5099001'), now='2099-01-01T00:00:00Z')
        must(added, 'inventory positive not stored')
        must(first.parsed.accepted_count == first.parsed.rejected_count == 1
             and first.parsed.entries[0].original_filename == 'example.dll',
             'inventory filename validation lost the valid row or admitted the unsafe basename')
        second, added = inventory.add_inventory(ws, raw, InventoryContext(kb='KB5099002'), now='2099-01-01T00:00:00Z')
        must(added and first.import_id != second.import_id, 'second context not stored')
        must(inventory.get_inventory(ws, first.import_id) == first, 'inventory replay mismatch')
        must(len(inventory.list_inventories(ws)) == inventory.inventory_count(ws) == 2, 'inventory SQL changed count')
        must(inventory.support_count(ws) == 0 and inventory.list_support(ws) == (), 'empty support changed')
        must(inventory.referenced_raw_hashes(ws) == (hashlib.sha256(raw).hexdigest(),), 'raw reference identity changed')
        refused(lambda: inventory.get_inventory(ws, "' OR 1=1 --"), KbcStoreError)
        refused(lambda: inventory.list_inventories(ws, limit='1; DROP TABLE docs'), KbcStoreError)
        must(len(ws.edges_for_kb(kbc_helpers.KB_CLIENT)) == before, 'inventory/lookup damaged advisory edges')
        must(inventory.read_source(ws, first) == raw, 'inventory source tokens not retained literally')
        return {'edges_preserved': before, 'inventory_count': 2, 'raw_preserved': True, 'unsafe_filename_rejected': 1}


def sql_search():
    from search_builders import make_service

    from patchtrace.search.contracts import SearchRequest
    from patchtrace.search.errors import SearchError
    from patchtrace.search.query import parse_query
    from patchtrace.search.service import SearchService

    service = make_service(WORK / 'project')
    literal_name = "FormatLine';DROP TABLE doc"
    for record in (*service.project.matches[0].older, *service.project.matches[0].newer):
        record.name = literal_name
    search = SearchService(service, WORK / 'cache')
    def ask(text):
        return search.search(SearchRequest(plan=parse_query(text)))
    positive = ask('FormatLine')
    must(positive.total > 0, 'search positive missing')
    literal = ask('"' + literal_name + '"')
    must(literal.total == 1 and any(e.title == literal_name for h in literal.hits for e in h.evidence),
         'quoted SQL-looking name did not survive real FTS indexing and lookup')
    outcomes = []
    for text in ("NEVERMATCHTOKEN';DELETE", "NEVERMATCHTOKEN' OR 1=1",
                 "NEVERMATCHTOKEN'); DROP TABLE doc; --", "NEVERMATCHTOKEN' OR 1=1 --",
                 'kind:"function) OR 1=1 --"', 'in:"fts_name); DROP TABLE doc;--"'):
        try:
            found = ask(text)
        except SearchError as exc:
            outcomes.append(exc.code)
        else:
            must(found.total == 0, 'SQL-looking search broadened into real rows')
            outcomes.append('zero-results')
    must(ask('FormatLine').total == positive.total, 'search input changed stored index rows')
    must(outcomes[:2] == ['zero-results', 'zero-results'], 'value controls did not reach actual FTS lookup')
    return {'positive_total': positive.total, 'literal_name': literal_name, 'hostile': outcomes}


def sql_ir():
    from unified_extract_builder import SHA, document_set, function, pe_view, write_jsonl

    from patchtrace.unified.ir import schema
    from patchtrace.unified.ir.ingest import ExpectedSide, ingest
    from patchtrace.unified.ir.reader import IrReader

    document = function(0x1000, [('mov',), ('ret',)], name=PAYLOAD, aliases=["alias'); DROP TABLE fn; --"])
    path = write_jsonl(WORK / 'authored.jsonl', document_set(document))
    out = WORK / 'out'
    out.mkdir()
    result = ingest(path, ExpectedSide('older', SHA, pe_view(), mode='analyze'), out_dir=out)
    reader = IrReader.open(result.directory)
    try:
        must(reader.functions.name == [PAYLOAD], 'IR name not retained as a value')
        must(reader.functions.aliases == [("alias'); DROP TABLE fn; --",)], 'IR alias changed')
    finally:
        reader.close()
    db = schema.open_readonly(result.directory / schema.DB_NAME)
    try:
        must(len(list(schema.table_rows(db, 'fn'))) == 1, 'valid IR table inaccessible')
        refused(lambda: list(schema.table_rows(db, 'fn; DROP TABLE fn;--')), KeyError)
        must(db.execute('SELECT COUNT(*) FROM fn').fetchone()[0] == 1, 'bad identifier changed IR rows')
    finally:
        db.close()
    return {'functions': 1, 'name': PAYLOAD, 'identifier_refused': True}


def sql_diaphora():
    from diaphora_support import make_result, row

    from patchtrace.diaphora.sqlite_guard import open_snapshot

    path = make_result(WORK / 'authored.diaphora', [row(n1=PAYLOAD)])
    original = path.read_bytes()
    with open_snapshot(path) as snap:
        must(snap.count('results') == 1, 'valid Diaphora count missing')
        must(list(snap.rows('results', 2))[0][4] == PAYLOAD, 'Diaphora label not literal')
        for table in ('results" UNION SELECT 1 --', 'results; DROP TABLE results;--'):
            refused(lambda: snap.count(table), KeyError)
            refused(lambda: list(snap.rows(table, 2)), KeyError)
        must(snap.count('results') == 1, 'identifier input changed snapshot')
    must(path.read_bytes() == original, 'Diaphora source changed')
    return {'rows': 1, 'rejected_identifiers': 4, 'source_unchanged': True}


CASES = {fn.__name__: fn for fn in (assertions_core, assertions_qt, assertions_bindiff, sql_retention,
                                   sql_workspace, sql_search, sql_ir, sql_diaphora)}
value = CASES[sys.argv[1]]()
modules = {}
for name, module in sorted(sys.modules.items()):
    if name == 'patchtrace' or name.startswith('patchtrace.'):
        file = getattr(module, '__file__', None)
        if file is not None:
            path = Path(file).resolve()
            must(path.is_relative_to(ROOT / 'src'), f'imported wrong source: {path}')
            modules[str(path.relative_to(ROOT))] = hashlib.sha256(path.read_bytes()).hexdigest()
print(json.dumps({'case': sys.argv[1], 'optimize': sys.flags.optimize, 'source_root': str(ROOT),
                  'result': value, 'source_files': modules}, sort_keys=True))
