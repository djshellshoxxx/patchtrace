"""Redirect only the frozen peer probe's observation output; leave assertions/source unchanged."""
import hashlib
import json
from pathlib import Path

QA = Path(__file__).resolve().parent
ORIGINAL = QA.parent / 'semantic-disposition-batch4' / 'test_r2_product_surfaces_v3.py'
OUTPUT = QA / 'green-product-surfaces'
EXPECTED = '37fa19d6c288b1892d9567ddeee7cae35d74c721a73a01247629db6e373b30c4'
PRESERVED = (ORIGINAL.parent / 'product-surfaces-v3', QA / 'current-product-surfaces')
BEFORE = None


def observed():
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
            for directory in PRESERVED for p in sorted(directory.glob('*.json'))}


def pytest_collection_modifyitems(items):
    global BEFORE
    assert hashlib.sha256(ORIGINAL.read_bytes()).hexdigest() == EXPECTED
    BEFORE = observed()
    OUTPUT.mkdir(exist_ok=False)
    found = [item for item in items if Path(item.module.__file__).resolve() == ORIGINAL]
    assert len(found) == 5
    for item in found:
        item.module.EVIDENCE = OUTPUT


def pytest_sessionfinish():
    after = observed()
    assert after == BEFORE, 'Original peer/current-red observation bytes changed'
    (QA / 'green-observations-integrity.json').write_text(json.dumps({
        'probe_sha256': hashlib.sha256(ORIGINAL.read_bytes()).hexdigest(),
        'before': BEFORE, 'after': after, 'unchanged': after == BEFORE,
    }, indent=2) + '\n')
