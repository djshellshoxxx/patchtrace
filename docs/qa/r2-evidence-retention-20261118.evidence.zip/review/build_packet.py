"""Retain the bounded R2 receipt set without modifying original evidence."""
import hashlib
import json
import subprocess
import zipfile
from pathlib import Path

ROOT = Path('/workspace/scratch/c7a9e8d98848/r2-evidence-retention')
QA = Path(__file__).resolve().parent
PEER = QA.parent / 'semantic-disposition-batch4'
SOURCE = '8f0864277d29d3d77a22ee8b30cede7146aa0c9b'
NAME = 'r2-evidence-retention-20261118'
DEST = ROOT / 'docs/qa'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == SOURCE
payloads = {}
for path in sorted(QA.rglob('*')):
    if path.is_file() and '__pycache__' not in path.parts:
        payloads['review/' + path.relative_to(QA).as_posix()] = path.read_bytes()
for name in ('historical-r2.command.json', 'historical-r2.log', 'historical-r2.xml',
             'r2-product-surfaces-v3.command.json', 'r2-product-surfaces-v3.log',
             'r2-product-surfaces-v3.xml', 'test_r2_product_surfaces_v3.py',
             'r2-product-surfaces-correction.md', 'historical-tests.json'):
    payloads['original-peer/' + name] = (PEER / name).read_bytes()
for path in sorted((PEER / 'historical/r2/tests').glob('*.py')):
    payloads['original-peer/' + path.relative_to(PEER).as_posix()] = path.read_bytes()
for path in sorted((PEER / 'product-surfaces-v3').glob('*.json')):
    payloads['original-peer/' + path.relative_to(PEER).as_posix()] = path.read_bytes()
source_manifest = json.loads((QA / 'source-manifest.json').read_text())
for item in source_manifest['files']:
    content = (ROOT / item['path']).read_bytes()
    assert hashlib.sha256(content).hexdigest() == item['sha256']
    payloads['source/' + item['path']] = content
payloads['README.md'] = (DEST / (NAME + '.md')).read_bytes()
archive = DEST / (NAME + '.evidence.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as target:
    for name, content in sorted(payloads.items()):
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o644 << 16
        target.writestr(info, content)
manifest = {
    'source': SOURCE, 'baseline': source_manifest['baseline'],
    'archive': archive.name, 'archive_bytes': archive.stat().st_size,
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'payloads': [{'path': name, 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}
                 for name, content in sorted(payloads.items())],
}
(DEST / (NAME + '.manifest.json')).write_text(json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive) as retained:
    assert sorted(retained.namelist()) == sorted(payloads)
    for item in manifest['payloads']:
        content = retained.read(item['path'])
        assert len(content) == item['bytes'] and hashlib.sha256(content).hexdigest() == item['sha256']
print(json.dumps({'source': SOURCE, 'payloads': len(payloads), 'archive_bytes': manifest['archive_bytes'],
                  'archive_sha256': manifest['archive_sha256']}))
