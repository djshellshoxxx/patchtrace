"""Source-pinned bounded local R2 checks; every label must be new."""
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('/workspace/scratch/c7a9e8d98848/r2-evidence-retention')
QA = Path(__file__).resolve().parent
PYTHON = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
FILES = (
    'src/patchtrace/unified/fusion/arbiter.py', 'src/patchtrace/unified/read_text.py',
    'src/patchtrace/unified/registry.py', 'tests/test_unified_evidence_retention.py',
    'tests/test_unified_registry.py', 'docs/specs/unified-engine/02-data-model.md',
    'docs/specs/unified-engine/05-fusion-and-noise.md', 'docs/specs/unified-engine/07-ui-and-cli.md',
    'docs/modules.md',
)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True)


def hashes():
    return {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in FILES}


label, *arguments = sys.argv[1:]
clean = '--clean' in arguments
if clean:
    arguments.remove('--clean')
assert label.replace('-', '').isalnum()
assert not (QA / (label + '.log')).exists(), 'Do not replace a retained run'
status = git('status', '--porcelain')
if clean:
    assert status == '', status
env = dict(os.environ, PYTHONPATH=str(ROOT / 'src') + ':' + str(ROOT / 'tests') + ':' + str(QA),
           QT_QPA_PLATFORM='offscreen')
command = [PYTHON, '-m', 'pytest', '-q', *arguments, '--junitxml=' + str(QA / (label + '.xml'))]
context = {'head': git('rev-parse', 'HEAD').strip(), 'status': status, 'cwd': str(ROOT),
           'argv': command, 'environment': {k: env[k] for k in ('PYTHONPATH', 'QT_QPA_PLATFORM')},
           'sha256': hashes(), 'required_clean': clean}
(QA / (label + '-context.json')).write_text(json.dumps(context, indent=2) + '\n')
if status:
    (QA / (label + '-uncommitted.patch')).write_text(git('diff', '--binary', 'HEAD'))
started = time.monotonic()
with (QA / (label + '.log')).open('w') as output:
    result = subprocess.run(command, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=240)
receipt = {'returncode': result.returncode, 'elapsed_seconds': time.monotonic() - started,
           'status_after': git('status', '--porcelain'), 'sha256_after': hashes()}
(QA / (label + '-exit.json')).write_text(json.dumps(receipt, indent=2) + '\n')
assert receipt['sha256_after'] == context['sha256'], 'Source changed during the run'
if clean:
    assert receipt['status_after'] == '', receipt['status_after']
print(json.dumps({'label': label, 'head': context['head'], 'returncode': result.returncode,
                  'elapsed_seconds': receipt['elapsed_seconds']}))
print((QA / (label + '.log')).read_text()[-6000:])
raise SystemExit(result.returncode)
