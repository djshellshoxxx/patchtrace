"""Redirect only the frozen probe's observation destination; preserve its source and original receipts."""
from pathlib import Path

ORIGINAL = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch4/test_r2_product_surfaces_v3.py')
OUTPUT = Path(__file__).resolve().parent / 'current-product-surfaces'


def pytest_collection_modifyitems(items):
    OUTPUT.mkdir(exist_ok=True)
    for item in items:
        if Path(item.module.__file__).resolve() == ORIGINAL:
            item.module.EVIDENCE = OUTPUT
