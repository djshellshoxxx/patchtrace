"""Retain exact source spans and references for a read-only admission proposal."""
from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/c7a9e8d98848/security-residual-qa')
QA = Path(__file__).resolve().parent
SOURCE = '9ad2ec5cdbde85155fdca3cdd88804fd8b2e1a53'
APPROVED_PLAN = '8b376a7bf4cbe2603958b5c596619849d363d828'
CORE = '9740860928c7911e6fa975528db1f7fa5ca1940b'
ENV = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1')


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, env=ENV)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write_new(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data.encode() if isinstance(data, str) else data)


def write_json(path, value):
    write_new(path, json.dumps(value, indent=2) + '\n')


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert git('status', '--porcelain') == b''
loaded = json.loads((QA / 'current.imports.json').read_text())
assert loaded['source_commit'] == SOURCE and loaded['drift'] == []
paths = {item['relative_path'] for item in loaded['modules']}
paths.update({
    'src/patchtrace/project_cli.py', 'src/patchtrace/kbcorrelation/recovery.py',
    'docs/specs/core-held-inputs.md', 'docs/specs/architecture.md',
    'docs/specs/local-package-intake.md', 'docs/specs/cli-project-compare.md',
    'docs/plans/program-e/KB-integration-plan.md', 'docs/modules.md',
    'tests/test_creation_operation_checkpoint.py', 'tests/test_creation_replacement_refusal.py',
    'tests/test_creation_schema_refusal.py', 'tests/test_project_cli.py',
    'tests/test_kbc_recovery.py', 'tests/test_kbc_store.py', 'pyproject.toml',
})
available = {entry.decode() for entry in git('ls-tree', '-r', '--name-only', SOURCE).splitlines()}
missing = sorted(paths - available)
# The integration-plan path is captured under its real current tracked location.
if missing == ['docs/plans/program-e/KB-integration-plan.md']:
    paths.remove(missing[0])
    real = [p for p in available if p.endswith('/program-e/KB-integration-plan.md')]
    assert len(real) == 1, real
    paths.add(real[0])
elif missing:
    raise AssertionError(missing)

records = []
for relative in sorted(paths):
    data = git('show', f'{SOURCE}:{relative}')
    assert (ROOT / relative).read_bytes() == data
    target = Path('source') / SOURCE / relative
    write_new(QA / target, data)
    records.append({'commit': SOURCE, 'path': relative, 'snapshot': target.as_posix(),
                    'sha256': sha(data), 'bytes': len(data),
                    'git_blob': git('rev-parse', f'{SOURCE}:{relative}').decode().strip()})
plan_path = 'docs/plans/kb-held-reader-propagation-20261118.md'
plan = git('show', f'{APPROVED_PLAN}:{plan_path}')
plan_target = Path('references') / f'{APPROVED_PLAN}-kb-held-reader-propagation.md'
write_new(QA / plan_target, plan)
old = Path('/workspace/scratch/c7a9e8d98848/qa/pw02-kb-held-reader-design')
references = [{'commit': APPROVED_PLAN, 'path': plan_path, 'snapshot': plan_target.as_posix(),
               'bytes': len(plan), 'sha256': sha(plan),
               'git_blob': git('rev-parse', f'{APPROVED_PLAN}:{plan_path}').decode().strip()}]
for name in ('README.md', 'test_existing_admission_boundary_v2.py',
             'existing-admission-v2.command.json', 'existing-admission-v2.xml',
             'existing-admission-v2.exit.json', 'source-provenance.json'):
    data = (old / name).read_bytes()
    target = Path('references') / 'prior-held-reader-design' / name
    write_new(QA / target, data)
    references.append({'original': str(old / name), 'snapshot': target.as_posix(),
                       'bytes': len(data), 'sha256': sha(data)})

compare = []
for path in ('src/patchtrace/input_readers.py', 'src/patchtrace/ingestion.py',
             'src/patchtrace/service.py', 'src/patchtrace/persistence.py', 'docs/specs/core-held-inputs.md'):
    before = git('show', f'{CORE}:{path}')
    now = git('show', f'{SOURCE}:{path}')
    compare.append({'path': path, 'reviewed_core': CORE, 'current_source': SOURCE,
                    'core_sha256': sha(before), 'current_sha256': sha(now), 'equal': before == now})

selections = {
    'src/patchtrace/models.py': {'uid', 'Record', 'Artifact', 'ComparisonProject'},
    'src/patchtrace/service.py': {'_remove_owned', '_rollback_creation', 'ProjectService.__init__',
        'ProjectService.create', 'ProjectService.open', 'ProjectService.export_report', 'ProjectService.close'},
    'src/patchtrace/persistence.py': {'validate_project', '_creation_file', '_same_creation_file',
        '_empty_creation_database', '_abandoned_creation', 'creation_directory_available',
        'ProjectLock.__init__', 'ProjectLock.close', 'ProjectStore.__init__',
        'ProjectStore._verify_files', 'ProjectStore.save', 'ProjectStore.load', 'ProjectStore.close'},
    'src/patchtrace/kbcorrelation/wiring.py': {'RealProjectPort.__init__', 'RealProjectPort._directory',
        'RealProjectPort.create_project', 'RealProjectPort.open_project', 'RealProjectPort.put_row',
        'RealProjectPort.list_rows', '_project_factory', 'new_project_factory'},
    'src/patchtrace/kbcorrelation/store.py': {'AttachRequest', 'ProjectAttachment._begin',
        'ProjectAttachment._create', 'ProjectAttachment._after_create', 'ProjectAttachment._rows',
        'ProjectAttachment.resume'},
    'src/patchtrace/kbcorrelation/recovery.py': {'mark_interrupted', 'repair'},
    'src/patchtrace/kbcorrelation/service.py': {'KbService.import_pair', 'KbService.attach', 'KbService._ops_for'},
}
seams = []
for relative, requested in selections.items():
    text = git('show', f'{SOURCE}:{relative}').decode()
    lines = text.splitlines(keepends=True)
    found = set()

    def visit(body, prefix=''):
        for node in body:
            if not isinstance(node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                continue
            name = prefix + node.name
            if name in requested:
                found.add(name)
                first = min([node.lineno, *(item.lineno for item in node.decorator_list)])
                data = ''.join(lines[first - 1:node.end_lineno]).encode()
                seams.append({'path': relative, 'symbol': name, 'first_line': first,
                              'last_line': node.end_lineno, 'sha256': sha(data),
                              'signature': (f'{node.name}({ast.unparse(node.args)})'
                                            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
                                            else f'class {node.name}')})
            if isinstance(node, ast.ClassDef):
                visit(node.body, name + '.')

    visit(ast.parse(text).body)
    assert found == requested, (relative, sorted(requested - found))
write_json(QA / 'source-seams.json', {'source_commit': SOURCE, 'seams': seams,
    'initialization_note': 'ProjectStore has __init__; no separate initialize method exists at this source.'})
searches = []
for label, patterns in [
    ('open-and-readonly-load', ['ProjectService.open', 'recover_interrupted=False']),
    ('project-create-and-id', ['ProjectService.create', 'project_id=']),
    ('postcommit-kb-port', ['create_project(', 'put_row(', 'list_rows(']),
]:
    argv = ['grep', '-n']
    for pattern in patterns:
        argv += ['-e', pattern]
    argv += [SOURCE, '--', 'src']
    data = git(*argv)
    target = Path('caller-searches') / f'{label}.txt'
    write_new(QA / target, data)
    searches.append({'argv': ['git', *argv], 'snapshot': target.as_posix(), 'sha256': sha(data)})
write_json(QA / 'source-provenance.json', {
    'source_commit': SOURCE, 'source_tree': git('rev-parse', f'{SOURCE}^{{tree}}').decode().strip(),
    'worktree': str(ROOT), 'branch': 'codex/package-core-admission-design-20261118',
    'preserved_utf8_tip': git('rev-parse', 'codex/dependency-utf8-20261118').decode().strip(),
    'source_snapshots': records, 'references': references, 'reviewed_core_comparison': compare,
    'caller_searches': searches, 'repository_source_or_test_edits': False,
})
print(json.dumps({'snapshots': len(records), 'symbol_spans': len(seams),
                  'reviewed_core_equal': all(item['equal'] for item in compare), 'references': len(references)}, indent=2))
