"""Seal the immutable core design observations; no production mutation."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/c7a9e8d98848/security-residual-qa')
QA = Path(__file__).resolve().parent
SOURCE = '9ad2ec5cdbde85155fdca3cdd88804fd8b2e1a53'
NAME = 'pw02-core-admission-design-20261118'
PLAN = ROOT / 'docs/plans/package-core-admission-seams-20261118.md'
ENV = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, env=ENV)


def write_new(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data.encode() if isinstance(data, str) else data)


def write_json(path, value):
    write_new(path, json.dumps(value, indent=2) + '\n')


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert git('diff', '--name-only', SOURCE, '--', 'src', 'tests', 'tools', '.github') == b''
assert git('rev-parse', 'codex/dependency-utf8-20261118').decode().strip() == (
    '754e1b934f2a4ab0efaf94d7be39a5b8b390db90')
provenance = json.loads((QA / 'source-provenance.json').read_text())
assert provenance['source_commit'] == SOURCE
assert all(item['equal'] for item in provenance['reviewed_core_comparison'])
for entry in provenance['source_snapshots']:
    raw = git('show', f"{entry['commit']}:{entry['path']}")
    assert raw == (QA / entry['snapshot']).read_bytes()
    assert sha(raw) == entry['sha256'] and len(raw) == entry['bytes']
for entry in provenance['references']:
    raw = ((Path(entry['original']).read_bytes()) if 'original' in entry else
           git('show', f"{entry['commit']}:{entry['path']}"))
    assert raw == (QA / entry['snapshot']).read_bytes()
    assert sha(raw) == entry['sha256'] and len(raw) == entry['bytes']
command = json.loads((QA / 'current.command.json').read_text())
for entry in command['test_files']:
    assert sha(Path(entry['path']).read_bytes()) == entry['sha256']
outcome = json.loads((QA / 'current.exit.json').read_text())
assert outcome['source_commit'] == SOURCE and outcome['exit_code'] == 0
assert outcome['drift'] == [] and outcome['prohibited_attempts'] == []
root = ET.parse(QA / 'current.xml').getroot()
suites = list(root.iter('testsuite'))
counts = {key: sum(int(s.attrib[key]) for s in suites)
          for key in ('tests', 'failures', 'errors', 'skipped')}
assert counts == dict(tests=10, failures=0, errors=0, skipped=0)
write_new(QA / 'README.md', PLAN.read_bytes())
write_json(QA / 'verification.json', {
    'source_commit': SOURCE, 'source_tree': provenance['source_tree'],
    'repository_source_tests_tools_workflows_unchanged': True,
    'canonical_snapshots_verified': len(provenance['source_snapshots']),
    'reference_snapshots_verified': len(provenance['references']),
    'symbol_spans': len(json.loads((QA / 'source-seams.json').read_text())['seams']),
    'junit': counts, 'source_pinned_modules': outcome['source_pinned_modules'],
    'prohibited_attempts': [], 'source_drift': [],
    'proposal_sha256': sha(PLAN.read_bytes()), 'test_files_unchanged': command['test_files'],
    'implementation_acceptance': False, 'native_or_package_route_acceptance': False,
})
files = sorted(p for p in QA.rglob('*') if p.is_file())
entries = [{'path': p.relative_to(QA).as_posix(), 'bytes': p.stat().st_size,
            'sha256': sha(p.read_bytes())} for p in files]
destination = ROOT / 'docs/qa'
archive = destination / f'{NAME}.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
    for path, entry in zip(files, entries, strict=True):
        info = zipfile.ZipInfo(entry['path'], date_time=(2026, 11, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        zipped.writestr(info, path.read_bytes())
with zipfile.ZipFile(archive) as zipped:
    assert zipped.namelist() == [item['path'] for item in entries]
    for entry in entries:
        raw = zipped.read(entry['path'])
        assert len(raw) == entry['bytes'] and sha(raw) == entry['sha256']
manifest = {'schema': 'qa-evidence-manifest/1', 'source_commit': SOURCE,
            'archive': archive.name, 'archive_bytes': archive.stat().st_size,
            'archive_sha256': sha(archive.read_bytes()), 'payload_count': len(entries),
            'payload_bytes': sum(item['bytes'] for item in entries), 'entries': entries}
write_json(destination / f'{NAME}.manifest.json', manifest)
report = f'''# Core package-admission design observations — 2026-11-18

This is a **read-only proposal**, not an implemented package route. Frozen source
`{SOURCE}` (tree `{provenance['source_tree']}`) remains unchanged in production,
tests, tooling and workflows. The five relevant core files equal reviewed source
`9740860928c7911e6fa975528db1f7fa5ca1940b`.

The [complete proposal](../plans/package-core-admission-seams-20261118.md) recommends
only an optional preallocated project ID on existing create, and explicit
recovery/checkpoint forwarding through existing open/load. It identifies all
durable facade/held-origin/provenance prerequisites that remain unimplemented.
Root must review the proposal before any source work; meaningful failing
integration controls must precede that future implementation.

## Current observations

Ten bounded controls pass, zero skips, in 0.43 seconds, with 60 exact-source
project/test-support imports and no drift. Eight new authored PE/real SQLite
controls are joined by the unchanged two earlier public KB controls. No network,
child process, native worker, target or compiler was executed. Counts describe
current behavior, not proposed capability acceptance.

The existing model/store can commit a caller-chosen ID without schema changes.
Two projects can share an ordered binary pair but have different IDs; orientation
can change under one ID. Therefore the later verifier must compare the actual
committed ID and ordered hashes before adoption or publication, while retaining
existing create refusal and destination ownership checks.

Explicit `load(recover_interrupted=False)` preserves queued state, database bytes
and history in the authored healthy case. `open(maintenance=False)` intentionally
retains startup recovery and adds a history row. This flag is not an application
read-only identity check. The lock holder record remains the documented exception
to unchanged project bytes; SQLite still opens through the current mode=rw path.

Fresh reopen after held creation performs 12 project-copy reads / 2,316 bytes
without the original callback in the authored example. The proposed per-call
checkpoint reaches existing full hash/PE/cache verification. It must not become
a persisted callback, reset the original operation, consume extraction output,
invoke creation rollback or recover queued/running records during reconciliation.

Save-return and constructor exceptions after a real commit both retain the
actual project and verified copies. The unchanged public fault still leaves a
committed project while its attachment says intent/project_id=None; generic
reader-less recovery then tries the original sources and records interruption.
That behavior is retained explicitly and is not qualified as safe package
recovery. Core preallocation alone does not supply a durable lease marker,
package lineage, or guarded metadata reconciliation.

## Exact evidence and limits

`source-provenance.json` contains 74 canonical Git snapshots and seven exact
reference snapshots, including the approved KB propagation plan from
`8b376a7bf4cbe2603958b5c596619849d363d828` (absent from this frozen base).
`source-seams.json` binds 43 complete source spans/signatures. Three full caller
searches, exact argv/environment/import manifests, current observations and the
original public probe/source receipts are retained. No original probe changed.

New current-observation probe SHA-256:
`{command['test_files'][0]['sha256']}`.
Unchanged prior public probe SHA-256:
`{command['test_files'][1]['sha256']}`.

Portable POSIX observations do not qualify native sharing, FDI/process handoff,
package exposure, durable recovery, arbitrary namespace resistance or frozen
acceptance. The core remains Qt-free/synchronous with caller-thread SQLite.
The plan explicitly distinguishes known commit, unknown result and missing
association, and never authorizes deleting or adopting a foreign project.

## Sealed packet

The [archive]({NAME}.zip) contains {len(entries)} verified payloads
({manifest['payload_bytes']:,} uncompressed bytes; {manifest['archive_bytes']:,} ZIP bytes).
Archive SHA-256: `{manifest['archive_sha256']}`.
The [manifest]({NAME}.manifest.json) records every payload hash and size.
Raw observations remain in `qa/pw02-core-admission-design`.
'''
write_new(destination / f'{NAME}.md', report)
print(json.dumps({key: value for key, value in manifest.items() if key != 'entries'}, indent=2))
