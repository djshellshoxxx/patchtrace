# Independent neutral core review at b85a0cf7

## Disposition

One bounded contract mismatch remains at exact source
`b85a0cf7bf135e9431677737613000707553b192`: `inspect_artifact` can replace an active
`InputReadError('cancelled')` with a `PermissionError` from failed owned temporary
file cleanup. The original operation category/object is therefore lost. The
operation still refuses, the temporary file remains, and no immutable artifact
is admitted in this control. This is error precedence and retained-cleanup
evidence, not a demonstrated path fallback, source substitution or project
admission. The original core author owns the narrow repair assigned by root.

Independent controls plus the 38 authored controls produced **1 failure and 51
passes**, no skips, in 0.76 seconds. Source ownership checks found no drift among
loaded PatchTrace modules; the network/process audit recorded no attempts.
Original files remain unchanged for replay. This review made no production,
specification or authored-test edits, and created no additional worktree.

## Scope and source

The review inspected all four production deltas and their relevant full-context
paths: `input_readers.py`, `ingestion.py`, `ProjectService.create` and its existing
creation rollback, plus `ProjectStore._verify_files/save` and its transaction/
verification-cache behavior. It also read the complete core specification, new
test helper/controls, and the author's raw qualification/runner correction.

| Role | Commit |
| --- | --- |
| Approved base | `068513a72e8a1412ce3960d3024c462d68d51376` |
| Specification/tests | `f3456f92681168f7c93a85c40d13f6903cf94de8` |
| Reviewed production | `b85a0cf7bf135e9431677737613000707553b192` |
| Author's stable QA tip during execution | `c791ed4e8a9019541c6789f3cd025d963b3ae8ec` |

The QA tip only clarifies that neutral InputReadError reasons propagate while
unrelated storage errors keep their existing mapping; production/test bytes
remain those of b85. The original specification already required original
callback type/reason propagation. Both forms and their exact difference are
captured. The preexisting unguarded cleanup statement is exposed by the new
neutral operation-stop contract; the review does not label it a new arbitrary
file deletion defect.

## Independent controls

The external file `test_core_reader_boundary.py` is immutable with SHA-256
`b7b5ad118cfd8b4b15fd6e1276d3dff0136c21f7b8df555b21db386fda49c1ed`.
It adds fourteen controls with authored synthetic PE bytes, retained ordinary
POSIX descriptors and real SQLite. It does not exercise or simulate Windows
sharing qualification.

Eight controls deny a held provider at check, open, read and context exit through
both `inspect_artifact` and `validate_pe`. Selected paths remain readable, but
guarded path-open seams record no fallback attempt; the exact neutral error and
original descriptor survive. Two public `ProjectService.create` controls fail
the older/newer held source independently, preserving a foreign file and
removing only newly owned project objects. A read-observation control records
actual bytes returned by provider and project-owned streams and verifies that
their sum equals the shared positive checkpoint ledger exactly, with no double
charge. Another control cancels immediately before a real existing-project
COMMIT and verifies both snapshot and history remain unchanged after ROLLBACK.
A service-constructor failure after the first commit leaves the committed
project readable. These thirteen independent controls pass.

The failing fourteenth control raises the same neutral cancellation object
during a held read and injects a PermissionError only for removal of the owned
`.input-*` temporary. The traceback shows the active neutral cancellation,
followed by `ingestion.py`'s final `stage.unlink(missing_ok=True)` replacing it.
The test expects the original InputReadError object, retained refused temp and
no published `.bin`; it fails on the exception type before those final outcome
assertions. No assertions were edited after observing the failure. The cleanup
failure is an authored I/O failure injection, not an observed native Windows
cleanup failure.

## Reproduction and receipts

```text
PYTHONDONTWRITEBYTECODE=1 /workspace/scratch/3a6632a6e5ff/venv/bin/python \
  /workspace/scratch/c7a9e8d98848/qa/core-held-inputs-independent/run_review.py initial
```

The runner refuses overwrites. It pins the exact worktree source and repository
root, uses a fresh system temporary directory outside Git, and denies sockets,
subprocesses, fork/exec and shell commands during pytest. Its one pre-test Git
tree read is local and replacement-disabled with file-only protocol policy.
Loaded source bytes are checked against the canonical Git blob identities and
also recorded with SHA-256. `initial.log`, `initial.xml` and
`initial-receipt.json` retain the result, argv, interpreter, source hashes and
audit attempts. The external controls and all original authored tests execute
in one 52-case invocation; the already-verified 19-file author gate was not
repeated unnecessarily.

`manifest.json` records all archive members and hashes. The archive includes the
external probe/runner, raw results, this report and exact source/spec/test
snapshots. Native reader identity/name binding, Windows handle/share-mode
behavior, package worker composition, KB propagation, frozen journeys and
durable provenance remain outside this portable review. No remote writes,
package installs, target execution, native analyzer, release or dispatch ran.
