"""A retained WAL schema is refused before SQLite can touch the database companions."""
import sqlite3

import pytest

from patchtrace.persistence import ProjectStore
from patchtrace.sample import synthetic_pe
from patchtrace.service import ProjectService


def test_retained_wal_view_survives_creation_refusal_without_a_sqlite_read(tmp_path):
    root = tmp_path / 'incomplete'
    ProjectStore(root, create=True).close()
    path = root / 'project.sqlite3'
    pair = tmp_path / 'older.dll', tmp_path / 'newer.dll'
    for index, source in enumerate(pair):
        source.write_bytes(synthetic_pe(index))
    writer = sqlite3.connect(path)
    try:
        assert writer.execute('PRAGMA journal_mode=WAL').fetchone()[0] == 'wal'
        writer.execute('PRAGMA wal_autocheckpoint=0')
        writer.execute('CREATE VIEW retained_operator_note AS SELECT 17 AS marker')
        writer.commit()
        companions = [path, path.with_name(path.name + '-wal'), path.with_name(path.name + '-shm')]
        before = {item: item.read_bytes() for item in companions}
        with pytest.raises(ValueError, match='project database already exists'):
            with ProjectService.create(*pair, 'must retain WAL state', root):
                pass
        assert {item: item.read_bytes() for item in companions} == before
        assert not (root / 'artifacts').exists()
        assert writer.execute('SELECT marker FROM retained_operator_note').fetchone() == (17,)
    finally:
        writer.close()
