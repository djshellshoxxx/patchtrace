def _database(path, cancel):
    size = path.stat().st_size
    if not 0 < size <= MAX_RETRY_DATABASE_BYTES:
        raise ValueError('PT-RETRY: incomplete database must be within 1 MiB')
    connection = sqlite3.connect(path.as_uri() + '?mode=ro&immutable=1', uri=True, timeout=0)
    steps = 0
    def progress():
        nonlocal steps
        steps += 1000
        return int(steps > 100_000 or (cancel is not None and cancel.is_set()))
    try:
        connection.set_progress_handler(progress, 1000)
        connection.setlimit(sqlite3.SQLITE_LIMIT_LENGTH, MAX_RETRY_DATABASE_BYTES)
        connection.setlimit(sqlite3.SQLITE_LIMIT_SQL_LENGTH, 4096)
        if connection.execute('PRAGMA user_version').fetchone()[0] != 1:
            raise ValueError('PT-RETRY: database version is not an incomplete current project')
        schema = connection.execute('SELECT type,name,sql FROM sqlite_schema').fetchall()
        expected = {('table', 'current_snapshot', _CURRENT_SNAPSHOT_SQL),
                    ('table', 'history', _HISTORY_SQL),
                    ('table', 'sqlite_sequence', 'CREATE TABLE sqlite_sequence(name,seq)')}
        if len(schema) != len(expected) or set(schema) != expected:
            raise ValueError('PT-RETRY: database schema is not an incomplete project')
        if connection.execute('PRAGMA quick_check').fetchall() != [('ok',)]:
            raise ValueError('PT-RETRY: database integrity check failed')
        for table in ('current_snapshot', 'history', 'sqlite_sequence'):
            if connection.execute(f'SELECT EXISTS(SELECT 1 FROM {table})').fetchone()[0]:
                raise ValueError('PT-RETRY: database already contains project data')
        _check_cancel(cancel)
    except sqlite3.Error as exc:
        _check_cancel(cancel)
        raise ValueError('PT-RETRY: incomplete database cannot be validated') from exc
    finally:
        connection.close()
