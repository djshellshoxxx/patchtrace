"""Seal the read-only design review and its unchanged bounded observation."""
from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

QA = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/c7a9e8d98848/security-residual-qa')
AUTHOR = QA.parent / 'package-durable-admission-design'
SOURCE = '195e04af27f7a724c6a2037363b7fe68df418a6b'
DESIGN = 'efe68b18654459e704d358d64423fbc1820afc0a'
CORE = '63ebc42746fbfbded311084288a339f26ed08d8c'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO,
                                   env=dict(os.environ, GIT_NO_REPLACE_OBJECTS='1'))


def write(name, value):
    with (QA / name).open('x') as output:
        json.dump(value, output, indent=2)
        output.write('\n')


files = {
    'src/patchtrace/kbcorrelation/store.py': ['WorkspaceStore', 'ProjectAttachment'],
    'src/patchtrace/kbcorrelation/service.py': ['KbService'],
    'src/patchtrace/kbcorrelation/wiring.py': ['RealProjectPort'],
    'src/patchtrace/kbcorrelation/recovery.py': ['mark_interrupted', 'repair'],
    'src/patchtrace/kbcorrelation/inventory_store.py': ['_budget', '_add', 'referenced_raw_hashes'],
    'src/patchtrace/kbcorrelation/workflow.py': ['reduce'],
    'src/patchtrace/kbcorrelation/contracts.py': ['Record', 'domain_id', 'InvestigationRevision'],
    'src/patchtrace/kbcorrelation/saved_scope.py': [],
    'src/patchtrace/enrichment/storage.py': ['Guard', 'Entry', 'EnrichmentStore'],
    'src/patchtrace/acquisition/package_budget.py': ['PackageBudget'],
    'src/patchtrace/acquisition/package_contracts.py': ['PackageLimits', 'PackageInventory', 'PackageUsage'],
    'src/patchtrace/input_readers.py': [],
    'src/patchtrace/owned_publication.py': ['directory_anchor', 'verify_anchor', 'publish_bytes'],
    'src/patchtrace/service.py': ['ProjectService'],
    'src/patchtrace/persistence.py': ['ProjectStore'],
}
records, spans = [], []
for role, commit, selected in (
    ('frozen', SOURCE, files),
    ('design', DESIGN, {'docs/plans/package-durable-admission-20261118.md': [],
                        'docs/plans/package-durable-admission-20261118.json': []}),
    ('later-core', CORE, {'src/patchtrace/service.py': ['ProjectService'],
                          'src/patchtrace/persistence.py': ['ProjectStore']}),
):
    for relative, symbols in selected.items():
        data = git('show', f'{commit}:{relative}')
        destination = QA / 'source' / role / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open('xb') as output:
            output.write(data)
        record = {'role': role, 'source': commit, 'path': relative, 'snapshot': str(destination.relative_to(QA)),
                  'git_blob': git('rev-parse', f'{commit}:{relative}').decode().strip(),
                  'sha256': sha(data), 'bytes': len(data)}
        records.append(record)
        if symbols:
            tree = ast.parse(data)
            for node in tree.body:
                if isinstance(node, (ast.ClassDef, ast.FunctionDef)) and node.name in symbols:
                    spans.append({'source': commit, 'path': relative, 'symbol': node.name,
                                  'start': node.lineno, 'end': node.end_lineno})
                    if isinstance(node, ast.ClassDef):
                        for method in node.body:
                            if isinstance(method, ast.FunctionDef):
                                spans.append({'source': commit, 'path': relative, 'symbol': f'{node.name}.{method.name}',
                                              'start': method.lineno, 'end': method.end_lineno})
write('source-manifest.json', records)
write('source-spans.json', spans)

provenance = json.loads((AUTHOR / 'source-provenance.json').read_text())
for record in provenance['git_snapshots']:
    data = git('show', f"{record['source']}:{record['path']}")
    assert sha(data) == record['sha256']
    assert (AUTHOR / record['stored']).read_bytes() == data
author_records = []
for name in ('test_workspace_version_observation.py', 'workspace-version.command.json', 'workspace-version.log',
             'workspace-version.xml', 'workspace-version.imports.json', 'workspace-version.observations.json',
             'source-provenance.json', 'source-seams.json', 'interpretation-corrections.json'):
    data = (AUTHOR / name).read_bytes()
    destination = QA / 'author-reference' / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    author_records.append({'path': str(AUTHOR / name), 'copy': str(destination.relative_to(QA)), 'sha256': sha(data)})
write('author-reference.json', author_records)

command = json.loads((QA / 'capture-red.command.json').read_text())
receipt = json.loads((QA / 'capture-red.exit.json').read_text())
imports = json.loads((QA / 'capture-red.imports.json').read_text())
assert command['source_commit'] == receipt['source_commit'] == imports['source_commit'] == SOURCE
assert command['design_commit'] == receipt['design_commit'] == DESIGN
assert receipt['pytest_exit'] == 1 and not receipt['drift'] and not receipt['prohibited_attempts']
assert sha((QA / 'test_capture_initialization_boundary.py').read_bytes()) == command['test_sha256']
for item in imports['modules']:
    data = git('show', f"{SOURCE}:{item['relative_path']}")
    assert sha(data) == item['sha256']
    assert item['git_blob'] == item['expected_git_blob']
cases = list(ET.parse(QA / 'capture-red.xml').getroot().iter('testcase'))
counts = {'tests': len(cases), 'failures': sum(case.find('failure') is not None for case in cases),
          'errors': sum(case.find('error') is not None for case in cases),
          'skipped': sum(case.find('skipped') is not None for case in cases)}
assert counts == {'tests': 4, 'failures': 2, 'errors': 0, 'skipped': 0}
write('review.json', {
    'design': DESIGN, 'frozen_source': SOURCE, 'later_core_dependency': CORE,
    'decision': 'One confirmed non-initializing-capture prerequisite; no second confirmed blocker.',
    'source_snapshots': len(records), 'source_spans': len(spans),
    'author_canonical_snapshots_verified': len(provenance['git_snapshots']),
    'author_observations_not_rerun': True, 'independent_probe': counts,
    'independent_pinned_imports': len(imports['modules']), 'probe_sha256': command['test_sha256'],
    'no_product_or_repository_mutations': True, 'no_native_or_package_acceptance': True,
    'required_before_storage_slice': 'Actual-connection existing/non-initializing WorkspaceStore mode before _create/WAL; default compatibility preserved.',
})
payloads = {path.relative_to(QA).as_posix(): path.read_bytes() for path in sorted(QA.rglob('*'))
            if path.is_file() and path.name not in {'evidence.zip', 'manifest.json', 'seal-result.json'}}
archive = QA / 'evidence.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for name, data in sorted(payloads.items()):
        info = zipfile.ZipInfo(name, (2026, 11, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        output.writestr(info, data)
manifest = {'design': DESIGN, 'source': SOURCE, 'archive_sha256': sha(archive.read_bytes()),
            'archive_bytes': archive.stat().st_size, 'payload_count': len(payloads),
            'uncompressed_bytes': sum(map(len, payloads.values())),
            'payloads': [{'path': name, 'sha256': sha(data), 'bytes': len(data)} for name, data in sorted(payloads.items())]}
write('manifest.json', manifest)
with zipfile.ZipFile(archive) as output:
    assert output.testzip() is None and len(output.namelist()) == len(payloads)
    for item in manifest['payloads']:
        data = output.read(item['path'])
        assert sha(data) == item['sha256'] and len(data) == item['bytes']
print(json.dumps({key: manifest[key] for key in ('design', 'source', 'archive_sha256', 'archive_bytes', 'payload_count', 'uncompressed_bytes')}))
