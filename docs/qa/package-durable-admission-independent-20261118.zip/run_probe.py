"""Pin the frozen design's current source; no product changes or package qualification."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import ssl
import stat
import subprocess
import sys
import tempfile
import time

REPO = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
QA = Path(__file__).resolve().parent
SOURCE = '195e04af27f7a724c6a2037363b7fe68df418a6b'
DESIGN = 'efe68b18654459e704d358d64423fbc1820afc0a'
TEST = QA / 'test_capture_initialization_boundary.py'
LABEL = 'capture-red'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO,
                                   env=dict(os.environ, GIT_NO_REPLACE_OBJECTS='1'))


head = git('rev-parse', 'HEAD').decode().strip()
assert not git('diff', '--name-only', SOURCE, head, '--', 'src', 'tests', 'tools', 'pyproject.toml')
assert not git('diff', '--name-only', 'HEAD', '--', 'src', 'tests', 'tools', 'pyproject.toml')
blobs = {}
for entry in git('ls-tree', '-r', '-z', SOURCE, 'src').split(b'\0'):
    if entry:
        meta, name = entry.split(b'\t', 1)
        blobs[name.decode()] = meta.split()[2].decode()
sys.path[:0] = [str(REPO / 'src'), str(QA)]
os.environ.update(PYTHONPATH=str(REPO / 'src'), PYTHONDONTWRITEBYTECODE='1', QT_QPA_PLATFORM='offscreen',
                  PACKAGE_CAPTURE_REVIEW_OUTPUT=str(QA / f'{LABEL}-observations'))
import pytest

attempts = []


def audit(event, args):
    if event in {'socket.__new__', 'socket.connect', 'subprocess.Popen', 'os.system', 'os.fork', 'os.posix_spawn'}:
        attempts.append(event)
        raise AssertionError('read-only capture review prohibits network and children')


temporary = Path(tempfile.mkdtemp(prefix='package-capture-independent-'))
arguments = ['-q', '-p', 'no:cacheprovider', '--confcutdir=' + str(QA), str(TEST),
             '--basetemp=' + str(temporary / 'pytest'), '--junitxml=' + str(QA / f'{LABEL}.xml')]
command = {'source_commit': SOURCE, 'design_commit': DESIGN, 'checkout_head': head, 'cwd': str(REPO),
           'argv': [sys.executable, str(Path(__file__).resolve())], 'pytest_arguments': arguments,
           'test_sha256': hashlib.sha256(TEST.read_bytes()).hexdigest(), 'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'environment': {name: os.environ[name] for name in ('PYTHONPATH', 'PYTHONDONTWRITEBYTECODE',
                                                             'QT_QPA_PLATFORM', 'PACKAGE_CAPTURE_REVIEW_OUTPUT')}}
with (QA / f'{LABEL}.command.json').open('x') as output:
    json.dump(command, output, indent=2)
    output.write('\n')
sys.addaudithook(audit)
start = time.monotonic()
result = int(pytest.main(arguments))
modules, drift = [], []
for name, module in sorted(sys.modules.items()):
    if not name.startswith('patchtrace') or not getattr(module, '__file__', None):
        continue
    path = Path(module.__file__).resolve()
    data = path.read_bytes()
    entry = {'module': name, 'path': str(path), 'sha256': hashlib.sha256(data).hexdigest()}
    if not path.is_relative_to(REPO):
        drift.append(name)
    else:
        relative = path.relative_to(REPO).as_posix()
        blob = hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()
        entry.update(relative_path=relative, git_blob=blob, expected_git_blob=blobs.get(relative))
        if blob != blobs.get(relative):
            drift.append(name)
    modules.append(entry)
assert hashlib.sha256(TEST.read_bytes()).hexdigest() == command['test_sha256']
with (QA / f'{LABEL}.imports.json').open('x') as output:
    json.dump({'source_commit': SOURCE, 'modules': modules, 'drift': drift}, output, indent=2)
    output.write('\n')
allocated = sum(item.stat().st_blocks * 512 for item in temporary.rglob('*')
                if stat.S_ISREG(item.lstat().st_mode))
exit_code = result if not drift and not attempts else 1
if exit_code == 0:
    shutil.rmtree(temporary)
receipt = {'source_commit': SOURCE, 'design_commit': DESIGN, 'pytest_exit': result, 'exit_code': exit_code,
           'seconds': time.monotonic() - start, 'pinned_modules': len(modules), 'drift': drift,
           'prohibited_attempts': attempts, 'temporary_directory': str(temporary),
           'temporary_allocated_bytes': allocated, 'temporary_removed': exit_code == 0}
with (QA / f'{LABEL}.exit.json').open('x') as output:
    json.dump(receipt, output, indent=2)
    output.write('\n')
raise SystemExit(exit_code)
