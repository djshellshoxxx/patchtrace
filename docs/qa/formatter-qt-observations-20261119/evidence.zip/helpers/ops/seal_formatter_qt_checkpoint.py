"""Seal exact formatter observations and final old-head Qt evidence; no test run."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = REPO / 'docs/qa/formatter-qt-observations-20261119'
SOURCE = '16c35e1fb1a4dd54b2c2c0cb2033c8160ee99347'
SPEC = 'fdc1f606dd0b8a3ce94ae2db94f4fb6984a02b69'
CHECKPOINT = '29192f7837ebdb268d5c47e0a2536c67148cbe9f'
OLD_REMOTE = '771e5a775f5bf60a8d9094232b51dcdbb47d6389'
OLD_LOCAL = '361dd495a7e050121f2b3cae4e7678faad7fee35'
MAIN = '9c411ca3d7b47f950be5f0c6f01b3c54184554c6'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read_json(path):
    return json.loads(path.read_bytes())


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('status', '--porcelain')
assert not git('diff', '--name-only', '1a9942a5', SOURCE, '--', 'src', 'tools', '.github')
previous = REPO / 'docs/qa/admission-diagnostics-integration-20261119/evidence.zip'
assert sha(previous.read_bytes()) == 'ab11b8c014d5fdf0cfe94b2e29f661bd20974019f7c4f9a91151b7593dce4ece'
f = ROOT / 'qa/formatter-predicate-observations'
q = ROOT / 'qa/hosted-pr316-771e-qt-final'
receipt, command, lint = (read_json(f / p) for p in ['exit.json', 'command.json', 'lint.json'])
assert receipt['source'] == command['source'] == lint['source'] == SOURCE
assert receipt['junit'] == dict(tests=9, failures=0, errors=0, skipped=0)
assert receipt['exit'] == lint['exit'] == 0 and receipt['canonical_imports'] == 40
assert receipt['original_windows_failure_resolved'] is False
cases = list(ET.parse(f / 'result.xml').getroot().iter('testcase'))
assert len(cases) == 9 and all(not any(c.find(k) is not None for k in ['failure', 'error', 'skipped']) for c in cases)
imports = read_json(f / 'collection.json')['final_sources']
assert len(imports) == 40
for row in imports.values():
    path = Path(row['path'])
    rel = path.relative_to(REPO).as_posix()
    assert row['sha256'] == sha(path.read_bytes()) == sha(git('show', SOURCE + ':' + rel))
guard = read_json(f / 'offline-guard.json')
assert guard['inherited_socket_descriptors'] == []
assert guard['network_audit_event_counts'] == {} and guard['process_audit_count'] == 7
assert guard['network_filter']['seccomp_load_result'] == 0
review = (f / 'independent-review.md').read_text()
assert SOURCE in review and SPEC in review and len(review) > 400
a, api = read_json(q / 'analysis.json'), read_json(q / 'api-projection.json')
assert a['head'] == OLD_REMOTE and a['local_equal_tree_source'] == OLD_LOCAL
assert a['tree'] == git('rev-parse', OLD_LOCAL + '^{tree}').decode().strip()
assert a['gui_file_count'] == 82 and a['workflow_job_timeout_minutes'] == 120
assert a['new_tests_or_native_execution'] is False
assert len(api['checks']) == 48
assert Counter((r['status'], r['conclusion']) for r in api['checks']) == {
    ('completed', 'success'): 34, ('completed', 'failure'): 5,
    ('completed', 'skipped'): 7, ('completed', 'cancelled'): 2}
jobs = {r['id']: r for r in api['jobs']['jobs']}
assert {r['job_id'] for r in a['jobs']} == {135175350753, 135175350919}
for row in a['jobs']:
    raw = (q / ('job-' + str(row['job_id']) + '.log')).read_bytes()
    job = jobs[row['job_id']]
    assert sha(raw) == row['sha256'] and len(raw) == row['bytes']
    assert job['head_sha'] == OLD_REMOTE and job['run_id'] == 44409973351
    assert job['conclusion'] == row['conclusion'] == 'cancelled'
    assert row['complete_pytest_summary_present'] is False
for row in a['source_files']:
    raw = (q / 'source' / row['path']).read_bytes()
    assert sha(raw) == row['sha256']
    assert raw == git('show', OLD_LOCAL + ':' + row['path']) == git('show', SOURCE + ':' + row['path'])

payloads = {}
for label, directory in [('formatter', f), ('qt-final', q)]:
    for path in sorted(directory.rglob('*')):
        if path.is_file():
            payloads[label + '/' + path.relative_to(directory).as_posix()] = path.read_bytes()
for name in ['ops/run_formatter_predicate_observation_gate.py',
             'ops/analyze_771e_qt_termination.py', 'ops/seal_formatter_qt_checkpoint.py',
             'ops/continuation_offline_pytest.py', 'ops/project_and_tools_receipt.py',
             'qa/full-batch-path-recheck/offline_replay.py']:
    payloads['helpers/' + name] = (ROOT / name).read_bytes()
for ref in [CHECKPOINT, SPEC, SOURCE]:
    payloads['history/' + ref + '.commit'] = git('cat-file', 'commit', ref)
for label, ref, names in [
    ('before', CHECKPOINT, ['tests/test_windows_network_diagnostics.py']),
    ('after', SOURCE, ['tests/test_windows_network_diagnostics.py', 'tools/windows_network/common.h',
                       'docs/specs/windows-bindiff-network-acceptance.md'])]:
    for name in names:
        payloads['source/' + label + '/' + name] = git('show', ref + ':' + name)
payloads['source/formatter.patch'] = git('diff', CHECKPOINT, SOURCE, '--', 'tests/test_windows_network_diagnostics.py')
verification = dict(checked_utc=datetime.now(timezone.utc).isoformat(), source=SOURCE,
                    tree=git('rev-parse', SOURCE + '^{tree}').decode().strip(),
                    previous_checkpoint=CHECKPOINT, main_last_verified=MAIN,
                    original_qt_remote_head=OLD_REMOTE, formatter_junit=receipt['junit'],
                    canonical_imports=40, authored_process_audit_events=7,
                    production_tools_workflow_unchanged_since_combined_gate=True,
                    independent_static_review_retained=True, original_windows_failure_resolved=False,
                    qt_complete_acceptance=False, release_authorized=False)
payloads['verification.json'] = (json.dumps(verification, indent=2) + '\n').encode()
rows = [dict(path=name, bytes=len(raw), sha256=sha(raw)) for name, raw in sorted(payloads.items())]
manifest = dict(schema='patchtrace-formatter-qt-evidence/1', source=SOURCE, payloads=rows)
manifest_raw = (json.dumps(manifest, indent=2) + '\n').encode()
OUT.mkdir(exist_ok=False)
with zipfile.ZipFile(OUT / 'evidence.zip', 'x', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, raw in sorted(payloads.items()):
        z.writestr(name, raw)
    z.writestr('manifest.json', manifest_raw)
with zipfile.ZipFile(OUT / 'evidence.zip') as z:
    assert z.testzip() is None and len(z.namelist()) == len(payloads) + 1
    for row in rows:
        raw = z.read(row['path'])
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
archive = (OUT / 'evidence.zip').read_bytes()
readme = f'''# Formatter observations and completed Qt evidence — 2026-11-19

This checkpoint records a narrow diagnostic improvement at `{SOURCE}` and the
final outcomes of the earlier published `{OLD_REMOTE}` Qt jobs. Main was last
verified at `{MAIN}`. PR #304, #307 and #316 remain open and unmerged at the
preceding API checkpoint. No release, tag, deployment or manual dispatch occurs.

## Formatter result and preserved failure

Spec `{SPEC}` precedes source `{SOURCE}`. The authored C harness now records
`pt_diag_count` and one captured `ferror(stderr)` value if its original success
predicate fails. It still requires exactly 16 attempts and a nonzero stream error;
failure still returns 4. The passing path still emits no stdout. The fixed numeric
failure record is bounded below 128 bytes, and pytest retains at most 512 bytes
from each stream in its assertion message. No extra write to the failed stream,
stream-error clearing, fake sink or production formatter change is introduced.
The original Python assertion condition and every other test AST are preserved.

The reviewed file passes **9 tests, zero failures/errors/skips**, in 0.49 seconds
of pytest time (1.101 seconds for the outer recorder) at the exact source above.
All **40 project/tool imports** match Git and disk. The inherited offline filter
loads; there are no inherited sockets or network audit events. Seven process
audit events cover the reviewed authored compiler/helper scope. Changed-file Ruff
passes. The independent static review, complete commands, original XML/log,
collection, filter and source-equivalence recorder are retained in `evidence.zip`.

The actual old Windows W51 result remains exit 4 with empty streams. Neither
individual predicate value was present in that receipt. These nine portable
passes do not establish the Windows cause or a fix. The previous **2,043-pass**
combined gate belongs to source `1a9942a5c63ba707e8678cb2f6dcd1dc39c4afd2`;
the two counts are separate observations, not an additive total. Production,
tools and workflow bytes have not changed since that gate. The retained normal
lint success and strict **80 unchanged findings** remain the preceding source
observations; no security waiver or suppression is added.

## Final old-head Qt outcomes

| Job | Repetition scope | Final result | Completed UTC | Job elapsed |
| --- | --- | --- | --- | --- |
| 135175350753 | Windows, all selected files, five repeats | Cancelled; no full passing summary | 2026-11-19 00:19:44 | 7,208 s |
| 135175350919 | Ubuntu, shard 3 of 4, twenty repeats | Cancelled; no full passing summary | 2026-11-19 00:19:53 | 7,216 s |

Both belong to run 44409973351, remote head `{OLD_REMOTE}`, merge preview
`ac6632ad6de486ba16343f0eeb4a2b5a446e4ac1`, tree
`ddf151c6ff8fb3f70b74378525fe1d8d5c9050e3`. Equal-tree local source
`{OLD_LOCAL}` supplies the verified runner/workflow snapshots. Both files remain
byte-identical at the newer formatter source. The runner selects 82 GUI files,
sorts and shards them, and repeats them in one pytest session. Its outer workflow
job timeout is 120 minutes. The logs end with cancellation; the annotation lookup
was unavailable through the connector and its two errors are preserved. The
specific cancellation cause and any slow-test cause are not inferred.

All **48** old-head checks are now completed: **34 success, 5 failure, 7 skipped,
2 cancelled**. The two cancelled Qt jobs are unverified, and dependent Linux
package/smoke/release checks are skipped. The earlier 00:18:02 pending snapshot
is retained unchanged as a historical observation. There was no cancellation
request from this work and no manual workflow dispatch.

Same-tree full-suite JUnit timings are retained as diagnostic context: 2,120
Windows GUI cases total 2,246.171 seconds; multiplying that separate session's
case times by five gives 187.18 minutes. The four Linux shards' analogous
arithmetic totals are 72.66, 81.79, 70.17 and 47.21 minutes for twenty repeats.
These are **not predictions, measured repeated-run durations or passing repeat
receipts**. No repeat count, assertion, skip policy, timeout or shard layout has
been changed. Per-file timings and bounded slowest-case lists are in the packet.

## Remaining work and evidence

Windows fixture repairs and the actual core creation/ownership investigation
continue on separate branches. The strict pure package admission contracts are
being developed from their reviewed specification. The approved native leaf and
reader work remains queued. Full Windows/Linux/Qt/native/frozen/package/security
gates and real CVE/KB/analyst journeys continue to block main merge and beta
readiness. Diagnostic retention does not resolve the native digest mismatch or
restricted Windows descendant/network qualification.

The archive has **{len(payloads)} payloads**, plus its manifest, and **{len(archive):,} bytes**.
SHA-256: `{sha(archive)}`. Every payload was reread, length/hash checked and ZIP-CRC
verified. Original failure evidence is in the preceding
[integration checkpoint](../admission-diagnostics-integration-20261119/README.md),
whose archive SHA-256 remains
`ab11b8c014d5fdf0cfe94b2e29f661bd20974019f7c4f9a91151b7593dce4ece`.
'''
(OUT / 'README.md').write_text(readme)
manifest['archive'] = dict(bytes=len(archive), sha256=sha(archive), members=len(payloads) + 1)
manifest['readme_sha256'] = sha(readme.encode())
(OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
append = f'''\n\n## Formatter diagnostics and final old-head Qt outcomes — 2026-11-19

Spec `{SPEC}` precedes formatter-harness source `{SOURCE}`. The original
count/stream-error predicate, return 4, empty successful stdout and Python assertion
condition remain unchanged; only failing observations are added. Independent
static review finds no blocker. The exact-source bounded replay passes 9 tests,
zero skips/errors, with 40 canonical imports and changed-file Ruff success. This
is separate from the prior 2,043-case source gate and does not resolve old Windows
W51, whose individual predicate values were absent.

The remaining published771e Qt jobs finished cancelled at 00:19:44 and 00:19:53 UTC
after roughly two hours, without complete passing summaries. All48old-head checks
are completed:34success/5failure/7skip/2cancelled. Both repeat gates remain unverified;
dependent packaging is skipped. The earlier pending snapshot remains historical.
No repeats, timeouts, assertions or workflow sources are changed. Actual cancellation
and slow-test causes are not established. Windows repairs and pure contracts
continue independently; main/native/platform/package/security/beta acceptance
remains blocked. [Complete observations and source evidence]({{link}}).
'''
for name, link in [
    ('docs/qa.md', 'qa/formatter-qt-observations-20261119/README.md'),
    ('docs/plans/patchtrace-completion-matrix.md', '../qa/formatter-qt-observations-20261119/README.md'),
    ('docs/plans/autonomous-consolidation-20261118/consolidation-ledger.md', '../../qa/formatter-qt-observations-20261119/README.md')]:
    with (REPO / name).open('a') as stream:
        stream.write(append.replace('{link}', link))
with (REPO / 'tasks/todo.md').open('a') as stream:
    stream.write('''\n\n### Formatter and Qt observation checkpoint — 2026-11-19

- [x] Preserve W51 failure and both original predicate operands; add bounded failing observations, obtain independent static review and pass the exact-source nine-test gate.
- [x] Retain final old-head Qt cancellation logs, API metadata, runner/workflow identity and same-tree timing context without attributing an unobserved cause.
- [ ] Obtain actual Windows formatter observations; keep its cap/assertion intact.
- [ ] Diagnose and complete the full Qt repeat gates without reducing repeat coverage.
- [ ] Complete the append-only PR publication, then continue Windows repairs, pure contracts and queued native ownership work; require new exact-head platform gates.
''')
print(json.dumps(dict(directory=str(OUT), payloads=len(payloads), archive_bytes=len(archive),
                      archive_sha256=sha(archive), source=SOURCE)))
