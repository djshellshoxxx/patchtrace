"""Replay the one reviewed authored formatter file; preserve the failing predicate."""
import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = ROOT / 'qa/formatter-predicate-observations'
BASE = '29192f7837ebdb268d5c47e0a2536c67148cbe9f'
TEST = 'tests/test_windows_network_diagnostics.py'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


source = git('rev-parse', '16c35e1f').decode().strip()
assert git('rev-parse', 'HEAD').decode().strip() == source and not git('status', '--porcelain')
assert git('diff', '--name-only', BASE, source, '--', 'src', 'tests', 'tools', '.github', 'pyproject.toml').decode().splitlines() == [TEST]
old, new = ast.parse(git('show', BASE + ':' + TEST)), ast.parse(git('show', source + ':' + TEST))
old_h = next(n for n in old.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'HARNESS' for t in n.targets))
new_h = next(n for n in new.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'HARNESS' for t in n.targets))
old_fragment = '        return pt_diag_count == 16 && ferror(stderr) ? 0 : 4;'
new_fragment = '''        {
            int stream_error = ferror(stderr);
            if (pt_diag_count == 16 && stream_error) return 0;
            printf("{\\"probe\\":\\"formatter-failed-write/1\\",\\"attempted\\":%lu,"
                   "\\"stream_error\\":%d}\\n", (unsigned long)pt_diag_count, stream_error);
            return 4;
        }'''
assert old_h.value.value.count(old_fragment) == new_h.value.value.count(new_fragment) == 1
assert new_h.value.value.replace(new_fragment, old_fragment) == old_h.value.value
new_h.value = old_h.value
changed_messages = [n for n in ast.walk(new) if isinstance(n, ast.Assert) and isinstance(n.msg, ast.Tuple)
                    and n.msg.elts and isinstance(n.msg.elts[0], ast.Constant) and n.msg.elts[0].value == 'formatter exit/stdout/stderr']
assert len(changed_messages) == 1
changed_messages[0].msg = None
assert ast.dump(old, include_attributes=False) == ast.dump(new, include_attributes=False)
OUT.mkdir(exist_ok=False)
owned = Path(tempfile.mkdtemp(prefix='patchtrace-formatter-observation-'))
compiler = shutil.which('cc')
assert compiler
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', QT_QPA_PLATFORM='offscreen',
           PYTHONPATH=os.pathsep.join(map(str, [REPO / 'src', REPO / 'tests', REPO, ROOT / 'ops'])),
           GIT_ALLOW_PROTOCOL='file', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null',
           GIT_TERMINAL_PROMPT='0', PATCHTRACE_BATCH_COLLECTION_RECEIPT=str(OUT / 'collection.json'),
           PATCHTRACE_OFFLINE_GUARD_RECEIPT=str(OUT / 'offline-guard.json'))
argv = [sys.executable, str(ROOT / 'ops/continuation_offline_pytest.py'), '-q', '-ra',
        '-p', 'no:cacheprovider', '-p', 'project_and_tools_receipt', TEST,
        '--basetemp=' + str(owned / 'pytest'), '--junitxml=' + str(OUT / 'result.xml')]
command = dict(source=source, base=BASE, tree=git('rev-parse', 'HEAD^{tree}').decode().strip(),
               argv=argv, cwd=str(REPO), pythonpath=env['PYTHONPATH'], started_utc=datetime.now(timezone.utc).isoformat(),
               timeout=60, owned_temp=str(owned), test_sha256=sha((REPO / TEST).read_bytes()),
               compiler=dict(path=compiler, sha256=sha(Path(compiler).read_bytes()),
                             version=subprocess.check_output([compiler, '--version'], timeout=10).decode()[:2000]),
               unchanged_production_tools_workflow=True, other_test_ASTs_and_all_assertion_conditions_preserved=True,
               scope='One complete reviewed test file; authored standard-C formatter only. Existing failure predicate and original Windows result remain unchanged. No native Windows/engine/target execution.')
(OUT / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
start = time.monotonic()
with (OUT / 'result.log').open('x') as stream:
    result = subprocess.run(argv, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=60)
collection = json.loads((OUT / 'collection.json').read_text())
for row in collection['final_sources'].values():
    path = Path(row['path'])
    rel = path.relative_to(REPO).as_posix()
    assert sha(git('show', source + ':' + rel)) == row['sha256'] == sha(path.read_bytes())
cases = list(ET.parse(OUT / 'result.xml').getroot().iter('testcase'))
counts = dict(tests=len(cases), failures=sum(c.find('failure') is not None for c in cases),
              errors=sum(c.find('error') is not None for c in cases), skipped=sum(c.find('skipped') is not None for c in cases))
assert counts == dict(tests=9, failures=0, errors=0, skipped=0) and result.returncode == 0
assert git('rev-parse', 'HEAD').decode().strip() == source and not git('status', '--porcelain')
assert sha((REPO / TEST).read_bytes()) == command['test_sha256']
lint_argv = [sys.executable, '-m', 'ruff', 'check', '--no-cache', TEST]
lint = subprocess.run(lint_argv, cwd=REPO, capture_output=True, timeout=30)
(OUT / 'lint.json').write_text(json.dumps(dict(source=source, argv=lint_argv, exit=lint.returncode,
                                             stdout=lint.stdout.decode(), stderr=lint.stderr.decode()), indent=2) + '\n')
assert lint.returncode == 0
shutil.rmtree(owned)
receipt = dict(source=source, exit=result.returncode, elapsed=time.monotonic()-start, junit=counts,
               canonical_imports=len(collection['final_sources']), test_unchanged=True, clean_head=True,
               owned_temp_removed=True, native_windows_acceptance=False,
               original_windows_failure_resolved=False, lint_exit=lint.returncode)
(OUT / 'exit.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
print((OUT / 'result.log').read_text())
