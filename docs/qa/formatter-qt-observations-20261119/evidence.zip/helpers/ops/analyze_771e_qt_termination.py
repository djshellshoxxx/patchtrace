"""Inspect retained Qt cancellation logs and same-tree full-suite timings; no tests."""
import ast
from collections import defaultdict
from datetime import datetime, timezone
import fnmatch
import hashlib
import json
import math
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = ROOT / 'qa/hosted-pr316-771e-qt-final'
BASE = '361dd495a7e050121f2b3cae4e7678faad7fee35'
HEAD = '771e5a775f5bf60a8d9094232b51dcdbb47d6389'
PREVIEW = 'ac6632ad6de486ba16343f0eeb4a2b5a446e4ac1'
TREE = 'ddf151c6ff8fb3f70b74378525fe1d8d5c9050e3'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert git('rev-parse', BASE + '^{tree}').decode().strip() == TREE
sources = []
for name in ['tools/qt_gate.py', '.github/workflows/qa-windows.yml']:
    raw = git('show', BASE + ':' + name)
    assert raw == git('show', 'HEAD:' + name)
    p = OUT / 'source' / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.open('xb').write(raw)
    sources.append(dict(path=name, source=BASE, git_blob=git('rev-parse', BASE + ':' + name).decode().strip(), sha256=sha(raw)))
runner = ast.parse((OUT / 'source/tools/qt_gate.py').read_text())
patterns = ast.literal_eval(next(n.value for n in runner.body if isinstance(n, ast.Assign)
                                and any(isinstance(t, ast.Name) and t.id == 'DEFAULT_PATTERNS' for t in n.targets)))
paths = git('ls-tree', '-r', '--name-only', BASE, '--', 'tests').decode().splitlines()
files = sorted(p for p in paths if Path(p).parent.as_posix() == 'tests' and any(fnmatch.fnmatchcase(Path(p).name, pat) for pat in patterns))
assert files
by_platform = {}
for platform, directory, artifact_id, expected in [
        ('linux', 'qa/hosted-pr316-771e-linux-qa', 14477819807, '552ba012c89e46013ff4c6d6094db93f0662b8c67cac0c9716b9aabd66df531f'),
        ('windows', 'qa/hosted-pr316-771e-windows-qa', 14483781250, 'd24926b2bb7c13ea8c6eb4ec8efbb8254675abb61f27540466f6256b55376c23')]:
    path = ROOT / directory / f'artifacts/artifact-{artifact_id}.zip'
    assert sha(path.read_bytes()) == expected
    with zipfile.ZipFile(path) as archive:
        raw = archive.read('qa-results.xml')
    assert len(raw) < 8 * 1024 * 1024 and b'\0' not in raw and b'<!DOCTYPE' not in raw.upper() and b'<!ENTITY' not in raw.upper()
    rows = defaultdict(lambda: dict(cases=0, seconds=0., failed=0, skipped=0, slowest=[]))
    for case in ET.fromstring(raw).iter('testcase'):
        name = '/'.join(case.attrib['classname'].split('.')[:2]) + '.py'
        if name not in files:
            continue
        elapsed = float(case.attrib.get('time', '0'))
        assert math.isfinite(elapsed) and elapsed >= 0
        row = rows[name]
        row['cases'] += 1
        row['seconds'] += elapsed
        row['failed'] += case.find('failure') is not None or case.find('error') is not None
        row['skipped'] += case.find('skipped') is not None
        row['slowest'].append(dict(name=case.attrib['name'], seconds=elapsed))
    for row in rows.values():
        row['seconds'] = round(row['seconds'], 3)
        row['slowest'] = sorted(row['slowest'], key=lambda r: -r['seconds'])[:5]
    shard_count, repeats = (4, 20) if platform == 'linux' else (1, 5)
    shards = []
    for i in range(shard_count):
        selected = files[i::shard_count]
        seconds = sum(rows[name]['seconds'] for name in selected)
        shards.append(dict(shard=f'{i+1}/{shard_count}', files=selected,
                           full_suite_cases=sum(rows[n]['cases'] for n in selected), full_suite_seconds=round(seconds, 3),
                           arithmetic_repeat_minutes=round(seconds * repeats / 60, 2),
                           limitation='Arithmetic from a different pytest session, not a timing prediction or successful repeat receipt.'))
    by_platform[platform] = dict(artifact=artifact_id, original_artifact_sha256=expected, junit_sha256=sha(raw),
                                 files=dict(sorted(rows.items())), shards=shards)
state = json.loads((OUT / 'api-projection.json').read_text())
jobs = {r['id']: r for r in state['jobs']['jobs']}
logs = []
for job_id in [135175350753, 135175350919]:
    job = jobs[job_id]
    assert job['head_sha'] == HEAD and job['run_id'] == 44409973351 and job['conclusion'] == 'cancelled'
    raw = (OUT / f'job-{job_id}.log').read_bytes()
    text = raw.decode('utf-8')
    assert PREVIEW in text and 'The operation was canceled.' in text
    start = datetime.fromisoformat(job['started_at'].replace('Z', '+00:00'))
    end = datetime.fromisoformat(job['completed_at'].replace('Z', '+00:00'))
    logs.append(dict(job_id=job_id, bytes=len(raw), sha256=sha(raw), elapsed_job_seconds=(end-start).total_seconds(),
                     conclusion='cancelled', complete_pytest_summary_present=any(' passed in ' in line for line in text.splitlines()),
                     final_progress=[line for line in text.splitlines() if '%]' in line][-6:]))
result = dict(checked_utc=datetime.now(timezone.utc).isoformat(), head=HEAD, preview=PREVIEW, tree=TREE,
              local_equal_tree_source=BASE, source_files=sources, gui_file_count=len(files),
              default_patterns=list(patterns), jobs=logs, full_suite_timing_context=by_platform,
              workflow_job_timeout_minutes=120,
              interpretation='Both jobs ended cancelled near the configured two-hour limit. Logs retain incomplete work and no passing repeat summary. Annotation cause was unavailable through the connector; no manual-cancellation or specific slow-test cause is inferred.',
              new_tests_or_native_execution=False)
(OUT / 'analysis.json').open('x').write(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(gui_files=len(files), jobs=logs, timing_context={p:[{k:v for k,v in r.items() if k!='files'} for r in d['shards']] for p,d in by_platform.items()})))
