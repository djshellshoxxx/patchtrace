# Independent static review: formatter failure observations

Reviewer: `/root/ci_qualification`. This review is read-only and changes no
author source. Inspected exact spec/module commit
`fdc1f606dd0b8a3ce94ae2db94f4fb6984a02b69` and implementation
`16c35e1fb1a4dd54b2c2c0cb2033c8160ee99347`.

**Disposition: no blocking finding in this bounded diagnostic delta.** The
complete diff covers the Windows acceptance specification, one existing module
row, and `tests/test_windows_network_diagnostics.py`. Production C, the native
launch/network protocol, process behavior, and acceptance policy are unchanged.

The failed-write harness still performs the same `freopen` and 1,000 calls to
the real extracted formatter. The success condition remains exactly an attempt
count of 16 and a nonzero `ferror(stderr)`. Sampling the error indicator once
into an `int` preserves that Boolean predicate. It additionally observes the
indicator when the count differs, where the original expression would have
short-circuited; this supplies the requested second observation without
clearing it. Success still returns 0 without stdout; failure still returns 4.

Only the failure branch prints one fixed numeric JSON record on the standalone
harness's stdout. The known count is capped at 16, the error indicator is an
`int`, the vocabulary is fixed, and the record remains below the specified
128-byte bound. It carries no path, command, environment, source contents,
nonce, token or native identity. Reporting does not write again to the failed
stderr stream, clear its error indicator, replace its sink, or alter the
formatter's 16-attempt cap. There is no stale-handle or native-resource change.

The pytest condition is unchanged: return code 0 and empty stdout are both
required. Its added assertion message is bounded to the return code and at
most 512 bytes of each stream. A diagnostic line can therefore explain a
failure; it cannot convert that failure into acceptance. Existing stderr size,
record shape and semantic assertions remain in place.

This review did not run a compiler, authored child, Windows executable or test
suite. Root separately reports nine portable tests passing at the exact source;
that result is not claimed as an independently executed reviewer gate here.
The original hosted Windows job `135175350823` at head `771e5a77` remains an
unresolved exit-4 result with neither constituent value captured. A later
actual Windows run must supply those observations; neither this static review
nor portable success identifies the original Windows CRT cause.
