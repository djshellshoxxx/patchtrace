from __future__ import annotations

import hashlib
import json
import zipfile
from datetime import UTC, datetime
from pathlib import Path

root = Path('/workspace/scratch/80dddc5347b2')
repo = root / 'PatchTrace-consolidation-followup'
pairs = [
    ('docs/audits/consolidation-20261119/residual-semantic-manifest.json', 'residual-semantic-evidence.zip'),
    ('docs/audits/consolidation-20261119/second-full-run-manifest.json', 'second-full-run-evidence.zip'),
    ('docs/audits/consolidation-20261119/windows-advisory-qualified-manifest.json', 'windows-advisory-qualified-evidence.zip'),
    ('docs/audits/consolidation-20261119/broad-linux-full-failure-manifest.json', 'broad-linux-full-failure-evidence.zip'),
    ('docs/qa/inventory-recovery-20261119/source-manifest.json', 'source-evidence.zip'),
    ('docs/qa/inventory-recovery-20261119/current-manifest.json', 'current-evidence.zip'),
    ('docs/qa/gui-help-announcements-20261119/manifest.json', 'evidence.zip'),
    ('docs/qa/strings-composition-20261119/manifest.json', 'evidence.zip'),
    ('docs/qa/strings-composition-admission-20261119/manifest.json', 'evidence.zip'),
    ('docs/qa/tool-admission-20261119/manifest.json', 'evidence.zip'),
    ('docs/qa/tool-admission-20261119/search-cli-correction.json', 'search-cli-correction.zip'),
    ('docs/qa/assembly-source-20261119/manifest.json', 'evidence.zip'),
]


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


results = []
for path, archive_name in pairs:
    manifest_path = repo / path
    manifest = json.loads(manifest_path.read_text())
    archive = manifest_path.parent / archive_name
    archive_data = archive.read_bytes()
    expected_archive = manifest.get('archive_sha256')
    if expected_archive is None:
        assert isinstance(manifest['archive'], dict), path
        expected_archive = manifest['archive']['sha256']
    assert sha(archive_data) == expected_archive, path
    members = manifest.get('members', manifest.get('files'))
    if isinstance(members, dict):
        members = [{'path': name, **metadata} for name, metadata in members.items()]
    assert isinstance(members, list), path
    expected = {member.get('path', member.get('name')) for member in members}
    extra_manifests = {}
    if archive_name == 'residual-semantic-evidence.zip':
        extra_manifests['residual-semantic-review-20261119-manifest.json'] = 'f5fadec687a67d94d4664fe6fbc5ec1cc59bdf5caf06ea528748b3e3fe6f127a'
    with zipfile.ZipFile(archive) as z:
        assert z.testzip() is None, archive
        assert set(z.namelist()) == expected | extra_manifests.keys(), (archive, set(z.namelist()) ^ expected)
        for name, expected_hash in extra_manifests.items():
            data = z.read(name)
            assert sha(data) == expected_hash
            assert data == (root / name).read_bytes()
            nested = json.loads(data)
            assert set(nested) == expected
            for nested_name, nested_sha in nested.items():
                assert sha(z.read(nested_name)) == nested_sha
        for member in members:
            name = member.get('path', member.get('name'))
            data = z.read(name)
            assert len(data) == member['bytes'], (archive, name)
            assert sha(data) == member['sha256'], (archive, name)
    results.append({'manifest': path, 'archive': str(archive.relative_to(repo)),
                    'bytes': len(archive_data), 'sha256': sha(archive_data),
                    'members': len(members) + len(extra_manifests),
                    'embedded_source_manifests': extra_manifests, 'result': 'verified'})

for folder in ['search-sources-20261119', 'search-admission-20261119']:
    directory = repo / 'docs/qa' / folder
    manifest = json.loads((directory / 'manifest.json').read_text())
    if 'members' in manifest:
        members = manifest['members']
    else:
        members = [{'name': key, 'sha256': value} for key, value in manifest.items()]
    for member in members:
        path = directory / member['name']
        data = path.read_bytes()
        assert sha(data) == member['sha256'], path
        if 'bytes' in member:
            assert len(data) == member['bytes'], path
    results.append({'manifest': str((directory / 'manifest.json').relative_to(repo)),
                    'members': len(members), 'result': 'verified'})

out = {'recorded_utc': datetime.now(UTC).isoformat(),
       'scope': 'New or previously unuploaded recovery and failure packets; no alteration of raw evidence.',
       'verification_format_correction': 'The first verifier assumed the residual ZIP had only the 14 manifest-listed payload members. It also has the original source-hash manifest. Its exact original bytes/hash and every nested entry were then independently verified; archive bytes remain unchanged.',
       'packets': results, 'mismatches': 0}
(root / 'assembly-evidence-verification.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'packets': len(results), 'members': sum(item['members'] for item in results),
                  'mismatches': 0}))
