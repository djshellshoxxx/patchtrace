"""One bounded affected-area run; no product source edits or native qualification claims."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import shlex
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path('/workspace/scratch/80dddc5347b2')
CWD = ROOT / 'PatchTrace-consolidation-followup'
RUNTIME = '9335e7dcadc6d0337243f894e8f234ccc74bc62e'
PLAN = ROOT / 'combined-affected-independent-plan.json'
RECEIPT = ROOT / 'combined-affected-independent-result.json'
LOG = ROOT / 'combined-affected-independent.log'
XML = ROOT / 'combined-affected-independent.xml'
SOURCE_PATHS = ('src', 'tests', 'tools', '.github', 'pyproject.toml')


def git(*args):
    return subprocess.check_output(['git', *args], text=True, cwd=CWD).strip()


def source_unchanged():
    return subprocess.run(['git', 'diff', '--quiet', RUNTIME, '--', *SOURCE_PATHS], cwd=CWD).returncode == 0


plan = json.loads(PLAN.read_text())
assert source_unchanged(), 'Runtime/test/configuration drifted from the frozen review source'
command = [sys.executable, '-m', 'pytest', '-q', '-ra', *plan['selected_targets'],
           '--deselect', plan['explicit_deselection'], f'--junitxml={XML}']
env = os.environ.copy()
env.update(PYTHONPATH='src:tests', QT_QPA_PLATFORM='offscreen')
plan.update(run_command=command, run_shell_command=shlex.join(command),
            run_environment={'PYTHONPATH': 'src:tests', 'QT_QPA_PLATFORM': 'offscreen'},
            outer_timeout_seconds=360, run_head=git('rev-parse', 'HEAD'),
            runtime_tree=git('rev-parse', RUNTIME + '^{tree}'),
            started_at=dt.datetime.now(dt.timezone.utc).isoformat())
PLAN.write_text(json.dumps(plan, indent=2) + '\n')
(ROOT / 'combined-affected-independent-command.txt').write_text(
    'cwd: ' + str(CWD) + '\nPYTHONPATH=src:tests QT_QPA_PLATFORM=offscreen ' + shlex.join(command) + '\n')
print(json.dumps({'status': 'running', 'runtime': RUNTIME, 'head': plan['run_head'],
                  'selected': 1200, 'explicit_deselections': 1, 'outer_timeout_seconds': 360}), flush=True)
started = time.monotonic()
with LOG.open('w') as output:
    try:
        completed = subprocess.run(command, cwd=CWD, env=env, stdout=output,
                                   stderr=subprocess.STDOUT, timeout=360)
        code, timed_out = completed.returncode, False
    except subprocess.TimeoutExpired:
        code, timed_out = 124, True
result = {'runtime_source': RUNTIME, 'runtime_tree': plan['runtime_tree'],
          'start_head': plan['run_head'], 'finish_head': git('rev-parse', 'HEAD'),
          'command': command, 'returncode': code, 'outer_timeout': timed_out,
          'elapsed_seconds': round(time.monotonic() - started, 3),
          'finished_at': dt.datetime.now(dt.timezone.utc).isoformat(),
          'runtime_tests_config_unchanged': source_unchanged(),
          'explicit_deselection': plan['explicit_deselection'], 'files': {}}
for path in (LOG, XML):
    if path.is_file():
        data = path.read_bytes()
        result['files'][path.name] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
RECEIPT.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'command'}, indent=2), flush=True)
print('\n'.join(LOG.read_text().splitlines()[-15:]), flush=True)
raise SystemExit(code if code else 0 if result['runtime_tests_config_unchanged'] else 2)
