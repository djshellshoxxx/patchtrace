"""Exercise the real workflow guard with bounded authored action-reference changes."""
from pathlib import Path

import pytest
import test_tier_r_shard as original

ROOT = Path('/workspace/scratch/80dddc5347b2/PatchTrace-ci-cache-pin')
CACHE = 'actions/cache@0057852bfaa89a56745cba8c7296529d2fc39830'
MSVC = 'ilammy/msvc-dev-cmd@0b201ec74fa43914dc39ae48a89fd1d8cb592756'


@pytest.mark.parametrize(('before', 'after', 'allowed'), [
    (CACHE, CACHE, True),
    (CACHE, 'actions/cache@v4', True),
    (CACHE, 'actions/cache@' + '0' * 40, False),
    (CACHE, 'actions/checkout@0057852bfaa89a56745cba8c7296529d2fc39830', False),
    (CACHE, CACHE + '0', False),
    (MSVC, 'ilammy/msvc-dev-cmd@v1', False),
])
def test_exact_pin_and_existing_tag_policy(tmp_path, monkeypatch, before, after, allowed):
    assert Path(original.__file__).resolve() == ROOT / 'tests/test_tier_r_shard.py'
    text = (ROOT / '.github/workflows/corpus-tier-r.yml').read_text()
    assert before in text
    changed = tmp_path / 'workflow.yml'
    changed.write_text(text.replace(before, after))
    monkeypatch.setattr(original, 'WORKFLOW', changed)
    if allowed:
        original.test_workflow_structure_and_pins()
    else:
        with pytest.raises(AssertionError):
            original.test_workflow_structure_and_pins()
