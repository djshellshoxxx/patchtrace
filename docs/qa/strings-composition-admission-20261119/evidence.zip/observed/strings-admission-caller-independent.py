"""Independent actual-producer/caller checks for stored Strings admission.

Synthetic PE fixtures and authored fake FLOSS only; no target/native tool runs.
Checks current-artifact fallback and refusal, not current raw-sidecar bytes.
"""
from __future__ import annotations

import hashlib
import json
import subprocess
import tempfile
import threading
from pathlib import Path
from types import SimpleNamespace

from test_ui_strings_run import fake_floss, make_project, tool_store

from patchtrace.intelligence.tools import runner
from patchtrace.intelligence.tools.common import ToolError, evidence_entry_id
from patchtrace.strings import compose
from patchtrace.strings.cli import compute
from patchtrace.strings.contracts import StringsError


def outcome(service, choice):
    try:
        result = compute(SimpleNamespace(source=choice, anchors=None, min_length=4),
                         service, threading.Event())
        return {'sources': result.sources,
                'artifacts': {side: table.basis.artifact_sha256 for side, table in result.tables.items()}}
    except (StringsError, ToolError) as exc:
        return {'refused': exc.code}


record = {'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'compose_sha256': hashlib.sha256(Path(compose.__file__).read_bytes()).hexdigest(), 'cases': []}
with tempfile.TemporaryDirectory(prefix='strings-admission-independent-') as directory:
    folder = Path(directory)
    with make_project(folder, 'floss-static') as service:
        artifacts = {a.side: a for a in service.project.artifacts}
        expected = {side: a.sha256 for side, a in artifacts.items()}
        request = runner.RunRequest(
            tuple(runner.ArtifactRef(a.side, service.root / a.relative_path, a.sha256, a.size)
                  for a in service.project.artifacts),
            runner.Setup(floss=fake_floss(folder, service)), profile='context', engines=('floss',))
        store = tool_store(service)
        first = runner.run_tools(request, store, threading.Event())
        original = next(job for job in first if job.run.side == 'newer')
        record['expected_artifacts'] = expected
        record['fresh'] = {'cache_hits': [job.run.cache_hit for job in first], **outcome(service, 'auto')}

        def guard_cases(phase, identities):
            for row, identity in identities.items():
                for field, value in [('stale', 1), ('project_id', 'foreign-authored-project')]:
                    db = service.store.connection
                    previous = db.execute(f'SELECT {field} FROM enrichment_entries WHERE id=?',
                                          (identity,)).fetchone()[0]
                    db.execute(f'UPDATE enrichment_entries SET {field}=? WHERE id=?', (value, identity))
                    before = tuple(db.iterdump())
                    try:
                        auto, explicit = outcome(service, 'auto'), outcome(service, 'floss')
                        record['cases'].append({
                            'phase': phase, 'row': row, 'field': field, 'auto': auto, 'explicit': explicit,
                            'store_unchanged': tuple(db.iterdump()) == before,
                            'passes': auto.get('sources') == {'older': 'floss', 'newer': 'builtin-scan'}
                                      and auto.get('artifacts') == expected
                                      and explicit.get('refused') == 'PT-STR-INPUT'
                                      and tuple(db.iterdump()) == before})
                    finally:
                        db.execute(f'UPDATE enrichment_entries SET {field}=? WHERE id=?', (previous, identity))

        guard_cases('fresh', {'selected-run': original.run.run_id,
                              'evidence': evidence_entry_id(original.evidence)})
        again = runner.run_tools(request, store, threading.Event())
        selected = next(job for job in again if job.run.side == 'newer')
        record['cache'] = {'cache_hits': [job.run.cache_hit for job in again],
                           'selected_raw_sidecar': selected.run.raw_sidecar,
                           'selected_stdout_digest': selected.run.stdout_digest,
                           **outcome(service, 'auto')}
        captured = compose.stored_sources('auto', store, artifacts)
        source = captured['newer']
        part = source.load().part if source is not None else None
        record['recorded_origin_provenance'] = {
            'original_run_id': original.run.run_id,
            'selected_run_id': selected.run.run_id,
            'captured_run_id': part.run_id if part else None,
            'raw_digest_matches_origin': part is not None and part.raw_sha256 == original.run.stdout_digest,
            'executable_matches_origin': part is not None
                                         and part.executable_sha256 == original.run.manifest.executable_sha256,
            'version_matches_origin': part is not None and part.source_version == original.run.manifest.version,
            'consent_matches_origin': part is not None
                                      and part.consent_sha256 == original.run.options.get('emulation_consent_sha256')}
        guard_cases('cache', {'selected-run': selected.run.run_id,
                              'evidence': evidence_entry_id(selected.evidence),
                              'origin-run': original.run.run_id})

record['guard_cases_passed'] = sum(case['passes'] for case in record['cases'])
record['guard_cases_total'] = len(record['cases'])
print(json.dumps(record, indent=2))
