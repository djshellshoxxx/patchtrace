"""Actual Strings caller handling of the independently reproduced BLOB boundary.

Uses synthetic PE inputs and authored fake FLOSS; no target/native tool executes.
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
import subprocess
import tempfile
import threading
from pathlib import Path
from types import SimpleNamespace

from test_ui_strings_run import fake_floss, make_project, tool_store

from patchtrace.intelligence.tools import runner
from patchtrace.intelligence.tools.common import ToolError, evidence_entry_id
from patchtrace.strings import compose
from patchtrace.strings.cli import compute
from patchtrace.strings.contracts import StringsError


def outcome(service, source):
    try:
        result = compute(SimpleNamespace(source=source, anchors=None, min_length=4),
                         service, threading.Event())
        return {'sources': result.sources,
                'artifacts': {side: table.basis.artifact_sha256 for side, table in result.tables.items()}}
    except (StringsError, ToolError) as exc:
        return {'refused': exc.code}


record = {'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
          'compose_sha256': hashlib.sha256(Path(compose.__file__).read_bytes()).hexdigest(), 'cases': []}
with tempfile.TemporaryDirectory(prefix='strings-blob-independent-') as directory:
    folder = Path(directory)
    with make_project(folder, 'floss-static') as service:
        expected = {a.side: a.sha256 for a in service.project.artifacts}
        request = runner.RunRequest(
            tuple(runner.ArtifactRef(a.side, service.root / a.relative_path, a.sha256, a.size)
                  for a in service.project.artifacts),
            runner.Setup(floss=fake_floss(folder, service)), profile='context', engines=('floss',))
        store = tool_store(service)
        jobs = runner.run_tools(request, store, threading.Event())
        selected = next(job for job in jobs if job.run.side == 'newer')
        record['before'] = outcome(service, 'auto')
        db = service.store.connection
        for kind, identity in [('run', selected.run.run_id),
                               ('evidence', evidence_entry_id(selected.evidence))]:
            body = db.execute('SELECT body FROM enrichment_entries WHERE id=?', (identity,)).fetchone()[0]
            db.execute('UPDATE enrichment_entries SET body=? WHERE id=?',
                       (sqlite3.Binary(body.encode('utf-8')), identity))
            before = tuple(db.iterdump())
            try:
                auto, explicit = outcome(service, 'auto'), outcome(service, 'floss')
                unchanged = tuple(db.iterdump()) == before
                record['cases'].append({
                    'kind': kind, 'auto': auto, 'explicit': explicit, 'store_unchanged': unchanged,
                    'passes': auto.get('sources') == {'older': 'builtin-scan', 'newer': 'builtin-scan'}
                              and auto.get('artifacts') == expected
                              and explicit.get('refused') == 'PT-STR-INPUT' and unchanged})
            finally:
                db.execute('UPDATE enrichment_entries SET body=? WHERE id=?', (body, identity))

record['cases_passed'] = sum(case['passes'] for case in record['cases'])
print(json.dumps(record, indent=2))
