"""Actual service/loader parity after a captured FLOSS artifact becomes unreadable.

Run in the pinned worktree with PYTHONPATH=src:tests and the dedicated composition
venv. Fixtures are authored PE bytes; the helper runs only a fake FLOSS program
that prints committed fixture output. No target or real native tool executes.
"""
from __future__ import annotations

import json
import subprocess
import tempfile
import threading
from pathlib import Path
from types import SimpleNamespace

from test_ui_strings_run import make_project, tool_store
from test_ui_strings_source import ServicePort, store_floss

from patchtrace.strings.cli import _artifacts, compute
from patchtrace.strings.compose import stored_sources
from patchtrace.strings.qt_panel import Request, load_strings

records = []
for kind in ('missing', 'hash-mismatch'):
    with tempfile.TemporaryDirectory(prefix='strings-independent-refusal-') as directory:
        root = Path(directory)
        with make_project(root, 'floss-static') as service:
            store_floss(root, service, 'older', 'newer')
            port = ServicePort(service)
            old, new, oldsha, newsha = port.artifact_paths()
            found = stored_sources('auto', tool_store(service), _artifacts(service))
            request = Request(port.key(), old, new, oldsha, newsha, root=service.root,
                              project=service.project.model_copy(), older_floss=found['older'],
                              newer_floss=found['newer'])
            old.unlink()
            if kind == 'hash-mismatch':
                old.write_bytes(b'authored replacement, not the verified artifact')
            row = {'case': kind}
            try:
                compute(SimpleNamespace(source='auto', anchors=None, min_length=4), service, threading.Event())
                row['cli'] = 'success'
            except Exception as exc:
                row['cli'] = {'class': type(exc).__name__, 'code': getattr(exc, 'code', None), 'message': str(exc)}
            try:
                result = load_strings(request, threading.Event(), lambda *args: None)
                row['dock'] = {'outcome': 'success', 'rows': len(result.rows), 'partial': list(result.partial),
                               'pairing_reason': result.pairing_reason}
            except Exception as exc:
                row['dock'] = {'class': type(exc).__name__, 'code': getattr(exc, 'code', None), 'message': str(exc)}
            records.append(row)

print(json.dumps({'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], text=True).strip(),
                  'cases': records}, indent=2))
