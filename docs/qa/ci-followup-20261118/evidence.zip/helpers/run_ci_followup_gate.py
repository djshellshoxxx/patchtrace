"""Qualify the reviewed cache, frozen-smoke, and lazy-FFI integration slice."""
from __future__ import annotations

import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
SOURCE = 'f3b7a0e895c3b9928e08f93ac77d2afda5c56dd8'
BASE = '12f5ff324572afdd039e7a55515c9d3ade001340'
OUT = ROOT / 'qa/ci-followup-integration'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write_json(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('status', '--porcelain')
assert not OUT.exists()
OUT.mkdir()
receipts = [ROOT / path for path in (
    'qa/corpus-archive-cache/cache-final-affected.command.json',
    'qa/linux-full-frozen-smoke/linux-smoke-final-affected.command.json',
    'qa/directory-publication-import-purity/final-affected-corrected.command.json')]
nodes = sorted({arg for path in receipts for arg in json.loads(path.read_text())['argv']
                if arg.startswith('tests/') and arg.endswith('.py')})

# The archived adversarial test imported the former private module attribute.
# Its new replay copy changes only the injection target to the same ctypes module.
# All assertions and every other AST node must be unchanged.
original = ROOT / 'qa/directory-publication-independent/test_directory_review.py'
original_bytes = original.read_bytes()
adapted_bytes = original_bytes.replace(b'publisher.ctypes', b'ctypes')
assert original_bytes.count(b'publisher.ctypes') == 2
assert ast.dump(ast.parse(original_bytes.decode().replace('publisher.ctypes', 'ctypes'))) == ast.dump(ast.parse(adapted_bytes))
original_assertions = [ast.dump(node) for node in ast.walk(ast.parse(original_bytes)) if isinstance(node, ast.Assert)]
adapted_assertions = [ast.dump(node) for node in ast.walk(ast.parse(adapted_bytes)) if isinstance(node, ast.Assert)]
assert original_assertions == adapted_assertions
adapted = OUT / 'test_directory_review_lazy_ffi.py'
with adapted.open('xb') as stream:
    stream.write(adapted_bytes)
write_json(OUT / 'external-probe-adaptation.json', dict(
    original=str(original), original_sha256=hashlib.sha256(original_bytes).hexdigest(),
    replay=str(adapted), replay_sha256=digest(adapted),
    reason='Lazy import removes the private publisher.ctypes attribute; patch the same imported ctypes module.',
    replacements=2, assertions_unchanged=len(original_assertions), other_ast_unchanged=True))
nodes += [str(ROOT / 'qa/corpus-cache-root-review/test_cache_boundary_review.py'), str(adapted)]
scope = dict(source=SOURCE, tree=git('rev-parse', 'HEAD^{tree}').decode().strip(),
             author_command_receipts={str(path): digest(path) for path in receipts},
             node_files=nodes, exact_selected_file_bytes=[dict(node=node,
                 sha256=digest(Path(node) if Path(node).is_absolute() else REPO / node)) for node in nodes],
             preserved_original_probe={str(original): digest(original)})
write_json(OUT / 'selected-nodes.json', scope)

owners = {
    '.github/workflows/corpus-tier-r.yml': '451e463d25e625c55344ac232fd9de90275b9013',
    'tests/test_corpus_cache_integrity.py': '451e463d25e625c55344ac232fd9de90275b9013',
    'tests/test_codex_pkg_workflows.py': '451e463d25e625c55344ac232fd9de90275b9013',
    'tools/build_linux.py': '2a7e3147abda0450840e885dc075cf319a59ccaa',
    'tools/frozen_smoke.py': '2a7e3147abda0450840e885dc075cf319a59ccaa',
    'tests/test_linux_frozen_smoke.py': '2a7e3147abda0450840e885dc075cf319a59ccaa',
    'tests/test_codex_pkg_packaging.py': '2a7e3147abda0450840e885dc075cf319a59ccaa',
    'src/patchtrace/directory_publication.py': '73bd7eadd1fa279cd1f7ea6887029b85e6c55430',
    'tests/test_directory_publication.py': '73bd7eadd1fa279cd1f7ea6887029b85e6c55430',
    'tests/test_directory_publication_imports.py': '73bd7eadd1fa279cd1f7ea6887029b85e6c55430',
}
changed = git('diff', '--name-only', BASE, SOURCE, '--', 'src', 'tests', 'tools', '.github', 'docs/schemas', 'pyproject.toml').decode().splitlines()
assert set(changed) == set(owners)
proofs = []
for path in changed:
    current, reviewed = git('show', SOURCE + ':' + path), git('show', owners[path] + ':' + path)
    assert current == reviewed
    assert (REPO / path).read_bytes() == current
    proofs.append(dict(path=path, reviewed_source=owners[path],
                       sha256=hashlib.sha256(current).hexdigest(), bytes=len(current)))
write_json(OUT / 'source-owner-preservation.json', dict(base=BASE, source=SOURCE, files=proofs))

owned = Path(tempfile.mkdtemp(prefix='patchtrace-ci-followup-'))
assert not any((path / '.git').exists() for path in (owned, *owned.parents))
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1',
    PYTHONPATH=os.pathsep.join(map(str, [REPO / 'src', REPO / 'tests', REPO, ROOT / 'ops'])),
    QT_QPA_PLATFORM='offscreen', QT_SCALE_FACTOR='1',
    GIT_ALLOW_PROTOCOL='file', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null',
    GIT_TERMINAL_PROMPT='0',
    PATCHTRACE_OFFLINE_GUARD_RECEIPT=str(OUT / 'combined-offline-guard.json'),
    PATCHTRACE_BATCH_COLLECTION_RECEIPT=str(OUT / 'combined-collection.json'))
command = [sys.executable, str(ROOT / 'ops/continuation_offline_pytest.py'), '-q', '-ra',
           '-p', 'no:cacheprovider', '-p', 'full_batch_receipt',
           *nodes, '--basetemp=' + str(owned / 'pytest'), '--junitxml=' + str(OUT / 'combined.xml')]
write_json(OUT / 'combined-command.json', dict(source=SOURCE, tree=scope['tree'], argv=command,
    cwd=str(REPO), environment={key: env[key] for key in ('PYTHONPATH', 'PYTHONDONTWRITEBYTECODE',
        'QT_QPA_PLATFORM', 'QT_SCALE_FACTOR', 'GIT_ALLOW_PROTOCOL', 'GIT_CONFIG_NOSYSTEM',
        'GIT_CONFIG_GLOBAL', 'GIT_TERMINAL_PROMPT')}, owned_system_temp=str(owned),
    started_utc=datetime.now(timezone.utc).isoformat(), timeout_seconds=300,
    helper_sha256={path.name: digest(path) for path in (Path(__file__),
        ROOT / 'ops/continuation_offline_pytest.py', ROOT / 'ops/full_batch_receipt.py')}))
started = time.monotonic()
try:
    with (OUT / 'combined.log').open('x') as stream:
        result = subprocess.run(command, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=300)
    code = result.returncode
except subprocess.TimeoutExpired:
    code = 124
collection_path = OUT / 'combined-collection.json'
collection = json.loads(collection_path.read_text()) if collection_path.exists() else {}
foreign, drift, non_git = [], [], []
for name, row in collection.get('final_sources', {}).items():
    path = Path(row['path'])
    if not path.is_relative_to(REPO / 'src'):
        foreign.append(dict(module=name, path=str(path)))
        continue
    if digest(path) != row['sha256']:
        drift.append(str(path))
    if hashlib.sha256(git('show', SOURCE + ':' + path.relative_to(REPO).as_posix())).hexdigest() != row['sha256']:
        non_git.append(str(path))
unchanged = digest(original) == scope['preserved_original_probe'][str(original)]
receipt = dict(exit=code, elapsed=time.monotonic()-started,
    source_after=git('rev-parse', 'HEAD').decode().strip(), status_after=git('status', '--porcelain').decode(),
    imported_source_count=len(collection.get('final_sources', {})), foreign_imports=foreign,
    imported_source_drift=drift, imported_sources_not_exact_git=non_git,
    original_external_probe_unchanged=unchanged, owned_system_temp=str(owned), temp_retained=True)
valid = receipt['source_after'] == SOURCE and not receipt['status_after'] and not foreign and not drift and not non_git and unchanged
if code == 0 and valid:
    shutil.rmtree(owned)
    receipt['temp_retained'] = False
write_json(OUT / 'combined-exit.json', receipt)
print(json.dumps(receipt))
print('\n'.join((OUT / 'combined.log').read_text().splitlines()[-40:]))
assert valid
raise SystemExit(code)
