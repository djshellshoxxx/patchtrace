"""Verify immutable cache evidence and replay exact workflow scripts on inert archives."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = ROOT / 'qa/corpus-cache-root-review'
SOURCE = '451e463d25e625c55344ac232fd9de90275b9013'
PRODUCTION = '693d0bc79762cec84f10764cdb9713568aa2792b'
QA = 'dc5388bf8539c4bbb697be74cb6fb57167f51428'
EXPECTED = 'e564d269009b90a1684a97d9f2fbb6fac50977c18a5006ca2aa897f2457a367e'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


OUT.mkdir(exist_ok=True)
assert not (OUT / 'review.json').exists()
archive = ROOT / 'qa/corpus-archive-cache.zip'
assert sha(archive.read_bytes()) == EXPECTED
assert archive.read_bytes() == git('show', QA + ':docs/qa/corpus-archive-cache-20261118.zip')
with zipfile.ZipFile(archive) as z:
    names = z.namelist()
    assert len(names) == len(set(names)) == 54 and z.testzip() is None
    manifest = json.loads(z.read('manifest.json'))
    assert manifest['source'] == SOURCE and manifest['production'] == PRODUCTION
    assert set(names) == {'manifest.json'} | {row['path'] for row in manifest['files']}
    for row in manifest['files']:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
    snapshots = json.loads(z.read('source-snapshots.json'))
    for row in snapshots:
        data = z.read(row['archive_path'])
        assert data == git('show', row['source'] + ':' + row['path']) and sha(data) == row['sha256']
        assert git('rev-parse', row['source'] + ':' + row['path']).decode().strip() == row['git_blob']
    junit = {}
    for name in names:
        if not name.endswith('.xml'):
            continue
        counts = Counter()
        for case in ET.fromstring(z.read(name)).findall('.//testcase'):
            skip = case.find('skipped')
            counts['failed' if case.find('failure') is not None else 'error' if case.find('error') is not None else
                   'expected_failure' if skip is not None and skip.get('type') == 'pytest.xfail' else
                   'skipped' if skip is not None else 'passed'] += 1
        junit[name] = dict(counts)
    assert junit['cache-final-affected.xml'] == {'passed': 495, 'expected_failure': 2}
    assert junit['cache-final-focused.xml'] == {'passed': 111, 'failed': 1}
    assert junit['tier-action-policy-corrected.xml'] == {'passed': 1}
    assert junit['original-four-after-cache.xml'] == {'passed': 2, 'failed': 2}

source_root = OUT / 'source-451e463d'
source_root.mkdir(exist_ok=False)
copied = []
for name in ('.github/workflows/corpus-tier-r.yml', 'tests/test_corpus_cache_integrity.py'):
    data = git('show', SOURCE + ':' + name)
    path = source_root / name
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream:
        stream.write(data)
    copied.append(dict(path=name, sha256=sha(data), git_blob=git('rev-parse', SOURCE + ':' + name).decode().strip()))
owned = Path(tempfile.mkdtemp(prefix='patchtrace-cache-review-'))
env = dict(os.environ, PYTHONPATH=str(source_root / 'tests'), QT_QPA_PLATFORM='offscreen',
           GIT_ALLOW_PROTOCOL='file', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null',
           GIT_TERMINAL_PROMPT='0', PATCHTRACE_OFFLINE_GUARD_RECEIPT=str(OUT / 'offline-guard.json'))
command = [sys.executable, str(ROOT / 'ops/continuation_offline_pytest.py'), '-q', '-ra', '-p', 'no:cacheprovider',
           str(source_root / 'tests/test_corpus_cache_integrity.py'), str(OUT / 'test_cache_boundary_review.py'),
           '--basetemp=' + str(owned / 'pytest'), '--junitxml=' + str(OUT / 'review.xml')]
context = dict(source=SOURCE, production=PRODUCTION, snapshots=copied, argv=command, cwd=str(source_root),
               started_utc=datetime.now(timezone.utc).isoformat(),
               boundary='Exact workflow bytes and original test copied without edits; tiny inert archives, '
                        'fixed downloader/pip stubs, actual bash/hash/tar/unzip only. Network denied before collection. '
                        'This is not the full candidate, authentic engine, hosted cache or native package acceptance.')
with (OUT / 'command.json').open('x') as stream:
    json.dump(context, stream, indent=2)
    stream.write('\n')
with (OUT / 'review.log').open('x') as stream:
    result = subprocess.run(command, cwd=source_root, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=120)
for row in copied:
    assert sha((source_root / row['path']).read_bytes()) == row['sha256']
record = dict(source=SOURCE, production=PRODUCTION, archive_members=len(names),
              archive_sha256=EXPECTED, git_snapshots_verified=len(snapshots), author_junit=junit,
              independent_exit=result.returncode, copied_bytes_unchanged=True,
              temp=str(owned), temp_retained=result.returncode != 0)
if result.returncode == 0:
    shutil.rmtree(owned)
with (OUT / 'review.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
print((OUT / 'review.log').read_text())
raise SystemExit(result.returncode)
