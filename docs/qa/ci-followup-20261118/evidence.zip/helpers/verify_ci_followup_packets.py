"""Independently check the sealed smoke and import-boundary history before porting."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = ROOT / 'qa/ci-followup-root-review'
OUT.mkdir(exist_ok=False)


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def blob(ref, name):
    return git('show', ref + ':' + name)


def sha(data):
    return hashlib.sha256(data).hexdigest()


packets = [
    ('linux-full-frozen-smoke', 'a07985ca804b6b54559f4e88d46757152f631216',
     '54db8bf76d790f12b8c5fdf4845473777a6d52a9d9e50208ea837ef2e161f541', 56, 27),
    ('directory-publication-import-purity', '15f2546d0263b555ea11eccd560abf3a252fa750',
     '8e9af84acae6024a48c143bfdb3480a33829b44631ed7e1e075700bc223765c4', 40, 16),
]
verified = []
for label, commit, expected, members, sources in packets:
    path = ROOT / 'qa' / (label + '.zip')
    data = path.read_bytes()
    assert sha(data) == expected and data == blob(commit, f'docs/qa/{label}-20261118.zip')
    with zipfile.ZipFile(path) as z:
        names = z.namelist()
        assert len(names) == len(set(names)) == members and z.testzip() is None
        manifest = json.loads(z.read('manifest.json'))
        assert {row['path'] for row in manifest['files']} == set(names) - {'manifest.json'}
        for row in manifest['files']:
            item = z.read(row['path'])
            assert len(item) == row['bytes'] and sha(item) == row['sha256']
        snapshots = json.loads(z.read('source-snapshots.json'))
        assert len(snapshots) == sources
        for row in snapshots:
            item = z.read(row['archive_path'])
            assert item == blob(row['source'], row['path']) and sha(item) == row['sha256']
            assert git('rev-parse', row['source'] + ':' + row['path']).decode().strip() == row['git_blob']
        junit = {}
        for name in names:
            if not name.endswith('.xml'):
                continue
            counts = Counter()
            for case in ET.fromstring(z.read(name)).findall('.//testcase'):
                skip = case.find('skipped')
                counts['failed' if case.find('failure') is not None else 'errors' if case.find('error') is not None else
                       'expected_failure' if skip is not None and skip.get('type') == 'pytest.xfail' else
                       'skipped' if skip is not None else 'passed'] += 1
            junit[name] = dict(counts)
        verified.append(dict(label=label, qa=commit, archive_sha256=expected, members=members,
                             git_snapshots=sources, junit=junit))

base = '068513a72e8a1412ce3960d3024c462d68d51376'
purity = '73bd7eadd1fa279cd1f7ea6887029b85e6c55430'
path = 'src/patchtrace/directory_publication.py'


class WithoutCtypesImport(ast.NodeTransformer):
    def visit_Import(self, node):
        if len(node.names) == 1 and node.names[0].name == 'ctypes' and node.names[0].asname is None:
            return None
        return node


old = WithoutCtypesImport().visit(ast.parse(blob(base, path)))
new = WithoutCtypesImport().visit(ast.parse(blob(purity, path)))
assert ast.dump(old) == ast.dump(new)
assert blob(base, 'tests/test_unified_packaging.py') == blob(purity, 'tests/test_unified_packaging.py')
old_assertions = [ast.dump(node) for node in ast.walk(ast.parse(blob(base, 'tests/test_directory_publication.py')))
                  if isinstance(node, ast.Assert)]
new_assertions = [ast.dump(node) for node in ast.walk(ast.parse(blob(purity, 'tests/test_directory_publication.py')))
                  if isinstance(node, ast.Assert)]
assert old_assertions == new_assertions

smoke = 'dd0ad00b0c3a8a1e2e95f06f3dce1de944520783'
smoke_before = '509199faea04c01cb96742f81932571d409d2f85'
old = ast.parse(blob(smoke_before, 'tools/frozen_smoke.py'))
new = ast.parse(blob(smoke, 'tools/frozen_smoke.py'))
assert isinstance(old.body[0], ast.Expr) and isinstance(new.body[0], ast.Expr)
assert isinstance(old.body[0].value, ast.Constant) and isinstance(new.body[0].value, ast.Constant)
old.body.pop(0)
new.body.pop(0)
assert ast.dump(old) == ast.dump(new)
assert not git('diff', smoke, '2a7e3147abda0450840e885dc075cf319a59ccaa', '--', 'src', 'tools', '.github')
assert set(git('diff', '--name-only', smoke_before, smoke).decode().splitlines()) == {
    'tools/build_linux.py', 'tools/frozen_smoke.py'}
record = dict(packets=verified, purity_only_import_placement_changed=True,
              original_purity_file_unchanged=True, original_publication_assertions_unchanged=len(old_assertions),
              frozen_harness_logic_unchanged=True, smoke_lint_followup_changes_no_production=True,
              review='Full specification, original/red control and production deltas read. '
                     'Independent combined candidate replay follows selective port; no native/package success inferred.')
with (OUT / 'archive-and-source-review.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
