"""Seal exact CI follow-up acceptance and preserve source-specific hosted failures."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
SOURCE = 'f3b7a0e895c3b9928e08f93ac77d2afda5c56dd8'
BASE = '12f5ff324572afdd039e7a55515c9d3ade001340'
MAIN = '9c411ca3d7b47f950be5f0c6f01b3c54184554c6'
QA = ROOT / 'qa/ci-followup-integration'
DEST = REPO / 'docs/qa/ci-followup-20261118'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE and not git('status', '--porcelain')
tree = git('rev-parse', 'HEAD^{tree}').decode().strip()
gate = json.loads((QA / 'combined-exit.json').read_text())
assert gate['exit'] == 0 and gate['source_after'] == SOURCE and not gate['status_after']
assert gate['imported_source_count'] == 221 and not gate['foreign_imports']
assert not gate['imported_source_drift'] and not gate['imported_sources_not_exact_git']
assert gate['original_external_probe_unchanged'] and not gate['temp_retained']
counts = Counter()
for case in ET.parse(QA / 'combined.xml').getroot().findall('.//testcase'):
    skip = case.find('skipped')
    kind = 'failed' if case.find('failure') is not None else 'error' if case.find('error') is not None else (
        'xfail' if skip is not None and skip.get('type') == 'pytest.xfail' else 'skipped' if skip is not None else 'passed')
    counts[kind] += 1
assert dict(counts) == {'passed': 1028, 'xfail': 1, 'skipped': 2}
owners = json.loads((QA / 'source-owner-preservation.json').read_text())
assert owners['source'] == SOURCE and len(owners['files']) == 10
for row in owners['files']:
    assert sha((REPO / row['path']).read_bytes()) == row['sha256']
lint = json.loads((QA / 'ruff-receipts.json').read_text())
strict = json.loads((QA / 'strict-sites-comparison.json').read_text())
assert lint[0]['exit'] == 0 and lint[1]['exit'] == 1 and lint[1]['findings'] == 80
assert strict['same_path_code_selected_statement_multiset']
fresh = json.loads((QA / 'fresh-before-publication.json').read_text())
reads = {row['path']: json.loads(row['result']['structuredContent']['content']) for row in fresh['reads']}
assert reads['branches/main']['commit']['sha'] == MAIN
assert reads['pulls/316']['head']['sha'] == 'f3f4492981f2c76c8d461d6a6d3eb1ac682fb996'
assert not reads['pulls/316']['merged'] and reads['pulls/316']['state'] == 'open'
commits = git('rev-list', '--reverse', BASE + '..' + SOURCE).decode().splitlines()
assert len(commits) == 12
assert all('[no release]' in git('show', '-s', '--format=%B', commit).decode() for commit in commits)

note = f'''# Cache, full Linux smoke and publication import purity — 2026-11-18

## Qualified bounded source

Exact clean candidate `{SOURCE}`, tree `{tree}`, passes **1,028 tests** with
**two explicit skips and one existing expected failure**, zero failures/errors,
in **22.89 seconds**. The 30-file selection is the union of all three author
affected scopes plus independent cache and publication probes. All 221 imported
PatchTrace modules match this commit's Git bytes, with no foreign imports or
drift. All ten changed source/test/tool/workflow files since `{BASE}` exactly
match reviewed author bytes. No production conflict required manual resolution.

Normal `ruff check src tests tools` passes. The isolated, ignore-noqa strict S
scan still fails on **80 unchanged path/code/selected-statement sites**. These
are scoped regression results; full Linux/Windows/Qt/native/frozen/package,
dependency/security and reproducibility acceptance remain incomplete.

## Integrated changes and independent review

| Slice | Behavior | Reviewed source / retained evidence |
| --- | --- | --- |
| Corpus archive cache | Cache original Rizin/Ghidra archives; validate pin syntax, type and SHA on both cache hits and cold paths; extract into an exclusively fresh runtime directory. Corrupt archives, symlinks, FIFOs and preexisting runtime objects refuse without running payloads. | `451e463d25e625c55344ac232fd9de90275b9013`; 54-member author packet and independent 26-pass shell control. Cooperative CI workspace boundary, without an active-writer race claim. |
| Full Linux frozen smoke | Invoke the existing complete `tools/frozen_smoke.py` harness against the new frozen executable before archive/digest creation, with a 900-second timeout. | `2a7e3147abda0450840e885dc075cf319a59ccaa`; 56-member author packet. Author gate's preexisting IR import-purity failure is preserved. This local gate exercises builder controls and source CLI smoke, not a new frozen build. |
| Publication import purity | Load Linux ctypes only when Linux native publication is actually dispatched. Windows/unsupported dispatch and pure IR imports no longer import ctypes. | `73bd7eadd1fa279cd1f7ea6887029b85e6c55430`; 40-member packet. Native move logic, ownership checks and all 32 existing publication assertions remain unchanged. |

The coordinator verified all 96 smoke/purity archive members and 43 canonical
Git snapshots, and the cache packet's 54 members and 22 Git snapshots. The
smoke harness AST is unchanged after its documentation string; the purity
production AST is unchanged after moving the ctypes import. Original failed
assertions, intermediate fixture/lint/collection errors and original author
results remain attributed to their own source and are not relabeled.

The independent archived publication probe formerly patched private
`publisher.ctypes`. A fresh replay copy changes exactly two injection targets to
the same already imported `ctypes` module. Every assertion and all other AST
nodes are identical; the original probe file remains byte-for-byte unchanged.
This adaptation is explicit in `external-probe-adaptation.json`.

The two skips require native Windows junction creation and host-denied AF_UNIX
socket creation. CODEX5 dependency hash closure is the sole remaining expected
failure in this scope. Cache verification and full-smoke policies are now normal
required assertions. The duplicate-ZIP fixture emits its expected warning.

Execution installs the retained Linux network-denial filter before collection,
rejects inherited sockets, restricts Git to local files and uses an owned system
temporary directory outside any repository. The audit saw 190 hostname events,
one denied AF_UNIX creation and 254 inspected local fixture/CLI/Git subprocess
invocations. The temporary directory was removed after success. This execution
guard is not a native product sandbox qualification.

## Preceding publication and fresh hosted evidence

At `{fresh['at']}`, main remained `{MAIN}` and PR316 remained open at
`f3f4492981f2c76c8d461d6a6d3eb1ac682fb996`. The preceding 45-commit append was
independently reread and published with a non-force expected-head lease. Its
tree `e49299eabe4cff2304d9dbe15f94c3c79566af44` equals local `{BASE}`. Preview
`a94495abb6117400c138eaaa0127d260c3010094` has main and actual f3 head as parents
and that same tree. Original publication receipts are retained here.

New hosted observations belong to that **preceding f3/preview tree**, not this
new local CI follow-up. Four downloaded artifacts match both API SHA-256 and
byte size; all member CRCs/hashes are retained. Native binaries in the BinDiff
artifact were read only as evidence and were not executed locally.

- Windows BinDiff now builds the native helper and passes six authored controls,
  including its 20/21-function synthetic end-to-end pair. Its no-network control
  fails: restricted control process chain exit125. Actual pytest and `bindiff.json`
  fail despite the job-level success status. There is no Windows no-network or
  representative-binary accuracy acceptance. Detailed diagnosis is assigned.
- Windows runtime and packaging dependency profiles get past source verification
  and scanner installation, then `python -I -m pip inspect --local` exits2 with
  a CP1252 UnicodeEncodeError for U+1F44B. This is a new, retained downstream
  failure; neither profile reaches product dependency-audit acceptance.
- Hosted static scanning reaches its strict scan and fails. Its artifact now
  retains `bootstrap-pip.txt`, establishing delivery of that prior upload repair.
  The complete hosted diagnostic/site comparison remains a separate review.

Job badges are not acceptance. Other hosted full/platform/native jobs are not
qualified by this packet. The old f3 gate remains 6,356 passed /18 skipped /three
expected failures at its own source; this later result does not alter it.

## Remaining work and release state

No PR has been merged or closed, no branch deleted, and no main/tag/release/
deployment ref changed. The 12 local follow-up commits retain `[no release]`;
their append-only remote publication and readback are separate receipts.

Portable serial worker grants and neutral held-input/core checkpoints are under
independent review. A persisted-signal navigation defect has preserved original
failures and an isolated repair in progress. Native worker transfer, rooted
stage/FDI, KB propagation, durable package provenance and a real frozen intake
journey remain open. Dependency hash closure and the newly observed Windows
encoding/native control failures continue independently. Whole PW02 and beta
readiness are not established. Frozen L1/L2/L3 outcomes remain unchanged.
'''

payloads = {'checkpoint-note.md': note.encode(), 'counts.json': (json.dumps(counts, indent=2)+'\n').encode()}
for label, path in (
    ('combined', QA), ('cache-root-review', ROOT/'qa/corpus-cache-root-review'),
    ('archive-root-review', ROOT/'qa/ci-followup-root-review'),
    ('preceding-hosted-f3', ROOT/'qa/hosted-pr316-f3')):
    for file in sorted(path.rglob('*')):
        if file.is_file() and '__pycache__' not in file.parts:
            payloads[label+'/'+file.relative_to(path).as_posix()] = file.read_bytes()
for name in ('objects-045.json', 'readback-before-ref.json', 'ref-update.json', 'published-readback.json',
             'pr316-body.md', 'pr-update.json', 'final-readback.json'):
    payloads['preceding-publication/'+name] = (ROOT/'qa/continuation-tail-publication'/name).read_bytes()
for name in ('run_ci_followup_gate.py','scan_ci_followup.py','review_corpus_cache_tail.py',
             'verify_ci_followup_packets.py','continuation_offline_pytest.py','full_batch_receipt.py',
             'seal_ci_followup_checkpoint.py'):
    payloads['helpers/'+name] = (ROOT/'ops'/name).read_bytes()
for path in git('diff','--name-only',BASE,SOURCE,'--','src','tests','tools','.github','docs/specs','docs/schemas').decode().splitlines():
    payloads['candidate-source/'+path] = git('show',SOURCE+':'+path)
payloads['integration/history.txt'] = git('log','--reverse','--format=fuller',BASE+'..'+SOURCE)
payloads['integration/patch.diff'] = git('diff',BASE,SOURCE,'--','src','tests','tools','.github','docs/specs','docs/schemas')
records=[json.loads(line) for line in (ROOT/'qa/followup-integration/record-resolutions.jsonl').read_text().splitlines()]
payloads['integration/append-conflicts.json']=(json.dumps([row for row in records if row['head'] in {BASE,*commits}],indent=2)+'\n').encode()
DEST.mkdir(exist_ok=False)
archive=DEST/'evidence.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path,data in sorted(payloads.items()):z.writestr(path,data)
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist())==len(set(z.namelist()))==len(payloads) and z.testzip() is None
    for path,data in payloads.items():assert z.read(path)==data
manifest=dict(source=SOURCE,tree=tree,sealed_utc=datetime.now(timezone.utc).isoformat(),
              archive=archive.name,archive_bytes=archive.stat().st_size,archive_sha256=sha(archive.read_bytes()),
              payloads=[dict(path=path,bytes=len(data),sha256=sha(data)) for path,data in sorted(payloads.items())])
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(DEST/'README.md').write_text(note+f'\n## Sealed archive\n\n{len(payloads)} verified payloads; {archive.stat().st_size:,} bytes. SHA-256 `{manifest["archive_sha256"]}`.\n')
short=f'''\n\n## CI follow-up — 2026-11-18, source f3b7a0e8

Source `{SOURCE}` integrates independently reviewed archive-cache verification,
full Linux frozen-smoke wiring and lazy publication ctypes imports. Exact
30-file gate: **1,028 passed, two explicit skips, one CODEX5 expected failure**,
zero failures/errors,22.89s. All221 imported modules and ten changed owner files
match Git bytes. Normal Ruff passes; strict S remains80 unchanged findings and
fails. The preceding PR316 f3 checkpoint was published with a verified non-force
lease; main remains `{MAIN}`. No merge/release/platform acceptance follows.
[Source-specific checkpoint](../qa/ci-followup-20261118/README.md).
'''
with (REPO/'docs/plans/patchtrace-completion-matrix.md').open('a') as f:
    f.write(short+'''

| Feature / bounded scope | Current state | Completion | Remaining work | Source | Dependencies | Tests | Security | Owner | Acceptance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Cached engine archive verification | Implemented and independently reviewed | D,R:50% for this slice | Hosted exact-source cold/cache-hit gates and full qualification |451e463d, PR316|Existing pins/download endpoints|Original failures,26 root checks,combined1,028|Verify before extraction; cooperative workspace boundary|CI + root|Native/hosted/final G remains open|
| Full Linux frozen smoke invocation | Implemented and independently reviewed | D,R:50% for this slice | Actual new frozen executable/package gate |2a7e3147, PR316|Existing complete smoke harness|Required policy,5 builder controls,source CLI and combined gate|Failure/timeout prevents archive creation|CI + root|Actual artifact smoke and final G|
| Pure IR import / native FFI boundary | Implemented and independently reviewed | D,R:50% for this slice | Native Windows and complete final gates |73bd7ead, PR316|Existing no-replace publication|Fresh subprocess imports,all existing ownership assertions,independent replay|No import-time FFI; move behavior unchanged|CI + root|Pure imports plus native/final G|

Whole PW02 remains partial with no package-to-project journey. New Windows
dependency encoding and BinDiff no-network failures are preserved on the prior
f3/preview tree and assigned for focused diagnosis; successful job badges do not
qualify those failed receipts. Worker grants, neutral core readers and signal
navigation are separate candidates under review, absent from this source.
''')
with (REPO/'docs/plans/autonomous-consolidation-20261118/consolidation-ledger.md').open('a') as f:
    f.write(short.replace('../qa/','../../qa/'))
with (REPO/'docs/qa.md').open('a') as f:
    f.write(short.replace('../qa/','qa/'))
with (REPO/'tasks/todo.md').open('a') as f:
    f.write('''\n\n### CI follow-up checkpoint — 2026-11-18

- [x] Verify preceding45-commit append-only PR316 publication and main/preview readback.
- [x] Independently review/port cache, full smoke and import-purity fixes; exact30-file gate1,028pass/two skips/one CODEX5 xfail.
- [x] Preserve ten owner paths,221 Git-pinned imports,unchanged strict80 findings and original probes.
- [x] Retain API-hash-verified prior-f3 Windows dependency/BinDiff/static artifacts, including actual failures despite job success.
- [ ] Publish this reviewed checkpoint append-only with exact object/ref/preview readback.
- [ ] Finish independent worker/core/navigation reviews and integrate eligible repairs.
- [ ] Diagnose and fix Windows pip inspection encoding and restricted-control exit125 without weakening gates.
- [ ] Complete dependency hash closure, native intake/KB/durable provenance and all actual-candidate final acceptance.
''')
print(json.dumps(dict(source=SOURCE,tree=tree,members=len(payloads),archive_bytes=archive.stat().st_size,archive_sha256=manifest['archive_sha256'])))
