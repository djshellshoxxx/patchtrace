"""Independent cooperative-workspace refusals for exact corpus setup scripts."""
import os
from pathlib import Path

import pytest
import test_corpus_cache_integrity as author


@pytest.mark.parametrize('kind', author.KINDS)
def test_cold_malformed_digest_refuses_before_downloader(tmp_path, kind):
    result, trace, exported = author._run(tmp_path, kind, hit=False, bad_pin=True)
    assert result.returncode != 0 and trace == [] and not exported.exists()
    assert not author._runtime_file(tmp_path, kind).exists()


@pytest.mark.parametrize('kind', author.KINDS)
def test_fifo_archive_refuses_without_opening_or_blocking(tmp_path, kind, monkeypatch):
    cache, _ = author._steps(kind)
    cached = tmp_path / cache['with']['path']
    original = Path.write_bytes

    def write(path, data):
        if path == cached:
            os.mkfifo(path)
            return len(data)
        return original(path, data)

    monkeypatch.setattr(Path, 'write_bytes', write)
    result, trace, exported = author._run(tmp_path, kind, hit=True)
    assert result.returncode != 0 and trace == [] and not exported.exists()
    assert cached.is_fifo()


@pytest.mark.parametrize('kind', author.KINDS)
def test_dangling_archive_link_is_not_replaced_by_download(tmp_path, kind, monkeypatch):
    cache, _ = author._steps(kind)
    cached = tmp_path / cache['with']['path']
    original = Path.symlink_to

    def link(path, target, target_is_directory=False):
        return original(path, tmp_path / 'missing-owned-target' if path == cached else target,
                        target_is_directory=target_is_directory)

    monkeypatch.setattr(Path, 'symlink_to', link)
    result, trace, exported = author._run(tmp_path, kind, hit=True, cache_object='symlink')
    assert result.returncode != 0 and trace == [] and not exported.exists()
    assert cached.is_symlink() and not cached.exists()


@pytest.mark.parametrize('kind', author.KINDS)
@pytest.mark.parametrize('runtime_type', ['file', 'symlink'])
def test_runtime_file_and_directory_link_are_preserved(tmp_path, kind, runtime_type):
    runtime = tmp_path / ('rizin' if kind == 'rizin' else 'ghidra-runtime')
    sentinel = b'foreign runtime remains unchanged'
    if runtime_type == 'file':
        runtime.write_bytes(sentinel)
    else:
        foreign = tmp_path / 'other-owned-directory'
        foreign.mkdir()
        (foreign / 'sentinel').write_bytes(sentinel)
        runtime.symlink_to(foreign, target_is_directory=True)
    result, trace, exported = author._run(tmp_path, kind, hit=True)
    assert result.returncode != 0 and trace == ['sha256sum'] and not exported.exists()
    if runtime_type == 'file':
        assert runtime.read_bytes() == sentinel
    else:
        assert runtime.is_symlink() and (foreign / 'sentinel').read_bytes() == sentinel
        assert list(foreign.iterdir()) == [foreign / 'sentinel']
