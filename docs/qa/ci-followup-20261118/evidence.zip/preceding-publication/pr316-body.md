## Purpose

Consolidate the reviewed #304 → #307 chain and independently reproduced follow-up repairs while preserving original failures, source attribution, immutable evidence, and the `[no release]` hold.

**This PR is not ready to merge into main.** Full candidate, native Windows, package, dependency/security and representative product-journey gates remain incomplete. No release, tag or deployment is authorized.

## Current published checkpoint

| Identity | Exact value |
| --- | --- |
| Canonical main SHA | `9c411ca3d7b47f950be5f0c6f01b3c54184554c6` |
| Actual PR head | `f3f4492981f2c76c8d461d6a6d3eb1ac682fb996` |
| Actual PR tree | `e49299eabe4cff2304d9dbe15f94c3c79566af44` |
| Equal-tree local checkpoint | `12f5ff324572afdd039e7a55515c9d3ade001340` |
| Locally tested source | `068513a72e8a1412ce3960d3024c462d68d51376` |
| Corresponding remote source commit | `e79e1a60df36ccf2935dc338acc43241f312f247` |
| Tested-source tree | `2183dcf3b9cfee268c3ebb163ad9f3e9e928e10f` |

The final checkpoint adds QA/tracking records only; source, tests, tools, workflows, specifications and schemas are unchanged from the tested source. This equivalence is explicit; it is not a claim that the final hosted/full/native gates ran locally.

Publication appended **45 commits** to actual prior head `14efc52369146f4a638b7d688208736a05321bc0`, with a non-force expected-head lease. Every reconstructed commit's tree, single parent, local-source attribution and no-release marker were independently reread before advancement. Original local authors, source history and patches are retained in the evidence.

Fresh reads show #304 open at `d8c02caea407f6d323eecd636735849c1eb31a2d` and #307 open at `58fc130631f602b6e907bb054d30c21d810551d4`; both are verified ancestors of this candidate's local history. This milestone merged or closed no PR and changed no main ref.

## Changes in this tail

- **Saved advisory scope:** validate finite stored coverage before components, pairs, plans, acquisition/import, inventory selection and all selected recovery writes. Preserve full-global revision admission and legacy cached receipts; changed admitted counterevidence changes context identity.
- **A/A reporting:** retain nonidentical rebuilds as failures through shard storage, merged provenance and CLI output, preserving other command/status semantics.
- **Optional COFF compatibility:** consume complete unquoted COFF symbols in the existing source-layer mask. The normal mutation factory does not invoke this optional check; the original caller-description mistake has a separately retained erratum.
- **Static bootstrap receipts:** include existing text receipts in strict-scanner artifact upload without changing scanner rules or installation behavior.
- **Windows source observations:** compare compatible path/descriptor metadata while retaining complete same-view states; preserve descriptor ChangeTime through final tree checks and stable dependency-receipt reads.
- **PW02 preparatory contracts:** add strict local package identities, raw-name/collision rules, container ownership, bounded shared accounting and generated schemas. The independently reproduced Unicode-to-ASCII basename alias is fixed. No stage, native decoder, worker, CLI or package-to-project route is enabled by this slice.
- **Action immutability:** pin 178 mutable uses in 21 workflows to 11 canonically resolved commits from their same existing refs. Preserve eight prior immutable uses and every other raw/YAML workflow field. Neighboring policy tests now require exact/full commit references.

## Executed source-specific checks

| Check | Result and scope |
| --- | --- |
| Reviewed 215-file combined gate | **6,356 passed / 18 skipped / 3 known xfailed**, zero unexpected failures/errors, **385.72 s**, at local `068513a7` |
| Source import audit | **552** project imports from the exact checkout; no foreign imports or source drift |
| Owner-byte audit | **101** changed source/test/tool/workflow/schema paths match independently reviewed owner bytes |
| Original observation integrity | Public saved-scope, R2 and A/A probe bytes and prior observation hashes preserved |
| Configured Ruff | `ruff check src tests tools` passed |
| Unsuppressed strict security scan | **Failed: 80 findings**, same path/code/selected-statement multiset as preceding qualified source |
| Action provenance | All **23 canonical API objects**, **22 workflow raw/YAML comparisons** and **61 Git snapshots** independently checked |
| Current checkpoint archive | **193 verified payloads**, 2,666,429 bytes; SHA-256 `e730ae18527bb4a0f2c2bc34071e567c68707203e7777f6b8cc8fb8a8b92a576` |

The execution wrapper installs inherited Linux network denial before collection, rejects inherited sockets, restricts Git transports to local files and uses an owned system temporary directory. No tests or assertions are deselected by the wrapper. The 18 skips comprise 16 native Windows controls, one optional colorspacious oracle and one host-denied AF_UNIX capability. Live BinDiff explicitly reports BLOCKED locally.

The three retained expected failures are CODEX5 dependency hash closure, CODEX6 cache verification and CODEX14 full Linux frozen CLI smoke. Separate cache/smoke repairs and a reproduced import-purity repair are undergoing integration after this frozen checkpoint; their later results do not change this gate's counts.

## Branch reconciliation and preserved evidence

All **131 original branch-name focal scopes** now have exact-tip dispositions, with zero remaining unselected in that original partition. This is neither whole-branch closure nor a product-completion percentage. Broader research/native/platform residue and incomplete workflows remain explicit.

All original product failures, contrary controls, historical fixture/policy mismatches, intermediate collection/setup errors and reviewer corrections remain attributed to their original source. Frozen L1/L2/L3 outcomes were not rewritten. The earlier incomplete broad run remains incomplete; #304's older full-suite/package passes do not qualify this newer source.

The older hosted14ef packet establishes limited authored Linux BinDiff positives and the original Windows source-guard failures before native compilation/scanning. Its strict scan completed with80 findings and omitted the bootstrap text artifact. The specific stat-field cause was not logged; native confirmation of the current repair remains required.

## Remaining gates and active work

- Complete actual-candidate Linux/Windows full suites, repeated Qt, native engine acceptance, frozen ZIP/installer/Linux packages, dependency/security and reproducibility evidence.
- Independently integrate the separate cache verification, full frozen smoke and import-purity handoffs.
- Implement/review serial package worker grants and neutral core held-reader/checkpoint propagation; then qualify native transfer/stage/FDI and the existing KB path with durable project provenance.
- Reconcile the Phase2 reference contract and the reproduced persisted-signal navigation boundary without changing confidence/calibration semantics.
- Finish complete platform/profile dependency hash-lock coverage and its source-specific acceptance.
- Keep L1's original six failures, L2 independent-ground-truth requirement and L3 source/permission/binary blockers explicit.

## Reviewable records

- [Complete current checkpoint and limits](https://github.com/djshellshoxxx/patchtrace/blob/f3f4492981f2c76c8d461d6a6d3eb1ac682fb996/docs/qa/continuation-tail-20261118/README.md)
- [Evidence manifest](https://github.com/djshellshoxxx/patchtrace/blob/f3f4492981f2c76c8d461d6a6d3eb1ac682fb996/docs/qa/continuation-tail-20261118/manifest.json)
- [Completion matrix](https://github.com/djshellshoxxx/patchtrace/blob/f3f4492981f2c76c8d461d6a6d3eb1ac682fb996/docs/plans/patchtrace-completion-matrix.md)
- [Consolidation ledger](https://github.com/djshellshoxxx/patchtrace/blob/f3f4492981f2c76c8d461d6a6d3eb1ac682fb996/docs/plans/autonomous-consolidation-20261118/consolidation-ledger.md)
- [Final original focal partition](https://github.com/djshellshoxxx/patchtrace/blob/f3f4492981f2c76c8d461d6a6d3eb1ac682fb996/docs/plans/autonomous-consolidation-20261118/semantic-disposition-batch7.md)
- [Older-source hosted evidence](https://github.com/djshellshoxxx/patchtrace/blob/f3f4492981f2c76c8d461d6a6d3eb1ac682fb996/docs/qa/hosted-pr316-14ef-20261118/README.md)

**No beta-ready classification; no main merge, release, tag or deployment.**
