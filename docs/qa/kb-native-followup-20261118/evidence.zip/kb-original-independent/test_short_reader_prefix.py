"""A legitimate short held read must not erase known PE architecture evidence."""
import json
import os
from pathlib import Path

from held_input_support import authored_pair, deny_source_opens
import pytest

from patchtrace.kbcorrelation.wiring import inspect_local_file


@pytest.mark.parametrize('limit', [None, 4096, 1, 17, 127])
def test_held_inspection_preserves_complete_bounded_header(tmp_path, monkeypatch, limit):
    with authored_pair(tmp_path/'inputs', padding=64) as (paths, readers):
        source = paths[0]
        expected = inspect_local_file(str(source))
        assert expected.machine == 'amd64'
        readers.older.read_limit = limit
        deny_source_opens(monkeypatch, paths)
        actual = inspect_local_file(str(source), reader=readers.older)
        observation = dict(limit=limit, expected_machine=expected.machine, actual_machine=actual.machine,
            hash_equal=actual.sha256==expected.sha256, size_equal=actual.size==expected.size,
            bytes_read=readers.older.bytes_read, expected_size=expected.size,
            opened=readers.older.opened, closed=readers.older.closed)
        out=Path(os.environ['PATCHTRACE_KB_SHORT_READ_OBSERVATIONS'])
        out.mkdir(parents=True,exist_ok=True)
        with (out/f'{limit}.json').open('x') as stream:
            json.dump(observation,stream,indent=2)
            stream.write('\n')
        assert actual.sha256 == expected.sha256 and actual.size == expected.size
        assert actual.basename == expected.basename
        assert readers.older.bytes_read == expected.size
        assert readers.older.opened == readers.older.closed == 1 and not readers.older.active
        assert actual.machine == expected.machine, observation
