# Security terminology clarification for the frozen fb09 hosted receipt

The hosted packet uses "untriaged" for the strict scanner's 80 emitted findings.
That correctly retains its failed, unsuppressed automated disposition, but does
not mean no human source review occurred. The earlier sealed
`docs/qa/security-residual-triage-20261118.md` and its ledger disposition all 80
sites. The current candidate's independent strict comparison still finds exactly
the same path/code/selected-statement multiset, with exit 1.

Manual disposition has not waived or satisfied the required scanner gate. These
are 80 detector findings, not 80 confirmed vulnerabilities. This clarification
adds interpretation without editing the original hosted payloads, scan output,
prior outcomes or archived README.
