"""Independent, read-only verification of the next KB/native author packets."""
from __future__ import annotations

import ast
import hashlib
import io
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = ROOT / 'qa/kb-native-followup-root-review'
OUT.mkdir(exist_ok=False)


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def blob(commit, path):
    return git('show', commit + ':' + path)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(name, data):
    with (OUT / name).open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


def archive(raw, manifest, expected, include_manifest):
    assert sha(raw) == expected['sha256'] and len(raw) == expected['bytes']
    z = zipfile.ZipFile(io.BytesIO(raw))
    names = z.namelist()
    assert len(names) == len(set(names)) == expected['members'] and z.testzip() is None
    assert set(names) == {r['path'] for r in manifest['files']} | ({'manifest.json'} if include_manifest else set())
    for row in manifest['files']:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
    if include_manifest:
        assert json.loads(z.read('manifest.json')) == manifest
    return z


def junit(z):
    counts = {}
    for name in z.namelist():
        if name.endswith('.xml'):
            cases = list(ET.fromstring(z.read(name)).iter('testcase'))
            counts[name] = dict(tests=len(cases), failures=sum(c.find('failure') is not None for c in cases),
                                errors=sum(c.find('error') is not None for c in cases),
                                skipped=sum(c.find('skipped') is not None for c in cases))
    return counts


def symbols(raw):
    lines, found = raw.splitlines(keepends=True), {}
    def visit(nodes, prefix=''):
        for node in nodes:
            if isinstance(node, ast.ClassDef):
                visit(node.body, prefix + node.name + '.')
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                start = min([node.lineno, *[d.lineno for d in node.decorator_list]])
                found[prefix + node.name] = (b''.join(lines[start-1:node.end_lineno]), ast.dump(node, include_attributes=False))
    visit(ast.parse(raw).body)
    return found


kb_base = '9ad2ec5cdbde85155fdca3cdd88804fd8b2e1a53'
kb_source = 'd9a939911f39f3641bd5eed97a2ce067d618856b'
kb_qa = 'b2174a249c748487dba58bca6ffda48e56706e9c'
stem = 'docs/qa/kb-held-input-propagation-20261118'
seal = json.loads(blob(kb_qa, stem + '.json'))
assert seal['sha256'] == '3371fd77e415259e04ebbd22674280d31fa9443784b70e627dbdd2cbab73de8f'
raw = blob(kb_qa, stem + '.zip')
manifest = json.loads(zipfile.ZipFile(io.BytesIO(raw)).read('manifest.json'))
with archive(raw, manifest, seal, True) as z:
    snapshots = json.loads(z.read('git-snapshots.json'))['snapshots']
    for row in snapshots:
        data = blob(row['git_commit'], row['git_path'])
        assert data == z.read(row['path']) and len(data) == row['bytes'] and sha(data) == row['sha256']
        assert git('rev-parse', row['git_commit'] + ':' + row['git_path']).decode().strip() == row['git_blob']
    proof = json.loads(z.read('source-proof.json'))
    for row in proof['unchanged_symbols']:
        before = symbols(blob(kb_base, row['path']))[row['name']]
        after = symbols(blob(kb_source, row['path']))[row['name']]
        assert before == after and sha(after[0]) == row['sha256'] and len(after[0]) == row['bytes']
    for row in proof['unchanged_paths']:
        assert blob(kb_base, row['path']) == blob(kb_source, row['path'])
        assert sha(blob(kb_source, row['path'])) == row['sha256']
    for path in proof['core_equal_files']:
        assert blob(proof['core_reference'], path) == blob(kb_source, path)
    originals = json.loads(z.read('original-preservation.json'))['files']
    for row in originals:
        data = Path(row['original_path']).read_bytes()
        assert data == z.read(row['path']) and sha(data) == row['sha256'] and len(data) == row['bytes']
    counts = junit(z)
    expected = {'spec-red.xml': (33,32), 'first-source-focused.xml': (33,0), 'final-focused.xml': (39,0),
                'short-prefix-spec-red.xml': (12,6), 'short-prefix-source-green.xml': (50,0),
                'original-independent/initial.xml': (5,3), 'short-prefix-original-green.xml': (5,0),
                'affected-source-green.xml': (300,0)}
    for name, (total, failed) in expected.items():
        assert counts[name] == dict(tests=total, failures=failed, errors=0, skipped=0)
    import_counts = {}
    for name in ('affected-source-green', 'short-prefix-original-green'):
        receipt = json.loads(z.read(name + '-source-proof.json'))
        assert receipt['head'] == kb_source
        for row in receipt['sources']:
            assert sha(blob(kb_source, row['path'])) == row['sha256']
        import_counts[name] = len(receipt['sources'])
    history = json.loads(z.read('history.json'))
    parent = history['design_pick_excluded']
    for row in history['commits']:
        fields = git('show','-s','--format=%H%x00%T%x00%P%x00%s',row['commit']).decode().strip().split('\0')
        assert fields[:3] == [row['commit'], row['tree'], parent] and '[no release]' in fields[3]
        assert git('show','--format=fuller','--binary',row['commit']) == z.read('commits/'+row['commit'][:8]+'.patch')
        parent = row['commit']
    assert parent == kb_source
    assert git('diff','--name-only',kb_base,kb_source,'--','src').decode().splitlines() == proof['changed_production']
    assert not git('diff',kb_base,kb_source,'--','tools','.github','docs/schemas')
    assert not git('diff',kb_source,kb_qa,'--','src','tests','tools','.github','docs/specs','docs/schemas','pyproject.toml')
    write('kb-archive-verification.json',dict(source=kb_source,qa=kb_qa,archive=seal,
        git_snapshots=len(snapshots),unchanged_full_function_proofs=len(proof['unchanged_symbols']),
        original_files_unchanged=len(originals),junit=counts,canonical_imports=import_counts,
        review='Full specification, propagation delta, all new admission/prefix tests and minimal correction reviewed. Original five-case probe and its three real failures preserved; no exposed package route or durable recovery claim.'))

native_base = '9f4e1a57dc75de8d34ef9023bea2fb7619690f0b'
native_source = '9ca3c078c1e14ba4895a5e10c00234985a0b3fc2'
native_tested = 'ace5db8b3f5c300e0afb9f3dffd2978672514545'
native_qa = 'dfdf1c488e242adc6b3a38eb6975e6503f1eb2b2'
stem = 'docs/qa/autonomous-ci-20261118/windows-network-diagnostics/'
seal = json.loads(blob(native_qa,stem+'seal.json'))
manifest_raw = blob(native_qa,stem+'manifest.json')
assert seal['sha256'] == 'aedb078f695e36f45c942c5f7878cd37e89b38d0c88e91edd61565a71c843230'
assert sha(manifest_raw) == seal['manifest_sha256']
manifest = json.loads(manifest_raw)
with archive(blob(native_qa,stem+'evidence.zip'),manifest,seal,True) as z:
    for row in manifest['git_sources']:
        data = blob(row['source_commit'],row['source_path'])
        assert data == z.read(row['path']) and sha(data) == row['sha256']
        assert git('rev-parse',row['source_commit']+':'+row['source_path']).decode().strip() == row['git_blob']
    counts = junit(z)
    expected = {'red.xml':(8,2,3),'red-write.xml':(9,2,4),'final.xml':(329,2,0),'final-v2.xml':(329,0,0)}
    for name,(total,failed,errors) in expected.items():
        assert counts[name] == dict(tests=total,failures=failed,errors=errors,skipped=0)
    imports = json.loads(z.read('final-v2.imports.json'))
    assert imports['source_commit'] == native_tested and not imports['drift']
    for row in imports['modules']:
        assert sha(blob(native_tested,row['relative_path'])) == row['sha256']
    old_test = blob(native_source,'tests/test_windows_network_diagnostics.py')
    new_test = blob(native_tested,'tests/test_windows_network_diagnostics.py')
    assert new_test.replace(b'[a-z][a-z0-9-]{0,31}',b'[a-z-]{1,32}') == old_test
    assert not git('diff',native_source,native_tested,'--','src','tools','.github','docs')
    assert not git('diff',native_tested,native_qa,'--','src','tests','tools','.github','docs/specs','docs/schemas','pyproject.toml')
    assert git('diff','--name-only',native_base,native_source,'--','src','tools','.github').decode().splitlines() == [
        'tools/windows_network/common.h','tools/windows_network/launcher.c','tools/windows_network/probe.c']
    for path in ('tests/test_windows_bindiff_network.py','tests/test_spec_registry.py'):
        assert blob(native_base,path) == blob(native_tested,path)
    raw = z.read('final-v2-formatter-05-budget.stderr.txt')
    rows = [json.loads(line) for line in raw.splitlines()]
    assert len(rows) == 16 and len(raw) == 3152
    assert [r['sequence'] for r in rows] == list(range(1,17))
    assert rows[-1]['stage']=='diagnostic-limit' and rows[-1]['kind']=='truncated'
    assert z.read('final-v2-formatter-06-failed-write.stderr.txt') == b''
    assert z.read('final-v2-formatter-06-failed-write.stdout.txt') == b''
    write('native-archive-verification.json',dict(source=native_source,tested=native_tested,qa=native_qa,
        archive=seal,git_snapshots=len(manifest['git_sources']),junit=counts,canonical_imports=len(imports['modules']),
        fixture_correction_is_one_lexical_predicate=True,existing_evidence_tests_unchanged=True,
        review='Complete three-file native diff, specification, all nine controls and packet README read. Fixed numeric/vocabulary stderr records and finite attempted-output budget preserve reviewed API flags, deadlines, call ordering, stdout schema and acceptance decisions. Static review and portable formatter execution do not qualify Windows runtime or native containment.'))

print(json.dumps(dict(kb_source=kb_source,native_source=native_source,native_tested=native_tested,
                     verified_packets=2,output=str(OUT))))
