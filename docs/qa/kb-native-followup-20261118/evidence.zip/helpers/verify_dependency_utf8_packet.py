"""Independently verify the sealed UTF-8-only invocation correction."""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = ROOT / 'qa/windows-dependency-root-review'
BASE = '207eea9d4e125ac1d371139d4db803ddbc2b4c8a'
SOURCE = '6dea194adf52ae0257d94c1604707a056d11c92c'
QA = '754e1b934f2a4ab0efaf94d7be39a5b8b390db90'
STEM = 'docs/qa/windows-dependency-encoding-20261118'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


OUT.mkdir(exist_ok=False)
manifest = json.loads(git('show', QA + ':' + STEM + '.manifest.json'))
raw_archive = git('show', QA + ':' + STEM + '.zip')
assert sha(raw_archive) == manifest['archive_sha256'] == '45625ae4a79d862973338c41174cfeeb435ef4f8a22e985a68b09c91e1ef1fcb'
assert len(raw_archive) == manifest['archive_bytes'] == 521904
with zipfile.ZipFile(io.BytesIO(raw_archive)) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == 168
    assert set(z.namelist()) == {row['path'] for row in manifest['entries']}
    for row in manifest['entries']:
        raw = z.read(row['path'])
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    chain = json.loads(z.read('source-chain.json'))
    assert chain['source'] == SOURCE and chain['base'] == BASE
    for row in chain['snapshots']:
        raw = git('show', row['commit'] + ':' + row['path'])
        assert raw == z.read(row['snapshot']) and len(raw) == row['bytes'] and sha(raw) == row['sha256']
    counts = {}
    for name in z.namelist():
        if name.endswith('.xml'):
            cases = list(ET.fromstring(z.read(name)).iter('testcase'))
            counts[name] = dict(tests=len(cases), failures=sum(c.find('failure') is not None for c in cases),
                                errors=sum(c.find('error') is not None for c in cases),
                                skipped=sum(c.find('skipped') is not None for c in cases))
    assert counts['affected.xml'] == dict(tests=167, failures=0, errors=0, skipped=0)
    assert counts['red.xml'] == dict(tests=5, failures=4, errors=0, skipped=0)
    assert counts['spec-red.xml'] == dict(tests=13, failures=9, errors=0, skipped=0)
    preserved = json.loads(z.read('original-files-verification.json'))['original_files']
    for row in preserved:
        raw = (ROOT / 'qa/windows-dependency-encoding' / row['path']).read_bytes()
        assert raw == z.read(row['path']) and sha(raw) == row['sha256']

old = git('show', BASE + ':tools/dependency_security.py')
new = git('show', SOURCE + ':tools/dependency_security.py')
definition = b"PYTHON_OPTIONS = ('-I', '-X', 'utf8')\n"
assert new.count(definition) == 1 and new.count(b'*PYTHON_OPTIONS') == 14
assert new.replace(definition, b'').replace(b'*PYTHON_OPTIONS', b"'-I'") == old
assert git('diff', '--name-only', BASE, SOURCE, '--', 'src', 'tests', 'tools', '.github', 'pyproject.toml').decode().splitlines() == [
    'tests/test_dependency_security_encoding.py', 'tools/dependency_security.py']
assert not git('diff', '--name-only', SOURCE, QA, '--', 'src', 'tests', 'tools', '.github', 'docs/specs', 'docs/schemas', 'pyproject.toml')
assert git('show', chain['spec_tests'] + ':tests/test_dependency_security_encoding.py') == git('show', SOURCE + ':tests/test_dependency_security_encoding.py')
record = dict(source=SOURCE, qa=QA, archive_sha256=sha(raw_archive), archive_bytes=len(raw_archive),
    members=168, canonical_git_snapshots=len(chain['snapshots']), junit=counts,
    original_files_unchanged=len(preserved), source_has_only_one_prefix_constant_and_14_replacements=True,
    every_other_tool_byte_unchanged=True, original_spec_tests_unchanged=True, qa_changes_no_product_or_test_bytes=True,
    root_review='Full spec and eight new controls plus unchanged external probe read; official Python 3.12 command-line and UTF-8-mode semantics independently retrieved. Authored conditional CP1252 model is not native pip evidence; corrected hosted Windows remains unverified.')
with (OUT / 'archive-verification.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
