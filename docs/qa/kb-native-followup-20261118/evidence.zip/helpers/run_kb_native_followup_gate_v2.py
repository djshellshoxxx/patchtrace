"""Exact-candidate union of reviewed KB, UTF-8 and portable diagnostic scopes."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = ROOT / 'qa/kb-native-followup-integration-v2'


def git(*args):
    return subprocess.check_output(['git','-C',str(REPO),*args])


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value,stream,indent=2)
        stream.write('\n')


source = git('rev-parse','HEAD').decode().strip()
assert source == '7b5f558fb1a51d45427648c39c15995ab3697e2c' and not git('status','--porcelain')
OUT.mkdir(exist_ok=False)
owners = {
    '6dea194adf52ae0257d94c1604707a056d11c92c': [
        'tools/dependency_security.py','tests/test_dependency_security_encoding.py',
        'docs/specs/dependency-security-qualification.md'],
    'd9a939911f39f3641bd5eed97a2ce067d618856b': [
        'src/patchtrace/kbcorrelation/service.py','src/patchtrace/kbcorrelation/store.py',
        'src/patchtrace/kbcorrelation/wiring.py','tests/test_kbc_held_input_admission.py',
        'tests/test_kbc_held_inspection_prefix.py','docs/specs/kb-held-inputs.md'],
    'ace5db8b3f5c300e0afb9f3dffd2978672514545': [
        'tools/windows_network/common.h','tools/windows_network/probe.c','tools/windows_network/launcher.c',
        'tests/test_windows_network_diagnostics.py','docs/specs/windows-bindiff-network-acceptance.md'],
}
owner_proofs = []
for reviewed, paths in owners.items():
    for path in paths:
        raw = git('show',reviewed+':'+path)
        assert raw == git('show',source+':'+path) == (REPO/path).read_bytes()
        owner_proofs.append(dict(path=path,reviewed=reviewed,sha256=hashlib.sha256(raw).hexdigest()))
kb = ['tests/test_'+name+'.py' for name in (
    'kbc_held_input_admission','kbc_held_inspection_prefix','kbc_service','kbc_store','kbc_recovery',
    'kbc_cli','kbc_acquire_cli','kbc_saved_scope_flow','kbc_saved_scope_validation',
    'kbc_saved_scope_revision_identity','kbc_inventory_source_admission','kb_investigation_service',
    'input_readers','ingestion_held_inputs','creation_operation_checkpoint')]
utf8 = ['tests/test_dependency_security_encoding.py','tests/test_dependency_security.py',
        'tests/test_dependency_security_bootstrap.py']
native = ['tests/test_windows_network_diagnostics.py','tests/test_windows_bindiff_network.py','tests/test_spec_registry.py']
kb_command = json.loads((ROOT/'qa/kb-held-input-propagation/affected-source-green.command.json').read_text())
native_command = json.loads((ROOT/'qa/windows-network-diagnostics/final-v2.command.json').read_text())
assert kb == [v for v in kb_command['argv'] if v.startswith('tests/')]
assert native == [v for v in native_command['pytest_arguments'] if v.startswith('tests/')]
external = {
    ROOT/'qa/windows-dependency-encoding/test_encoding_boundary.py': '08fc908b2daa0b869f36a8e836f73e2285a90ad48a0bbb7681e5f8d1dcabbea3',
    ROOT/'qa/kb-held-inputs-independent/test_short_reader_prefix.py': '672e1a2e13e990c1e1249d319f714ef8e91425d44fcafe63dd6fe32a3d9feee6',
}
for path, digest in external.items():
    assert sha(path) == digest
nodes = list(dict.fromkeys([*kb,*utf8,*native,*map(str,external)]))
assert len(nodes)==23
protected = {}
for directory in ('qa/windows-dependency-encoding','qa/kb-held-inputs-independent'):
    for path in (ROOT/directory).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts:
            protected[str(path)] = sha(path)
owned=Path(tempfile.mkdtemp(prefix='patchtrace-kb-native-followup-'))
assert not any((p/'.git').exists() for p in (owned,*owned.parents))
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',QT_QPA_PLATFORM='offscreen',
    PYTHONPATH=os.pathsep.join(map(str,[REPO/'src',REPO/'tests',REPO,ROOT/'ops'])),
    GIT_ALLOW_PROTOCOL='file',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_TERMINAL_PROMPT='0',
    PATCHTRACE_ENCODING_OBSERVATIONS=str(OUT/'encoding-observations'),
    PATCHTRACE_KB_SHORT_READ_OBSERVATIONS=str(OUT/'short-read-observations'),
    PATCHTRACE_BATCH_COLLECTION_RECEIPT=str(OUT/'collection.json'),
    PATCHTRACE_OFFLINE_GUARD_RECEIPT=str(OUT/'offline-guard.json'))
argv=[sys.executable,str(ROOT/'ops/continuation_offline_pytest.py'),'-q','-ra','-p','no:cacheprovider',
      '-p','project_and_tools_receipt',*nodes,'--basetemp='+str(owned/'pytest'),'--junitxml='+str(OUT/'result.xml')]
write('command.json',dict(source=source,tree=git('rev-parse','HEAD^{tree}').decode().strip(),argv=argv,cwd=str(REPO),
    pythonpath=env['PYTHONPATH'],owned_temp=str(owned),started_utc=datetime.now(timezone.utc).isoformat(),timeout=180,
    selected_files=[dict(path=node,sha256=sha(Path(node) if Path(node).is_absolute() else REPO/node)) for node in nodes],
    reviewed_owner_files=owner_proofs,protected_original_files=protected,
    helper_hashes={str(p):sha(p) for p in (Path(__file__),ROOT/'ops/continuation_offline_pytest.py',ROOT/'ops/project_and_tools_receipt.py')},
    boundary='Reviewed offline Python scopes and authored portable C formatter only; no downloaded target/native image execution or native Windows acceptance'))
start=time.monotonic()
with (OUT/'result.log').open('x') as stream:
    result=subprocess.run(argv,cwd=REPO,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=180)
collection=json.loads((OUT/'collection.json').read_text())
drift=[]
for name,row in collection['final_sources'].items():
    path=Path(row['path'])
    if not path.is_relative_to(REPO) or not path.is_relative_to(REPO/'src') and not path.is_relative_to(REPO/'tools'):
        drift.append(dict(module=name,path=str(path),reason='foreign import'))
    else:
        raw=git('show',source+':'+path.relative_to(REPO).as_posix())
        if path.read_bytes()!=raw or hashlib.sha256(raw).hexdigest()!=row['sha256']:
            drift.append(dict(module=name,path=str(path),reason='Git byte mismatch'))
preserved=all(sha(path)==digest for path,digest in protected.items())
after=git('rev-parse','HEAD').decode().strip();status=git('status','--porcelain').decode()
valid=after==source and not status and not drift and preserved
cases=list(ET.parse(OUT/'result.xml').getroot().iter('testcase'))
counts=dict(tests=len(cases),failures=sum(c.find('failure') is not None for c in cases),
    errors=sum(c.find('error') is not None for c in cases),skipped=sum(c.find('skipped') is not None for c in cases))
removed=False
if result.returncode==0 and valid:
    shutil.rmtree(owned)
    removed=True
receipt=dict(exit=result.returncode,elapsed=time.monotonic()-start,source_after=after,status_after=status,junit=counts,
    imported_source_count=len(collection['final_sources']),drift=drift,original_files_unchanged=preserved,
    owned_temp=str(owned),temp_removed=removed)
write('exit.json',receipt)
normal=subprocess.run([sys.executable,'-m','ruff','check','src','tests','tools'],cwd=REPO,capture_output=True,timeout=120)
write('normal-ruff.json',dict(source=source,argv=[sys.executable,'-m','ruff','check','src','tests','tools'],exit=normal.returncode,
    stdout=normal.stdout.decode(),stderr=normal.stderr.decode()))
assert valid and normal.returncode==0
print(json.dumps(receipt));print((OUT/'result.log').read_text())
raise SystemExit(result.returncode)
