"""Independently verify the frozen remote inventory delta without repeating stable audits."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parent.parent
REPO=ROOT/'continuation-integration'
Q=ROOT/'qa/branch-refresh-after-fb09'


def sha(raw):return hashlib.sha256(raw).hexdigest()


def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])


seal=json.loads((ROOT/'qa/branch-refresh-after-fb09-seal.json').read_text())
manifest=json.loads((Q/'manifest.json').read_text())
raw=(ROOT/'qa/branch-refresh-after-fb09.zip').read_bytes()
assert len(raw)==seal['bytes']==2243888
assert sha(raw)==seal['sha256']=='59615017740a49e9ea9e27b38627cb9435b5c232f1225b76abc0fc420fa972d9'
assert sha((Q/'manifest.json').read_bytes())==seal['manifest_sha256']
with zipfile.ZipFile(ROOT/'qa/branch-refresh-after-fb09.zip') as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==72
    assert set(z.namelist())=={r['path'] for r in manifest['files']}|{'manifest.json'}
    assert z.read('manifest.json')==(Q/'manifest.json').read_bytes()
    for row in manifest['files']:
        data=z.read(row['path'])
        assert data==(Q/row['path']).read_bytes() and len(data)==row['bytes'] and sha(data)==row['sha256']
    summary=json.loads(z.read('summary.json'))
    assert sha(z.read('summary.json'))==seal['summary_sha256']
    baseline=json.loads(z.read('baseline/inventory.json'))
    assert z.read('baseline/inventory.json')==git('show',summary['complete_branch_baseline']['commit']+':docs/plans/autonomous-consolidation-20261118/branch-inventory.json')
    old={r['branch']:r['head_sha'] for r in baseline['branches']}
    current={r['name']:r['commit']['sha'] for r in json.loads(z.read('branches-current.json'))}
    assert len(current)==316 and len(old)==307
    removed=old.keys()-current.keys()
    changed={name:dict(previous=old.get(name),current=head) for name,head in current.items() if old.get(name)!=head}
    assert not removed and len(changed)==11
    delta=json.loads(z.read('branch-head-deltas.json'))
    assert changed==delta['changed_or_new'] and sum(old.get(k)==v for k,v in current.items())==305
    head=summary['comparison_head']
    dispositions=json.loads(z.read('changed-tip-dispositions.json'))['branches']
    assert {r['branch'] for r in dispositions}==set(changed)
    for row in dispositions:
        assert row['head']==current[row['branch']]
        subprocess.run(['git','-C',str(REPO),'merge-base','--is-ancestor',row['head'],head],check=True)
        assert git('cherry',head,row['head'])==b''
        assert git('rev-parse',row['head']+'^{tree}').decode().strip()==row['tree']
        assert git('merge-base',row['head'],row['comparison_base']).decode().strip()==row['merge_base']
    for row in summary['priority_prs']:
        assert git('show','-s','--format=%P',row['preview']).decode().strip().split()==[row['base'],row['head']]
        assert git('rev-parse',row['preview']+'^{tree}').decode().strip()==row['head_tree']==row['preview_tree']
        assert git('merge-base',row['base'],row['head']).decode().strip()==row['base']==row['merge_base']
    prior={r['number']:r for r in json.loads(z.read('baseline/open-prs-164356.json'))['data']}
    prs={r['number']:r for r in json.loads(z.read('open-prs-current.json'))}
    assert len(prior)==62 and len(prs)==63 and prs.keys()-prior.keys()=={316} and not prior.keys()-prs.keys()
    for number,row in prior.items():
        now=prs[number]
        assert all(row[k]==now[k] for k in ('title','draft','updated_at'))
        assert row['head']['sha']==now['head']['sha'] and row['base']['ref']==now['base']['ref']
    original=json.loads(z.read('original-131-preservation.json'))
    assert len(original['union'])==131 and all(current[name]==row['head'] for name,row in original['union'].items())
    for row in original['packets']:
        data=git('show',row['git_commit']+':'+row['path'])
        assert data==z.read('baseline/semantic-batch'+str(row['batch'])+'.json') and sha(data)==row['sha256']
    record=dict(main=summary['main'],comparison_head=head,archive_sha256=sha(raw),archive_bytes=len(raw),members=72,
        current_branches=len(current),unchanged_heads=305,changed_or_new_tips_verified_ancestors=len(dispositions),
        removed_branches=0,open_prs=len(prs),new_since_latest_open_pr_inventory=[316],
        original_focal_tips_unchanged=131,priority_preview_parent_and_tree_checks=3,
        limitation='Exact frozen inventory delta; no stable semantic re-audit, qualification, PR approval or main merge implied.')
with (ROOT/'qa/kb-native-followup-root-review/branch-refresh-verification.json').open('x') as f:
    json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record))
