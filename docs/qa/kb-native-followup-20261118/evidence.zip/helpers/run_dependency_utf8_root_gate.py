"""Replay the complete UTF-8 affected scope on the actual integration candidate."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT/'continuation-integration'
OUT = ROOT/'qa/windows-dependency-root-review'
SOURCE = '23d1d25102ad138394915b1c93951477474fa2ef'


def git(*args):
    return subprocess.check_output(['git','-C',str(REPO),*args])


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(name, value):
    with (OUT/name).open('x') as stream:
        json.dump(value,stream,indent=2)
        stream.write('\n')


assert git('rev-parse','HEAD').decode().strip()==SOURCE and not git('status','--porcelain')
assert not (OUT/'combined-command.json').exists()
original=ROOT/'qa/windows-dependency-encoding/test_encoding_boundary.py'
assert sha(original)=='08fc908b2daa0b869f36a8e836f73e2285a90ad48a0bbb7681e5f8d1dcabbea3'
protected={str(path):sha(path) for path in (ROOT/'qa/windows-dependency-encoding').rglob('*') if path.is_file() and '__pycache__' not in path.parts}
for path in ('tools/dependency_security.py','tests/test_dependency_security_encoding.py','docs/specs/dependency-security-qualification.md'):
    assert git('show',SOURCE+':'+path)==git('show','6dea194adf52ae0257d94c1604707a056d11c92c:'+path)==(REPO/path).read_bytes()
write('source-and-preservation.json',dict(source=SOURCE,reviewed='6dea194adf52ae0257d94c1604707a056d11c92c',protected_original_files=protected))
owned=Path(tempfile.mkdtemp(prefix='patchtrace-dependency-utf8-root-'))
assert not any((p/'.git').exists() for p in (owned,*owned.parents))
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',QT_QPA_PLATFORM='offscreen',
    PYTHONPATH=os.pathsep.join(map(str,[REPO/'src',REPO/'tests',REPO,ROOT/'ops'])),
    GIT_ALLOW_PROTOCOL='file',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_TERMINAL_PROMPT='0',
    PATCHTRACE_ENCODING_OBSERVATIONS=str(OUT/'fresh-external-observations'),
    PATCHTRACE_BATCH_COLLECTION_RECEIPT=str(OUT/'combined-collection.json'),
    PATCHTRACE_OFFLINE_GUARD_RECEIPT=str(OUT/'combined-offline-guard.json'))
nodes=['tests/test_dependency_security_encoding.py','tests/test_dependency_security.py',
       'tests/test_dependency_security_bootstrap.py',str(original)]
argv=[sys.executable,str(ROOT/'ops/continuation_offline_pytest.py'),'-q','-ra','-p','no:cacheprovider',
      '-p','project_and_tools_receipt',*nodes,'--basetemp='+str(owned/'pytest'),'--junitxml='+str(OUT/'combined.xml')]
write('combined-command.json',dict(source=SOURCE,tree=git('rev-parse','HEAD^{tree}').decode().strip(),argv=argv,cwd=str(REPO),
    pythonpath=env['PYTHONPATH'],owned_temp=str(owned),started_utc=datetime.now(timezone.utc).isoformat(),timeout=120,
    selected_files=[dict(path=node,sha256=sha(Path(node) if Path(node).is_absolute() else REPO/node)) for node in nodes],
    helper_hashes={str(p):sha(p) for p in (Path(__file__),ROOT/'ops/continuation_offline_pytest.py',ROOT/'ops/project_and_tools_receipt.py')}))
start=time.monotonic()
with (OUT/'combined.log').open('x') as stream:
    result=subprocess.run(argv,cwd=REPO,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=120)
collection=json.loads((OUT/'combined-collection.json').read_text())
drift=[]
for name,row in collection['final_sources'].items():
    path=Path(row['path'])
    if not path.is_relative_to(REPO) or not path.is_relative_to(REPO/'src') and not path.is_relative_to(REPO/'tools'):
        drift.append(dict(module=name,path=str(path),reason='foreign import'))
    else:
        raw=git('show',SOURCE+':'+path.relative_to(REPO).as_posix())
        if path.read_bytes()!=raw or hashlib.sha256(raw).hexdigest()!=row['sha256']:
            drift.append(dict(module=name,path=str(path),reason='Git byte mismatch'))
preserved=all(sha(path)==digest for path,digest in protected.items())
after=git('rev-parse','HEAD').decode().strip();status=git('status','--porcelain').decode()
valid=after==SOURCE and not status and not drift and preserved
removed=False
if result.returncode==0 and valid:
    shutil.rmtree(owned)
    removed=True
receipt=dict(exit=result.returncode,elapsed=time.monotonic()-start,source_after=after,status_after=status,
    imported_source_count=len(collection['final_sources']),drift=drift,original_files_unchanged=preserved,
    owned_temp=str(owned),temp_removed=removed)
write('combined-exit.json',receipt)
normal=subprocess.run([sys.executable,'-m','ruff','check','src','tests','tools'],cwd=REPO,capture_output=True,timeout=120)
write('normal-ruff.json',dict(source=SOURCE,argv=[sys.executable,'-m','ruff','check','src','tests','tools'],exit=normal.returncode,
    stdout=normal.stdout.decode(),stderr=normal.stderr.decode()))
assert valid and normal.returncode==0
print(json.dumps(receipt));print((OUT/'combined.log').read_text())
raise SystemExit(result.returncode)
