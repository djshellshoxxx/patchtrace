"""Pinned, offline reviewer reproduction against the first held-KB source."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parent.parent
REPO=ROOT/'semantic-disposition-batch4'
OUT=ROOT/'qa/kb-held-inputs-independent'
SOURCE='73b7de55cb4ff3556f68fac616d47244626bc887'


def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])


def write(name,value):
    with (OUT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')


assert git('rev-parse','HEAD').decode().strip()==SOURCE and not git('status','--porcelain')
assert not git('diff','--name-only','3fee8026ce9d176c80deb574eb5f78a6eeb5e7d6',SOURCE,'--','src')
owned=Path(tempfile.mkdtemp(prefix='patchtrace-kb-short-read-'))
probe=OUT/'test_short_reader_prefix.py'
probe_sha=hashlib.sha256(probe.read_bytes()).hexdigest()
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',QT_QPA_PLATFORM='offscreen',
    PYTHONPATH=os.pathsep.join(map(str,[REPO/'src',REPO/'tests',REPO,ROOT/'ops'])),
    GIT_ALLOW_PROTOCOL='file',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_TERMINAL_PROMPT='0',
    PATCHTRACE_KB_SHORT_READ_OBSERVATIONS=str(OUT/'initial-observations'),
    PATCHTRACE_BATCH_COLLECTION_RECEIPT=str(OUT/'initial-imports.json'),
    PATCHTRACE_OFFLINE_GUARD_RECEIPT=str(OUT/'initial-offline-guard.json'))
argv=[sys.executable,str(ROOT/'ops/continuation_offline_pytest.py'),'-q','-ra','-p','no:cacheprovider',
    '-p','project_and_tools_receipt',str(probe),'--basetemp='+str(owned/'pytest'),'--junitxml='+str(OUT/'initial.xml')]
write('initial-command.json',dict(source=SOURCE,tree=git('rev-parse','HEAD^{tree}').decode().strip(),
    production_source='3fee8026ce9d176c80deb574eb5f78a6eeb5e7d6',argv=argv,cwd=str(REPO),pythonpath=env['PYTHONPATH'],probe_sha256=probe_sha,owned_temp=str(owned)))
with (OUT/'initial.log').open('x') as f:result=subprocess.run(argv,cwd=REPO,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=90)
imports=json.loads((OUT/'initial-imports.json').read_text());drift=[]
for name,row in imports['final_sources'].items():
    path=Path(row['path']);assert path.is_relative_to(REPO)
    raw=git('show',SOURCE+':'+path.relative_to(REPO).as_posix())
    if raw!=path.read_bytes() or hashlib.sha256(raw).hexdigest()!=row['sha256']:drift.append(name)
receipt=dict(exit=result.returncode,source_after=git('rev-parse','HEAD').decode().strip(),status_after=git('status','--porcelain').decode(),
    imports=len(imports['final_sources']),drift=drift,probe_unchanged=hashlib.sha256(probe.read_bytes()).hexdigest()==probe_sha,owned_temp_retained=str(owned))
write('initial-exit.json',receipt)
print(json.dumps(receipt));print((OUT/'initial.log').read_text())
assert receipt['source_after']==SOURCE and not receipt['status_after'] and not drift and receipt['probe_unchanged']
raise SystemExit(result.returncode)
