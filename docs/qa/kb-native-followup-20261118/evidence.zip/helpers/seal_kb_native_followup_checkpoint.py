"""Seal the exact-source KB, UTF-8 and portable native diagnostic integration."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parent.parent
REPO=ROOT/'continuation-integration'
BASE='9ad2ec5cdbde85155fdca3cdd88804fd8b2e1a53'
SOURCE='7b5f558fb1a51d45427648c39c15995ab3697e2c'
DOCS='195e04af27f7a724c6a2037363b7fe68df418a6b'
MAIN='9c411ca3d7b47f950be5f0c6f01b3c54184554c6'
REMOTE_BASE='fb09e43499f1abb84615b66b976629c22d5a41c2'
Q=ROOT/'qa/kb-native-followup-integration-v2'
DEST=REPO/'docs/qa/kb-native-followup-20261118'


def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])


def sha(raw):return hashlib.sha256(raw).hexdigest()


assert git('rev-parse','HEAD').decode().strip()==DOCS and not git('status','--porcelain')
assert not git('diff',SOURCE,DOCS,'--','src','tests','tools','.github','docs/specs','docs/schemas','pyproject.toml')
tree=git('rev-parse',SOURCE+'^{tree}').decode().strip()
gate=json.loads((Q/'exit.json').read_text())
assert gate['source_after']==SOURCE and gate['exit']==0 and not gate['drift'] and not gate['status_after']
assert gate['junit']==dict(tests=803,failures=0,errors=0,skipped=0)
assert gate['imported_source_count']==118 and gate['original_files_unchanged'] and gate['temp_removed']
command=json.loads((Q/'command.json').read_text())
assert len(command['selected_files'])==23 and len(command['reviewed_owner_files'])==14
for row in command['reviewed_owner_files']:
    assert sha((REPO/row['path']).read_bytes())==row['sha256']
assert json.loads((Q/'normal-ruff.json').read_text())['exit']==0
strict=json.loads((Q/'strict-sites-comparison.json').read_text())
assert strict['exit']==1 and strict['findings']==80 and strict['same_path_code_selected_statement_multiset']
failed=json.loads((ROOT/'qa/kb-native-followup-integration/exit.json').read_text())
assert failed['junit']==dict(tests=803,failures=1,errors=0,skipped=0)
assert git('diff','--name-only','8e830fa5f7f49c71e8c999eb880791da53369511',SOURCE).decode().splitlines()==['docs/specs/REGISTRY.md']
assert git('diff','--numstat','8e830fa5f7f49c71e8c999eb880791da53369511',SOURCE).decode().strip()=='1\t0\tdocs/specs/REGISTRY.md'
guard=json.loads((Q/'offline-guard.json').read_text())
assert guard['network_audit_event_counts']=={'socket.gethostname':182} and guard['process_audit_count']==118
fresh=json.loads((ROOT/'qa/kb-native-followup-publication/fresh-before-publication.json').read_text())
reads={row['path']:json.loads(row['result']['structuredContent']['content']) for row in fresh['reads']}
assert reads['branches/main']['commit']['sha']==MAIN and reads['pulls/316']['head']['sha']==REMOTE_BASE
assert reads['pulls/316']['state']=='open' and not reads['pulls/316']['merged']
branch=json.loads((ROOT/'qa/branch-refresh-after-fb09/summary.json').read_text())
assert branch['comparison_head']==REMOTE_BASE and branch['branch_counts']['current']==316
assert (ROOT/'qa/kb-native-followup-root-review/hosted-fb09-verification.json').is_file()
hosted=json.loads((ROOT/'qa/hosted-pr316-fb09/seal.json').read_text())
commits=git('rev-list','--reverse',BASE+'..'+DOCS).decode().splitlines()
assert len(commits)==17 and all('[no release]' in git('show','-s','--format=%B',c).decode() for c in commits)

note=f'''# KB held inputs, UTF-8 inventory and bounded native diagnostics

## Qualified candidate and current release limits

Source `{SOURCE}`, tree `{tree}`, passes **803 tests, zero skips,
failures or errors in 9.76 seconds** (10.35 seconds including verification).
The scope is the union of all three reviewed affected suites: 21 repository
files and two unchanged independent probe files. All **118** imported project
and tool modules match canonical Git bytes. Fourteen changed source/test/spec
paths match their independently reviewed owners. Normal `ruff check src tests
tools` passes. The isolated strict S scan still exits 1 on **80 unchanged
path/code/selected-statement sites**; nothing is suppressed or waived.

The final design/checkpoint commits add documentation and evidence only. Product,
test, workflow, specification, schema and project-configuration bytes remain equal
to the tested source above. These affected-scope results do not replace full
Linux/Windows, repeated Qt, native, frozen-package, dependency, security or
reproducibility acceptance. Main remains `{MAIN}`. No main merge, PR closure,
branch deletion, force-push, tag, release or deployment occurs here.

## Changes independently reviewed and integrated

| Scope | Delivered behavior | Source and limits |
| --- | --- | --- |
| Windows dependency JSON encoding | Fourteen isolated Python argv sites now explicitly select UTF-8. Removing that single prefix constant/replacing the expansions recovers every previous tool byte. Existing argv order, pins, environment filtering, raw output, timeouts, bounds and verdict validation remain. | `6dea194adf52ae0257d94c1604707a056d11c92c`. The conditional CP1252 model is authored portable evidence; corrected actual Windows pip inventory remains pending. |
| Internal KB held capability | The same pair/checkpoint reaches inspection, complete intent/create hashes, both factories and the existing core. Original positive byte accounting, zero-byte boundary checks, complete global/saved/revision/source admission and ordinary injected call shapes remain. Typed stops propagate without path retry. | `d9a939911f39f3641bd5eed97a2ce067d618856b`. Exactly three KB production files. No exposed held-origin CLI/GUI/package route or durable recovery claim. |
| Bounded native failure context | Shared standard-C formatter emits fixed vocabulary and numeric stderr records. Sixteen attempted records per process, each under 512 bytes, with one terminal truncation marker and failed-write budget consumption. Win32/WSA values are captured before cleanup; socket stage/counts and child startup/finish context are retained. | C `9ca3c078c1e14ba4895a5e10c00234985a0b3fc2`, tested `ace5db8b3f5c300e0afb9f3dffd2978672514545`. Reviewed flags, OS call arguments/order, deadlines, stdout schema and decisions remain. Portable compilation/static checks do not qualify Windows runtime. |

Held inspection now accumulates at most the existing 4096-byte PE prefix across
legitimate short reads. Hashing still covers the entire input. The last allowed
signature position succeeds, while headers at offsets4096/4160 remain refused.
Reader contexts close the borrowed stream and retain original descriptor ownership.
Actual PE/SQLite tests deny source pathname opens, verify caller-thread access and
reopen immutable copies after original input removal. No checkpoint was inserted
between committed core creation returning and the existing created-journal write.

## Preserved failures and independent verification

The original KB capability tests recorded32 failed/1 passed before implementation.
Root then reproduced a valid-PE short-read failure: **three failures/two positives**
at the first candidate. The two-line prefix correction followed a six-failed/
six-positive contract regression. Its unchanged root probe now passes five cases.
The author affected scope passed300 at its own source; root's earlier UTF-8 replay
passed167. These overlapping counts are not added into coverage percentages.

Native diagnostic reds retain missing-boundary failures and missing-formatter
setup errors. The first implemented gate had327 passes/two failures because a
test predicate rejected the specified `win32` spelling. Only that lexical predicate
changed; the exact eight-kind assertion and all C bytes remained. The corrected
author gate passed329. Its real formatter emitted16 records/3152 bytes for1000
calls and consumed the finite budget against a valid read-only stdio stream.

The first root combined run at8e830fa5 had **802 passed/one failed**, exposing a
missing entry for the new KB specification in the existing registry. A single
required registry row corrected it; no test or production assertion changed.
The original command/log/XML/import/audit receipts and temporary failure workspace
remain. The same23-file scope then passed all803 at the source above.

Root verified the UTF-8 packet's168 members/56 Git snapshots, KB packet's147
members/81 Git snapshots/150 complete unchanged function spans/nine original
files, and native packet's89 members/28 Git snapshots. The original hosted f3
diagnosis and corrected worker supplement were independently rechecked. All
original probes/observations remain byte-identical. The branch verifier's first
historical filename assumption failed before product execution; that original
helper and observed error are retained alongside its path-only correction.

The reviewed offline guard installed inherited network denial and local-only Git
transport before test collection. It observed182 hostname events and118 process
events within the inspected fixture/compiler scope, with no socket operation.
Only the extracted authored formatter was compiled/executed; no retained target
or Windows image was executed. The successful owned temp directory was removed.
This test guard does not claim a product or native containment boundary.

## Fresh repository and hosted evidence

The sealed refresh covers316 branches and63 open PRs. Compared with the complete
307-branch inventory,305 heads are unchanged, two known heads advanced and nine
known branches were added; none disappeared. All eleven changed/new tips are
actual ancestors of `{REMOTE_BASE}`, with no unmatched cherry residues.
All131 original focal tips still match their seven retained disposition records.
Their broader unresolved work remains open; ancestry is not release qualification.

| PR | Head before this publication | Disposition |
| --- | --- | --- |
|304|d8c02caea407f6d323eecd636735849c1eb31a2d|Open; exact-candidate mandatory gates remain incomplete.|
|307|58fc130631f602b6e907bb054d30c21d810551d4|Open, stacked on304; native/Windows/full qualification remains blocked.|
|316|{REMOTE_BASE}|Open integrated review vehicle; next append-only publication is separately read back.|

Priority merge previews have exact base/head parents and trees equal to their
heads. Both remote-ref snapshots match all322 observed refs. Existing PR metadata
matches the later62-PR inventory, with316 the sole added open PR. Fresh review
lists contain no submitted approvals or inline comments. No PR is closed as
superseded because its replacement has not met main acceptance.

At the fb09 check observation, full Linux/Windows QA and five Qt shards remained
in progress. The separate sealed hosted review inspects source-bound artifacts
and actual outcomes, not job badges. Windows native still records depth0 only,
four loopback10060 errors, external10013 and exit125. Its outer job is empty and
not timed out; aggregate cleanup false reflects the incomplete sequence, not
proof of a surviving descendant. This run built the old C bytes and cannot test
the new diagnostics. The failing descendant stage remains unresolved.

Windows dependency inventory still failed before audit at that old source.
Linux dependency and native successes are source-specific bounded evidence, with
details and remaining controls in the hosted packet. They do not confer cross-OS,
real-CVE matching accuracy, calibration or final-candidate acceptance. All native
artifact sizes/API hashes/CRC and text provenance are retained; no native image
was run locally. Research L1/L2/L3 frozen outcomes remain unchanged.

## Durable package work and preserved workspace evidence

The read-only core-admission design3e4abd88 is independently verified:107 members,
74 canonical snapshots,43 full source spans, seven references and ten actual
current-behavior observations with60 pinned imports. It confirms that existing
stored IDs and complete side-keyed hashes can support expected identity; it also
retains the after-create intent gap, default recovery mutation and postcommit
copy reads without the creation checkpoint.

Root approved only additive existing create/open/load seams in service/persistence:
prevalidated optional project ID, explicit recovery control and per-call original
read checkpoint. Spec and meaningful failures must precede source. Durable package
intent, held-origin guard before generic recovery, repeated actual identity checks,
provenance and idempotent reconciliation remain separate work. A lost lease never
authorizes reopening stored package paths. The complete package route stays absent.

The archive also preserves cleanup receipts for four completed old clean checkouts.
Tracked files matched canonical Git bytes,814 nontracked test-support files were
archived/hash-verified, and normal non-force worktree removal retained every branch.
No active checkout, original evidence, branch, dependency environment or uncertain
temporary artifact was removed. Prior fb09 publication receipts retain all25
remote commit/tree/ordered-parent readbacks and the exact non-force ref update.

## Next assignments and acceptance

Core owns the bounded expected-ID/reopen-checkpoint implementation and close-only
failure handling, with genuine regressions before source. KB owns a read-only
durable intent/provenance/reconciliation proposal over existing services. CI owns
source-bound hosted/native diagnosis and later exact-source qualification. Root
owns independent review, candidate tests, evidence, branch disposition and non-force
publication. No manual paid/native dispatch is authorized by this checkpoint.

Whole CVE-to-function and package-to-project journeys, full platform and repeated
Qt gates, Windows containment/native adapters, frozen ZIP/installer/Linux packaging,
dependency lock closure, security and reproducibility remain required. D/R/J/G
percentages describe bounded slices only; passing authored fixtures supplies no
whole-feature beta readiness. Subsequent publication and source changes require
their own exact-source receipts.
'''

payloads={'checkpoint-note.md':note.encode()}
def add_dir(label,path):
    for p in sorted(path.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':
            payloads[label+'/'+p.relative_to(path).as_posix()]=p.read_bytes()
for label,path in (
    ('combined',Q),('original-combined-failure',ROOT/'qa/kb-native-followup-integration'),
    ('root-review',ROOT/'qa/kb-native-followup-root-review'),
    ('utf8-root-review',ROOT/'qa/windows-dependency-root-review'),
    ('kb-original-independent',ROOT/'qa/kb-held-inputs-independent'),
    ('cleanup',ROOT/'qa/worker-core-space-review')):
    add_dir(label,path)
for name in ('run_kb_native_followup_gate.py','run_kb_native_followup_gate_v2.py',
             'scan_kb_native_followup.py','verify_kb_native_followup_packets.py',
             'verify_followup_preserved_addenda.py','verify_core_admission_design.py',
             'verify_fb09_branch_refresh.py','verify_fb09_branch_refresh_v2.py',
             'verify_fb09_hosted_packet.py',
             'verify_dependency_utf8_packet.py','run_dependency_utf8_root_gate.py',
             'run_kb_short_read_root_probe.py','project_and_tools_receipt.py',
             'continuation_offline_pytest.py','cleanup_completed_tail_worktrees.py',
             'seal_kb_native_followup_checkpoint.py'):
    payloads['helpers/'+name]=(ROOT/'ops'/name).read_bytes()
payloads['helpers/offline_replay.py']=(ROOT/'qa/full-batch-path-recheck/offline_replay.py').read_bytes()
for name in ('objects-025.json','readback-before-ref.json','ref-update.json','pr316-body.md',
             'pr-update.json','final-readback.json','chain-pr-readback.json','chain-ancestry.json'):
    payloads['preceding-publication/'+name]=(ROOT/'qa/worker-core-navigation-publication'/name).read_bytes()
payloads['fresh-before-publication.json']=(ROOT/'qa/kb-native-followup-publication/fresh-before-publication.json').read_bytes()
for target,path in (
    ('branch-refresh/evidence.zip',ROOT/'qa/branch-refresh-after-fb09.zip'),
    ('branch-refresh/seal.json',ROOT/'qa/branch-refresh-after-fb09-seal.json'),
    ('branch-refresh/README.md',ROOT/'qa/branch-refresh-after-fb09/README.md'),
    ('branch-refresh/summary.json',ROOT/'qa/branch-refresh-after-fb09/summary.json'),
    ('hosted-fb09/evidence.zip',ROOT/'qa/hosted-pr316-fb09/evidence.zip'),
    ('hosted-fb09/seal.json',ROOT/'qa/hosted-pr316-fb09/seal.json'),
    ('hosted-fb09/README.md',ROOT/'qa/hosted-pr316-fb09/README.md'),
    ('hosted-f3-diagnosis/evidence.zip',ROOT/'qa/hosted-pr316-f3/ci-diagnosis/evidence.zip'),
    ('hosted-f3-diagnosis/manifest.json',ROOT/'qa/hosted-pr316-f3/ci-diagnosis/manifest.json'),
    ('worker-supplement/evidence.zip',ROOT/'qa/pw02-worker-independent-corrected-20261118.zip'),
    ('worker-supplement/manifest.json',ROOT/'qa/pw02-worker-independent-corrected-20261118.manifest.json')):
    payloads[target]=path.read_bytes()
for path in git('diff','--name-only',BASE,SOURCE,'--','src','tests','tools','.github','docs/specs','docs/schemas').decode().splitlines():
    payloads['candidate-source/'+path]=git('show',SOURCE+':'+path)
payloads['integration/history.txt']=git('log','--reverse','--format=fuller',BASE+'..'+DOCS)
payloads['integration/patch.diff']=git('diff',BASE,SOURCE,'--','src','tests','tools','.github','docs/specs','docs/schemas')
records=[json.loads(line) for line in (ROOT/'qa/followup-integration/record-resolutions.jsonl').read_text().splitlines()]
payloads['integration/append-conflicts.json']=(json.dumps([r for r in records if r['head'] in {BASE,*commits}],indent=2)+'\n').encode()
DEST.mkdir(exist_ok=False)
with zipfile.ZipFile(DEST/'evidence.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path,data in sorted(payloads.items()):z.writestr(path,data)
with zipfile.ZipFile(DEST/'evidence.zip') as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==len(payloads)
    for path,data in payloads.items():assert z.read(path)==data
archive=DEST/'evidence.zip'
manifest=dict(source=SOURCE,tree=tree,documentation_parent=DOCS,remote_base=REMOTE_BASE,
    sealed_utc=datetime.now(timezone.utc).isoformat(),archive='evidence.zip',archive_bytes=archive.stat().st_size,
    archive_sha256=sha(archive.read_bytes()),payloads=[dict(path=p,bytes=len(d),sha256=sha(d)) for p,d in sorted(payloads.items())])
(DEST/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(DEST/'README.md').write_text(note+f'\n## Archive integrity\n\n{len(payloads)} verified payloads; {archive.stat().st_size:,} bytes. SHA-256 `{manifest["archive_sha256"]}`.\n')
short=f'''\n\n## KB, UTF-8 and native diagnostic milestone — 2026-11-18

Exact source `{SOURCE}` passes803 tests with zero skips/failures/errors in9.76s.
All118 imported project/tool modules and14 reviewed owner paths match Git; the
same23-file gate retains the original802-pass/one-registry-failure result and its
one-row documentation correction. Normal Ruff passes; strict S still fails on80
unchanged sites. The KB short-read correction, isolated UTF-8 invocation and
bounded stderr diagnostic source are independently reviewed and integrated.
[Complete checkpoint](../qa/kb-native-followup-20261118/README.md).
Fresh316-branch/63-open-PR refresh preserves all131 focal tips and verifies all11
changed/new tips as ancestors of fb09. Main remains `{MAIN}`; no main merge,
closure, force-push, deletion, tag, release or deployment occurs. Current fb09
Windows native/dependency failures and pending full/Qt jobs remain source-specific.
'''
with (REPO/'docs/plans/patchtrace-completion-matrix.md').open('a') as f:
    f.write(short+'''

| Feature / bounded scope | Current state | Completion | Remaining work | Source | Dependencies | Tests | Security | Owner | Acceptance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Internal KB held-reader propagation | Implemented and independently reviewed | D,R:50% for this slice | Durable held-origin intent/expected identity, postcommit checkpoints, native provider and final gates |d9a93991,PR316|Existing KB/core readers and caller-thread SQLite|Original32/1 and3/2 reds, author300, unchanged5 probe, combined803|No path fallback; full admission/hashes and finite prefix; retained committed outcome|KB + root|No exposed package route until durable recovery is qualified|
| Isolated dependency JSON UTF-8 | Implemented and independently reviewed | D,R:50% for this slice | Exact-source Windows pip/audit/packaging and lock closure |6dea194a,PR316|Existing isolated Python argv/environment and evidence validation|Original encoding failures, author/root167, combined803|Same bounds/pins/strict raw validation; no environment fallback|CI + root|Actual hosted Windows and final G|
| Native failure diagnostics | Implemented portable diagnostic support | D,R:50% for this diagnostic slice | Windows SDK build and actual error-path/complete native acceptance |9ca3c078/ace5db8b,PR316|Existing helper/Job/AppContainer evidence|Real portable formatter/refusal controls, preserved fixture errors, combined803|Fixed stderr vocabulary/numeric fields, finite lifetime budget; decisions unchanged|CI + root|Diagnostics cannot substitute for denial/cleanup/BinDiff receipts|
| Core durable admission hooks | Reviewed design; implementation assigned | None:0% for proposed hook implementation | Spec/tests-first optional ID and open/load recovery/checkpoint forwarding |3e4abd88|Existing model/store and approved core ownership|Ten current-behavior observations only|Committed/foreign/unknown retention and close-only stops required|Core + root|Meaningful reds, source review and actual-candidate replay|
| Whole PW02 local package fallback | Partial; no exposed package-to-project route | None:0% of whole-feature milestones | Native stage/FDI/worker handoff, durable intent/provenance/reconciliation, original budgets and frozen journey |Current portable slices and retained designs|Qualified Windows lane and existing KB/core services|Portable components only; whole journey absent|No lost-lease pathname resurrection or cross-project adoption|KB + core + CI|Complete specified D/R/J/G journey|

Frozen research outcomes, real CVE matching/calibration, full platform/Qt/native/
package/security/reproducibility acceptance remain unchanged and incomplete.
These completion fractions follow the existing D/R/J/G definitions, not test counts.
''')
for path,prefix in [('docs/qa.md','qa/'),('docs/plans/autonomous-consolidation-20261118/consolidation-ledger.md','../../qa/')]:
    with (REPO/path).open('a') as f:f.write(short.replace('../qa/',prefix))
with (REPO/'tasks/todo.md').open('a') as f:
    f.write('''\n\n### KB / encoding / native diagnostic checkpoint — 2026-11-18

- [x] Independently review and port UTF-8 invocation, three-file KB propagation/short-read correction and bounded diagnostic source; retain original failures and fixture corrections.
- [x] Pass the exact7b5f558f combined23-file gate:803 passes/0skips,118 canonical imports,14 owner paths and unchanged original probes. Preserve the prior802/1 registry red and path-only verifier mistake.
- [x] Preserve full normal lint success and unchanged unsuppressed strict80 failure.
- [x] Verify316-branch/63-PR delta, original131 focal heads, prior25-commit fb09 publication and fresh source-bound hosted evidence.
- [x] Review and approve the bounded existing-core admission design; assign spec/test-first implementation and separate durable KB design.
- [ ] Publish this checkpoint append-only with exact remote tree/parent/ref/preview verification.
- [ ] Independently review expected-ID/reopen checkpoint and owned-open failure handling before integration.
- [ ] Implement/qualify durable held-origin intent, actual project identity, provenance and idempotent reconciliation before package exposure.
- [ ] Qualify actual new-source Windows diagnostics/dependency fix, native stage/FDI/handoff, full platform/Qt/packaging/security/reproducibility gates and complete analyst/CVE journeys.
''')
print(json.dumps(dict(source=SOURCE,tree=tree,members=len(payloads),archive_bytes=archive.stat().st_size,archive_sha256=manifest['archive_sha256'])))
