"""Independently verify frozen hosted artifacts/log provenance; never extract native images."""
from __future__ import annotations
import hashlib
import io
import json
from pathlib import Path
import subprocess
import zipfile

ROOT=Path(__file__).resolve().parent.parent
REPO=ROOT/'continuation-integration'
Q=ROOT/'qa/hosted-pr316-fb09'


def sha(data):return hashlib.sha256(data).hexdigest()


def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])


seal=json.loads((Q/'seal.json').read_text())
manifest=json.loads((Q/'manifest.json').read_text())
raw=(Q/'evidence.zip').read_bytes()
assert sha(raw)==seal['sha256']=='dfeaa42b96f85b72883092c2fa8336ec4551f7898fc31689a6ef262b47930528'
assert len(raw)==seal['bytes']==3314801
assert sha((Q/'manifest.json').read_bytes())==seal['manifest_sha256']
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==429
    assert set(z.namelist())=={r['path'] for r in manifest['files']}|{'manifest.json'}
    assert z.read('manifest.json')==(Q/'manifest.json').read_bytes()
    for row in manifest['files']:
        data=z.read(row['path'])
        assert data==(Q/row['path']).read_bytes() and len(data)==row['bytes'] and sha(data)==row['sha256']
        if not row['path'].endswith('.zip'):
            assert not any(secret in data for secret in (b'X-Amz-Signature=',b'?sig=',b'&sig=')), row['path']
    source=manifest['source']
    assert source['head']=='fb09e43499f1abb84615b66b976629c22d5a41c2'
    assert git('rev-parse',source['head']+'^{tree}').decode().strip()==source['tree']
    assert git('rev-parse',source['preview']+'^{tree}').decode().strip()==source['tree']
    assert git('show','-s','--format=%P',source['preview']).decode().strip().split()==[source['base'],source['head']]
    assert '[no release]' in git('show','-s','--format=%B',source['head']).decode()
    for row in manifest['git_sources']:
        data=git('show',row['tree']+':'+row['path'])
        assert data==z.read(row['archived_path']) and sha(data)==row['sha256'] and len(data)==row['bytes']
    artifacts=0;members=0
    for name in z.namelist():
        if not name.startswith('artifacts/') or not name.endswith('.verified.json'):continue
        info=json.loads(z.read(name));api=info['api_metadata']
        data=z.read(info['archive'])
        assert len(data)==info['verified_size']==api['size_in_bytes']
        assert sha(data)==info['verified_sha256']==api['digest'].removeprefix('sha256:')
        assert api['workflow_run']['head_sha']==source['head']
        assert not info['signed_transfer_url_retained'] and not info['executed_members']
        with zipfile.ZipFile(io.BytesIO(data)) as original:
            assert original.testzip() is None and set(original.namelist())=={r['path'] for r in info['members']}
            for row in info['members']:
                body=original.read(row['path'])
                assert sha(body)==row['sha256'] and len(body)==row['bytes']
                assert original.getinfo(row['path']).CRC==row['crc32']
                members+=1
        artifacts+=1
    assert artifacts==16
    findings=json.loads(z.read('findings.json'))
    for row in findings['decoded_logs']:
        delivery=json.loads(z.read(row['delivery']))
        data=delivery['response']['structuredContent']['content'].encode('utf-8')
        assert data==z.read(row['path']) and sha(data)==row['sha256'] and len(data)==row['bytes']
        assert row['observed_checkout'] in data.decode('utf-8')
    assert len(findings['pending_once'])==7
    assert findings['check_counts']==dict(success=29,failure=6,skipped=3,in_progress=7)
    assert findings['windows_bindiff']['status']=='failed' and findings['linux_bindiff']['status']=='passed'
    assert findings['windows_network']['status']=='failed'
    for row in findings['windows_dependency']:
        assert row['process']['exit_code']==2 and not row['process']['timed_out'] and not row['process']['output_limited']
    assert sorted(r['audited_distributions'] for r in findings['linux_dependency'])==[17,32]
    assert all(r['inventory_matches_audit_exactly'] and r['vulnerabilities']==r['skips']==r['fixes']==0 for r in findings['linux_dependency'])
    record=dict(source=source,archive_sha256=sha(raw),archive_bytes=len(raw),payloads=len(manifest['files']),
        canonical_git_sources=len(manifest['git_sources']),verified_original_artifacts=artifacts,
        verified_original_members=members,decoded_logs=len(findings['decoded_logs']),
        signed_transfer_urls_in_packet=False,native_images_extracted_or_executed=False,
        no_new_source_acceptance=True,review='Full README and source/metadata boundaries reviewed. Win native/dependency failure and full/Qt pending remain; Linux fixture/profile successes retain original scope and source. Root records the distinction between scanner untriaged status and prior manual 80-site disposition separately.')
with (ROOT/'qa/kb-native-followup-root-review/hosted-fb09-verification.json').open('x') as f:
    json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in record.items() if k!='review'}))
