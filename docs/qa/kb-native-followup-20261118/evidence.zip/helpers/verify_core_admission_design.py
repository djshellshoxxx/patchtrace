"""Independently bind the read-only core admission proposal to frozen source and observations."""
from __future__ import annotations
import ast
import hashlib
import io
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT=Path(__file__).resolve().parent.parent
REPO=ROOT/'continuation-integration'
QA='3e4abd88df010c8dde95ec1661b0a877e9e39e82'
BASE='9ad2ec5cdbde85155fdca3cdd88804fd8b2e1a53'
STEM='docs/qa/pw02-core-admission-design-20261118'


def git(*args):
    return subprocess.check_output(['git','-C',str(REPO),*args])


def blob(ref,path):
    return git('show',ref+':'+path)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


manifest=json.loads(blob(QA,STEM+'.manifest.json'))
raw=blob(QA,STEM+'.zip')
assert sha(raw)==manifest['archive_sha256']=='2360724532d6bd77c73b1f52ef8640b80ea279dfc78ff3a1f7afdfe60ac5ec5a'
assert len(raw)==manifest['archive_bytes']==561595
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    assert z.testzip() is None and len(z.namelist())==len(set(z.namelist()))==107
    assert set(z.namelist())=={r['path'] for r in manifest['entries']}
    for row in manifest['entries']:
        data=z.read(row['path'])
        assert sha(data)==row['sha256'] and len(data)==row['bytes']
    provenance=json.loads(z.read('source-provenance.json'))
    for row in provenance['source_snapshots']+provenance['references']:
        data=blob(row['commit'],row['path']) if 'commit' in row else Path(row['original']).read_bytes()
        assert data==z.read(row['snapshot']) and sha(data)==row['sha256'] and len(data)==row['bytes']
    seams=json.loads(z.read('source-seams.json'))['seams']
    for row in seams:
        data=blob(BASE,row['path'])
        part=b''.join(data.splitlines(keepends=True)[row['first_line']-1:row['last_line']])
        assert sha(part)==row['sha256']
        found=[]
        def walk(nodes,prefix=''):
            for node in nodes:
                if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
                    name=prefix+node.name
                    if name==row['symbol']:
                        found.append(node)
                    if isinstance(node,ast.ClassDef):walk(node.body,name+'.')
        walk(ast.parse(data).body)
        assert len(found)==1 and found[0].end_lineno==row['last_line']
        assert min([found[0].lineno,*[d.lineno for d in found[0].decorator_list]])==row['first_line']
    for row in provenance['reviewed_core_comparison']:
        assert blob(row['reviewed_core'],row['path'])==blob(BASE,row['path'])==blob('7b5f558fb1a51d45427648c39c15995ab3697e2c',row['path'])
    for row in provenance['caller_searches']:
        result=subprocess.check_output(row['argv'],cwd=REPO)
        assert result==z.read(row['snapshot']) and sha(result)==row['sha256']
    imports=json.loads(z.read('current.imports.json'))
    assert imports['source_commit']==BASE and not imports['drift']
    for row in imports['modules']:
        assert sha(blob(BASE,row['relative_path']))==row['sha256']
    cases=list(ET.fromstring(z.read('current.xml')).iter('testcase'))
    assert len(cases)==10 and not any(c.find(t) is not None for c in cases for t in ('failure','error','skipped'))
    verification=json.loads(z.read('verification.json'))
    for row in verification['test_files_unchanged']:
        assert sha(Path(row['path']).read_bytes())==row['sha256']
    assert z.read('README.md')==blob(QA,'docs/plans/package-core-admission-seams-20261118.md')
    assert not git('diff',BASE,QA,'--','src','tests','tools','.github','docs/specs','docs/schemas','pyproject.toml')
    record=dict(design_commit=QA,source=BASE,archive_sha256=sha(raw),archive_bytes=len(raw),members=107,
        canonical_snapshots=len(provenance['source_snapshots']),references=len(provenance['references']),
        full_symbol_spans=len(seams),caller_searches=len(provenance['caller_searches']),
        passed_current_behavior_observations=len(cases),canonical_imports=len(imports['modules']),
        original_probes_unchanged=True,implementation_acceptance=False,
        root_review='Full proposal plus actual create/open, load/_verify_files/save boundary, Record and close inspected. Approve only service.create/open and persistence.load with tests-first optional bounded ID/recovery/read checkpoints. Durable held-origin facade/expected intent/ordered identity and native/package exposure remain separate requirements.')
with (ROOT/'qa/kb-native-followup-root-review/core-admission-design-verification.json').open('x') as f:
    json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in record.items() if k!='root_review'}))
