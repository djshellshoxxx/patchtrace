"""Read-only verification of the original hosted diagnosis and corrected worker supplement."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT=Path(__file__).resolve().parent.parent
REPO=ROOT/'continuation-integration'
OUT=ROOT/'qa/kb-native-followup-root-review'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(ref,path):
    return subprocess.check_output(['git','-C',str(REPO),'show',ref+':'+path])


def verify(z,files):
    assert z.testzip() is None
    assert len(z.namelist())==len(set(z.namelist()))==len(files)
    assert set(z.namelist())=={r['path'] for r in files}
    for row in files:
        raw=z.read(row['path'])
        assert len(raw)==row['bytes'] and sha(raw)==row['sha256']


def write(name,data):
    with (OUT/name).open('x') as f:
        json.dump(data,f,indent=2);f.write('\n')


q=ROOT/'qa/hosted-pr316-f3/ci-diagnosis'
manifest=json.loads((q/'manifest.json').read_text())
raw=(q/'evidence.zip').read_bytes()
assert len(raw)==119520 and sha(raw)=='7364e918b98da11e6898316f3e640a568d2372a67fa658ad33d0adae052114f8'
with zipfile.ZipFile(q/'evidence.zip') as z:
    verify(z,manifest['files'])
    capture=json.loads(z.read('capture.json'))
    assert capture['tree']==manifest['tree']=='e49299eabe4cff2304d9dbe15f94c3c79566af44'
    for row in capture['canonical_tree_sources']:
        data=blob(capture['tree'],row['path'])
        assert data==z.read('source/'+row['path']) and sha(data)==row['sha256'] and len(data)==row['bytes']
    selected=0
    for artifact in capture['artifacts']:
        p=ROOT/'qa/hosted-pr316-f3/artifacts'/('artifact-'+str(artifact['artifact_id'])+'.zip')
        data=p.read_bytes()
        assert len(data)==artifact['bytes']==artifact['api']['size_in_bytes']
        assert sha(data)==artifact['sha256']==artifact['api']['digest'].removeprefix('sha256:')
        with zipfile.ZipFile(p) as original:
            assert original.testzip() is None
            for row in artifact['selected_members']:
                body=original.read(row['path'])
                assert body==z.read('artifact-'+str(artifact['artifact_id'])+'/'+row['path'])
                assert len(body)==row['bytes'] and sha(body)==row['sha256']
                selected+=1
    for row in capture['logs']:
        delivery=ROOT/'qa/hosted-pr316-f3'/(row['name']+'-log-delivery.json')
        assert sha(delivery.read_bytes())==row['delivery_sha256']
        data=z.read('logs/'+row['name']+'.log')
        assert sha(data)==row['log_sha256'] and len(data)==row['bytes']
    build=json.loads(z.read('artifact-14470410950/network-build/build.json'))
    assert build['source']['tree']==capture['tree']
    for name,digest in build['sources'].items():
        assert sha(blob(capture['tree'],'tools/windows_network/'+name))==digest
    write('original-hosted-diagnosis-verification.json',dict(head=capture['head'],preview=capture['preview'],tree=capture['tree'],
        archive_bytes=len(raw),archive_sha256=sha(raw),members=len(manifest['files']),canonical_sources=len(capture['canonical_tree_sources']),
        original_artifacts_verified=len(capture['artifacts']),selected_members_compared=selected,complete_logs_verified=len(capture['logs']),
        native_build_sources_match=True,native_images_extracted_or_executed=False,
        disposition='Original native/dependency/static outcomes remain failed. Stage diagnostics are a later candidate, not a reinterpretation of this evidence.'))

p=ROOT/'qa/pw02-worker-independent-corrected-20261118.zip'
m=json.loads(p.with_suffix('.manifest.json').read_text())
raw=p.read_bytes()
assert len(raw)==m['archive_bytes']==10479
assert sha(raw)==m['archive_sha256']=='39ab82a6110bee26915cc11a88607716f2d2ad54f0d6dd9184527ac24b83c8e4'
with zipfile.ZipFile(p) as z:
    verify(z,m['files'])
    imports=json.loads(z.read('corrected.imports.json'))
    source=m['source_commit']
    assert source==imports['source_commit']=='7259f86838c2181d6bdbcabe98c7a294a4499e8d' and not imports['drift']
    for row in imports['modules']:
        assert sha(blob(source,row['relative_path']))==row['sha256']
    assert z.read('package_budget.py')==blob(source,'src/patchtrace/acquisition/package_budget.py')
    cases=list(ET.fromstring(z.read('corrected.xml')).iter('testcase'))
    assert len(cases)==5 and not any(c.find(tag) is not None for c in cases for tag in ('failure','error','skipped'))
    command=json.loads(z.read('corrected.command.json'))
    for row in command['test_files']:
        assert sha(Path(row['path']).read_bytes())==row['sha256']=='5396faa2c3934dbabc4b889949c10695efe490fa318ecaa235643f7d3a4dcc29'
    exit=json.loads(z.read('corrected.exit.json'))
    assert exit['pytest_exit']==exit['exit_code']==0 and not exit['drift'] and not exit['denied_attempts']
    write('corrected-worker-supplement-verification.json',dict(source=source,archive_sha256=sha(raw),archive_bytes=len(raw),
        members=len(m['files']),canonical_imports=len(imports['modules']),passed=len(cases),original_probe_unchanged=True))
print('Verified original hosted diagnosis and corrected worker supplement without extracting or executing native images.')
