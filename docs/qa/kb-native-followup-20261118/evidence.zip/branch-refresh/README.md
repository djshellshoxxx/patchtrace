# Branch and PR refresh after fb09

Read-only observation window: 2026-11-18T21:56:13.030910+00:00 through 2026-11-18T22:04:00.400262+00:00.
No remote write, checkout/source edit, new worktree, commit, merge, closure or dispatch.
The semantic worktree remains clean at `b2174a249c748487dba58bca6ffda48e56706e9c`.

## Delta and interpretation

The complete retained inventory at `d13a6d2466afb1f19348e6e2a643a49553f58811` captured 307 branches and
297 all-state PR records. Current GET pages and two exact ls-remote snapshots
agree on **316 branches**: **305 unchanged, two existing advances, nine additions,
zero removals**. The changes are the known #304/#307 updates and #308–#316.
All eleven tips are actual ancestors of current #316, with no remaining git
cherry rows against that head. Their exact commits, files, merge bases and raw
left/right counts are retained in changed-tip-dispositions.json.

The later sealed 16:43:56 UTC inventory had 62 open PRs. Every existing head,
base ref, title, draft flag and update timestamp matches. #316 is the sole
addition, giving **63 open PRs**; no prior open PR is absent. The latest published
fb09/main/#304/#307 readbacks also match. All **131 original focal branch tips**
still equal the seven retained semantic batch records. No stable source audit
was repeated; original broad residue remains open.

## Priority source and previews

| PR | Exact head | Exact base / merge base | Preview |
| --- | --- | --- | --- |
| #304 | `d8c02caea407f6d323eecd636735849c1eb31a2d` | `9c411ca3d7b47f950be5f0c6f01b3c54184554c6` | `f756d7f151857755c993ebeb95f7a27e1487b9d4` |
| #307 | `58fc130631f602b6e907bb054d30c21d810551d4` | `d8c02caea407f6d323eecd636735849c1eb31a2d` | `dfd25630e15444b70e371b8d7503ab2d81347663` |
| #316 | `fb09e43499f1abb84615b66b976629c22d5a41c2` | `9c411ca3d7b47f950be5f0c6f01b3c54184554c6` | `cf534b0e79fe523ce4ee376a277fa398ffe4af70` |

Each fetched preview has exactly [base, head] parents and a tree identical to
the head. Main remains `9c411ca3d7b47f950be5f0c6f01b3c54184554c6`. #304 is
mergeable/clean; #307 and #316 are mergeable/unstable. All remain open/unmerged.
All 322 observed refs (316 branch heads plus six priority head/merge refs)
match between the before/final snapshots; no head drift was observed.

## Reviews and checks

Fresh REST lists contain zero submitted reviews and zero inline comments for
#304/#307/#316. #304 has one unchanged historical issue comment. This supplies
no approval and does not replace retained independent local review.

At their recorded check timestamps, #304 has 28 success/3 skipped records;
#307 has 17 success/4 skipped/2 failed Qt records; #316 has 29 success/3 skipped,
7 in-progress QA/Qt records and 6 failures. The six failures come from two runs
covering the same three job families (Windows runtime dependency audit,
Windows packaging dependency audit, security scan). They are not six distinct
defects. No new artifact analysis or cause inference was performed.

## Evidence layout and limits

summary.json is the machine-readable receipt. raw/ retains every API response
and its URL/timestamps; git/ retains ls-remote/fetch commands and complete output.
baseline/ preserves the complete inventory, all seven semantic JSON records,
the exact sealed 62-PR member with manifest provenance and latest publication
readbacks. priority-pr-ancestry.json records parents/trees/merge bases;
changed-tip-dispositions.json contains only changed/new tips. review-summary.json
and check-summary.json retain current limitations and individual failing IDs.

interpretation-notes.json distinguishes observation windows, raw count order,
ancestry versus qualification, historical comment authority and overlapping
check records. analysis-corrections.json preserves the first metadata reader's
captured_at/data wrapper TypeError; the original archive member was unchanged
and then verified against its original manifest. Previously closed PRs remain
historical records. No test/native/manual/package/release acceptance or blanket
branch closure follows from this refresh.
