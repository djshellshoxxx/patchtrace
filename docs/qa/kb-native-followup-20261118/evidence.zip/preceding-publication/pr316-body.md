## Purpose

Continue the reviewed #304 → #307 integration chain with preserved history and source-specific evidence. This update fixes three independently reproduced boundary defects and adds the portable foundations needed for bounded local-package intake. Full main/beta qualification remains blocked.

## Latest reviewed milestone

- Actual PR head: `fb09e43499f1abb84615b66b976629c22d5a41c2`; tree `db005f5ede44b60fa2cf92581ac7dd685b087d99`.
- Equal-tree local checkpoint: `9ad2ec5cdbde85155fdca3cdd88804fd8b2e1a53`.
- Tested local source: `207eea9d4e125ac1d371139d4db803ddbc2b4c8a`; remote source counterpart `8580a7d6214a48f8e9f40034d6a655f996db77f7`; tree `29065e36f19ed4e3b0df73d80c8e16cabba1ce6f`.
- The final checkpoint adds documentation/evidence only. Source, tests, tools, workflow, specs, schemas and project configuration match the tested source.
- **1,103 passed, one native Windows skip, zero failures/errors/xfails**, 44.57 seconds. All 51 selected files, 28 unchanged independent cases, 498 imported project modules and 23 changed owner files are recorded and verified.
- Normal Ruff and generated-schema checks pass. The unsuppressed isolated strict S scan still fails on **80 unchanged diagnostic sites**.
- [Complete milestone and immutable evidence](https://github.com/djshellshoxxx/patchtrace/blob/fb09e43499f1abb84615b66b976629c22d5a41c2/docs/qa/worker-core-navigation-20261118/README.md): 132 verified payloads, 943,483-byte archive, SHA-256 `afa877d8bf7c413121d65e8194b97adaecc34fd1983ae64778e75565f12b68f2`.

## Behavior changed

| Scope | Result |
| --- | --- |
| Portable worker accounting | Strict serial grants and cumulative receipts preserve ownership, original budget/deadline, quiescence and permanent failure. A terminal receipt now prevents later complete/fail callbacks from mutating output tokens or counters. No native worker or package-to-project caller is introduced. |
| Neutral held core input | Optional Qt-free readers preserve complete PE/hash/ownership checks without pathname fallback; operation checkpoints run through owned reads and before the first-save COMMIT. A cleanup failure preserves the original cancellation/error and records a bounded retention note. No callback after committed save enters creation rollback. |
| Signal navigation | The existing action validates current location evidence before revealing text and refuses unsupported representations. Valid decompiled navigation, scoring/storage behavior and the unchanged UI size ceiling are preserved. |
| Design/disposition records | Retains the Phase2 reference contract disposition, exact dependency-installer map and native/KB seam evidence. These records do not implement hash-lock closure, reference interchange, native package intake or calibration. |

The original worker 2-fail/3-pass, core cleanup 1-fail/51-pass, stale navigation 3-fail/4-pass and representation 1-fail/1-pass probes remain intact. All fixture corrections, intermediate failures and author receipts stay attributed to their original source. Only fresh observation destinations are routed for the unchanged external tests.

## Publication and history

This is a 25-commit append to previous actual head `e78788791f03bd27b68e5891cd75ff0856b86342`, using a non-force expected-head update. Every remote commit was reread for exact tree, ordered parent, local-commit attribution and `[no release]` before updating the branch.

Earlier milestones remain historical: the reviewed continuation source had 6,356 passes/18 skips/three expected failures; the cache/full-smoke/import-purity source had 1,028 passes/two skips/one expected failure. They are not acceptance for unrelated newer source. All 131 original focal reconciliation tips have a disposition; whole-branch and research residue remains explicit.

No main merge, PR closure, branch deletion, tag, release or deployment is authorized by this checkpoint. Main was freshly read as `9c411ca3d7b47f950be5f0c6f01b3c54184554c6`.

## Open gates and active work

Actual-candidate full Linux/Windows QA, repeated Qt, native engines, frozen packages/installers, dependency/security and reproducibility gates remain required. The one local skip requires native Windows junction creation. Prior hosted job success badges are not substituted for failed or missing acceptance artifacts.

Retained prior-source Windows evidence shows dependency inventory failing on CP1252 Unicode output, and BinDiff native no-network acceptance failing with process-chain exit125. Socket timeouts are not network-denial evidence. Focused UTF-8 invocation and bounded native diagnostic work are in progress; actual hosted qualification remains pending.

Existing KB/core held-reader propagation is the next product slice. Native worker/stage/FDI, complete read accounting, durable package provenance/recovery, representative CVE/KB and analyst journeys remain incomplete. Frozen L1/L2/L3 outcomes and accuracy limits are unchanged.

See the [completion matrix](https://github.com/djshellshoxxx/patchtrace/blob/fb09e43499f1abb84615b66b976629c22d5a41c2/docs/plans/patchtrace-completion-matrix.md) and [consolidation ledger](https://github.com/djshellshoxxx/patchtrace/blob/fb09e43499f1abb84615b66b976629c22d5a41c2/docs/plans/autonomous-consolidation-20261118/consolidation-ledger.md).
