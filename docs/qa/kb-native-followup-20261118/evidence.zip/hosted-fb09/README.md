# PR316 fb09 hosted evidence — bounded read-only checkpoint

**This source remains unqualified.** Windows BinDiff's no-network check failed,
both canonical-push Windows dependency profiles failed before their final
audit, and the strict static scan returned 80 untriaged findings. The initial
snapshot still had both full QA jobs and all five Qt shards in progress. No
later status is inferred, and no check was dispatched, retried, or polled again.

## Source and capture boundary

The metadata read completed by **2026-11-18 21:56:04 UTC**. PR316 was open at
`fb09e43499f1abb84615b66b976629c22d5a41c2`, with base
`9c411ca3d7b47f950be5f0c6f01b3c54184554c6`. Its exact merge preview was
`cf534b0e79fe523ce4ee376a277fa398ffe4af70`. The GitHub commit responses show
both head and preview use tree
`db005f5ede44b60fa2cf92581ac7dd685b087d99`; preview parents are the captured
base and head. The actual head message contains the literal `[no release]` hold.

The single check snapshot contains 45 checks: 29 success, six failure, three
skipped, and seven in progress. The eleven workflow runs consist of nine PR
runs and two push runs, all attempt 1. The failures are the two Windows
dependency profiles and strict static scan in each of the push and PR runs.
The skipped jobs are the PR release gate, optional live build environment,
and optional dispatch-only MSVC advisory lane. The complete pending job IDs
and initial conclusions are in `findings.json` and the original delivery.
Windows standalone/package completion is not established while its QA
dependencies are pending.

This packet keeps canonical-push observations distinct from PR-preview
observations. Matching trees are useful for code comparison; they do not make
a PR preview a canonical release source. Eighteen relevant workflow/tool/C
files were read from the exact Git tree and retained under `source/`, with
canonical blob IDs in `source-snapshots.json`.

No later diagnostic implementation or UTF-8 correction is present in this
hosted source. The packet cannot qualify those changes. The separate native
diagnostic branch remains clean and unchanged at its already sealed QA tip
`dfdf1c488e242adc6b3a38eb6975e6503f1eb2b2`.

## Current failures and incomplete evidence

### Windows BinDiff

Run `44402969986`, job `135150625204`, artifact `14472587718` reports a green
advisory job, but the actual status JSON is **failed**. Six subchecks pass;
`checks.no_network` fails with `restricted control process chain: 125`.
The workflow intentionally permits the Windows live-test failure; its badge
and reported step conclusion are therefore insufficient.

The receipt binds the exact preview/tree above. The unrestricted probe chain
runs, but the restricted attempt records only depth 0. All four loopback cases
return `10060`, while external TCP returns access denied `10013`. The native
launcher records `tree_empty: true` and `timed_out: false`, returning `125`
after about 16.078 seconds. The aggregate's `process_tree_empty: false` records
an incomplete overall flow; it is not proof of surviving processes. Profile
and owned-tree cleanup are recorded as completed. No restricted BinDiff adapter,
full descendant chain, lifecycle controls, or post-cleanup positive chain is
established by this attempt.

The build receipt has the same three native source hashes as the earlier f3
failure and approved diagnostic baseline. The socket errors alone do not
explain the process exit in that code. The exact failing native API/stage
remains unknown until a later run of the separately reviewed diagnostics.
Artifact SHA-256 is
`187675a23a2a2a2ad5638ff027ee87194ee82857ccc7167464f2314f7d60adb7`
(194,544 bytes). Original f3 and earlier packets remain unchanged.

### Canonical Windows dependency profiles and strict static scan

Canonical push run `44402959775` owns Windows runtime artifact `14474726470`
and packaging artifact `14473851745`. Both contexts bind the actual head,
tree, repository, workflow, attempt and profile. Both fail at
`python -I -m pip inspect --local` in the scanner environment, exit 2,
without timeout or evidence-output overflow. Pip/Rich attempts CP1252 output
and cannot encode `U+1F44B`. Their stderr SHA-256
`9c8d5bab13d580f90abd73417ffd68363ec7a855ff703a1e5f8492156c1c072f`
and partial stdout SHA-256
`3523ffb210c3f208521f624b4a2162edb80ab8d2a23e9949a8d4ca9d014908c3`
match the earlier f3 failures byte for byte. These are new observations of
the old invocation, not a run of the later UTF-8 repair. Final product
inventories/audits were not reached, so neither Windows profile is clean.

Canonical static artifact `14472902047` retains the actual isolated Ruff S
command, its exit 1, full JSON, stderr, inventory and required text files.
There are **80 findings**: S608 35, S105 14, S110 12, S101 9, S310 6, S314 2,
S603 1, S108 1. No suppression or baseline acceptance was applied. These are
untriaged detector findings, not 80 confirmed vulnerabilities. The original
strict failure remains a blocker.

### Tier R remains incomplete

Run `44402970061` has a green aggregate job, but artifact `14473159146`
contains `ci-summary.status: warning`: **five of eleven rz-diff engine pairs
completed**, six failed because no older functions were reported. The failed
strata are AA, mutation, authored, and three noise pairs. A separate
byte-identical source-only card was skipped; it is not one of the eleven
engine attempts. Windows advisory artifact `14474781535` records eleven
`findings` cases with reason `exit 1`, no labels and no reports. Its underlying
cause was not investigated further in this bounded checkpoint. None of these
green badges establishes full compiler/corpus qualification.

## New positive Linux evidence and its exact limits

| Lane | Run / job | Actual retained observation |
| --- | --- | --- |
| BinDiff Linux | `44402969986` / `135150625485` | All seven fixture controls passed; pytest 1 passed in 16.13 s. |
| Rizin Linux | `44402969877` / `135150624547` | `live-rzdiff` passed, engine run `ok`, 30 matches, no recorded errors. |
| Unified Linux | `44402970399` / `135157345474` | Both authored pairs pass the recorded L0–L6 checks, including cross-OS content equality. |
| Dependency runtime Linux | `44402959775` / `135150587362` | Canonical-push inventory and actual audit cover the same 17 distributions. |
| Dependency packaging Linux | `44402959775` / `135150586258` | Canonical-push inventory and actual audit cover the same 32 distributions. |

The three native Linux job logs explicitly show checkout
`cf534b0e79fe523ce4ee376a277fa398ffe4af70`. Their artifacts are owned by the
same repository/run/head/attempt through GitHub metadata. The JSON receipts
that omit a source field are not treated as self-authenticating; their source
binding uses the observed checkout, owning job/run, artifact metadata and
verified archive. They remain PR-preview evidence.

Linux BinDiff artifact `14473302083` records 20 matches both ordinarily and
inside `unshare -rn`. The complete semantic fingerprint agrees:
`77f36f7aac14a6e321c2c6aba9e0c7e3ca6cdba3f690fc18d188ca987b88e181`.
This is stronger than count agreement, but applies only to the authored
20/21-function fixture and the recorded native tool. It does not establish
real-driver accuracy or Windows network containment.

Rizin artifact `14472557989` records version 0.9.1, pinned archive identity,
fixture hashes, output hash, required help flags and 30 matches. The separate
Windows artifact `14472652821` records a passed fixture run with 322 matches.
The two platforms use different compiled fixtures; their counts are not a
cross-platform equivalence assertion.

Unified Linux artifact `14473324489` and Windows artifact `14473773258`
contain the same four input hashes across two pairs. All four content digests
match across operating systems, and Ghidriff-retained programs agree with
independent analyze-mode extraction. The pairs have 377 and 383 functions
per side. H0, exported instruction-mask and mnemonic-with-operand-count
equivalence checks pass. The declared h3 comparison uses the 306/311 functions
without skipped instructions; 71/72 functions contain skipped instructions.
Legacy `hm` is coarser (`equal: false`) while satisfying its explicitly
required refinement condition. The current script requires that condition,
not legacy-hm class equality. No broader semantic or corpus claim is made.

The two canonical Linux dependency audits include **pip 26.3**, report zero
vulnerability rows, zero skipped distributions and zero fixes. Their exact
name/version sets equal the retained final auditable inventories; the
repository-owned PatchTrace distribution is separately identified. Both
bootstrap transitions and pinned wheel hashes are retained. These observations
apply to the selected installed Python production/optional/packaging profiles
and the advisory database used at that time. The retained `unaudited.json`
explicitly excludes external native tools/JDK, OS and vendored native code,
separate frozen/bundle bills of materials, calibration-dev, scanner-tool
dependencies, and vulnerabilities absent from that database. They do not
establish an overall clean security result.

## Other retained native Windows controls

Canonical Ghidriff push run `44402959896` has five distinct variants. Three
project variants retain raw Ghidriff JSON and backend execution receipts in
artifacts `14474077125`, `14473632665`, and `14472398341`; the receipts show
stopped processes, exit 0, and Ghidra 12.0.4/Ghidriff 1.0.0/Python 3.12.10.
The JVM version remains explicitly `unverified` in those backend receipts.

The raw-cache control log records a verified cache hit with one identical
normalized match and matching raw bytes. The plain-Ghidriff variant positively
reproduces the expected cached-PDB `FileExistsError`; it is an intentional
negative control. Those two jobs do not upload project artifacts: the workflow
selects a path they do not retain, and the logs report no files found. Their
bounded log observations are retained without inventing missing raw artifacts.
These are defined fixture controls, not general frozen-app or local-package
native acceptance.

## Retention and verification

The packet holds **16 original ZIP artifacts totaling 1,710,114 compressed
bytes**, eight decoded logs and their original connector delivery records,
one check/run snapshot, completed-job step metadata, and 18 exact Git-tree
source snapshots. Every ZIP was checked against its API SHA-256 and exact size,
all member CRCs were verified under explicit member/expanded-size bounds, and
member hashes were retained. Only bounded UTF-8 text members were materialized.
Native `.exe`, `.obj`, DLL, database and other binary members remain inert in
the original ZIPs; none was executed locally. No package or executable payload
was fetched beyond these small evidence artifacts.

Signed connector transfer URLs are not retained in this packet. Verification
records retain the connector file ID/host plus canonical GitHub artifact
metadata. Logs are exact UTF-8 encodings of the decoded tool deliveries;
`summary-setup-notes.md` records the initially normalized derivative newline
issue and its reconstruction from unchanged deliveries. GitHub did not provide
an independent digest for the decoded job logs.

`findings.json` contains the checked source/ownership relationships and
receipt comparisons. `manifest.json`, `seal.json` and `evidence.zip` freeze
the payloads. No code, policy, remote ref, release, tag, workflow dispatch or
native diagnostic source was changed while making this checkpoint.
