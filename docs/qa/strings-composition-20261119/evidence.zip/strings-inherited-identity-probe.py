"""Observe stored strings identity across a real project orientation swap; synthetic inputs only."""
import json
import tempfile
import threading
from pathlib import Path
from types import SimpleNamespace

import patchtrace.strings.cli as strings_cli
from test_ui_strings_run import fake_floss, make_project, tool_store

from patchtrace.strings.run_service import make_request, run_strings

with tempfile.TemporaryDirectory(prefix='patchtrace-orientation-proof-') as folder:
    root = Path(folder)
    with make_project(root, 'floss-static') as service:
        outcome = run_strings(make_request(service, floss=fake_floss(root, service)), threading.Event())
        assert outcome.state == 'ready'
        store = tool_store(service)
        for job in outcome.jobs:
            store.publish_run(job.run)
            store.publish_evidence(job.evidence)
        service.swap_orientation()
        expected = {a.side: a.sha256 for a in service.project.artifacts}
        result = strings_cli.compute(SimpleNamespace(source='auto', anchors=None, min_length=4),
                                     service, threading.Event())
        observed = {side: table.basis.artifact_sha256 for side, table in result.tables.items()}
        print(json.dumps({'module': strings_cli.__file__, 'expected_current_artifacts': expected,
                          'observed_source_artifacts': observed, 'sources': result.sources,
                          'wrong_artifact_reproduced': expected != observed}, indent=2))
