"""Authored runner receipts only: no compiler, engine, network, or target execution."""
import pytest

from tools.calibration.tier_r import shard as S


def run_case(rc, stdout, stderr):
    plan = {'contract': S.PLAN_CONTRACT, 'seed': 1, 'subset': 'smoke',
            'engines': ['rz-diff'], 'of': 1, 'cases_total': 1,
            'shards': [{'shard': 0, 'cases': ['suite:_template/tiny']}]}
    plan['plan_sha256'] = S.digest(plan, 'plan_sha256')
    calls, logs = [], []

    def captured(argv, timeout, env):
        calls.append(list(argv))
        return rc, stdout, None, stderr

    result = S.run_shard(plan, 0, runner=captured, log=logs.append)
    assert len(calls) == 2  # suite and its separate engine evaluation are both injected.
    assert result['labels'] == [] and result['features'] == [] and result['reports'] == []
    return result, logs


@pytest.mark.parametrize('stdout', ['', '{invalid-json'])
def test_exit1_without_contract_summary_preserves_failure_diagnostic(stdout):
    result, logs = run_case(1, stdout, 'Traceback (authored): fixture import failure')
    assert all(row['status'] == 'failed' for row in result['cases'])
    assert any('fixture import failure' in line for line in logs)


def test_declared_findings_remain_findings():
    result, _logs = run_case(1, '{"command":"suite","disagreements":1}', '')
    assert all(row['status'] == 'findings' for row in result['cases'])


def test_blocked_control_retains_stderr():
    result, logs = run_case(3, '{"command":"suite","error":"authored missing tool"}',
                            'fixture blocked detail')
    assert all(row['status'] == 'blocked' for row in result['cases'])
    assert any('fixture blocked detail' in line for line in logs)
