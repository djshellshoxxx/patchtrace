"""Seal the bounded Tier R repair packet; no repository/source mutation."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import zipfile


ROOT = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages')
QA = Path(__file__).resolve().parent
SOURCE = '4cdd463fa8d903c8b2ea6d2149d5003d23978122'
GENERATED = {'evidence.zip', 'manifest.json', 'seal.json'}


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT)


def canonical(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def write_new(name, raw):
    with (QA / name).open('xb') as output:
        output.write(raw)


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('status', '--porcelain')
assert not any((QA / name).exists() for name in GENERATED)
snapshots = []
for phase in ('red', 'green', 'affected'):
    command = json.loads((QA / f'{phase}.command.json').read_text())
    commit = command['source_commit']
    for record in command['source_files']:
        path = record['path']
        raw = (QA / f'{phase}-source' / path).read_bytes()
        assert raw == git('show', f'{commit}:{path}')
        assert hashlib.sha256(raw).hexdigest() == record['sha256']
        snapshots.append({
            'packet_path': f'{phase}-source/{path}', 'commit': commit,
            'repository_path': path, 'bytes': len(raw), 'sha256': record['sha256'],
            'git_blob': git('rev-parse', f'{commit}:{path}').decode().strip(),
        })
write_new('source-snapshots.json', canonical({'source_snapshots': snapshots}))

files = []
for path in sorted(QA.rglob('*')):
    if not path.is_file() or path.relative_to(QA).as_posix() in GENERATED:
        continue
    assert not path.is_symlink()
    raw = path.read_bytes()
    files.append({'path': path.relative_to(QA).as_posix(), 'bytes': len(raw),
                  'sha256': hashlib.sha256(raw).hexdigest()})
manifest = canonical({'contract': 'bounded-qa-manifest/1', 'source_commit': SOURCE, 'files': files})
write_new('manifest.json', manifest)
with zipfile.ZipFile(QA / 'evidence.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for record in files:
        info = zipfile.ZipInfo(record['path'], date_time=(1980, 1, 1, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, (QA / record['path']).read_bytes())
    info = zipfile.ZipInfo('manifest.json', date_time=(1980, 1, 1, 0, 0, 0))
    info.compress_type = zipfile.ZIP_DEFLATED
    info.external_attr = 0o100644 << 16
    archive.writestr(info, manifest)

with zipfile.ZipFile(QA / 'evidence.zip') as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files) + 1
    assert archive.read('manifest.json') == manifest
    for record in files:
        raw = archive.read(record['path'])
        assert len(raw) == record['bytes'] and hashlib.sha256(raw).hexdigest() == record['sha256']
original = QA / 'original-diagnosis/evidence.zip'
assert hashlib.sha256(original.read_bytes()).hexdigest() == 'feb8c805e92d3d9747968c73175719c6e38dddd3c42e36526d0b6d14912ca283'
with zipfile.ZipFile(original) as archive:
    assert archive.testzip() is None
raw = (QA / 'evidence.zip').read_bytes()
seal = {
    'contract': 'bounded-qa-seal/1', 'source_commit': SOURCE,
    'archive': {'path': 'evidence.zip', 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest(),
                'members': len(files) + 1, 'payloads': len(files)},
    'manifest_sha256': hashlib.sha256(manifest).hexdigest(),
    'verified_git_source_snapshots': len(snapshots), 'original_packet_preserved': True,
    'scope': 'Authored injected runners only; no compiler, engine, target or network execution. Native acceptance remains pending.',
}
write_new('seal.json', canonical(seal))
print(json.dumps(seal, indent=2))
