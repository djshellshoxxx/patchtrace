"""Pinned Tier R reporting controls; every runtime child/network attempt is refused."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time


ROOT = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages')
QA = Path(__file__).resolve().parent
ORIGINAL = QA.parent / 'tier-r-fb09-diagnosis/test_exit1_diagnostics.py'
PROBE_SHA = 'ab1629e9f61a3ca6b380f2abc4488cf2327a7891dcac977a1c6c25c3235d806e'
SOURCE, LABEL = sys.argv[1:]
assert LABEL in {'red', 'green', 'affected', 'affected-v2'}
for suffix in ('log', 'xml', 'command.json', 'imports.json', 'exit.json'):
    assert not (QA / f'{LABEL}.{suffix}').exists()
assert hashlib.sha256(ORIGINAL.read_bytes()).hexdigest() == PROBE_SHA
os.chdir(ROOT)
sys.dont_write_bytecode = True
sys.path[:0] = [str(ROOT / 'src'), str(ROOT), str(ROOT / 'tests')]
os.environ.update(PYTHONPATH=f'{ROOT}/src:{ROOT}', PYTHONDONTWRITEBYTECODE='1',
                  GIT_NO_REPLACE_OBJECTS='1', GIT_ALLOW_PROTOCOL='file', QT_QPA_PLATFORM='offscreen')
os.environ.pop('PATCHTRACE_TIER_R_NO_EVAL', None)


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT)


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('diff', '--name-only', 'HEAD')
blobs = {}
for row in git('ls-tree', '-r', '-z', SOURCE, 'src', 'tools', 'tests').split(b'\0'):
    if row:
        meta, path = row.split(b'\t', 1)
        blobs[path.decode()] = meta.split()[2].decode()
files = ['tests/test_tier_r_exit1_diagnostics.py', str(ORIGINAL)]
if LABEL.startswith('affected'):
    files += ['tests/test_tier_r_shard.py', 'tests/test_tier_r_aa_failures.py', 'tests/test_spec_registry.py']
owned = ['tools/calibration/tier_r/shard.py', 'tools/calibration/tier_r/cli.py',
         'docs/specs/known-answer-corpus.md', 'docs/modules.md', *[p for p in files if not Path(p).is_absolute()]]
snapshots = []
for name in owned:
    raw = (ROOT / name).read_bytes()
    assert raw == git('show', f'{SOURCE}:{name}')
    target = QA / f'{LABEL}-source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as output:
        output.write(raw)
    snapshots.append({'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
import pytest

temporary = Path(tempfile.mkdtemp(prefix='patchtrace-tier-r-exit1-'))
os.environ['TMPDIR'] = str(temporary)
tempfile.tempdir = str(temporary)
denied = []


def audit(event, args):
    if event in {'socket.__new__', 'socket.connect', 'socket.bind', 'socket.getaddrinfo',
                 'http.client.connect', 'subprocess.Popen', 'os.system', 'os.posix_spawn', 'os.fork', 'os.exec'}:
        denied.append(event)
        raise PermissionError('Tier R reporting gate refuses runtime children and network')


arguments = ['-q', '-p', 'no:cacheprovider', '--basetemp', str(temporary / 'pytest'),
             *files, f'--junitxml={QA}/{LABEL}.xml']
command = {'source_commit': SOURCE, 'cwd': str(ROOT), 'python': sys.version,
           'argv': [sys.executable, str(Path(__file__).resolve()), SOURCE, LABEL],
           'pytest_arguments': arguments, 'source_files': snapshots,
           'original_probe': {'path': str(ORIGINAL), 'sha256': PROBE_SHA},
           'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'scope': 'authored injected runner only; no compiler/engine/native/target/network execution',
           'git_identity_reads': 'read-only local Git completed before the runtime audit hook',
           'environment': {key: os.environ[key] for key in ('PYTHONPATH', 'PYTHONDONTWRITEBYTECODE',
                            'GIT_NO_REPLACE_OBJECTS', 'GIT_ALLOW_PROTOCOL', 'QT_QPA_PLATFORM', 'TMPDIR')}}
(QA / f'{LABEL}.command.json').write_text(json.dumps(command, indent=2) + '\n', encoding='utf-8')
(QA / f'{LABEL}-runner.py').write_bytes(Path(__file__).read_bytes())
started = time.monotonic()
sys.addaudithook(audit)
with (QA / f'{LABEL}.log').open('x', encoding='utf-8', newline='\n') as output:
    old_streams = sys.stdout, sys.stderr
    sys.stdout = sys.stderr = output
    try:
        outcome = int(pytest.main(arguments))
    finally:
        sys.stdout, sys.stderr = old_streams
modules, drift = [], []
for name, module in sorted(sys.modules.items()):
    if not (name.startswith('patchtrace') or name == 'tools' or name.startswith('tools.')):
        continue
    if not getattr(module, '__file__', None):
        continue
    path = Path(module.__file__).resolve()
    row = {'module': name, 'path': str(path)}
    if not path.is_relative_to(ROOT):
        drift.append(name)
    else:
        raw = path.read_bytes()
        relative = path.relative_to(ROOT).as_posix()
        blob = hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest()
        row.update(relative_path=relative, sha256=hashlib.sha256(raw).hexdigest(),
                   git_blob=blob, expected_git_blob=blobs.get(relative))
        if blob != blobs.get(relative):
            drift.append(name)
    modules.append(row)
for row in snapshots:
    if hashlib.sha256((ROOT / row['path']).read_bytes()).hexdigest() != row['sha256']:
        drift.append(row['path'])
if hashlib.sha256(ORIGINAL.read_bytes()).hexdigest() != PROBE_SHA:
    drift.append('original probe')
(QA / f'{LABEL}.imports.json').write_text(json.dumps({'source_commit': SOURCE, 'modules': modules,
                                                   'drift': drift}, indent=2) + '\n', encoding='utf-8')
code = outcome if not drift and not denied else 97
result = {'source_commit': SOURCE, 'pytest_exit': outcome, 'exit_code': code,
          'seconds': time.monotonic() - started, 'project_tool_imports': len(modules),
          'drift': drift, 'denied_attempts': denied, 'runtime_child_attempts': len(denied),
          'original_probe_sha256_after': hashlib.sha256(ORIGINAL.read_bytes()).hexdigest()}
(QA / f'{LABEL}.exit.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8')
print((QA / f'{LABEL}.log').read_text()[-2600:])
print(json.dumps(result))
shutil.rmtree(temporary)  # Completed, owned authored-fixture tree only.
raise SystemExit(code)
