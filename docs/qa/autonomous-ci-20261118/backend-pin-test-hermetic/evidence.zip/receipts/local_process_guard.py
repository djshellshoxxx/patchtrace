"""Qualification-only guard: local authored Git operations, no socket activity."""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

import pytest

active = False
allowed = []
denied = []


def audit(event, args):
    if not active:
        return
    if event in {'socket.connect', 'socket.getaddrinfo', 'socket.sendto', 'socket.sendmsg',
                 'os.system', 'os.posix_spawn', 'os.spawn'}:
        denied.append({'event': event})
        raise AssertionError(f'Qualification refuses external activity: {event}')
    if event == 'subprocess.Popen':
        executable, argv, cwd, _env = args
        entry = {'event': event, 'argv': list(argv), 'cwd': str(cwd) if cwd else None}
        allowed_executable = Path(executable).name in {'git', 'git.exe'}
        if not allowed_executable or not isinstance(argv, (list, tuple)):
            denied.append(entry)
            raise AssertionError('Qualification allows only authored local Git subprocesses')
        if 'fetch' in argv:
            local_repo = Path(argv[-2])
            if not local_repo.is_absolute() or not local_repo.is_dir():
                denied.append(entry)
                raise AssertionError('Qualification refused a nonlocal Git fetch before process creation')
        allowed.append(entry)


sys.addaudithook(audit)


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_protocol(item, nextitem):
    global active
    active = True
    try:
        yield
    finally:
        active = False


def pytest_sessionfinish(session, exitstatus):
    output = Path(os.environ['PT_LOCAL_GUARD_RECORD'])
    output.write_text(json.dumps({'allowed_local_processes': allowed, 'denied_events': denied,
                                 'git_protocol_allowlist': os.environ.get('GIT_ALLOW_PROTOCOL'),
                                 'exitstatus': int(exitstatus)}, indent=2) + '\n')
    if denied:
        session.exitstatus = 1
