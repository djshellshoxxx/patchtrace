"""Probe the existing no-input unit fixture without starting any subprocess.

The interception supplies only synthetic command outcomes. A separate Python
audit hook rejects real process creation and socket activity before execution.
"""
from __future__ import annotations

import importlib.util
import json
import os
import subprocess
import sys
from pathlib import Path


def test_no_input_fixture_uses_its_injected_runner(tmp_path, monkeypatch):
    root = Path(os.environ['PT_REVIEW_ROOT']).resolve()
    record_path = Path(os.environ['PT_REVIEW_RECORD']).resolve()
    record = {'source_root': str(root), 'intercepted_default_runner_calls': [], 'blocked_audit_events': []}
    active = [True]

    def audit(event, args):
        if active[0] and event in {'subprocess.Popen', 'os.system', 'os.posix_spawn', 'os.spawn',
                                   'socket.connect', 'socket.getaddrinfo', 'socket.sendto', 'socket.sendmsg'}:
            record['blocked_audit_events'].append(event)
            raise AssertionError(f'Independent pre-execution refusal: {event}')

    sys.addaudithook(audit)

    def intercept(argv, *args, **kwargs):
        argv = list(argv)
        cwd = kwargs.get('cwd')
        record['intercepted_default_runner_calls'].append({'argv': argv, 'cwd': str(cwd) if cwd else None})
        if argv in (['git', '--version'], ['gpg', '--version']):
            return subprocess.CompletedProcess(argv, 0, 'synthetic version for refusal probe\n', '')
        if argv == ['git', '-c', 'core.autocrlf=false', 'init', '-q']:
            return subprocess.CompletedProcess(argv, 0, '', '')
        return subprocess.CompletedProcess(argv, 1, '', 'independent interception: no command executed')

    try:
        spec = importlib.util.spec_from_file_location('review_backend_pin_test', root / 'tests/test_verify_backend_pins.py')
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        monkeypatch.setattr(subprocess, 'run', intercept)
        module.test_verify_without_inputs_records_nothing(tmp_path, monkeypatch)
        assert not record['intercepted_default_runner_calls'], 'unit fixture reached the default process runner'
        assert not record['blocked_audit_events'], 'unit fixture attempted a process or network operation'
    finally:
        active[0] = False
        record_path.write_text(json.dumps(record, indent=2) + '\n')
