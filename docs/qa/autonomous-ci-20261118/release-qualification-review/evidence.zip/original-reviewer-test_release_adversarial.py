"""Independent controls against exact release guard source 0bb63363.

Only authored Git repositories and REST/ZIP metadata. No target, network call,
release mutation, workflow dispatch or native qualification is performed.
"""
from __future__ import annotations

import copy
import io
import json
import math
import os
import subprocess
import sys
import zipfile

import pytest
from test_release_qualification import AuthoredAPI, SHA, assess, existing_release
from tools import release_qualification as gate


def git(root, *args):
    environment = dict(os.environ, GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL=os.devnull)
    return subprocess.run(['git', *args], cwd=root, env=environment, capture_output=True, text=True, check=True).stdout.strip()


def checkout(tmp_path, message='Authored accepted source'):
    root = tmp_path / 'repository'
    root.mkdir()
    git(root, 'init', '-q')
    git(root, 'config', 'user.name', 'Independent authored fixture')
    git(root, 'config', 'user.email', 'fixture@example.invalid')
    (root / 'tracked.txt').write_text('original reviewed content\n', encoding='utf-8')
    git(root, 'add', 'tracked.txt')
    git(root, 'commit', '-q', '-m', message)
    return root, git(root, 'rev-parse', 'HEAD')


@pytest.mark.parametrize('mask', ['replacement-object', 'assume-unchanged', 'skip-worktree'])
def test_actual_source_bytes_cannot_be_hidden_from_qualification(tmp_path, mask):
    root, sha = checkout(tmp_path)
    if mask == 'replacement-object':
        (root / 'tracked.txt').write_text('different unreviewed bytes\n', encoding='utf-8')
        git(root, 'add', 'tracked.txt')
        git(root, 'commit', '-q', '-m', 'Authored replacement view')
        replacement = git(root, 'rev-parse', 'HEAD')
        git(root, 'reset', '--soft', sha)
        git(root, 'replace', sha, replacement)
    else:
        git(root, 'update-index', '--' + mask, 'tracked.txt')
        (root / 'tracked.txt').write_text('different unreviewed bytes\n', encoding='utf-8')
    assert git(root, '--no-replace-objects', 'rev-parse', 'HEAD') == sha
    assert git(root, '--no-replace-objects', 'show', sha + ':tracked.txt') == 'original reviewed content'
    assert (root / 'tracked.txt').read_text().strip() == 'different unreviewed bytes'
    git(root, 'diff', '--quiet', 'HEAD', '--')  # normal diff is masked; this is the defect's precondition
    with pytest.raises(gate.QualificationError):
        gate.checked_source(root, sha)


def test_clean_source_and_actual_hold_metadata_are_still_enforced(tmp_path):
    root, sha = checkout(tmp_path, 'Authored actual commit [no release]')
    git(root, 'commit', '--allow-empty', '-q', '-m', 'Replacement hides the hold in its message')
    replacement = git(root, 'rev-parse', 'HEAD')
    git(root, 'reset', '--soft', sha)
    git(root, 'replace', sha, replacement)
    with pytest.raises(gate.QualificationError, match=r'\[no release\]'):
        gate.checked_source(root, sha)


@pytest.mark.parametrize('raw', [b'{"elapsed_s":1e999}', b'{"nested":[{"elapsed_s":-1e999}]}'])
def test_json_exponent_overflow_is_rejected_as_nonfinite_evidence(raw):
    assert math.isinf(json.loads(raw)['elapsed_s'] if b'nested' not in raw else json.loads(raw)['nested'][0]['elapsed_s'])
    with pytest.raises(gate.QualificationError):
        gate.strict_json(raw)


def native_zip(extra=b''):
    body = json.dumps({'engine': 'bindiff', 'status': 'passed', 'mocked': False,
                       'checks': {name: {'status': 'passed'} for name in gate.BINDIFF_CHECKS}}).encode()
    body = body[:-1] + extra + b'}'
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w') as archive:
        archive.writestr('bindiff.json', body)
    return buffer.getvalue()


def test_nonfinite_native_extra_metadata_cannot_qualify_the_full_aggregate():
    api = AuthoredAPI(gate)
    artifact = next(iter(api.artifacts_data.values()))[0]
    api.blobs[artifact['id']] = native_zip(b',"elapsed_s":1e999')
    assert not assess(gate, api)['qualified']


def test_two_platform_reports_cannot_claim_the_same_artifact_identity():
    api = AuthoredAPI(gate)
    artifacts = next(iter(api.artifacts_data.values()))
    assert len(artifacts) == 2 and artifacts[0]['name'] != artifacts[1]['name']
    artifacts[1]['id'] = artifacts[0]['id']
    assert not assess(gate, api)['qualified']


def test_valid_annotated_chain_keeps_existing_assets_and_only_reads():
    api = AuthoredAPI(gate)
    existing_release(api)
    tag_one, tag_two = 'b' * 40, 'c' * 40
    api.refs_data[0]['object'] = {'type': 'tag', 'sha': tag_one}
    api.tags_data[tag_one] = {'sha': tag_one, 'object': {'type': 'tag', 'sha': tag_two}}
    api.tags_data[tag_two] = {'sha': tag_two, 'object': {'type': 'commit', 'sha': SHA}}
    before = copy.deepcopy((api.refs_data, api.releases_data, api.tags_data))
    assert assess(gate, api)['qualified']
    assert before == (api.refs_data, api.releases_data, api.tags_data)


def test_command_failure_does_not_include_a_dummy_credential(monkeypatch, capsys):
    marker = 'AUTHORED_NOT_A_REAL_TOKEN'
    monkeypatch.setenv('GH_TOKEN', marker)
    with pytest.raises(gate.QualificationError) as raised:
        gate.command([sys.executable, '-c',
                      'import os, sys; sys.stderr.write(os.environ["GH_TOKEN"]); raise SystemExit(3)'])
    assert marker not in str(raised.value)
    captured = capsys.readouterr()
    assert marker not in captured.out + captured.err


def test_finite_numeric_metadata_and_normal_complete_evidence_remain_usable():
    assert gate.strict_json(b'{"elapsed_s":1e308}') == {'elapsed_s': 1e308}
    assert assess(gate, AuthoredAPI(gate))['qualified']
