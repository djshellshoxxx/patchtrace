"""Exact-source authored portable controls; deny sockets and all child creation."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages')
OUT = Path(__file__).resolve().parent
TESTS = ['tests/test_package_contracts.py', 'tests/test_package_paths.py', 'tests/test_package_budget.py',
         'tests/test_package_platform.py', 'tests/test_package_schemas.py', 'tests/test_package_boundary_edges.py',
         'tests/test_spec_registry.py']


def main():
    phase = sys.argv[1]
    if phase not in {'red', 'green', 'edge-red', 'final'}:
        raise SystemExit('unknown evidence phase')
    log, junit = OUT / f'{phase}.log', OUT / f'{phase}.xml'
    if log.exists() or junit.exists():
        raise SystemExit('refusing to overwrite previous evidence')
    os.chdir(ROOT)
    sys.path[:0] = [str(ROOT / 'src'), str(ROOT)]
    os.environ['PYTHONPATH'] = str(ROOT / 'src') + os.pathsep + str(ROOT)
    os.environ['QT_QPA_PLATFORM'] = 'offscreen'
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    import patchtrace
    assert Path(patchtrace.__file__).resolve().is_relative_to(ROOT / 'src')
    sha = subprocess.check_output(['git', '--no-replace-objects', 'rev-parse', 'HEAD'], text=True).strip()
    tracked = subprocess.check_output(['git', '--no-replace-objects', 'diff', '--binary', 'HEAD'])
    sources = sorted(p for pattern in ['src/patchtrace/acquisition/package*.py', 'tests/test_package*.py',
                                       'tests/package_support.py', 'tools/generate_package_schemas.py']
                     for p in ROOT.glob(pattern))
    provenance = {'head': sha, 'diff_sha256': hashlib.sha256(tracked).hexdigest(),
                  'python': sys.version, 'python_executable': sys.executable,
                  'imported_package': patchtrace.__file__,
                  'files': [{'path': p.relative_to(ROOT).as_posix(),
                             'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources],
                  'qualification': 'authored portable mechanics only; no Windows FDI or native credit'}
    attempts = []

    def audit(event, arguments):
        if event in {'socket.__new__', 'socket.connect', 'socket.bind', 'subprocess.Popen',
                     'os.system', 'os.posix_spawn', 'os.fork', 'os.exec'}:
            attempts.append(event)
            raise PermissionError('PW02 portable controls forbid network and child execution')

    sys.addaudithook(audit)
    import pytest
    base = tempfile.mkdtemp(prefix='patchtrace-pw02-contracts-')
    argv = ['-q', *TESTS, '--junitxml=' + str(junit), '--basetemp=' + base, '-p', 'no:cacheprovider']
    provenance['pytest_argv'] = argv
    with log.open('x', encoding='utf-8', newline='\n') as stream:
        old_out, old_err = sys.stdout, sys.stderr
        sys.stdout = sys.stderr = stream
        try:
            status = int(pytest.main(argv))
        finally:
            sys.stdout, sys.stderr = old_out, old_err
    provenance.update(exit_code=status, denied_attempts=attempts)
    (OUT / f'{phase}-provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
    print(json.dumps({'phase': phase, 'exit_code': status, 'denied_attempts': attempts,
                      'log': str(log), 'junit': str(junit)}))
    return status


if __name__ == '__main__':
    raise SystemExit(main())
