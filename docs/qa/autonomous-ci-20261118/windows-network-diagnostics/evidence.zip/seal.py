"""Seal immutable diagnostics controls; do not execute native or remote content."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import zipfile

QA = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages')
HEAD = 'ace5db8b3f5c300e0afb9f3dffd2978672514545'
PRODUCTION = '9ca3c078c1e14ba4895a5e10c00234985a0b3fc2'
BASE = '9f4e1a57dc75de8d34ef9023bea2fb7619690f0b'
CHAIN = [BASE, '666ee125f9fee045cb77d0c6021790cb47146a5e',
         '44654c74ab34305ad3a8be6a10db4f69ec7eeea5', PRODUCTION, HEAD]
PHASES = dict(zip(('red', 'red-write', 'final', 'final-v2'), CHAIN[1:], strict=True))


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT,
                                   env=dict(os.environ, GIT_NO_REPLACE_OBJECTS='1', GIT_ALLOW_PROTOCOL='file'))


def write_json(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(value, indent=2, sort_keys=True) + '\n')


assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert git('diff', '--name-only', 'HEAD') == b''
previous = 'df479203b4e5e878887493e2b21049aa54c1c1ae'
assert git('rev-parse', 'refs/heads/codex/pw02-worker-contracts-20261118').decode().strip() == previous
chain = []
for commit in CHAIN:
    record = json.loads(git('show', '-s', '--format={"sha":"%H","tree":"%T","parents":"%P"}', commit))
    chain.append(record)
for parent, child in zip(chain, chain[1:]):
    assert child['parents'] == parent['sha']
native = []
for name in ('common.h', 'probe.c', 'launcher.c'):
    path = 'tools/windows_network/' + name
    raw = git('show', HEAD + ':' + path)
    assert raw == git('show', PRODUCTION + ':' + path) == (ROOT / path).read_bytes()
    native.append({'path': path, 'bytes': len(raw), 'sha256': digest(raw),
                   'baseline_sha256': digest(git('show', BASE + ':' + path))})
originals = []
for relative, size, expected in (
    ('qa/hosted-pr316-f3/artifacts/artifact-14470410950.zip', 194511,
     '81495184fab2fc88adfbbc5889fd878f5b2a63e663c8b307feeb4fc5c73b316f'),
    ('qa/hosted-pr316-f3/ci-diagnosis/evidence.zip', 119520,
     '7364e918b98da11e6898316f3e640a568d2372a67fa658ad33d0adae052114f8'),
):
    path = ROOT.parent / relative
    raw = path.read_bytes()
    assert len(raw) == size and digest(raw) == expected
    originals.append({'path': str(path), 'bytes': size, 'sha256': expected, 'unchanged': True})
sources = []
for phase, commit in PHASES.items():
    command = json.loads((QA / f'{phase}.command.json').read_text())
    assert command['source_commit'] == commit
    for row in command['source_files']:
        relative = f'{phase}-source/' + row['path']
        raw = (QA / relative).read_bytes()
        canonical = git('show', commit + ':' + row['path'])
        assert raw == canonical and digest(raw) == row['sha256'] and len(raw) == row['bytes']
        sources.append({'path': relative, 'source_commit': commit, 'source_path': row['path'],
                        'git_blob': hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest(),
                        'sha256': digest(raw)})
final = json.loads((QA / 'final-v2.exit.json').read_text())
assert final['exit_code'] == 0 and not final['drift'] and not final['denied_attempts']
command = json.loads((QA / 'final-v2.command.json').read_text())
assert digest((QA / 'final-v2-runner.py').read_bytes()) == command['runner_sha256']
write_json(QA / 'provenance.json', {
    'source_chain': chain, 'production_commit': PRODUCTION, 'tested_commit': HEAD,
    'previous_retained_branch': {'name': 'codex/pw02-worker-contracts-20261118', 'head': previous},
    'branch': git('branch', '--show-current').decode().strip(), 'native_source_files': native,
    'original_failed_packets': originals, 'native_qualification': 'pending; portable evidence only',
})
files = []
for path in sorted(QA.rglob('*')):
    if path.is_dir():
        continue
    assert not path.is_symlink() and path.name not in {'evidence.zip', 'manifest.json', 'seal.json'}
    raw = path.read_bytes()
    files.append({'path': path.relative_to(QA).as_posix(), 'bytes': len(raw), 'sha256': digest(raw)})
write_json(QA / 'manifest.json', {'contract': 'diagnostic-qa-packet/1', 'tested_commit': HEAD,
                                 'production_commit': PRODUCTION, 'files': files, 'git_sources': sources})
manifest_bytes = (QA / 'manifest.json').read_bytes()
archive = QA / 'evidence.zip'
with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as packed:
    for name in [row['path'] for row in files] + ['manifest.json']:
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        packed.writestr(info, (QA / name).read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
with zipfile.ZipFile(archive) as packed:
    assert packed.testzip() is None
    assert set(packed.namelist()) == {row['path'] for row in files} | {'manifest.json'}
    for row in files:
        raw = packed.read(row['path'])
        assert len(raw) == row['bytes'] and digest(raw) == row['sha256']
    assert packed.read('manifest.json') == manifest_bytes
raw_archive = archive.read_bytes()
write_json(QA / 'seal.json', {'archive': 'evidence.zip', 'bytes': len(raw_archive),
                            'sha256': digest(raw_archive), 'members': len(files) + 1,
                            'verified_payloads': len(files), 'verified_git_sources': len(sources),
                            'manifest_sha256': digest(manifest_bytes),
                            'production_commit': PRODUCTION, 'tested_commit': HEAD})
destination = ROOT / 'docs/qa/autonomous-ci-20261118/windows-network-diagnostics'
destination.mkdir(parents=True, exist_ok=False)
for name in ('README.md', 'manifest.json', 'seal.json', 'evidence.zip'):
    shutil.copyfile(QA / name, destination / name)
    assert (destination / name).read_bytes() == (QA / name).read_bytes()
print((QA / 'seal.json').read_text())
