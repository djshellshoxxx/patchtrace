"""Static call-argument/order comparison, not native semantic qualification."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages')
QA = Path(__file__).resolve().parent
BASE = '9f4e1a57dc75de8d34ef9023bea2fb7619690f0b'
HEAD = 'ace5db8b3f5c300e0afb9f3dffd2978672514545'
NAMES = ['tools/windows_network/common.h', 'tools/windows_network/probe.c',
         'tools/windows_network/launcher.c']
EXCLUDED = {'GetLastError', 'SetLastError', 'WSAGetLastError', 'GetCurrentProcessId'}
LOWER = {'socket', 'connect', 'send', 'recv', 'select', 'getsockopt', 'ioctlsocket', 'closesocket', 'htons'}
STDOUT = {'printf', 'putchar', 'pt_json_wide'}
LEX = re.compile(r'//[^\n]*|/\*[\s\S]*?\*/|L?"(?:\\.|[^"\\])*"|'
                 r"L?'(?:\\.|[^'\\])*'|[A-Za-z_]\w*|[^\s]")


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT,
                                   env=dict(os.environ, GIT_NO_REPLACE_OBJECTS='1', GIT_ALLOW_PROTOCOL='file'))


def calls(text):
    tokens = [token for token in LEX.findall(text) if not token.startswith(('//', '/*'))]
    rows = []
    for index, token in enumerate(tokens[:-1]):
        if not re.fullmatch(r'[A-Za-z_]\w*', token) or tokens[index + 1] != '(':
            continue
        depth = 0
        for end in range(index + 1, len(tokens)):
            if tokens[end] == '(':
                depth += 1
            elif tokens[end] == ')':
                depth -= 1
                if depth == 0:
                    break
        rows.append({'name': token, 'arguments': ' '.join(tokens[index + 2:end])})
    return rows


assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert git('diff', '--name-only', 'HEAD') == b''
rows = []
for name in NAMES:
    old, new = (git('show', f'{sha}:{name}') for sha in (BASE, HEAD))
    assert (ROOT / name).read_bytes() == new
    # The first classifier incorrectly included the new X-macro formatter
    # declarations as Windows API calls. Compare native boundaries outside that
    # already separately exercised standard-C block; keep the first report.
    native = new.decode()
    if '/* PT_DIAGNOSTIC_PORTABLE_BEGIN */' in native:
        start = native.index('/* PT_DIAGNOSTIC_PORTABLE_BEGIN */')
        finish = native.index('/* PT_DIAGNOSTIC_PORTABLE_END */') + len('/* PT_DIAGNOSTIC_PORTABLE_END */')
        native = native[:start] + native[finish:]
    before, after = calls(old.decode()), calls(native)
    api = lambda row: (row['name'][0].isupper() or row['name'] in LOWER) and row['name'] not in EXCLUDED
    stdout = lambda row: row['name'] in STDOUT
    old_api, new_api = [row for row in before if api(row)], [row for row in after if api(row)]
    old_stdout, new_stdout = [row for row in before if stdout(row)], [row for row in after if stdout(row)]
    rows.append({'path': name, 'baseline_sha256': hashlib.sha256(old).hexdigest(),
                 'source_sha256': hashlib.sha256(new).hexdigest(), 'api_calls': old_api,
                 'same_api_call_arguments_and_lexical_order': old_api == new_api,
                 'stdout_calls': old_stdout, 'same_stdout_calls': old_stdout == new_stdout})
report = {'baseline': BASE, 'source': HEAD, 'files': rows,
          'excluded_error_and_owner_diagnostic_reads': sorted(EXCLUDED),
          'limit': 'Static lexical comparison only; branch execution, SDK compilation and Windows runtime remain unqualified.'}
with (QA / 'source-boundaries-v2.json').open('x', encoding='utf-8', newline='\n') as stream:
    stream.write(json.dumps(report, indent=2) + '\n')
checks = json.loads((QA / 'static-checks.json').read_text())
print(json.dumps({'files': [{key: row[key] for key in ('path', 'same_api_call_arguments_and_lexical_order',
                 'same_stdout_calls')} for row in rows], 'checks': checks}, indent=2))
raise SystemExit(0 if all(row['same_api_call_arguments_and_lexical_order'] and row['same_stdout_calls']
                         for row in rows) and all(row['exit_code'] == 0 for row in checks) else 1)
