#include <stdio.h>
#include <stdint.h>
#include <string.h>

/* One serial helper process, fixed vocabulary, no input strings or stdout.
   The final slot reports truncation. Failed writes also consume their slot. */
#define PT_DIAG_STAGES(X) \
    X(UNKNOWN, "unknown") X(DIAGNOSTIC_LIMIT, "diagnostic-limit") \
    X(PROCESS_ID, "process-id") X(PROCESS_TIMES, "process-times") \
    X(PROCESS_TOKEN, "process-token") X(TOKEN_APPCONTAINER, "token-appcontainer") \
    X(TOKEN_CAPABILITIES, "token-capabilities") X(TOKEN_SID, "token-sid") \
    X(CAPABILITY_COUNT, "capability-count") X(APP_SID, "app-sid") \
    X(SID_TEXT, "sid-text") X(SID_BOUND, "sid-bound") \
    X(PROCESS_SNAPSHOT, "process-snapshot") X(PROCESS_PARENT, "process-parent") \
    X(ARGUMENT_BOUND, "argument-bound") X(COMMAND_BUFFER, "command-buffer") \
    X(COMMAND_FORMAT, "command-format") X(IMAGE_OPEN, "image-open") \
    X(STDIO_KIND, "stdio-kind") X(NUL_OPEN, "nul-open") \
    X(STDOUT_DUPLICATE, "stdout-duplicate") X(STDERR_DUPLICATE, "stderr-duplicate") \
    X(ATTRIBUTE_SIZE, "attribute-size") X(ATTRIBUTE_BUFFER, "attribute-buffer") \
    X(ATTRIBUTE_INITIALIZE, "attribute-initialize") X(ATTRIBUTE_HANDLES, "attribute-handles") \
    X(ATTRIBUTE_CAPABILITIES, "attribute-capabilities") X(PARENT_TOKEN, "parent-token") \
    X(JOB_CREATE, "job-create") X(JOB_LIMITS, "job-limits") \
    X(PROCESS_CREATE, "process-create") X(JOB_ASSIGN, "job-assign") \
    X(CHILD_TOKEN, "child-token") X(TOKEN_MATCH, "token-match") \
    X(STARTUP_TERMINATE, "startup-terminate") X(STARTUP_WAIT, "startup-wait") \
    X(HANDLE_CLOSE, "handle-close") X(PROCESS_WAIT, "process-wait") \
    X(FINISH_WAIT, "finish-wait") X(EXIT_CODE, "exit-code") \
    X(JOB_TERMINATE, "job-terminate") X(JOB_QUERY, "job-query") X(JOB_EMPTY, "job-empty") \
    X(CHILD_EXIT, "child-exit") X(CHILD_SPAWN, "child-spawn") \
    X(CHILD_RESUME, "child-resume") X(CHILD_FINISH, "child-finish") \
    X(PROBE_ARGUMENTS, "probe-arguments") X(WINSOCK_STARTUP, "winsock-startup") \
    X(WINSOCK_CLEANUP, "winsock-cleanup") \
    X(RECEIPT_OPEN, "receipt-open") X(RECEIPT_WRITE, "receipt-write") X(RECEIPT_FLUSH, "receipt-flush") \
    X(SOCKET_ADDRESS, "socket-address") X(SOCKET_CREATE, "socket-create") \
    X(SOCKET_NONBLOCK, "socket-nonblock") X(SOCKET_CONNECT, "socket-connect") \
    X(SOCKET_CONNECT_WAIT, "socket-connect-wait") X(SOCKET_ERROR, "socket-error") \
    X(SOCKET_SEND, "socket-send") X(SOCKET_SEND_WAIT, "socket-send-wait") \
    X(SOCKET_RECEIVE, "socket-receive") X(SOCKET_RECEIVE_WAIT, "socket-receive-wait") \
    X(SOCKET_ECHO, "socket-echo") X(SOCKET_CLOSE, "socket-close")
#define PT_DIAG_KINDS(X) \
    X(UNKNOWN, "unknown") X(WIN32, "win32") X(WINSOCK, "winsock") X(VALIDATION, "validation") \
    X(TIMEOUT, "timeout") X(CHILD_EXIT, "child-exit") X(WAIT_RESULT, "wait-result") X(TRUNCATED, "truncated")
#define PT_DIAG_STAGE_ENUM(name, text) PT_DG_##name,
typedef enum { PT_DIAG_STAGES(PT_DIAG_STAGE_ENUM) PT_DG_COUNT } PT_DIAG_STAGE;
#undef PT_DIAG_STAGE_ENUM
#define PT_DIAG_KIND_ENUM(name, text) PT_DK_##name,
typedef enum { PT_DIAG_KINDS(PT_DIAG_KIND_ENUM) PT_DK_COUNT } PT_DIAG_KIND;
#undef PT_DIAG_KIND_ENUM
static uint32_t pt_diag_count = 0;

void pt_diag_emit(PT_DIAG_STAGE stage, PT_DIAG_KIND kind, uint32_t owner, uint32_t subject,
                  uint32_t error, uint32_t socket_index, uint32_t sent, uint32_t received) {
#define PT_DIAG_TEXT(name, text) text,
    static const char *const stages[] = {PT_DIAG_STAGES(PT_DIAG_TEXT)};
    static const char *const kinds[] = {PT_DIAG_KINDS(PT_DIAG_TEXT)};
#undef PT_DIAG_TEXT
    char record[512];
    int length;
    if (pt_diag_count >= 16) return;
    ++pt_diag_count;
    if (pt_diag_count == 16) {
        stage = PT_DG_DIAGNOSTIC_LIMIT; kind = PT_DK_TRUNCATED;
        subject = error = sent = received = 0; socket_index = UINT32_MAX;
    }
    if ((unsigned int)stage >= PT_DG_COUNT) stage = PT_DG_UNKNOWN;
    if ((unsigned int)kind >= PT_DK_COUNT) kind = PT_DK_UNKNOWN;
    length = snprintf(record, sizeof(record),
        "{\"diagnostic\":\"windows-network-diagnostic/1\",\"sequence\":%lu,\"stage\":\"%s\",\"kind\":\"%s\","
        "\"owner_pid\":%lu,\"subject_pid\":%lu,\"error\":%lu,\"socket_index\":%lu,"
        "\"sent_bytes\":%lu,\"received_bytes\":%lu}\n",
        (unsigned long)pt_diag_count, stages[stage], kinds[kind], (unsigned long)owner,
        (unsigned long)subject, (unsigned long)error, (unsigned long)socket_index,
        (unsigned long)sent, (unsigned long)received);
    if (length > 0 && (size_t)length < sizeof(record)) {
        (void)fwrite(record, 1, (size_t)length, stderr);
        (void)fflush(stderr);
    }
}
#undef PT_DIAG_STAGES
#undef PT_DIAG_KINDS

int main(int argc, char **argv) {
    unsigned int i;
    if (argc == 3 && strcmp(argv[1], "failed-write") == 0) {
        /* A valid read-only FILE rejects real stdio writes without a fake sink. */
        if (!freopen(argv[2], "r", stderr)) return 3;
        for (i = 0; i < 1000; ++i)
            pt_diag_emit(PT_DG_CHILD_SPAWN, PT_DK_WIN32, 1, 2, 5, UINT32_MAX, 0, 0);
        return pt_diag_count == 16 && ferror(stderr) ? 0 : 4;
    }
    if (argc != 2) return 2;
    if (strcmp(argv[1], "max") == 0) {
        pt_diag_emit(PT_DG_SOCKET_RECEIVE_WAIT, PT_DK_WINSOCK, UINT32_MAX, UINT32_MAX,
                     UINT32_MAX, UINT32_MAX, UINT32_MAX, UINT32_MAX);
    } else if (strcmp(argv[1], "invalid") == 0) {
        pt_diag_emit((PT_DIAG_STAGE)UINT32_MAX, (PT_DIAG_KIND)UINT32_MAX,
                     1, 2, 3, UINT32_MAX, 0, 0);
    } else if (strcmp(argv[1], "stages") == 0) {
        for (i = 0; i < PT_DG_COUNT; ++i) {
            pt_diag_count = 0; /* Independent formatter states, not the budget stress mode. */
            pt_diag_emit((PT_DIAG_STAGE)i, PT_DK_VALIDATION, 1, 2, 0, UINT32_MAX, 0, 0);
        }
    } else if (strcmp(argv[1], "kinds") == 0) {
        for (i = 0; i < PT_DK_COUNT; ++i) {
            pt_diag_count = 0;
            pt_diag_emit(PT_DG_UNKNOWN, (PT_DIAG_KIND)i, 1, 2, 0, UINT32_MAX, 0, 0);
        }
    } else if (strcmp(argv[1], "budget") == 0) {
        for (i = 0; i < 1000; ++i)
            pt_diag_emit(PT_DG_CHILD_SPAWN, PT_DK_WIN32, 1, 2, 5, UINT32_MAX, 0, 0);
    } else return 2;
    return 0;
}
