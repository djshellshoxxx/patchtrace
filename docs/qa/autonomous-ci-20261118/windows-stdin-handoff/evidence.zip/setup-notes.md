# Preserved setup failure

The first red runner accidentally retained only the previous formatter filename in its compiler allowlist. Its own audit hook refused the newly authorized stdin-handoff.c -> stdin-handoff-check compilation before the compiler ran. Red records retain 4 expected static/vocabulary failures, 8 positives and 45 fixture setup errors, with the exact denied argv. This is not a native failure or behavioral stdin red.

runner-v2.py adds only that exact authored source/output basename pair beneath the same owned temporary directory, with the unchanged fixed compiler arguments, compiler identity and no-network/unapproved-child guard. Repository source/tests remain at 56a7766bed47dcb30dc8b9d4ccb72123d2bff786. The original runner and red receipts are unchanged.
