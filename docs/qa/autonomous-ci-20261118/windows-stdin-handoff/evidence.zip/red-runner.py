"""Pinned portable stdin gate; authored scripted APIs/formatting and inspected local fixtures only."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages')
QA = Path(__file__).resolve().parent
SOURCE, LABEL = sys.argv[1:]
assert LABEL in {'red', 'red-v2', 'source', 'final', 'final-v2'}
for suffix in ('log', 'xml', 'command.json', 'imports.json', 'exit.json'):
    assert not (QA / f'{LABEL}.{suffix}').exists(), 'refusing to overwrite evidence'
os.chdir(ROOT)
sys.dont_write_bytecode = True
sys.path[:0] = [str(ROOT / 'src'), str(ROOT), str(ROOT / 'tests')]
os.environ.update(PYTHONPATH=f'{ROOT}/src:{ROOT}', QT_QPA_PLATFORM='offscreen',
                  PYTHONDONTWRITEBYTECODE='1', GIT_NO_REPLACE_OBJECTS='1', GIT_ALLOW_PROTOCOL='file')


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT)


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert git('diff', '--name-only', 'HEAD') == b''
blobs = {}
for row in git('ls-tree', '-r', '-z', SOURCE, 'src', 'tools', 'tests').split(b'\0'):
    if row:
        meta, name = row.split(b'\t', 1)
        blobs[name.decode()] = meta.split()[2].decode()
files = ['tests/test_windows_network_stdin.py', 'tests/test_windows_network_diagnostics.py']
if LABEL.startswith('final'):
    files += ['tests/test_windows_bindiff_network.py', 'tests/test_spec_registry.py']
owned = ['tools/windows_network/common.h', 'tools/windows_network/probe.c',
         'tools/windows_network/launcher.c', 'docs/specs/windows-bindiff-network-acceptance.md',
         'docs/modules.md', *files]
snapshots = []
for name in dict.fromkeys(owned):
    raw = (ROOT / name).read_bytes()
    assert raw == git('show', f'{SOURCE}:{name}')
    target = QA / f'{LABEL}-source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as stream:
        stream.write(raw)
    snapshots.append({'path': name, 'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)})
compiler = shutil.which('cc')
compiler_receipt = None
if compiler:
    compiler_receipt = {'path': compiler, 'resolved_path': str(Path(compiler).resolve()),
                        'sha256': hashlib.sha256(Path(compiler).read_bytes()).hexdigest(),
                        'version': subprocess.check_output([compiler, '--version'], text=True)[:2000]}
import pytest

STDIN_MODES = {'forward-cleanup-fails', 'select-cleanup-error', 'capture-load-fails', 'capture-disk', 'forward-replaced', 'forward-duplicate-fails', 'capture-query-fails', 'select-neither', 'select-both', 'forward-copy-type', 'forward-ok', 'release-both-fail', 'select-forward', 'release-close-fails', 'select-fresh-protected', 'forward-copy-protected', 'capture-startup-invalid', 'release-twice', 'forward-private-inherit', 'forward-copy-flags', 'capture-validation-cleanup-fails', 'forward-copy-identity', 'capture-startup-null', 'select-fresh-pipe', 'capture-type-error', 'capture-private-identity', 'capture-private-flags', 'capture-private-type', 'capture-duplicate-fails', 'forward-private-protected', 'forward-race', 'capture-identity', 'select-fresh', 'capture-no-flag', 'capture-current-null', 'capture-pipe', 'capture-export-cleanup-fails', 'capture-race', 'capture-export-fails', 'select-nul-fails', 'forward-occupied', 'capture-ok', 'capture-current-invalid', 'capture-unknown', 'release-module-fails'}

children, denied = [], []
temporary = Path(tempfile.mkdtemp(prefix='patchtrace-stdin-handoff-'))
formatter_runs = []
original_run = subprocess.run


def capture_formatter(*args, **kwargs):
    result = original_run(*args, **kwargs)
    argv = args[0] if args else kwargs.get('args')
    if not isinstance(argv, (list, tuple)) or not argv:
        return result
    executable = os.fsdecode(argv[0])
    if executable != compiler and Path(executable).name not in {'formatter-check', 'stdin-handoff-check'}:
        return result
    label = 'compile' if executable == compiler else argv[1]
    prefix = QA / f'{LABEL}-portable-{len(formatter_runs):03d}-{label}'
    record = {'argv': list(argv), 'returncode': result.returncode, 'output': {}}
    for name in ('stdout', 'stderr'):
        raw = getattr(result, name)
        assert isinstance(raw, bytes) and len(raw) <= 1024 * 1024
        path = prefix.with_name(prefix.name + f'.{name}.txt')
        with path.open('xb') as stream:
            stream.write(raw)
        record['output'][name] = {'path': path.name, 'bytes': len(raw),
                                  'sha256': hashlib.sha256(raw).hexdigest()}
    if label == 'compile' and result.returncode == 0:
        source, binary = Path(argv[5]), Path(argv[7])
        raw = source.read_bytes()
        (QA / f'{LABEL}-{source.name}').write_bytes(raw)
        record['harness_sha256'] = hashlib.sha256(raw).hexdigest()
        record['local_formatter_sha256'] = hashlib.sha256(binary.read_bytes()).hexdigest()
    formatter_runs.append(record)
    return result


subprocess.run = capture_formatter


def audit(event, args):
    if event in {'socket.__new__', 'socket.connect', 'socket.bind', 'os.system',
                 'os.fork', 'os.posix_spawn', 'os.exec'}:
        denied.append(event)
        raise PermissionError('diagnostic gate refuses network and unapproved child execution')
    if event != 'subprocess.Popen':
        return
    executable, argv, cwd = os.fsdecode(args[0]), list(args[1]), args[2]
    category = None
    # Compile only the actual authored formatter or stdin helper excerpt.
    # Stdin APIs are scripted surrogates: no Windows ABI/native acceptance.
    if executable == compiler and len(argv) == 8 and argv[1:5] == [
            '-std=c11', '-Wall', '-Wextra', '-Werror'] and argv[6] == '-o':
        source, output = Path(argv[5]), Path(argv[7])
        if source.is_relative_to(temporary) and output.parent == source.parent and (
                source.name, output.name) == ('formatter.c', 'formatter-check'):
            category = 'authored-portable-C-compile'
    elif Path(executable).is_relative_to(temporary) and Path(executable).name == 'formatter-check':
        if len(argv) == 2 and argv[1] in {'max', 'invalid', 'stages', 'kinds', 'budget'}:
            category = 'authored-portable-formatter-run'
        elif (len(argv) == 3 and argv[1] == 'failed-write'
              and Path(argv[2]) == Path(executable).with_name('formatter.c')):
            category = 'authored-portable-formatter-write-failure'
    elif Path(executable).is_relative_to(temporary) and Path(executable).name == 'stdin-handoff-check':
        if len(argv) == 2 and argv[1] in STDIN_MODES:
            category = 'authored-scripted-stdin-control'
    # These three original tests use inspected local Git, an authored Python
    # stdout fixture, and the repository's fixed fake BinDiff in mode=ok.
    elif Path(executable).name == 'git' and cwd and Path(cwd).resolve().is_relative_to(temporary):
        command = next((arg for arg in argv[1:] if arg in {
            'init', 'add', 'commit', 'rev-parse', 'show', 'ls-tree', 'cat-file'}), None)
        if command and not {'fetch', 'push', 'clone', 'pull', 'ls-remote'}.intersection(argv):
            category = 'authored-local-git-fixture'
    elif executable == sys.executable and len(argv) == 4 and argv[1:3] == ['-u', '-c']:
        if argv[3].startswith('import json,os,time; from pathlib import Path; '):
            category = 'authored-short-pipe-fixture'
    elif Path(executable).is_relative_to(temporary) and Path(executable).name == 'bindiff':
        raw = Path(executable).read_text(encoding='utf-8')
        if "MODE = 'ok'" in raw and raw.startswith('#!'):
            category = 'authored-fake-bindiff-fixture'
    record = {'argv': argv, 'cwd': str(cwd) if cwd else None, 'category': category}
    children.append(record)
    if category is None:
        denied.append(record)
        raise PermissionError('unapproved diagnostic-gate child')


arguments = ['-q', '-p', 'no:cacheprovider', '--basetemp', str(temporary / 'pytest'),
             *files, f'--junitxml={QA}/{LABEL}.xml']
(QA / f'{LABEL}.command.json').write_text(json.dumps({
    'source_commit': SOURCE, 'cwd': str(ROOT), 'python': sys.version,
    'argv': [sys.executable, str(Path(__file__).resolve()), SOURCE, LABEL],
    'pytest_arguments': arguments, 'source_files': snapshots, 'compiler': compiler_receipt,
    'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'scope': 'actual authored stdin C with scripted Win32 APIs, formatter and Python evidence controls; no Windows compilation/native acceptance',
    'audit_limit': 'Python parent audit; local compiler descendants are not instrumented',
    'environment': {key: os.environ[key] for key in ('PYTHONPATH', 'QT_QPA_PLATFORM',
                     'PYTHONDONTWRITEBYTECODE', 'GIT_NO_REPLACE_OBJECTS', 'GIT_ALLOW_PROTOCOL')},
}, indent=2) + '\n')
(QA / f'{LABEL}-runner.py').write_bytes(Path(__file__).read_bytes())
started = time.monotonic()
sys.addaudithook(audit)
with (QA / f'{LABEL}.log').open('x', encoding='utf-8', newline='\n') as stream:
    previous = sys.stdout, sys.stderr
    sys.stdout = sys.stderr = stream
    try:
        outcome = int(pytest.main(arguments))
    finally:
        sys.stdout, sys.stderr = previous
modules, drift = [], []
for name, module in sorted(sys.modules.items()):
    if not (name.startswith('patchtrace') or name == 'tools' or name.startswith('tools.')):
        continue
    if not getattr(module, '__file__', None):
        continue
    path = Path(module.__file__).resolve()
    record = {'name': name, 'path': str(path)}
    if not path.is_relative_to(ROOT):
        drift.append(name)
    else:
        raw = path.read_bytes()
        relative = path.relative_to(ROOT).as_posix()
        blob = hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest()
        record.update(relative_path=relative, sha256=hashlib.sha256(raw).hexdigest(),
                      git_blob=blob, expected_git_blob=blobs.get(relative))
        if blob != blobs.get(relative):
            drift.append(name)
    modules.append(record)
for record in snapshots:
    if hashlib.sha256((ROOT / record['path']).read_bytes()).hexdigest() != record['sha256']:
        drift.append(record['path'])
(QA / f'{LABEL}.imports.json').write_text(json.dumps({'source_commit': SOURCE, 'modules': modules,
                                                    'drift': drift}, indent=2) + '\n')
result = outcome if not drift and not denied else 1
(QA / f'{LABEL}.exit.json').write_text(json.dumps({
    'source_commit': SOURCE, 'pytest_exit': outcome, 'exit_code': result,
    'project_tool_imports': len(modules), 'drift': drift, 'denied_attempts': denied,
    'approved_children': children, 'seconds': time.monotonic() - started,
    'formatter_runs': formatter_runs,
}, indent=2) + '\n')
print((QA / f'{LABEL}.log').read_text()[-2500:])
print(json.dumps({'label': LABEL, 'source': SOURCE, 'exit_code': result,
                  'imports': len(modules), 'drift': drift, 'denied': denied, 'children': len(children)}))
shutil.rmtree(temporary)  # Only this runner's completed, owned fixture/build tree.
raise SystemExit(result)
