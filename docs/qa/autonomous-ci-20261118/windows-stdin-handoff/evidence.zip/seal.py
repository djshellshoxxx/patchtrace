"""Verify local receipts/source snapshots and seal the bounded stdin candidate."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile


QA = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages')
BASE = 'c1685bca780de6702d8c3d1932136f75f760de35'
SPEC = '56a7766bed47dcb30dc8b9d4ccb72123d2bff786'
SOURCE = '3d0831025d50d231171aa69c32be4021b18fe7f6'
TIP = '49e2bf908b76e0296f645afb7450e634b6036b8a'
OLD = 'dfdf1c488e242adc6b3a38eb6975e6503f1eb2b2'
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_NO_REPLACE_OBJECTS='1')


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT, env=ENV)


def load(name):
    return json.loads((QA / name).read_bytes())


def write(name, value):
    with (QA / name).open('x', encoding='utf-8', newline='\n') as output:
        json.dump(value, output, indent=2, ensure_ascii=False)
        output.write('\n')


def main():
    assert git('rev-parse', 'HEAD').decode().strip() == TIP
    assert git('rev-parse', 'refs/heads/codex/windows-network-diagnostics-20261118').decode().strip() == OLD
    assert not git('status', '--porcelain=v1', '--untracked-files=no')
    git('diff', '--check', BASE, TIP)
    expected_paths = {
        'tools/windows_network/common.h', 'tools/windows_network/probe.c',
        'tools/windows_network/launcher.c', 'tests/test_windows_network_stdin.py',
        'tests/test_windows_network_diagnostics.py', 'docs/modules.md',
        'docs/specs/windows-bindiff-network-acceptance.md',
    }
    assert set(git('diff', '--name-only', BASE, TIP).decode().splitlines()) == expected_paths
    phases = []
    snapshots = []
    outputs = 0
    expected_results = {
        'red': (SPEC, 4, 45, 8), 'red-v2': (SPEC, 47, 0, 10),
        'source': (SOURCE, 0, 0, 57), 'final': (SOURCE, 0, 0, 379),
        'final-v2': (TIP, 0, 0, 379),
    }
    for label, (commit, failed, errors, passed) in expected_results.items():
        command, imports, result = [load(f'{label}.{suffix}.json') for suffix in ('command', 'imports', 'exit')]
        assert command['source_commit'] == imports['source_commit'] == result['source_commit'] == commit
        assert not imports['drift'] and not result['drift']
        if label != 'red':
            assert not result['denied_attempts']
        else:
            assert len(result['denied_attempts']) == 1
            assert Path(result['denied_attempts'][0]['argv'][5]).name == 'stdin-handoff.c'
        nodes = list(ET.parse(QA / f'{label}.xml').iter('testcase'))
        actual_failed = sum(node.find('failure') is not None for node in nodes)
        actual_errors = sum(node.find('error') is not None for node in nodes)
        actual_skipped = sum(node.find('skipped') is not None for node in nodes)
        actual_passed = len(nodes) - actual_failed - actual_errors - actual_skipped
        assert (actual_failed, actual_errors, actual_passed, actual_skipped) == (failed, errors, passed, 0)
        for record in command['source_files']:
            path = record['path']
            raw = (QA / f'{label}-source' / path).read_bytes()
            assert len(raw) == record['bytes'] and sha(raw) == record['sha256']
            assert raw == git('show', f'{commit}:{path}')
            snapshots.append({'phase': label, 'commit': commit, **record,
                              'git_blob': git('rev-parse', f'{commit}:{path}').decode().strip()})
        runner = (QA / f'{label}-runner.py').read_bytes()
        assert sha(runner) == command['runner_sha256']
        for process in result['formatter_runs']:
            for record in process['output'].values():
                path = QA / record['path']
                assert path.parent == QA
                raw = path.read_bytes()
                assert len(raw) == record['bytes'] and sha(raw) == record['sha256']
                outputs += 1
            if 'harness_sha256' in process:
                name = Path(process['argv'][5]).name
                assert sha((QA / f'{label}-{name}').read_bytes()) == process['harness_sha256']
        phases.append({'phase': label, 'commit': commit, 'failed': failed, 'errors': errors,
                       'passed': passed, 'skipped': 0, 'project_tool_imports': len(imports['modules']),
                       'denied_attempts': len(result['denied_attempts']),
                       'approved_child_records': sum(row['category'] is not None for row in result['approved_children'])})
    for label, commit, code in [('ruff', SOURCE, 1), ('ruff-v2', TIP, 0)]:
        receipt = load(label + '.json')
        assert receipt['source'] == commit and receipt['exit_code'] == code
        for stream in ('stdout', 'stderr'):
            assert sha((QA / f'{label}.{stream}.log').read_bytes()) == receipt[f'{stream}_sha256']
    design = QA / 'approved-design'
    seal = json.loads((design / 'seal.json').read_bytes())
    raw = (design / 'evidence.zip').read_bytes()
    assert len(raw) == 27706 and sha(raw) == seal['sha256'] == '1369f6b5ef62a9a937aecbb38a268a757ac1480b59a05357befe54f50e5aba6e'
    assert sha((design / 'manifest.json').read_bytes()) == seal['manifest_sha256']
    with zipfile.ZipFile(design / 'evidence.zip') as archive:
        assert archive.testzip() is None and len(archive.infolist()) == 11
        assert archive.read('manifest.json') == (design / 'manifest.json').read_bytes()
        for item in json.loads(archive.read('manifest.json'))['payloads']:
            raw = archive.read(item['path'])
            assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
    native = load('native-red-reference.json')
    row = native['retained_stderr']
    raw = (QA / row['copy']).read_bytes()
    assert raw == Path(row['original']).read_bytes() and len(raw) == row['bytes'] and sha(raw) == row['sha256']
    verification = {
        'baseline': BASE, 'spec_tests': SPEC, 'production': SOURCE, 'tested_tip': TIP,
        'tested_tree': git('rev-parse', TIP + '^{tree}').decode().strip(),
        'prior_diagnostic_branch_retained': OLD,
        'owner_paths': sorted(expected_paths), 'phases': phases,
        'verified_git_source_snapshots': len(snapshots), 'source_snapshots': snapshots,
        'verified_raw_child_outputs': outputs,
        'approved_design_payloads_verified': 10,
        'approved_design_zip_sha256': seal['sha256'],
        'native_qualification': False,
        'limits': ['Scripted Win32 APIs do not establish SDK/ABI/native behavior.',
                   'Python audit does not instrument compiler descendants.',
                   'Original four loopback timeouts still do not qualify 10013 denial.'],
    }
    write('verification.json', verification)
    payloads = []
    for path in sorted(QA.rglob('*')):
        if not path.is_file() or path.relative_to(QA).as_posix() in {'manifest.json', 'seal.json', 'evidence.zip'}:
            continue
        assert not path.is_symlink()
        raw = path.read_bytes()
        payloads.append({'path': path.relative_to(QA).as_posix(), 'bytes': len(raw), 'sha256': sha(raw)})
    assert sum(row['bytes'] for row in payloads) < 15_000_000
    write('manifest.json', {'schema': 'windows-stdin-handoff-qa/1', 'source': SOURCE,
                            'tested_tip': TIP, 'payloads': payloads})
    with zipfile.ZipFile(QA / 'evidence.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
        for row in payloads:
            archive.write(QA / row['path'], row['path'])
        archive.write(QA / 'manifest.json', 'manifest.json')
    with zipfile.ZipFile(QA / 'evidence.zip') as archive:
        assert archive.testzip() is None
        assert len(archive.infolist()) == len(payloads) + 1
        for row in payloads:
            raw = archive.read(row['path'])
            assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    raw = (QA / 'evidence.zip').read_bytes()
    result = {'archive': 'evidence.zip', 'bytes': len(raw), 'sha256': sha(raw),
              'manifest_sha256': sha((QA / 'manifest.json').read_bytes()),
              'members': len(payloads) + 1, 'verified_payloads': len(payloads),
              'verified_git_source_snapshots': len(snapshots),
              'verified_raw_child_outputs': outputs, 'approved_design_payloads_verified': 10,
              'production': SOURCE, 'tested_tip': TIP, 'native_qualification': False}
    write('seal.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
