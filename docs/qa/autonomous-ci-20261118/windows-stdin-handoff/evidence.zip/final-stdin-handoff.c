#define PT_HAS_STDIN 1
#define PT_DG_APP_SID 0
#define PT_DG_ARGUMENT_BOUND 1
#define PT_DG_ATTRIBUTE_BUFFER 2
#define PT_DG_ATTRIBUTE_CAPABILITIES 3
#define PT_DG_ATTRIBUTE_HANDLES 4
#define PT_DG_ATTRIBUTE_INITIALIZE 5
#define PT_DG_ATTRIBUTE_SIZE 6
#define PT_DG_CAPABILITY_COUNT 7
#define PT_DG_CHILD_EXIT 8
#define PT_DG_CHILD_TOKEN 9
#define PT_DG_COMMAND_BUFFER 10
#define PT_DG_COMMAND_FORMAT 11
#define PT_DG_COUNT 12
#define PT_DG_DIAGNOSTIC_LIMIT 13
#define PT_DG_EXIT_CODE 14
#define PT_DG_FINISH_WAIT 15
#define PT_DG_HANDLE_CLOSE 16
#define PT_DG_IMAGE_OPEN 17
#define PT_DG_JOB_ASSIGN 18
#define PT_DG_JOB_CREATE 19
#define PT_DG_JOB_EMPTY 20
#define PT_DG_JOB_LIMITS 21
#define PT_DG_JOB_QUERY 22
#define PT_DG_JOB_TERMINATE 23
#define PT_DG_NUL_OPEN 24
#define PT_DG_PARENT_TOKEN 25
#define PT_DG_PROCESS_CREATE 26
#define PT_DG_PROCESS_ID 27
#define PT_DG_PROCESS_SNAPSHOT 28
#define PT_DG_PROCESS_TIMES 29
#define PT_DG_PROCESS_TOKEN 30
#define PT_DG_PROCESS_WAIT 31
#define PT_DG_SID_BOUND 32
#define PT_DG_SID_TEXT 33
#define PT_DG_STARTUP_TERMINATE 34
#define PT_DG_STARTUP_WAIT 35
#define PT_DG_STDERR_DUPLICATE 36
#define PT_DG_STDIN_CAPTURE 37
#define PT_DG_STDIN_CLOSE 38
#define PT_DG_STDIN_DUPLICATE 39
#define PT_DG_STDIN_EXPORT 40
#define PT_DG_STDIN_FLAGS 41
#define PT_DG_STDIN_IDENTITY 42
#define PT_DG_STDIN_MODE 43
#define PT_DG_STDIN_MODULE 44
#define PT_DG_STDIN_MODULE_CLOSE 45
#define PT_DG_STDIN_STARTUP 46
#define PT_DG_STDIN_TYPE 47
#define PT_DG_STDIO_KIND 48
#define PT_DG_STDOUT_DUPLICATE 49
#define PT_DG_TOKEN_APPCONTAINER 50
#define PT_DG_TOKEN_CAPABILITIES 51
#define PT_DG_TOKEN_MATCH 52
#define PT_DG_TOKEN_SID 53
#define PT_DG_UNKNOWN 54

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>
typedef uint32_t DWORD;
typedef int BOOL;
typedef void *HANDLE;
typedef void *HMODULE;
typedef void *PSID;
typedef int PT_DIAG_STAGE;
#define WINAPI
/* This surrogate signature is not the SDK FARPROC or an ABI qualification. */
typedef BOOL (*FARPROC)(HANDLE, HANDLE);
typedef struct { DWORD nLength; void *lpSecurityDescriptor; BOOL bInheritHandle; } SECURITY_ATTRIBUTES;
typedef struct { DWORD dwFlags; HANDLE hStdInput; } STARTUPINFOW;
#define TRUE 1
#define FALSE 0
#define ERROR_SUCCESS 0
#define ERROR_INVALID_DATA 13
#define INVALID_HANDLE_VALUE ((HANDLE)(uintptr_t)-1)
#define STD_INPUT_HANDLE ((DWORD)-10)
#define STARTF_USESTDHANDLES 0x100
#define FILE_TYPE_UNKNOWN 0
#define FILE_TYPE_DISK 1
#define FILE_TYPE_CHAR 2
#define FILE_TYPE_PIPE 3
#define HANDLE_FLAG_INHERIT 1
#define HANDLE_FLAG_PROTECT_FROM_CLOSE 2
#define DUPLICATE_SAME_ACCESS 2
#define GENERIC_READ 0x80000000u
#define FILE_SHARE_READ 1
#define FILE_SHARE_WRITE 2
#define OPEN_EXISTING 3
#define FILE_ATTRIBUTE_NORMAL 0x80
#define LOAD_LIBRARY_SEARCH_SYSTEM32 0x800
#define ZeroMemory(p,n) memset((p), 0, (n))
typedef struct { int object, open, owned, attempts; DWORD type, flags; } OBJECT;
OBJECT objects[128];
DWORD last_error, startup_flags = STARTF_USESTDHANDLES;
HANDLE current_input = (HANDLE)(uintptr_t)10, startup_input = (HANDLE)(uintptr_t)11;
int next_handle = 20, load_calls, export_calls, duplicate_calls, nul_calls, close_calls, free_calls;
int bad_arguments, borrowed_close, stale_close, diagnostics, module_live;
int deny_nul, fail_load, fail_export, fail_duplicate, fail_close, fail_free, fail_flags;
int bad_type_duplicate, bad_flags_duplicate, bad_object_duplicate, race_after_duplicate;
int nul_pipe, nul_flags, unknown_error;
DWORD bad_flags_value = HANDLE_FLAG_INHERIT;
int id(HANDLE h) { uintptr_t v = (uintptr_t)h; return v < 128 ? (int)v : 0; }
DWORD GetLastError(void) { return last_error; }
void SetLastError(DWORD value) { last_error = value; }
HANDLE GetCurrentProcess(void) { return (HANDLE)(uintptr_t)999; }
void pt_diag_win32(PT_DIAG_STAGE stage, DWORD subject) { (void)stage; (void)subject; ++diagnostics; }
void pt_diag_validation(PT_DIAG_STAGE stage, DWORD subject) { (void)stage; (void)subject; ++diagnostics; }
HANDLE GetStdHandle(DWORD which) { if (which != STD_INPUT_HANDLE) ++bad_arguments; return current_input; }
void GetStartupInfoW(STARTUPINFOW *out) { out->dwFlags = startup_flags; out->hStdInput = startup_input; }
DWORD GetFileType(HANDLE handle) {
    int h = id(handle);
    if (!h || !objects[h].open) { last_error = 707; return FILE_TYPE_UNKNOWN; }
    if (!objects[h].type) last_error = (DWORD)unknown_error;
    return objects[h].type;
}
BOOL GetHandleInformation(HANDLE handle, DWORD *flags) {
    int h = id(handle);
    if (fail_flags || !h || !objects[h].open) { last_error = 706; return FALSE; }
    *flags = objects[h].flags; return TRUE;
}
BOOL compare_objects(HANDLE first, HANDLE second) {
    int a = id(first), b = id(second);
    last_error = 933; /* A rejected identity must set a deterministic validation error. */
    return a && b && objects[a].open && objects[b].open && objects[a].object == objects[b].object;
}
HMODULE LoadLibraryExW(const wchar_t *name, HANDLE file, DWORD flags) {
    ++load_calls;
    if (wcscmp(name, L"kernelbase.dll") || file || flags != LOAD_LIBRARY_SEARCH_SYSTEM32) ++bad_arguments;
    if (fail_load) { last_error = 701; return NULL; }
    ++module_live; return (HMODULE)(uintptr_t)200;
}
FARPROC GetProcAddress(HMODULE module, const char *name) {
    ++export_calls;
    if (module != (HMODULE)(uintptr_t)200 || !module_live || strcmp(name, "CompareObjectHandles")) ++bad_arguments;
    if (fail_export) { last_error = 702; return NULL; }
    return compare_objects;
}
BOOL FreeLibrary(HMODULE module) {
    ++free_calls;
    if (module != (HMODULE)(uintptr_t)200 || module_live != 1) ++bad_arguments;
    if (fail_free) { last_error = 709; return FALSE; }
    --module_live; last_error = 912; return TRUE;
}
BOOL DuplicateHandle(HANDLE source_process, HANDLE source, HANDLE destination_process,
                     HANDLE *out, DWORD access, BOOL inherit, DWORD options) {
    int h = id(source), created;
    ++duplicate_calls;
    if (source_process != GetCurrentProcess() || destination_process != GetCurrentProcess() ||
        access != 0 || options != DUPLICATE_SAME_ACCESS || (inherit != FALSE && inherit != TRUE)) ++bad_arguments;
    if (duplicate_calls == fail_duplicate) { last_error = 600 + (DWORD)duplicate_calls; return FALSE; }
    if (!h || !objects[h].open || next_handle >= 100) { last_error = 707; return FALSE; }
    created = next_handle++;
    objects[created] = objects[h]; objects[created].owned = 1; objects[created].attempts = 0;
    objects[created].flags = inherit ? HANDLE_FLAG_INHERIT : 0;
    if (duplicate_calls == bad_type_duplicate) objects[created].type = FILE_TYPE_PIPE;
    if (duplicate_calls == bad_flags_duplicate) objects[created].flags = bad_flags_value;
    if (duplicate_calls == bad_object_duplicate) objects[created].object = 77;
    *out = (HANDLE)(uintptr_t)created;
    if (duplicate_calls == race_after_duplicate) objects[10].object = 88;
    last_error = 913; return TRUE;
}
HANDLE CreateFileW(const wchar_t *name, DWORD access, DWORD share, SECURITY_ATTRIBUTES *security,
                   DWORD disposition, DWORD flags, HANDLE template_file) {
    int h;
    ++nul_calls;
    if (wcscmp(name, L"NUL") || access != GENERIC_READ || share != (FILE_SHARE_READ | FILE_SHARE_WRITE) ||
        !security || security->nLength != sizeof(*security) || security->lpSecurityDescriptor ||
        security->bInheritHandle != TRUE || disposition != OPEN_EXISTING ||
        flags != FILE_ATTRIBUTE_NORMAL || template_file) ++bad_arguments;
    if (deny_nul) { last_error = 5; return INVALID_HANDLE_VALUE; }
    h = next_handle++;
    objects[h] = (OBJECT){1, 1, 1, 0, nul_pipe ? FILE_TYPE_PIPE : FILE_TYPE_CHAR,
                           nul_flags ? HANDLE_FLAG_PROTECT_FROM_CLOSE : HANDLE_FLAG_INHERIT};
    last_error = 914; return (HANDLE)(uintptr_t)h;
}
BOOL CloseHandle(HANDLE handle) {
    int h = id(handle);
    ++close_calls;
    if (!h || !objects[h].owned) { ++borrowed_close; last_error = 707; return FALSE; }
    if (++objects[h].attempts > 1 || !objects[h].open) { ++stale_close; last_error = 707; return FALSE; }
    if (close_calls == fail_close) { last_error = 708; return FALSE; }
    objects[h].open = 0; last_error = 911; return TRUE;
}
void setup(void) {
    objects[10] = (OBJECT){1, 1, 0, 0, FILE_TYPE_CHAR, HANDLE_FLAG_INHERIT};
    objects[11] = objects[10]; last_error = 991;
}

/* Extracted by authored tests with scripted APIs, not a Windows ABI substitute.
   NUL origin comes from the controlled creator; CHAR alone is not that proof. */
typedef BOOL (WINAPI *PT_COMPARE_OBJECT_HANDLES)(HANDLE, HANDLE);
typedef struct {
    HANDLE held;
    HMODULE comparison_module;
    PT_COMPARE_OBJECT_HANDLES compare;
} PT_STDIN;

BOOL pt_stdin_invalid(PT_DIAG_STAGE stage) {
    SetLastError(ERROR_INVALID_DATA);
    pt_diag_validation(stage, 0);
    SetLastError(ERROR_INVALID_DATA);
    return FALSE;
}

BOOL pt_stdin_kind(HANDLE handle) {
    DWORD type, error;
    if (!handle || handle == INVALID_HANDLE_VALUE) return pt_stdin_invalid(PT_DG_STDIN_TYPE);
    SetLastError(ERROR_SUCCESS);
    type = GetFileType(handle);
    error = GetLastError();
    if (type == FILE_TYPE_CHAR) return TRUE;
    if (type == FILE_TYPE_UNKNOWN && error) {
        SetLastError(error); pt_diag_win32(PT_DG_STDIN_TYPE, 0); return FALSE;
    }
    return pt_stdin_invalid(PT_DG_STDIN_TYPE);
}

BOOL pt_stdin_flags(HANDLE handle, DWORD wanted) {
    DWORD flags = 0;
    if (!GetHandleInformation(handle, &flags)) { pt_diag_win32(PT_DG_STDIN_FLAGS, 0); return FALSE; }
    if (flags != wanted) return pt_stdin_invalid(PT_DG_STDIN_FLAGS);
    return TRUE;
}

BOOL pt_stdin_drop(HANDLE *owned) {
    HANDLE handle = *owned;
    *owned = NULL; /* Consume ownership before any close; never retry a stale value. */
    if (!handle) return TRUE;
    if (handle == INVALID_HANDLE_VALUE) return pt_stdin_invalid(PT_DG_STDIN_CLOSE);
    if (!CloseHandle(handle)) { pt_diag_win32(PT_DG_STDIN_CLOSE, 0); return FALSE; }
    return TRUE;
}

BOOL pt_stdin_release(PT_STDIN *input) {
    HMODULE module;
    DWORD entry = GetLastError(), first = ERROR_SUCCESS;
    if (!input) return pt_stdin_invalid(PT_DG_STDIN_STARTUP);
    module = input->comparison_module;
    input->comparison_module = NULL;
    input->compare = NULL; /* No call may outlive the owned loader reference. */
    if (!pt_stdin_drop(&input->held)) {
        first = GetLastError();
        if (!first) first = ERROR_INVALID_DATA;
    }
    if (module && !FreeLibrary(module)) {
        DWORD error = GetLastError();
        pt_diag_win32(PT_DG_STDIN_MODULE_CLOSE, 0);
        if (!first) first = error ? error : ERROR_INVALID_DATA;
    }
    SetLastError(first ? first : entry);
    return first == ERROR_SUCCESS;
}

BOOL pt_stdin_check(const PT_STDIN *input) {
    STARTUPINFOW startup;
    HANDLE current;
    if (!input || !input->held || !input->comparison_module || !input->compare)
        return pt_stdin_invalid(PT_DG_STDIN_STARTUP);
    ZeroMemory(&startup, sizeof(startup));
    GetStartupInfoW(&startup);
    current = GetStdHandle(STD_INPUT_HANDLE);
    if (!(startup.dwFlags & STARTF_USESTDHANDLES)) return pt_stdin_invalid(PT_DG_STDIN_STARTUP);
    if (!pt_stdin_kind(input->held) || !pt_stdin_kind(startup.hStdInput) || !pt_stdin_kind(current) ||
        !pt_stdin_flags(input->held, 0)) return FALSE;
    if (!input->compare(input->held, startup.hStdInput) || !input->compare(input->held, current))
        return pt_stdin_invalid(PT_DG_STDIN_IDENTITY);
    return TRUE;
}

BOOL pt_stdin_capture(PT_STDIN *input) {
    STARTUPINFOW startup;
    HANDLE current, captured = NULL;
    FARPROC symbol;
    DWORD primary;
    if (!input || input->held || input->comparison_module || input->compare)
        return pt_stdin_invalid(PT_DG_STDIN_STARTUP);
    ZeroMemory(&startup, sizeof(startup));
    GetStartupInfoW(&startup);
    current = GetStdHandle(STD_INPUT_HANDLE);
    if (!(startup.dwFlags & STARTF_USESTDHANDLES)) return pt_stdin_invalid(PT_DG_STDIN_STARTUP);
    if (!pt_stdin_kind(current) || !pt_stdin_kind(startup.hStdInput)) return FALSE;
    /* Runtime API floor: Windows 10 / Server 2016. No fallback or import/SDK change. */
    input->comparison_module = LoadLibraryExW(L"kernelbase.dll", NULL, LOAD_LIBRARY_SEARCH_SYSTEM32);
    if (!input->comparison_module) { pt_diag_win32(PT_DG_STDIN_MODULE, 0); return FALSE; }
    symbol = GetProcAddress(input->comparison_module, "CompareObjectHandles");
    if (!symbol) { pt_diag_win32(PT_DG_STDIN_EXPORT, 0); goto failed; }
    input->compare = (PT_COMPARE_OBJECT_HANDLES)symbol;
    if (!input->compare(current, startup.hStdInput)) {
        pt_stdin_invalid(PT_DG_STDIN_IDENTITY); goto failed;
    }
    if (!DuplicateHandle(GetCurrentProcess(), current, GetCurrentProcess(),
                         &captured, 0, FALSE, DUPLICATE_SAME_ACCESS)) {
        pt_diag_win32(PT_DG_STDIN_CAPTURE, 0); goto failed;
    }
    input->held = captured; /* Only a successful duplicate establishes ownership. */
    if (!pt_stdin_check(input)) goto failed;
    return TRUE;
failed:
    primary = GetLastError();
    pt_stdin_release(input);
    SetLastError(primary);
    return FALSE;
}

BOOL pt_stdin_duplicate(const PT_STDIN *input, HANDLE *out) {
    HANDLE created = NULL;
    DWORD primary;
    if (!out || *out) return pt_stdin_invalid(PT_DG_STDIN_DUPLICATE);
    if (!pt_stdin_check(input)) return FALSE;
    if (!DuplicateHandle(GetCurrentProcess(), input->held, GetCurrentProcess(),
                         &created, 0, TRUE, DUPLICATE_SAME_ACCESS)) {
        pt_diag_win32(PT_DG_STDIN_DUPLICATE, 0); return FALSE;
    }
    if (!pt_stdin_kind(created) || !pt_stdin_flags(created, HANDLE_FLAG_INHERIT)) goto failed;
    if (!input->compare(input->held, created)) {
        pt_stdin_invalid(PT_DG_STDIN_IDENTITY); goto failed;
    }
    if (!pt_stdin_check(input)) goto failed;
    *out = created;
    return TRUE;
failed:
    primary = GetLastError();
    pt_stdin_drop(&created);
    SetLastError(primary);
    return FALSE;
}

BOOL pt_stdin_select(PSID app_sid, const PT_STDIN *input, HANDLE *out) {
    SECURITY_ATTRIBUTES security = {sizeof(SECURITY_ATTRIBUTES), NULL, TRUE};
    HANDLE created;
    DWORD primary;
    if (!out || *out || ((app_sid != NULL) == (input != NULL))) return pt_stdin_invalid(PT_DG_STDIN_MODE);
    if (input) return pt_stdin_duplicate(input, out);
    created = CreateFileW(L"NUL", GENERIC_READ, FILE_SHARE_READ | FILE_SHARE_WRITE,
                          &security, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
    if (created == INVALID_HANDLE_VALUE) { pt_diag_win32(PT_DG_NUL_OPEN, 0); return FALSE; }
    if (!pt_stdin_kind(created) || !pt_stdin_flags(created, HANDLE_FLAG_INHERIT)) {
        primary = GetLastError();
        pt_stdin_drop(&created);
        SetLastError(primary);
        return FALSE;
    }
    *out = created;
    return TRUE;
}

int main(int argc, char **argv) {
    PT_STDIN input = {0};
    HANDLE out = NULL;
    int result = 0, release_result = -1, second_release = -1, output_id, output_flags, output_object;
    int held_flags = -1, held_object = -1, empty;
    DWORD error = 0, release_error = 0;
    const char *mode;
    if (argc != 2) return 2;
    mode = argv[1]; setup();
    if (strncmp(mode, "select-", 7) == 0) {
        PSID sid = NULL;
        const PT_STDIN *provided = &input;
        objects[12] = (OBJECT){1, 1, 1, 0, FILE_TYPE_CHAR, 0};
        input.held = (HANDLE)(uintptr_t)12; input.comparison_module = (HMODULE)(uintptr_t)200;
        input.compare = compare_objects; module_live = 1;
        if (!strcmp(mode, "select-forward")) deny_nul = 1;
        else if (!strcmp(mode, "select-fresh")) { sid = (PSID)(uintptr_t)1; provided = NULL; }
        else if (!strcmp(mode, "select-nul-fails")) { sid = (PSID)(uintptr_t)1; provided = NULL; deny_nul = 1; }
        else if (!strcmp(mode, "select-neither")) provided = NULL;
        else if (!strcmp(mode, "select-both")) sid = (PSID)(uintptr_t)1;
        else if (!strcmp(mode, "select-fresh-pipe")) { sid = (PSID)(uintptr_t)1; provided = NULL; nul_pipe = 1; }
        else if (!strcmp(mode, "select-fresh-protected")) { sid = (PSID)(uintptr_t)1; provided = NULL; nul_flags = 1; }
        else if (!strcmp(mode, "select-cleanup-error")) {
            sid = (PSID)(uintptr_t)1; provided = NULL; nul_pipe = 1; fail_close = 1;
        } else return 2;
        result = pt_stdin_select(sid, provided, &out); error = GetLastError();
    } else {
#if PT_HAS_STDIN
        if (!strcmp(mode, "capture-load-fails")) fail_load = 1;
        else if (!strcmp(mode, "capture-export-fails")) fail_export = 1;
        else if (!strcmp(mode, "capture-export-cleanup-fails")) { fail_export = 1; fail_free = 1; }
        else if (!strcmp(mode, "capture-no-flag")) startup_flags = 0;
        else if (!strcmp(mode, "capture-current-null")) current_input = NULL;
        else if (!strcmp(mode, "capture-current-invalid")) current_input = INVALID_HANDLE_VALUE;
        else if (!strcmp(mode, "capture-startup-null")) startup_input = NULL;
        else if (!strcmp(mode, "capture-startup-invalid")) startup_input = INVALID_HANDLE_VALUE;
        else if (!strcmp(mode, "capture-pipe")) objects[10].type = FILE_TYPE_PIPE;
        else if (!strcmp(mode, "capture-disk")) objects[11].type = FILE_TYPE_DISK;
        else if (!strcmp(mode, "capture-unknown")) objects[10].type = FILE_TYPE_UNKNOWN;
        else if (!strcmp(mode, "capture-type-error")) { objects[10].type = FILE_TYPE_UNKNOWN; unknown_error = 705; }
        else if (!strcmp(mode, "capture-identity")) objects[11].object = 99;
        else if (!strcmp(mode, "capture-duplicate-fails")) fail_duplicate = 1;
        else if (!strcmp(mode, "capture-private-flags")) bad_flags_duplicate = 1;
        else if (!strcmp(mode, "capture-private-type")) bad_type_duplicate = 1;
        else if (!strcmp(mode, "capture-private-identity")) bad_object_duplicate = 1;
        else if (!strcmp(mode, "capture-race")) race_after_duplicate = 1;
        else if (!strcmp(mode, "capture-query-fails")) fail_flags = 1;
        else if (!strcmp(mode, "capture-validation-cleanup-fails")) { bad_object_duplicate = 1; fail_close = 1; fail_free = 1; }
        else if (strcmp(mode, "capture-ok") && strncmp(mode, "forward-", 8) && strncmp(mode, "release-", 8)) return 2;
        result = pt_stdin_capture(&input); error = GetLastError();
        if (result) {
            held_flags = (int)objects[id(input.held)].flags;
            held_object = objects[id(input.held)].object;
            if (strncmp(mode, "forward-", 8) == 0) {
                if (!strcmp(mode, "forward-replaced")) objects[10].object = 99;
                else if (!strcmp(mode, "forward-duplicate-fails")) fail_duplicate = 2;
                else if (!strcmp(mode, "forward-private-inherit")) objects[id(input.held)].flags = HANDLE_FLAG_INHERIT;
                else if (!strcmp(mode, "forward-private-protected")) objects[id(input.held)].flags = HANDLE_FLAG_PROTECT_FROM_CLOSE;
                else if (!strcmp(mode, "forward-copy-flags")) { bad_flags_duplicate = 2; bad_flags_value = 0; }
                else if (!strcmp(mode, "forward-copy-protected")) { bad_flags_duplicate = 2; bad_flags_value = 3; }
                else if (!strcmp(mode, "forward-copy-type")) bad_type_duplicate = 2;
                else if (!strcmp(mode, "forward-copy-identity")) bad_object_duplicate = 2;
                else if (!strcmp(mode, "forward-cleanup-fails")) { bad_object_duplicate = 2; fail_close = 1; }
                else if (!strcmp(mode, "forward-race")) race_after_duplicate = 2;
                else if (!strcmp(mode, "forward-occupied")) {
                    objects[30] = (OBJECT){3, 1, 1, 0, FILE_TYPE_CHAR, 0}; out = (HANDLE)(uintptr_t)30;
                } else if (strcmp(mode, "forward-ok")) return 2;
                result = pt_stdin_duplicate(&input, &out); error = GetLastError();
            } else if (strncmp(mode, "release-", 8) == 0) {
                if (!strcmp(mode, "release-close-fails")) fail_close = 1;
                else if (!strcmp(mode, "release-module-fails")) fail_free = 1;
                else if (!strcmp(mode, "release-both-fail")) { fail_close = 1; fail_free = 1; }
                else if (strcmp(mode, "release-twice")) return 2;
            }
        }
#else
        puts("{\"missing_helpers\":true}"); return 0;
#endif
    }
    output_id = id(out); output_flags = (int)objects[output_id].flags; output_object = objects[output_id].object;
#if PT_HAS_STDIN
    if (strncmp(mode, "select-", 7)) {
        if (out && output_id != 30) { CloseHandle(out); out = NULL; }
        if (input.held || input.comparison_module || input.compare) {
            SetLastError(345); release_result = pt_stdin_release(&input); release_error = GetLastError();
            second_release = pt_stdin_release(&input);
        }
    }
#endif
    empty = !input.held && !input.comparison_module && !input.compare;
    printf("{\"result\":%d,\"error\":%u,\"release\":%d,\"release_error\":%u,\"second_release\":%d,"
           "\"nul\":%d,\"duplicates\":%d,\"loads\":%d,\"exports\":%d,\"closes\":%d,\"frees\":%d,"
           "\"bad_arguments\":%d,\"borrowed_close\":%d,\"stale_close\":%d,\"empty\":%d,"
           "\"output\":%d,\"output_flags\":%d,\"output_object\":%d,\"held_flags\":%d,\"held_object\":%d,"
           "\"external_open\":%d,\"diagnostics\":%d}\n",
           result, error, release_result, release_error, second_release, nul_calls, duplicate_calls,
           load_calls, export_calls, close_calls, free_calls, bad_arguments, borrowed_close, stale_close, empty,
           output_id, output_flags, output_object, held_flags, held_object, objects[30].open, diagnostics);
    return 0;
}
