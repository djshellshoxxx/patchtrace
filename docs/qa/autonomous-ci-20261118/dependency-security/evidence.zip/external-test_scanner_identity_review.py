"""Independent contradictions in native interpreter and pip provenance."""
import copy

import pytest
from tools import dependency_security as scan


def records(tmp_path):
    python = str(tmp_path / 'env/bin/python')
    identity = {'executable': python, 'prefix': str(tmp_path / 'env'), 'base_prefix': str(tmp_path / 'base'),
                'version': '3.12.14', 'implementation': 'CPython', 'system': 'Linux',
                'machine': 'x86_64', 'ensurepip': '25.0.1'}
    inspect = {'version': '1', 'pip_version': '25.0.1', 'environment': {
        'platform_system': 'Linux', 'python_version': '3.12', 'python_full_version': '3.12.14',
        'implementation_name': 'cpython', 'platform_python_implementation': 'CPython',
        'implementation_version': '3.12.14', 'platform_machine': 'x86_64'},
        'installed': [{'metadata': {'name': 'pip', 'version': '25.0.1'}},
                      {'metadata': {'name': 'authored-tool', 'version': '1.0'}}]}
    report = {'version': '1', 'pip_version': '25.0.1', 'environment': copy.deepcopy(inspect['environment']),
              'install': [{'metadata': {'name': 'authored-tool', 'version': '1.0'}, 'is_yanked': False,
                           'download_info': {'url': 'https://files.pythonhosted.org/packages/authored.whl',
                                             'archive_info': {'hashes': {'sha256': 'a' * 64}}}}]}
    return python, identity, inspect, report


@pytest.mark.parametrize('field,value', [('python_full_version', '3.12.10'),
                                       ('platform_machine', 'aarch64'),
                                       ('implementation_name', 'pypy')])
def test_inventory_cannot_claim_another_native_interpreter(tmp_path, field, value):
    python, identity, inspect, _ = records(tmp_path)
    inspect['environment'][field] = value
    with pytest.raises(scan.EvidenceError):
        scan.validate_interpreter(identity, python, 'Linux', inspect)


def test_inspection_pip_version_must_match_the_installed_bootstrap(tmp_path):
    _, identity, inspect, report = records(tmp_path)
    inspect['pip_version'] = '26.0'
    with pytest.raises(scan.EvidenceError):
        scan.validate_installation(inspect, identity, [report], tmp_path)


def test_installation_report_cannot_claim_another_native_platform(tmp_path):
    _, identity, inspect, report = records(tmp_path)
    report['environment']['platform_system'] = 'Windows'
    with pytest.raises(scan.EvidenceError):
        scan.validate_installation(inspect, identity, [report], tmp_path)


def test_consistent_native_inventory_keeps_its_positive_path(tmp_path):
    python, identity, inspect, report = records(tmp_path)
    scan.validate_interpreter(identity, python, 'Linux', inspect)
    scan.validate_installation(inspect, identity, [report], tmp_path)
