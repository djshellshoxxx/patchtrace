"""Narrow selector regression plus unchanged source-pinned portable gates."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages')
OUT = Path(__file__).resolve().parent
PROBE = Path('/workspace/scratch/c7a9e8d98848/qa/pw02-contracts-independent/test_package_ascii_selection.py')
PROBE_SHA = 'a6940bb6a42a006192deeb62f9d66faf0cf57e170b26918e8e5beb78cfcdfcfd'
ORIGINAL = ['tests/test_package_contracts.py', 'tests/test_package_paths.py', 'tests/test_package_budget.py',
            'tests/test_package_platform.py', 'tests/test_package_schemas.py',
            'tests/test_package_boundary_edges.py', 'tests/test_spec_registry.py']


def main():
    phase = sys.argv[1]
    if phase not in {'red', 'red-assertions', 'final'}:
        raise SystemExit('unknown phase')
    log, junit = OUT / f'{phase}.log', OUT / f'{phase}.xml'
    if log.exists() or junit.exists():
        raise SystemExit('refusing to overwrite evidence')
    assert hashlib.sha256(PROBE.read_bytes()).hexdigest() == PROBE_SHA
    if not (OUT / 'independent-probe.py').exists():
        (OUT / 'independent-probe.py').write_bytes(PROBE.read_bytes())
    os.chdir(ROOT)
    sys.path[:0] = [str(ROOT / 'src'), str(ROOT)]
    os.environ['PYTHONPATH'] = str(ROOT / 'src') + os.pathsep + str(ROOT)
    os.environ['QT_QPA_PLATFORM'] = 'offscreen'
    os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
    import patchtrace
    assert Path(patchtrace.__file__).resolve().is_relative_to(ROOT / 'src')
    head = subprocess.check_output(['git', '--no-replace-objects', 'rev-parse', 'HEAD'], text=True).strip()
    tests = (ORIGINAL if phase == 'final' else []) + ['tests/test_package_ascii_admission.py', str(PROBE)]
    paths = [ROOT / 'src/patchtrace/acquisition/package_contracts.py',
             ROOT / 'tests/test_package_ascii_admission.py', PROBE]
    provenance = {'head': head, 'python': sys.version, 'executable': sys.executable,
                  'imported_package': patchtrace.__file__, 'probe_sha256': PROBE_SHA,
                  'files': [{'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
                            for path in paths], 'qualification': 'portable authored selector mechanics only'}
    attempts = []

    def audit(event, args):
        if event in {'socket.__new__', 'socket.connect', 'socket.bind', 'subprocess.Popen',
                     'os.system', 'os.posix_spawn', 'os.fork', 'os.exec'}:
            attempts.append(event)
            raise PermissionError('selector gate forbids network and child creation')

    sys.addaudithook(audit)
    import pytest
    base = tempfile.mkdtemp(prefix='patchtrace-pw02-ascii-')
    argv = ['-q', *tests, '--junitxml=' + str(junit), '--basetemp=' + base, '-p', 'no:cacheprovider']
    with log.open('x', encoding='utf-8', newline='\n') as stream:
        oldout, olderr = sys.stdout, sys.stderr
        sys.stdout = sys.stderr = stream
        try:
            code = int(pytest.main(argv))
        finally:
            sys.stdout, sys.stderr = oldout, olderr
    provenance.update(pytest_argv=argv, exit_code=code, denied_attempts=attempts)
    (OUT / f'{phase}-provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
    assert hashlib.sha256(PROBE.read_bytes()).hexdigest() == PROBE_SHA
    print(json.dumps({'phase': phase, 'exit_code': code, 'denied_attempts': attempts, 'head': head}))
    return code


if __name__ == '__main__':
    raise SystemExit(main())
