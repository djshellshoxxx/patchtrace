"""Independent selected-name boundary: only ASCII normalization is authorized."""
import pytest

from patchtrace.acquisition.contracts import AcquisitionError
from patchtrace.acquisition.package_contracts import (
    PackageContainer, PackageDecoder, PackageFileIdentity, PackageInventory,
    PackageLimits, PackagePart, PackageSelection, PackageSource,
    inventory_identity, member_identity, select_member,
)


def admitted_inventory(name):
    source = PackageSource(
        sha256='a' * 64, size=128, display_name='authored.cab',
        file_identity=PackageFileIdentity(volume_serial=7, file_id='1' * 32,
                                          size=128, last_write_ticks=10))
    raw = name.encode('utf-8')
    member = PackagePart(
        member_id=member_identity(source.sha256, (), 1, raw.hex(), True),
        container_sha256=source.sha256, ordinal=1, raw_name_hex=raw.hex(),
        name_utf8=True, logical_path=name, declared_size=4,
        kind='fullfile', kind_basis='content', content_state='reverified',
        observed_size=4, observed_sha256='b' * 64, rehash_sha256='b' * 64, machine=34404)
    fields = dict(
        source=source,
        decoder=PackageDecoder(dll_sha256='d' * 64, dll_version='authored-1',
                               os_version='authored-Windows', probe_state='passed'),
        mode='recursive', limits=PackageLimits(), parts=(member,),
        containers=(PackageContainer(container_sha256=source.sha256, size=128,
                                     entry_count=1, complete=True),), complete=True)
    receipt = PackageInventory(inventory_id=inventory_identity(fields), **fields)
    choice = PackageSelection(inventory_id=receipt.inventory_id, source_sha256=source.sha256,
                              member_id=member.member_id, side='older', expected_basename='kernel.dll')
    return receipt, choice


@pytest.mark.parametrize('name', ['kernel.dll', 'KERNEL.DLL'])
def test_ascii_basename_cases_remain_selectable(name):
    receipt, choice = admitted_inventory(name)
    assert select_member(receipt, choice).logical_path == name


def test_unicode_kelvin_sign_cannot_become_an_ascii_expected_basename():
    # U+212A lowercases to ASCII k in Python, unlike ASCII-only normalization.
    receipt, choice = admitted_inventory('\u212aERNEL.DLL')
    with pytest.raises(AcquisitionError):
        select_member(receipt, choice)
