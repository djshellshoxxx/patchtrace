"""Immutable spec-first and final terminal-accounting receipts; no child/network in tests."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages')
OUT = Path(__file__).resolve().parent
PROBE = Path('/workspace/scratch/c7a9e8d98848/qa/pw02-worker-independent/test_terminal_accounting.py')
PROBE_SHA = '5396faa2c3934dbabc4b889949c10695efe490fa318ecaa235643f7d3a4dcc29'
NEW = 'tests/test_package_worker_terminal.py'
AFFECTED = ['tests/test_package_worker_contracts.py', 'tests/test_package_worker_grants.py',
            'tests/test_package_worker_edges.py', 'tests/test_package_contracts.py',
            'tests/test_package_paths.py', 'tests/test_package_budget.py',
            'tests/test_package_platform.py', 'tests/test_package_schemas.py',
            'tests/test_package_boundary_edges.py', 'tests/test_package_ascii_admission.py',
            'tests/test_spec_registry.py']


def main():
    phase = sys.argv[1]
    if phase not in {'red', 'final'}:
        raise SystemExit('unknown terminal phase')
    log, junit, receipt = (OUT / (phase + suffix) for suffix in ('.log', '.xml', '-provenance.json'))
    if any(path.exists() for path in (log, junit, receipt)):
        raise SystemExit('refusing to overwrite terminal evidence')
    probe = PROBE.read_bytes()
    if hashlib.sha256(probe).hexdigest() != PROBE_SHA:
        raise SystemExit('independent original probe changed')
    os.chdir(ROOT)
    env = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1', GIT_ALLOW_PROTOCOL='file')
    head = subprocess.check_output(['git', '--no-replace-objects', 'rev-parse', 'HEAD'],
                                   cwd=ROOT, env=env, text=True).strip()
    sys.path[:0] = [str(ROOT / 'src'), str(ROOT)]
    sys.dont_write_bytecode = True
    os.environ.update(PYTHONPATH=str(ROOT / 'src') + os.pathsep + str(ROOT),
                      QT_QPA_PLATFORM='offscreen', PYTHONDONTWRITEBYTECODE='1',
                      GIT_NO_REPLACE_OBJECTS='1', GIT_ALLOW_PROTOCOL='file')
    names = ['src/patchtrace/acquisition/package_budget.py',
             'src/patchtrace/acquisition/package_worker_contracts.py', NEW,
             'docs/specs/local-package-intake.md', 'docs/modules.md']
    rows = []
    for name, data in [(name, (ROOT / name).read_bytes()) for name in names] + [
            ('external/test_terminal_accounting.py', probe)]:
        target = OUT / (phase + '-source') / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as stream:
            stream.write(data)
        rows.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    attempts = []

    def audit(event, args):
        if event in {'socket.__new__', 'socket.connect', 'socket.bind', 'subprocess.Popen',
                     'os.system', 'os.posix_spawn', 'os.fork', 'os.exec'}:
            attempts.append(event)
            raise PermissionError('terminal gate forbids network/child creation')

    sys.addaudithook(audit)
    import pytest
    tests = [NEW, str(PROBE), *(AFFECTED if phase == 'final' else [])]
    argv = ['-q', *tests, '--junitxml=' + str(junit),
            '--basetemp=' + tempfile.mkdtemp(prefix='patchtrace-worker-terminal-'), '-p', 'no:cacheprovider']
    with log.open('x', encoding='utf-8', newline='\n') as stream:
        previous = sys.stdout, sys.stderr
        sys.stdout = sys.stderr = stream
        try:
            code = int(pytest.main(argv))
        finally:
            sys.stdout, sys.stderr = previous
    imports = {name: module.__file__ for name, module in sys.modules.items()
               if name.startswith('patchtrace') and getattr(module, '__file__', None)}
    drift = [path for path in imports.values() if not Path(path).resolve().is_relative_to(ROOT / 'src')]
    record = {'phase': phase, 'head': head, 'argv': argv, 'python': sys.version,
              'executable': sys.executable, 'files': rows, 'imports': imports,
              'source_location_drift': drift, 'denied_attempts': attempts, 'exit_code': code,
              'original_probe_sha256': PROBE_SHA, 'qualification': 'portable accounting only'}
    with receipt.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'phase': phase, 'head': head, 'exit_code': code, 'attempts': attempts, 'drift': drift}))
    if attempts or drift:
        raise SystemExit('terminal gate source/audit boundary changed')
    return code


if __name__ == '__main__':
    raise SystemExit(main())
