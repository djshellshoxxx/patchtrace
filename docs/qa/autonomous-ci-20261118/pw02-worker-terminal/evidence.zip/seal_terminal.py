"""Bounded exact-source checks and immutable terminal-follow-up packet."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages')
OUT = Path(__file__).resolve().parent
SOURCE = '7259f86838c2181d6bdbcabe98c7a294a4499e8d'
BASE = 'f427186b9a9e3ba70dbdf90e18b63a5d90315313'
DEST = ROOT / 'docs/qa/autonomous-ci-20261118/pw02-worker-terminal'
ENV = dict(os.environ, PYTHONPATH=str(ROOT / 'src') + os.pathsep + str(ROOT),
           PYTHONDONTWRITEBYTECODE='1', QT_QPA_PLATFORM='offscreen',
           GIT_NO_REPLACE_OBJECTS='1', GIT_ALLOW_PROTOCOL='file')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT, env=ENV)


def main():
    archive, manifest = OUT / 'evidence.zip', OUT / 'manifest.json'
    if any(path.exists() for path in (archive, manifest, DEST, OUT / 'checks.json')):
        raise SystemExit('refusing to overwrite follow-up evidence')
    if git('rev-parse', 'HEAD').decode().strip() != SOURCE or git('status', '--porcelain'):
        raise SystemExit('not the clean pinned follow-up')
    commands = {'ruff': [sys.executable, '-m', 'ruff', 'check', '--no-cache', 'src', 'tests', 'tools'],
                'schemas': [sys.executable, 'tools/generate_package_schemas.py', '--check'],
                'diff-check': ['git', '--no-replace-objects', 'diff', '--check', BASE, SOURCE]}
    checks = []
    for name, command in commands.items():
        result = subprocess.run(command, cwd=ROOT, env=ENV, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, timeout=90, check=False)
        with (OUT / (name + '.log')).open('xb') as stream:
            stream.write(result.stdout)
        checks.append({'name': name, 'command': command, 'exit_code': result.returncode,
                       'sha256': sha(result.stdout)})
    if any(row['exit_code'] for row in checks):
        raise SystemExit('static follow-up gate failed; output retained')
    final = json.loads((OUT / 'final-provenance.json').read_text())
    if final['head'] != SOURCE or final['exit_code'] or final['denied_attempts'] or final['source_location_drift']:
        raise SystemExit('final provenance does not match')
    canonical = []
    for row in final['files']:
        if row['path'].startswith('external/'):
            continue
        data = git('show', SOURCE + ':' + row['path'])
        if data != (OUT / 'final-source' / row['path']).read_bytes() or sha(data) != row['sha256']:
            raise SystemExit('final source snapshot mismatch')
        canonical.append(row['path'])
    changed = git('diff', '--name-only', BASE, SOURCE).decode().splitlines()
    if any(name.startswith('docs/schemas/') for name in changed):
        raise SystemExit('unexpected schema change')
    originals = {
        '/workspace/scratch/c7a9e8d98848/qa/pw02-worker-independent/test_terminal_accounting.py':
            '5396faa2c3934dbabc4b889949c10695efe490fa318ecaa235643f7d3a4dcc29',
        '/workspace/scratch/c7a9e8d98848/qa/pw02-worker-independent-20261118.zip':
            '4e767d01a24b552c75503ff42dc02ed45fd84de15ba7060a9a3d8713240f1872',
        '/workspace/scratch/c7a9e8d98848/qa/pw02-local-packages/worker-grants/evidence.zip':
            '36c5ff29cf8fd31cc5a3c326445e32fc82c528c218f78dfea3bb593a3dc757c8',
    }
    if any(sha(Path(path).read_bytes()) != expected for path, expected in originals.items()):
        raise SystemExit('original review/author evidence changed')
    check_record = {'source': SOURCE, 'base': BASE, 'checks': checks, 'canonical_final_files': canonical,
                    'changed_paths': changed, 'originals_verified': originals,
                    'schemas_unchanged': True}
    with (OUT / 'checks.json').open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(check_record, indent=2) + '\n')
    payload = sorted(path for path in OUT.rglob('*') if path.is_file()
                     and '__pycache__' not in path.parts and path not in {archive, manifest})
    rows = []
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for path in payload:
            data = path.read_bytes()
            name = path.relative_to(OUT).as_posix()
            zipped.writestr(name, data)
            rows.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
    with zipfile.ZipFile(archive) as zipped:
        if len(zipped.namelist()) != len(set(zipped.namelist())) or zipped.testzip():
            raise SystemExit('ZIP membership or CRC failure')
        for row in rows:
            if sha(zipped.read(row['path'])) != row['sha256']:
                raise SystemExit('archive hash mismatch')
    data = archive.read_bytes()
    result = {'source': SOURCE, 'tree': git('rev-parse', SOURCE + '^{tree}').decode().strip(),
              'spec_tests': 'dcd2653fc7d79e457a02569edb8e461960f47080', 'base': BASE,
              'tests': {'passed': 451, 'failed': 0, 'skipped': 0, 'seconds': 1.63},
              'archive': {'path': archive.name, 'bytes': len(data), 'sha256': sha(data), 'members': len(rows)},
              'qualification': 'portable terminal-accounting correction only', 'files': rows}
    with manifest.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(result, indent=2) + '\n')
    DEST.mkdir(parents=True)
    for path in (OUT / 'README.md', archive, manifest):
        shutil.copyfile(path, DEST / path.name)
        if path.read_bytes() != (DEST / path.name).read_bytes():
            raise SystemExit('tracked packet copy mismatch')
    print(json.dumps({key: value for key, value in result.items() if key != 'files'}))


if __name__ == '__main__':
    main()
