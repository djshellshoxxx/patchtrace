"""External authored controls for the terminal worker accounting boundary.

No package, target, native worker, process or network operation is performed.
"""
from __future__ import annotations

import threading

import pytest

from patchtrace.acquisition.contracts import AcquisitionError
from patchtrace.acquisition.package_budget import PackageBudget
from patchtrace.acquisition.package_contracts import PackageLimits, PackageSource
from patchtrace.acquisition.package_worker_contracts import PackageWorkerBinding


class Clock:
    now = 100

    def __call__(self):
        return self.now


def setup_pair(*, cancel=None):
    clock = Clock()
    owner = PackageBudget(PackageLimits(max_expanded_bytes=8), clock_ns=clock)
    source = PackageSource(sha256='a' * 64, size=128, display_name='authored.cab',
                           file_identity=dict(volume_serial=1, file_id='1' * 32,
                                              size=128, last_write_ticks=20))
    binding = PackageWorkerBinding(operation_id='b' * 64, request_id='c' * 64,
                                   attempt_id='d' * 64, source=source)
    grant = owner.issue_worker(binding)
    worker = PackageBudget.from_worker_grant(grant.model_dump_json().encode(),
                                             clock_ns=clock, cancel=cancel)
    return owner, grant, worker


@pytest.mark.parametrize('completed', [1, 3])
def test_exported_terminal_receipt_cannot_be_followed_by_new_confirmed_bytes(completed):
    _owner, _grant, worker = setup_pair()
    pending = worker.reserve_output(worker.begin_entry(3), 3)
    terminal = worker.worker_receipt()
    assert terminal.status == 'failed'
    assert terminal.pending_outputs == terminal.open_entries == 1
    assert terminal.usage.reserved_output_bytes == 3
    assert terminal.usage.confirmed_output_bytes == 0

    with pytest.raises(AcquisitionError):
        worker.complete_output(pending, completed)

    # A terminal record is the final non-cleanup accounting boundary. The
    # rejected call must not create later confirmed bytes that it cannot export.
    assert worker.snapshot().confirmed_output_bytes == terminal.usage.confirmed_output_bytes
    assert worker.snapshot().reserved_output_bytes == terminal.usage.reserved_output_bytes


def test_completed_write_before_terminal_receipt_keeps_known_bytes_after_cancel():
    cancel = threading.Event()
    owner, grant, worker = setup_pair(cancel=cancel)
    pending = worker.reserve_output(worker.begin_entry(3), 3)
    cancel.set()
    with pytest.raises(AcquisitionError) as stopped:
        worker.complete_output(pending, 3)
    assert stopped.value.code == 'PT-ACQ-CANCEL'
    terminal = worker.worker_receipt()
    assert terminal.status == 'failed' and terminal.pending_outputs == 0
    assert terminal.usage.reserved_output_bytes == terminal.usage.confirmed_output_bytes == 3
    with pytest.raises(AcquisitionError):
        owner.reconcile_worker(grant, terminal.model_dump_json().encode())
    assert owner.snapshot().confirmed_output_bytes == 3
    assert not owner.worker_usage_unknown


def test_terminal_failure_still_allows_only_owned_allocation_cleanup():
    _owner, _grant, worker = setup_pair()
    token = worker.allocate(7)
    terminal = worker.worker_receipt()
    assert terminal.status == 'failed' and terminal.usage.live_allocated_bytes == 7
    worker.free(token)
    assert worker.snapshot().live_allocated_bytes == 0
    assert worker.snapshot().peak_allocated_bytes == 7
    with pytest.raises(AcquisitionError):
        worker.check()


def test_failed_terminal_record_cannot_enable_parent_continuation_or_replay():
    owner, grant, worker = setup_pair()
    worker.reserve_output(worker.begin_entry(3), 3)
    raw = worker.worker_receipt().model_dump_json().encode()
    with pytest.raises(AcquisitionError):
        owner.reconcile_worker(grant, raw)
    usage = owner.snapshot()
    assert usage.failed and usage.reserved_output_bytes == 3 and usage.confirmed_output_bytes == 0
    assert not owner.worker_usage_unknown and not owner.worker_pending
    with pytest.raises(AcquisitionError):
        owner.charge_hash(1)
    with pytest.raises(AcquisitionError):
        owner.reconcile_worker(grant, raw)
    assert owner.snapshot().reserved_output_bytes == 3
    assert owner.snapshot().hashed_input_bytes == 0
    assert not owner.worker_usage_unknown
