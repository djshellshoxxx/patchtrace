"""Seal immutable source-specific static upload evidence and copy the packet."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import zipfile

root = Path(__file__).resolve().parent
excluded = {'manifest.json', 'evidence.zip', 'seal.log'}
paths = sorted((p for p in root.rglob('*') if p.is_file() and
                p.relative_to(root).as_posix() not in excluded and '__pycache__' not in p.parts),
               key=lambda p: p.relative_to(root).as_posix())
members = []
with zipfile.ZipFile(root / 'evidence.zip', 'x', compression=zipfile.ZIP_DEFLATED) as archive:
    for path in paths:
        assert not path.is_symlink()
        raw, name = path.read_bytes(), path.relative_to(root).as_posix()
        archive.writestr(name, raw)
        members.append({'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
with zipfile.ZipFile(root / 'evidence.zip') as archive:
    assert archive.testzip() is None and archive.namelist() == [row['path'] for row in members]
    for row in members:
        raw = archive.read(row['path'])
        assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
        assert raw == (root / row['path']).read_bytes()
raw = (root / 'evidence.zip').read_bytes()
manifest = {'schema': 1, 'sealed_utc': datetime.now(timezone.utc).isoformat(),
            'baseline': '740869debb111f8edbef33899316e4c75e6fdf7a',
            'source_sha': '7adcecd72e7476746819e30937dfc3ca09c01f1e',
            'archive_bytes': len(raw), 'archive_sha256': hashlib.sha256(raw).hexdigest(),
            'member_count': len(members), 'member_bytes': sum(row['bytes'] for row in members),
            'all_members_verified': True, 'hosted_native_or_scan_qualification': False,
            'members': members}
with (root / 'manifest.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
destination = root.parents[1] / 'static-scan-receipt/docs/qa/autonomous-ci-20261118/static-scan-receipt'
destination.mkdir(parents=True, exist_ok=False)
for name in ('README.md', 'manifest.json', 'evidence.zip'):
    data = (root / name).read_bytes()
    with (destination / name).open('xb') as stream:
        stream.write(data)
    assert (destination / name).read_bytes() == data
print(json.dumps({key: value for key, value in manifest.items() if key != 'members'}, sort_keys=True))
