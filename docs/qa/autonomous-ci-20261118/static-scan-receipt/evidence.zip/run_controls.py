"""Run only inspected existing workflow controls with process/network denial."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

qa = Path(__file__).resolve().parent
root = qa.parents[1] / 'static-scan-receipt'
head = subprocess.check_output(['git', '--no-replace-objects', 'rev-parse', 'HEAD'], cwd=root).decode().strip()
assert head == '7adcecd72e7476746819e30937dfc3ca09c01f1e'
files = ['.github/workflows/dependency-security.yml',
         'docs/specs/dependency-security-qualification.md', 'tools/dependency_security.py',
         'tools/release_qualification.py', 'tests/test_dependency_security.py',
         'tests/test_release_qualification.py']
proof = []
for name in files:
    raw = (root / name).read_bytes()
    assert raw == subprocess.check_output(['git', '--no-replace-objects', 'show', head + ':' + name], cwd=root)
    proof.append({'path': name, 'sha256': hashlib.sha256(raw).hexdigest()})
denied = []
def guard(event, _args):
    if event.startswith('socket.') or event in {'subprocess.Popen', 'os.system', 'os.exec', 'os.posix_spawn', 'os.spawn'}:
        denied.append(event)
        raise RuntimeError('offline workflow review denied ' + event)
sys.addaudithook(guard)
os.chdir(root)
sys.path[:0] = [str(root / 'src'), str(root / 'tests'), str(root)]
os.environ['PYTHONPATH'] = os.pathsep.join(sys.path[:3])
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
import pytest
nodes = [
    'tests/test_dependency_security.py::test_workflow_has_every_native_inventory_and_mandatory_unsuppressed_step',
    'tests/test_dependency_security.py::test_release_policy_requires_four_native_profiles_and_static',
    'tests/test_release_qualification.py::test_policy_critical_names_match_actual_source_workflows',
    'tests/test_release_qualification.py::test_publishers_require_shared_guard_before_mutation',
]
code = pytest.main(['-q', *nodes, '--junitxml=' + str(qa / 'controls.xml')])
record = {'source_sha': head, 'source_files': proof, 'pytest_nodes': nodes,
          'exit_code': int(code), 'denied_process_or_network_attempts': denied,
          'no_scanner_native_or_installer_execution': True}
with (qa / 'controls-provenance.json').open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(record, indent=2, sort_keys=True) + '\n')
assert not denied
raise SystemExit(code)
