"""Direct flat-file upload-pattern check against retained scanner evidence.

This does not run an action, scanner, installer, or network request.
"""
import argparse
import fnmatch
import hashlib
import json
from pathlib import Path
import re
import sys
import zipfile

import yaml

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, required=True)
parser.add_argument('--receipt', type=Path, required=True)
args = parser.parse_args()
qa = Path(__file__).resolve().parent
raw = (args.root / '.github/workflows/dependency-security.yml').read_bytes()
job = yaml.safe_load(raw)['jobs']['security-scan']
uploads = [step for step in job['steps'] if 'upload-artifact@' in step.get('uses', '')]
assert len(uploads) == 1
upload = uploads[0]
assert upload['if'] == 'always()' and upload['with']['if-no-files-found'] == 'error'
patterns = upload['with']['path'].splitlines()
assert all(re.fullmatch(r'build/security-static/\*\.(json|stdout|stderr|txt)', pattern) for pattern in patterns)
archive = qa / 'original-static-14459695622.zip'
assert hashlib.sha256(archive.read_bytes()).hexdigest() == '75edfdea10a0e71dbf252d69e3aab967398b00499222611d0b2d8fcdda4c921c'
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == 38
    assert all(Path(name).name == name for name in z.namelist())
    assert 'bootstrap-pip.txt' not in z.namelist()
    assert json.loads(z.read('static.process.json'))['exit_code'] == 1
    assert len(json.loads(z.read('static.stdout'))) == 81
    existing = ['build/security-static/' + name for name in z.namelist()]
required = 'build/security-static/bootstrap-pip.txt'
covered = [name for name in [*existing, required] if any(fnmatch.fnmatchcase(name, pattern) for pattern in patterns)]
assert all(name in covered for name in existing)
result = {'workflow_sha256': hashlib.sha256(raw).hexdigest(), 'patterns': patterns,
          'original_artifact_id': 14459695622, 'original_artifact_missing_input': True,
          'original_scan_exit': 1, 'original_scan_findings': 81,
          'original_member_count': len(existing), 'original_members_still_covered': len(existing),
          'required_static_input': required, 'required_input_covered': required in covered,
          'check': 'passed' if required in covered else 'failed',
          'scope': 'Flat upload-glob inclusion only; no hosted upload, scanner or native qualification claim',
          'prospective_input_evidence': 'required bootstrap-pip.txt is written by the shared producer and present in the retained runtime artifact; no file is injected into the original static ZIP'}
with args.receipt.open('x', encoding='utf-8') as stream:
    stream.write(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, sort_keys=True))
sys.exit(0 if required in covered else 1)
