"""Offline, exact-source QA wrapper for the reviewed creation-identity repair."""
from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys
import time


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--receipt', required=True, type=Path)
    parser.add_argument('--unit', action='store_true')
    parser.add_argument('pytest_args', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    arguments = args.pytest_args[1:] if args.pytest_args[:1] == ['--'] else args.pytest_args
    source = Path(__file__).with_name('network_filter_source.py')
    spec = importlib.util.spec_from_file_location('qa_network_filter', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    filter_receipt = module.install_network_filter()
    events, denied = [], []

    def audit(event, values):
        if event in {'socket.__new__', 'socket.connect', 'socket.bind', 'socket.sendto', 'socket.sendmsg',
                     'socket.getaddrinfo', 'socket.gethostbyname', 'socket.gethostbyaddr',
                     'os.system', 'os.exec', 'os.posix_spawn', 'os.spawn'}:
            denied.append({'event': event})
            raise PermissionError('offline identity QA denied ' + event)
        if event == 'subprocess.Popen':
            executable, argv, cwd, environ = values
            row = {'executable': os.fsdecode(executable), 'argv': [os.fsdecode(value) for value in argv],
                   'cwd': os.fsdecode(cwd) if cwd is not None else os.getcwd(),
                   'pythonpath': (environ or os.environ).get('PYTHONPATH')}
            events.append(row)
            if args.unit or (Path(row['executable']).name == 'git' and
                             any(verb in row['argv'] for verb in ('fetch', 'pull', 'push', 'clone', 'remote'))):
                denied.append(dict(row, event=event))
                raise PermissionError('identity QA refused a process outside its reviewed scope')

    sys.addaudithook(audit)
    started = time.monotonic()
    code = 90
    try:
        import pytest
        code = int(pytest.main(arguments))
    finally:
        result = {'pytest_args': arguments, 'cwd': os.getcwd(), 'python': sys.executable,
                  'pythonpath': os.environ.get('PYTHONPATH'), 'unit_mode': args.unit,
                  'elapsed_seconds': time.monotonic() - started, 'pytest_exit': code,
                  'network_filter': filter_receipt, 'process_audit_events': events,
                  'denied_audit_events': denied}
        if denied:
            code = 91
        result['guarded_exit'] = code
        args.receipt.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
    return code


if __name__ == '__main__':
    raise SystemExit(main())
