"""Append-only edge control outputs; keep the original runner and receipts unchanged."""
from pathlib import Path

import run_controls

run_controls.OUT = Path(__file__).resolve().parent / 'edges'
run_controls.OUT.mkdir(exist_ok=True)
run_controls.AUTHORED = ['tests/test_package_worker_edges.py']
run_controls.AFFECTED = []
raise SystemExit(run_controls.main())
