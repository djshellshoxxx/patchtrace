"""Exact-source worker accounting gates, denied network/child creation during pytest."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages')
OUT = Path(__file__).resolve().parent
AUTHORED = ['tests/test_package_worker_contracts.py', 'tests/test_package_worker_grants.py']
AFFECTED = ['tests/test_package_contracts.py', 'tests/test_package_paths.py', 'tests/test_package_budget.py',
            'tests/test_package_platform.py', 'tests/test_package_schemas.py',
            'tests/test_package_boundary_edges.py', 'tests/test_package_ascii_admission.py']


def main() -> int:
    phase = sys.argv[1]
    if phase not in {'red', 'green', 'final'}:
        raise SystemExit('unknown phase')
    log, junit, provenance = (OUT / (phase + suffix) for suffix in ('.log', '.xml', '-provenance.json'))
    if any(p.exists() for p in (log, junit, provenance)):
        raise SystemExit('refusing to overwrite evidence')
    os.chdir(ROOT)
    sys.path[:0] = [str(ROOT / 'src'), str(ROOT)]
    sys.dont_write_bytecode = True
    os.environ.update(PYTHONPATH=str(ROOT / 'src') + os.pathsep + str(ROOT),
                      QT_QPA_PLATFORM='offscreen', PYTHONDONTWRITEBYTECODE='1',
                      GIT_NO_REPLACE_OBJECTS='1', GIT_ALLOW_PROTOCOL='file')
    import patchtrace
    assert Path(patchtrace.__file__).resolve().is_relative_to(ROOT / 'src')
    head = subprocess.check_output(['git', '--no-replace-objects', 'rev-parse', 'HEAD'], text=True).strip()
    paths = ['src/patchtrace/acquisition/package_budget.py',
             'src/patchtrace/acquisition/package_worker_contracts.py', 'tools/generate_package_schemas.py',
             'tests/package_worker_support.py', *AUTHORED, 'docs/specs/local-package-intake.md']
    files = []
    for name in paths:
        path = ROOT / name
        if path.is_file():
            data = path.read_bytes()
            target = OUT / (phase + '-source') / name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            files.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
        else:
            files.append({'path': name, 'state': 'absent'})
    attempts = []

    def audit(event, args):
        if event in {'socket.__new__', 'socket.connect', 'socket.bind', 'subprocess.Popen',
                     'os.system', 'os.posix_spawn', 'os.fork', 'os.exec'}:
            attempts.append(event)
            raise PermissionError('worker-accounting gate forbids network and child creation')

    sys.addaudithook(audit)
    import pytest
    tests = [*AUTHORED, *(AFFECTED if phase != 'red' else []), 'tests/test_spec_registry.py']
    argv = ['-q', *tests, '--junitxml=' + str(junit),
            '--basetemp=' + tempfile.mkdtemp(prefix='patchtrace-worker-grants-'), '-p', 'no:cacheprovider']
    with log.open('x', encoding='utf-8', newline='\n') as stream:
        oldout, olderr = sys.stdout, sys.stderr
        sys.stdout = sys.stderr = stream
        try:
            code = int(pytest.main(argv))
        finally:
            sys.stdout, sys.stderr = oldout, olderr
    imports = {name: module.__file__ for name, module in sys.modules.items()
               if name.startswith('patchtrace') and getattr(module, '__file__', None)}
    if any(not Path(path).resolve().is_relative_to(ROOT / 'src') for path in imports.values()):
        raise RuntimeError('import source drift')
    record = {'phase': phase, 'head': head, 'python': sys.version, 'executable': sys.executable,
              'argv': argv, 'files': files, 'imports': imports,
              'denied_attempts': attempts, 'exit_code': code,
              'qualification': 'authored portable accounting only; no native or worker execution'}
    with provenance.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'phase': phase, 'head': head, 'exit_code': code, 'denied_attempts': attempts}))
    return code


if __name__ == '__main__':
    raise SystemExit(main())
