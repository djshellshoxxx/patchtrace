"""Bounded offline static checks at the committed worker-accounting source."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages')
OUT = Path(__file__).resolve().parent
SOURCE = 'eb50b0283cf7a46e7bd25ffc23cd78b18dfeb2e0'


def main():
    env = dict(os.environ, PYTHONPATH=str(ROOT / 'src') + os.pathsep + str(ROOT),
               PYTHONDONTWRITEBYTECODE='1', QT_QPA_PLATFORM='offscreen',
               GIT_NO_REPLACE_OBJECTS='1', GIT_ALLOW_PROTOCOL='file')
    actual = subprocess.check_output(['git', '--no-replace-objects', 'rev-parse', 'HEAD'],
                                     cwd=ROOT, env=env, text=True).strip()
    if actual != SOURCE:
        raise SystemExit('source drift')
    commands = {
        'ruff': [sys.executable, '-m', 'ruff', 'check', '--no-cache', 'src', 'tests', 'tools'],
        'schemas': [sys.executable, 'tools/generate_package_schemas.py', '--check'],
        'diff-check': ['git', '--no-replace-objects', 'diff', '--check',
                       '068513a72e8a1412ce3960d3024c462d68d51376', SOURCE],
    }
    outputs = [OUT / (name + '.log') for name in commands]
    receipt = OUT / 'static-checks.json'
    if any(path.exists() for path in [*outputs, receipt]):
        raise SystemExit('refusing to overwrite static-check evidence')
    rows = []
    for (name, command), target in zip(commands.items(), outputs, strict=True):
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, check=False, timeout=90)
        with target.open('xb') as stream:
            stream.write(result.stdout)
        rows.append({'name': name, 'command': command, 'exit_code': result.returncode,
                     'output': target.name, 'bytes': len(result.stdout),
                     'sha256': hashlib.sha256(result.stdout).hexdigest()})
    with receipt.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps({'source': SOURCE, 'checks': rows,
                                 'qualification': 'offline static checks only'}, indent=2) + '\n')
    print(json.dumps(rows))
    return int(any(row['exit_code'] for row in rows))


if __name__ == '__main__':
    raise SystemExit(main())
