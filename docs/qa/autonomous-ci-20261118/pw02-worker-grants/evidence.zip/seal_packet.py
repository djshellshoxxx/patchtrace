"""Seal preserved worker controls and canonical source; never replace a packet."""
from __future__ import annotations

import hashlib
import json
import shutil
import zipfile
from pathlib import Path
from xml.etree import ElementTree

OUT = Path(__file__).resolve().parent
DEST = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages/docs/qa/autonomous-ci-20261118/pw02-worker-grants')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    archive, manifest = OUT / 'evidence.zip', OUT / 'manifest.json'
    if archive.exists() or manifest.exists() or DEST.exists():
        raise SystemExit('refusing to replace sealed evidence')
    expected = {'red': (149, 111), 'green': (0, 431),
                'edges/red': (9, 112), 'final': (0, 441)}
    gates = []
    for name, counts in expected.items():
        suites = ElementTree.parse(OUT / (name + '.xml')).getroot().findall('testsuite')
        total, failures, errors, skips = (sum(int(s.attrib.get(field, 0)) for s in suites)
                                         for field in ('tests', 'failures', 'errors', 'skipped'))
        if (failures + errors, total - failures - errors - skips) != counts or skips:
            raise SystemExit('unexpected gate totals: ' + name)
        record = json.loads((OUT / (name + '-provenance.json')).read_text())
        if record['denied_attempts']:
            raise SystemExit('unexpected attempted socket/child operation: ' + name)
        gates.append({'phase': name, 'tests': total, 'failures': failures, 'errors': errors,
                      'skipped': skips, 'test_socket_or_child_attempts': 0,
                      'head': record['head'], 'exit_code': record['exit_code']})
    source = json.loads((OUT / 'source-provenance.json').read_text())
    for row in source['canonical_files']:
        data = (OUT / 'committed-source' / row['path']).read_bytes()
        if len(data) != row['bytes'] or digest(data) != row['sha256']:
            raise SystemExit('canonical source capture mismatch')
    payload = sorted(path for path in OUT.rglob('*') if path.is_file()
                     and '__pycache__' not in path.parts
                     and path not in {archive, manifest})
    rows = []
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as zipped:
        for path in payload:
            data = path.read_bytes()
            name = path.relative_to(OUT).as_posix()
            zipped.writestr(name, data)
            rows.append({'path': name, 'bytes': len(data), 'sha256': digest(data)})
    with zipfile.ZipFile(archive) as zipped:
        names = zipped.namelist()
        if len(names) != len(set(names)) or names != [row['path'] for row in rows] or zipped.testzip():
            raise SystemExit('archive membership or CRC failure')
        for row in rows:
            data = zipped.read(row['path'])
            if len(data) != row['bytes'] or digest(data) != row['sha256']:
                raise SystemExit('archive payload mismatch')
    data = archive.read_bytes()
    record = {'source': source['source'], 'tree': source['tree'], 'base': source['base'],
              'spec_test_commits': source['spec_test_commits'],
              'archive': {'path': archive.name, 'bytes': len(data), 'sha256': digest(data),
                          'members': len(rows), 'payload_bytes': sum(row['bytes'] for row in rows)},
              'canonical_source_files': len(source['canonical_files']), 'gates': gates,
              'qualification': 'portable authored accounting only; native/Windows/FDI/project pending',
              'files': rows}
    with manifest.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
    DEST.mkdir(parents=True)
    for path in (OUT / 'README.md', manifest, archive):
        shutil.copyfile(path, DEST / path.name)
        if path.read_bytes() != (DEST / path.name).read_bytes():
            raise SystemExit('tracked packet copy mismatch')
    print(json.dumps({key: value for key, value in record.items() if key != 'files'}))


if __name__ == '__main__':
    main()
