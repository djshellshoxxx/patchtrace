"""Capture canonical Git sources and compare the exact final test inputs."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
from pathlib import Path

ROOT = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages')
OUT = Path(__file__).resolve().parent
BASE = '068513a72e8a1412ce3960d3024c462d68d51376'
SOURCE = 'eb50b0283cf7a46e7bd25ffc23cd78b18dfeb2e0'
SPECS = ['a522e275ddeedc25bfb2b06fd01b20ec7caef1d7', '4474686899318efb57dac683e66c3e07f99dcf87']
ENV = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1', GIT_ALLOW_PROTOCOL='file')


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT, env=ENV)


def main():
    target = OUT / 'committed-source'
    receipt = OUT / 'source-provenance.json'
    if target.exists() or receipt.exists():
        raise SystemExit('refusing to overwrite source evidence')
    if git('rev-parse', 'HEAD').decode().strip() != SOURCE or git('status', '--porcelain'):
        raise SystemExit('source is not the clean pinned implementation')
    final = json.loads((OUT / 'final-provenance.json').read_text())
    if final['head'] != SOURCE or final['exit_code'] != 0 or final['denied_attempts']:
        raise SystemExit('final gate provenance does not match the source')
    changed = git('diff', '--name-only', BASE, SOURCE).decode().splitlines()
    paths = set(changed)
    paths.update(Path(path).relative_to(ROOT).as_posix() for path in final['imports'].values())
    paths.update(name for name in final['argv'] if name.startswith('tests/') and name.endswith('.py'))
    paths.update(row['path'] for row in final['files'])
    paths.update(['pyproject.toml', 'tests/conftest.py', 'tests/package_support.py',
                  'docs/specs/REGISTRY.md', 'AGENTS.md'])
    paths.update(path.relative_to(ROOT).as_posix() for path in
                 (ROOT / 'docs/schemas/local-package').glob('*.json'))
    rows = []
    for name in sorted(paths):
        data = git('show', SOURCE + ':' + name)
        if (ROOT / name).read_bytes() != data:
            raise SystemExit('checked-out bytes differ from pinned Git source: ' + name)
        dest = target / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        with dest.open('xb') as stream:
            stream.write(data)
        rows.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    for row in final['files']:
        data = (target / row['path']).read_bytes()
        if hashlib.sha256(data).hexdigest() != row['sha256']:
            raise SystemExit('final gate snapshot differs from canonical source')
    old_schema_changes = [name for name in changed if name.startswith('docs/schemas/local-package/')
                          and '/PackageWorker' not in name]
    if old_schema_changes:
        raise SystemExit('existing package schemas changed unexpectedly')
    record = {'base': BASE, 'spec_test_commits': SPECS, 'source': SOURCE,
              'tree': git('rev-parse', SOURCE + '^{tree}').decode().strip(),
              'changed_paths': changed, 'canonical_files': rows,
              'final_snapshots_equal_git': True, 'existing_package_schemas_unchanged': True,
              'boundary': 'portable serial accounting only; no native or project-admission credit'}
    with receipt.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'source': SOURCE, 'canonical_files': len(rows), 'changed_paths': len(changed)}))


if __name__ == '__main__':
    main()
