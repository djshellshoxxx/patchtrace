"""The committed affected gate includes the appended edge controls."""
import run_controls

run_controls.AUTHORED.append('tests/test_package_worker_edges.py')
raise SystemExit(run_controls.main())
