"""Read only pinned local Git objects for the PW-02 design; no source mutation."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages')
OUTPUT = Path(__file__).resolve().parent
BASE = '27e4318b'
CONTRACTS = '645839646a68815ee1822ee61039af42d583903a'
PATHS = (
    'src/patchtrace/jobs.py',
    'src/patchtrace/owned_publication.py',
    'src/patchtrace/ingestion.py',
    'src/patchtrace/service.py',
    'src/patchtrace/kbcorrelation/ports.py',
    'src/patchtrace/kbcorrelation/service.py',
    'src/patchtrace/kbcorrelation/store.py',
    'src/patchtrace/kbcorrelation/wiring.py',
    'src/patchtrace/acquisition/package_contracts.py',
    'src/patchtrace/acquisition/package_budget.py',
    'src/patchtrace/acquisition/package_platform.py',
    'src/patchtrace/secondary/binexport_run.py',
    'src/patchtrace/__main__.py',
    'tools/build_windows.py',
    'docs/specs/local-package-intake.md',
    'docs/specs/architecture.md',
    'docs/modules.md',
)
URLS = (
    'https://learn.microsoft.com/en-us/windows/win32/procthread/process-security-and-access-rights',
    'https://learn.microsoft.com/en-us/windows/win32/api/handleapi/nf-handleapi-duplicatehandle',
    'https://learn.microsoft.com/en-us/windows/win32/procthread/inheritance',
    'https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-createprocessw',
    'https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-updateprocthreadattribute',
    'https://learn.microsoft.com/en-us/windows/win32/api/winbase/ns-winbase-file_id_info',
    'https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-reopenfile',
    'https://learn.microsoft.com/en-us/windows/win32/fileio/creating-and-opening-files',
    'https://learn.microsoft.com/en-us/windows/win32/api/winternl/nf-winternl-ntcreatefile',
    'https://learn.microsoft.com/en-us/windows/win32/api/fileapi/nf-fileapi-createfilew',
    'https://docs.python.org/3.12/library/time.html#time.monotonic',
)


def git(*args: str) -> bytes:
    environment = dict(os.environ, GIT_NO_REPLACE_OBJECTS='1', GIT_ALLOW_PROTOCOL='file')
    return subprocess.run(['git', '--no-replace-objects', *args], cwd=ROOT, env=environment,
                          check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                          timeout=10).stdout


def main() -> None:
    source = git('rev-parse', '--verify', BASE + '^{commit}').decode().strip()
    records = []
    for path in PATHS:
        body = git('show', source + ':' + path)
        destination = OUTPUT / 'source' / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        if destination.exists() and destination.read_bytes() != body:
            raise RuntimeError('existing source snapshot differs; do not overwrite')
        if not destination.exists():
            with destination.open('xb') as stream:
                stream.write(body)
        records.append({'path': path, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest(),
                        'blob': git('rev-parse', source + ':' + path).decode().strip(),
                        'equal_corrected_contracts_base': body == git('show', CONTRACTS + ':' + path)})
    record = {'status': 'design-only; no native or test execution',
              'captured_utc': datetime.now(UTC).isoformat(),
              'source_sha': source,
              'tree': git('rev-parse', source + '^{tree}').decode().strip(),
              'contracts_source': CONTRACTS,
              'source_files': records,
              'primary_urls': URLS,
              'git_environment': {'GIT_NO_REPLACE_OBJECTS': '1', 'GIT_ALLOW_PROTOCOL': 'file'},
              'network_or_target_execution': False}
    destination = OUTPUT / 'current-source-provenance.json'
    if destination.exists():
        raise RuntimeError('existing provenance retained; use a new capture name')
    with destination.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'source_sha': source, 'tree': record['tree'], 'files': len(records),
                      'different_from_contracts_base': [item['path'] for item in records
                                                        if not item['equal_corrected_contracts_base']]}))


if __name__ == '__main__':
    main()
