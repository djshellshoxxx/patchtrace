# PW-02 native stage/worker seam audit and next-slice draft

**Revision notice:** the child-opened parent `PROCESS_DUP_HANDLE` proposal in
section 1 below is rejected. The retained initial draft is `initial-README.md`.
The current concrete proposal is [native-handoff.md](native-handoff.md), with a
parent-directed transfer inside the existing suspended launch lifecycle. This
file preserves the earlier audit observations and explains the change; it is
not an approved implementation contract. The KB/held-reader owner is separately
mapping the existing admission path in `qa/pw02-kb-held-reader-design`.

Status: **read-only design draft; no native source edits or execution**. Inspected
baseline: exact corrected contracts `645839646a68815ee1822ee61039af42d583903a`
(QA-only tip `dc4ebf9ccf04abc284ffe334b858c6d39047b68d`). The first contract packet
and the ASCII correction remain separate immutable records. Native Windows,
SDK ABI, filesystem behavior and frozen journey qualification are pending.

## 1. Preserve the existing supervisor and original handles

`jobs.run_process` already starts Windows children suspended, assigns the Job and
memory cap, then resumes. It supplies bounded raw stdout/stderr, output totals,
cancellation and process-tree termination. There is no arbitrary handle-passing
API. The proposed package worker should use this supervisor unchanged.

The parent can create and retain the source, private root, request and selected
output handles before launch. The worker receives a parent PID, creation FILETIME
and request-handle value as fixed command arguments, opens that process with only
the required duplicate/query access, verifies creation identity through the held
process handle, then duplicates the request-listed handles into itself. Duplicates
are non-inheritable and refer to the same objects; the parent keeps every original
until verification, promotion or cleanup completes. Microsoft documents both
cross-process duplication and the shared file position. Therefore the first
implementation must remain serial and explicitly position reads; parent and child
must not seek/read the same object concurrently. [DuplicateHandle][duplicate]
[GetProcessTimes][process-times]

This avoids a new process supervisor and avoids a child-created arbitrary native
handle value becoming authority in the parent. Selected output handles are known
to the parent before decoding. The response may identify only those exact request
tokens; it cannot request that the parent close/open a free-form handle. Failure to
query parent identity, duplicate a listed handle, enforce a Job cap, or confirm a
required filesystem identity refuses before package parsing or admission.

The worker is a capped trusted parser process, not a general security sandbox.
The input remains data. It never launches package members or servicing tools, and
has no package-related network provider. Parent process duplication is bounded by
the request protocol and native object checks; it is not an isolation claim against
arbitrary code already running under the analyst's user identity.

## 2. A concrete existing-reader compatibility boundary

`WindowsPublication.open_child(create=True)` grants read/write and DELETE access
while sharing only READ. Those exact handles support exclusive creation, native
no-replace rename, and owned disposal. The approved package design requires keeping
that identity and sharing lock through basename handoff.

The existing KB `inspect_local_file` and ingestion `file_fingerprint`, `sha256_file`,
`validate_pe` and `inspect_artifact` repeatedly reopen paths using ordinary Python
file opening. They accept no held native reader. A new open must share the access
already granted to existing handles; Microsoft explicitly requires DELETE sharing
when a prior handle has DELETE access. `ReOpenFile` has the same bidirectional
compatibility constraints. It cannot be assumed that an ordinary reopen works, or
that reopening with a new lock can safely replace the original handle.
[ReOpenFile][reopen] [Creating and opening files][sharing]

This is a **design compatibility risk**, not an observed native failure: no Windows
probe has run. Do not close the rename/delete-capable handle to make a path reopen
work, do not weaken its sharing lock, and do not use a global open monkeypatch.

Proposed bounded integration extension, for root review: an optional operation-owned
input-reader lease through the existing inspection/ingestion/project-creation path.
The lease duplicates a held source handle into a read-only descriptor, resets its
position only while serially owned, and checks the same native identity/state before
and after reading. Ordinary path callers keep their existing behavior. The package
wiring supplies the per-operation lease to the existing KbService.import_pair and
ProjectAttachment route; it does not create a second admission or project service.
The exact minimal signatures should be finalized after a real Windows probe of
held R/W+DELETE source, native rename, duplicate-to-reader and immutable artifact
copy. This crosses existing ingestion/persistence/ProjectService ownership and
needs root coordination before edits there.

## 3. Private stage and FDI I/O ownership

Reuse WindowsPublication's rooted NT structures, identity queries, rename and
disposal. Its directory `create=True` uses OPEN_IF and its directory handles lack
DELETE, so that function alone is not proof of an exclusive owned attempt directory.
A narrow package-stage extension must use FILE_CREATE for the random attempt root,
an explicit protected current-user/System DACL, and a held cleanup-capable handle.
Rooted descendant access continues to refuse reparse points. Reject UNC/mapped
remote sources and uncertain local-volume identity before opening package bytes.
Archive names remain logical; all physical names come from the application.

Selected files are precreated exclusively with opaque names under held side roots.
The worker writes only to their duplicated handles. The parent verifies source,
receipt, exact output identity/size and full hash, then calls the existing native
rename with ReplaceIfExists=False and the safe ASCII expected basename. No handle
lock is dropped between these stages. Rename requires DELETE access, and the target
directory has the already-reviewed compatible sharing semantics.
[FILE_RENAME_INFORMATION][rename]

Intermediate nested cabinets use owned scratch handles with exact disposal. A
native delete-on-close option may be appropriate for worker-only intermediates,
but must be tested with duplication and FDI reuse before relying on it for crash
cleanup. Parent cleanup handles only its known created objects. Unknown or replaced
entries prevent directory removal and remain reported; there is no recursive
pathname cleanup or prefix/mtime ownership inference. No process deletes a handle
owned by a different request.

FDI open/read/seek callbacks map fixed opaque cabinet aliases to held inputs with
independent logical cursors. No callback opens an archive pathname. Output callback
tokens map only to a selected sink, a bounded metadata/nested-container sink, or a
bounded discard sink. Every WRITE reservation is checked before I/O, every known
completion is recorded even if cancellation arrives afterward, and every payload
byte including discarded/nested output spends the operation budget. COPY_FILE
declarations are retained; CLOSE_FILE_INFO execution intent is refused and never
interpreted as a byte count. Callback exceptions preserve the first failure and
return the documented failure value; they cannot escape as an apparent success.

## 4. Shared worker grants and receipt protocol

The existing PackageBudget remains the parent operation owner. A new versioned
grant records the operation/request identity, original absolute deadline, source
capture, original limits and the remaining serial allowance. It must not restart
the wall clock or grant a new 8 GiB at each side/worker. Child usage is a delta
against that exact grant, and parent reconciliation refuses missing/overspent,
contradictory or replayed deltas. No second grant is issued concurrently. If a
worker dies without a complete receipt, the attempt fails; its grant is not
refunded for continued work or implicit retry.

The request is strict JSON with a separate small hard cap, carried by a known
owned request handle. The result is bounded strict JSON on stdout; configure both
`log_limit` and `max_output_bytes` to the result cap, separate stderr to 64 KiB,
memory to the captured process ceiling, and timeout to the original remaining
deadline. Require complete output length/totals, expected request/source/attempt,
successful exit and no supervisor stop reason before accepting a result. Read/hash,
result parsing and final parent verification still check the original budget.

Header selection and materialization create different inventory receipts. Preserve
the user's original selection/inventory ID, revalidate its source/member/ancestor
identity before work, and link the resulting materialized inventory explicitly.
Do not silently reinterpret the original header receipt as already reverified.
Only the post-materialization selector can admit a complete full PE; neither
receipt establishes signature, product, checkpoint, applicability or chronology.

## 5. Test-first implementation order after root disposition

1. Add grant/request/result contracts and allocation/write/callback ownership tests
   before implementing callback plumbing. Portable fake callbacks qualify only
   mechanics; keep the corrected 284/independent controls unchanged.
2. Add stage handle-operation tests before the rooted native stage. Include exclusive
   root collision, reparse/foreign object, cleanup failure, exact native rename and
   parent/child identity cases. No broad ingestion edits in this stage slice.
3. Bind FDI with fixed-width Windows types and pointer-sized handles, kept callback
   references and explicit System32 DLL loading. Require native SDK structure/offset
   checks and real authored CAB/MSU cases before claiming a usable qualified lane.
4. Run the actual Windows held-handle reader compatibility probe and agree on the
   minimal existing-ingestion lease signatures. Then compose the package service
   with root's already-reviewed saved-scope admission, WorkspaceStore and ordinary
   import route. No service.py/context/index/saved_scope parallel implementation.
5. Qualify real Windows callback budgets/cancel/cleanup and the frozen authored-PE
   pair journey. Linux must refuse platform operations before reads/staging/children.

No workflow dispatch, package retrieval, target execution, release or remote
mutation is proposed by this draft. Root owns integration and any hosted run.

[duplicate]: https://learn.microsoft.com/en-us/windows/win32/api/handleapi/nf-handleapi-duplicatehandle
[process-times]: https://learn.microsoft.com/en-us/windows/win32/api/processthreadsapi/nf-processthreadsapi-getprocesstimes
[reopen]: https://learn.microsoft.com/en-us/windows/win32/api/winbase/nf-winbase-reopenfile
[sharing]: https://learn.microsoft.com/en-us/windows/win32/fileio/creating-and-opening-files
[rename]: https://learn.microsoft.com/en-us/windows-hardware/drivers/ddi/ntifs/ns-ntifs-_file_rename_information
