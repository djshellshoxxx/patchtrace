"""Seal this design audit; do not alter any prior source or QA receipt."""
from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
EXCLUDED = {'manifest.json', 'evidence.zip'}


def main() -> None:
    archive = ROOT / 'evidence.zip'
    manifest = ROOT / 'manifest.json'
    if archive.exists() or manifest.exists():
        raise RuntimeError('the design packet is already sealed')
    members = []
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
        for path in sorted(ROOT.rglob('*')):
            if not path.is_file() or path.name in EXCLUDED or '__pycache__' in path.parts:
                continue
            name = path.relative_to(ROOT).as_posix()
            body = path.read_bytes()
            info = zipfile.ZipInfo(name, date_time=(2026, 11, 18, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            output.writestr(info, body)
            members.append({'path': name, 'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()})
    with zipfile.ZipFile(archive) as check:
        if check.testzip() is not None or len(check.infolist()) != len(members):
            raise RuntimeError('archive verification failed')
        for item in members:
            body = check.read(item['path'])
            if len(body) != item['bytes'] or hashlib.sha256(body).hexdigest() != item['sha256']:
                raise RuntimeError('archive member differs')
    body = archive.read_bytes()
    record = {'status': 'design-only; no native execution or test qualification',
              'source_sha': '27e4318b87e0af3be0fc11a1906b86d95c44f46b',
              'contracts_source_sha': '645839646a68815ee1822ee61039af42d583903a',
              'archive': {'path': archive.name, 'bytes': len(body),
                          'sha256': hashlib.sha256(body).hexdigest(),
                          'members': len(members), 'uncompressed_bytes': sum(x['bytes'] for x in members)},
              'members': members}
    with manifest.open('x', encoding='utf-8', newline='\n') as stream:
        stream.write(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record['archive']))


if __name__ == '__main__':
    main()
