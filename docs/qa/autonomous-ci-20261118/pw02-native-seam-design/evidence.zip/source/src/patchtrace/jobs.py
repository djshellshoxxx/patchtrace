"""Bounded child-process execution. Targets are never executed by this module."""
from __future__ import annotations

import os
import signal
import subprocess
import threading
import time
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path

LOG_LIMIT = 2 * 1024 * 1024
_PROGRESS_TAIL_LIMIT = 16 * 1024
# Windows: inheritable pipe/NUL handles exist from CreatePipe until the parent closes the child ends after
# CreateProcessW(bInheritHandles=True). Serialising that window stops a concurrent run_process child from
# inheriting another run's pipe write end (which would keep that reader from ever seeing EOF).
_WINDOWS_SPAWN_LOCK = threading.Lock()
# prlimit()/setrlimit() raise OverflowError (not OSError) beyond the rlim_t range; no real cap is this large.
MEMORY_LIMIT_CEILING = 1 << 62
# CreateProcessW runs a .bat/.cmd through cmd.exe, which still parses these after list2cmdline quoting
# (`%`/`!` expand even inside quotes; CR/LF end the command).
_BATCH_METACHARACTERS = frozenset('&|<>^%!\r\n')
_JOB_KILL_ON_JOB_CLOSE, _JOB_DIE_ON_UNHANDLED_EXCEPTION, _JOB_PROCESS_MEMORY = 0x2000, 0x400, 0x100


def _positive_int(value: object) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and value >= 1


def _valid_environment(env: Mapping[str, str]) -> bool:
    """TB-15: names and values that mean the same in a POSIX `environ` and in a NUL-separated Windows block.

    A NUL would end an entry early and start another variable; `=` in a name moves the name/value boundary.
    """
    return all(isinstance(name, str) and isinstance(value, str) and name and '=' not in name
               and '\0' not in name and '\0' not in value for name, value in env.items())


@dataclass(frozen=True)
class ProcessProgress:
    """Bounded, unredacted child output for trusted internal observers only."""

    elapsed_seconds: float
    log_tail: str
    stderr_tail: str
    stdout_total: int
    stderr_total: int
    last_output_elapsed_seconds: float | None


def _argv_error(argv: Sequence[str], windows: bool) -> str | None:
    """Return why `argv` must not be launched, or None (architecture.md "Launch argument rules")."""
    args = [os.fsdecode(arg) for arg in argv]
    if any('\0' in arg for arg in args):
        return 'PT-BACKEND: a program argument contains a NUL character'
    # Windows ignores trailing dots and spaces in a file name, so `x.bat.` is still a batch file.
    program = args[0].casefold().rstrip('. ') if args else ''
    if windows and program.endswith(('.bat', '.cmd')) and any(_BATCH_METACHARACTERS.intersection(a) for a in args):
        return ('PT-BACKEND: a .bat/.cmd launcher cannot be given a path or argument containing '
                '& | < > ^ % ! or a line break; configure the program .exe')
    return None


def _windows_env_block(env: Mapping[str, str]) -> str:
    """CREATE_UNICODE_ENVIRONMENT block, sorted case-insensitively as CreateProcessW documents."""
    for name, value in env.items():
        # A leading '=' is legal (the per-drive `=C:` entries); a later one would split the name.
        if not name or '\0' in name or '=' in name[1:] or '\0' in value:
            raise ValueError('PT-BACKEND: an environment variable name or value is not valid for Windows')
    entries = sorted(env.items(), key=lambda item: (item[0].upper(), item[0]))
    return '\0'.join(f'{k}={v}' for k, v in entries) + '\0\0'


def _job_limit_flags(memory_limit_bytes: int | None) -> int:
    # DIE_ON_UNHANDLED_EXCEPTION: a crashed tool exits instead of waiting in an error-report dialog until the
    # timeout. Breakaway (0x800/0x1000) is never allowed: every descendant stays in the job.
    flags = _JOB_KILL_ON_JOB_CLOSE | _JOB_DIE_ON_UNHANDLED_EXCEPTION
    return flags | _JOB_PROCESS_MEMORY if memory_limit_bytes is not None else flags


@dataclass(frozen=True)
class ProcessResult:
    returncode: int
    log_tail: str
    reason: str | None = None
    # Populated only when run_process(separate_streams=True); log_tail is then stdout alone.
    stderr_tail: str = ''
    # Windows only: the Job Object's PeakProcessMemoryUsed (committed bytes); None elsewhere or if unavailable.
    peak_memory_bytes: int | None = None
    # Additive (SPEC-29 TA-4/TA-5). The captured streams as the exact bytes read (log_tail/stderr_tail are their
    # lossy `errors='replace'` text) and the total number of bytes each stream delivered, so a caller can hash
    # what the child wrote, reject invalid UTF-8 and tell an output flood from a large legitimate output.
    log_bytes: bytes | None = None
    stderr_bytes: bytes | None = None
    stdout_total: int = 0
    stderr_total: int = 0
    # Supervisor-clock duration, excluding cleanup waits. Preserve all prior positional fields.
    elapsed_seconds: float = 0.0
    last_output_elapsed_seconds: float | None = None


def _windows_process(argv: Sequence[str], cwd: Path, env: Mapping[str, str], separate_streams: bool = False,
                     memory_limit_bytes: int | None = None):
    """Start suspended, contain the child before it can run, then resume it.

    Popen discards the primary thread handle, so use CreateProcessW directly.
    A containment failure terminates the suspended child and fails closed.
    """
    import ctypes as c
    import msvcrt
    from ctypes import wintypes as w

    class Security(c.Structure):
        _fields_ = [('length', w.DWORD), ('descriptor', c.c_void_p), ('inherit', w.BOOL)]

    class Startup(c.Structure):
        _fields_ = [('cb', w.DWORD), ('reserved', w.LPWSTR), ('desktop', w.LPWSTR),
                    ('title', w.LPWSTR), ('x', w.DWORD), ('y', w.DWORD),
                    ('xsize', w.DWORD), ('ysize', w.DWORD), ('xcount', w.DWORD),
                    ('ycount', w.DWORD), ('fill', w.DWORD), ('flags', w.DWORD),
                    ('show', w.WORD), ('reserved_size', w.WORD), ('reserved2', c.c_void_p),
                    ('stdin', w.HANDLE), ('stdout', w.HANDLE), ('stderr', w.HANDLE)]

    class ProcessInfo(c.Structure):
        _fields_ = [('process', w.HANDLE), ('thread', w.HANDLE), ('pid', w.DWORD), ('tid', w.DWORD)]

    class BasicLimits(c.Structure):
        _fields_ = [('process_time', c.c_longlong), ('job_time', c.c_longlong),
                    ('flags', w.DWORD), ('min_ws', c.c_size_t), ('max_ws', c.c_size_t),
                    ('active', w.DWORD), ('affinity', c.c_size_t),
                    ('priority', w.DWORD), ('scheduling', w.DWORD)]

    class IoCounters(c.Structure):
        _fields_ = [(name, c.c_ulonglong) for name in
                    ['read_ops', 'write_ops', 'other_ops', 'read_bytes', 'write_bytes', 'other_bytes']]

    class ExtendedLimits(c.Structure):
        _fields_ = [('basic', BasicLimits), ('io', IoCounters), ('process_memory', c.c_size_t),
                    ('job_memory', c.c_size_t), ('peak_process', c.c_size_t), ('peak_job', c.c_size_t)]

    kernel = c.WinDLL('kernel32', use_last_error=True)
    signatures = {
        'CreatePipe': ([c.POINTER(w.HANDLE), c.POINTER(w.HANDLE), c.POINTER(Security), w.DWORD], w.BOOL),
        'SetHandleInformation': ([w.HANDLE, w.DWORD, w.DWORD], w.BOOL),
        'CreateFileW': ([w.LPCWSTR, w.DWORD, w.DWORD, c.POINTER(Security), w.DWORD, w.DWORD, w.HANDLE], w.HANDLE),
        'CreateProcessW': ([w.LPCWSTR, w.LPWSTR, c.c_void_p, c.c_void_p, w.BOOL,
                            w.DWORD, c.c_void_p, w.LPCWSTR, c.POINTER(Startup), c.POINTER(ProcessInfo)], w.BOOL),
        'CreateJobObjectW': ([c.c_void_p, w.LPCWSTR], w.HANDLE),
        'SetInformationJobObject': ([w.HANDLE, c.c_int, c.c_void_p, w.DWORD], w.BOOL),
        'AssignProcessToJobObject': ([w.HANDLE, w.HANDLE], w.BOOL),
        'ResumeThread': ([w.HANDLE], w.DWORD),
        'GetExitCodeProcess': ([w.HANDLE, c.POINTER(w.DWORD)], w.BOOL),
        'WaitForSingleObject': ([w.HANDLE, w.DWORD], w.DWORD),
        'TerminateProcess': ([w.HANDLE, w.UINT], w.BOOL),
        'TerminateJobObject': ([w.HANDLE, w.UINT], w.BOOL),
        'CloseHandle': ([w.HANDLE], w.BOOL),
        'QueryInformationJobObject': ([w.HANDLE, c.c_int, c.c_void_p, w.DWORD, c.POINTER(w.DWORD)], w.BOOL),
    }
    for name, (args, result) in signatures.items():
        fn = getattr(kernel, name)
        fn.argtypes, fn.restype = args, result

    def check(value):
        if not value:
            raise c.WinError(c.get_last_error())
        return value

    environment = c.create_unicode_buffer(_windows_env_block(env))  # validated before anything is created
    read, write = w.HANDLE(), w.HANDLE()
    err_read, err_write = w.HANDLE(), w.HANDLE()
    security = Security(c.sizeof(Security), None, True)
    info = ProcessInfo()
    job = null = None
    stdout = stderr = None
    _WINDOWS_SPAWN_LOCK.acquire()
    try:
        check(kernel.CreatePipe(c.byref(read), c.byref(write), c.byref(security), 0))
        check(kernel.SetHandleInformation(read, 1, 0))
        if separate_streams:
            check(kernel.CreatePipe(c.byref(err_read), c.byref(err_write), c.byref(security), 0))
            check(kernel.SetHandleInformation(err_read, 1, 0))
        null = kernel.CreateFileW('NUL', 0x80000000, 3, c.byref(security), 3, 0, None)
        if null == c.c_void_p(-1).value:
            raise c.WinError(c.get_last_error())
        startup = Startup()
        startup.cb, startup.flags = c.sizeof(Startup), 0x100
        startup.stdin, startup.stdout = null, write
        startup.stderr = err_write if separate_streams else write
        command = c.create_unicode_buffer(subprocess.list2cmdline(list(argv)))
        check(kernel.CreateProcessW(str(argv[0]), command, None, None, True,
                                    0x4 | 0x400 | 0x08000000, environment, str(cwd),
                                    c.byref(startup), c.byref(info)))
        job = check(kernel.CreateJobObjectW(None, None))
        limits = ExtendedLimits()
        limits.basic.flags = _job_limit_flags(memory_limit_bytes)
        if memory_limit_bytes is not None:
            # JOB_OBJECT_LIMIT_PROCESS_MEMORY: committed-memory cap per process, set before the child resumes.
            # Over-limit behaviour (allocation failure vs termination, exit code) is a measured unknown (U7).
            limits.process_memory = memory_limit_bytes
        check(kernel.SetInformationJobObject(job, 9, c.byref(limits), c.sizeof(limits)))
        check(kernel.AssignProcessToJobObject(job, info.process))
        if kernel.ResumeThread(info.thread) == 0xffffffff:
            raise c.WinError(c.get_last_error())
        stdout = os.fdopen(msvcrt.open_osfhandle(read.value, os.O_RDONLY | os.O_BINARY), 'rb', buffering=0)
        read = w.HANDLE()  # Python now owns this handle.
        if separate_streams:
            stderr = os.fdopen(msvcrt.open_osfhandle(err_read.value, os.O_RDONLY | os.O_BINARY), 'rb', buffering=0)
            err_read = w.HANDLE()
    except BaseException:
        if info.process:
            kernel.TerminateProcess(info.process, 1)
            kernel.WaitForSingleObject(info.process, 5000)
            kernel.CloseHandle(info.process)
        if job:
            kernel.CloseHandle(job)
        if stdout:
            stdout.close()
        if stderr:
            stderr.close()
        raise
    finally:
        try:
            for handle in [write, read, err_write, err_read, null, info.thread]:
                if handle:
                    kernel.CloseHandle(handle)
        finally:
            _WINDOWS_SPAWN_LOCK.release()

    class WindowsChild:
        pid = info.pid

        def __init__(self):
            self.stdout = stdout
            self.stderr = stderr

        def poll(self):
            # Exit code 259 is legal: wait status distinguishes it from STILL_ACTIVE.
            if kernel.WaitForSingleObject(info.process, 0) == 258:
                return None
            code = w.DWORD()
            check(kernel.GetExitCodeProcess(info.process, c.byref(code)))
            return code.value

        def peak_memory(self):
            info_out = ExtendedLimits()
            if not kernel.QueryInformationJobObject(job, 9, c.byref(info_out), c.sizeof(info_out), None):
                return None
            return int(info_out.peak_process)

        def kill_tree(self):
            check(kernel.TerminateJobObject(job, 1))

        def close(self):
            kernel.CloseHandle(job)
            kernel.CloseHandle(info.process)

    return WindowsChild()


def _posix_preexec(memory_limit_bytes: int | None):
    if memory_limit_bytes is None or hasattr(__import__('resource'), 'prlimit'):
        return None
    import resource

    def apply():  # only on POSIX systems without prlimit (not Linux)
        resource.setrlimit(resource.RLIMIT_AS, (memory_limit_bytes, memory_limit_bytes))
    return apply


def _posix_prlimit(child, memory_limit_bytes: int) -> None:
    import resource
    if not hasattr(resource, 'prlimit'):
        return  # applied by preexec_fn
    try:
        _, hard = resource.prlimit(child.pid, resource.RLIMIT_AS)
        # Never raise an inherited lower hard limit (needs privilege); lowering is always allowed.
        cap = memory_limit_bytes if hard == resource.RLIM_INFINITY else min(hard, memory_limit_bytes)
        resource.prlimit(child.pid, resource.RLIMIT_AS, (cap, cap))
    except ProcessLookupError:
        pass  # exited before the cap applied: nothing left to cap
    except OSError:
        try:  # fail closed: never run uncapped when a cap was requested
            os.killpg(child.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        child.wait(timeout=5)
        raise


def run_process(argv: Sequence[str], *, cwd: Path, env: Mapping[str, str],
                cancel: threading.Event, timeout_seconds: float,
                check_output: Callable[[], str | None] | None = None,
                log_limit: int = LOG_LIMIT, separate_streams: bool = False,
                stderr_limit: int = LOG_LIMIT, memory_limit_bytes: int | None = None,
                max_output_bytes: int | None = None,
                on_progress: Callable[[ProcessProgress], None] | None = None) -> ProcessResult:
    """Run an argv with a bounded log and terminate descendants on every exit.

    By default stdout and stderr are merged into `log_tail`. With `separate_streams`,
    `log_tail` holds stdout only (bounded by `log_limit`) and `stderr_tail` holds stderr
    (bounded by `stderr_limit`), each drained by its own thread so neither can block the other.

    `memory_limit_bytes` (default None = unlimited, unchanged behaviour) caps the child: a Windows Job Object
    per-process memory limit applied before the suspended child resumes; on Linux RLIMIT_AS set with
    prlimit() right after spawn (no preexec_fn in a threaded GUI; a self-limiting child closes the startup
    window); on other POSIX systems RLIMIT_AS through preexec_fn. RLIMIT_AS counts virtual memory, so size
    the cap with headroom over the expected RSS.

    `max_output_bytes` (default None = unlimited) stops the child as soon as its stdout has delivered more than
    that many bytes in total (`reason='output-limit'`): `log_limit` only bounds the memory of the kept tail, so a
    child that prints without end would otherwise run to the full timeout.

    `on_progress` receives at most one bounded snapshot per second and a final snapshot after pipe drain.
    It runs on this supervisor thread without the reader lock and must return promptly. Ordinary observer
    errors are ignored; interrupts still trigger cleanup. Output activity never changes the fixed deadline.
    """
    if not argv or not Path(argv[0]).is_absolute():
        raise ValueError('PT-BACKEND: configure an absolute executable path')
    if error := _argv_error(argv, os.name == 'nt'):
        raise ValueError(error)
    # `not x > 0` rejects NaN (which never reaches a deadline); a float limit would kill the reader thread.
    if not timeout_seconds > 0 or not _positive_int(log_limit) or not _positive_int(stderr_limit):
        raise ValueError('PT-BACKEND: timeout and log limit must be positive')
    if max_output_bytes is not None and not _positive_int(max_output_bytes):
        raise ValueError('PT-BACKEND: output limit must be a positive integer')
    if memory_limit_bytes is not None and not (_positive_int(memory_limit_bytes)
                                               and memory_limit_bytes < MEMORY_LIMIT_CEILING):
        raise ValueError('PT-BACKEND: memory limit must be a positive integer')
    if not _valid_environment(env):
        # The name and the value stay out of the message: either may be a credential or hostile text.
        raise ValueError('PT-BACKEND: child environment has an invalid variable name or value')
    if cancel.is_set():
        return ProcessResult(-1, '', 'cancelled')
    peek_exit = os.name != 'nt' and all(hasattr(os, name) for name in
                                       ('waitid', 'P_PID', 'WEXITED', 'WNOHANG', 'WNOWAIT'))
    if os.name != 'nt' and not peek_exit:
        raise OSError('PT-BACKEND: safe process supervision requires POSIX waitid with WNOWAIT')
    if os.name == 'nt':
        child = _windows_process(argv, cwd, env, separate_streams, memory_limit_bytes)
    else:
        if signal.getsignal(signal.SIGCHLD) == signal.SIG_IGN:
            # The kernel then reaps children itself and Popen reports every exit status (even a crash) as 0.
            raise OSError('PT-BACKEND: SIGCHLD is ignored by this process, so child exit statuses would be lost; '
                          'restore it with signal.signal(signal.SIGCHLD, signal.SIG_DFL)')
        child = subprocess.Popen(list(argv), cwd=cwd, env=dict(env), shell=False,
                                 stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE if separate_streams else subprocess.STDOUT,
                                 start_new_session=True, bufsize=0,
                                 preexec_fn=_posix_preexec(memory_limit_bytes))
    tail, err_tail = bytearray(), bytearray()
    totals = {'out': 0, 'err': 0}
    last_output_at: float | None = None
    lock = threading.Lock()

    def collect(stream, buffer: bytearray, limit: int, name: str):
        nonlocal last_output_at
        try:
            while chunk := stream.read(8192):
                with lock:
                    totals[name] += len(chunk)
                    last_output_at = time.monotonic()
                    buffer.extend(chunk)
                    if len(buffer) > limit:
                        del buffer[:-limit]
        except (OSError, ValueError):
            pass

    readers = [threading.Thread(target=collect, args=(child.stdout, tail, log_limit, 'out'),
                                name='patchtrace-log', daemon=True)]
    if separate_streams:
        readers.append(threading.Thread(target=collect, args=(child.stderr, err_tail, stderr_limit, 'err'),
                                        name='patchtrace-err', daemon=True))
    # POSIX invariant (TB-09): the group is signalled only while its leader is unreaped. A reaped leader's pid can
    # be recycled, and killpg would then reach an unrelated group. So the exit is observed without reaping (WNOWAIT
    # leaves the zombie holding the pid), the group is killed, and only then does wait() reap. Unsupported POSIX
    # runtimes are refused before spawn, because polling first can release the PID to an unrelated group.
    group_owned = True

    def running() -> bool:
        nonlocal group_owned
        if peek_exit:
            try:
                return os.waitid(os.P_PID, child.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT) is None
            except ChildProcessError:
                group_owned = False  # An external reaper released the PID: never signal that group again.
                raise RuntimeError('PT-BACKEND: child was reaped outside its supervisor') from None
        return child.poll() is None

    def terminate():
        if os.name == 'nt':
            child.kill_tree()
        elif group_owned and child.returncode is None:
            try:
                os.killpg(child.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass

    def activity_elapsed(elapsed: float, output_at: float | None) -> float | None:
        # Readers may start before the deadline clock and finish draining after the observed stop.
        # Keep their activity on the execution interval so reported idle time cannot be negative.
        return None if output_at is None else min(elapsed, max(0.0, output_at - started))

    def notify_progress(elapsed: float, out: bytes, err: bytes,
                        out_total: int, err_total: int, output_at: float | None) -> None:
        if on_progress is None:
            return
        snapshot = ProcessProgress(elapsed, out[-_PROGRESS_TAIL_LIMIT:].decode('utf-8', errors='replace'),
                                   err[-_PROGRESS_TAIL_LIMIT:].decode('utf-8', errors='replace'),
                                   out_total, err_total, activity_elapsed(elapsed, output_at))
        try:
            on_progress(snapshot)
        except Exception:
            pass  # Observation cannot change child supervision, exit status, or failure evidence.

    try:
        # Everything after the spawn is covered by the `finally`: a failed memory cap, a reader thread that
        # cannot start (thread exhaustion) or an interrupt must not leave the child tree running or its pipes open.
        if os.name != 'nt' and memory_limit_bytes is not None:
            _posix_prlimit(child, memory_limit_bytes)
        for reader in readers:
            reader.start()
        started, reason = time.monotonic(), None
        next_progress = started
        stopped: float | None = None
        while running():
            if cancel.is_set():
                reason = 'cancelled'
            elif time.monotonic() - started >= timeout_seconds:
                reason = 'timeout'
            elif max_output_bytes is not None and totals['out'] > max_output_bytes:
                reason = 'output-limit'
            elif check_output:
                reason = check_output()
            if reason:
                stopped = time.monotonic()
                terminate()
                break
            now = time.monotonic()
            if on_progress is not None and now >= next_progress:
                with lock:
                    progress_out = bytes(tail[-_PROGRESS_TAIL_LIMIT:])
                    progress_err = bytes(err_tail[-_PROGRESS_TAIL_LIMIT:])
                    progress_out_total, progress_err_total = totals['out'], totals['err']
                    progress_output_at = last_output_at
                notify_progress(now - started, progress_out, progress_err,
                                progress_out_total, progress_err_total, progress_output_at)
                next_progress = time.monotonic() + 1.0
            cancel.wait(0.05)
        elapsed_seconds = (time.monotonic() if stopped is None else stopped) - started
        # A successful parent may leave a descendant holding the output pipe.
        terminate()
        if os.name != 'nt':
            try:
                returncode = child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                raise RuntimeError('PT-BACKEND: terminated child did not exit') from None
        else:
            deadline = time.monotonic() + 5
            while child.poll() is None and time.monotonic() < deadline:
                time.sleep(0.01)
            returncode = child.poll()
            if returncode is None:
                raise RuntimeError('PT-BACKEND: contained child did not exit')
        for reader in readers:
            reader.join(timeout=5)
        with lock:
            log_raw, err_raw = bytes(tail), bytes(err_tail)
            out_total, err_total = totals['out'], totals['err']
            output_at = last_output_at
        log = log_raw.decode('utf-8', errors='replace')
        err = err_raw.decode('utf-8', errors='replace')
        peak = None
        if os.name == 'nt':
            try:
                peak = child.peak_memory()
            except OSError:
                peak = None
        notify_progress(elapsed_seconds, log_raw, err_raw, out_total, err_total, output_at)
        return ProcessResult(returncode, log, reason, err, peak, log_raw, err_raw, out_total, err_total,
                             elapsed_seconds, activity_elapsed(elapsed_seconds, output_at))
    finally:
        try:
            terminate()
        finally:  # a failing kill must not leak the Job/process handles or the pipes
            if os.name != 'nt':
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    pass  # Already reported above; do not mask the primary error.
            if os.name == 'nt':
                child.close()
            streams = [child.stdout, child.stderr][:len(readers)]
            for reader, stream in zip(readers, streams, strict=True):
                if not reader.is_alive():
                    stream.close()
