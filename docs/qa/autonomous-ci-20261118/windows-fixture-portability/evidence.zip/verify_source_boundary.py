"""Read-only verifier for the exact reviewed fixture/tool-source delta."""
import ast
from collections import Counter
import json
from pathlib import Path
import subprocess


ROOT = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages')
QA = Path(__file__).resolve().parent
BASE = 'f16d41062a5d558d889ef6a6bda922004e0ac3b4'
SOURCE = '81590f936b3f01555720221e55f99ec0611ec4a1'


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT)


allowed = {'docs/modules.md', 'docs/specs/ci-workflow-integrity.md', 'tasks/todo.md',
           'tests/test_release_qualification.py', 'tests/test_release_source_stat.py',
           'tests/test_dependency_security.py', 'tests/test_windows_bindiff_network.py',
           'tests/test_linux_frozen_smoke.py', 'tools/build_linux.py'}
changed = set(git('diff', '--name-only', BASE, SOURCE).decode().splitlines())
assert changed == allowed
rows = []
for path in sorted(p for p in changed if p.startswith('tests/')):
    before = ast.parse(git('show', BASE + ':' + path))
    after = ast.parse(git('show', SOURCE + ':' + path))

    def assertions(tree):
        return Counter(ast.dump(node, include_attributes=False) for node in ast.walk(tree)
                       if isinstance(node, ast.Assert))

    def contexts(tree):
        return Counter(ast.dump(item.context_expr, include_attributes=False) for node in ast.walk(tree)
                       if isinstance(node, (ast.With, ast.AsyncWith)) for item in node.items)

    old, new = assertions(before), assertions(after)
    assert not old - new and not contexts(before) - contexts(after)
    old_tests = {node.name: node for node in before.body
                 if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith('test_')}
    new_tests = {node.name: node for node in after.body
                 if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name.startswith('test_')}
    for name, node in old_tests.items():
        assert name in new_tests
        assert [ast.dump(item) for item in node.decorator_list] == [
            ast.dump(item) for item in new_tests[name].decorator_list]
        assert ast.dump(node.args) == ast.dump(new_tests[name].args)
    rows.append({'file': path, 'original_assertions': sum(old.values()),
                 'preserved_original_test_functions': len(old_tests),
                 'assertions_and_context_managers_preserved': True,
                 'original_test_decorators_preserved': True})
old = git('show', BASE + ':tools/build_linux.py')
new = git('show', SOURCE + ':tools/build_linux.py')
line = b"inventory = sorted(str(p.relative_to(package)) for p in package.rglob('*') if p.is_file())"
assert old.count(line) == 1
assert new == old.replace(line,
    b"inventory = sorted(p.relative_to(package).as_posix() for p in package.rglob('*') if p.is_file())")
validators = ['tools/release_qualification.py', 'tools/dependency_security.py', 'tools/windows_bindiff_network.py']
assert all(git('show', BASE + ':' + path) == git('show', SOURCE + ':' + path) for path in validators)
result = {'baseline': BASE, 'source': SOURCE, 'changed_paths': sorted(changed), 'original_assertions': rows,
          'one_approved_tool_line_only': True, 'unchanged_validators': validators,
          'native_source_unchanged': not git('diff', '--name-only', BASE, SOURCE, 'tools/windows_network', 'src')}
assert result == json.loads((QA / 'source-boundary.json').read_text())
print(json.dumps({'verified': True, 'source': SOURCE, 'original_assertions': sum(
    row['original_assertions'] for row in rows), 'original_test_functions': sum(
    row['preserved_original_test_functions'] for row in rows)}, indent=2))
