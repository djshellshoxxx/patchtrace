"""Seal source-attributed fixture evidence without executing repository tests."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile


QA = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages')
CHECKPOINT = REPO / 'docs/qa/autonomous-ci-20261118/windows-fixture-portability'
assert not (QA / 'manifest.json').exists() and not (QA / 'evidence.zip').exists()
assert not CHECKPOINT.exists()
snapshots = []
for label in ['red', 'green', 'green-v2', 'affected', 'affected-v2']:
    command = json.loads((QA / f'{label}.command.json').read_text())
    assert hashlib.sha256((QA / f'{label}-runner.py').read_bytes()).hexdigest() == command['runner_sha256']
    for record in command['source_files']:
        path = QA / f'{label}-source' / record['path']
        data = path.read_bytes()
        expected = subprocess.check_output(['git', '--no-replace-objects', 'show',
            command['source_commit'] + ':' + record['path']], cwd=REPO)
        assert data == expected and len(data) == record['bytes']
        assert hashlib.sha256(data).hexdigest() == record['sha256']
        snapshots.append({'run': label, 'source': command['source_commit'], 'stored': str(path.relative_to(QA)),
                          **record})
(QA / 'verified-source-snapshots.json').write_text(json.dumps(snapshots, indent=2) + '\n')
records = []
for path in sorted(QA.rglob('*')):
    if not path.is_file() or path.name in {'manifest.json', 'evidence.zip', 'seal.json'}:
        continue
    assert not path.is_symlink()
    data = path.read_bytes()
    records.append({'path': path.relative_to(QA).as_posix(), 'bytes': len(data),
                    'sha256': hashlib.sha256(data).hexdigest()})
manifest = {'contract': 'authored-qualification-evidence/1',
            'source': '81590f936b3f01555720221e55f99ec0611ec4a1',
            'baseline': 'f16d41062a5d558d889ef6a6bda922004e0ac3b4',
            'scope': 'Portable fixture and Linux inventory correction; native Windows remains unverified.',
            'payloads': records}
manifest_data = (json.dumps(manifest, indent=2) + '\n').encode()
(QA / 'manifest.json').write_bytes(manifest_data)
with zipfile.ZipFile(QA / 'evidence.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as archive:
    for record in records:
        archive.write(QA / record['path'], record['path'])
    archive.write(QA / 'manifest.json', 'manifest.json')
with zipfile.ZipFile(QA / 'evidence.zip') as archive:
    assert archive.testzip() is None and len(archive.infolist()) == len(records) + 1
    assert archive.read('manifest.json') == manifest_data
    for record in records:
        data = archive.read(record['path'])
        assert len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256']
data = (QA / 'evidence.zip').read_bytes()
seal = {'sealed_utc': dt.datetime.now(dt.UTC).isoformat(), 'archive': 'evidence.zip',
        'archive_bytes': len(data), 'archive_sha256': hashlib.sha256(data).hexdigest(),
        'manifest_sha256': hashlib.sha256(manifest_data).hexdigest(), 'payloads': len(records),
        'members': len(records) + 1, 'payload_bytes': sum(row['bytes'] for row in records),
        'verified_git_source_snapshots': len(snapshots),
        'baseline': manifest['baseline'], 'source': manifest['source'],
        'focused': '20 passed, no skips', 'affected': '678 passed, 8 explicit native Windows skips',
        'original_hosted_result': 'failed, unchanged', 'recorder_errors_preserved': 2,
        'native_windows_qualified': False, 'remote_mutations': False}
(QA / 'seal.json').write_text(json.dumps(seal, indent=2) + '\n')
CHECKPOINT.mkdir(parents=True)
for name in ['README.md', 'manifest.json', 'evidence.zip', 'seal.json']:
    shutil.copyfile(QA / name, CHECKPOINT / name)
    assert (CHECKPOINT / name).read_bytes() == (QA / name).read_bytes()
print(json.dumps(seal, indent=2))
