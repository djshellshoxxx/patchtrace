"""Exact-source fixture gates: local authored Git only, no network/native payloads."""
from __future__ import annotations

import ast
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time


ROOT = Path('/workspace/scratch/c7a9e8d98848/pw02-local-packages')
QA = Path(__file__).resolve().parent
SOURCE, LABEL = sys.argv[1:]
assert LABEL in {'red', 'green', 'green-v2', 'affected', 'affected-v2'}
for suffix in ('log', 'xml', 'command.json', 'imports.json', 'exit.json', 'fixtures.json'):
    assert not (QA / f'{LABEL}.{suffix}').exists()
os.chdir(ROOT)
sys.dont_write_bytecode = True
sys.path[:0] = [str(ROOT / 'src'), str(ROOT), str(ROOT / 'tests')]
os.environ.update(PYTHONPATH=f'{ROOT}/src:{ROOT}:{ROOT}/tests', PYTHONDONTWRITEBYTECODE='1',
                  GIT_NO_REPLACE_OBJECTS='1', GIT_ALLOW_PROTOCOL='file', GIT_CONFIG_NOSYSTEM='1',
                  GIT_CONFIG_GLOBAL=os.devnull, QT_QPA_PLATFORM='offscreen',
                  PYTEST_DISABLE_PLUGIN_AUTOLOAD='1')
for key in list(os.environ):
    if key in {'GIT_CONFIG_COUNT', 'GIT_CONFIG_PARAMETERS'} or key.startswith(('GIT_CONFIG_KEY_', 'GIT_CONFIG_VALUE_')):
        os.environ.pop(key)


def git(*args):
    return subprocess.check_output(['git', '--no-replace-objects', *args], cwd=ROOT)


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('diff', '--name-only', 'HEAD')
blobs = {}
for row in git('ls-tree', '-r', '-z', SOURCE, 'src', 'tools', 'tests').split(b'\0'):
    if row:
        meta, path = row.split(b'\t', 1)
        blobs[path.decode()] = meta.split()[2].decode()
files = ['tests/test_release_source_stat.py', 'tests/test_dependency_security.py',
         'tests/test_windows_bindiff_network.py', 'tests/test_linux_frozen_smoke.py']
if LABEL.startswith('affected'):
    files += ['tests/test_release_qualification.py', 'tests/test_dependency_security_bootstrap.py',
              'tests/test_build_full_variants.py', 'tests/test_spec_registry.py']
owned = list(dict.fromkeys([*files, 'tests/test_release_qualification.py', 'tools/build_linux.py',
    'tools/release_qualification.py', 'tools/dependency_security.py', 'tools/windows_bindiff_network.py',
    'docs/specs/ci-workflow-integrity.md', 'docs/modules.md', 'tasks/todo.md']))
if LABEL.startswith('affected'):
    owned += ['tests/fake_bindiff.py', 'tests/fake_exe.py', 'tests/bindiff_builder.py',
              'tests/fixtures/secondary/bindiff-8-help.txt']
snapshots = []
for name in owned:
    data = (ROOT / name).read_bytes()
    assert data == git('show', f'{SOURCE}:{name}')
    target = QA / f'{LABEL}-source' / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    snapshots.append({'path': name, 'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})
import pytest

temporary = Path(tempfile.mkdtemp(prefix='patchtrace-fixture-portability-', dir='/tmp')).resolve()
os.environ['TMPDIR'] = str(temporary)
tempfile.tempdir = str(temporary)
git_binary = Path(shutil.which('git')).resolve()
children, denied = [], []
python_binary = Path(sys.executable).resolve()
constant_children, fake_bytes = set(), None
if LABEL.startswith('affected'):
    # Reviewed literal stdout/stderr/exit/output-cap probes, not scanner commands.
    for node in ast.walk(ast.parse((ROOT / 'tests/test_dependency_security.py').read_text())):
        if (isinstance(node, ast.List) and len(node.elts) == 4
                and isinstance(node.elts[0], ast.Attribute) and node.elts[0].attr == 'executable'
                and all(isinstance(item, ast.Constant) for item in node.elts[1:])
                and [item.value for item in node.elts[1:3]] == ['-I', '-c']):
            constant_children.add(node.elts[3].value)
    assert len(constant_children) == 4 and all(len(value) < 200 for value in constant_children)
    definitions = {node.targets[0].id: ast.literal_eval(node.value)
                   for node in ast.parse((ROOT / 'tests/fake_bindiff.py').read_text()).body
                   if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)
                   and node.targets[0].id in {'_SOURCE', 'VERSION_LINE'}}
    fake_source = (definitions['_SOURCE'].replace('TESTS', repr(str(ROOT / 'tests')), 1)
                   .replace('MODE_VALUE', repr('ok')).replace('VERSION', repr(definitions['VERSION_LINE']))
                   .replace('HELP', repr((ROOT / 'tests/fixtures/secondary/bindiff-8-help.txt').read_text())))
    fake_bytes = (f'#!{python_binary}\n' + fake_source).encode('utf-8')


def owner_exit_probe(script):
    """Recognize the one reviewed short pipe producer with an owned receipt path."""
    if not isinstance(script, str) or len(script) > 5000:
        return False
    try:
        paths = [node.args[0].value for node in ast.walk(ast.parse(script)) if isinstance(node, ast.Call)
                 and isinstance(node.func, ast.Name) and node.func.id == 'Path' and len(node.args) == 1
                 and isinstance(node.args[0], ast.Constant) and isinstance(node.args[0].value, str)]
    except (SyntaxError, ValueError):
        return False
    if len(paths) != 1:
        return False
    receipt = Path(paths[0]).resolve()
    if receipt.name != 'start.json' or not receipt.is_relative_to(temporary):
        return False
    rows = [{'pid': 100 + depth, 'parent_pid': 99 + depth, 'created': str(1100 + depth),
             'depth': depth, 'nonce': 'e' * 32, 'appcontainer': True,
             'sid': 'S-1-15-2-1-2-3-4-5-6-7', 'capability_count': 0, 'cases': []} for depth in range(3)]
    expected = ('import json,os,time; from pathlib import Path; '
                f'Path({str(receipt)!r}).write_text(json.dumps({{"owner_pid":os.getpid(),"pid":100}})); '
                f'rows=json.loads({json.dumps(rows)!r}); '
                '[print(json.dumps(r),flush=True) for r in rows]; time.sleep(30)')
    return script == expected


def refuse(event, detail):
    denied.append({'event': event, 'detail': str(detail)[:1000]})
    raise PermissionError('Fixture portability gate refuses unreviewed child/network activity')


def audit(event, args):
    if event in {'socket.__new__', 'socket.connect', 'socket.bind', 'socket.getaddrinfo', 'http.client.connect',
                 'os.system', 'os.posix_spawn', 'os.fork', 'os.exec'}:
        refuse(event, 'network or unreviewed process primitive')
    if event != 'subprocess.Popen':
        return
    executable, argv, cwd, env = args
    argv = list(map(os.fspath, argv)) if isinstance(argv, (list, tuple)) else []
    actual = shutil.which(os.fspath(executable)) if executable else None
    cwd = Path(cwd or os.getcwd()).resolve()
    if LABEL.startswith('affected') and actual and Path(actual).resolve() == python_binary:
        if (len(argv) == 4 and argv[1:3] == ['-I', '-c'] and argv[3] in constant_children
                and cwd == ROOT):
            kind = 'authored literal scanner-receipt producer'
        elif (len(argv) == 4 and argv[1:3] == ['-u', '-c'] and owner_exit_probe(argv[3])
              and cwd.is_relative_to(temporary)):
            kind = 'authored bounded owner-exit pipe producer'
        else:
            refuse(event, {'argv': argv, 'cwd': str(cwd)})
        children.append({'kind': kind, 'argv': argv, 'cwd': str(cwd)})
        return
    if (LABEL.startswith('affected') and actual and Path(actual).resolve().is_relative_to(temporary)
            and Path(actual).name == 'bindiff' and Path(actual).read_bytes() == fake_bytes
            and cwd.is_relative_to(temporary)):
        for argument in argv[1:]:
            if argument.startswith(('--primary=', '--secondary=', '--output_dir=', '--config=')):
                if not Path(argument.split('=', 1)[1]).resolve().is_relative_to(temporary):
                    refuse(event, argv)
        children.append({'kind': 'exact authored fake BinDiff script, mode ok', 'argv': argv, 'cwd': str(cwd),
                         'script_sha256': hashlib.sha256(fake_bytes).hexdigest()})
        return
    if not actual or Path(actual).resolve() != git_binary:
        refuse(event, {'argv': argv, 'cwd': str(cwd)})
    remaining = argv[1:]
    while remaining and remaining[0] in {'--no-replace-objects', '-C', '-c'}:
        option, remaining = remaining[0], remaining[1:]
        if option == '--no-replace-objects':
            continue
        if not remaining:
            refuse(event, argv)
        value, remaining = remaining[0], remaining[1:]
        if option == '-C':
            cwd = (cwd / value).resolve()
        if option == '-c' and not value.startswith(('user.name=', 'user.email=')):
            refuse(event, argv)
    if not cwd.is_relative_to(temporary) or not remaining or remaining[0] not in {
        'init', 'config', 'add', 'commit', 'rev-parse', 'show', 'ls-tree', 'cat-file', 'update-index',
        'update-ref', 'reset', 'replace'}:
        refuse(event, argv)
    if remaining[0] == 'update-ref' and not (
            len(remaining) == 3 and remaining[1] == 'HEAD' and len(remaining[2]) == 40
            and all(c in '0123456789abcdef' for c in remaining[2])):
        refuse(event, argv)
    environment = env if env is not None else os.environ
    if environment.get('GIT_ALLOW_PROTOCOL') != 'file':
        refuse(event, 'Git file-only protocol boundary missing')
    if len(children) >= 2500:
        refuse(event, 'bounded local Git call allowance exhausted')
    children.append({'argv': argv, 'cwd': str(cwd), 'environment': {key: environment.get(key) for key in
        ('GIT_ALLOW_PROTOCOL', 'GIT_CONFIG_GLOBAL', 'GIT_CONFIG_NOSYSTEM', 'GIT_NO_REPLACE_OBJECTS')}})


arguments = ['-q', '-p', 'no:cacheprovider', '--basetemp', str(temporary / 'pytest'), *files,
             f'--junitxml={QA}/{LABEL}.xml']
if LABEL in {'red', 'green', 'green-v2'}:
    arguments += ['-k', 'host_text_newlines or host_git_normalization or windows_relative_inventory']
command = {'source_commit': SOURCE, 'cwd': str(ROOT), 'python': sys.version,
           'argv': [sys.executable, str(Path(__file__).resolve()), SOURCE, LABEL],
           'pytest_arguments': arguments, 'source_files': snapshots,
           'runner_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'scope': 'authored fixtures/local Git/injected builder; affected gate adds exact reviewed Python probes only',
           'authored_python_constants': sorted(constant_children),
           'authored_fake_sha256': hashlib.sha256(fake_bytes).hexdigest() if fake_bytes else None,
           'environment': {key: os.environ[key] for key in ('PYTHONPATH', 'PYTHONDONTWRITEBYTECODE',
               'GIT_NO_REPLACE_OBJECTS', 'GIT_ALLOW_PROTOCOL', 'GIT_CONFIG_GLOBAL', 'GIT_CONFIG_NOSYSTEM',
               'QT_QPA_PLATFORM', 'TMPDIR', 'PYTEST_DISABLE_PLUGIN_AUTOLOAD')}}
(QA / f'{LABEL}.command.json').write_text(json.dumps(command, indent=2) + '\n')
(QA / f'{LABEL}-runner.py').write_bytes(Path(__file__).read_bytes())
started = time.monotonic()
sys.addaudithook(audit)
with (QA / f'{LABEL}.log').open('x', encoding='utf-8', newline='\n') as output:
    prior = sys.stdout, sys.stderr
    sys.stdout = sys.stderr = output
    try:
        outcome = int(pytest.main(arguments))
    finally:
        sys.stdout, sys.stderr = prior
modules, drift = [], []
for name, module in sorted(sys.modules.items()):
    if not (name.startswith('patchtrace') or name == 'tools' or name.startswith('tools.')):
        continue
    if not getattr(module, '__file__', None):
        continue
    path = Path(module.__file__).resolve()
    row = {'module': name, 'path': str(path)}
    if not path.is_relative_to(ROOT):
        drift.append(name)
    else:
        data = path.read_bytes()
        relative = path.relative_to(ROOT).as_posix()
        blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        row.update(relative_path=relative, sha256=hashlib.sha256(data).hexdigest(),
                   git_blob=blob, expected_git_blob=blobs.get(relative))
        if blob != blobs.get(relative):
            drift.append(name)
    modules.append(row)
for row in snapshots:
    if hashlib.sha256((ROOT / row['path']).read_bytes()).hexdigest() != row['sha256']:
        drift.append(row['path'])
fixtures = []
for path in sorted(temporary.rglob('*')):
    if path.is_file() and path.name in {'sample.txt', 'README', 'example.py', 'bootstrap-pip.txt',
                                       'audit-requirements.txt', 'authored.gitconfig', 'host-text.txt'}:
        data = path.read_bytes()
        assert len(data) <= 65536
        fixtures.append({'path': str(path.relative_to(temporary)), 'bytes': len(data),
                         'sha256': hashlib.sha256(data).hexdigest(), 'hex': data.hex()})
(QA / f'{LABEL}.fixtures.json').write_text(json.dumps(fixtures, indent=2) + '\n')
(QA / f'{LABEL}.imports.json').write_text(json.dumps({'source_commit': SOURCE, 'modules': modules,
                                                   'drift': drift}, indent=2) + '\n')
code = outcome if not drift and not denied else 97
result = {'source_commit': SOURCE, 'pytest_exit': outcome, 'exit_code': code,
          'seconds': time.monotonic() - started, 'project_tool_imports': len(modules),
          'drift': drift, 'denied_attempts': denied, 'reviewed_children': children,
          'native_or_engine_children': 0, 'network_attempts': 0}
(QA / f'{LABEL}.exit.json').write_text(json.dumps(result, indent=2) + '\n')
print((QA / f'{LABEL}.log').read_text()[-4500:])
print(json.dumps({key: value for key, value in result.items() if key != 'reviewed_children'}))
shutil.rmtree(temporary)  # Only the completed owned authored-fixture tree, after byte receipts.
raise SystemExit(code)
