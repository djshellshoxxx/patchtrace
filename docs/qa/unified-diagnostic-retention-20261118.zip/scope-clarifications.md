Append to the sealed read-only design; the original proposal/archive is unchanged.

Root approved implementation from 52a562b6f4c8063b7cb47b31c3942f55db7fa5f5, using the retained security-residual-qa checkout and a new branch. The original 0201 branch remains. Ownership is only tools/live_unified_check.py, the new focused tests, SPEC-31 extraction subsection, existing module row and QA. The existing schema.open_readonly performs initial SQL before a caller can install progress handling: the step limit applies only after it returns; bounded 4 MiB snapshots and cooperative checks surround that call. Diagnostic reporting must itself be best effort and bounded, so stderr/write failure cannot change acceptance or mask the original operation. The original two-red/one-positive probe remains byte-identical and must replay with fresh observation directories. No digest, source engine, workflow, native, DLL/GZF or frozen outcome changes.

## Final reporting boundary (append only)

The first implementation protected all reporter BaseExceptions. Its 326-pass
affected receipt at e3f07f76 remains historical, along with the separate two-red,
four-positive boundary probe and six-red, 35-positive spec-first extension.
Final source adab5118 records whether a caller exception is already active at
capture entry, before any diagnostic work. Only that explicit local Boolean
shields the caller's original failure against a secondary reporter BaseException.
An internal diagnostic stop, metadata refusal or publication failure cannot
create a shield. Fresh KeyboardInterrupt and SystemExit from the reporter
therefore propagate after ordinary capture or internal diagnostic refusal.
Ordinary reporter Exceptions remain harmless. No exception object or protection
state is stored globally or retained after capture. The existing active-primary
tests remain unchanged; seven added cases distinguish the two boundaries.

## Cooperative file boundary (append only)

The specification already excludes arbitrary same-user namespace immunity.
The reader checks lstat before a normal path open; it does not bind that check
atomically to opening, so a concurrent replacement between those operations is
outside this slice's cooperative private-work claim. Root explicitly disposed
that question as out of scope after reading the full subsection, without asking
for a broader reader API or claiming hostile-namespace protection. Stable
symlinks, directories and FIFOs are covered: the latter two controls instrument
opening to prove refusal before it is attempted, avoiding any blocking FIFO
operation. No native or namespace-race qualification is inferred from them.

The deadline is cooperative and does not preempt blocked OS I/O. The 2M SQLite
VM-step allowance starts only after schema.open_readonly returns. The 4 MiB
snapshot and checks surrounding that helper apply before then. The tool's
preexisting full JSONL read is unchanged and outside the diagnostic reader's
new limits. The final 333-case gate and six external controls establish the
documented portable boundaries only.
