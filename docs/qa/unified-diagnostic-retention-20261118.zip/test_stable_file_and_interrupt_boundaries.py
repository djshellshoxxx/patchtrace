"""Read-only review controls for the stable private-file and reporter interrupt boundary."""
from __future__ import annotations

import os
from pathlib import Path
from types import SimpleNamespace

import pytest
import test_unified_live_diagnostics as owner


@pytest.fixture
def case(tmp_path):
    tool = owner.load_tool()
    work, out = tmp_path / 'work', tmp_path / 'out'
    work.mkdir()
    out.mkdir()
    side = SimpleNamespace(label='older', sha256=owner.SHA, other_sha256='12' * 32, work=work)
    result = owner.build_result(work)
    return tool, work, out, side, result


@pytest.mark.parametrize('kind', ['directory', 'fifo'])
def test_stable_nonregular_source_is_refused_before_open(case, monkeypatch, kind):
    tool, work, out, side, result = case
    target = result['directory'] / owner.schema.DB_NAME
    backup = target.with_suffix('.original')
    target.rename(backup)
    if kind == 'directory':
        target.mkdir()
    else:
        if not hasattr(os, 'mkfifo'):
            pytest.skip('this portable host has no FIFO creation API')
        os.mkfifo(target)
    original = Path.open
    attempted = []

    def refuse_target_open(path, *args, **kwargs):
        if path == target:
            attempted.append(path)
            raise AssertionError('a stable nonregular source must not be opened')
        return original(path, *args, **kwargs)

    monkeypatch.setattr(Path, 'open', refuse_target_open)
    tool._RunDiagnostics(out, work, 'stable-type').capture(side, 1, result)
    doc = owner.documents(out)[0][1]
    assert doc['ir']['reason'] == 'nonregular' and doc['ir']['retained_bytes'] == 0
    assert not attempted and backup.is_file() and target.exists()


@pytest.mark.parametrize('kind', [KeyboardInterrupt, SystemExit])
def test_fresh_interrupt_from_capture_read_propagates_unchanged(case, monkeypatch, kind):
    tool, work, out, side, result = case
    target = result['directory'] / owner.schema.DB_NAME
    original = Path.open
    stop = kind('authored read interrupt')

    def interrupt_read(path, *args, **kwargs):
        if path == target:
            raise stop
        return original(path, *args, **kwargs)

    monkeypatch.setattr(Path, 'open', interrupt_read)
    with pytest.raises(kind) as caught:
        tool._RunDiagnostics(out, work, 'read-interrupt').capture(side, 1, result)
    assert caught.value is stop and not list(out.iterdir())


@pytest.mark.parametrize('kind', [KeyboardInterrupt, SystemExit])
def test_fresh_reporter_interrupt_should_propagate_without_a_primary(case, monkeypatch, kind):
    tool, _work, _out, _side, _result = case
    stop = kind('authored fresh sink interrupt')

    class Sink:
        def write(self, _value):
            raise stop

    monkeypatch.setattr(tool.sys, 'stderr', Sink())
    with pytest.raises(kind) as caught:
        tool._diagnostic_report('saved', 'authored.json')
    assert caught.value is stop
