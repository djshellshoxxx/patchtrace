"""Seal existing authored receipts; do not rerun tests or mutate product source."""
from __future__ import annotations

import base64
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

ROOT = Path('/workspace/scratch/c7a9e8d98848')
REPO = ROOT / 'security-residual-qa'
HERE = Path(__file__).resolve().parent
DESIGN = ROOT / 'qa/unified-diagnostic-retention-design'
BASE = '52a562b6f4c8063b7cb47b31c3942f55db7fa5f5'
SOURCE = 'adab5118264011ed2da0a664b198a1288391c25f'
CHAIN = [
    'abb201de7c6653eb2d33464800090da54f4275fe',
    '86aa905ab86881624aea4b690c112b2ec9b1d7be',
    '18afb550134c83b7605ed5257710e18da2c07fa8',
    'e3f07f76f564b37a8bf9c410a4474b160918fba7',
    '61e5eab3d19cfa8b23ab47a2fe75bc31bbae1e0c',
    SOURCE,
]
OWNED = [
    'docs/modules.md',
    'docs/specs/unified-engine/03-extraction.md',
    'tests/test_unified_live_diagnostics.py',
    'tools/live_unified_check.py',
]
NEIGHBORS = [
    '.github/workflows/live-unified.yml',
    'src/patchtrace/unified/ir/schema.py',
    'src/patchtrace/unified/ir/ingest.py',
    'src/patchtrace/unified/limits.py',
    'tests/test_unified_live_tool.py',
    'tests/test_unified_live_workflow.py',
    'tests/test_unified_ir_ingest.py',
    'tests/test_unified_extract_runner.py',
    'tests/test_unified_packaging.py',
    'tests/test_spec_registry.py',
    'tests/unified_extract_builder.py',
]
EXPECTED_PHASES = {
    'spec-red': (CHAIN[0], 27, 1),
    'focused-initial': (CHAIN[1], 0, 28),
    'receipt-red': (CHAIN[2], 2, 32),
    'focused-final': (CHAIN[3], 0, 34),
    'affected-final': (CHAIN[3], 0, 326),
    'boundary-red': (CHAIN[3], 2, 4),
    'interrupt-red': (CHAIN[4], 6, 35),
    'focused-interrupt-green': (SOURCE, 0, 41),
    'boundary-green': (SOURCE, 0, 6),
    'affected-interrupt-green': (SOURCE, 0, 333),
}
PROBE_SHA = '8f5d054cdca97976ef6c8f663c159d061ff1926ed1a1e5067fe797e66e9f3bd2'
DESIGN_SHA = '07570484efe7aa948fa7bc3fe587e7c115795cbb238c44623c54ed4f3fc77bd5'
STEM = 'unified-diagnostic-retention-20261118'


def git(*args: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def put(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == data, f'refusing replacement of {path}'
    else:
        with path.open('xb') as stream:
            stream.write(data)


def dump(path: Path, value) -> None:
    put(path, (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode('utf-8'))


def counts(data: bytes) -> dict:
    cases = list(ET.fromstring(data).iter('testcase'))
    return {
        'tests': len(cases),
        'failures': sum(c.find('failure') is not None for c in cases),
        'errors': sum(c.find('error') is not None for c in cases),
        'skips': sum(c.find('skipped') is not None for c in cases),
    }


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('status', '--porcelain')
assert git('diff', '--name-only', BASE, SOURCE).decode().splitlines() == OWNED
assert sha((DESIGN / 'test_retention_boundary.py').read_bytes()) == PROBE_SHA
assert sha((DESIGN / 'evidence.zip').read_bytes()) == DESIGN_SHA

copy_ledger = []


def preserve(original: Path, relative: str) -> None:
    data = original.read_bytes()
    put(HERE / relative, data)
    copy_ledger.append({'original': str(original), 'path': relative,
                        'bytes': len(data), 'sha256': sha(data)})


for name in ('evidence.zip', 'manifest.json', 'test_retention_boundary.py',
             'proposal.md', 'source-provenance.json', 'red.log', 'red.xml',
             'command.json', 'exit.json', 'imports.json'):
    preserve(DESIGN / name, 'original-design/' + name)

original_manifest = json.loads((DESIGN / 'manifest.json').read_bytes())
with zipfile.ZipFile(DESIGN / 'evidence.zip') as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == 37
    assert set(archive.namelist()) == {p['path'] for p in original_manifest['payloads']}
    for item in original_manifest['payloads']:
        data = archive.read(item['path'])
        assert len(data) == item['bytes'] and sha(data) == item['sha256']
        assert data == (DESIGN / item['path']).read_bytes()
assert counts((DESIGN / 'red.xml').read_bytes()) == {
    'tests': 3, 'failures': 2, 'errors': 0, 'skips': 0,
}

for original, destination in [
    ('ops/project_and_tools_receipt.py', 'support/project_and_tools_receipt.py'),
    ('ops/continuation_offline_pytest.py', 'support/continuation_offline_pytest.py'),
    ('qa/full-batch-path-recheck/offline_replay.py', 'support/offline_replay.py'),
    ('qa/hosted-pr316-771e-gates-refresh/artifacts/artifact-14477506098.verified.json',
     'hosted/artifact-14477506098.verified.json'),
    ('qa/hosted-pr316-771e-gates-refresh/log-windows-unified.log', 'hosted/windows.log'),
    ('qa/hosted-pr316-771e-gates-refresh/text/14477506098/live-out/live-unified-ci-pair-windows.json',
     'hosted/live-unified-ci-pair-windows.json'),
    ('qa/hosted-pr316-771e-gates-refresh/text/14477506098/live-out/live-unified-probe-pair-windows.json',
     'hosted/live-unified-probe-pair-windows.json'),
    ('qa/core-admission-root-review/hosted-771e-verification.json',
     'hosted/source-verification.json'),
]:
    preserve(ROOT / original, destination)

snapshots = []
snapshot_keys = set()


def snapshot(commit: str, path: str) -> None:
    if (commit, path) in snapshot_keys:
        return
    data = git('show', commit + ':' + path)
    name = 'canonical/' + commit + '/' + path
    put(HERE / name, data)
    snapshots.append({'commit': commit, 'source_path': path, 'path': name,
                      'blob': git('rev-parse', commit + ':' + path).decode().strip(),
                      'bytes': len(data), 'sha256': sha(data)})
    snapshot_keys.add((commit, path))


for path in OWNED:
    if path != 'tests/test_unified_live_diagnostics.py':
        snapshot(BASE, path)
    snapshot(SOURCE, path)
for path in NEIGHBORS:
    snapshot(SOURCE, path)
chain_rows = []
parent = BASE
for commit in CHAIN:
    assert git('rev-parse', commit + '^').decode().strip() == parent
    changed = git('diff', '--name-only', parent, commit).decode().splitlines()
    assert set(changed) <= set(OWNED)
    for path in changed:
        snapshot(commit, path)
    patch_path = 'changes/' + commit + '.patch'
    put(HERE / patch_path, git('diff', '--binary', parent, commit, '--', *OWNED))
    chain_rows.append({'commit': commit, 'parent': parent,
                       'tree': git('rev-parse', commit + '^{tree}').decode().strip(),
                       'subject': git('show', '-s', '--format=%s', commit).decode().strip(),
                       'changed_paths': changed, 'patch': patch_path})
    parent = commit
dump(HERE / 'source-chain.json', {'base': BASE, 'source': SOURCE,
                                'chain': chain_rows, 'snapshots': snapshots})

rechecked = []
cache = {}
for phase, (commit, failures, passed) in EXPECTED_PHASES.items():
    folder = HERE / phase
    result = json.loads((folder / 'exit.json').read_bytes())
    command = json.loads((folder / 'command.json').read_bytes())
    imported = json.loads((folder / 'imports.json').read_bytes())
    offline = json.loads((folder / 'offline.json').read_bytes())
    tally = counts((folder / 'result.xml').read_bytes())
    assert tally == {'tests': failures + passed, 'failures': failures, 'errors': 0, 'skips': 0}
    assert tally == result['counts']
    assert result['source'] == command['source'] == commit
    assert result['exit'] == (1 if failures else 0)
    assert not result['drift'] and not result['dirty_after'] and result['probe_unchanged']
    assert command['probe_sha256'] == PROBE_SHA
    assert not offline['network_audit_event_counts']
    assert offline['process_audit_count'] == (34 if phase.startswith('affected') else 0)
    assert offline['filter_source_sha256'] == sha((HERE / 'support/offline_replay.py').read_bytes())
    assert len(imported['final_sources']) == result['imports']
    assert len(imported['nodeids']) == tally['tests']
    for name, item in imported['final_sources'].items():
        relative = Path(item['path']).relative_to(REPO).as_posix()
        key = (commit, relative)
        if key not in cache:
            cache[key] = sha(git('show', commit + ':' + relative))
        assert cache[key] == item['sha256'], (phase, name)
    assert command['tool_sha256'] == sha(git('show', commit + ':tools/live_unified_check.py'))
    if 'test_sha256' in command:
        assert command['test_sha256'] == sha(git('show', commit + ':tests/test_unified_live_diagnostics.py'))
    runner = HERE / ('run_boundary.py' if phase.startswith('boundary') else 'run_gate.py')
    assert command['runner_sha256'] == sha(runner.read_bytes())
    rechecked.append({'phase': phase, 'source': commit, 'counts': tally,
                      'imports': result['imports'], 'process_events': offline['process_audit_count'],
                      'network_events': offline['network_audit_event_counts'],
                      'owned_temp': result['owned_temp'], 'original_probe_unchanged': True})

tmp = Path(json.loads((HERE / 'affected-interrupt-green/exit.json').read_bytes())['owned_temp']) / 'pytest'
example_rows = []
for fixture in ('test_l1_failure_retains_actual0', 'test_first_run_evidence_surviv0',
                'test_unchanged_authored_gate_p0'):
    for original in sorted((tmp / fixture / 'public-output').glob('*.json')):
        relative = 'examples/' + fixture + '/' + original.name
        preserve(original, relative)
        doc = json.loads(original.read_bytes())
        item = {'path': relative, 'bytes': original.stat().st_size, 'sha256': sha(original.read_bytes())}
        if original.name.startswith('live-unified-diagnostics-'):
            assert doc['contract'] == 'live-unified-diagnostics/1'
            for key in ('jsonl', 'ir'):
                part = doc[key]
                assert part['status'] == 'complete'
                data = base64.b64decode(part['data_base64'], validate=True)
                assert len(data) == part['bytes'] and sha(data) == part['sha256']
            item.update(side=doc['side'], ordinal=doc['analyze_ordinal'], complete=doc['complete'])
        example_rows.append(item)
assert len(example_rows) == 11
dump(HERE / 'examples.json', example_rows)
dump(HERE / 'copied-originals.json', copy_ledger)
dump(HERE / 'receipt-verification.json', {
    'source': SOURCE, 'base': BASE, 'canonical_snapshot_count': len(snapshots),
    'phase_count': len(rechecked), 'phases': rechecked,
    'canonical_import_source_pairs_rechecked': len(cache),
    'original_design_payloads_verified': 37, 'original_design_sha256': DESIGN_SHA,
    'original_design_counts': counts((DESIGN / 'red.xml').read_bytes()),
    'original_probe_sha256': PROBE_SHA,
    'copied_original_count': len(copy_ledger), 'example_files': len(example_rows),
    'limit': 'Source-specific authored/offline verification only; no native or namespace-race qualification.',
})

excluded = {'evidence.zip', 'manifest.json', 'seal-verification.json'}
payload_paths = sorted(p for p in HERE.rglob('*') if p.is_file() and
                       not (p.parent == HERE and p.name in excluded))
payloads = []
archive_path = HERE / 'evidence.zip'
assert not archive_path.exists()
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in payload_paths:
        relative = path.relative_to(HERE).as_posix()
        data = path.read_bytes()
        info = zipfile.ZipInfo(relative, (2026, 11, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, data)
        payloads.append({'path': relative, 'bytes': len(data), 'sha256': sha(data)})
archive_data = archive_path.read_bytes()
with zipfile.ZipFile(archive_path) as archive:
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(payloads)
    assert archive.testzip() is None
    for item in payloads:
        data = archive.read(item['path'])
        assert len(data) == item['bytes'] and sha(data) == item['sha256']

manifest = {
    'source_commit': SOURCE, 'base_commit': BASE, 'source_chain': CHAIN,
    'archive': STEM + '.zip', 'archive_sha256': sha(archive_data),
    'archive_bytes': len(archive_data), 'payload_count': len(payloads),
    'uncompressed_bytes': sum(item['bytes'] for item in payloads), 'payloads': payloads,
}
dump(HERE / 'manifest.json', manifest)
tracked = REPO / 'docs/qa'
put(tracked / (STEM + '.md'), (HERE / 'README.md').read_bytes())
put(tracked / (STEM + '.zip'), archive_data)
put(tracked / (STEM + '.manifest.json'), (HERE / 'manifest.json').read_bytes())
dump(HERE / 'seal-verification.json', {
    'source': SOURCE, 'payload_count': len(payloads), 'archive_sha256': sha(archive_data),
    'archive_bytes': len(archive_data), 'canonical_snapshots_verified': len(snapshots),
    'original_probe_unchanged': sha((DESIGN / 'test_retention_boundary.py').read_bytes()) == PROBE_SHA,
    'original_design_unchanged': sha((DESIGN / 'evidence.zip').read_bytes()) == DESIGN_SHA,
    'tracked_copies_equal': True,
})
print(json.dumps({key: value for key, value in manifest.items() if key != 'payloads'}, indent=2))
