"""Authored IR only: actual live-tool checks/cleanup, no native producer or target execution."""
from __future__ import annotations

import importlib.util
import json
import os
import socket
import subprocess
from pathlib import Path

import pytest
from unified_extract_builder import document_set, function, pe_view, write_jsonl

from patchtrace.unified.ir import schema
from patchtrace.unified.ir.ingest import ExpectedSide, ingest

ROOT = Path('/workspace/scratch/c7a9e8d98848/security-residual-qa')


def setup_tool(tmp_path, monkeypatch, case):
    spec = importlib.util.spec_from_file_location('review_live_tool', ROOT / 'tools/live_unified_check.py')
    tool = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(tool)
    work = tmp_path / 'owned-private-work'
    work.mkdir()
    out = tmp_path / 'public-output'
    observations = []
    closed = []

    def forbidden(*_args, **_kwargs):
        pytest.fail('This authored control must not execute a child or access the network')

    monkeypatch.setattr(subprocess, 'Popen', forbidden)
    monkeypatch.setattr(socket, 'create_connection', forbidden)
    monkeypatch.setattr(socket.socket, 'connect', forbidden)
    monkeypatch.setattr(tool.tempfile, 'mkdtemp', lambda **_kwargs: str(work))
    monkeypatch.setattr(tool.runner, 'self_check', lambda _backend: {'ok': True})

    class AuthoredSide(tool.Side):
        def __init__(self, label, dll, other_sha256, backend, work):
            self.label, self.dll, self.backend, self.work = label, dll, backend, work
            self.sha256, self.other_sha256 = tool.file_sha256(dll), other_sha256
            self.pe = pe_view()
            self.counter = 0

        def close(self):
            closed.append(self.label)

        def run(self, mode, gzf=None, gzf_sha256=None):
            self.counter += 1
            if case == 'later-failure' and self.label == 'older' and self.counter == 2:
                raise RuntimeError('authored second extraction stop')
            changed = case == 'different' and self.label == 'newer' and self.counter == 2
            alias = 'only-in-second' if changed else 'first-run-alias'
            record = function(0x1000, [('ret',)], name='same-name', aliases=(alias,))
            raw = write_jsonl(self.work / f'{self.label}-{self.counter}.jsonl',
                              document_set(record, sha=self.sha256, mode=mode))
            destination = self.work / f'{self.label}-{self.counter}-ir'
            destination.mkdir()
            result = ingest(raw, ExpectedSide(self.label, self.sha256, self.pe, mode=mode),
                            out_dir=destination)
            packed = None
            if mode == 'analyze':
                packed = self.work / f'{self.label}-{self.counter}.gzf'
                packed.write_bytes(b'authored placeholder, never parsed or executed')
            db = schema.open_readonly(destination / schema.DB_NAME)
            try:
                rows = {table: list(schema.table_rows(db, table)) for table in schema.TABLES}
            finally:
                db.close()
            observations.append({'side': self.label, 'ordinal': self.counter, 'mode': mode,
                                 'manifest': result.manifest.model_dump(mode='json'), 'rows': rows,
                                 'six_column_summary': self.function_rows(destination)})
            return {'mode': mode, 'manifest': result.manifest, 'directory': destination,
                    'jsonl': raw.read_bytes(), 'gzf': packed,
                    'probe': dict.fromkeys(('ghidra', 'pyghidra', 'java', 'python'), 'authored'),
                    'extract_seconds': 0.0, 'ingest_seconds': 0.0, 'stderr_tail': ''}

    monkeypatch.setattr(tool, 'Side', AuthoredSide)
    old, new = tmp_path / 'older.data', tmp_path / 'newer.data'
    old.write_bytes(b'authored older input, not a PE')
    new.write_bytes(b'authored newer input, not a PE')
    args = ['--old', str(old), '--new', str(new), '--ghidra-dir', str(tmp_path), '--out', str(out),
            '--tag', case, '--no-hashers', '--no-ghidriff']

    def save_observation():
        target = Path(os.environ['PATCHTRACE_LIVE_REVIEW_OUTPUT']) / f'{case}.json'
        target.write_text(json.dumps({'runs': observations, 'private_work_removed': not work.exists(),
                                      'closed': closed, 'public_files': sorted(p.name for p in out.glob('*.json'))},
                                     sort_keys=True, indent=2) + '\n', encoding='utf-8')

    return tool, args, out, work, observations, closed, save_observation


def test_l1_failure_retains_actual_second_run_after_cleanup(tmp_path, monkeypatch):
    tool, args, out, work, runs, closed, save = setup_tool(tmp_path, monkeypatch, 'different')
    assert tool.main(args) == 1
    assert not work.exists() and sorted(closed) == ['newer', 'older']
    first, second = [r for r in runs if r['side'] == 'newer' and r['mode'] == 'analyze']
    assert first['manifest']['ir_key'] == second['manifest']['ir_key']
    assert first['manifest']['counts'] == second['manifest']['counts']
    assert first['six_column_summary'] == second['six_column_summary']
    assert first['manifest']['content_digest'] != second['manifest']['content_digest']
    save()
    retained = '\n'.join(p.read_text(encoding='utf-8') for p in out.glob('*.json'))
    assert second['manifest']['content_digest'] in retained and 'only-in-second' in retained


def test_first_run_evidence_survives_a_later_extraction_error(tmp_path, monkeypatch):
    tool, args, out, work, runs, closed, save = setup_tool(tmp_path, monkeypatch, 'later-failure')
    with pytest.raises(RuntimeError, match='authored second extraction stop'):
        tool.main(args)
    assert not work.exists() and sorted(closed) == ['newer', 'older']
    assert len(runs) == 1
    save()
    retained = '\n'.join(p.read_text(encoding='utf-8') for p in out.glob('*.json'))
    assert runs[0]['manifest']['content_digest'] in retained and 'first-run-alias' in retained


def test_unchanged_authored_gate_passes_and_cleans_owned_work(tmp_path, monkeypatch):
    tool, args, out, work, runs, closed, save = setup_tool(tmp_path, monkeypatch, 'equal')
    assert tool.main(args) == 0
    assert not work.exists() and sorted(closed) == ['newer', 'older']
    summary = json.loads(next(out.glob('live-unified-equal-*.json')).read_text(encoding='utf-8'))
    for side in ('older', 'newer'):
        analyzed = [r for r in runs if r['side'] == side and r['mode'] == 'analyze']
        assert len(analyzed) == 2
        assert analyzed[0]['manifest']['content_digest'] == analyzed[1]['manifest']['content_digest']
        assert summary['sides'][side]['content_digest'] == analyzed[0]['manifest']['content_digest']
    save()
