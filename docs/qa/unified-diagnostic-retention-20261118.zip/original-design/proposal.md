# Bounded retention of the two L1 analysis runs

Status: read-only proposal, with portable red controls. No production, workflow, engine, digest, fixture or outcome change has been made.

## 1. Exact authority and finding

The observed hosted source is public commit `771e5a775f5bf60a8d9094232b51dcdbb47d6389`, tree `ddf151c6ff8fb3f70b74378525fe1d8d5c9050e3`. That tree is available locally through the equal-tree publication checkpoint `361dd495a7e050121f2b3cae4e7678faad7fee35`; the public commit object itself is not available in this checkout. Root verified the public/preview source delivery in `qa/core-admission-root-review/hosted-771e-verification.json`. This review reads the available exact tree, rather than attributing a newer private commit to the hosted job.

`tools/live_unified_check.py` at that tree is blob `e47ee177e0eb5541273a943eb38bb39c98ed09c8`, SHA-256 `1c84fce3e63208dd926fafe5c55e119de215bd216e29438a9825f543ad933e94`. It is byte-identical in the portable control checkout at `0201a4c8a1ab715af8136d166bc29eb2985d13c7`. The workflow, IR schema/ingest, extraction spec and existing live-tool tests also match the hosted tree. The portable runner records every imported project module against 0201 separately; this is not a claim that every inactive imported core file equals the older hosted tree.

Actual Windows evidence is root-owned under `qa/hosted-pr316-771e-gates-refresh`: run 44409973392, job 135175184056, artifact 14477506098. The verified archive contains the four DLLs and two 4,562-byte summaries. The probe newer side reports first digest `a658ef9f00c21c74bac115a68414f8188206258c051a9c3ea9c484e0d0e65c0c`; the retained log reports second digest `b7dc355b73b3482f82fff8c81ba8d32e51e285a357dc39ba96ba0f6bcf3bf936`. The IR key is equal. No second-run records or IR are retained. The observed GZF/Ghidriff comparisons agree with the first run. These observations do not identify why the second analysis differs.

Source boundaries:

| Current boundary | Result |
| --- | --- |
| `Side.run`, lines 313–340 | Reads extractor JSONL, ingests a private IR, returns their data/paths, then removes the extractor-owned output. |
| `check_side`, lines 355–400 | Runs analyze twice and compares both digests, but publishes/returns only the first result. |
| `Side.function_rows`, lines 342–348 | Keeps only rva, h0, h3, hm, flags and name; aliases and other function fields are absent. |
| `schema.table_rows/content_digest`, lines 170–192 | The canonical digest covers eight tables, including decompressed instruction/text payload hashes; six function fields cannot explain all differences. |
| `main`, lines 495–534 | Writes the summary only after later checks complete; `finally` removes private work, including both IRs. |
| Workflow lines 61–65 and 95–99 | Uploads top-level `live-out/*.json` even on failure. Cross-OS consumers name the existing summary explicitly. |

## 2. Preserved portable evidence

`test_retention_boundary.py` substitutes only the producer/side acquisition and native self-check. It uses the actual ingest, `check_side`, `main`, JSON summary writer and work cleanup. The source inputs and GZF placeholders are authored data and are never executed or parsed by a native tool. Child creation and socket connections are refused by the test.

Exact result: **2 failed, 1 passed in 0.51 s**, 55 canonical project imports, no source drift or dirty checkout. `red.log`, `red.xml`, `command.json`, `imports.json`, `exit.json` and all observations are retained unchanged.

1. An alias-only second-run change leaves counts, IR key and the existing six-field function projection equal, while actual ingestion produces different content digests. The L1 assertion correctly fails and exits 1. After cleanup, the second digest and alias are absent from all retained JSON.
2. A deliberate second-extraction exception occurs after the first IR was successfully ingested. The original exception propagates and work is removed, but no JSON retains the first result.
3. Equal authored runs pass the existing gate and close/remove owned work.

These are tool lifecycle controls. They do not reproduce Ghidra nondeterminism or qualify native Windows/Linux behavior. The actual hosted failure remains failed, and its missing records cannot be recovered by this change.

## 3. Proposed smallest source scope

Own only:

- `tools/live_unified_check.py`: one bounded diagnostic writer, its fixed limits, invocation context, and two calls immediately after the first and second successful analyze returns. Keep the existing result shape and return value.
- `tests/test_unified_live_diagnostics.py`: new portable integration/boundary controls; extend an existing live-tool test only if needed for unchanged summary behavior.
- `docs/specs/unified-engine/03-extraction.md`: an explicit diagnostic-retention subsection and named acceptance tests.
- The existing live acceptance row in `docs/modules.md`, plus a small QA receipt.

No production `src/` edits, new extraction mode, source/ingest revision bump, digest algorithm, native process, workflow, CLI option, frozen fixture or outcome edits. No new module is necessary for this bounded first slice. If implementation cannot remain clear within this seam, request separate helper ownership before creating it.

## 4. Evidence format and ownership

Write one top-level `live-unified-diagnostics-<invocation UUID hex>-<older|newer>-analyze-<1|2>.json` for each completed L1 analyze result. The UUID is allocated once per main invocation. Fixed ASCII components come from the internal side/ordinal enumeration, never a producer path/name. Exclusive creation is mandatory; a collision preserves the existing file and is an explicit diagnostic write failure. There are at most four attempted diagnostic files per ordered pair. No automatic retry or quota refund follows a write failure. Repeated invocations in one output directory have separate names; the cap is per invocation, not a global retention policy for that directory.

Each envelope has a fixed contract/version and contains:

- Invocation, side and analyze ordinal; ordered older/newer artifact SHA-256 values; bounded tag/OS/runtime context; exact tool/source hashes where available; extractor script SHA-256.
- The full validated manifest, including IR key/content digest, producer/options/symbol identities, counts, limits and warnings. A locally reported CI identifier is context, not independent proof of hosted ownership; the workflow/source receipt must bind it externally.
- The complete `fn` column list and bounded rows from `schema.table_rows(connection, 'fn')`, not the existing six-field L5 projection. This is readable evidence, not a new canonicalization or acceptance rule.
- Exact extractor JSONL bytes and exact `ir.sqlite3` bytes, each base64 encoded, with decoded byte length and SHA-256. The copied IR must match the manifest's file hash. These preserve all table and instruction/text values without expanding/decompressing the entire database during capture. The SQLite byte hash is explicitly distinct from the canonical content digest.
- Actual row/record counts where determined, retained counts/bytes, per-component status and fixed reason, and overall completeness. A truncated projection is labeled as a prefix. An omitted binary payload has no fabricated observed hash or full-data claim.

Readers can decode the bounded IR snapshot and use the existing hardened schema reader/content-digest implementation to investigate all eight tables. That offline comparison is separate from the live gate. The tool must not recompute a replacement digest, change the existing L1 comparison, or assert that SQLite byte equality is canonical equality.

The exact IR bytes are first copied with a bounded read into a small exclusively owned snapshot under the current private work directory. Hash verification and fixed-schema count/projection queries use that same captured snapshot. This avoids binding row evidence to a later pathname reopen of a different original file. Native handles or target DLLs are not retained in these envelopes. No GZF, environment, credentials or unrestricted stderr dump is added.

## 5. Explicit budgets

These are proposed new conservative limits, not measured production facts. MiB means 1,048,576 bytes; KiB means 1,024 bytes.

| Resource | One analyze run | One ordered pair / invocation |
| --- | ---: | ---: |
| Final encoded JSON diagnostic bytes | 12 MiB | 48 MiB, at most four files |
| Exact JSONL decoded bytes | 4 MiB | 16 MiB |
| JSONL records, including header/footer | 4,098 | 16,392 |
| Exact IR database decoded bytes | 4 MiB | 16 MiB |
| Sum of rows in the eight fixed IR tables | 32,768 | 131,072 |
| Readable full-column function rows | 4,096 | 16,384 |
| Encoded readable function projection | 512 KiB | 2 MiB |
| One encoded function row | 16 KiB | Same per-row limit |
| Encoded metadata and component statuses | 128 KiB | 512 KiB |
| Cooperative capture time | 2 seconds | 8 seconds |
| SQLite progress steps for metadata/count/projection | 2,000,000 | 8,000,000 |

The two 4 MiB binary payloads consume at most 10 2/3 MiB after base64 encoding. Metadata and the function projection fit below the 12 MiB envelope limit, but a final actual UTF-8 byte count independently enforces that limit. Row, metadata and envelope limits apply to encoded bytes, so Unicode does not bypass them. Serializers must stop when their budget is reached; do not construct an unbounded dump and only then test its length.

Read the IR source in bounded chunks, stopping after the 4 MiB limit plus one detection byte; reject nonregular/symlink sources and do not trust a size stat alone. The source JSONL is already in memory under the current tool's existing implementation; enforce its diagnostic byte/record cap before encoding it. This slice does not claim to repair that pre-existing full JSONL read. Query only the fixed IR tables with the existing read-only schema helper. Progress checks and the capture clock bound added computation cooperatively; blocking OS I/O is not given a hard preemptive deadline. Do not decompress instruction blobs during diagnostic capture.

All eight-table row totals must be known and within the cap before labeling the IR snapshot complete. Count/query timeout, malformed snapshot, hash mismatch or cap refusal cannot yield a complete component. A fixed small failure envelope remains possible within the metadata budget. If even it cannot be written, the console explicitly reports the capture/write failure; durable retention cannot be promised after a storage failure.

## 6. Save timing and failure semantics

Capture first immediately after `first = side.run('analyze')` returns, before starting the second analysis. Capture second immediately after its successful return, before L2, L3, L4, L5 or final summary publication. The files live in `args.out`, outside the work directory deleted in `main.finally`. No native retry is added.

Cap or parse/read failures produce bounded `omitted`, `truncated` or `error` component states with fixed reason labels. Preserve the metadata and any independently complete component that fits its quota. An envelope is complete only when its declared components are complete. Ordinary diagnostic errors are reported separately and never enter `Checks.failures`, change either digest, change the L1 PASS/FAIL result or turn the original exception into success. The existing acceptance exit status is preserved. Interrupts still propagate through normal cleanup.

Do not make a capture from a `finally` block that could mask an active extraction exception. Already completed captures survive later failures naturally. A write error preserves previously completed files and reports the attempted basename and bounded error category. A partially written file is not reported as saved/complete; retain it as failed-write evidence rather than deleting a possibly foreign replacement. No diagnostic failure grants additional cleanup authority. This is a cooperative private-workspace guarantee, not arbitrary same-user namespace-race immunity.

The legacy `live-unified-<tag>-<os>.json` summary remains compatible, so existing L6 and workflow consumers continue to name it. The added top-level JSON files match existing artifact upload globs. Missing/capped diagnostics are explicitly incomplete diagnostic evidence and do not relax or strengthen native acceptance in this slice.

## 7. Spec-first acceptance plan

Before source changes, commit the spec and meaningful red tests. Preserve the three external controls and the actual hosted failed receipt unchanged.

1. Replay the two omission controls with real authored ingestion and actual main/check-side cleanup; retain both manifests and the readable alias after work removal. Equal-run positive and original failure/exit behavior stay intact.
2. Add an instruction-text/non-function-table difference whose full function projection is equal. Decode both IR payloads, use the existing content-digest implementation, and prove each equals its own retained manifest while the digests differ. Exact JSONL bytes round-trip with their recorded hashes.
3. Exercise per-run and cumulative byte/row limits, exactly-at versus one-over boundaries, metadata/Unicode limits, oversized rows, and query/deadline refusal. Small injected internal limits keep fixtures bounded; the default numeric limits are separately pinned.
4. A source file that grows beyond its stat, a changed/hash-mismatched snapshot, malformed SQLite, and a nonregular source produce explicit incomplete evidence without changing L1. Verify reads are bounded and no decoder/native process executes the payload.
5. Repeated tags cannot overwrite previous captures. A forced filename collision preserves foreign bytes. A partial writer failure is observable, cannot claim complete retention, and does not erase earlier successful captures or mask a later primary error.
6. Check the unchanged cross-OS summary consumer, fixture recorder opt-in, L1/IR-key/L2/L5 semantics, and expected native call count. The portable gate must deny unexpected children/network and pin imports to the exact source under review.

Root reviews this proposal and assigns the implementation baseline before production edits. A later hosted run is needed to prove the new files are uploaded on Windows and to obtain the missing real first/second data. This repair itself does not resolve or reclassify the nondeterminism.
