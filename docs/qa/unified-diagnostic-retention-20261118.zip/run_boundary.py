from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET
from pathlib import Path

WORKSPACE = Path('/workspace/scratch/c7a9e8d98848')
REPO = WORKSPACE / 'security-residual-qa'
HERE = Path(__file__).resolve().parent
PHASE, SOURCE = sys.argv[1:]
OUT = HERE / PHASE
PROBE = WORKSPACE / 'qa/unified-diagnostic-retention-design/test_retention_boundary.py'
EXPECTED_PROBE = '8f5d054cdca97976ef6c8f663c159d061ff1926ed1a1e5067fe797e66e9f3bd2'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('status', '--porcelain')
assert sha(PROBE) == EXPECTED_PROBE
OUT.mkdir(exist_ok=False)
observations = OUT / 'observations'
observations.mkdir()
owned = Path(tempfile.mkdtemp(prefix='unified-diagnostic-' + PHASE + '-'))
nodes = [str(HERE / 'test_stable_file_and_interrupt_boundaries.py')]
if PHASE.startswith('affected'):
    nodes += ['tests/test_unified_live_tool.py', 'tests/test_unified_live_workflow.py',
              'tests/test_unified_ir_ingest.py', 'tests/test_unified_extract_runner.py',
              'tests/test_unified_packaging.py', 'tests/test_spec_registry.py']
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', QT_QPA_PLATFORM='offscreen',
           PYTHONPATH=os.pathsep.join(map(str, [REPO / 'src', REPO / 'tests', REPO, WORKSPACE / 'ops'])),
           GIT_ALLOW_PROTOCOL='file', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null',
           GIT_TERMINAL_PROMPT='0', PATCHTRACE_LIVE_REVIEW_OUTPUT=str(observations),
           PATCHTRACE_BATCH_COLLECTION_RECEIPT=str(OUT / 'imports.json'),
           PATCHTRACE_OFFLINE_GUARD_RECEIPT=str(OUT / 'offline.json'))
argv = [sys.executable, str(WORKSPACE / 'ops/continuation_offline_pytest.py'), '-q', '-ra',
        '-p', 'no:cacheprovider', '-p', 'project_and_tools_receipt', *nodes,
        '--basetemp=' + str(owned / 'pytest'), '--junitxml=' + str(OUT / 'result.xml')]
command = {'source': SOURCE, 'argv': argv, 'cwd': str(REPO), 'pythonpath': env['PYTHONPATH'],
           'probe_sha256': EXPECTED_PROBE, 'boundary_sha256': sha(HERE / 'test_stable_file_and_interrupt_boundaries.py'), 'owned_temp': str(owned), 'runner_sha256': sha(__file__),
           'tool_sha256': sha(REPO / 'tools/live_unified_check.py'),
           'test_sha256': sha(REPO / 'tests/test_unified_live_diagnostics.py'),
           'scope': 'Offline authored extraction data and real ingestion/tool lifecycle; no native acceptance.'}
(OUT / 'command.json').write_text(json.dumps(command, indent=2) + '\n')
start = time.monotonic()
with (OUT / 'result.log').open('x') as log:
    result = subprocess.run(argv, cwd=REPO, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
receipt = json.loads((OUT / 'imports.json').read_text())
drift = []
for name, item in receipt['final_sources'].items():
    path = Path(item['path'])
    try:
        relative = path.relative_to(REPO).as_posix()
    except ValueError:
        drift.append(name)
        continue
    data = git('show', SOURCE + ':' + relative)
    if data != path.read_bytes() or hashlib.sha256(data).hexdigest() != item['sha256']:
        drift.append(name)
cases = list(ET.parse(OUT / 'result.xml').getroot().iter('testcase'))
counts = {'tests': len(cases), 'failures': sum(c.find('failure') is not None for c in cases),
          'errors': sum(c.find('error') is not None for c in cases),
          'skips': sum(c.find('skipped') is not None for c in cases)}
status = git('status', '--porcelain').decode()
summary = {'source': SOURCE, 'exit': result.returncode, 'elapsed': time.monotonic() - start,
           'counts': counts, 'imports': len(receipt['final_sources']), 'drift': drift, 'dirty_after': status,
           'probe_unchanged': sha(PROBE) == EXPECTED_PROBE, 'owned_temp': str(owned)}
(OUT / 'exit.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
assert not drift and not status and summary['probe_unchanged']
raise SystemExit(result.returncode)
