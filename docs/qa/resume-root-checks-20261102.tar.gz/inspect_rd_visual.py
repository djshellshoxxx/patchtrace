"""Portable offscreen visual review of the exact paired-window UI source."""
from __future__ import annotations
import json
import sys
import tempfile
from pathlib import Path
from PySide6.QtCore import QSettings, QTimer
from PySide6.QtWidgets import QApplication
from patchtrace.service import ProjectService
from patchtrace.ui import MainWindow

out=Path('/workspace/scratch/142cb233d750/reviews-resume')
temporary=tempfile.TemporaryDirectory(); root=Path(temporary.name)
app=QApplication([])
window=MainWindow(ProjectService.sample(root/'project'),QSettings(str(root/'ui.ini'),QSettings.IniFormat))
window.resize(1440,960); window.show(); window.mode.setCurrentIndex(3)
phase=0; records=[]
def capture(name):
    controller=window.raw_alignment
    if controller.status.height() < controller.status.heightForWidth(controller.status.width()):
        raise RuntimeError('paired status text clipped')
    path=out/name
    if not window.grab().save(str(path)):
        raise RuntimeError('screenshot save failed')
    records.append({'image':str(path),'window':[window.width(),window.height()],'status':controller.status.text(),'status_bounds':[controller.status.width(),controller.status.height()],'required_height':controller.status.heightForWidth(controller.status.width())})
def step():
    global phase
    try:
        controller=window.raw_alignment
        if phase==0 and window._current_inspection() is not None:
            controller.toggle.setChecked(True); phase=1
        elif phase==1 and controller.result is not None:
            controller.offsets['older'].setText('200'); controller.offsets['newer'].setText('210'); controller.size.setValue(128); controller.request(); phase=2
        elif phase==2 and controller.result is not None:
            capture('rd-paired-wide.png'); window.resize(960,740); phase=3
        elif phase==3:
            capture('rd-paired-narrow.png'); controller.offsets['older'].setText(format(window._current_inspection().reader('older').size,'x')); controller.request(); phase=4
        elif phase==4 and controller.result is not None:
            capture('rd-paired-eof.png'); (out/'rd-visual-observations.json').write_text(json.dumps(records,indent=2)+'\n'); window.close(); app.quit(); return
        QTimer.singleShot(30,step)
    except Exception as exc:
        print(type(exc).__name__+': '+str(exc),file=sys.stderr); window.close(); app.exit(1)
def timeout():
    print('visual capture timed out',file=sys.stderr); window.close(); app.exit(2)
QTimer.singleShot(0,step); QTimer.singleShot(15000,timeout)
code=app.exec(); temporary.cleanup(); print(json.dumps(records)); sys.exit(code)
