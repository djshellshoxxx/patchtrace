"""Independent portable mutation controls; does not execute input artifacts."""
from __future__ import annotations
import hashlib
import json
import os
import sys
import tempfile
from contextlib import contextmanager
from pathlib import Path


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def replacement(path):
    before = path.stat()
    original = path.read_bytes()
    moved = path.with_suffix('.held')
    path.rename(moved)
    path.write_bytes(original)
    os.utime(path, ns=(before.st_atime_ns, before.st_mtime_ns))
    require(path.stat().st_size == before.st_size, 'size control failed')
    require(path.stat().st_mtime_ns == before.st_mtime_ns, 'mtime control failed')
    require(path.stat().st_ino != before.st_ino, 'identity control failed')
    return moved


def backup_control(folder):
    from patchtrace import verified_backup as module
    path = folder / 'backup.sqlite3'
    path.write_bytes(b'equal bytes and restored mtime, different owner')
    original = hashlib.sha256
    moved = []
    class SwappingDigest:
        def __init__(self):
            self.digest = original()
        def update(self, data):
            self.digest.update(data)
            if not moved:
                moved.append(replacement(path))
        def hexdigest(self):
            return self.digest.hexdigest()
    try:
        module.hashlib.sha256 = SwappingDigest
        require(module._fingerprint(path) is None, 'replacement received backup byte trust')
    finally:
        module.hashlib.sha256 = original
    require(moved[0].read_bytes() == path.read_bytes(), 'control altered bytes')
    return 'same-byte same-size restored-mtime replacement during hashing refused'


def output_control(folder):
    from tools.calibration.tier_r import output_store as module
    path = folder / 'output.json'
    path.write_bytes(b'{"evidence":"equal-byte replacement"}')
    original = os.fdopen
    moved = []
    @contextmanager
    def swapping_fdopen(*args, **kwargs):
        with original(*args, **kwargs) as stream:
            class Reader:
                def read(self, count):
                    require(count == module.RS.MAX_OUTPUT_BYTES + 1, 'unbounded or changed read limit')
                    raw = stream.read(count)
                    moved.append(replacement(path))
                    return raw
            yield Reader()
    refused = False
    try:
        module.os.fdopen = swapping_fdopen
        try:
            module.read_output_bytes(path)
        except module.OutputError:
            refused = True
    finally:
        module.os.fdopen = original
    require(refused, 'replacement received output trust')
    require(moved[0].read_bytes() == path.read_bytes(), 'control altered bytes')
    return 'same-byte same-size restored-mtime replacement during bounded read refused'


with tempfile.TemporaryDirectory() as folder:
    result = {'backup': backup_control, 'output': output_control}[sys.argv[1]](Path(folder))
print(json.dumps({'control': sys.argv[1], 'result': 'passed', 'detail': result}, sort_keys=True))
