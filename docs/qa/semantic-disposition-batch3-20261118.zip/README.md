# Semantic branch batch 3 — sealed evidence

Exact source: 55f3d0742f7d4cf32357a42b8b1cc76d85875e71, tree
11a0c1598764ebd3fd8d3b540377aa52e949f88a (actual published PR #316).

This packet records a read-only 20-tip semantic review. It does not mutate
production/tests/workflows, remote refs or the frozen inventory. ledger.json/md
hold the exact-tip decisions; snapshot.json retains merge bases, patch equivalence,
changed paths and current blob projection. Branch .patch files compare merge base
to tip; .current-comparison.patch files compare current source to old tip. The
production.diff files are the original source-only patches inspected. Symbol/AST
equality is supporting structural evidence, never standalone semantic acceptance.
replacement-provenance.json records full-history ancestral code needles and parent
presence; current-source/ and its manifest retain exact source/spec/test bytes.

Current bounded gate: 36 files, 666 passed / 4 Windows-only skipped, 62.85 s pytest
summary (62.782 s JUnit). The separate public backup probe has 2 failed / 1 passed,
0.31 s summary (0.225 s JUnit). The complete historical code-highlighter test file
is unchanged from c7fb422c; three selected nodes have 1 failed / 2 passed, 0.51 s
summary (0.439 s JUnit). All invocations use absolute current PYTHONPATH and offscreen
Qt. Their original command JSON, stdout/stderr logs and XML remain unchanged.
Neither contrary control is repaired in this docs branch. Do not add overlapping
historical/current positives or repeated per-branch test mappings.

The provenance script initially referenced two inaccurate source text needles:
describe_backend_exit(sanitized_log), and pt-ghidra rather than patchtrace-ghidra.
It stopped on the first assertion. The initial script/log are preserved; the
corrected script uses actual source text and full merge history (ordinary path
history omits the merged consolidation). This was a read-only evidence preflight,
not a product-test failure or a source repair. Document path existence checks
passed after removing a nonexistent guessed code_text spec reference.

No fresh remote/hosted status, historical full suite, integrated full suite, live
network/provider/acquisition, target/native engine, Windows, frozen package or
manual/screen-reader acceptance ran. Sixty of 131 original reconciliation tips
now have selected-scope entries; 71 remain unselected. Broad branch packaging,
native and research residue remains open. No whole-branch closure is authorized.

evidence-manifest.json gives size and SHA-256 for every other archive member.
All members are reopened and checked after ZIP creation. No cache/bytecode or
ephemeral project contents are included. The original probes are retained intact.
