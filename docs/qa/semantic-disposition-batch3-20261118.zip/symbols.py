from pathlib import Path
import ast,hashlib,json,subprocess
R=Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch3')
Q=Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch3')
D=json.loads((Q/'snapshot.json').read_text())
B=D['comparison_base']
cache={}
def source(sha,path):
    key=(sha,path)
    if key not in cache:
        done=subprocess.run(['git','show',sha+':'+path],cwd=R,capture_output=True,text=True)
        cache[key]=done.stdout if done.returncode==0 else None
    return cache[key]
def symbols(text):
    if text is None: return {}
    out={}
    def visit(nodes,prefix=''):
        for n in nodes:
            if isinstance(n,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)):
                name=prefix+n.name
                out[name]={'ast_sha256':hashlib.sha256(ast.dump(n,include_attributes=False).encode()).hexdigest(),
                           'line':n.lineno,'end_line':n.end_lineno}
                if isinstance(n,ast.ClassDef): visit(n.body,name+'.')
    visit(ast.parse(text).body)
    return out
all=[]
for row in D['branches']:
    records=[]
    for p in row['source_projection']:
        path=p['path']
        if not path.startswith('src/') or not path.endswith('.py'): continue
        old,cur=symbols(source(row['tip'],path)),symbols(source(B,path))
        records += [{'path':path,'symbol':name,'tip':data,'baseline':cur.get(name),
                     'status':'missing' if name not in cur else 'same_ast' if cur[name]['ast_sha256']==data['ast_sha256'] else 'changed_ast'}
                    for name,data in old.items()]
    all.append({'branch':row['branch'],'tip':row['tip'],'symbols':records})
    missing=[r['path'].removeprefix('src/patchtrace/')+':'+r['symbol'] for r in records if r['status']=='missing']
    same=sum(r['status']=='same_ast' for r in records)
    print(row['branch'],f'same_ast={same} missing={len(missing)}', ', '.join(missing[:18]))
(Q/'symbol-comparison.json').write_text(json.dumps({'baseline':B,'note':'AST equality is structural evidence, not standalone semantic equivalence or qualification','branches':all},indent=2)+'\n')
