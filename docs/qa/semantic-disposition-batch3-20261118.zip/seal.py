"""Validate and seal the read-only branch review packet; never include caches or unbounded scratch."""
from pathlib import Path
import hashlib
import json
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch3')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch3')
PLAN = ROOT / 'docs/plans/autonomous-consolidation-20261118'
QA = ROOT / 'docs/qa'
NAME = 'semantic-disposition-batch3-20261118'
BASE = '55f3d0742f7d4cf32357a42b8b1cc76d85875e71'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

ledger = json.loads((PLAN / 'semantic-disposition-batch3.json').read_text())
assert ledger['comparison_source'] == BASE
assert len(ledger['branches']) == 20 and len(ledger['still_unselected_original_tips']) == 71
assert not git('diff', BASE, '--', 'src', 'tests', 'tools', '.github')
assert not git('status', '--porcelain', '--', 'src', 'tests', 'tools', '.github')
validation = subprocess.run(['git', 'diff', '--check'], cwd=ROOT, text=True,
                            capture_output=True, check=False)
(OUT / 'diff-check.log').write_text(validation.stdout + validation.stderr)
assert validation.returncode == 0
(OUT / 'document-validation.json').write_text(json.dumps({
    'comparison_source': BASE, 'comparison_tree': git('rev-parse', BASE + '^{tree}'),
    'selected_branches': 20, 'distinct_selected': len({r['branch'] for r in ledger['branches']}),
    'original_reconciliation_count': 131, 'previously_selected': 40, 'remaining_unselected': 71,
    'frozen_tip_matches': all(r['tip_matches_inventory'] for r in ledger['branches']),
    'all_current_source_paths_exist': all((ROOT / p).is_file() for r in ledger['branches'] for p in r['current_paths']),
    'all_spec_test_paths_exist': all((ROOT / p).is_file() for r in ledger['branches'] for p in r['specs'] + ['tests/' + t for t in r['tests']]),
    'no_product_test_tool_workflow_changes': True, 'diff_check_exit': validation.returncode,
    'archive_verification': 'seal.py independently re-reads every ZIP member and matches its size and SHA-256 to the manifest after writing',
}, indent=2) + '\n')
(OUT / 'ledger.json').write_bytes((PLAN / 'semantic-disposition-batch3.json').read_bytes())
(OUT / 'ledger.md').write_bytes((PLAN / 'semantic-disposition-batch3.md').read_bytes())
(OUT / 'README.md').write_text('''# Semantic branch batch 3 — sealed evidence

Exact source: 55f3d0742f7d4cf32357a42b8b1cc76d85875e71, tree
11a0c1598764ebd3fd8d3b540377aa52e949f88a (actual published PR #316).

This packet records a read-only 20-tip semantic review. It does not mutate
production/tests/workflows, remote refs or the frozen inventory. ledger.json/md
hold the exact-tip decisions; snapshot.json retains merge bases, patch equivalence,
changed paths and current blob projection. Branch .patch files compare merge base
to tip; .current-comparison.patch files compare current source to old tip. The
production.diff files are the original source-only patches inspected. Symbol/AST
equality is supporting structural evidence, never standalone semantic acceptance.
replacement-provenance.json records full-history ancestral code needles and parent
presence; current-source/ and its manifest retain exact source/spec/test bytes.

Current bounded gate: 36 files, 666 passed / 4 Windows-only skipped, 62.85 s pytest
summary (62.782 s JUnit). The separate public backup probe has 2 failed / 1 passed,
0.31 s summary (0.225 s JUnit). The complete historical code-highlighter test file
is unchanged from c7fb422c; three selected nodes have 1 failed / 2 passed, 0.51 s
summary (0.439 s JUnit). All invocations use absolute current PYTHONPATH and offscreen
Qt. Their original command JSON, stdout/stderr logs and XML remain unchanged.
Neither contrary control is repaired in this docs branch. Do not add overlapping
historical/current positives or repeated per-branch test mappings.

The provenance script initially referenced two inaccurate source text needles:
describe_backend_exit(sanitized_log), and pt-ghidra rather than patchtrace-ghidra.
It stopped on the first assertion. The initial script/log are preserved; the
corrected script uses actual source text and full merge history (ordinary path
history omits the merged consolidation). This was a read-only evidence preflight,
not a product-test failure or a source repair. Document path existence checks
passed after removing a nonexistent guessed code_text spec reference.

No fresh remote/hosted status, historical full suite, integrated full suite, live
network/provider/acquisition, target/native engine, Windows, frozen package or
manual/screen-reader acceptance ran. Sixty of 131 original reconciliation tips
now have selected-scope entries; 71 remain unselected. Broad branch packaging,
native and research residue remains open. No whole-branch closure is authorized.

evidence-manifest.json gives size and SHA-256 for every other archive member.
All members are reopened and checked after ZIP creation. No cache/bytecode or
ephemeral project contents are included. The original probes are retained intact.
''')
excluded = {'evidence-manifest.json', 'seal-result.json', 'seal.log'}
files = sorted(path for path in OUT.rglob('*') if path.is_file()
               and '__pycache__' not in path.parts and '.pytest_cache' not in path.parts
               and path.name not in excluded and not path.name.endswith('.pyc'))
manifest = {str(path.relative_to(OUT)): {'bytes': path.stat().st_size,
                                        'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
            for path in files}
(OUT / 'evidence-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = QA / (NAME + '.zip')
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for path in files + [OUT / 'evidence-manifest.json']:
        bundle.write(path, str(path.relative_to(OUT)))
with zipfile.ZipFile(archive) as bundle:
    assert set(bundle.namelist()) == set(manifest) | {'evidence-manifest.json'}
    assert bundle.testzip() is None
    for name, item in manifest.items():
        data = bundle.read(name)
        assert len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256'], name
metadata = {'source': BASE, 'archive': str(archive.relative_to(ROOT)),
            'members': len(manifest) + 1, 'bytes': archive.stat().st_size,
            'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'verified_members': len(manifest) + 1}
(OUT / 'seal-result.json').write_text(json.dumps(metadata, indent=2) + '\n')

receipt = f'''# Semantic disposition batch 3: source-pinned QA receipt

This docs-only review inspects 20 original branch tips against actual published
PR #316 source **`{BASE}`**, tree
`11a0c1598764ebd3fd8d3b540377aa52e949f88a`. Eighteen focal scopes are retained,
one old helper retains a confirmed backup defect, and one historical highlighter
guard is missing. [Complete ledger](../plans/autonomous-consolidation-20261118/semantic-disposition-batch3.md)
and [machine-readable evidence](../plans/autonomous-consolidation-20261118/semantic-disposition-batch3.json)
record exact tips, source replacements, all inspected paths and unreviewed residue.

## Sealed evidence

[Receipt archive]({NAME}.zip): **{metadata['members']} members**, **{metadata['bytes']:,} bytes**,
SHA-256 **`{metadata['sha256']}`**. Every member was reopened and checked;
`evidence-manifest.json` records size/SHA-256 for all other members. The packet
retains complete source patches/current comparisons, blob/AST projections,
full-history source proofs, exact current source/spec/test snapshots, original
probes and raw command/log/XML receipts. The frozen inventory is unchanged.

## Exact-source executions

| Invocation at `55f3d074` | Actual result | Pytest summary | JUnit suite duration |
|---|---|---|---|
| 36 current focal replacement files, including the actual global tooltip sweep | 666 passed, 4 skipped, 0 failures/errors | 62.85 s | 62.782 s |
| External public backup publication probe | 2 failed, 1 passed, 0 setup errors | 0.31 s | 0.225 s |
| Three original unchanged historical highlighter nodes | 1 failed, 2 passed, 0 setup errors | 0.51 s | 0.439 s |

The four skips are `test_windows_containment_failure_fails_closed`,
`test_windows_assignment_denial_terminates_suspended_child`,
`test_ghidra_output_path_rejects_overlong_windows_path`, and
`test_work_dir_windows`. Reasons are native Windows Job Object/cleanup, long-path
and local-app-data acceptance. They are not passing controls on this Linux host.
All commands use `/workspace/scratch/3a6632a6e5ff/venv/bin/python`,
`QT_QPA_PLATFORM=offscreen` and absolute current `PYTHONPATH` pointing to this
worktree’s `src` and `tests`. Shared per-branch test mappings and historical
positive neighbors are not additional executions or additive completion credit.

## B3-C1: retained backup reservation ownership defect

The unchanged probe `test_backup_reservation_review.py`, SHA-256
`2fb21e2ff6b346f8c0ec96a1cac1abdfbd9547c87fd519f68153991816c20006`,
uses actual `ProjectService.sample` and `ProjectService.backup`. Replacing the
reserved destination with a foreign empty directory causes two preservation
failures: ordinary rename publication replaces it, and rename-error cleanup
removes it. A held descriptor records the replacement directory losing its link.
The original project database bytes remain unchanged and ordinary backup/reopen
passes. This is a **POSIX empty-replacement** finding, not native Windows or
general source-project corruption evidence.

The historical `audit/core` helper is AST-identical to current
`persistence._publish_no_replace`, so this is retained incomplete behavior,
not a missing port. Contract: `cli-project-compare.md` §3.6 and `architecture.md`
§3. Root owns a separate publication repair and is checking the installer’s
duplicated helper on later continuation source. This packet preserves the
original two-red/one-positive result and makes no later-fix claim.

## B3-C2: omitted highlighter dispatch guard

The full historical `tests/test_ui_codetext.py` is retained unchanged from
`c7fb422c750f1d0e5591277b91492874afd79af7` as
`historical-controls/codetext/test_ui_codetext.py` (16,911 bytes), SHA-256
`238abb33cad9ff066f73564c97ee1215e514735c17aa62ea26a4e39d8f5721e3`.

| Historical node | Result at current source |
|---|---|
| `test_bulk_load_skips_span_dispatch_outside_the_window` | Failed: actual span calls include off-window blocks |
| `test_windowed_highlighter_formats_only_the_window` | Passed |
| `test_scroll_updates_window_within_budget` | Passed |

The failing node’s later call-count/state assertions were not reached; retain
and exercise them after a separately reviewed repair. Current `controller.spans`
filters internally, so the existing tests correctly pass visible formatting and
scroll behavior while the earlier dispatch optimization remains absent. The
proposed source scope is `ui_codetext.py::CodeHighlighter.highlightBlock`, the
WBQ contract and focused regressions, including failure/disabled states and a
high-DPI offscreen run. No native timing or blanket historical-port claim follows.
The branch’s unrelated native distinct-I/O helper is retained, with later worker
reporting added; it was inspected but not executed.

## Evidence checks and limitations

Document/source-path checks and `git diff --check` pass. Production, tests, tools
and workflows have no diff from the pinned source. The read-only provenance
preflight stopped on an inaccurate text needle; its initial script/log remain
retained, then the exact actual call/prefix and full merge history were used.
A nonexistent guessed spec filename was removed before document validation.
These are evidence-script corrections, not repaired product-test failures.

No full historical/integrated suite, live provider/acquisition, target/native
engine, Windows, frozen package or manual/screen-reader acceptance ran. There
was no fresh GitHub/hosted observation or remote mutation. Sixty of 131 original
reconciliation tips have scoped selections after this batch; 71 remain
unselected, with broader native/package/research residue explicit. No product
percentage, whole-branch closure, merge or release is credited. Independent
review/selective integration of this docs checkpoint is pending root.
'''
(QA / (NAME + '.md')).write_text(receipt)
print(json.dumps(metadata, indent=2))
