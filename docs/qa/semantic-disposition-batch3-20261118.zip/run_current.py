"""Run the bounded current-source gate with exact source and artifact receipts."""
from datetime import UTC, datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch3')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch3')
PYTHON = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
BASE = '55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
FILES = '''test_audit_ai_reports.py test_interpretation.py test_audit_core.py test_core.py
test_audit_desktop.py test_audit_runtime.py test_jobs.py test_backend_bundle_env.py
test_backend_sec1.py test_backend_sec3.py test_diagnostics_core8.py test_ingestion_core10.py
test_cli_acq13.py test_acquisition_acq12.py test_network_consent_symbols.py
test_alpha_integration.py test_artifact_bytes.py test_representations.py
test_preflight_overview.py test_diff_navigation_extra.py test_runtime_discovery.py
test_runtime_discovery_bundle.py test_runtime_discovery_bindiff.py test_tooltips.py
test_inspection_row_tooltips.py test_ui_codetext.py test_ui_profiles.py
test_ui_symbol_local.py test_ghidriff_threading.py test_ui_setup_dialog.py test_ui.py
test_ui_inspection_signing.py test_audit116_stale_inspection_failure.py
test_gui_creation_retry.py test_creation_schema_refusal.py test_creation_replacement_refusal.py'''.split()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

assert git('rev-parse', 'HEAD') == BASE
assert not git('status', '--porcelain', '--', 'src', 'tests', 'tools')
paths = ['tests/' + name for name in FILES]
assert all((ROOT / path).is_file() for path in paths)
environment = {'PYTHONPATH': str(ROOT / 'src') + ':' + str(ROOT / 'tests'),
               'QT_QPA_PLATFORM': 'offscreen'}
command = [PYTHON, '-m', 'pytest', '-q', *paths,
           '--junitxml=' + str(OUT / 'current-affected.xml')]
receipt = {
    'source': BASE, 'tree': git('rev-parse', 'HEAD^{tree}'), 'cwd': str(ROOT),
    'command': command, 'environment': environment,
    'started_utc': datetime.now(UTC).isoformat(),
    'test_files': {path: hashlib.sha256((ROOT / path).read_bytes()).hexdigest() for path in paths},
    'qualification_scope': 'Authored deterministic source/offscreen regression controls. No live provider, network acquisition, target or native engine execution, Windows or package acceptance.',
}
(OUT / 'current-command.json').write_text(json.dumps(receipt, indent=2) + '\n')
start = time.monotonic()
with (OUT / 'current-affected.log').open('w') as log:
    result = subprocess.run(command, cwd=ROOT, env=os.environ | environment,
                            stdout=log, stderr=subprocess.STDOUT, check=False)
receipt.update(exit_code=result.returncode, finished_utc=datetime.now(UTC).isoformat(),
               wall_seconds=time.monotonic() - start)
if (OUT / 'current-affected.xml').is_file():
    root = ET.parse(OUT / 'current-affected.xml').getroot()
    receipt['junit_suites'] = [suite.attrib for suite in root.iter('testsuite')]
    receipt['skips'] = [
        {'test': case.attrib, 'reason': node.attrib, 'detail': node.text}
        for case in root.iter('testcase') for node in case.findall('skipped')
    ]
receipt['final_product_source_status'] = git('status', '--porcelain', '--', 'src', 'tests', 'tools')
(OUT / 'current-command.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'exit_code': result.returncode, 'files': len(paths),
                  'wall_seconds': receipt['wall_seconds'],
                  'junit_suites': receipt.get('junit_suites'), 'skips': receipt.get('skips')}, indent=2))
print('\n'.join((OUT / 'current-affected.log').read_text().splitlines()[-12:]))
raise SystemExit(result.returncode)
