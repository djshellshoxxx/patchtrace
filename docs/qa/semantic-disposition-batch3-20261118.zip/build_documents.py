"""Build the bounded semantic ledger and retain exact source snapshots; no product edits."""
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch3')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch3')
PLAN = ROOT / 'docs/plans/autonomous-consolidation-20261118'
BASE = '55f3d0742f7d4cf32357a42b8b1cc76d85875e71'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def raw(sha, path):
    return subprocess.check_output(['git', 'show', sha + ':' + path], cwd=ROOT)

def read(name):
    return json.loads((OUT / name).read_text())

def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def append_section(path, marker, text):
    old = path.read_text()
    if marker in old:
        old = old.split(marker, 1)[0].rstrip() + '\n'
    path.write_text(old.rstrip() + '\n\n' + marker + '\n\n' + text.rstrip() + '\n')

snapshot = read('snapshot.json')
catalogue = read('catalogue.json')
dispositions = read('dispositions.json')
proofs = {row['branch']: row['proofs'] for row in read('replacement-provenance.json')['branches']}
structural = {row['branch']: row for row in read('symbol-comparison.json')['branches']}
inventory = json.loads((PLAN / 'branch-inventory.json').read_text())
old_by_name = {row['branch']: row for row in inventory['branches']}
assert not git('diff', BASE, '--', 'src', 'tests', 'tools', '.github')
assert hashlib.sha256((PLAN / 'branch-inventory.json').read_bytes()).hexdigest() == snapshot['inventory_source_sha256']
assert len(dispositions) == 20 and {r['branch'] for r in dispositions} == {r['branch'] for r in snapshot['branches']}
inputs = {row['branch']: row for row in snapshot['branches']}
remaining = [{'branch': row['branch'], 'tip': old_by_name[row['branch']]['head_sha']}
             for row in catalogue['branches'] if row['branch'] not in inputs]
assert len(remaining) == 71
assert len({row['branch'] for row in remaining}) == 71
counts = Counter(row['classification'] for row in dispositions)
assert counts == {'retained_focal_scope': 18, 'retained_with_confirmed_defect': 1,
                  'confirmed_selective_omission': 1}

current = read('current-command.json')
assert current['source'] == BASE and current['exit_code'] == 0
assert current['junit_suites'][0]['tests'] == '670'
assert current['junit_suites'][0]['skipped'] == '4'

def cases(filename):
    root = ET.parse(OUT / filename).getroot()
    return [{'name': case.attrib['name'],
             'result': 'failed' if case.find('failure') is not None else 'passed'}
            for case in root.iter('testcase')]

backup = cases('backup-reservation-red.xml')
highlighter = cases('historical-codetext-red.xml')
assert sum(c['result'] == 'failed' for c in backup) == 2
assert sum(c['result'] == 'failed' for c in highlighter) == 1
assert hashlib.sha256((OUT / 'test_backup_reservation_review.py').read_bytes()).hexdigest() == '2fb21e2ff6b346f8c0ec96a1cac1abdfbd9547c87fd519f68153991816c20006'
historical = read('codetext-historical-manifest.json')
assert (OUT / historical['retained']).read_bytes() == raw(historical['source'], historical['path'])
assert hashlib.sha256((OUT / historical['retained']).read_bytes()).hexdigest() == historical['sha256']

branches = []
for decision in dispositions:
    original = inputs[decision['branch']]
    mapped = structural[decision['branch']]['symbols']
    row = original | decision | {
        'qualification': 'current-affected: shared 36-file gate; see exact file map, not additive per-branch execution',
        'source_proofs': proofs[decision['branch']],
        'structural_summary': dict(Counter(item['status'] for item in mapped)),
        'whole_branch_closed': False, 'remote_action_authorized': False,
    }
    branches.append(row)

result = {
    'schema': 'patchtrace-semantic-disposition/1', 'batch': 3,
    'prepared_at_utc': datetime.now(UTC).isoformat(),
    'comparison_source': BASE, 'comparison_tree': snapshot['comparison_tree'],
    'comparison_identity': 'Actual published PR #316 baseline, not the later continuation candidate',
    'inventory_observed_at': snapshot['inventory_observed_at'],
    'inventory_source_sha256': snapshot['inventory_source_sha256'],
    'remote_refresh': snapshot['remote_refresh'],
    'previous_batches': [
        {'batch': 1, 'checkpoint': '8148ff0fada34e3adff893a3d68f0bce1ffc6e0f',
         'comparison_source': 'ac789497597fba3cb87696990d171a7a27024fca', 'selected': 20},
        {'batch': 2, 'checkpoint': '1a07861f3d54dde6fce0bbd3c79fc772295c92ac',
         'comparison_source': '3be3af166897fc2376dc64850edc66485273dea1', 'selected': 20,
         'note': 'Read from its committed JSON; batch 2 is not in this comparison baseline ancestry.'},
    ],
    'selection_denominator': {'original_needs_reconciliation_tips': 131,
                              'previously_selected': 40, 'selected_this_batch': 20,
                              'cumulatively_selected': 60, 'still_unselected': 71,
                              'meaning': 'Scope-selection counts, not completed branches or feature percentage'},
    'classification_counts': dict(counts),
    'decision_criteria': [
        'Read the merge-base-to-tip production patch, relevant current definitions and reachable callers.',
        'Record exact current blob/AST identity or substantive replacement guards and ancestry; do not infer equivalence from branch names or commit subjects.',
        'Map current behavior tests to each inspected scope and execute one pinned bounded gate.',
        'Retain confirmed contrary controls and separate historical, Linux/offscreen, native, package and manual claims.',
        'A retained focal scope does not close the whole branch, unrelated workflow/research residue or any original feature milestone.',
    ],
    'qualification': {
        'source': BASE, 'current_affected': {'files': 36, 'passed': 666, 'skipped': 4,
                                          'failed': 0, 'errors': 0, 'summary_seconds': 62.85,
                                          'junit_seconds': 62.782,
                                          'command': 'current-command.json',
                                          'receipts': ['current-affected.log', 'current-affected.xml'],
                                          'skips': current['skips']},
        'backup_external': {'failed': 2, 'passed': 1, 'errors': 0, 'summary_seconds': 0.31,
                            'junit_seconds': 0.225, 'cases': backup,
                            'command': 'backup-reservation-command.json'},
        'codetext_original': {'failed': 1, 'passed': 2, 'errors': 0, 'summary_seconds': 0.51,
                              'junit_seconds': 0.439, 'cases': highlighter,
                              'command': 'historical-codetext-command.json',
                              'original_source': historical},
        'not_run': ['historical branch full suites', 'final combined full suite', 'native Windows',
                    'target execution', 'live network acquisition/provider', 'native engines',
                    'frozen packages', 'manual or screen-reader acceptance', 'fresh hosted check observation'],
        'overlap': 'Tests and helpers shared by several branch rows are one execution. Historical positives overlap current behavior and are not additive qualification credit.',
    },
    'candidates': [
        {'id': 'B3-C1', 'kind': 'retained incomplete guarantee', 'branch': 'audit/core',
         'scope': 'POSIX backup directory reservation replacement', 'owner': 'root',
         'probe': 'test_backup_reservation_review.py',
         'probe_sha256': '2fb21e2ff6b346f8c0ec96a1cac1abdfbd9547c87fd519f68153991816c20006',
         'status_at_baseline': '2 failures, 1 ordinary-backup positive; no source fix here',
         'followup': 'Root reported a separate design/repair on continuation 3faf436a and is checking the duplicated offline_bundle helper; later work is not part of this baseline.'},
        {'id': 'B3-C2', 'kind': 'omitted historical behavior', 'branch': 'fix/codetext-budget-wave3',
         'scope': 'CodeHighlighter early guard before spans dispatch', 'owner': 'not yet assigned source',
         'probe': historical['retained'], 'probe_sha256': historical['sha256'],
         'status_at_baseline': '1 unchanged historical failure and 2 positive neighbors; no source fix here',
         'followup': 'Propose one ui_codetext.py guard slice after this docs handoff, with WBQ spec/tests first and formatting, scrolling, disabled/failure-state and high-DPI controls.'},
    ],
    'branches': branches, 'still_unselected_original_tips': remaining,
    'limitations': [
        'The original inventory and its mechanical classifications are immutable and unchanged.',
        'All selected local fetched tips match the original snapshot, but no new GitHub status/review/check evidence was fetched.',
        'Broader checkpoint/packaging/research residue remains open even when a focal source behavior is retained.',
        'No source, schema, workflow or test changes; no remote mutation, merge, close, delete, tag or release.',
        'No product completion percentage is inferred from tests, selected tips or file identity.',
    ],
}
write_json(PLAN / 'semantic-disposition-batch3.json', result)

# Exact current source/spec/test bytes make the code facts independently inspectable.
paths = {p for row in dispositions for p in row['current_paths'] + row['specs']}
paths |= set(current['test_files'])
paths |= {'AGENTS.md', 'docs/modules.md', 'tests/conftest.py', 'tests/pe_builder.py'}
source_manifest = {}
for path in sorted(paths):
    data = raw(BASE, path)
    destination = OUT / 'current-source' / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(data)
    source_manifest[path] = {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data),
                             'git_blob': git('rev-parse', BASE + ':' + path)}
for sha, path, label in [
    ('c7fb422c750f1d0e5591277b91492874afd79af7', 'src/patchtrace/ui_codetext.py', 'codetext'),
    ('fae13b2ed3043ddce00bbf387e386e93e7b3ee06', 'src/patchtrace/persistence.py', 'audit-core'),
]:
    destination = OUT / 'historical-source' / label / path
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(raw(sha, path))
write_json(OUT / 'current-source-manifest.json', {'source': BASE, 'tree': snapshot['comparison_tree'], 'files': source_manifest})

labels = {'retained_focal_scope': 'Retained focal scope',
          'retained_with_confirmed_defect': 'Retained, confirmed defect',
          'confirmed_selective_omission': 'Confirmed selective omission'}
lines = [
    '# Semantic branch disposition — batch 3', '',
    f'Comparison source: **`{BASE}`**, tree `{snapshot["comparison_tree"]}` (actual published PR #316).', '',
    'This is a read-only review of 20 source-bearing tips from the 91 original tips left unselected after batch 2. '
    'Eighteen inspected focal scopes are retained in current source; one retains a reproduced backup defect and '
    'one omits a historical highlighter dispatch guard. No product source was changed.', '',
    'The [complete JSON](semantic-disposition-batch3.json) retains every exact tip, merge base, ahead/behind count, '
    'patch-equivalence record, changed-path/blob projection, source proof, test mapping and all 71 still-unselected '
    'tips. The [QA receipt](../../qa/semantic-disposition-batch3-20261118.md) links the sealed raw evidence.', '',
    '## Observation and criteria', '',
    f'The original inventory was observed at `{snapshot["inventory_observed_at"]}`. This batch cross-checks local '
    'fetched refs against those frozen tips; it does not refresh GitHub PR/review/check state. Batch 1 selected 20 '
    'tips at `ac789497`; batch 2 selected 20 at `3be3af16` and is read from its committed checkpoint `1a07861f`. '
    'Batch 2 is not part of this older comparison baseline ancestry. Later named-source/UI/static or backup '
    'continuation results do not relabel this source.', '',
    'All 20 production patches were read against their merge bases, then compared with actual current guards, '
    'call sites and tests. Exact file/AST matches support some decisions; moved implementations require their '
    'current caller and contract evidence. Source introduction/replacement history is recorded with full merge '
    'history and parent presence, including the consolidation that simplified path history omits. A source match '
    'does not transfer historical native or release acceptance.', '',
    '**60 of 131 original reconciliation tips now have selected-scope entries; 71 remain unselected.** These '
    'are scope counts, not completed branches, a feature percentage or closure authority. Unreviewed broader '
    'checkpoint/packaging/research residue remains open. All branches are preserved.', '',
    '## Twenty exact tips', '',
    '| Branch | Exact tip | Focal outcome |', '|---|---|---|',
]
for row in branches:
    lines.append(f'| `{row["branch"]}` | `{row["tip"]}` | {labels[row["classification"]]}: {row["focus"]} |')
lines += ['', '## Source-level dispositions', '']
for number, row in enumerate(branches, 1):
    evidence_commits = []
    for item in row['source_proofs']:
        for h in item['history']:
            if h['needle_present_in_commit'] and not h['needle_present_in_first_parent'] and h['sha'] not in evidence_commits:
                evidence_commits.append(h['sha'])
    prs = ', '.join('#' + str(p['number']) for p in row['pull_requests']) or 'none mapped in frozen inventory'
    lines += [f'### {number}. `{row["branch"]}`', '',
              f'**{labels[row["classification"]]}.** Frozen PR mapping: {prs}.', '',
              '**Historical delta:** ' + row['historical_behavior'], '',
              '**Current replacement:** ' + row['current_behavior'], '',
              'Source: ' + ', '.join('`' + p + '`' for p in row['current_paths']) + '.', '',
              'Verified ancestral source records: ' + ', '.join('`' + sha + '`' for sha in evidence_commits) +
              '. Exact code needles, line locations, blobs and parent-presence evidence are in the JSON/receipt.', '',
              'Current test map: ' + ', '.join('`tests/' + t + '`' for t in row['tests']) +
              '. These are subsets of the shared 36-file execution, not separate additive runs.', '',
              '**Selective decision:** ' + row['recommendation'], '',
              '**Residual scope:** ' + row['residue'], '']
lines += [
    '## Confirmed candidates and unchanged contrary evidence', '',
    '### B3-C1 — retained backup reservation defect (root-owned follow-on)', '',
    '`persistence._publish_no_replace` is AST-identical in `audit/core` and this baseline '
    '(`b4891d17d2e2d25da1a12005520f0e3620c94d7e04aaf579774887bb2e24c43b`). '
    'The current public `ProjectService.backup` path reserves a new directory with mkdir, then uses rename; '
    'its failure handler removes the pathname. An external control substitutes another owner’s empty directory '
    'between those operations. Successful publication replaces it; a forced rename error removes it in cleanup. '
    'Both fail the preservation assertion while the ordinary complete-backup control passes. The held replacement '
    'directory descriptor confirms deletion; original project database bytes remain unchanged.', '',
    'The unchanged probe SHA-256 is `2fb21e2ff6b346f8c0ec96a1cac1abdfbd9547c87fd519f68153991816c20006`. '
    'Scope is **POSIX empty-directory substitution**, not native Windows or general backup corruption. The '
    'no-overwrite contract is `docs/specs/cli-project-compare.md` §3.6 and `docs/specs/architecture.md` §3. '
    'Root owns a separate design/repair on continuation `3faf436a` and is checking the installer’s duplicated '
    'helper. No subsequent fix is included or credited here.', '',
    '### B3-C2 — omitted window guard before highlighter dispatch', '',
    'Original source/test tip: `c7fb422c750f1d0e5591277b91492874afd79af7`. The complete historical '
    '`tests/test_ui_codetext.py` is retained byte-for-byte, SHA-256 '
    '`238abb33cad9ff066f73564c97ee1215e514735c17aa62ea26a4e39d8f5721e3`. '
    '`test_bulk_load_skips_span_dispatch_outside_the_window` fails at the assertion that all recorded span calls '
    'belong to the installed window. Its later call-count/state assertions are not reached in that failing case. '
    'The unchanged window-formatting and scroll-budget neighbors pass. The current `spans` method filters '
    'internally, preserving visible formatting while `highlightBlock` still dispatches every Qt block callback.', '',
    'Proposed separate slice: `src/patchtrace/ui_codetext.py::CodeHighlighter.highlightBlock`, the WBQ '
    'integration-plan contract and focused regressions. Install a guard before dispatch, keep exception-to-plain '
    'text behavior, constant default block state, scroll window cleanup, source/model ownership, font metrics '
    'and extra selections. Reuse the exact historical control and nearest current tests under normal and '
    'high-DPI offscreen settings. No bulk native/Rizin or broader UI refactor is indicated. The branch’s '
    'distinct-I/O native control already survives, differing only by later worker-count reporting; it was not run.', '',
    '## Qualification and open boundaries', '',
    '| Pinned execution at `55f3d074` | Result | Pytest summary time |',
    '|---|---|---|',
    '| 36 current focal replacement files, including actual global tooltip sweep | 666 passed, 4 skipped; zero failures/errors | 62.85 s |',
    '| Unchanged external public backup controls | 2 failed, 1 passed; zero setup errors | 0.31 s |',
    '| Three unchanged historical highlighter controls | 1 failed, 2 passed; zero setup errors | 0.51 s |', '',
    'The skips are Windows containment denial, suspended-child cleanup, Ghidra long paths and local-app-data '
    'work directory. JUnit durations and exact commands/environment/source hashes are retained separately. '
    'Overlapping positives are not summed into an aggregate success score. The original failure receipts are '
    'unchanged; this docs-only checkpoint does not repair either issue.', '',
    'No historical full suite, final integrated full suite, new native engine/Windows, live acquisition/provider, '
    'target execution, frozen package or manual/screen-reader acceptance ran. In particular, Linux build-tool '
    'residue on the symbol-settings branch and large SPEC-26 future requirements remain separate. No older '
    'PR closure, branch deletion, merge or release is authorized.', '',
]
(PLAN / 'semantic-disposition-batch3.md').write_text('\n'.join(lines))

append_section(PLAN / 'consolidation-ledger.md', '## Semantic reconciliation batch 3 — 2026-11-18', '''
The [third scoped batch](semantic-disposition-batch3.md) compares 20 further original tips
with actual published PR #316 `55f3d0742f7d4cf32357a42b8b1cc76d85875e71`.
Eighteen focal behaviors are retained; the old backup helper is retained but fails a
new POSIX empty-directory ownership control, and a historical code-highlighter
dispatch guard is absent. Root owns the separate backup follow-on; the highlighter
requires a separately reviewed narrow slice. No product source changed in this review.

The exact current 36-file gate passes 666 tests with four explicit Windows skips.
The original backup 2-red/1-positive and historical highlighter 1-red/2-positive
receipts remain unchanged. Tests are not added across overlapping branch mappings.
All 143 old tooltip IDs/three templates survive, and Files/inspection/runtime and
representation replacements are traced through actual source and callers.

Batch 1/2/3 now select 60 of 131 original reconciliation tips; 71 remain unselected,
with broader native/package/research residue still open. These are scope counts,
not whole-branch closure or product-completion credit. The initial inventory is
unchanged and no fresh GitHub state/remote action is claimed. Batch 2 is read from
its separate `1a07861f` checkpoint, not retroactively inserted into this baseline.
[Exact tips, source proof and remaining list](semantic-disposition-batch3.json);
[sealed receipt](../../qa/semantic-disposition-batch3-20261118.md).
''')
append_section(ROOT / 'docs/plans/patchtrace-completion-matrix.md', '## Semantic batch 3 scope update — 2026-11-18', '''
This read-only update is pinned to actual PR #316 `55f3d074`, independently of later
continuation source. It adds no product milestone or percentage: the denominator
131 is original branch tips needing reconciliation, not feature acceptance criteria.
Twenty more selected scopes bring the cumulative selection to 60; 71 remain
unselected and broad-tip residue remains open.

| Assessed scope | Current evidence at the pinned source | Remaining work/acceptance |
|---|---|---|
| Eighteen focal runtime/desktop/representation behaviors | Actual source/caller replacements and 666-pass shared gate, four Windows skips | Unreviewed branch residue; native/manual/package and final combined gates |
| Backup destination ownership | Retained helper fails two POSIX empty-replacement controls; ordinary backup passes | Root-owned publication design/repair; preserve original database/foreign destination; separate Windows/native qualification |
| Code-highlighter bulk-load dispatch | Original historical guard is absent; one unchanged failure with two formatting/scroll positives | Narrow spec/test-first guard repair and independent source/normal/high-DPI checks; no native timing claim |

[Detailed exact-tip disposition](autonomous-consolidation-20261118/semantic-disposition-batch3.md)
and [raw QA receipt](../qa/semantic-disposition-batch3-20261118.md) preserve the
historical failures and current-source limits. No whole-branch closure follows.
''')
append_section(ROOT / 'docs/qa.md', '## [SEMANTIC-DISPOSITION-BATCH3-20261118]', '''
Read-only comparison at actual published #316 `55f3d074`: 20 exact original tips,
18 retained focal scopes, one retained backup defect and one omitted highlighter
dispatch guard. Current 36-file source/offscreen gate: **666 passed, four explicit
Windows skips, 62.85 s**. Separate original contrary controls remain **2 failed/1
passed** for public backup publication and **1 failed/2 passed** for unchanged
historical highlighter behavior. No production/test/workflow edit, native run,
fresh hosted observation or whole-branch closure. Cumulative selected scopes:
60 of the original 131, with 71 still unselected and broader residue open.
[Exact sources, commands, archive and limits](qa/semantic-disposition-batch3-20261118.md).
''')
append_section(ROOT / 'tasks/todo.md', '### [SEMANTIC-DISPOSITION-BATCH3-20261118]', '''
- [x] Inspect 20 further exact source-bearing tips against actual #316 `55f3d074`; preserve real patch, caller, replacement and ancestry evidence.
- [x] Run source-pinned 36-file current gate (666 passed, four Windows skips), preserving global tooltip coverage and all original contrary controls.
- [x] Record two narrow candidates without source edits: retained backup ownership defect (root-owned follow-on) and missing code-highlighter dispatch guard.
- [ ] Independently review and selectively retain this docs-only batch; preserve all branches and original mechanical inventory.
- [ ] Design/repair/independently qualify backup directory publication in its separately assigned scope.
- [ ] Propose, spec/test and independently qualify the one-file highlighter guard slice; retain unchanged historical test bytes.
- [ ] Inspect the remaining 71 original tips and broader checkpoint/package/research residue; no blanket closure.
- [ ] Complete actual final-source full/platform/native/package/manual gates; source/offscreen tests are not that acceptance.
''')
print(json.dumps({'selected': len(branches), 'classifications': counts, 'remaining': len(remaining),
                  'source_snapshots': len(source_manifest), 'source': BASE}, indent=2))
