"""Read-only source/ancestry proofs for the selected semantic scopes, not equivalence by branch name."""
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
from pathlib import Path
import ast
import hashlib
import json
import subprocess

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch3')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch3')
SNAPSHOT = json.loads((OUT / 'snapshot.json').read_text())
BASE = SNAPSHOT['comparison_base']

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

@lru_cache(None)
def source(sha, path):
    result = subprocess.run(['git', 'show', sha + ':' + path], cwd=ROOT,
                            text=True, capture_output=True, check=False)
    return result.stdout if result.returncode == 0 else None

PROOFS = {
    'audit/ai-reports': [('providers.py', 'class _CallLimit'), ('providers.py', 'response.read1('),
                         ('reports.py', '# Windows paths may contain spaces')],
    'audit/core': [('persistence.py', 'def finite_float'), ('persistence.py', 'def _publish_no_replace'),
                   ('persistence.py', 'def _abandoned_creation'),
                   ('service.py', 'match-override records are created only by manual correction')],
    'audit/desktop': [('ui.py', 'def plain_tip'), ('ui.py', 'if not self.destination.text().strip():'),
                     ('__main__.py', 'window.close()')],
    'audit/runtime': [('backend.py', 'def _remove_scratch'), ('backend.py', 'output-check-failed'),
                     ('runtime_discovery.py', 'entry.name.casefold().startswith(prefix)'),
                     ('diagnostics.py', 'def redact_log')],
    'chatgpt/deferred-audit-fixes-1': [('backend.py', 'def _snapshot_input'),
                                    ('ingestion.py', 'def _validate_pe_prefix'),
                                    ('service.py', 'analysis run already has a prepared import'),
                                    ('secondary/cli_import.py', 'def _secondary_run')],
    'feat/alpha-ui-integration': [('artifact_inspection.py', 'def inspect_project_artifacts'),
                                ('raw_view.py', 'def build_side'),
                                ('ui_inspection.py', 'class FilesController'),
                                ('ui.py', 'if key != self._project_inspection_key():')],
    'feat/artifact-bytes-seam': [('artifact_bytes.py', 'class VerifiedArtifactReader'),
                               ('artifact_bytes.py', 'VERIFY_BLOCK_BYTES =')],
    'feat/byte-representations': [('representations/scope.py', 'class ByteScope'),
                                ('representations/paging.py', 'def read_page'),
                                ('representations/render.py', 'def render_page')],
    'feat/local-runtime-discovery': [('runtime_discovery.py', 'def discover_local_runtimes'),
                                    ('runtime_discovery.py', 'def _ordered'),
                                    ('ui.py', '_DISCOVERY_THREADS.add(thread)')],
    'feat/tooltip-registry': [('tooltips.py', 'REGISTRY: dict'), ('tooltips.py', 'def template('),
                              ('gui/tips.py', 'def apply_tip(')],
    'feature/alpha-file-overview-20261013': [('preflight.py', 'def overview_rows'),
                                          ('ui_inspection.py', 'def recorded_rows'),
                                          ('ui.py', 'files.refresh()')],
    'feature/gui-inspection-preview': [('ui.py', 'def navigate_hunk'),
                                      ('ui.py', 'No further changed functions in the current filtered list.'),
                                      ('tooltips.py', "'viewer.older_code':")],
    'fix/backend-exit-diagnostics': [('diagnostics.py', 'def describe_backend_exit'),
                                    ('backend.py', 'describe_backend_exit(result.returncode, sanitized_log)')],
    'fix/explicit-offline-symbol-policy': [('backend.py', 'allow_symbol_downloads: bool = False'),
                                          ('ui_symbols.py', 'def effective_profile_symbol_mode'),
                                          ('backend.py', "'--no-symbols'")],
    'claude/symbol-policy-isolated-settings': [('backend.py', "'XDG_CONFIG_HOME'"),
                                              ('backend.py', "'ghidra-settings'"),
                                              ('diagnostics.py', 'PDB')],
    'fix/pe-inspection-row-tooltips-20261013': [('tooltips.py', "'overview.pe_row':"),
                                              ('ui_inspection.py', 'def pe_rows'),
                                              ('ui_inspection.py', 'return row.tip')],
    'chatgpt/ghidriff-sequential-lock-fix-20261017': [('backend.py', 'def _ghidriff_argv'),
                                                  ('backend.py', "'--no-threaded'"),
                                                  ('backend.py', "RAW_ADAPTER_VERSION = 'patchtrace-ghidriff-adapter/2'")],
    'fix/ghidra-dot-paths': [('backend.py', 'def _validated_ghidra_output_path'),
                            ('backend.py', "f'runs/quarantine-{run.id}'")],
    'fix/isolate-ghidra-scratch': [('backend.py', "tempfile.mkdtemp(prefix='patchtrace-ghidra-'")],
    'fix/codetext-budget-wave3': [('ui_codetext.py', 'self.setCurrentBlockState(-1)'),
                                 ('ui_codetext.py', 'def spans('),
                                 ('@tools/rzdiff/native_control.c', 'static int check_distinct')],
}

def proof(item):
    rel, needle = item
    path = rel[1:] if rel.startswith('@') else 'src/patchtrace/' + rel
    current = source(BASE, path)
    assert current is not None and needle in current, (path, needle)
    history = []
    commits = git('log', '--full-history', '-m', '--reverse', '--format=%H',
                  '-S' + needle, BASE, '--', path).splitlines()
    for sha in dict.fromkeys(commits):
        parents = git('rev-list', '--parents', '-n', '1', sha).split()[1:]
        value = source(sha, path)
        parent_value = source(parents[0], path) if parents else None
        history.append({
            'sha': sha, 'subject': git('show', '-s', '--format=%s', sha),
            'is_ancestor_of_comparison': subprocess.run(
                ['git', 'merge-base', '--is-ancestor', sha, BASE], cwd=ROOT, check=False).returncode == 0,
            'needle_present_in_commit': value is not None and needle in value,
            'needle_present_in_first_parent': parent_value is not None and needle in parent_value,
            'parent_presence': [{'sha': parent, 'needle_present': needle in (source(parent, path) or '')}
                                for parent in parents],
        })
    return {
        'path': path, 'needle': needle,
        'current_lines': [i for i, line in enumerate(current.splitlines(), 1) if needle in line],
        'current_blob': git('rev-parse', BASE + ':' + path),
        'current_sha256': hashlib.sha256(current.encode()).hexdigest(),
        'history': history,
    }

with ThreadPoolExecutor(max_workers=4) as pool:
    captured = dict(zip(PROOFS, pool.map(lambda items: list(map(proof, items)), PROOFS.values()), strict=True))

def named_dict(text, name):
    for node in ast.parse(text).body:
        if isinstance(node, ast.AnnAssign) and isinstance(node.target, ast.Name) and node.target.id == name:
            return {ast.literal_eval(key): ast.dump(value, include_attributes=False)
                    for key, value in zip(node.value.keys, node.value.values, strict=True)}
    raise AssertionError(name)

tip = next(row['tip'] for row in SNAPSHOT['branches'] if row['branch'] == 'feat/tooltip-registry')
tip_tips, current_tips = source(tip, 'src/patchtrace/tooltips.py'), source(BASE, 'src/patchtrace/tooltips.py')
registries = {}
for name in ('REGISTRY', 'TEMPLATES'):
    old, new = named_dict(tip_tips, name), named_dict(current_tips, name)
    registries[name] = {
        'tip_count': len(old), 'current_static_count': len(new),
        'removed_ids': sorted(old.keys() - new.keys()), 'added_ids': sorted(new.keys() - old.keys()),
        'same_ast_ids': sorted(key for key in old.keys() & new.keys() if old[key] == new[key]),
        'changed_copy_ids': sorted(key for key in old.keys() & new.keys() if old[key] != new[key]),
        'note': 'Only statically declared IDs here. Panel registrations and actual widget bindings are verified by the existing current global sweep; equality of copy alone is not widget coverage.',
    }

result = {
    'baseline': BASE, 'tree': SNAPSHOT['comparison_tree'],
    'meaning': 'History records prove exact code text at ancestral commits and current locations. Human branch dispositions also inspect guards, callers and current tests. These records do not claim whole-branch patch equivalence.',
    'branches': [{'branch': name, 'proofs': items} for name, items in captured.items()],
    'tooltip_static_identity': registries,
}
(OUT / 'replacement-provenance.json').write_text(json.dumps(result, indent=2) + '\n')
for name, items in captured.items():
    print(name, [(item['path'], [h['sha'][:10] for h in item['history'] if h['needle_present_in_commit']]) for item in items])
print('tooltip IDs', {name: {'old': data['tip_count'], 'current': data['current_static_count'],
                             'removed': data['removed_ids'], 'changed': data['changed_copy_ids']}
                       for name, data in registries.items()})
