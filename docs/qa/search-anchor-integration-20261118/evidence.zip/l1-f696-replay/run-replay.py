"""One bounded, exclusive offline replay of frozen real metadata; no production edits."""
from __future__ import annotations

import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/e83fbf4505c3')
SOURCE = ROOT / 'l1-replay-final304-source-f69614fa'
SNAPSHOT = ROOT / 'l1-live-snapshot'
OUTPUT = ROOT / 'l1-replay-final304-20261118'
PYTHON = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
HEAD = 'f69614fa6b5bb9d25d4233b06a4c4ce179964a52'
TREE = '6585b91ab746f7615c614efea831a119f34ae8d2'
FROZEN = 'b27775b781db126675565eee5ee008d5854dbf99887726295e7c7c1982e4f487'


def git(*arguments: str) -> str:
    return subprocess.check_output(['git', *arguments], cwd=SOURCE, text=True).strip()


assert git('rev-parse', 'HEAD') == HEAD
assert git('rev-parse', 'HEAD^{tree}') == TREE
assert not git('status', '--porcelain=v1', '--untracked-files=all')
assert not (OUTPUT / 'file-receipt.json').exists()
assert not (OUTPUT / 'execution-receipt.json').exists()

arguments = [
    PYTHON, '-m', 'tools.research_qualification', 'l1-run',
    str(SNAPSHOT / 'frozen-manifest.json'),
    '--months', str(SNAPSHOT / 'months'),
    '--frozen-sha', FROZEN,
    '--evidence-class', 'live',
    '--winbindex', str(SNAPSHOT / 'winbindex'),
    '--winbindex-date', '2026-11-18',
    '--out', str(OUTPUT / 'file-receipt.json'),
]
overrides = {
    'RQ_ALLOWED_DIRS': str(SNAPSHOT) + os.pathsep + str(OUTPUT),
    'PYTHONDONTWRITEBYTECODE': '1',
    'PYTHONPATH': 'src:.',
    'QT_QPA_PLATFORM': 'offscreen',
}
environment = os.environ.copy()
environment.update(overrides)
started = datetime.datetime.now(datetime.UTC).isoformat()
clock = time.monotonic()
timed_out = False
with (OUTPUT / 'stdout.log').open('xb') as stdout, (OUTPUT / 'stderr.log').open('xb') as stderr:
    process = subprocess.Popen(arguments, cwd=SOURCE, env=environment, stdout=stdout, stderr=stderr)
    try:
        exit_code = process.wait(timeout=600)
    except subprocess.TimeoutExpired:
        timed_out = True
        process.kill()
        exit_code = process.wait()

receipt = {
    'started_at': started,
    'finished_at': datetime.datetime.now(datetime.UTC).isoformat(),
    'elapsed_seconds': time.monotonic() - clock,
    'argv': arguments,
    'cwd': str(SOURCE),
    'environment_overrides': overrides,
    'timeout_seconds': 600,
    'timed_out': timed_out,
    'exit_code': exit_code,
    'source_commit': HEAD,
    'source_tree': TREE,
    'source_commit_after': git('rev-parse', 'HEAD'),
    'source_tree_after': git('rev-parse', 'HEAD^{tree}'),
    'source_clean_after': not git('status', '--porcelain=v1', '--untracked-files=all'),
    'fresh_source_retrieval': False,
    'target_acquisition': False,
    'target_execution': False,
    'scope': 'Existing frozen real-source L1 expected-filename resolvability regression replay',
    'outputs': {},
}
for name in ('stdout.log', 'stderr.log', 'file-receipt.json'):
    path = OUTPUT / name
    if path.exists():
        content = path.read_bytes()
        receipt['outputs'][name] = {'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}
with (OUTPUT / 'execution-receipt.json').open('x') as stream:
    json.dump(receipt, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps(receipt, indent=2, sort_keys=True), flush=True)
sys.exit(exit_code if exit_code >= 0 else 1)
