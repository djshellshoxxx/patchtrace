"""Independent review guard: verify imported production source before tests."""
import json
import os
from pathlib import Path

def pytest_sessionstart(session):
    import patchtrace.search.anchors as anchors
    expected = Path(os.environ["PATCHTRACE_REVIEW_SOURCE"]).resolve()
    actual = Path(anchors.__file__).resolve()
    if not actual.is_relative_to(expected / "src"):
        raise RuntimeError(f"Wrong review source: {actual}; expected {expected}")
    print("REVIEW_SOURCE " + json.dumps({"anchors_module": str(actual), "expected_checkout": str(expected)}, sort_keys=True))

