"""Read-only cross-head search review; constructs synthetic inputs outside the worktrees."""
from __future__ import annotations

import dataclasses
import hashlib
import io
import json
import os
import tempfile
from pathlib import Path
from types import SimpleNamespace

from search_builders import make_service
from patchtrace.enrichment.identity import domain_id
from patchtrace.enrichment.storage import EnrichmentStore
from patchtrace.intelligence.anchors import anchors_for
from patchtrace.intelligence.contracts import Anchor
from patchtrace.intelligence.csaf import normalize, validate
from patchtrace.intelligence.storage import AdvisoryStore
from patchtrace.models import AnalystAnnotation
from patchtrace.search import anchors as anchor_module
from patchtrace.search import cli
from patchtrace.search.anchors import coverage_for, plan_for, plans_for, query_text
from patchtrace.search.service import SearchService
from patchtrace.search.sources.advisory import advisory_specs
from patchtrace.service import ProjectService

CHECKOUT = Path(os.environ["PATCHTRACE_REVIEW_SOURCE"]).resolve()
assert Path(anchor_module.__file__).resolve().is_relative_to(CHECKOUT / "src")
FIXTURE = Path(os.environ["PATCHTRACE_REVIEW_BASE"]) / "tests/fixtures/csaf/synthetic-advisory-rev1.json"
CVE = "CVE-2099-10001"

def facts_for(title):
    body = json.loads(FIXTURE.read_bytes())
    body["vulnerabilities"][0]["title"] = title
    raw = json.dumps(body).encode()
    parsed, validation = validate.load_document(raw)
    return raw, normalize.normalize(parsed, validation, hashlib.sha256(raw).hexdigest())

def anchor(kind, value):
    return Anchor(anchor_id=domain_id("anchor", 1, {"kind": kind, "value": value}),
                  kind=kind, value=value, source="csaf-title",
                  pointer="/vulnerabilities/0/title", quality="derived", label="review anchor")

def coverage(service, item):
    return dataclasses.asdict(coverage_for(plans_for([item]), lambda req: service.search(req, build=False))[0])

result = {"source_checkout": str(CHECKOUT), "anchors_module": str(Path(anchor_module.__file__).resolve())}
with tempfile.TemporaryDirectory(prefix="search-review-", dir=os.environ["PATCHTRACE_REVIEW_OUTPUT"]) as tmp:
    tmp = Path(tmp)
    raw, facts = facts_for("ReviewOnlyModule.sys Elevation of Privilege Vulnerability")
    stored = SimpleNamespace(facts=facts, source=SimpleNamespace(retrieved_at="2099-03-01T00:00:00Z"),
                             superseded=False)
    port = SimpleNamespace(advisories=lambda: ([stored], []))
    service = SearchService(make_service(tmp / "advisory-project"), tmp / "advisory-cache",
                            extra_specs=lambda req: advisory_specs(port, None))
    service.build()
    actual = next(a for a in anchors_for(CVE, [facts]).anchors
                  if a.kind == "module" and a.value == "reviewonlymodule.sys")
    result["parsed_advisory_only_module"] = coverage(service, actual)
    result["advisory_only_by_anchor_kind"] = {kind: coverage(service, anchor(kind, actual.value))
                                            for kind in ("module", "feature", "component", "api")}
    result["binary_controls"] = {value: coverage(service, anchor("api", value))
                                for value in ("CheckLength", "MainLoop")}

    project = make_service(tmp / "notes-project")
    project.project.annotations.append(AnalystAnnotation(id="review-note", target_id="m-mod",
                                                       kind="note", text="reviewnoteonly.sys"))
    service = SearchService(project, tmp / "notes-cache")
    service.build()
    result["default_groups_note_only"] = coverage(service, anchor("module", "reviewnoteonly.sys"))

    long_value = "Component" + "A" * 151
    _, long_facts = facts_for(long_value + " Elevation of Privilege Vulnerability")
    long_anchor = next(a for a in anchors_for(CVE, [long_facts]).anchors
                       if a.kind == "component" and a.value == long_value)
    project = make_service(tmp / "long-project")
    target = next(m for m in project.project.matches if m.id == "m-add").newer[0]
    target.code = 'int CheckLength(int n) { const char *component = "' + long_value + '"; return n; }'
    service = SearchService(project, tmp / "long-cache")
    service.build()
    result["long_component_binary_match"] = {
        "value_length": len(long_value),
        "query_length": len(query_text(long_anchor, changed=True)),
        "query": query_text(long_anchor, changed=True),
        "coverage": coverage(service, long_anchor),
    }
    result["largest_accepted_component_value_length"] = max(
        n for n in range(1, 257) if plan_for(anchor("component", "A" * n)).plan is not None)
    result["kind_filters"] = {kind: list(plan_for(anchor(kind, "token")).plan.kinds)
                              for kind in ("module", "feature", "component", "api", "string", "pdb")}
    injected = plan_for(anchor("component", 'literal kind:advisory -token " OR code')).plan
    result["quoted_syntax"] = {"kinds": list(injected.kinds), "excludes": list(injected.excludes),
                               "terms": len(injected.terms), "phrases": list(injected.phrases)}

    with ProjectService.sample(tmp / "stored-project") as saved:
        AdvisoryStore(saved.root, EnrichmentStore(saved.store), saved.project.id, saved.project.revision).add(
            raw, origin="local-import", uri=None, file_name="synthetic.json", retrieved_at="2099-03-01T00:00:00Z")
    out, err = io.StringIO(), io.StringIO()
    code = cli.main([str(tmp / "stored-project"), "--anchors-from", CVE,
                     "--cache-dir", str(tmp / "stored-cache"), "--json"], stdout=out, stderr=err)
    result["default_stored_advisory_cli"] = {"exit_code": code, "stdout": json.loads(out.getvalue()),
                                            "stderr": err.getvalue()}
print(json.dumps(result, indent=2, sort_keys=True))

