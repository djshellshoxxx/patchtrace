"""Independent controls for the frozen search repair; actual synthetic source and store paths."""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path

import pytest
from search_builders import make_service

from patchtrace.enrichment.storage import EnrichmentStore
from patchtrace.intelligence.anchors import anchors_for
from patchtrace.intelligence.csaf import normalize, validate
from patchtrace.intelligence.storage import AdvisoryStore
from patchtrace.search import cli
from patchtrace.search.anchors import coverage_for, plan_for
from patchtrace.search.contracts import QueryPlan
from patchtrace.search.service import SearchService
from patchtrace.service import ProjectService

CVE = "CVE-2099-10001"
FIXTURE = Path(__import__("search_builders").__file__).parent / "fixtures/csaf/synthetic-advisory-rev1.json"
KINDS = ("asm", "build", "capability", "code", "export", "function", "import", "rule", "string")


def _advisory(value):
    payload = json.loads(FIXTURE.read_bytes())
    payload["vulnerabilities"][0]["title"] = value + " Elevation of Privilege Vulnerability"
    raw = json.dumps(payload).encode()
    parsed, report = validate.load_document(raw)
    facts = normalize.normalize(parsed, report, hashlib.sha256(raw).hexdigest())
    item = next(a for a in anchors_for(CVE, [facts]).anchors if a.kind == "component" and a.value == value)
    return raw, item


@pytest.mark.parametrize("changed", [True, False], ids=["changed", "indexed-only"])
def test_240_character_actual_component_is_found_in_the_correct_scope(tmp_path, changed):
    value = "Component" + "Z" * 231
    _, anchor = _advisory(value)
    source = make_service(tmp_path / "project")
    match = next(m for m in source.project.matches if m.id == ("m-add" if changed else "m-same"))
    code = 'void Review() { const char *s = "' + value + '"; }'
    for function in (*match.older, *match.newer):
        function.code = code
    search = SearchService(source, tmp_path / "cache")
    search.build()
    plan = plan_for(anchor)
    assert plan.plan is not None and len(plan.plan.text) == 256
    assert plan.plan.kinds == KINDS
    assert QueryPlan.model_validate_json(plan.plan.model_dump_json()) == plan.plan
    (result,) = coverage_for([plan], lambda req: search.search(req, build=False))
    assert result.status == ("changed" if changed else "indexed-only")
    assert result.hits == 1


@pytest.mark.parametrize("changed,length,accepted", [(True, 241, False), (False, 254, True), (False, 255, False)])
def test_original_changed_and_indexed_boundaries_do_not_expand(changed, length, accepted):
    _, anchor = _advisory("A" * length)
    plan = plan_for(anchor, changed=changed)
    if accepted:
        assert plan.plan is not None
        assert len(plan.plan.text) == 256 and plan.plan.kinds == KINDS
        assert QueryPlan.model_validate_json(plan.plan.model_dump_json()) == plan.plan
    else:
        assert plan.plan is None
        assert "256 characters" in plan.reason

        def forbidden_query(_request):
            raise AssertionError("An over-budget anchor must not execute a search")

        (result,) = coverage_for([plan], forbidden_query)
        assert result.status == "not-searchable" and result.hits == 0


def _invoke(project, cache):
    out, err = io.StringIO(), io.StringIO()
    code = cli.main([str(project), "--anchors-from", CVE, "--cache-dir", str(cache), "--json"],
                    stdout=out, stderr=err)
    return code, json.loads(out.getvalue()), err.getvalue()


def test_default_stored_source_is_read_without_reopening_or_changing_the_project(tmp_path):
    project, cache = tmp_path / "project", tmp_path / "cache"
    raw, _ = _advisory("IndependentOnly.sys")
    with ProjectService.sample(project) as owner:
        store = AdvisoryStore(owner.root, EnrichmentStore(owner.store), owner.project.id, owner.project.revision)
        store.add(raw, origin="local-import", uri=None, file_name="synthetic.json",
                  retrieved_at="2099-03-01T00:00:00Z")
        expected_project = owner.project.model_dump(mode="json")
        expected_facts = [a.facts.facts_id for a in store.for_cve(CVE)[0]]
    first = _invoke(project, cache)
    second = _invoke(project, cache)
    assert first == second
    code, document, error = first
    assert code == 3 and error == ""
    assert document["status"] == "partial" and "error" not in document
    modules = [a for a in document["result"]["anchors"] if a["kind"] == "module"]
    chosen = next(a for a in modules if a["value"] == "independentonly.sys")
    assert chosen["status"] == "unknown" and chosen["hits"] == 0
    with ProjectService.open(project) as reopened:
        assert reopened.project.model_dump(mode="json") == expected_project
        store = AdvisoryStore(reopened.root, EnrichmentStore(reopened.store),
                              reopened.project.id, reopened.project.revision)
        assert [a.facts.facts_id for a in store.for_cve(CVE)[0]] == expected_facts

