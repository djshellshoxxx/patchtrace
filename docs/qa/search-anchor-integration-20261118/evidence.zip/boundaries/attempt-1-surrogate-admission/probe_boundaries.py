"""Read-only source review with synthetic metadata and temporary authored fixtures."""
from __future__ import annotations

import argparse
import json
from pathlib import Path
import socket
import tempfile
import unicodedata

from search_builders import make_service

from patchtrace.intelligence.contracts import Anchor
from patchtrace.search.anchors import plan_for, query_text
from patchtrace.search.contracts import QueryPlan, SearchRequest
from patchtrace.search.errors import SearchError
from patchtrace.search.query import parse_query
from patchtrace.search.service import SearchService


BINARY = ('asm', 'build', 'capability', 'code', 'export', 'function', 'import', 'rule', 'string')
KINDS = ('module', 'feature', 'component', 'api', 'pdb', 'string')
OVERRIDES = {'pdb': ('build',), 'string': ('string',)}


def anchor(kind, value):
    return Anchor(anchor_id='a' * 64, kind=kind, value=value, source='csaf-title',
                  quality='derived', label='independent boundary control')


def summarize(kind, value, changed):
    item = anchor(kind, value)
    text = query_text(item, changed=changed)
    result = plan_for(item, changed=changed)
    return {
        'kind': kind, 'changed': changed, 'input_chars': len(value),
        'nfc_chars': len(unicodedata.normalize('NFC', value)),
        'query_text': text, 'query_chars': len(text), 'searchable': result.plan is not None,
        'reason': result.reason,
        'plan': None if result.plan is None else result.plan.model_dump(mode='json'),
        'digest': None if result.plan is None else result.plan.digest(),
    }


def run():
    def offline(*args, **kwargs):
        raise AssertionError('independent search controls are offline')
    for name in ('socket', 'create_connection', 'getaddrinfo'):
        setattr(socket, name, offline)

    result = {'boundary_cases': [], 'quote_cases': [], 'invalid_cases': [], 'digest_cases': []}
    for kind in KINDS:
        for changed in (True, False):
            overhead = 2 + (14 if changed else 0) + {'pdb': 11, 'string': 12}.get(kind, 0)
            boundary = 256 - overhead
            for form, character in (('ascii', 'A'), ('NFC', '\u00e9'), ('NFD', 'e\u0301')):
                for length in (boundary - 1, boundary, boundary + 1):
                    case = summarize(kind, character * length, changed)
                    case.update(form=form, normalized_payload_length=length,
                                original_boundary=boundary, expected_searchable=length <= boundary)
                    result['boundary_cases'].append(case)

    literal = 'kind:advisory\t" scope:indexed -omit* OR (literal) \nside:older'
    for kind in KINDS:
        result['quote_cases'].append(summarize(kind, literal, True))

    for label, value in (('zero_width', 'a\u200bb'), ('bidi', 'a\u202eb'),
                         ('private_use', 'a\ue000b'), ('null', 'a\x00b'),
                         ('surrogate', 'a\ud800b'), ('only_quotes', '"""')):
        result['invalid_cases'].append({'label': label, **summarize('component', value, True)})

    for kind in KINDS:
        plan = plan_for(anchor(kind, 'ReviewSentinel')).plan
        kinds = OVERRIDES.get(kind, BINARY)
        explicit = parse_query(' '.join(f'kind:{k}' for k in kinds) +
                               ' scope:changed "ReviewSentinel"', mode='words')
        result['digest_cases'].append({
            'kind': kind, 'plan_digest': plan.digest(), 'explicit_digest': explicit.digest(),
            'equal': plan.digest() == explicit.digest(), 'plan_kinds': list(plan.kinds),
            'json_round_trip': QueryPlan.model_validate_json(plan.model_dump_json()) == plan,
            'scope_digest_changes': plan.digest() != plan.model_copy(update={'scope': 'indexed'}).digest(),
        })

    result['plain_query_bound'] = []
    for length in (256, 257):
        try:
            parsed = parse_query('A' * length)
            result['plain_query_bound'].append({'length': length, 'accepted': True, 'text_chars': len(parsed.text)})
        except SearchError as exc:
            result['plain_query_bound'].append({'length': length, 'accepted': False, 'code': exc.code, 'message': exc.message})

    with tempfile.TemporaryDirectory(prefix='search-boundary-review-') as directory:
        root = Path(directory)
        project = make_service(root / 'project')
        for match in project.project.matches:
            if match.id in ('m-mod', 'm-add'):
                match.newer[0].code = 'int ReviewControl(void) { return ReviewCursorSentinel(); }'
        service = SearchService(project, root / 'cache')
        plan = plan_for(anchor('component', 'ReviewCursorSentinel')).plan
        request = SearchRequest(plan=plan, limit=1, expand=False)
        first = service.search(request)
        assert first.total == 2 and first.cursor and len(first.hits) == 1
        explicit = parse_query(' '.join(f'kind:{k}' for k in BINARY) +
                               ' scope:changed "ReviewCursorSentinel"', mode='words')
        equivalent_text = QueryPlan.model_validate(plan.model_dump() | {'text': 'Display-only explanation'})
        alternatives = [('same_plan', plan), ('display_text_only', equivalent_text),
                        ('explicit_closed_kinds', explicit),
                        ('different_kinds', QueryPlan.model_validate(plan.model_dump() | {'kinds': ('string',)})),
                        ('different_scope', QueryPlan.model_validate(plan.model_dump() | {'scope': 'indexed'}))]
        result['cursor'] = {'first_total': first.total, 'first_hit': first.hits[0].hit_id,
                            'first_plan_digest': plan.digest(), 'attempts': []}
        for label, alternate in alternatives:
            try:
                page = service.search(SearchRequest(plan=alternate, limit=1, expand=False,
                                                    cursor=first.cursor), build=False)
                result['cursor']['attempts'].append({
                    'label': label, 'accepted': True, 'hit_ids': [hit.hit_id for hit in page.hits],
                    'distinct_from_first': all(hit.hit_id != first.hits[0].hit_id for hit in page.hits),
                    'plan_digest': alternate.digest(),
                })
            except SearchError as exc:
                result['cursor']['attempts'].append({'label': label, 'accepted': False,
                                                     'code': exc.code, 'message': exc.message,
                                                     'plan_digest': alternate.digest()})
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    output = run()
    args.output.write_text(json.dumps(output, indent=2, ensure_ascii=True) + '\n')
    print(json.dumps({'output': str(args.output), 'boundary_cases': len(output['boundary_cases']),
                      'boundary_deviations': sum(c['searchable'] != c['expected_searchable']
                                                 for c in output['boundary_cases']),
                      'cursor_attempts': output['cursor']['attempts']}, indent=2))
