from pathlib import Path
import json


root = Path(__file__).resolve().parent
base, incoming, fixed = (json.loads((root / name).read_text()) for name in
                         ('base-f69614fa.json', 'pr306-f6ef1528.json', 'repair-b9fac06b.json'))
binary = ['asm', 'build', 'capability', 'code', 'export', 'function', 'import', 'rule', 'string']
overrides = {'pdb': ['build'], 'string': ['string']}
identical_override_count = 0
for old, candidate, repaired in zip(base['boundary_cases'], incoming['boundary_cases'], fixed['boundary_cases'], strict=True):
    assert repaired['searchable'] == repaired['expected_searchable'] == old['searchable']
    assert repaired['query_text'] == old['query_text']
    assert repaired['reason'] == old['reason']
    if repaired['plan'] is not None:
        expected = old['plan'] | {'kinds': overrides.get(old['kind'], binary)}
        assert repaired['plan'] == expected
        assert len(repaired['plan']['text']) <= 256
    if repaired['kind'] in overrides:
        assert old == candidate == repaired
        identical_override_count += 1

for old, repaired in zip(base['quote_cases'], fixed['quote_cases'], strict=True):
    assert repaired['searchable']
    plan = repaired['plan']
    assert plan['phrases'] == ['kind:advisory scope:indexed -omit* OR (literal) side:older']
    assert plan['terms'] == plan['excludes'] == plan['identity'] == []
    assert plan['scope'] == 'changed'
    assert plan['kinds'] == overrides.get(repaired['kind'], binary)
    assert repaired['query_text'] == old['query_text']

assert base['invalid_cases'] == fixed['invalid_cases']
assert all(not case['searchable'] for case in fixed['invalid_cases'])
assert all(case['equal'] and case['json_round_trip'] and case['scope_digest_changes']
           for case in fixed['digest_cases'])
assert base['plain_query_bound'] == incoming['plain_query_bound'] == fixed['plain_query_bound']
assert [case['accepted'] for case in fixed['plain_query_bound']] == [True, False]
attempts = {case['label']: case for case in fixed['cursor']['attempts']}
for label in ('same_plan', 'display_text_only', 'explicit_closed_kinds'):
    assert attempts[label]['accepted'] and attempts[label]['distinct_from_first']
for label in ('different_kinds', 'different_scope'):
    assert not attempts[label]['accepted'] and attempts[label]['code'] == 'PT-SEARCH-STALE'
assert incoming['cursor'] == fixed['cursor']

report = {
    'frozen_repair_boundary_cases': len(fixed['boundary_cases']),
    'original_vs_repair_boundary_deviations': 0,
    'incoming_boundary_deviations': sum(c['searchable'] != c['expected_searchable']
                                       for c in incoming['boundary_cases']),
    'exact_three_head_pdb_string_cases': identical_override_count,
    'quoted_literal_cases': len(fixed['quote_cases']),
    'unchanged_invalid_input_refusals': len(fixed['invalid_cases']),
    'typed_digest_and_round_trip_cases': len(fixed['digest_cases']),
    'real_cursor_controls': len(attempts),
    'plain_query_limit_unchanged': True,
    'result': 'PASS',
}
(root / 'comparison.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
