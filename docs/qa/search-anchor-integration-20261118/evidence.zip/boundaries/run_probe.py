from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys


evidence = Path(__file__).resolve().parent
source, label = Path(sys.argv[1]), sys.argv[2]
python = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
environment = {'PYTHONDONTWRITEBYTECODE': '1', 'QT_QPA_PLATFORM': 'offscreen',
               'PYTHONPATH': f'{source}/src:{source}:{source}/tests'}
argv = [python, str(evidence / 'probe_boundaries.py'), '--output', str(evidence / f'{label}.json')]


def git(*args):
    return subprocess.check_output(['git', *args], cwd=source, text=True).strip()


receipt = {'argv': argv, 'cwd': str(evidence), 'environment_overrides': environment,
           'source_path': str(source), 'source_head': git('rev-parse', 'HEAD'),
           'source_tree': git('rev-parse', 'HEAD^{tree}'), 'source_status_before': git('status', '--porcelain=v1'),
           'timeout_seconds': 60, 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
result = subprocess.run(argv, cwd=evidence, env=os.environ | environment, capture_output=True, timeout=60)
receipt.update(exit_code=result.returncode, finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               source_status_after=git('status', '--porcelain=v1'))
for stream, data in (('stdout', result.stdout), ('stderr', result.stderr)):
    (evidence / f'{label}.{stream}.log').write_bytes(data)
    receipt[f'{stream}_sha256'] = hashlib.sha256(data).hexdigest()
(evidence / f'{label}.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(label, result.returncode)
print(result.stdout.decode('utf-8'))
print(result.stderr.decode('utf-8'))
sys.exit(result.returncode)
