"""Current-source authored CLI observation; source files are synthetic and never executed."""
from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import os
import subprocess

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch2')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch2/named-superseded-cli')
OUT.mkdir(exist_ok=True)
PYTHON = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
SOURCE = '3be3af166897fc2376dc64850edc66485273dea1'


def document(kb, date):
    return json.dumps({
        'dialect': 'cvrf-json/0',
        'document': {'release_id': '2099-Feb', 'current_release_date': date},
        'product_tree': [{'product_id': 'P1', 'name': 'Windows 11 Version 24H2 for x64-based Systems'}],
        'vulnerabilities': [{'cve': 'CVE-2099-0001', 'remediations': [
            {'type': 2, 'description': kb, 'product_ids': ['P1']}]}],
    }).encode()


older = OUT / 'older.json'
newer = OUT / 'newer.json'
older.write_bytes(document('KB5099001', '2099-02-13T00:00:00Z'))
newer.write_bytes(document('KB5099002', '2099-03-05T00:00:00Z'))
old_id = hashlib.sha256(older.read_bytes()).hexdigest()
new_id = hashlib.sha256(newer.read_bytes()).hexdigest()
(OUT / 'old-scope.json').write_text(json.dumps({'doc_ids': [old_id]}))
(OUT / 'new-scope.json').write_text(json.dumps({'doc_ids': [new_id]}))
env = dict(os.environ, PYTHONPATH=str(ROOT / 'src'))
guard = ('import sys; from patchtrace.cli import main; code=main(sys.argv[1:]); '
         'assert not any(n.startswith("PySide6") for n in sys.modules); sys.exit(code)')
commands = [
    ('import', ['index', 'import', str(older), str(newer), '--json']),
    ('named-old-json', ['search', 'KB5099001', '--offline', '--scope-file', str(OUT / 'old-scope.json'), '--json']),
    ('named-old-text', ['search', 'KB5099001', '--offline', '--scope-file', str(OUT / 'old-scope.json')]),
    ('named-new-json', ['search', 'KB5099002', '--offline', '--scope-file', str(OUT / 'new-scope.json'), '--json']),
    ('cached-old-json', ['search', 'KB5099001', '--offline', '--json']),
]
records = []
for label, arguments in commands:
    command = [PYTHON, '-c', guard, 'kb', *arguments, '--workspace', str(OUT / 'workspace')]
    result = subprocess.run(command, cwd=ROOT, env=env, capture_output=True, text=True)
    (OUT / (label + '.stdout')).write_text(result.stdout)
    (OUT / (label + '.stderr')).write_text(result.stderr)
    records.append({'label': label, 'command': command, 'exit_code': result.returncode,
                    'stdout': label + '.stdout', 'stderr': label + '.stderr'})
    assert result.stderr == '', (label, result.stderr)
assert [r['exit_code'] for r in records] == [0, 4, 4, 0, 4]
old = json.loads((OUT / 'named-old-json.stdout').read_text())
new = json.loads((OUT / 'named-new-json.stdout').read_text())
assert old['result']['edges'] == []
assert any(w.startswith('SUPERSEDED') for w in old['warnings'])
assert not any(w.startswith('NAMED_SUPERSEDED') for w in old['warnings'])
assert 'these documents do not list it' in (OUT / 'named-old-text.stdout').read_text()
assert len(new['result']['edges']) == 1
receipt = {'source': SOURCE, 'generated_at': datetime.now(UTC).isoformat(),
           'env': {'PYTHONPATH': env['PYTHONPATH']}, 'older_doc_id': old_id, 'newer_doc_id': new_id,
           'commands': records,
           'finding': 'Selected superseded source is withheld correctly; named-source warning absent. '
                      'JSON carries generic superseded warning; plain CLI text omits all warnings and says '
                      'the checked documents do not list the selected source hit.',
           'source_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (older, newer)}}
(OUT / 'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print('Five actual headless CLI commands observed; withholding unchanged, selected-file explanation absent.')
