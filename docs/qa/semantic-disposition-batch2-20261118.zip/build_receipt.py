"""Build the durable, docs-only semantic-disposition packet from retained evidence."""
from collections import Counter
from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import re
import subprocess
from xml.etree import ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch2')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch2')
PLAN = ROOT / 'docs/plans/autonomous-consolidation-20261118'
QA = ROOT / 'docs/qa'
BASE = '3be3af166897fc2376dc64850edc66485273dea1'
snapshot = json.loads((OUT / 'snapshot.json').read_text())
notes = json.loads((OUT / 'dispositions.json').read_text())
symbols = json.loads((OUT / 'symbol-comparison.json').read_text())
provenance = json.loads((OUT / 'replacement-provenance.json').read_text())
inventory = json.loads((PLAN / 'branch-inventory.json').read_text())
batch1 = json.loads((PLAN / 'semantic-disposition-batch1.json').read_text())
assert snapshot['comparison_base'] == BASE
assert set(notes) == {row['branch'] for row in snapshot['branches']}
assert all(row['tip_matches_inventory'] for row in snapshot['branches'])
assert len(snapshot['branches']) == 20
assert not subprocess.check_output(['git', 'diff', '--name-only', BASE, '--', 'src', 'tests', 'tools'], cwd=ROOT)
for entry in notes.values():
    assert all((ROOT / path).is_file() for path in entry['specs'])
    assert all((ROOT / 'tests' / path).is_file() for path in entry['tests'])


def gate(name, *, role):
    tree = ET.parse(OUT / (name + '.xml')).getroot()
    suite = tree if tree.tag == 'testsuite' else tree.find('testsuite')
    n = {key: int(suite.attrib[key]) for key in ('tests', 'failures', 'errors', 'skipped')}
    n['passed'] = n['tests'] - n['failures'] - n['errors'] - n['skipped']
    n['seconds'] = float(suite.attrib['time'])
    n['seconds_kind'] = 'JUnit suite time'
    summary = (OUT / (name + '.log')).read_text().splitlines()[-1]
    n['pytest_summary'] = summary
    duration = re.search(r' in ([0-9.]+)s$', summary)
    n['pytest_reported_seconds'] = float(duration[1]) if duration else None
    skips, failures = [], []
    for case in tree.iter('testcase'):
        if case.find('skipped') is not None:
            skips.append({'test': case.attrib['classname'] + '::' + case.attrib['name'],
                          'reason': case.find('skipped').attrib.get('message', '')})
        if case.find('failure') is not None:
            failures.append({'test': case.attrib['classname'] + '::' + case.attrib['name'],
                             'message': case.find('failure').attrib.get('message', '')})
    return {'id': name, 'source': BASE, 'role': role, **n, 'skip_details': skips,
            'failure_details': failures, 'log': name + '.log', 'xml': name + '.xml'}


gates = [
    gate('current-affected', role='39 current replacement test files'),
    gate('current-audit-boundaries', role='4 additional current audit boundary files'),
    gate('historical-rules', role='15 unchanged original rule/callgraph controls replayed on current source'),
    gate('historical-acquisition', role='8 unchanged original acquisition controls replayed on current source'),
    gate('historical-kbc', role='30 unchanged original KB controls replayed on current source'),
    gate('named-superseded-red', role='Single initial omission reproduction; overlaps historical-kbc'),
]
assert [(g['passed'], g['failures'], g['errors'], g['skipped']) for g in gates] == [
    (955, 0, 0, 2), (139, 0, 0, 0), (15, 0, 0, 0), (7, 1, 0, 0), (28, 2, 0, 0), (0, 1, 0, 0)]

selected = set(notes)
prior = {row['branch'] for row in batch1['branches']}
remaining = [{'branch': row['branch'], 'tip': row['head_sha']}
             for row in inventory['branches']
             if row['classification'] == 'needs_reconciliation' and row['branch'] not in selected | prior]
assert len(remaining) == 91
branches = []
for index, row in enumerate(snapshot['branches'], 1):
    record = {**row, **notes[row['branch']], 'review_id': f'B2-{index:02d}',
              'branch_closure_or_deletion_authorized': False,
              'replacement_provenance': {group: provenance['groups'][group]
                                         for group in notes[row['branch']]['replacement_groups']}}
    syms = next(r['symbols'] for r in symbols['branches'] if r['branch'] == row['branch'])
    record['structural_comparison_summary'] = dict(Counter(s['status'] for s in syms))
    branches.append(record)

candidate = {
    'id': 'B2-C1', 'status': 'confirmed_explanation_omission_no_source_change',
    'title': 'Explain that an explicitly selected advisory source was superseded',
    'historical_source': '3f0df14d9d68dfd9523afd7f9e97482f9d7907ff',
    'overlapping_tips': ['280bf05856eb60f4ddb0d58210616f65a3735816', '798e11ef345ed7a7a65508a466eaf77ee85ef77c'],
    'current_seams': ['src/patchtrace/kbcorrelation/index.py::_lookup',
                      'src/patchtrace/kbcorrelation/index.py::_warnings',
                      'src/patchtrace/kbcorrelation/service.py::_search_outcome',
                      'src/patchtrace/kbcorrelation/cli_index.py::emit/present'],
    'observation': 'Pure lookup keeps status not_observed and the selected old hit in superseded. '
                   'The selected-document warning is missing. Actual CLI JSON returns unavailable/exit4 with '
                   'no edge and only a generic superseded warning; plain output says the selected documents do '
                   'not list the KB. A selected active-document positive succeeds.',
    'evidence': ['named-superseded-red.log', 'named-superseded-red.xml',
                 'historical-controls/coordinator-kbc/test_kbc_bugfixes_20261029.py',
                 'named-superseded-cli-final/receipt.json', 'named-superseded-cli-final/named-old-text.stdout'],
    'proposed_acceptance': [
        'Retain original historical test/red byte-for-byte, and add positive named-active and unscoped controls.',
        'Warn only about explicitly named selected-source hits withheld as superseded, with a bounded count/list of stable source IDs.',
        'Keep status, trusted edges, cards, applicability, native revision ambiguity and conflict precedence unchanged.',
        'Check pure lookup, actual JSON/text CLI and the existing presentation adapter. A warning stored only in Outcome.warnings is not visible in the current plain-text CLI.',
        'Cover mixed/provided-file scopes, unrelated superseded documents, product filtering and list truncation without new network/store/schema work.',
    ],
    'ownership': 'Separate follow-on proposed to root; no code edits or branch closure in this evidence batch.',
}

# Archive only reproducible evidence. Active SQLite lock files and generated Python caches are excluded.
payloads = {}
for path in sorted(OUT.rglob('*')):
    if not path.is_file() or path.name == 'manifest.json':
        continue
    if any(part in {'__pycache__', '.pytest_cache'} for part in path.relative_to(OUT).parts):
        continue
    if path.name.endswith(('.pyc', '.lock', '-wal', '-shm')):
        continue
    payloads[path.relative_to(OUT).as_posix()] = path.read_bytes()
manifest = {'source': BASE, 'tree': snapshot['comparison_tree'],
            'files': {name: {'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                      for name, data in payloads.items()},
            'note': 'All inputs are retained branch source/test diffs or authored synthetic QA. No native acceptance.'}
manifest_bytes = (json.dumps(manifest, indent=2) + '\n').encode()
(OUT / 'manifest.json').write_bytes(manifest_bytes)
archive = QA / 'semantic-disposition-batch2-20261118.zip'
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as bundle:
    for name, data in {**payloads, 'manifest.json': manifest_bytes}.items():
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        bundle.writestr(info, data)
with zipfile.ZipFile(archive) as bundle:
    assert bundle.testzip() is None
    for name, meta in manifest['files'].items():
        data = bundle.read(name)
        assert len(data) == meta['size'] and hashlib.sha256(data).hexdigest() == meta['sha256']
archive_info = {'file': 'docs/qa/' + archive.name, 'members': len(payloads) + 1,
                'size': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
                'manifest_verified': True}

document = {
    'schema': 'patchtrace-semantic-disposition/1', 'generated_at_utc': datetime.now(UTC).isoformat(),
    'comparison_source': BASE, 'comparison_tree': snapshot['comparison_tree'],
    'inventory_source_sha256': snapshot['inventory_source_sha256'],
    'inventory_observed_at': snapshot['inventory_observed_at'],
    'local_refs_observed_at': snapshot['captured_at_utc'],
    'remote_status_refresh': 'No fresh REST query; all 20 fetched local tips match the original inventory.',
    'scope': 'Second evidence-only bounded semantic review of actual analyst/acquisition/enrichment/rules source deltas.',
    'method': [
        'Retain merge-base-to-tip and tip-to-current complete source/test/tools patches, exact tips, changed paths, ahead/behind and git-cherry output.',
        'Compare per-function/class ASTs, inspect nonidentical behavior and trace actual replacement modules/commits; names or ancestry alone are not semantic proof.',
        'Run current replacement controls, preserve unchanged historical replays and classify each failure instead of relabelling it.',
        'Use real authored temporary stores and headless CLI output for the confirmed explanation gap; no source/native/network mutation.',
    ],
    'counting': {'original_mechanical_reconciliation_tips': 131, 'previously_selected': 20,
                 'selected_this_batch': 20, 'selected_across_two_batches': 40,
                 'focal_scopes_retained_this_batch': 18, 'tips_with_one_shared_omission': 2,
                 'unique_confirmed_behavior_omissions': 1, 'unselected_original_tips_remaining': 91,
                 'whole_branch_closures': 0, 'percentage_estimate': None,
                 'uncertainty': 'Branch entries are the denominator, not features or acceptance criteria. Broad historical residue and qualification gates remain unmeasured.'},
    'gates': gates, 'failure_dispositions': json.loads((OUT / 'failure-disposition.json').read_text()),
    'cli_observation': json.loads((OUT / 'named-superseded-cli-final/receipt.json').read_text()),
    'candidates': [candidate], 'branches': branches, 'remaining_original_tips': remaining,
    'evidence_archive': archive_info,
    'limitations': [
        'No historical branch full suite was run. Replays execute historical controls against the pinned current source.',
        'The same current and historical tests overlap in behavior; their counts are not added into product completion or confidence.',
        'Native Windows WinVerifyTrust and msdelta tests are skipped. No target execution, native acquisition, provider fetch or packaged/manual acceptance occurred.',
        'Previously accepted raw/saved/CVRF/publication/XML/creation/callgraph repairs and scanner work are separate ownership/qualification and are not new candidates in this batch.',
        'Frozen PR states and local remote-tracking refs are historical observations, not a refreshed remote review/CI status.',
        'The two partially retained tips share one warning omission. Neither they nor the 18 scoped-retained tips are authorized for closure/deletion or wholesale merge.',
    ],
}
(PLAN / 'semantic-disposition-batch2.json').write_text(json.dumps(document, indent=2) + '\n')

md = [
    '# Semantic branch disposition — batch 2 (2026-11-18)', '',
    '**Result:** 20 additional original reconciliation tips received a scoped source comparison. Eighteen retain their examined focal behavior, including three with explicit helper-contract replacements. Two overlapping tips share one confirmed missing analyst explanation: an explicitly selected advisory file can be superseded without a selected-file warning. No product source was changed.', '',
    f'Comparison source: `{BASE}`; tree `{snapshot["comparison_tree"]}`. '
    f'The frozen inventory observation remains `{snapshot["inventory_observed_at"]}`. '
    f'Local fetched refs were observed at `{snapshot["captured_at_utc"]}`; all 20 selected tips match that inventory. '
    'This is a current local integration baseline, not a claim that main or remote qualification changed.', '',
    '## Scope, denominator and limits', '',
    'The original mechanical set contains 131 `needs_reconciliation` tips. Batch 1 selected 20; this batch selects another 20, leaving **91 unselected original tips**. Broad residue within previously inspected tips remains open. The two partial rows here describe **one shared behavior**, not two features. No whole branch is closed, deleted or declared fully reconciled.', '',
    'No completion percentage is assigned. Branch entries and test cases are not a denominator for implemented product requirements or native acceptance. The original mechanical inventory and its observation date remain unchanged.', '',
    'The review uses actual patches, changed paths, symbol-level structure, source call sites, replacement ancestry and behavior controls. Neither branch names nor commit subjects establish equivalence. Source/test/tools files are unchanged in this branch.', '',
    'Evidence: [complete machine-readable ledger](semantic-disposition-batch2.json), '
    '[QA receipt](../../qa/semantic-disposition-batch2-20261118.md), and '
    '[sealed raw archive](../../qa/semantic-disposition-batch2-20261118.zip). '
    'The JSON retains the exact 91 remaining names/tips for the next batch.', '',
    '## Confirmed candidate: B2-C1 — explain a selected superseded source', '',
    'The unchanged historical `test_kbc12_a_named_superseded_file_says_its_hit_is_not_counted` fails at the missing `NAMED_SUPERSEDED` warning. Its preceding assertions pass: the lookup remains `not_observed`, and the old hit is retained under `superseded`. Historical source is `3f0df14d9d68dfd9523afd7f9e97482f9d7907ff`, present in the two overlapping coordinator tips but absent from the current ancestry.', '',
    'Five actual headless CLI commands use two authored revisions and explicit source-ID scopes. The older-source query returns exit 4, no trusted edge, and only a generic superseded warning in JSON. Plain output says the checked documents do not list the KB, even though the selected older document contains it. The active-source query returns its hit; unscoped cached lookup remains negative. No advisory freshness or applicability is inferred.', '',
    'A separate bounded warning-only repair is proposed. It must preserve all status/edge/card withholding, current revision ambiguity and conflict precedence, product scope, native source IDs and limits. The current plain-text presenter emits `Outcome.text` without its warnings, so `_lookup/_warnings` alone does not make the explanation visible in actual CLI output. A minimal presentation amendment needs explicit ownership alongside those index methods. No such source change is included here.', '',
    '## Exact tips and scoped dispositions', '',
    '| ID | Branch / frozen historical PR | Exact tip | Disposition |',
    '|---|---|---|---|',
]
for row in branches:
    prs = ', '.join('#' + str(p['number']) for p in row['pull_requests']) or 'no linked PR in frozen inventory'
    status = 'Partial: shared B2-C1 omission' if row['status'].startswith('partial') else (
        'Retained; explicit contract replacement' if 'contract_replacement' in row['status'] else 'Focal behavior retained')
    md.append(f'| {row["review_id"]} | `{row["branch"]}` — {prs} | `{row["tip"]}` | {status} |')
md += ['', '## Qualification and original failures', '',
       '| Gate on the comparison source | Result | Meaning |', '|---|---|---|',
       '| 39 current replacement files | 955 passed; 2 skipped; 32.63 s | Current source, injected transport/synthetic inputs and offscreen UI |',
       '| 4 additional audit boundary files | 139 passed; 15.31 s | Artifact bytes, representations, core project and MainWindow behavior |',
       '| Original rule/callgraph file, unchanged | 15 passed; 0.81 s | Retained older fixes; overlaps current test scope |',
       '| Original acquisition file, unchanged | 7 passed; 1 failed; 0.19 s | Failure is the obsolete direct helper-surrogate expectation; public entry validation is retained |',
       '| Original KB file, unchanged | 28 passed; 2 failed; 0.45 s | One missing warning; one old fixture lacks current ambiguity/truncation fields |',
       '| Initial selected-source control | 1 failed; 0.50 s | Same missing warning, retained separately; do not count twice |',
       '| Actual headless CLI observation | 5 commands; exits 0, 4, 4, 0, 4 | Withholding preserved; active source positive; named-file explanation absent |', '',
       'The two skipped tests are native Windows WinVerifyTrust and `msdelta.dll` controls. Native compatibility, package/manual acceptance, live providers, empirical accuracy and timing targets remain separate gates. No test total is converted into a completion percentage.', '',
       'Original evidence is retained: the preflight caught one nonexistent selected test file before pytest ran; the corrected selection omits it. The first authored CLI harness used raw SHA-256 values instead of the importer’s domain-separated document IDs and therefore selected nonexistent scopes. Its script, failure and all outputs are preserved. The corrected harness uses `import_bytes(...).doc_id` and records every child exit. These harness failures are not described as product defects.', '',
       'The original acquisition helper assertion is not silently changed: current `strict_json` checks document syntax while `parse` and `parse_rows` perform mandatory per-entry UTF-8/hash validation. The old KB prefix fixture is also unchanged in the replay; the production-shaped current test adds `ambiguous` and `truncated` fields and passes.', '',
       '## Detailed behavior and selective-port decisions', '']
for row in branches:
    md += [f'### {row["review_id"]}: `{row["branch"]}`', '',
           f'**Focus:** {row["focus"]}', '',
           '**Historical behavior.** ' + row['historical_behavior'], '',
           '**Current replacement evidence.**', '']
    md += ['- ' + proof for proof in row['current_proof']]
    commits = [item['sha'] for group in row['replacement_provenance'].values() for item in group]
    md += ['', '**Replacement provenance:** ' + ', '.join('`' + c + '`' for c in commits) + '.', '',
           '**Current controls:** ' + ', '.join('`tests/' + p + '`' for p in row['tests']) + '.', '',
           '**Qualification:** ' + row['qualification'], '',
           '**Decision:** ' + row['recommendation'], '',
           '**Residual limits:** ' + row['residue'], '']
md += ['## Continuation', '',
       'Finish B2-C1 only through a separately owned, reviewed follow-on. Continue the remaining 91 frozen tips and the broad checkpoint research residue. Previously accepted creation, cap-truth and shared-path-budget repairs remain documented in their own source-pinned receipts; their old batch-1 failures stay historical. Preserve all branch tips until root makes an explicit disposition or merge decision.', '']
(PLAN / 'semantic-disposition-batch2.md').write_text('\n'.join(md))

qa = f'''# Semantic branch disposition batch 2 — QA receipt (2026-11-18)

Comparison source: `{BASE}`. Tree: `{snapshot['comparison_tree']}`.
Evidence-only branch: `codex/semantic-disposition-batch2-20261118`.

The [semantic ledger](../plans/autonomous-consolidation-20261118/semantic-disposition-batch2.md)
and [complete JSON](../plans/autonomous-consolidation-20261118/semantic-disposition-batch2.json)
record all 20 exact tips, source projections, merge bases, ahead/behind counts,
patch-equivalence output, scoped decisions and the 91 unselected original tips.
The source/tests/tools tree is unchanged from the comparison source.

## Reproducible evidence

[Raw archive](semantic-disposition-batch2-20261118.zip): **{archive_info['members']} members**,
**{archive_info['size']:,} bytes**. SHA-256:
`{archive_info['sha256']}`.

Every retained file has a size and SHA-256 in `manifest.json`; the builder
reopened the archive, checked its ZIP integrity and verified every manifest hash.
The archive contains complete source/test/tools patches, mechanical snapshots,
per-symbol AST evidence, replacement ancestry, scripts, exact command records,
stdout/stderr, JUnit XML and authored temporary-store inputs. It excludes transient
locks and Python caches. The original inventory observation is unchanged; no REST
refresh or remote mutation occurred.

## Results and scope

| Invocation | Result | Scope |
|---|---|---|
| `current_gate.py` | 955 passed, 2 skipped, 32.63 s | 39 selected current replacement files |
| `current-audit-boundaries-command.json` | 139 passed, 15.31 s | 4 additional current audit files |
| `historical-rules-command.json` | 15 passed, 0.81 s | Unchanged original rules/callgraph file |
| `historical-acquisition-command.json` | 7 passed, 1 failed, 0.19 s | Old direct strict-JSON helper contract differs |
| `historical-kbc-command.json` | 28 passed, 2 failed, 0.45 s | Missing selected-file warning and an obsolete fixture shape |
| `named-superseded-red-command.json` | 1 failed, 0.50 s | Initial warning reproduction, overlapping the previous row |
| `named-superseded-cli-final/receipt.json` | 5 actual headless calls; exits 0/4/4/0/4 | JSON/text observation plus active/cached controls |

All pytest invocations use the shared venv with absolute `PYTHONPATH` pointing to
this exact worktree. Qt uses `QT_QPA_PLATFORM=offscreen`. The actual CLI children
assert no PySide6 module was imported. The two native skips are
`test_native_unsigned_file_does_not_raise` (WinVerifyTrust) and
`test_apply_synthetic_delta_created_with_createdeltab` (`msdelta.dll`).

The counts are separate invocations with overlapping behavior, not additive
product completeness or accuracy. No historical full tree, native engine,
target execution, live provider, manual GUI or packaged acceptance is claimed.
Table durations reproduce pytest's terminal summaries; the JSON also retains
the separately labelled JUnit suite durations.

## Preserved failures and corrections

`failure-disposition.json` records each failure without changing its original
input or relabelling it as a passing test. The old acquisition helper test expects
document-wide surrogate rejection; current public entry parsers intentionally
validate each record so valid siblings survive. The old KB prefix test constructs
a SimpleNamespace without current `ambiguous`/`truncated` fields; the current
production-shaped prefix control passes. The missing `NAMED_SUPERSEDED` warning
is the one confirmed behavior omission, shared by two historical tips.

The first gate preflight selected a nonexistent `test_rules_window.py`; it stopped
before pytest. Its exact script is retained as `current_gate_preflight.py`, with
an explicitly labelled posthoc preflight record. The corrected selection uses
the existing original rules diff-cap controls. The initial CLI observation script
used raw hashes as document IDs; it selected absent scopes and failed its result
assertion. `named_superseded_cli_initial.py`, its failure log and all five output
pairs remain unchanged. The corrected script uses the production importer ID and
retains subprocess exits before assertions.

The final CLI output confirms correct withholding but misleading selected-source
explanation. JSON includes only the generic superseded warning; plain output omits
warnings and says the checked documents do not list the old hit. The proposed
follow-on must cover both index warning and presentation without changing source
admission, status, applicability, ambiguity or conflict behavior.

## Gate limits

This docs-only batch receives no new source implementation credit. Eighteen
examined focal scopes are retained, two tips share one omission, and 91 original
tips have not been selected by either semantic batch. No entire branch is closed
or authorized for deletion/wholesale merging. Current platform, package, native,
security and empirical research gates remain owned by their separate workflows.
'''
(QA / 'semantic-disposition-batch2-20261118.md').write_text(qa)


def append_once(path, heading, text):
    old = path.read_text()
    if heading not in old:
        path.write_text(old.rstrip() + '\n\n' + heading + '\n\n' + text.rstrip() + '\n')


append_once(PLAN / 'consolidation-ledger.md', '## Semantic reconciliation batch 2 — 2026-11-18', '''
The [second bounded batch](semantic-disposition-batch2.md) compares 20 additional
original reconciliation tips against `3be3af166897fc2376dc64850edc66485273dea1`.
Eighteen focal source scopes are retained; two overlapping coordinator tips share
one confirmed missing selected-superseded-source explanation. Status and trusted
edge withholding remain correct. A warning-only follow-on is proposed; no source
port, branch closure, deletion or remote mutation occurs in this batch.

Current gates pass 955 cases with two native Windows skips, then 139 additional
audit cases. Original historical replays and their failures are preserved and
classified: a replaced internal-helper expectation, an obsolete fixture shape,
and the real warning omission. Actual headless CLI JSON/text shows the presentation
effect. [Complete records](semantic-disposition-batch2.json) and the
[sealed QA receipt](../../qa/semantic-disposition-batch2-20261118.md) retain exact
source/commands/hashes. The original 131-tip denominator now has 40 selected
scopes and 91 unselected tips; broad residue and qualification are still open.
No completion percentage is inferred from these counts.
''')
append_once(ROOT / 'docs/plans/patchtrace-completion-matrix.md', '## Semantic branch review batch 2 — 2026-11-18', '''
[Batch 2](autonomous-consolidation-20261118/semantic-disposition-batch2.md)
adds scoped evidence for 20 original tips at
`3be3af166897fc2376dc64850edc66485273dea1`: 18 focal behaviors retained,
two overlapping tips with one missing selected-source explanation. The original
mechanical set remains 131; 40 scopes have been selected across two batches,
leaving 91 unselected original tips plus documented broad-tip residue.

| Criterion | Current evidence | Remaining boundary |
|---|---|---|
| Selected enrichment/acquisition/rule/n-way behaviors | Source comparisons, replacement ancestry and current controls retained | No whole-branch closure; native/provider/empirical gates separate |
| Selected superseded advisory explanation | Original warning control is red; actual CLI JSON/text reproduces the missing explanation; source withholding is correct | Separate bounded warning/presentation repair and independent review |
| Historical controls | Original files and failures preserved with explicit contract/fixture diagnoses | Historical trees are not freshly qualified |
| Native platform acceptance | WinVerifyTrust and msdelta skipped on Linux | Windows execution and package/manual gates remain open |

This documentation does not add D/R/J/G percentage credit or change a feature
readiness estimate. Branch/test counts do not measure completed requirements.
The separately reviewed creation and two callgraph repairs now present in the
comparison tree retain their own acceptance receipts and original failure history.
''')

print(json.dumps({'archive': archive_info, 'branches': len(branches), 'remaining': len(remaining),
                  'docs': ['semantic-disposition-batch2.json', 'semantic-disposition-batch2.md']}, indent=2))
