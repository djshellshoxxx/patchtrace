"""Run the bounded current-source replacement gate, recording exact arguments."""
from pathlib import Path
import json
import os
import subprocess
from datetime import UTC, datetime

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch2')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch2')
PYTHON = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
BASE = '3be3af166897fc2376dc64850edc66485273dea1'
NAMES = [
    'audit_enrichment', 'audit_ai_reports', 'audit_core', 'audit_desktop', 'audit_runtime',
    'enrichment_core', 'enrichment_signals', 'enrichment_wil', 'enrichment_cache',
    'enrichment_cve', 'enrichment_intelligence', 'enrichment_review_regressions', 'enrichment_storage',
    'ui_enrichment', 'cli', 'nway_graph', 'nway_series', 'secondary_bindiff', 'secondary_binexport',
    'secondary_reconcile', 'secondary_rzdiff', 'secondary_evidence', 'pe_overview', 'pe_overview_map_compare',
    'acquisition_winbindex', 'acquisition_hostile_20261029', 'acquisition_transport',
    'acquisition_quarantine', 'acquisition_delta', 'acquisition_cli', 'ui_symbol_local',
    'rules_cg_bugfixes_20261029', 'rules_export', 'rules_matrix', 'rules_store', 'rules_window',
    'kbc_bugfixes_20261029', 'profiles', 'raw_cache', 'ui_profiles',
]
files = ['tests/test_' + name + '.py' for name in NAMES]
for path in files:
    if not (ROOT / path).is_file():
        raise SystemExit('Missing selection: ' + path)
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert head == BASE, (head, BASE)
env = dict(os.environ, PYTHONPATH=str(ROOT / 'src') + ':' + str(ROOT / 'tests'), QT_QPA_PLATFORM='offscreen')
command = [PYTHON, '-m', 'pytest', '-q', *files, '--junitxml=' + str(OUT / 'current-affected.xml')]
record = {'source': head, 'cwd': str(ROOT), 'command': command,
          'env': {k: env[k] for k in ('PYTHONPATH', 'QT_QPA_PLATFORM')},
          'started_at': datetime.now(UTC).isoformat(), 'selected_files': len(files)}
(OUT / 'current-command.json').write_text(json.dumps(record, indent=2)+'\n')
with (OUT / 'current-affected.log').open('w') as stream:
    result = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
record.update(exit_code=result.returncode, completed_at=datetime.now(UTC).isoformat())
(OUT / 'current-command.json').write_text(json.dumps(record, indent=2)+'\n')
print('exit', result.returncode, 'files', len(files))
raise SystemExit(result.returncode)
