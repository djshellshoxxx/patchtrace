"""Check replacement ancestry and retain per-path latest changes at the pinned baseline."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch2')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch2')
BASE = '3be3af166897fc2376dc64850edc66485273dea1'
GROUPS = {
    'enrichment-original': ['0d22e9cdd833528e7b355051613c9deceb929f52'],
    'enrichment-hardening': ['1223cdd5517c2d49423210a6c7a35b5946679a07', 'f689d33f506c8ce37e626712c042f8560523e02c', '67e5a6c6919ee711c99d334ed58e3e91298c3038'],
    'cache-hardening': ['ec40ea98da45844d2677e5704250848c867844ca', '4e47b20fa034888eded7e064a2db114d998aba21', '802b5b1bb5f5e64118256e75414b7ca74ad61fcc'],
    'audit-beta': ['49851325357c66bef10ca04edf871e2f52965fd3'],
    'profiles-raw-cache': ['20a843348dc125346af346ec32c815c469c67283'],
    'nway-secondary': ['7eea00147d2c9c898725c973aa2854aabcdeff9a'],
    'nway-hardening': ['cda7fe8630a76ff321f9cbd114b4a69fe7d9a71a', '3daf65420b770685920bc27346460b0df99527f5', 'ad87acdd0e65e044c5eefd07990aee53863f540f'],
    'secondary-worker': ['9403d1dc92537cee4341db21b3b48cb4a5ac183f'],
    'evidence-adjudication': ['6764acb5dc99e39c94655188a1548225c10ac656', '29a4d3f3a76ac398fe53b9f47dd5d2fa7341cf99', 'cb25132b0ebd12abb2f15bdc60324b8d177bef25'],
    'winbindex-symbol-policy': ['f1a1c0b2fd6d48a07c4f655247818e8a9ed30371', '7716e2b02feaa04e59dce302c1c6cacbe800634b', 'f0af3fe2b4bfd6a8413d6d3cec093238d34e9d93'],
    'pe-overview': ['f1d95e154738e8cfc99f91d6f2bc06615f7bf1b1', 'f676f1009747de1e5e65d3d11ea01264787f9f94', 'e4b2b2ef1b0039ce1ab06de5bce694289756b724'],
    'rules': ['936435241a3ab9663a3fa67da4497a088f32f09c', '9d66abb26a015f075235e0434744eab38f676f83', 'e2b31582abe3777e8a83b8126ed42bbeab028a0a', 'df0f1eb8e935bc4a0a491faf7ee91e74f437b845', '4067914793fa1822e9829484302120b137b6fe82'],
    'reviewed-callgraph-paths': ['36e14051a4d36f5c66df0186f037a4905b01bf05'],
    'not-retained-named-superseded': ['3f0df14d9d68dfd9523afd7f9e97482f9d7907ff'],
}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


commits = {}
for group, values in GROUPS.items():
    commits[group] = []
    for sha in values:
        ancestor = subprocess.run(['git', 'merge-base', '--is-ancestor', sha, BASE], cwd=ROOT).returncode == 0
        assert ancestor == (group != 'not-retained-named-superseded'), (group, sha)
        commits[group].append({'sha': sha, 'is_ancestor': ancestor,
                               'subject': git('show', '-s', '--format=%s', sha),
                               'paths': git('show', '--format=', '--name-only', sha).splitlines()})
snapshot = json.loads((OUT / 'snapshot.json').read_text())
paths = sorted({s['path'] for row in snapshot['branches'] for s in row['source_projection']
                if s['path'].startswith(('src/', 'tools/'))})
latest = [{'path': path, 'latest_change': git('log', '-1', '--format=%H %s', BASE, '--', path),
           'current_sha256': hashlib.sha256((ROOT / path).read_bytes()).hexdigest() if (ROOT / path).is_file() else None}
          for path in paths]
(OUT / 'replacement-provenance.json').write_text(json.dumps({
    'source': BASE,
    'method': 'Ancestry proves the named change reached this tree; inspected source diffs and behavior tests establish the scoped replacement. Commit names alone are not proof.',
    'groups': commits, 'current_paths': latest,
}, indent=2)+'\n')
print('checked replacement groups', len(commits), 'current paths', len(paths))
