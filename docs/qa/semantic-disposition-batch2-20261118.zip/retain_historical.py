from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch2')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch2')
SOURCES = [
    ('798e11ef345ed7a7a65508a466eaf77ee85ef77c', 'tests/test_kbc_bugfixes_20261029.py', 'coordinator-kbc/test_kbc_bugfixes_20261029.py'),
    ('78d48cf80bf9a8c698e604dc1ce58e8aecedca45', 'tests/test_rules_cg_bugfixes_20261029.py', 'rules-original/test_rules_cg_bugfixes_20261029.py'),
    ('c0d1c38aee74461969ff0a8b4d61179c3dbb9b0b', 'tests/test_acquisition_hostile_20261029.py', 'acquisition-original/test_acquisition_hostile_20261029.py'),
]
manifest = []
for sha, path, retained in SOURCES:
    data = subprocess.check_output(['git', 'show', sha + ':' + path], cwd=ROOT)
    dest = OUT / 'historical-controls' / retained
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    manifest.append({'source': sha, 'path': path, 'retained': str(dest.relative_to(OUT)),
                     'size': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
(OUT / 'historical-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
