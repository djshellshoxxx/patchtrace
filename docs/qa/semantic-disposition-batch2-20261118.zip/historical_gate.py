"""Replay original historical controls separately from the current test tree."""
from datetime import UTC, datetime
from pathlib import Path
import json
import os
import subprocess

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch2')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch2')
PYTHON = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
env = dict(os.environ, PYTHONPATH=str(ROOT / 'src') + ':' + str(ROOT / 'tests'), QT_QPA_PLATFORM='offscreen')
cases = [
    ('historical-rules', 'rules-original/test_rules_cg_bugfixes_20261029.py'),
    ('historical-acquisition', 'acquisition-original/test_acquisition_hostile_20261029.py'),
    ('historical-kbc', 'coordinator-kbc/test_kbc_bugfixes_20261029.py'),
]
for label, relative in cases:
    command = [PYTHON, '-m', 'pytest', '-q', str(OUT / 'historical-controls' / relative),
               '--junitxml=' + str(OUT / (label + '.xml'))]
    record = {'source': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
              'cwd': str(ROOT), 'command': command,
              'env': {k: env[k] for k in ('PYTHONPATH', 'QT_QPA_PLATFORM')},
              'started_at': datetime.now(UTC).isoformat()}
    with (OUT / (label + '.log')).open('w') as stream:
        completed = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
    record.update(exit_code=completed.returncode, completed_at=datetime.now(UTC).isoformat())
    (OUT / (label + '-command.json')).write_text(json.dumps(record, indent=2)+'\n')
    print(label, completed.returncode)
