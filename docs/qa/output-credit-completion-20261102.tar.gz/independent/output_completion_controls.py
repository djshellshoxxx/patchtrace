"""Reviewer-only crash and multi-report budget controls, using synthetic providers."""
from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

from test_tier_r_output_persistence import LABELS, provider

from tools.calibration import train
from tools.calibration.tier_r import evaluate as E
from tools.calibration.tier_r import output_store as OS
from tools.calibration.tier_r import report_schemas as RS


def child(stage: str, folder: Path):
    publish = OS._publish_owned_bytes
    name = {"sentinel": OS.COMPLETION_FILE, "credit": OS.CREDIT_FILE}.get(stage)

    def crash_after_publish(path, raw):
        result = publish(path, raw)
        if Path(path).name == name:
            os._exit(73)
        return result

    OS._publish_owned_bytes = crash_after_publish
    E.evaluate([LABELS], [provider()], output_dir=folder, b_count=20)
    assert stage == "completed"
    os._exit(74)


def main():
    root = Path(tempfile.mkdtemp(prefix="completion-controls-", dir=Path(__file__).parent))
    records = []
    for stage in ("sentinel", "credit", "completed"):
        folder = root / stage
        result = subprocess.run([sys.executable, __file__, "child", stage, str(folder)], check=False)
        assert result.returncode == (74 if stage == "completed" else 73)
        assert (folder / OS.output_file_name(LABELS.pair_id, "rz-diff")).is_file()
        assert not (folder / OS.FAILURE_FILE).exists() and not (folder / OS.UNCREDITED_REPORT).exists()
        assert (folder / OS.CREDIT_FILE).exists() == (stage != "sentinel")
        assert (folder / OS.COMPLETION_FILE).exists() == (stage != "completed")
        if stage == "completed":
            assert OS.read_credited_outputs(folder)
            assert train.load_outputs(folder, allow_legacy=False)
        else:
            for reader in (OS.read_credited_outputs, lambda path: train.load_outputs(path, allow_legacy=False)):
                try:
                    reader(folder)
                except (OS.OutputError, train.TrainError) as exc:
                    assert "incomplete" in str(exc)
                else:
                    raise AssertionError("interrupted output was accepted")
        records.append({"stage": stage, "returncode": result.returncode, "folder": str(folder)})

    reports = [E.evaluate([LABELS], [provider(engine)], b_count=20) for engine in ("rz-diff", "bindiff")]

    def prepared(folder):
        store = OS.OutputStore(folder)
        for engine in ("rz-diff", "bindiff"):
            output = E.engine_output_doc(provider(engine).outputs[LABELS.pair_id], LABELS, "hidden")
            store.write(LABELS.pair_id, engine, output)
        return store

    reference = prepared(root / "reference")
    reference.finalize(reports)
    raw = (reference.folder / OS.CREDIT_FILE).read_bytes()
    document = json.loads(raw)
    assert len(document["reports"]) == len(document["outputs"]) == 2
    metadata = [{k: v for k, v in row.items() if k != "report_sha256"} for row in document["outputs"]]
    maximum = RS.MAX_CREDIT_BYTES
    try:
        RS.MAX_CREDIT_BYTES = len(raw)
        OS.preflight_credit_manifest(reports, metadata)
        boundary = prepared(root / "boundary")
        boundary.finalize(reports)
        assert (boundary.folder / OS.CREDIT_FILE).read_bytes() == raw
        RS.MAX_CREDIT_BYTES -= 1
        before = sorted(str(p.relative_to(root)) for p in root.rglob("*"))
        try:
            OS.preflight_credit_manifest(reports, metadata)
        except OS.OutputError:
            pass
        else:
            raise AssertionError("oversized aggregate preflight was accepted")
        assert sorted(str(p.relative_to(root)) for p in root.rglob("*")) == before
        oversized = prepared(root / "oversized")
        for attempt in range(2):
            try:
                oversized.finalize(reports)
            except OS.OutputError as exc:
                assert ("exceeds" if attempt == 0 else "finalized") in str(exc)
            else:
                raise AssertionError("failed finalization was reused")
        assert not (oversized.folder / OS.CREDIT_FILE).exists()
        assert not (oversized.folder / OS.COMPLETION_FILE).exists()
    finally:
        RS.MAX_CREDIT_BYTES = maximum
    for name, expected in RS.render().items():
        assert (Path("docs/schemas/corpus") / name).read_text() == expected
    result = {"crash_controls": records, "aggregate_bytes": len(raw), "reports": 2,
              "exact_boundary": "accepted", "one_byte_less": "preflight and finalization refused",
              "failed_retry": "refused", "generated_schemas": "exact"}
    (root / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result))


if __name__ == "__main__":
    if len(sys.argv) > 1:
        child(sys.argv[2], Path(sys.argv[3]))
    else:
        main()
