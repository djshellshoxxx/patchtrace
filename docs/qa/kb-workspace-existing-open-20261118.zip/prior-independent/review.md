# Independent review of the durable package-admission proposal

## Disposition

Reviewed design **efe68b18654459e704d358d64423fbc1820afc0a**, both Markdown and
JSON, against its frozen production authority
**195e04af27f7a724c6a2037363b7fe68df418a6b**. The dedicated table, explicit
expected identity, held-origin recovery refusal, verified project association
and separate committed-project reconciliation form a viable bounded direction.
There is **one confirmed design prerequisite** before implementing the promised
capture boundary: `WorkspaceStore(create=False)` does not itself prevent
initialization. No second confirmed blocker was established in this review.

This is not acceptance of a package implementation or native journey. No product,
repository test, plan, schema, policy or remote object was changed. The completed
core branch remains at `0201a4c8a1ab715af8136d166bc29eb2985d13c7`.

## Confirmed prerequisite: capture must not initialize an unadmitted database

Design §5 requires an already initialized workspace opened with `create=False`
and says failed capture must not silently create storage. The frozen constructor
only uses `create=False` to reject a missing `kbc.sqlite3`. Once a file exists,
`WorkspaceStore.__init__` at `store.py:173–182` calls `_create()` whenever
`PRAGMA user_version` is zero, then enables WAL. `_create()` at `192–202` installs
tables and stamps version 1.

The unchanged-source four-case probe uses only authored local SQLite files:

| Fixture | Observed result |
|---|---|
| Existing zero-byte database | Opens successfully; initializes workspace tables and stamps version 1; database bytes change |
| Existing unrelated v0 database with retained notes | Opens successfully; adds workspace tables alongside the retained table, stamps version 1; database bytes change |
| Healthy initialized v1 workspace | Opens successfully; retained database and analyst-file bytes stay equal |
| Missing database in an existing directory | Refuses; existing analyst file stays unchanged |

Result: **2 failures / 2 positives**, zero errors/skips, 0.34 seconds, 31 imported
project modules exactly matching frozen `195e04af`; no source drift, child or
network attempts. The failures assert the proposed package-capture precondition,
not a previously promised ordinary `create=False` read-only contract. This is not
a new claim that the current ordinary workspace constructor violated its own
documented behavior.

`test_capture_initialization_boundary.py`, `capture-red.*` and the four JSON
observations remain unchanged. The failed fixture directory is retained at
`/tmp/package-capture-independent-1kgr5se3`, 315,392 allocated bytes. No original
author observation or design file was modified.

The smallest correction is an explicit existing/non-initializing mode on the
existing WorkspaceStore path. Validate the **actual opened connection** before
initialization or journal-mode setup; preserve default ordinary behavior. A
separate pathname/version check followed by the current constructor leaves a
replacement interval and does not establish the promised refusal. Initial
capture must not migrate, create tables, stamp a version or switch WAL on an
unadmitted database. The later accepted writer transaction must still recheck
the same workspace binding, schema/version and captured admission state. No
parallel raw-SQLite admission service is recommended.

Inventory acknowledged this missing enforcement and is preparing an attributed
append correction. The original design/QA objects remain immutable. The root
approved that documentation/proposal extension; this reviewer made no source
correction.

## Smallest reviewable implementation boundary

Proceed in separately reviewed steps. Pure contracts can be specified and tested
without exposing a native capability. Storage/recovery implementation requires
the non-initializing capture prerequisite above. Facade, project association and
reconciliation remain later slices.

| Boundary | Required implementation condition and meaningful controls |
|---|---|
| Pure contracts | Specify exact finite limits and an acyclic canonical preimage. Intent identity excludes its own derived ID, the attachment ID derived from it, and mutable progress. Bind the preallocated canonical UUID, exact ordered sides, captures and immutable metadata references. Validate phase/flags, SQL/body identities and contradictory bindings; native handles/readers remain absent |
| Existing capture | New optional mode refuses zero-byte/uninitialized/unsupported or contradictory schema on the actual connection before `_create`/WAL. Missing and healthy initialized cases remain positive controls; ordinary defaults remain unchanged. An open-time replacement challenge must not be satisfied by an earlier pathname check |
| Lazy v2 transition | One `BEGIN IMMEDIATE` contains the exact new table, first intent/progress and version stamp. A v1 table-name collision, v2 missing/mismatched table, unknown version or malformed metadata refuses. Interrupt each precommit step; no partial table/row/version. Unknown commit is read back or reported unknown, never used to start blind creation |
| Initial and later CAS | Validate the captured current revision/digest, admitted BYTES_VERIFIED revision, ordered pair and source/scope bindings **inside** the writer transaction. Subsequent progress generation/digest and the permitted investigation transition commit together. An explicit participant is needed; the existing validation guard is invoked twice and cannot safely host side effects |
| Legacy isolation | Every held phase stays outside legacy `journal`. Fresh frozen readers become read-only; an already-open old client remains writable and can change ordinary state. New CAS must detect those changes. Do not describe the version stamp or separate table as a universal old-writer exclusion barrier |
| Recovery guard | Before `mark_interrupted`, ordinary enumeration, attempts, source reads or direct resume, check bounded package state. An indexed `done` phase alone cannot establish resolution: indexed/body phase, flags, hashes and binding must agree. Corrupt or over-budget rows refuse; a forged resolved index must not bypass unresolved/corrupt body validation |
| Shared accounting | One finite accounting policy must cover advisory, inventory/support and package writes in both insertion directions, including reuse by identical raw hash and typed record bytes. Recheck limits in the accepting transaction. New orphan references are recognized without inventing deletion authority |
| Per-call committed project validation | Use accepted core false/false open and the exact checkpoint; compare actual project/store ID and both labeled hashes/sizes before caching or any sidecar, enrichment initialization/backup or row operation. Repeat for every fresh open; an old `_dirs` entry or arbitrary journal lookup is not authority |
| Provenance | A selected-row bounded adapter verifies key/kind/project/guard/body hash/strict bytes before use. Publish only if absent; reuse an exact row without timestamp/revision rewrite; refuse conflicts. Define a stable intent-specific Guard, and preserve the original row's observed project revision on later idempotent reuse |
| Cross-store failures | Project association and workspace progress are not atomic together. Retain project/row on marker failure; reverify/reuse exact provenance during explicit one-intent reconciliation. Missing/corrupt row despite a linked marker is damaged/pending, never success. No source lease resurrection, extraction retry, project create or deletion in reconciliation |

These are approval bounds and proposed acceptance controls, not additional
reproduced product defects. The design already states most of them; they must be
made concrete in the first relevant contract/specification and actual tests.
The proposed 1 MiB record, six-object, 500-intent and 32 MiB aggregate limits
remain proposed policy decisions requiring explicit approval, not current
product facts.

## Source-backed challenges and resolved questions

The frozen source supports the design's main separation:

- `WorkspaceStore._transaction` explicitly begins a writer transaction and
  rolls back an active transaction on BaseException. The author's seven
  original observations include an authored DDL/row/version rollback and both
  fresh and preopened legacy-client behavior. This reviewer verified their
  source and receipt bytes; those seven tests were not independently rerun or
  relabeled as migration acceptance.
- `append_revision` writes current-revision CAS, revision/decisions and optional
  journal within that transaction. Its `guard` executes before and after writes.
  An explicit package participant is the narrow composition point.
- `recovery.repair` calls `mark_interrupted` before evaluating `only`, and direct
  marking independently writes attempts/journal. Guards only in a context
  builder or selected-operation predicate would be too late.
- `ProjectAttachment._after_create/_attach_context` publish sidecars before
  project-row calls, while `RealProjectPort` currently reopens/caches without
  package expected-ID policy. The proposal correctly requires a verified held
  association scope before these writes and a create-only bound port.
- `EnrichmentStore.ensure` can create tables/backups, and `publish` performs an
  upsert. `entries(kind)` loads all rows of a kind. The proposed package adapter
  must inspect only the exact bounded row, after identity verification, and
  cannot blindly delegate conflict semantics to that upsert.
- A possible revision/guard contradiction was examined and is not a finding:
  frozen `Guard` contains project ID, run ID, raw hash and input digest; project
  revision is a separate `Entry` field. A stable intent-specific guard and an
  unchanged historical row revision can support the proposed idempotence after
  a normal project revision. The facade must specify this mapping explicitly.
- The subsequent core source `63ebc427` adds the needed creation ID and
  non-recovering checkpointed open/load, plus constructor cleanup precedence.
  It does not add adoption, provenance or recovery authority. The frozen design
  correctly labels these as later dependencies rather than pretending they
  existed at `195e04af`.

## Scope and evidence

The review traces the actual store/reducer/admission/recovery/port/enrichment
contracts and retains canonical Git snapshots and symbol spans. The independent
probe ran read-only against the author's checkout at QA tip
`988ce3f746fe65bc022b4f3a6c1f2234989ec985`; production/test/tool bytes were checked
equal to `195e04af` before execution and each imported module was verified
against frozen Git blobs. Only authored temporary fixture databases were mutated
by the observed constructor. No repository files, target binaries, native
processes, network payloads, installed packages or remote state were changed.

This packet qualifies a design review and one concrete current-boundary
counterexample. It does not test a nonexistent migration/facade, prove arbitrary
same-user filesystem/database exclusion, or complete native Windows/FDI/Job
handoff, package authenticity, advisory applicability, frozen corpus or release
acceptance. The original design remains preserved; the capture correction is a
separate attributed appendix.
