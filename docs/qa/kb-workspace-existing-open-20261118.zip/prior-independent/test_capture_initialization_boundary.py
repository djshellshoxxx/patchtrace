"""Challenge the proposed no-initial-mutation capture, using only authored SQLite files."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import sqlite3

import pytest

from patchtrace.kbcorrelation.store import KbcStoreError, WorkspaceStore

OUT = Path(os.environ['PACKAGE_CAPTURE_REVIEW_OUTPUT'])


def observe(path):
    return {item.relative_to(path).as_posix(): hashlib.sha256(item.read_bytes()).hexdigest()
            for item in path.rglob('*') if item.is_file()}


@pytest.mark.parametrize('state', ['zero-byte', 'foreign-v0', 'initialized-v1', 'missing-database'])
def test_capture_open_does_not_initialize_unadmitted_storage(tmp_path, state):
    root = tmp_path / 'workspace'
    root.mkdir()
    path = root / 'kbc.sqlite3'
    if state == 'zero-byte':
        path.write_bytes(b'')
    elif state == 'foreign-v0':
        with sqlite3.connect(path) as connection:
            connection.execute('CREATE TABLE retained_notes (body TEXT)')
            connection.execute('INSERT INTO retained_notes VALUES (?)', ('authored unrelated evidence',))
            assert connection.execute('PRAGMA user_version').fetchone() == (0,)
    elif state == 'initialized-v1':
        WorkspaceStore(root).close()
    (root / 'analyst.txt').write_bytes(b'Preserve unrelated analyst-owned file.')
    before = observe(root)
    caught, opened, version, tables = None, False, None, []
    try:
        with WorkspaceStore(root, create=False) as store:
            opened = True
            version = store.db.execute('PRAGMA user_version').fetchone()[0]
            tables = [row[0] for row in store.db.execute("SELECT name FROM sqlite_schema WHERE type='table' ORDER BY name")]
    except KbcStoreError as exc:
        caught = exc
    after = observe(root)
    observation = {'state': state, 'opened': opened, 'error_code': caught.code if caught else None,
                   'observed_version': version, 'observed_tables': tables,
                   'files_before': before, 'files_after': after, 'bytes_unchanged': before == after,
                   'scope': 'Frozen current create=False behavior versus proposed package capture precondition.'}
    OUT.mkdir(parents=True, exist_ok=True)
    with (OUT / f'{state}.json').open('x') as output:
        json.dump(observation, output, indent=2)
        output.write('\n')
    if state == 'initialized-v1':
        assert opened and caught is None and version == 1
        assert before == after
    else:
        assert not opened and caught is not None, 'Package capture must enforce initialized storage before this constructor'
        assert before == after
