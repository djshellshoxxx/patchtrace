"""Run one immutable source-pinned offline gate and retain every result."""
from __future__ import annotations

import argparse
import contextlib
from datetime import UTC, datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
QA = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--source', required=True)
parser.add_argument('--label', required=True)
parser.add_argument('tests', nargs='+')
args = parser.parse_args()


def git(*argv):
    return subprocess.check_output(['git', '-C', str(ROOT), *argv])


assert git('rev-parse', 'HEAD').decode().strip() == args.source
assert not git('status', '--porcelain', '--untracked-files=no').strip()
objects = {}
for item in git('ls-tree', '-rz', args.source).split(b'\0'):
    if item:
        head, path = item.split(b'\t', 1)
        objects[path.decode()] = head.split()[2].decode()
pytest_args = ['-q', '-p', 'no:cacheprovider', *args.tests,
               '--junitxml=' + str(QA / (args.label + '.xml'))]
metadata = {'source': args.source,
            'tree': git('rev-parse', args.source + '^{tree}').decode().strip(),
            'branch': git('branch', '--show-current').decode().strip(),
            'argv': [sys.executable, *sys.argv],
            'pytest_arguments': pytest_args, 'cwd': str(ROOT),
            'environment': {name: os.environ.get(name) for name in
                            ('PYTHONPATH', 'PYTHONDONTWRITEBYTECODE', 'QT_QPA_PLATFORM')},
            'started_utc': datetime.now(UTC).isoformat()}
with (QA / (args.label + '.command.json')).open('x') as output:
    json.dump(metadata, output, indent=2)
    output.write('\n')
os.chdir(ROOT)
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'src'))
attempts = []


def audit(event, _arguments):
    if event in {'socket.connect', 'socket.bind', 'socket.getaddrinfo', 'subprocess.Popen',
                 'os.system', 'os.posix_spawn', 'os.spawn'}:
        attempts.append(event)
        raise AssertionError('This bounded gate forbids network or child-process execution')


sys.addaudithook(audit)
import pytest  # noqa: E402

started = time.monotonic()
with (QA / (args.label + '.log')).open('x') as output:
    with contextlib.redirect_stdout(output), contextlib.redirect_stderr(output):
        status = pytest.main(pytest_args)
modules = []
drift = []
virtual_dependencies = []
for name, module in sorted(sys.modules.items()):
    origin = getattr(module, '__file__', None)
    if not origin:
        continue
    given = Path(origin)
    path = given.resolve()
    is_project = name == 'patchtrace' or name.startswith('patchtrace.')
    if not given.is_absolute() and not path.exists() and not (
            is_project or name.startswith(('tests.', 'test_', 'tools.'))):
        virtual_dependencies.append({'module': name, 'virtual_origin': origin})
        continue
    if not path.is_relative_to(ROOT):
        if is_project:
            drift.append({'module': name, 'wrong_origin': str(path)})
        continue
    if path.suffix != '.py':
        continue
    rel = path.relative_to(ROOT).as_posix()
    data = path.read_bytes()
    blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data, usedforsecurity=False).hexdigest()
    item = {'module': name, 'path': rel, 'git_blob': blob,
            'expected_blob': objects.get(rel), 'sha256': hashlib.sha256(data).hexdigest()}
    modules.append(item)
    if blob != objects.get(rel):
        drift.append(item)
totals = {}
xml_path = QA / (args.label + '.xml')
if xml_path.exists():
    suites = list(ET.parse(xml_path).getroot().iter('testsuite'))
    totals = {key: sum(int(s.attrib.get(key, 0)) for s in suites)
              for key in ('tests', 'failures', 'errors', 'skipped')}
receipt = {'source': args.source, 'pytest_exit': int(status),
           'exit_code': 97 if drift or attempts else int(status),
           'seconds': time.monotonic() - started, 'junit_totals': totals,
           'pinned_modules': len(modules), 'drift': drift, 'prohibited_attempts': attempts,
           'virtual_dependencies': virtual_dependencies,
           'finished_utc': datetime.now(UTC).isoformat()}
with (QA / (args.label + '.imports.json')).open('x') as output:
    json.dump({'source': args.source, 'modules': modules, 'drift': drift}, output, indent=2)
    output.write('\n')
with (QA / (args.label + '.exit.json')).open('x') as output:
    json.dump(receipt, output, indent=2)
    output.write('\n')
print(json.dumps(receipt))
raise SystemExit(receipt['exit_code'])
