"""Freeze the new-mode evidence without rewriting any earlier observations."""
from __future__ import annotations

import ast
from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path
import platform
import shutil
import sqlite3
import subprocess
import sys
import zipfile

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
QA = Path(__file__).resolve().parent
BASE = 'cf5f7301c735c6b6ca1c0d64242804bfb432dfa1'
SPEC = 'f484b54c8203c34816dda017beef6f66809d1613'
SOURCE = 'c470a31acec624410a0412e7c803cc38732235a9'
STORE = 'src/patchtrace/kbcorrelation/store.py'
TEST = 'tests/test_kbc_workspace_open_mode.py'
SPEC_PATH = 'docs/specs/program-e/KB-integration-plan.md'
PRIOR = QA.parent / 'package-durable-admission-independent'


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as handle:
        handle.write(data)


def dump(path, value):
    write(path, (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode())


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
assert not git('status', '--porcelain', '--untracked-files=no').strip()
assert shutil.disk_usage(ROOT).free > 100 * 1024**2
old = git('show', BASE + ':' + STORE).decode()
new = git('show', SOURCE + ':' + STORE).decode()
old_tree, new_tree = ast.parse(old), ast.parse(new)
old_cls = next(node for node in old_tree.body if isinstance(node, ast.ClassDef)
               and node.name == 'WorkspaceStore')
new_cls = next(node for node in new_tree.body if isinstance(node, ast.ClassDef)
               and node.name == 'WorkspaceStore')
old_methods = {node.name: node for node in old_cls.body if isinstance(node, ast.FunctionDef)}
new_methods = {node.name: node for node in new_cls.body if isinstance(node, ast.FunctionDef)}
old_init, new_init = old_methods['__init__'], new_methods['__init__']
assert isinstance(new_init.body[0], ast.If) and isinstance(new_init.body[6], ast.If)
assert ast.unparse(new_init.body[0].test) == "type(open_mode) is not str or open_mode not in ('normal', 'existing')"
assert ast.unparse(new_init.body[6].test) == "open_mode == 'existing'"
retained = [node for index, node in enumerate(new_init.body) if index not in {0, 6}]
assert [ast.dump(node) for node in old_init.body] == [ast.dump(node) for node in retained]
unchanged_methods = []
for name, node in old_methods.items():
    if name != '__init__':
        assert ast.dump(node) == ast.dump(new_methods[name]), name
        unchanged_methods.append(name)
assert set(new_methods) - set(old_methods) == {'_open_existing'}
changed_src = git('diff', '--name-only', BASE, SOURCE, '--', 'src').decode().splitlines()
assert changed_src == [STORE]
assert git('show', SPEC + ':' + TEST) == git('show', SOURCE + ':' + TEST)
assert git('show', SPEC + ':' + SPEC_PATH) == git('show', SOURCE + ':' + SPEC_PATH)
write(QA / 'source.diff', git('diff', BASE, SOURCE, '--', STORE))
write(QA / 'spec-tests.diff', git('diff', BASE, SPEC, '--', SPEC_PATH, TEST))
dump(QA / 'source-proof.json', {
    'base': BASE, 'spec_tests': SPEC, 'source': SOURCE,
    'source_tree': git('rev-parse', SOURCE + '^{tree}').decode().strip(),
    'changed_production_paths': changed_src,
    'normal_constructor_body_ast_equal_after_removing_only_mode_validation_and_dispatch': True,
    'removed_new_statements': [ast.unparse(new_init.body[i]) for i in (0, 6)],
    'unchanged_workspace_methods': sorted(unchanged_methods),
    'only_new_workspace_method': '_open_existing',
    'new_probe_bytes_unchanged_since_spec_commit': True,
    'new_spec_bytes_unchanged_since_spec_commit': True,
    'original_design_correction_separate_commit': '62f0712782b999b63cdb40b1f906526f8fef64f3',
})

snapshots = {}
for label in ('spec-red-pinned', 'focused-green', 'affected-green'):
    receipt = json.loads((QA / (label + '.imports.json')).read_bytes())
    assert not receipt['drift']
    for item in receipt['modules']:
        key = (receipt['source'], item['path'])
        snapshots[key] = item
for commit, path in ((BASE, STORE), (BASE, SPEC_PATH), (SPEC, SPEC_PATH), (SOURCE, SPEC_PATH)):
    snapshots.setdefault((commit, path), None)
source_records = []
for (commit, path), recorded in sorted(snapshots.items()):
    raw = git('show', commit + ':' + path)
    blob = git('rev-parse', commit + ':' + path).decode().strip()
    if recorded is not None:
        assert recorded['git_blob'] == recorded['expected_blob'] == blob
        assert recorded['sha256'] == sha(raw)
    member = 'source/' + commit + '/' + path
    write(QA / member, raw)
    source_records.append({'commit': commit, 'path': path, 'member': member,
                           'git_blob': blob, 'sha256': sha(raw), 'bytes': len(raw)})
dump(QA / 'source-manifest.json', source_records)

prior_archive = (PRIOR / 'evidence.zip').read_bytes()
assert sha(prior_archive) == 'ab2e7ecb8e44f6c78c0f8af76c7bdb6bdf1f93a8ca41c23f20f680d86a49c2af'
original_probe = (PRIOR / 'test_capture_initialization_boundary.py').read_bytes()
assert sha(original_probe) == '823117ef4d6886ceebe747020aece47cc07f4758c7c94217cbdec31394a8e2d3'
prior_files = ['evidence.zip', 'manifest.json', 'review.md', 'review.json',
               'test_capture_initialization_boundary.py', 'capture-red.command.json',
               'capture-red.exit.json', 'capture-red.imports.json', 'capture-red.log', 'capture-red.xml']
prior_records = []
for name in prior_files:
    raw = (PRIOR / name).read_bytes()
    write(QA / 'prior-independent' / name, raw)
    prior_records.append({'path': str(PRIOR / name), 'member': 'prior-independent/' + name,
                          'sha256': sha(raw), 'bytes': len(raw)})
dump(QA / 'prior-independent.json', {'replayed': False, 'files': prior_records,
    'meaning': 'The unchanged ordinary create=False probe disproves the earlier capture assumption; '
               'its original 2-red/2-positive result is retained, not relabeled as a regression fixed by existing mode.'})
dump(QA / 'environment.json', {'python': sys.version, 'executable': sys.executable,
                              'platform': platform.platform(), 'sqlite': sqlite3.sqlite_version,
                              'observed_utc': datetime.now(UTC).isoformat()})

members = []
for path in sorted(QA.rglob('*')):
    if path.is_file() and path.name not in {'manifest.json', 'evidence.zip', 'seal-receipt.json'}:
        raw = path.read_bytes()
        members.append({'path': path.relative_to(QA).as_posix(), 'bytes': len(raw), 'sha256': sha(raw)})
# The explicitly retained inner original manifest/archive are payloads, too.
for name in ('manifest.json', 'evidence.zip'):
    path = QA / 'prior-independent' / name
    raw = path.read_bytes()
    members.append({'path': path.relative_to(QA).as_posix(), 'bytes': len(raw), 'sha256': sha(raw)})
members.sort(key=lambda item: item['path'])
assert len({item['path'] for item in members}) == len(members)
manifest = {'format': 'patchtrace-evidence/1', 'base': BASE, 'spec_tests': SPEC, 'source': SOURCE,
            'source_tree': git('rev-parse', SOURCE + '^{tree}').decode().strip(),
            'payload_count': len(members), 'git_snapshot_count': len(source_records), 'members': members}
dump(QA / 'manifest.json', manifest)
with zipfile.ZipFile(QA / 'evidence.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for name in [item['path'] for item in members] + ['manifest.json']:
        info = zipfile.ZipInfo(name, date_time=(2026, 11, 18, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, (QA / name).read_bytes())
with zipfile.ZipFile(QA / 'evidence.zip') as archive:
    assert len(archive.namelist()) == len(members) + 1
    assert archive.read('manifest.json') == (QA / 'manifest.json').read_bytes()
    for item in members:
        raw = archive.read(item['path'])
        assert len(raw) == item['bytes'] and sha(raw) == item['sha256']
result = {'source': SOURCE, 'payload_count': len(members), 'archive_members': len(members) + 1,
          'git_snapshots': len(source_records), 'archive_bytes': (QA / 'evidence.zip').stat().st_size,
          'archive_sha256': sha((QA / 'evidence.zip').read_bytes()),
          'manifest_sha256': sha((QA / 'manifest.json').read_bytes()),
          'verified_all_members': True}
dump(QA / 'seal-receipt.json', result)
print(json.dumps(result, indent=2))
