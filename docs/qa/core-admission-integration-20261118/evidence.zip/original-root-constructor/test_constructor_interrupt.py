"""Actual SQLite open failure before ProjectService receives its owned store."""
from __future__ import annotations

import json
import os
from pathlib import Path
import sqlite3

import pytest

from patchtrace.input_readers import InputReadError
from patchtrace.persistence import ProjectStore
from patchtrace.sample import synthetic_pe
from patchtrace.service import ProjectService

OUT=Path(os.environ['PATCHTRACE_CONSTRUCTOR_REVIEW_OUTPUT'])


@pytest.mark.parametrize('kind',['keyboard','system-exit','neutral-positive'])
def test_interrupted_constructor_closes_its_acquired_resources(tmp_path,monkeypatch,kind):
    paths=[tmp_path/(side+'.sys') for side in ('older','newer')]
    for variant,path in enumerate(paths):path.write_bytes(synthetic_pe(variant))
    root=tmp_path/'project'
    with ProjectService.create(*paths,'authored existing project',root) as service:
        owned=[root/'project.sqlite3',*(root/a.relative_path for a in service.project.artifacts)]
    before={p:p.read_bytes() for p in owned}
    primary={'keyboard':KeyboardInterrupt('authored constructor interruption'),
             'system-exit':SystemExit(7),'neutral-positive':InputReadError('cancelled')}[kind]
    stores=[];connections=[];boundaries=[]
    real_connect,real_init,real_close=sqlite3.connect,ProjectStore.__init__,ProjectStore.close

    class ActualConnection(sqlite3.Connection):
        def execute(self,sql,*args,**kwargs):
            if sql=='PRAGMA quick_check':
                boundaries.append(sql)
                raise primary
            return super().execute(sql,*args,**kwargs)

    def connect(*args,**kwargs):
        assert 'factory' not in kwargs
        connection=real_connect(*args,factory=ActualConnection,**kwargs)
        connections.append(connection)
        return connection

    def initialize(store,*args,**kwargs):
        stores.append(store)
        return real_init(store,*args,**kwargs)

    monkeypatch.setattr(sqlite3,'connect',connect)
    monkeypatch.setattr(ProjectStore,'__init__',initialize)
    caught=None
    try:
        try:ProjectService.open(root,maintenance=False)
        except BaseException as exc:caught=exc
        assert len(stores)==len(connections)==len(boundaries)==1
        store=stores[0]
        observed=dict(kind=kind,primary_preserved=caught is primary,caught_type=type(caught).__name__,
            closed=store.closed,connection_closed=store.connection is None,lock_closed=store.lock is None,
            boundary=boundaries[0],actual_sqlite_connection=isinstance(connections[0],sqlite3.Connection),
            project_files_unchanged=all(p.read_bytes()==data for p,data in before.items()))
        OUT.mkdir(parents=True,exist_ok=True)
        with (OUT/(kind+'.json')).open('x') as stream:json.dump(observed,stream,indent=2);stream.write('\n')
    finally:
        # Close only these test-owned resources after observing product behavior.
        for store in stores:real_close(store)
    assert caught is primary
    assert observed['project_files_unchanged']
    assert observed['closed'] and observed['connection_closed'] and observed['lock_closed']
