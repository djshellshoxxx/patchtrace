## Why this integration is needed

The retained #304 → #307 chain and reviewed follow-ups contain useful CVE/KB, ownership, persistence and analyst-workflow repairs, but required production and platform gates remain incomplete. This PR preserves their provenance and qualified source slices while keeping main unchanged and the release hold explicit.

**[no release] — do not merge as beta-ready.** Main is `9c411ca3d7b47f950be5f0c6f01b3c54184554c6`. No release, tag or deployment is authorized.

## Latest independently reviewed milestone

Actual head: `771e5a775f5bf60a8d9094232b51dcdbb47d6389`  
Tree: `ddf151c6ff8fb3f70b74378525fe1d8d5c9050e3`  
Equal-tree local checkpoint: `361dd495a7e050121f2b3cae4e7678faad7fee35`

This update appends 18 verified commits to `fb09e43499f1abb84615b66b976629c22d5a41c2`, with a non-force expected-head update. Every remote commit's tree, ordered parent, local source attribution and literal release hold was read back before moving the ref.

| Change | Resulting behavior |
| --- | --- |
| Isolated dependency UTF-8 invocation | Fourteen Python argv sites explicitly select UTF-8 while preserving isolated mode, pins, arguments, environment filtering, raw output, limits and verdict validation. |
| Internal KB held-reader propagation | The original pair and checkpoint reach existing inspection, complete attachment hashes and core creation. Ordinary injected calls, saved/global source admission, caller-thread SQLite and exact stop reasons remain. No pathname fallback or new package entry point. |
| Short-read PE prefix correction | Valid short reads accumulate within the existing 4096-byte prefix. Full hashes and byte accounting remain; headers beyond the original bound still refuse. |
| Bounded Windows diagnostic context | Fixed vocabulary/numeric stderr records retain socket and child-stage error context. At most 16 attempted records per process, each below 512 bytes. Existing capabilities, Job/handle policy, deadlines, stdout schema and acceptance decisions remain. |
| Core admission design | Source-bound proposal for existing create/open/load identity and checkpoint seams. The implementation is a separate workstream; this design supplies no package admission or recovery authority. |

## Exact-source verification

Tested local source: `7b5f558fb1a51d45427648c39c15995ab3697e2c`  
Corresponding remote source: `9a186bfbfb0b91b87650776ae35cee66ed3327a5`  
Tested tree: `deff3849cd430ae12f4278e82fa92d8ca6df4e34`

- **803 passed; zero failures, errors or skips; 9.76 seconds.**
- 23 files: all three affected author scopes plus two unchanged independent probes.
- All 118 imported project/tool modules match Git bytes; 14 reviewed owner source/test/spec paths are exact.
- Final design/checkpoint commits change only documentation/evidence; product, tests, workflows, specs, schemas and project configuration equal the tested source.
- Full normal `ruff check src tests tools` passes.
- The unsuppressed isolated strict S scan **still fails on 80 unchanged path/code/selected-statement sites**. Manual source dispositions do not waive that gate.
- Original KB API and short-read failures, native missing-formatter errors, the test grammar correction and the initial combined **802-pass/one-registry-failure** result remain retained. The registry correction adds one required row without altering a test or production assertion.

Complete command/environment/import/audit/XML records and independent packet verification:
[latest checkpoint](https://github.com/djshellshoxxx/patchtrace/blob/771e5a775f5bf60a8d9094232b51dcdbb47d6389/docs/qa/kb-native-followup-20261118/README.md).

Its archive contains 137 verified payloads, 6,984,216 bytes; SHA-256:
`cc85f074a8e9b398a2d5f2a15a3a648c962e59f3dd7a931b50411bff7bc129fe`.

The prior 1,103-pass/one-native-skip worker/core/navigation gate and earlier 1,028/6,356-pass gates remain attributed to their own sources. Overlapping counts are not cumulative coverage or completion percentages.

## Fresh branch and hosted evidence

The retained refresh covers **316 branches and 63 open PRs**. All eleven changed/new tips since the complete inventory are actual ancestors of the preceding fb09 head; all 131 original focal tips remain unchanged. Broader residue remains explicitly open. #304 and #307 remain open/unmerged at `d8c02cae` and `58fc1306`; no superseded PR is closed before its replacement qualifies on main.

Source-bound fb09 evidence retains 16 API-size/SHA/CRC-verified artifacts, eight exact decoded logs and 18 canonical source snapshots. Windows BinDiff again has an actual no-network failure behind a green advisory badge: depth 0 only and exit 125. Its C bytes predate this diagnostic change, so the failure stage is still unknown. Windows dependency inventories also repeat the old-source CP1252 failure before final audit.

Linux fixture/profile successes retain their exact scope and source. The captured full Linux/Windows QA and five Qt shards were pending. Neither those earlier results nor their badges qualify this new head.

## Remaining merge/release gates

Required full/platform/Qt/native/package/security/reproducibility acceptance is incomplete. Whole CVE-to-function and package-to-project journeys remain incomplete. Durable held-origin intent, expected project identity, pre-recovery refusal, provenance and idempotent reconciliation must precede any exposed package route. Actual Windows/native execution cannot be inferred from portable tests.

[Completion matrix](https://github.com/djshellshoxxx/patchtrace/blob/771e5a775f5bf60a8d9094232b51dcdbb47d6389/docs/plans/patchtrace-completion-matrix.md) · [Consolidation ledger](https://github.com/djshellshoxxx/patchtrace/blob/771e5a775f5bf60a8d9094232b51dcdbb47d6389/docs/plans/autonomous-consolidation-20261118/consolidation-ledger.md)

No main merge, PR closure, force-push, branch deletion, tag, release or deployment has been performed.
