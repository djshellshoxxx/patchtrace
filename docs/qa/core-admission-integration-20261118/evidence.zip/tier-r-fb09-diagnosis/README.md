# Retained fb09 Tier R: bounded source trace and diagnostic-loss probe

## Scope and disposition

This packet inspects the already retained PR316 **fb09** evidence. It makes no
source change, recompiles no corpus image, runs no engine, downloads no additional
artifact, changes no corpus outcome, and executes no target/native image.

Exact actual source: `fb09e43499f1abb84615b66b976629c22d5a41c2`; merge preview
`cf534b0e79fe523ce4ee376a277fa398ffe4af70`; shared tree
`db005f5ede44b60fa2cf92581ac7dd685b087d99`. Original evidence remains unchanged in
`qa/hosted-pr316-fb09` and its sealed archive SHA-256
`dfeaa42b96f85b72883092c2fa8336ec4551f7898fc31689a6ef262b47930528`.

One source-grounded reporting defect is reproduced: `run_shard` treats an
exit-code-1 child as `findings` even when it emits no parseable JSON object, and
does not retain/log that child's stderr. An authored injected-runner control
therefore loses a traceback-style failure exactly at this boundary. This explains
why the retained Windows aggregate cannot establish the original child error;
it does **not** establish what caused that original error.

The six Linux `no functions in the older file` outcomes are still failures.
Their native function-discovery cause is not proven by the retained aggregate
or this source-only inspection. No gate or benchmark interpretation is changed.

## Original receipt facts

| Evidence | Identity |
| --- | --- |
| Tier R run | 44402970061, attempt 1 |
| Linux aggregate job | 135156548760 |
| Aggregate artifact | 14473159146; 6,048 bytes |
| Aggregate SHA-256 | `f63f5c13e5bf80ffcc0d896dcb3927b92676b32d367462d2c192d243a5c961db` |
| Windows advisory job | 135150625486 |
| Windows artifact | 14474781535; 588 bytes |
| Windows SHA-256 | `2d1bb3fab55ff903780e1398b6994118ac07bb33e396969cd8682c60210c87ec` |

The unchanged original ZIPs and their prior API/member verification records are
included under `original/`. Only JSON receipt members were read. Their source
binding was established in the original fb09 hosted packet; this follow-up does
not poll or reinterpret the remote jobs.

The Linux CI summary is `warning`: **5/11** rz-diff pairs complete. The six failed
pairs are:

- `aa-tiny-v1-O2-rebuild`
- `mutation-tiny-v1-cmp-flip-1000-O2`
- `noise-tiny-v1-msvc-free-O0-msvc-free-O1`
- `noise-tiny-v1-msvc-free-O2-mingw-gcc-O2`
- `noise-tiny-v1-msvc-free-O2-msvc-free-Os`
- `ours-_template-tiny-v1-v2-O2`

Each has null metrics/output digest and the same normalized explanation: rz-diff
reported no functions in the older file and compared nothing. Five zlib pairs
complete with actual metrics; completion itself is not an accuracy acceptance.
A separate byte-identical source-change card is skipped outside these eleven
engine pairs. The build/label cases succeed, and the retained tiny A/A label
summary contains four project functions with no runtime functions.

The Windows artifact contains eleven `findings`, each with only `reason: exit 1`;
their digests are null, and the artifact has no labels, features or engine reports.
It contains no child stderr, compiler inventory or raw engine output. These facts
are insufficient to identify an import failure, missing compiler, encoding error
or any other concrete original child cause.

## Source trace

Fourteen source/fixture snapshots are retained under `source/`, pinned by Git blob
and SHA-256 in `source-snapshots.json`. They are exact bytes from the shared fb09
tree. The inspected paths are also byte-identical to the unchanged diagnostic
checkout, but the executable probe below separately pins all transitive project
imports to the old tree.

`src/patchtrace/secondary/rzdiff.py::interpret` emits the normalized no-functions
message when the engine returns zero, stdout is empty and its stderr matches the
no-functions pattern. The Tier R provider uses the production secondary adapter
and preserves that failure in its report. The private engine images use the
`symbols: hidden` path. The current workflow uploads aggregate metadata, not the
images or each raw engine process receipt; those raw details cannot be recovered
from the retained aggregate.

The tiny fixture contains four ordinary C functions with no explicit export
declarations. Its `msvc-free` builder uses freestanding Clang, links a DLL with
`/noentry`, `/nodefaultlib`, `/opt:noref` and `/opt:noicf`, then strips the engine
image with `llvm-strip --strip-all`. These are source facts. Lack of useful
function-discovery seeds is a candidate explanation to test, not a demonstrated
cause of this native run. This packet does not infer actual entry, export,
exception-directory or section contents from build flags alone.

For the Windows receipt loss, `shard.py::_classify` maps return code 1 to
`findings` without requiring a parsed command summary. In `run_shard`, stderr is
reported only for timeout/failed/blocked cases; an ordinary `findings` case gets
the generic `exit 1` reason. A child with absent/malformed JSON and traceback
stderr follows that branch and loses the diagnostic. The supplied pure probe
calls the real `run_shard` with its existing injected runner seam, so it launches
no compiler, engine or child process.

## Authored probe and exact-source result

`test_exit1_diagnostics.py` is unchanged across all three runs. Its two expected-red
controls supply exit 1 with empty or malformed JSON stdout and a fixed authored
stderr message. They require that unexpected command failure to be classified
and diagnosed. The two positive controls preserve declared findings with a JSON
summary, and preserve a blocked response with stderr.

The final exact-source run is `exit1-red-v3.*`:

- **2 expected failures / 2 positive passes**, 0.37 seconds.
- **38 project/tool imports**, every byte pinned to the fb09 tree; no source drift.
- **Zero network or child-process attempts** after the audit guard is installed.
- One read-only `git ls-tree` metadata command precedes the guard. The authored
  runner injects both the suite and engine-evaluation responses.
- No native result, Windows capability, compiler availability or corpus accuracy
  claim follows from these portable controls.

Preceding setup results are retained rather than overwritten:

1. `exit1-red.*`: 2 expected-red/2 positive assertions were observed, but the import
   audit detected unrelated `ingestion.py` and `persistence.py` bytes from the
   diagnostic checkout differing from the old source. The runner returned **97**;
   this is not the final exact-source result.
2. `exit1-red-v2.*`: 37 captured import files were materialized from Git, but the
   older source additionally imports `patchtrace.input_readers`. Collection failed
   with that missing canonical file; the runner returned **2**, with no drift or
   denied network/child attempts. This is a setup error, not a corpus failure.
3. The missing file was added from the same old Git tree. `run_probe_v3.py` uses
   all 38 exact files under `exact-source/` and produces the final **2 red/2
   positive** result. `exact-source-snapshots.json` records every file. Neither
   original runner/log nor the test assertions were changed.

## Bounded next questions, not implementation

A narrow reporting repair could require a parseable command summary before an
exit-1 response can count as declared findings, preserve existing valid findings,
and route unexpected exit-1 stderr through the existing bounded diagnostic path.
Its source/spec/tests require root review before edits. It must not claim to fix
the unknown original Windows child cause.

A separate future native probe could rebuild the authored tiny baseline with the
recorded pinned toolchain, retain bounded PE entry/export/exception metadata and
raw rz-diff stdout/stderr, and compare explicit diagnostic variants without
modifying the frozen canonical corpus. That work is not executed or qualified
here. Original six failed engine outcomes remain unchanged.

`manifest.json` and `seal.json` define the immutable packet. There is no source
commit for this read-only follow-up, and the diagnostic branch stays unchanged.
