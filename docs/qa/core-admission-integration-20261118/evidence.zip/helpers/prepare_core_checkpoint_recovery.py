"""Retain owned space-recovery evidence and append the checkpoint environment error."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
STAGE = Path('/tmp/patchtrace-core-space-recovery-405t855n')
DEST = ROOT / 'qa/core-admission-space-review'
Q = ROOT / 'qa/core-admission-integration'
HEAD = 'cf5f7301c735c6b6ca1c0d64242804bfb432dfa1'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert not git('status', '--porcelain')
assert not (REPO / 'docs/qa/core-admission-integration-20261118').exists()
assert not DEST.exists() and STAGE.is_dir() and not STAGE.is_symlink()
setup = json.loads((STAGE / 'setup.json').read_text())
assert sha((STAGE / 'cleanup.py').read_bytes()) == setup['helper_sha256']
assert setup['helper_sha256'] == 'cc57e641c7b106f5900701ba8b9e01f3bc959d3315dda2eb7ead0d1f392eb652'
evidence = STAGE / 'evidence'
before = json.loads((evidence / 'pre-removal.json').read_text())
receipt = json.loads((evidence / 'receipt.json').read_text())
assert receipt['removed_checkouts'] == 7 and receipt['tracked_files_verified'] == 28491
assert receipt['support_files_retained'] == 1545 and receipt['branch_heads_unchanged']
assert not receipt['force'] and not receipt['branch_deletion']
for row in before['worktrees']:
    assert row['head'] == setup['selected'][row['name']]
    assert git('rev-parse', row['branch']).decode().strip() == row['head']
    assert not (ROOT / row['name']).exists()
    removed = json.loads((evidence / (row['name'] + '-removal.json')).read_text())
    assert removed['exit'] == 0 and removed['branch_head_after'] == row['head']
    tracked = json.loads((evidence / (row['name'] + '-tracked-files.json')).read_text())
    assert tracked['head'] == row['head'] and len(tracked['files']) == row['tracked_files']
archive = evidence / 'retained-test-support.zip'
assert sha(archive.read_bytes()) == receipt['support_archive_sha256'] == before['support_archive_sha256']
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert len(z.namelist()) == len(set(z.namelist())) == len(before['support']) == 1545
    assert set(z.namelist()) == {r['path'] for r in before['support']}
    for row in before['support']:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
files = []
for path in sorted(STAGE.rglob('*')):
    if path.is_file():
        assert not path.is_symlink()
        data = path.read_bytes()
        files.append(dict(path=path.relative_to(STAGE).as_posix(), bytes=len(data), sha256=sha(data)))
shutil.copytree(STAGE, DEST)
for row in files:
    data = (DEST / row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256']
with (DEST / 'root-retention-verification.json').open('x') as f:
    json.dump(dict(at=datetime.now(timezone.utc).isoformat(), files=files,
        bytes=sum(r['bytes'] for r in files), source_stage=str(STAGE), stage_retained=True,
        all_selected_branch_heads_unchanged=True, archive_crc_and_all_support_hashes_verified=True,
        excluded_dirty_worktree='cve-review',
        agent_ownership_confirmations=['ci_qualification', 'integration_inventory', 'report_evidence_review'],
        process_visibility='Current execution namespace; agent ownership confirmations supplement it.'), f, indent=2)
    f.write('\n')
initial_note = Q / 'checkpoint-note.md'
note_bytes = initial_note.read_bytes()
with (Q / 'checkpoint-note-initial.md').open('xb') as f:
    f.write(note_bytes)
old_helper = ROOT / 'ops/seal_core_admission_integration_checkpoint.py'
old_bytes = old_helper.read_bytes()
with (Q / 'initial-seal-environment-error.json').open('x') as f:
    json.dump(dict(tool_chunk='a1493b', helper=str(old_helper), helper_sha256=sha(old_bytes),
        initial_note_sha256=sha(note_bytes), source_head=HEAD,
        statement='DEST.mkdir(exist_ok=False)', error_type='OSError', errno=28,
        error='No space left on device', destination=str(REPO / 'docs/qa/core-admission-integration-20261118'),
        occurred_before_archive_and_repository_mutation=True,
        destination_still_absent_and_checkout_clean_on_recheck=True,
        correction='Preserved original helper/note; reclaim only completed attributed clean worktrees; add recovery evidence in v2.',
        no_source_test_or_acceptance_change=True), f, indent=2)
    f.write('\n')
with initial_note.open('a') as f:
    f.write('''

## Checkpoint environment error and verified space recovery

The first seal attempt stopped at its destination-directory creation with
`OSError: [Errno 28] No space left on device` (tool chunk `a1493b`). No archive or
repository change was written. Its helper and input note remain byte-identical;
the v2 helper adds this recovery evidence only. The tested source, tests, limits
and acceptance results are unchanged.

The coordinator then verified seven completed, clean, branch-backed worktrees:
cvrf-pilot, inventory, object-publication, release-qualification,
security-contract-triage, tooltip-review and integration307. All 28,491 tracked
files matched their canonical Git blobs before removal. The support archive
retains 1,545 non-bytecode ignored files with per-file hashes and a verified CRC;
only reproducible Python bytecode was omitted. The three active agents confirmed
no ownership or pending process in these paths. The process scan covers the
current execution namespace, supplemented by those explicit ownership checks.

All seven checkouts were removed with ordinary `git worktree remove`, without
force. Every branch ref remains at its original exact SHA. This removal's own
measurement increased available bytes from 1,205,018,624 to 1,705,549,824. The
dirty cve-review worktree, active checkouts, failed-run evidence, dependency
environments and unknown-provenance files were retained. The complete cleanup
packet was copied from its owned temporary stage and independently checked for
byte equality, branch retention, ZIP integrity and every support-file hash.
The temporary stage remains available. This recovery is separate from the four
earlier completed-checkout removals documented above.
''')
old = old_bytes.decode()
needle = "('cleanup', ROOT / 'qa/kb-native-space-review')]:"
assert old.count(needle) == 1
new = old.replace(needle, "('cleanup', ROOT / 'qa/kb-native-space-review'),\n                    ('emergency-cleanup', ROOT / 'qa/core-admission-space-review')]:")
needle = "'seal_core_admission_integration_checkpoint.py']:"
assert new.count(needle) == 1
new = new.replace(needle, "'seal_core_admission_integration_checkpoint.py',\n             'prepare_core_checkpoint_recovery.py', 'seal_core_admission_integration_checkpoint_v2.py']:")
with (ROOT / 'ops/seal_core_admission_integration_checkpoint_v2.py').open('x') as f:
    f.write(new)
assert old_helper.read_bytes() == old_bytes
assert not git('status', '--porcelain')
print(json.dumps(dict(retained_files=len(files), retained_bytes=sum(r['bytes'] for r in files),
    support_files_verified=1545, branch_heads_verified=7, source_unchanged=True,
    original_helper_sha256=sha(old_bytes), initial_note_sha256=sha(note_bytes))))
