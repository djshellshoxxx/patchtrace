"""Pin one bounded independent constructor probe; preserve its first observations."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parent.parent
REPO=ROOT/'security-residual-qa'
OUT=ROOT/'qa/core-initialization-independent'
SOURCE='441c47c2262603555aa77c11e63fedcce11ba502'
TEST=OUT/'test_constructor_interrupt.py'


def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def write(name,value):
    with (OUT/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')


head=git('rev-parse','HEAD').decode().strip()
assert not git('diff',SOURCE,head,'--','src','tests','tools','docs/specs','pyproject.toml')
for path in ('src/patchtrace/persistence.py','src/patchtrace/service.py'):
    assert (REPO/path).read_bytes()==git('show',SOURCE+':'+path)
owned=Path(tempfile.mkdtemp(prefix='patchtrace-constructor-root-red-'))
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',QT_QPA_PLATFORM='offscreen',
    PYTHONPATH=os.pathsep.join(map(str,[REPO/'src',REPO/'tests',REPO,ROOT/'ops'])),
    GIT_ALLOW_PROTOCOL='file',GIT_CONFIG_NOSYSTEM='1',GIT_CONFIG_GLOBAL='/dev/null',GIT_TERMINAL_PROMPT='0',
    PATCHTRACE_CONSTRUCTOR_REVIEW_OUTPUT=str(OUT/'initial-observations'),
    PATCHTRACE_BATCH_COLLECTION_RECEIPT=str(OUT/'initial-imports.json'),
    PATCHTRACE_OFFLINE_GUARD_RECEIPT=str(OUT/'initial-offline-guard.json'))
argv=[sys.executable,str(ROOT/'ops/continuation_offline_pytest.py'),'-q','-ra','-p','no:cacheprovider',
    '-p','project_and_tools_receipt',str(TEST),'--basetemp='+str(owned/'pytest'),'--junitxml='+str(OUT/'initial.xml')]
write('initial-command.json',dict(source=SOURCE,checkout_head=head,argv=argv,cwd=str(REPO),pythonpath=env['PYTHONPATH'],
    test_sha256=sha(TEST),helper_sha256=sha(__file__),owned_temp=str(owned),started_utc=datetime.now(timezone.utc).isoformat()))
start=time.monotonic()
with (OUT/'initial.log').open('x') as stream:
    result=subprocess.run(argv,cwd=REPO,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=120)
imports=json.loads((OUT/'initial-imports.json').read_text())
drift=[]
for name,row in imports['final_sources'].items():
    path=Path(row['path'])
    if not path.is_relative_to(REPO):drift.append(name);continue
    raw=git('show',SOURCE+':'+path.relative_to(REPO).as_posix())
    if sha(path)!=hashlib.sha256(raw).hexdigest() or row['sha256']!=sha(path):drift.append(name)
cases=list(ET.parse(OUT/'initial.xml').getroot().iter('testcase'))
counts=dict(tests=len(cases),failures=sum(c.find('failure') is not None for c in cases),
    errors=sum(c.find('error') is not None for c in cases),skipped=sum(c.find('skipped') is not None for c in cases))
after=git('rev-parse','HEAD').decode().strip()
assert not git('diff',SOURCE,after,'--','src','tests','tools','docs/specs','pyproject.toml')
assert not drift
receipt=dict(source=SOURCE,checkout_head_after=after,exit=result.returncode,junit=counts,elapsed=time.monotonic()-start,
    canonical_imports=len(imports['final_sources']),drift=drift,test_sha256=sha(TEST),owned_temp_retained=str(owned))
write('initial-exit.json',receipt)
print(json.dumps(receipt));print((OUT/'initial.log').read_text())
raise SystemExit(result.returncode)
