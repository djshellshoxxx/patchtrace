"""Independently verify new hosted Windows evidence without executing images."""
from __future__ import annotations

from collections import defaultdict
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
Q = ROOT / 'qa/hosted-pr316-771e'
OUT = ROOT / 'qa/core-admission-root-review/hosted-771e-verification.json'
HEAD = '771e5a775f5bf60a8d9094232b51dcdbb47d6389'
PREVIEW = 'ac6632ad6de486ba16343f0eeb4a2b5a446e4ac1'
TREE = 'ddf151c6ff8fb3f70b74378525fe1d8d5c9050e3'
BASE = '9c411ca3d7b47f950be5f0c6f01b3c54184554c6'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def unique(rows):
    result = {}
    for key, value in rows:
        assert key not in result
        result[key] = value
    return result


def invalid(value):
    raise ValueError(value)


def decode(raw):
    assert len(raw) <= 8 * 1024 * 1024
    return json.loads(raw, object_pairs_hook=unique, parse_constant=invalid)


def read(path):
    return decode(path.read_bytes())


def api(name):
    delivery = read(Q / (name + '.delivery.json'))['response']
    assert not delivery.get('isError')
    return decode(delivery['structuredContent']['content'])


def distributions(rows, wrapped=False):
    entries = [row['metadata'] if wrapped else row for row in rows]
    result = {(re.sub(r'[-_.]+', '-', row['name']).lower(), row['version']) for row in entries}
    assert len(result) == len(entries)
    return result


seal, manifest = read(Q / 'seal.json'), read(Q / 'manifest.json')
archive = (Q / 'evidence.zip').read_bytes()
assert sha(archive) == seal['sha256'] == '34444dbc44582dcfb9a90656b54d1029d84e96be9cd71b11585fdf676648e7bd'
assert len(archive) == seal['bytes'] == 2546594
assert sha((Q / 'manifest.json').read_bytes()) == seal['manifest_sha256'] == '35a0d1b304713d6c79b6d9f279a16936d071d3a4c2dab3c7165d4bd98f8338f6'
assert manifest['source'] == dict(base=BASE, head=HEAD, preview=PREVIEW, tree=TREE)
assert git('rev-parse', '361dd495a7e050121f2b3cae4e7678faad7fee35^{tree}').decode().strip() == TREE
pr, head, preview = api('pull-316'), api('head-commit'), api('preview-commit')
assert pr['head']['sha'] == head['sha'] == HEAD
assert pr['base']['sha'] == BASE and pr['merge_commit_sha'] == preview['sha'] == PREVIEW
assert head['commit']['tree']['sha'] == preview['commit']['tree']['sha'] == TREE
assert [r['sha'] for r in preview['parents']] == [BASE, HEAD]
assert '[no release]' in head['commit']['message']
artifact_count = member_count = 0
with zipfile.ZipFile(io.BytesIO(archive)) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == 246
    assert set(z.namelist()) == {r['path'] for r in manifest['files']} | {'manifest.json'}
    assert z.read('manifest.json') == (Q / 'manifest.json').read_bytes()
    for row in manifest['files']:
        path = Path(row['path'])
        assert not path.is_absolute() and '..' not in path.parts
        data = z.read(row['path'])
        assert data == (Q / path).read_bytes() and len(data) == row['bytes'] and sha(data) == row['sha256']
        if not row['path'].endswith('.zip'):
            for url in re.findall(rb'https?://[^\s"<>]+', data):
                assert not any(token in url for token in (b'X-Amz-Signature=', b'?sig=', b'&sig='))
    assert len(manifest['git_sources']) == 10
    for row in manifest['git_sources']:
        raw = git('show', row['tree'] + ':' + row['path'])
        assert raw == z.read(row['archived_path']) and sha(raw) == row['sha256']
        assert hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest() == row['git_blob']
    for name in z.namelist():
        if not name.startswith('artifacts/') or not name.endswith('.verified.json'):
            continue
        record = decode(z.read(name))
        meta = record['api_metadata']
        raw = z.read(record['archive'])
        assert len(raw) == record['verified_size'] == meta['size_in_bytes']
        assert sha(raw) == record['verified_sha256'] == meta['digest'].removeprefix('sha256:')
        assert meta['workflow_run']['head_sha'] == HEAD
        assert not record['signed_transfer_url_retained'] and not record['executed_members']
        with zipfile.ZipFile(io.BytesIO(raw)) as original:
            assert original.testzip() is None
            assert set(original.namelist()) == {r['path'] for r in record['members']}
            for row in record['members']:
                data = original.read(row['path'])
                assert len(data) == row['bytes'] and sha(data) == row['sha256']
                assert original.getinfo(row['path']).CRC == row['crc32']
                if row['retained_as_text']:
                    assert data == z.read(f"text/{meta['id']}/" + row['path'])
                member_count += 1
        artifact_count += 1
assert artifact_count == 3 and member_count == 206
verification = read(Q / 'verification.json')
for row in verification['decoded_logs']:
    name = Path(row['path']).name.removesuffix('.log')
    delivery = read(Q / (name + '.delivery.json'))['response']['structuredContent']['content']
    raw = delivery.encode('utf-8')
    assert raw == (Q / row['path']).read_bytes() and sha(raw) == row['sha256'] and len(raw) == row['bytes']
assert len(verification['decoded_logs']) == 3
jobs = {r['id']: r for r in api('jobs-44409963273')['jobs']}
run = next(r for r in api('head-workflow-runs')['workflow_runs'] if r['id'] == 44409963273)
assert run['head_sha'] == HEAD and run['event'] == 'push' and run['run_attempt'] == 1
assert run['path'] == '.github/workflows/dependency-security.yml'
profiles = []
for artifact, profile, job_id, count in [(14475803357, 'runtime', 135175146507, 17),
                                       (14475753388, 'packaging', 135175146843, 34)]:
    folder = Q / 'text' / str(artifact)
    job = jobs[job_id]
    assert job['head_sha'] == HEAD and job['run_id'] == 44409963273 and job['run_attempt'] == 1
    assert job['name'] == f'dependency-audit (windows-latest, {profile})'
    assert job['status'] == 'completed' and job['conclusion'] == 'success'
    assert [s['conclusion'] for s in job['steps'] if s['name'] == 'Audit installed dependencies'] == ['success']
    context = read(folder / 'context.json')
    assert context['source_sha'] == HEAD and context['source_tree'] == TREE
    assert context['profile'] == profile and context['platform'] == 'windows-latest'
    assert context['run_id'] == 44409963273 and context['run_attempt'] == 1
    processes = list(folder.glob('*.process.json'))
    for path in processes:
        p = read(path)
        assert type(p['exit_code']) is int and p['exit_code'] == 0
        assert p['timed_out'] is False and p['output_limited'] is False and p['error'] is None
        assert p['argv'][1:4] == ['-I', '-X', 'utf8']
        for stream in ['stdout', 'stderr']:
            data = (folder / (path.name.removesuffix('.process.json') + '.' + stream)).read_bytes()
            data.decode('utf-8', errors='strict')
            assert sha(data) == p[stream + '_sha256']
    inventory, inspected = read(folder / 'inventory.json'), read(folder / 'profile-inspect.stdout')
    identity = read(folder / 'profile-identity.stdout')
    environment = inspected['environment']
    assert identity['version'] == environment['python_full_version'] == environment['implementation_version'] == '3.12.10'
    assert identity['system'] == environment['platform_system'] == 'Windows'
    assert identity['machine'] == environment['platform_machine'] == 'AMD64'
    assert inspected['pip_version'] == '26.3' and environment['sys_platform'] == 'win32'
    auditable = distributions(inventory['auditable'])
    installed = distributions(inspected['installed'], wrapped=True)
    owned = inventory['repository_owned']
    assert owned['name'] == 'patchtrace' and owned['origin'] == 'file:///D:/a/patchtrace/patchtrace'
    assert installed == auditable | {('patchtrace', owned['version'])}
    assert set((folder / 'audit-requirements.txt').read_text().splitlines()) == {n + '==' + v for n, v in auditable}
    audit = read(folder / 'audit.stdout')
    assert distributions(audit['dependencies']) == auditable and len(auditable) == count
    assert ('pip', '26.3') in auditable and audit['fixes'] == []
    assert all(r['vulns'] == [] and 'skip_reason' not in r for r in audit['dependencies'])
    scanner_bytes = (folder / 'scanner-inspect.stdout').read_bytes()
    scanner = decode(scanner_bytes)
    assert ('pip-audit', '2.10.1') in distributions(scanner['installed'], wrapped=True)
    assert scanner['environment'] == environment and scanner['pip_version'] == '26.3'
    assert b'\xf0\x9f\x91\x8b' in scanner_bytes
    for prefix in ['profile', 'scanner']:
        boot, transition = read(folder / f'{prefix}-bootstrap-inspect.stdout'), read(folder / f'{prefix}-bootstrap-install.json')
        assert boot['pip_version'] == transition['pip_version'] == '25.0.1'
        assert boot['environment'] == transition['environment'] == environment
        assert distributions(transition['install'], wrapped=True) == {('pip', '26.3')}
        installation = read(folder / f'{prefix}-install.json')
        assert installation['environment'] == environment and installation['pip_version'] == '26.3'
    profiles.append(dict(profile=profile, artifact_id=artifact, job_id=job_id,
        process_receipts=len(processes), auditable_distributions=count,
        audit_inventory_requirements_equal=True, vulnerability_rows=0, skips=0, fixes=0,
        actual_utf8_wave_bytes=True, bootstrap_issuer='25.0.1', target_pip='26.3'))

native = Q / 'text/14475538670'
build = read(native / 'network-build/build.json')
assert build['status'] == 'passed' and build['source'] == dict(commit=PREVIEW, tree=TREE)
assert read(native / 'network-build/compiler.process.json')['returncode'] == 0
for name, digest in build['sources'].items():
    path = 'tools/windows_network/' + name
    raw = git('show', TREE + ':' + path)
    assert sha(raw) == digest and raw == git('show', '9ca3c078c1e14ba4895a5e10c00234985a0b3fc2:' + path)
image_members = read(Q / 'artifacts/artifact-14475538670.verified.json')['members']
for name, digest in build['images'].items():
    assert next(r['sha256'] for r in image_members if r['path'] == 'network-build/' + name + '.exe') == digest
receipt = read(native / 'network/receipt.json')
assert receipt['source'] == build['source'] and receipt['status'] == 'failed'
assert receipt['helper_sha256'] == build['images']['launcher'] and receipt['probe_sha256'] == build['images']['probe']
def ndjson(name):
    return [decode(line) for line in (native / name).read_bytes().splitlines() if line.strip()]
before = ndjson('network/probe-before.stdout')
assert [r['depth'] for r in before] == [0, 1, 2]
assert all(r['appcontainer'] is False and len(r['cases']) == 5 and all(c['status'] == 'connected' and c['error'] == 0 for c in r['cases']) for r in before)
started, finished = ndjson('network/01-probe-denied.ndjson')
assert all(started[k] is True for k in ['appcontainer', 'suspended', 'job_before_resume', 'token_before_resume', 'image_locked'])
assert started['capability_count'] == 0 and started['handles'] == ['nul', 'pipe', 'pipe']
assert finished == dict(phase='finished', returncode=125, timed_out=False, tree_empty=True)
restricted = ndjson('network/01-probe-denied.stdout')
assert len(restricted) == 1
probe = restricted[0]
assert probe['depth'] == 0 and probe['pid'] == started['pid'] and probe['parent_pid'] == started['owner_pid']
assert probe['sid'] == started['sid'] and probe['created'] == started['created'] and probe['nonce'] == receipt['nonce']
assert [r['error'] for r in probe['cases']] == [10060, 10060, 10060, 10060, 10013]
diagnostics = ndjson('network/01-probe-denied.stderr')
assert len(diagnostics) == 9
assert all(len(line) + 1 < 512 for line in (native / 'network/01-probe-denied.stderr').read_bytes().splitlines())
by_owner = defaultdict(list)
for row in diagnostics:
    assert row['diagnostic'] == 'windows-network-diagnostic/1'
    by_owner[row['owner_pid']].append(row)
for owner, rows in by_owner.items():
    assert owner in [started['pid'], started['owner_pid']]
    assert [r['sequence'] for r in rows] == list(range(1, len(rows) + 1)) and len(rows) <= 16
children = by_owner[probe['pid']]
assert [r['stage'] for r in children] == ['socket-connect-wait', 'socket-connect-wait', 'socket-receive-wait', 'socket-receive-wait', 'socket-error', 'nul-open', 'child-spawn']
assert all(r['kind'] == 'win32' and r['error'] == 5 for r in children[-2:])
assert all(r['sent_bytes'] == 32 and r['received_bytes'] == 0 for r in children[2:4])
assert [r['stage'] for r in by_owner[started['owner_pid']]] == ['child-exit', 'child-finish']
assert all(r['error'] == 125 and r['subject_pid'] == probe['pid'] for r in by_owner[started['owner_pid']])
status = read(native / 'bindiff.json')
assert status['status'] == status['checks']['no_network']['status'] == 'failed'
assert len(status['checks']) == 7 and all(r['status'] == 'passed' for k, r in status['checks'].items() if k != 'no_network')
assert '1 failed in 38.01s' in (Q / 'logs/log-windows-bindiff.log').read_text()
record = dict(source=manifest['source'], archive_sha256=sha(archive), archive_bytes=len(archive),
    payloads=245, canonical_git_sources=10, original_artifacts=3, original_members=206, decoded_logs=3,
    windows_dependency=profiles, native_compiler='passed', native_acceptance='failed',
    native_diagnostics=9, immediate_boundary='Restricted descendant NUL open reports Win32 error5 before CreateProcessW.',
    unrestricted_depths=[0, 1, 2], restricted_depths=[0], other_native_subchecks_passed=6,
    images_extracted_or_executed=False, signed_transfer_urls=False,
    review='Root read the full frozen README, both verifier implementations, actual raw diagnostics and exact source ownership. Native compile and Windows dependency inventory/audit have real hosted evidence; the failed no-network path, four loopback timeouts, absent descendant/lifecycle stages and full platform/package/security gates remain unqualified.')
with OUT.open('x') as f:
    json.dump(record, f, indent=2)
    f.write('\n')
print(json.dumps(record))
