"""Verify the separate design counterexample and its frozen source authority."""
from __future__ import annotations
import hashlib
import io
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
Q = ROOT / 'qa/package-durable-admission-independent'
SOURCE = '195e04af27f7a724c6a2037363b7fe68df418a6b'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


manifest = json.loads((Q / 'manifest.json').read_text())
archive = (Q / 'evidence.zip').read_bytes()
assert sha(archive) == manifest['archive_sha256'] == 'ab2e7ecb8e44f6c78c0f8af76c7bdb6bdf1f93a8ca41c23f20f680d86a49c2af'
assert len(archive) == manifest['archive_bytes'] == 185510
assert manifest['source'] == SOURCE
with zipfile.ZipFile(io.BytesIO(archive)) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == 45
    assert set(z.namelist()) == {r['path'] for r in manifest['payloads']}
    for row in manifest['payloads']:
        raw = z.read(row['path'])
        assert raw == (Q / row['path']).read_bytes() and len(raw) == row['bytes'] and sha(raw) == row['sha256']
    sources = json.loads(z.read('source-manifest.json'))
    assert len(sources) == 19
    for row in sources:
        raw = git('show', row['source'] + ':' + row['path'])
        assert raw == z.read(row['snapshot']) and sha(raw) == row['sha256'] and len(raw) == row['bytes']
        assert hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest() == row['git_blob']
    imports = json.loads(z.read('capture-red.imports.json'))
    assert imports['source_commit'] == SOURCE and imports['drift'] == [] and len(imports['modules']) == 31
    for row in imports['modules']:
        raw = git('show', SOURCE + ':' + row['relative_path'])
        assert sha(raw) == row['sha256']
        assert hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest() == row['git_blob'] == row['expected_git_blob']
    review = json.loads(z.read('review.json'))
    assert sha(z.read('test_capture_initialization_boundary.py')) == review['probe_sha256'] == '823117ef4d6886ceebe747020aece47cc07f4758c7c94217cbdec31394a8e2d3'
    cases = list(ET.fromstring(z.read('capture-red.xml')).iter('testcase'))
    counts = dict(tests=len(cases), failures=sum(c.find('failure') is not None for c in cases),
                  errors=sum(c.find('error') is not None for c in cases),
                  skipped=sum(c.find('skipped') is not None for c in cases))
    assert counts == review['independent_probe'] == dict(tests=4, failures=2, errors=0, skipped=0)
    observations = [json.loads(z.read(name)) for name in z.namelist() if name.startswith('capture-red-observations/')]
    assert len(observations) == 4
    for row in observations:
        if row['state'] in ['zero-byte', 'foreign-v0']:
            assert row['opened'] is True and row['observed_version'] == 1 and row['bytes_unchanged'] is False
        else:
            assert row['bytes_unchanged'] is True
record = dict(source=SOURCE, design=manifest['design'], archive_sha256=sha(archive), archive_bytes=len(archive),
    payloads=45, canonical_git_sources=19, exact_imports=31, junit=counts,
    review='Root read the complete independent review and unchanged four-case probe. The two failures challenge a proposed package capture assumption, not the documented ordinary create=False behavior. A new optional actual-connection mode needs new explicit controls; original default behavior and original counterexample remain unchanged.',
    first_slice_bounds='Acyclic strict contract identities; actual-connection capture before initialization/WAL; atomic lazy table/intent/version transaction; captured/current/source CAS inside writer; bounded coherent bodies before resolved-state recovery admission; stable intent-specific provenance guard and exact reuse; no package exposure or native acceptance.')
with (ROOT / 'qa/core-admission-root-review/durable-independent-verification.json').open('x') as f:
    json.dump(record, f, indent=2)
    f.write('\n')
print(json.dumps(record))
