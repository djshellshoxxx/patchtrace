"""Independently verify immutable design and diagnostic packets against Git."""
from __future__ import annotations

import ast
from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = ROOT / 'qa/core-admission-root-review'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest()


def counts(raw):
    cases = list(ET.fromstring(raw).iter('testcase'))
    return dict(tests=len(cases), failures=sum(c.find('failure') is not None for c in cases),
                errors=sum(c.find('error') is not None for c in cases),
                skipped=sum(c.find('skipped') is not None for c in cases))


source = '195e04af27f7a724c6a2037363b7fe68df418a6b'
design = 'efe68b18654459e704d358d64423fbc1820afc0a'
qa = '988ce3f746fe65bc022b4f3a6c1f2234989ec985'
stem = 'docs/qa/package-durable-admission-design-20261118'
outer = json.loads(git('show', qa + ':' + stem + '.manifest.json'))
archive = git('show', qa + ':' + stem + '.zip')
assert len(archive) == outer['archive_bytes'] == 461545
assert sha(archive) == outer['archive_sha256'] == '156c93ba411214921694e865a7615e0f9357b2d43ffbd82348cf65dfb58dec82'
assert outer['source'] == source and outer['design_commit'] == design
with zipfile.ZipFile(io.BytesIO(archive)) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == 93
    assert sha(z.read('manifest.json')) == outer['manifest_sha256']
    manifest = json.loads(z.read('manifest.json'))
    assert set(z.namelist()) == {r['path'] for r in manifest['members']} | {'manifest.json'}
    for row in manifest['members']:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
    provenance = json.loads(z.read('source-provenance.json'))
    assert provenance['source'] == source and provenance['tree'] == git('rev-parse', source + '^{tree}').decode().strip()
    assert len(provenance['git_snapshots']) == 42
    for row in provenance['git_snapshots']:
        data = git('show', source + ':' + row['path'])
        assert data == z.read(row['stored']) and len(data) == row['bytes']
        assert sha(data) == row['sha256'] and blob(data) == row['blob']
    assert len(provenance['equalities']) == 11
    for row in provenance['equalities']:
        data = git('show', source + ':' + row['path'])
        assert data == git('show', row['reference'] + ':' + row['path'])
        assert sha(data) == row['reference_sha256'] == row['current_sha256'] and row['equal'] is True
    spans = json.loads(z.read('source-seams.json'))
    assert len(spans) == 56
    for row in spans:
        raw = git('show', source + ':' + row['path'])
        assert sha(raw) == row['source_sha256']
        body = ast.parse(raw).body
        for name in row['symbol'].split('.'):
            found = [n for n in body if isinstance(n, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)) and n.name == name]
            assert len(found) == 1, (row['path'], row['symbol'])
            node = found[0]
            body = node.body
        assert node.lineno == row['start'] and node.end_lineno == row['end']
        selected = b''.join(raw.splitlines(keepends=True)[node.lineno - 1:node.end_lineno])
        assert sha(selected) == row['sha256']
    assert len(provenance['references']) == 16
    for row in provenance['references']:
        data = Path(row['original']).read_bytes()
        assert data == z.read(row['stored']) and len(data) == row['bytes'] and sha(data) == row['sha256']
    search_counts = {}
    for row in provenance['caller_searches']:
        assert row['argv'][:3] == ['rg', '-n', '-e']
        raw = z.read(row['stored'])
        assert sha(raw) == row['sha256']
        found = git('grep', '-n', '-E', '-e', row['argv'][3], source, '--', *row['argv'][4:])
        canonical = [line.removeprefix(source.encode() + b':') for line in found.splitlines()]
        assert Counter(canonical) == Counter(raw.splitlines()), row['name']
        assert Counter(raw.splitlines()) == Counter(z.read('caller-searches/' + row['name'] + '.replay.txt').splitlines())
        search_counts[row['name']] = len(canonical)
    command = json.loads(z.read('workspace-version.command.json'))
    assert command['source'] == source and command['exit_code'] == 0 and command['forbidden_attempts'] == []
    assert len(command['import_checks']) == 32
    for row in command['import_checks']:
        assert row['matches'] is True
        assert sha(git('show', source + ':' + row['path'])) == row['sha256'] == row['expected_sha256']
    observations = counts(z.read('workspace-version.xml'))
    assert observations == dict(tests=7, failures=0, errors=0, skipped=0)
    probe = z.read('test_workspace_version_observation.py')
    assert sha(probe) == 'f7a0cdcf8d079068f39a34ccca17adb11c72c2594c88535db7e03310bf078a5c'
    assert probe == (ROOT / 'qa/package-durable-admission-design/test_workspace_version_observation.py').read_bytes()
    for suffix in ['md', 'json']:
        path = 'docs/plans/package-durable-admission-20261118.' + suffix
        assert git('show', design + ':' + path) == z.read('proposal/' + path)
assert not git('diff', '--name-only', source, qa, '--', 'src', 'tests', 'tools', '.github', 'docs/specs', 'docs/schemas', 'pyproject.toml')
durable = dict(source=source, design=design, qa=qa, archive_sha256=sha(archive), archive_bytes=len(archive),
    members=93, canonical_git_snapshots=42, complete_ast_spans=56, reference_equalities=11,
    preserved_prior_files=16, canonical_caller_search_counts=search_counts, imports=32, junit=observations,
    product_tests_schema_workflow_unchanged=True,
    limits='Design only. Already-open legacy writers remain possible. Independently confirmed non-initializing capture prerequisite and explicit implementation approval bounds require a subsequent append; no package facade or native acceptance is established.')

q = ROOT / 'qa/tier-r-fb09-diagnosis'
seal, manifest = json.loads((q / 'seal.json').read_text()), json.loads((q / 'manifest.json').read_text())
archive = (q / 'evidence.zip').read_bytes()
assert len(archive) == seal['bytes'] == 227300
assert sha(archive) == seal['sha256'] == 'feb8c805e92d3d9747968c73175719c6e38dddd3c42e36526d0b6d14912ca283'
assert sha((q / 'manifest.json').read_bytes()) == seal['manifest_sha256'] == '0840ec79fce7e3db3af68cd8b5e7c964a2f88193041b0205ecaa478ad322a07b'
with zipfile.ZipFile(io.BytesIO(archive)) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == 78
    assert set(z.namelist()) == {r['path'] for r in manifest['files']} | {'manifest.json'}
    for row in manifest['files']:
        data = z.read(row['path'])
        assert data == (q / row['path']).read_bytes() and len(data) == row['bytes'] and sha(data) == row['sha256']
    assert len(manifest['git_sources']) == 52
    for row in manifest['git_sources']:
        raw = git('show', row['tree'] + ':' + row['path'])
        assert raw == z.read(row['archived_path']) and sha(raw) == row['sha256'] and blob(raw) == row['git_blob']
    verification = json.loads(z.read('verification.json'))
    for row in verification['originals']:
        raw = z.read(row['path'])
        assert raw == (ROOT / 'qa/hosted-pr316-fb09/artifacts' / Path(row['path']).name).read_bytes()
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    imports = json.loads(z.read('exit1-red-v3.imports.json'))
    assert imports['source_drift'] == imports['network_or_child_attempts'] == [] and imports['native_execution'] is False
    assert imports['pytest_exit'] == 1 and len(imports['imports']) == 38
    for row in imports['imports']:
        assert blob(git('show', imports['tree'] + ':' + row['path'])) == row['git_blob'] == row['expected_blob']
    totals = counts(z.read('exit1-red-v3.xml'))
    assert totals == dict(tests=4, failures=2, errors=0, skipped=0)
    assert sha(z.read('test_exit1_diagnostics.py')) == seal['probe_test_sha256'] == 'ab1629e9f61a3ca6b380f2abc4488cf2327a7891dcac977a1c6c25c3235d806e'
tier = dict(source_tree=manifest['source_tree'], archive_sha256=sha(archive), archive_bytes=len(archive),
    members=78, payloads=77, canonical_git_snapshots=52, original_archives=2,
    exact_project_tool_imports=38, junit=totals, network_or_child_attempts=[], native_execution=False,
    review='Frozen reporting-defect evidence only: two unexpected exit1 responses lose diagnostic status/stderr, with two unchanged positive controls. Original Windows child cause and six Linux no-functions causes remain unproven; source, native corpus and historical outcomes are unchanged.')
with (OUT / 'durable-and-tier-r-packets.json').open('x') as f:
    json.dump(dict(durable_design=durable, tier_r=tier), f, indent=2)
    f.write('\n')
print(json.dumps(dict(durable_design=durable, tier_r=tier)))
