"""Owned, bounded QA replay. It does not modify the repository or its tests.

This is an execution guard for an inspected offline scope, not a product sandbox
qualification. Network syscalls are refused in this process and its descendants;
the parent Python audit hook additionally restricts process launches to the
reviewed fixtures. Compiler subprocesses only build/read authored fixture bytes.
"""
from __future__ import annotations

import argparse
import ast
import ctypes
import errno
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import socket
import stat
import sys
import tempfile
import time


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def install_network_filter():
    """Fail before collection if the process-local inherited filter is unavailable."""
    if sys.platform != "linux":
        raise RuntimeError("this inspected replay requires Linux libseccomp")
    lib = ctypes.CDLL("libseccomp.so.2", use_errno=True)
    lib.seccomp_init.argtypes = [ctypes.c_uint32]
    lib.seccomp_init.restype = ctypes.c_void_p
    lib.seccomp_release.argtypes = [ctypes.c_void_p]
    lib.seccomp_release.restype = None
    lib.seccomp_syscall_resolve_name.argtypes = [ctypes.c_char_p]
    lib.seccomp_syscall_resolve_name.restype = ctypes.c_int
    lib.seccomp_rule_add_array.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int,
                                         ctypes.c_uint, ctypes.c_void_p]
    lib.seccomp_rule_add_array.restype = ctypes.c_int
    lib.seccomp_load.argtypes = [ctypes.c_void_p]
    lib.seccomp_load.restype = ctypes.c_int
    libc = ctypes.CDLL(None, use_errno=True)
    libc.prctl.argtypes = [ctypes.c_int, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong]
    libc.prctl.restype = ctypes.c_int
    before = libc.prctl(21, 0, 0, 0, 0)  # PR_GET_SECCOMP; an outer filter may already exist.
    if libc.prctl(38, 1, 0, 0, 0) != 0:  # PR_SET_NO_NEW_PRIVS
        raise OSError(ctypes.get_errno(), "PR_SET_NO_NEW_PRIVS failed")
    context = lib.seccomp_init(0x7FFF0000)  # SCMP_ACT_ALLOW for unrelated syscalls.
    if not context:
        raise RuntimeError("seccomp_init failed")
    names = ("socket", "connect", "bind", "listen", "accept", "accept4", "sendto", "sendmsg", "sendmmsg",
             "io_uring_setup")
    rules = []
    try:
        for name in names:
            number = lib.seccomp_syscall_resolve_name(name.encode("ascii"))
            if number < 0:
                raise RuntimeError(f"native syscall unavailable to this guard: {name}")
            result = lib.seccomp_rule_add_array(context, 0x00050000 | errno.EPERM, number, 0, None)
            if result != 0:
                raise RuntimeError(f"seccomp rule failed: {name}: {result}")
            rules.append({"name": name, "number": number, "action": "ERRNO(EPERM)"})
        result = lib.seccomp_load(context)
        if result != 0:
            raise RuntimeError(f"seccomp_load failed: {result}")
    finally:
        lib.seccomp_release(context)
    after = libc.prctl(21, 0, 0, 0, 0)
    if after != 2 or libc.prctl(39, 0, 0, 0, 0) != 1:  # PR_GET_NO_NEW_PRIVS
        raise RuntimeError("loaded filter/no-new-privileges state is not confirmed")
    denied = []
    for family in (socket.AF_INET, socket.AF_INET6):
        try:
            handle = socket.socket(family, socket.SOCK_STREAM)
        except OSError as error:
            if error.errno != errno.EPERM:
                raise
            denied.append({"family": int(family), "errno": error.errno, "operation": "socket creation"})
        else:
            handle.close()
            raise RuntimeError("network socket creation unexpectedly succeeded")
    return {"seccomp_load_result": result, "mode_before": before, "mode_after": after,
            "no_new_privileges": True, "rules": rules, "local_denial_probes": denied,
            "attribution_limit": "An outer sandbox already may deny sockets. Successful load proves the additional "
                                 "filter was installed; denial observations are not an independent product boundary test."}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--scope", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--owned-root", required=True, type=Path)
    parser.add_argument("--mode", choices=("preflight", "collect", "run"), required=True)
    args = parser.parse_args()
    scope = json.loads(args.scope.read_bytes())
    root, owned, output = Path(scope["worktree"]).resolve(), args.owned_root.resolve(), args.output.resolve()
    if Path.cwd().resolve() != root or not owned.is_relative_to(Path(tempfile.gettempdir()).resolve()):
        raise RuntimeError("unexpected worktree or system temporary directory")
    if any((parent / ".git").exists() for parent in (owned, *owned.parents)):
        raise RuntimeError("temporary root is under a Git marker")
    if stat.S_IMODE(owned.stat().st_mode) != 0o700 or owned.stat().st_uid != os.geteuid():
        raise RuntimeError("temporary root is not private and owned")
    if os.environ.get("RQ_ALLOWED_DIRS") is not None:
        raise RuntimeError("RQ_ALLOWED_DIRS must be absent; the replay cannot expand product permission")
    if os.environ.get("GIT_ALLOW_PROTOCOL") != "file":
        raise RuntimeError("the local Git protocol restriction is missing")
    for row in scope["source_files"]:
        if digest(root / row["path"]) != row["sha256"]:
            raise RuntimeError(f"inspected source changed: {row['path']}")
    fds = []
    for item in Path("/proc/self/fd").iterdir():
        try:
            info = item.stat()
            target = os.readlink(item)
        except FileNotFoundError:
            continue
        if stat.S_ISSOCK(info.st_mode):
            raise RuntimeError("an inherited socket descriptor would escape the inspected preconditions")
        fds.append({"fd": int(item.name), "target": target, "mode": stat.S_IFMT(info.st_mode)})
    commands = {name: Path(shutil.which(name)).resolve() for name in ("gcc", "nm", "uname")}
    commands["python"] = Path(sys.executable).resolve()
    identities = {name: {"path": str(path), "sha256": digest(path)} for name, path in commands.items()}
    fixture_ast = ast.parse((root / "tools/research_qualification/fixture_pairs.py").read_text())
    authored_source = next(ast.literal_eval(node.value) for node in fixture_ast.body
                           if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "SOURCE"
                                                                   for t in node.targets)).encode()
    snippets = {
        "print('Sorting functions'); print('12 entries')", "import sys; sys.exit(3)",
        "import subprocess,sys,time\nc=subprocess.Popen([sys.executable,'-c','import time\\nwhile True: time.sleep(1)'])\n"
        "print('child', c.pid, flush=True)\ntime.sleep(60)\n",
        "import time; time.sleep(60)", "import os; print('SEEN' if 'RQ_SECRET_TOKEN' in os.environ else 'CLEAN')",
        "import os; print(os.environ.get('RQ_X'))", "print('x'*1000)\nfor _ in range(2000): print('y'*100)",
        "b=bytearray(30_000_000)\nimport time; t=time.time()\nwhile time.time()-t<0.6: pass", "print('same')",
        "print('selftest'); print('Sorting functions')", "print(1)", "raise SystemExit(4)",
    }
    events, denied = [], []
    active_node = None
    network_events = {"socket.__new__", "socket.connect", "socket.bind", "socket.sendto", "socket.sendmsg",
                      "socket.getaddrinfo", "socket.gethostbyname", "socket.gethostbyaddr"}
    forbidden_events = {"os.system", "os.exec", "os.posix_spawn", "os.spawn"}
    system_tmp = Path(tempfile.gettempdir()).resolve()

    def under_tmp(value):
        return Path(value).resolve().is_relative_to(system_tmp)

    def allowed(executable, argv, cwd, environ):
        if not isinstance(argv, (list, tuple)) or not argv:
            return False, "not an argv sequence"
        argv = [os.fsdecode(value) for value in argv]
        if argv[0] in ("no-such-binary-xyz", "definitely-not-a-real-binary-xyz"):
            return len(argv) == 1 and shutil.which(argv[0]) is None, "authored missing-executable control"
        exe = Path(os.fsdecode(executable))
        if not exe.is_absolute():
            located = shutil.which(str(exe), path=(environ or os.environ).get("PATH"))
            if not located:
                return False, "unrecognized executable"
            exe = Path(located)
        exe = exe.resolve()
        if exe not in commands.values() or digest(exe) != next(row["sha256"] for row in identities.values()
                                                            if row["path"] == str(exe)):
            return False, "executable is not an inspected trusted tool"
        if exe == commands["python"]:
            tail = argv[1:]
            if tail[:1] == ["-P"]:
                tail = tail[1:]
            if len(tail) == 2 and tail[0] == "-c":
                return tail[1] in snippets, "exact authored Python snippet"
            if tail[:2] == ["-m", "tools.research_qualification"]:
                return (len(tail) >= 3 and tail[2] in {"selftest", "receipt", "perf", "stages", "parity"}
                        and Path(cwd or os.getcwd()).resolve() == root), "inspected offline research CLI"
            if tail[:5] == ["-m", "patchtrace", "kb", "index", "plan"]:
                return (environ or os.environ).get("PYTHONPATH") == str(root / "src"), "offline KB plan preview"
            if tail[:3] == ["-m", "patchtrace.rules.worker", "--request"] and len(tail) == 4:
                return (under_tmp(tail[3]) and Path(tail[3]).name == "req.json"
                        and (environ or os.environ).get("PYTHONPATH") == str(root / "src")), "synthetic rule worker"
            return False, "uninspected Python invocation"
        if exe == commands["gcc"]:
            if argv[1:] in (["-dumpmachine"], ["--version"]):
                return True, "trusted compiler identity"
            if not cwd or not under_tmp(cwd):
                return False, "compile cwd is outside system temporary directory"
            tail = argv[1:]
            if not tail or tail[0] not in ("-O0", "-O2"):
                return False, "uninspected compiler options"
            tail = tail[1:]
            if tail[:1] == ["-DFIXED"]:
                tail = tail[1:]
            fixed = ["-g0", "-fPIC", "-shared", "-nostdlib", "-fvisibility=hidden", "-fno-asynchronous-unwind-tables",
                     "-fno-ident", "-Wl,--build-id=none", "-o"]
            return (len(tail) == len(fixed) + 2 and tail[:len(fixed)] == fixed and tail[-1] == "mini.c"
                    and under_tmp(tail[-2]) and Path(tail[-2]).parent.resolve() == Path(cwd).resolve()
                    and (Path(cwd) / "mini.c").read_bytes() == authored_source), "exact authored C compilation"
        if exe == commands["nm"]:
            return (len(argv) == 5 and argv[1:4] == ["-S", "--defined-only", "-n"] and under_tmp(argv[4])
                    and Path(argv[4]).suffix == ".so"), "read authored ELF symbols; never execute output"
        return exe == commands["uname"] and argv[1:] == ["-p"], "read-only platform query"

    def audit(event, values):
        if event in network_events or event in forbidden_events:
            entry = {"event": event, "nodeid": active_node, "reason": "outside inspected offline scope"}
            denied.append(entry)
            raise PermissionError(errno.EPERM, f"offline QA guard refused {event}")
        if event == "subprocess.Popen":
            executable, argv, cwd, environ = values
            good, reason = allowed(executable, argv, cwd, environ)
            entry = {"event": event, "nodeid": active_node, "argv": [os.fsdecode(v) for v in argv],
                     "cwd": os.fsdecode(cwd) if cwd is not None else os.getcwd(), "allowed": good, "reason": reason,
                     "pythonpath": (environ or os.environ).get("PYTHONPATH")}
            events.append(entry)
            if not good:
                denied.append(entry)
                raise PermissionError(errno.EPERM, f"offline QA guard refused process: {reason}")

    status = {"source": scope["source"], "tree": scope["tree"], "mode": args.mode,
              "worktree": str(root), "owned_root": str(owned), "basetemp": str(owned / "pytest-tmp"),
              "system_temp": str(system_tmp), "git_markers_under_temporary_root": [],
              "rq_allowed_dirs_initial": None, "tool_identities": identities, "inherited_fds": fds,
              "scope_sha256": digest(args.scope), "guard_sha256": digest(__file__), "started_monotonic": time.monotonic()}
    filter_receipt = install_network_filter()
    status["network_filter"] = filter_receipt
    sys.addaudithook(audit)
    output.mkdir(parents=True, exist_ok=True)
    dump(output / f"{args.mode}-preflight.json", status)
    code = 90
    records, collection = [], []

    class ReceiptPlugin:
        def pytest_collection_finish(self, session):
            collection.extend(item.nodeid for item in session.items)
            if set(item.nodeid.split("::", 1)[0] for item in session.items) != set(scope["modules"]):
                raise RuntimeError("collected module set differs from inspected scope")
            dump(output / f"{args.mode}-collection.json", collection)

        def pytest_runtest_logstart(self, nodeid, location):
            nonlocal active_node
            active_node = nodeid

        def pytest_runtest_logreport(self, report):
            records.append({"nodeid": report.nodeid, "when": report.when, "outcome": report.outcome,
                            "duration": report.duration, "longrepr": str(report.longrepr) if report.longrepr else None})

    try:
        if args.mode == "preflight":
            code = 0
        else:
            import pytest
            pytest_args = ["-q", "-ra", f"--basetemp={owned / 'pytest-tmp'}", f"--junitxml={output / (args.mode + '.xml')}"]
            if args.mode == "collect":
                pytest_args.append("--collect-only")
            pytest_args.extend(scope["modules"])
            status["pytest_argv"] = pytest_args
            signal.alarm(240)
            code = int(pytest.main(pytest_args, plugins=[ReceiptPlugin()]))
            signal.alarm(0)
    finally:
        changed = [row["path"] for row in scope["source_files"] if digest(root / row["path"]) != row["sha256"]]
        imports = []
        foreign = []
        for name, module in sorted(sys.modules.items()):
            file = getattr(module, "__file__", None)
            if file and (name == "patchtrace" or name.startswith("patchtrace.") or name.startswith("tools.research_qualification")):
                path = Path(file).resolve()
                row = {"name": name, "path": str(path), "sha256": digest(path)}
                imports.append(row)
                if not path.is_relative_to(root):
                    foreign.append(row)
        status.update(pytest_exit=code, elapsed_seconds=time.monotonic() - status["started_monotonic"],
                      process_audit_events=events, denied_audit_events=denied, results=records,
                      collected=len(collection), loaded_source=imports, foreign_source_imports=foreign,
                      changed_inspected_source=changed)
        if denied or changed or foreign:
            code = 91
        status["guarded_exit"] = code
        dump(output / f"{args.mode}-receipt.json", status)
    return code


if __name__ == "__main__":
    raise SystemExit(main())
