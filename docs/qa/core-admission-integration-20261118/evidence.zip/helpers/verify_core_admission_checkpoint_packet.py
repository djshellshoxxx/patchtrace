"""Independently verify the frozen first core-admission implementation packet."""
from __future__ import annotations

import ast
import hashlib
import io
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = ROOT / 'qa/core-admission-root-review'
BASE = '7b5f558fb1a51d45427648c39c15995ab3697e2c'
DESIGN = '1102f1baba94a8ce3dd5bc12df52e69a2595e995'
SPEC = 'cb26b38de018612e76f87c544fb8b1dfe70acbf2'
SOURCE = '441c47c2262603555aa77c11e63fedcce11ba502'
QA = 'fa4bebbb7a5a7095d4764066ffb73cd73cf85499'
STEM = 'docs/qa/core-admission-checkpoints-20261118'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()


OUT.mkdir(exist_ok=False)
manifest = json.loads(git('show', QA + ':' + STEM + '.manifest.json'))
archive = git('show', QA + ':' + STEM + '.zip')
assert sha(archive) == manifest['archive_sha256'] == '89970d49ed048ee63c22c88601831c0a39aca96f0147edcfd7398944cfcc43d6'
assert len(archive) == manifest['archive_bytes'] == 1195401
assert manifest['source_commit'] == SOURCE
with zipfile.ZipFile(io.BytesIO(archive)) as z:
    names = z.namelist()
    assert len(names) == len(set(names)) == manifest['payload_count'] == 136
    assert z.testzip() is None
    assert set(names) == {row['path'] for row in manifest['payloads']}
    assert sum(row['bytes'] for row in manifest['payloads']) == manifest['uncompressed_bytes'] == 2898984
    for row in manifest['payloads']:
        raw = z.read(row['path'])
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['path']
    snapshots = json.loads(z.read('receipts/canonical-source.json'))
    assert len(snapshots) == 54
    for row in snapshots:
        raw = git('show', row['commit'] + ':' + row['path'])
        assert raw == z.read(row['member']) and len(raw) == row['bytes']
        assert sha(raw) == row['sha256'] and blob(raw) == row['git_blob'], row['path']
    chain = json.loads(z.read('receipts/chain.json'))
    assert [row['commit'] for row in chain] == [BASE, DESIGN, SPEC, SOURCE]
    for row in chain:
        assert git('rev-parse', row['commit'] + '^{tree}').decode().strip() == row['tree']
        assert git('show', '-s', '--format=%P', row['commit']).decode().split() == row['parents']
        assert git('show', '-s', '--format=%s', row['commit']).decode().strip() == row['subject']
        assert '[no release]' in row['subject']
    verification = json.loads(z.read('receipts/verification.json'))
    expected_counts = {
        'open-red': (5, 4, 0, 0), 'spec-red': (47, 41, 0, 0),
        'first-green': (47, 0, 0, 0), 'affected': (512, 2, 0, 0),
        'affected-v2': (512, 0, 0, 0),
    }
    counts = {}
    for label, expected in expected_counts.items():
        raw = z.read(f'receipts/{label}.xml')
        cases = list(ET.fromstring(raw).iter('testcase'))
        actual = (len(cases), *(sum(c.find(tag) is not None for c in cases)
                               for tag in ('failure', 'error', 'skipped')))
        assert actual == expected, (label, actual)
        authored = next(row for row in verification['xml'] if row['label'] == label)
        assert sha(raw) == authored['sha256']
        counts[label] = dict(zip(('tests', 'failures', 'errors', 'skipped'), actual))
        counts[label]['passed'] = actual[0] - sum(actual[1:])
    import_counts = {}
    for label, source in [('open-red', DESIGN), ('spec-red', SPEC),
                          ('affected', SOURCE), ('affected-v2', SOURCE)]:
        record = json.loads(z.read(f'receipts/{label}.imports.json'))
        assert record['source_commit'] == source and record['drift'] == []
        for row in record['modules']:
            raw = git('show', source + ':' + row['relative_path'])
            assert sha(raw) == row['sha256']
            assert blob(raw) == row['git_blob'] == row['expected_git_blob']
        import_counts[label] = len(record['modules'])
    assert import_counts['affected-v2'] == 462
    command = json.loads(z.read('receipts/affected-v2.command.json'))
    assert command['source_commit'] == SOURCE and len(command['test_files']) == 28
    repository_test_count = 0
    for row in command['test_files']:
        path = Path(row['path'])
        if path.is_relative_to(command['cwd']):
            relative = path.relative_to(command['cwd']).as_posix()
            raw = git('show', SOURCE + ':' + relative)
            repository_test_count += 1
        else:
            raw = path.read_bytes()
        assert sha(raw) == row['sha256'], str(path)
    assert repository_test_count == 26
    original_probes = []
    for row in verification['original_probes']:
        raw = Path(row['path']).read_bytes()
        assert sha(raw) == row['sha256']
        member = ('receipts/original-peer/test_core_reader_boundary.py'
                  if Path(row['path']).name == 'test_core_reader_boundary.py'
                  else 'receipts/test_open_failure_boundary.py')
        assert raw == z.read(member)
        original_probes.append(row)
    for path in verification['test_bytes_unchanged_since_red']:
        assert git('show', SPEC + ':' + path) == git('show', SOURCE + ':' + path)
    for path in ['src/patchtrace/service.py', 'src/patchtrace/persistence.py']:
        before = z.read('receipts/first-green-' + Path(path).name)
        after = git('show', SOURCE + ':' + path)
        assert ast.dump(ast.parse(before)) == ast.dump(ast.parse(after))
    correction = json.loads(z.read('receipts/runner-correction.json'))
    for role in ('original', 'corrected'):
        assert sha(z.read('receipts/' + correction[role + '_runner'])) == correction[role + '_sha256']
    final_exit = json.loads(z.read('receipts/affected-v2.exit.json'))
    assert final_exit['source_commit'] == SOURCE
    assert final_exit['pytest_exit'] == final_exit['exit_code'] == 0
    assert final_exit['drift'] == final_exit['prohibited_attempts'] == []
    assert final_exit['temporary_storage']['removed'] is True
    assert len(final_exit['children']) == 5
    for child in final_exit['children']:
        assert child['argv'][0] == command['argv'][0]
        assert child['PYTHONPATH'] == command['cwd'] + '/src'
    assert z.read('receipts/exact-normal-ruff.log').strip() == b'All checks passed!'

assert git('diff', '--name-only', BASE, SOURCE, '--', 'src').decode().splitlines() == [
    'src/patchtrace/persistence.py', 'src/patchtrace/service.py']
assert git('diff', '--name-only', BASE, SOURCE, '--', 'tests').decode().splitlines() == [
    'tests/test_project_creation_identity.py', 'tests/test_project_open_checkpoint.py']
assert not git('diff', '--name-only', BASE, SOURCE, '--', 'tools', '.github', 'docs/schemas', 'pyproject.toml')
assert not git('diff', '--name-only', SOURCE, QA, '--', 'src', 'tests', 'tools', '.github', 'docs/specs', 'docs/schemas', 'pyproject.toml')
record = {
    'base': BASE, 'spec_tests': SPEC, 'source': SOURCE, 'qa': QA,
    'archive_sha256': sha(archive), 'archive_bytes': len(archive),
    'payloads': 136, 'canonical_git_snapshots': 54, 'junit': counts,
    'canonical_import_counts': import_counts,
    'gate_selection': {'files': 28, 'repository_tests': 26, 'original_external_probes': 2},
    'unchanged_external_probes': original_probes,
    'source_scope_verified': True, 'spec_tests_unchanged_since_red': True,
    'qa_product_test_tool_workflow_config_bytes_unchanged': True,
    'five_source_pinned_reviewed_children': True,
    'review': 'Root read both source changes, the specifications, both new regression files, the unchanged original five-case failure probe, affected runner and all 136 payload receipts. Original failure and policy-refusal results are preserved. This verifies the frozen author packet; a new combined root execution follows after the separately reproduced constructor correction.',
    'limits': 'The first implementation closes failures after ProjectStore returns only. The independently reproduced constructor interruption/secondary-cleanup defects are not fixed or covered by this 512-case green result. Parent audit does not establish child-wide syscall interception. Native, Windows and complete package qualification remain separate.',
}
with (OUT / 'first-packet-verification.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
