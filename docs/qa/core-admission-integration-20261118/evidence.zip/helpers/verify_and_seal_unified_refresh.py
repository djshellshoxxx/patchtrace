"""Seal read-only completed Windows unified evidence and a separate pending-gate snapshot."""
from __future__ import annotations

from collections import Counter
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
Q = ROOT / 'qa/hosted-pr316-771e-gates-refresh'
TREE = 'ddf151c6ff8fb3f70b74378525fe1d8d5c9050e3'
OLD_TREE = 'db005f5ede44b60fa2cf92581ac7dd685b087d99'
HEAD = '771e5a775f5bf60a8d9094232b51dcdbb47d6389'
PREVIEW = 'ac6632ad6de486ba16343f0eeb4a2b5a446e4ac1'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as f:
        f.write(data)


def save(name, data):
    write(Q / name, (json.dumps(data, indent=2) + '\n').encode())


def decode_tool(result):
    assert not result.get('isError')
    return json.loads(result['structuredContent']['content'])


refresh = json.loads((Q / 'metadata.json').read_text())
checks = decode_tool(refresh['checks'])
assert checks['total_count'] == len(checks['check_runs']) == 45
check_counts = dict(Counter(row['conclusion'] or row['status'] for row in checks['check_runs']))
assert check_counts == dict(skipped=4, success=32, in_progress=6, failure=3)
qa_jobs = decode_tool(refresh['qa_jobs'])['jobs']
assert all(job['head_sha'] == HEAD for job in qa_jobs)
pending = [dict(id=j['id'], name=j['name'], status=j['status']) for j in qa_jobs if j['status'] != 'completed']
assert len(pending) == 6 and decode_tool(refresh['qa_artifacts'])['artifacts'] == []
initial = json.loads((Q / 'windows-failure-metadata-initial.json').read_text())
run = decode_tool(initial['run'])
assert run['id'] == 44409973392 and run['head_sha'] == HEAD and run['path'] == '.github/workflows/live-unified.yml'
jobs = decode_tool(json.loads((Q / 'windows-unified-jobs.json').read_text()))['jobs']
job = next(j for j in jobs if j['id'] == 135175184056)
assert job['head_sha'] == HEAD and job['conclusion'] == 'failure'
step_status = {s['name']: s['conclusion'] for s in job['steps']}
assert step_status['Live extraction, CI fixture pair'] == 'success'
assert step_status['Live extraction, probe pair'] == 'failure'
assert next(j for j in jobs if j['name'] == 'linux')['conclusion'] == 'skipped'
artifact = json.loads((Q / 'artifacts/artifact-14477506098.verified.json').read_text())
api = artifact['api_metadata']
assert api['workflow_run']['head_sha'] == HEAD and api['workflow_run']['id'] == run['id']
raw = (Q / artifact['archive']).read_bytes()
assert len(raw) == api['size_in_bytes'] == 215897
assert sha(raw) == api['digest'].removeprefix('sha256:') == 'f785fd27d473c0410c4bbd57459cedf94fbee7e8f45e9b6f4319c801c81e3e9d'
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == 6
    assert set(z.namelist()) == {r['path'] for r in artifact['members']}
    for row in artifact['members']:
        body = z.read(row['path'])
        assert sha(body) == row['sha256'] and len(body) == row['bytes'] and z.getinfo(row['path']).CRC == row['crc32']
        if row['retained_as_text']:
            assert body == (Q / 'text/14477506098' / row['path']).read_bytes()
        else:
            assert row['path'].endswith('.dll')
            assert not (Q / 'text/14477506098' / row['path']).exists()
delivery = json.loads((Q / 'log-windows-unified.delivery.json').read_text())['structuredContent']['content']
assert delivery.encode() == (Q / 'log-windows-unified.log').read_bytes()
assert PREVIEW in delivery
failure = 'FAIL L1 newer: two analyze runs give the same content_digest'
first_digest = 'a658ef9f00c21c74bac115a68414f8188206258c051a9c3ea9c484e0d0e65c0c'
second_digest = 'b7dc355b73b3482f82fff8c81ba8d32e51e285a357dc39ba96ba0f6bcf3bf936'
assert delivery.count(failure) == 1 and first_digest + ' vs ' + second_digest in delivery
assert 'FAIL L1 older:' not in delivery
sources = []
for path in ['.github/workflows/live-unified.yml', 'tools/live_unified_check.py',
             'src/patchtrace/unified/extract/__init__.py', 'src/patchtrace/unified/extract/ghidra_script.py',
             'src/patchtrace/unified/extract/runner.py', 'src/patchtrace/unified/ir/ingest.py']:
    data = git('show', TREE + ':' + path)
    archived = 'source/' + path
    write(Q / archived, data)
    sources.append(dict(path=path, tree=TREE, archived_path=archived, bytes=len(data), sha256=sha(data),
                        git_blob=hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest(),
                        equal_to_fb09=data == git('show', OLD_TREE + ':' + path)))
assert all(r['equal_to_fb09'] for r in sources)
save('source-snapshots.json', sources)
old = ROOT / 'qa/hosted-pr316-fb09'
old_members = json.loads((old / 'artifacts/artifact-14473773258.verified.json').read_text())['members']
fixture_equalities = []
for row in artifact['members']:
    if not row['path'].endswith('.dll'):
        continue
    previous = next(r for r in old_members if r['path'] == row['path'])
    assert previous['sha256'] == row['sha256'] and previous['bytes'] == row['bytes']
    fixture_equalities.append(dict(path=row['path'], bytes=row['bytes'], sha256=row['sha256'], equal_to_fb09=True))
summaries = []
script_hash = next(r['sha256'] for r in sources if r['path'].endswith('/ghidra_script.py'))
for pair in ['ci', 'probe']:
    name = 'live-unified-' + pair + '-pair-windows.json'
    current = json.loads((Q / 'text/14477506098/live-out' / name).read_text())
    previous = json.loads((old / 'text/14473773258/live-out' / name).read_text())
    assert current['script_sha256'] == previous['script_sha256'] == script_hash
    for side in ['older', 'newer']:
        record = current['sides'][side]
        before = previous['sides'][side]
        assert record['artifact_sha256'] == before['artifact_sha256']
        assert record['content_digest'] == before['content_digest']
        assert record['probe'] == before['probe']
        assert current['ghidriff'][side]['equals_own_analysis'] is True
        if pair == 'probe' and side == 'newer':
            assert record['content_digest'] == first_digest and record['counts']['functions'] == 383
        summaries.append(dict(pair=pair, side=side, artifact_sha256=record['artifact_sha256'],
                              content_digest=record['content_digest'], equal_first_digest_to_fb09=True,
                              functions=record['counts']['functions'], probe=record['probe']))
findings = dict(head=HEAD, preview=PREVIEW, tree=TREE, snapshot_clock=refresh['clock'], check_counts=check_counts,
    full_qa_qt_pending=pending, full_qa_artifacts_at_snapshot=[], unified_run=run['id'], unified_job=job['id'],
    unified_job_conclusion='failure', linux_unified_job='skipped', artifact_id=api['id'],
    artifact_sha256=sha(raw), artifact_bytes=len(raw), original_members=6, materialized_json_members=2,
    fixture_images_extracted_or_executed=False, canonical_sources=sources, fixture_equalities=fixture_equalities,
    first_analysis_summaries=summaries, failing_case='L1 newer probe pair deterministic content_digest',
    first_digest=first_digest, second_digest=second_digest, first_and_second_ir_key_equal=True,
    second_run_function_rows_retained=False, exact_decoded_log_sha256=sha(delivery.encode()),
    diagnosis='The actual second analyze digest differs. Existing JSON reports only first-run details; work cleanup discards the second-run/function records, so the specific divergent record and native cause cannot be recovered from this artifact.',
    limits='Same four fixture hashes, extractor script and six traced source files as fb09; this does not establish identical transient engine state. GZF/hashers positives do not override L1 failure. No native rerun, release qualification or corpus outcome change.',
    retrieval_setup='Direct generic GET for the job detail was unsupported (400), then the supported run-jobs collection and dedicated job-log tool succeeded. Initial tool error and original deliveries remain preserved.')
save('findings.json', findings)
readme = f'''# PR316 771e: completed unified Windows failure and pending QA snapshot

At **{refresh['clock']['current_time']}**, the exact head `{HEAD}` had 32 successful,
3 failed, 4 skipped and 6 still-running check records. The full QA workflow's six
Linux/Windows QA/Qt jobs were still running; its artifact collection was empty.
One Qt shard was complete. The release gate was skipped. No pending/skipped job
is credited as passing, and this packet performs no dispatch or retry.

The completed new non-static failure is the Windows unified workflow
`44409973392`, job `135175184056`. Its CI fixture extraction step passes; the
probe-pair step fails. The downstream Linux job is skipped. The actual probe
newer side reports two different analyze digests:

- first: `{first_digest}`
- second: `{second_digest}`

The repeated ir_key agrees. GZF extraction and the Ghidriff-retained program
agree with the first run. Their positive checks do not satisfy the failed L1
determinism assertion. The first run has 383 functions. The full decoded log
preserves the exact connector text and both digests.

Original artifact `14477506098` has six members, 215,897 bytes, SHA-256
`{sha(raw)}`. API metadata, every member hash/CRC and the two exact JSON
materializations are verified. The four authored fixture DLLs stay inert inside
the original ZIP; none was extracted or executed. All four input hashes and the
four first-run digests equal the earlier fb09 artifact. Six traced workflow,
checker and extractor/ingest files also match fb09 byte for byte. Engine scratch
state is not shown to be equal by those comparisons.

The uploaded JSON records only the first analyze run. The actual checker retains
both analyses temporarily, compares them, then removes the work directory in its
finally block. The second manifest/function records are absent from this artifact.
The original divergent field and its native cause therefore remain unknown.
The next assigned work is a bounded diagnostic-retention proposal with meaningful
portable tests; no digest/normalization, native engine or acceptance changes are
authorized by this evidence.

This refresh is separate from the immutable earlier 771e Windows dependency/native
packet. That packet's initial status snapshot remains unchanged. The first direct
job-detail retrieval was unsupported by the generic connector; the original
error is retained, and the supported run-jobs/log routes supplied the completed
job evidence. No setup failure is presented as a product test.

`findings.json`, `source-snapshots.json`, the original delivery objects and ZIP,
and the exact decoded log provide the reviewable data. No signed transfer URL is
retained. This result keeps unified/native qualification blocked.
'''
write(Q / 'README.md', readme.encode())
write(Q / 'seal_helper.py', Path(__file__).read_bytes())
files = []
for path in sorted(Q.rglob('*')):
    if path.is_file() and '__pycache__' not in path.parts:
        data = path.read_bytes()
        if path.suffix != '.zip':
            for url in re.findall(rb'https?://[^\s"<>]+', data):
                assert not any(t in url for t in (b'X-Amz-Signature=', b'?sig=', b'&sig='))
        files.append(dict(path=path.relative_to(Q).as_posix(), bytes=len(data), sha256=sha(data)))
save('manifest.json', dict(source=dict(head=HEAD, preview=PREVIEW, tree=TREE), files=files))
with zipfile.ZipFile(Q / 'evidence.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for row in files:
        z.write(Q / row['path'], row['path'])
    z.write(Q / 'manifest.json', 'manifest.json')
with zipfile.ZipFile(Q / 'evidence.zip') as z:
    assert z.testzip() is None
    for row in files:
        assert sha(z.read(row['path'])) == row['sha256']
sealed = (Q / 'evidence.zip').read_bytes()
save('seal.json', dict(archive='evidence.zip', sha256=sha(sealed), bytes=len(sealed), members=len(files) + 1,
    payloads=len(files), manifest_sha256=sha((Q / 'manifest.json').read_bytes()),
    canonical_git_sources=len(sources), original_artifacts=1, original_members=6, decoded_logs=1))
print(json.dumps(dict(check_counts=check_counts, full_qa_qt_pending=len(pending), unified_status='failed',
                     archive_sha256=sha(sealed), archive_bytes=len(sealed), payloads=len(files))))
