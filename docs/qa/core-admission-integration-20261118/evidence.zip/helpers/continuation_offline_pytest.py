"""Run explicitly reviewed offline checks with inherited network denial.

This execution safeguard adds no product sandbox or native-acceptance claim.
The selected tests and assertions are not modified or excluded by this helper.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys

WORKSPACE = Path(__file__).resolve().parent.parent
FILTER = WORKSPACE / 'qa/full-batch-path-recheck/offline_replay.py'
EXPECTED_FILTER = '381298968b20c80f76e210ffeb98f33769ec2d14580c56a7934ff9cef7c71744'


def main() -> int:
    assert hashlib.sha256(FILTER.read_bytes()).hexdigest() == EXPECTED_FILTER
    descriptors = []
    for path in Path('/proc/self/fd').iterdir():
        try:
            mode = path.stat().st_mode
        except FileNotFoundError:
            continue
        if stat.S_ISSOCK(mode):
            raise RuntimeError('An inherited socket violates this offline gate precondition')
        descriptors.append(int(path.name))
    assert os.environ.get('GIT_ALLOW_PROTOCOL') == 'file'
    assert os.environ.get('GIT_CONFIG_NOSYSTEM') == '1'
    assert os.environ.get('GIT_CONFIG_GLOBAL') == '/dev/null'
    spec = importlib.util.spec_from_file_location('reviewed_network_filter', FILTER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    receipt = dict(filter_source_sha256=EXPECTED_FILTER, inherited_socket_descriptors=[],
                   observed_descriptor_numbers=descriptors, network_filter=module.install_network_filter(),
                   network_audit_event_counts={}, process_audit_count=0,
                   limitation='Inspected offline scope only; no product or arbitrary broker-mediated sandbox claim')
    output = Path(os.environ['PATCHTRACE_OFFLINE_GUARD_RECEIPT'])
    assert not output.exists()

    def audit(event, _args):
        if event.startswith('socket.'):
            counts = receipt['network_audit_event_counts']
            counts[event] = counts.get(event, 0) + 1
        elif event in {'subprocess.Popen', 'os.system', 'os.exec', 'os.posix_spawn', 'os.spawn'}:
            receipt['process_audit_count'] += 1

    sys.addaudithook(audit)
    try:
        import pytest
        result = pytest.main(sys.argv[1:])
        receipt['pytest_exit'] = int(result)
        return int(result)
    finally:
        output.write_text(json.dumps(receipt, indent=2) + '\n')


if __name__ == '__main__':
    raise SystemExit(main())
