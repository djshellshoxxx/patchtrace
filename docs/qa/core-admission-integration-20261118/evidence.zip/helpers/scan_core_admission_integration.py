"""Retain the unsuppressed exact-source static gate independently of normal lint."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parent.parent
REPO=ROOT/'continuation-integration'
OUT=ROOT/'qa/core-admission-integration'
SOURCE='a8f698f6a1d075b673bc6ec94c991141113d2b30'
BEFORE='7b5f558fb1a51d45427648c39c15995ab3697e2c'


def git(*args):
    return subprocess.check_output(['git','-C',str(REPO),*args])


def selected_sites(rows,ref):
    sites=Counter()
    for row in rows:
        path=Path(row['filename']).relative_to(REPO).as_posix()
        lines=git('show',ref+':'+path).decode().splitlines(keepends=True)
        start,end=row['location'],row['end_location']
        selected=lines[start['row']-1:end['row']]
        if len(selected)==1:
            text=selected[0][start['column']-1:end['column']-1]
        else:
            selected[0]=selected[0][start['column']-1:]
            selected[-1]=selected[-1][:end['column']-1]
            text=''.join(selected)
        sites[path,row['code'],text]+=1
    return sites


assert git('rev-parse','HEAD').decode().strip()==SOURCE and not git('status','--porcelain')
normal=json.loads((OUT/'normal-ruff.json').read_text())
assert normal['source']==SOURCE and normal['exit']==0
argv=[sys.executable,'-m','ruff','check','--isolated','--select','S','--ignore-noqa','--no-cache',
      '--no-respect-gitignore','--output-format','json','src']
started=datetime.now(timezone.utc).isoformat()
result=subprocess.run(argv,cwd=REPO,capture_output=True,timeout=120)
for name,data in [('stdout',result.stdout),('stderr',result.stderr)]:
    with (OUT/('ruff-strict.'+name)).open('xb') as f:f.write(data)
current=json.loads(result.stdout)
prior=json.loads((ROOT/'qa/kb-native-followup-integration-v2/ruff-strict.stdout').read_text())
left,right=selected_sites(prior,BEFORE),selected_sites(current,SOURCE)
receipt=dict(source=SOURCE,before=BEFORE,argv=argv,cwd=str(REPO),started_utc=started,exit=result.returncode,
    findings=len(current),by_rule=dict(Counter(r['code'] for r in current)),
    stdout_sha256=hashlib.sha256(result.stdout).hexdigest(),stderr_sha256=hashlib.sha256(result.stderr).hexdigest(),
    same_path_code_selected_statement_multiset=left==right,
    added=[dict(path=p,code=c,statement=s,count=n) for (p,c,s),n in (right-left).items()],
    removed=[dict(path=p,code=c,statement=s,count=n) for (p,c,s),n in (left-right).items()],
    strict_scan_still_fails=result.returncode!=0)
with (OUT/'strict-sites-comparison.json').open('x') as f:
    json.dump(receipt,f,indent=2);f.write('\n')
assert git('rev-parse','HEAD').decode().strip()==SOURCE and not git('status','--porcelain')
print(json.dumps(dict(strict_exit=result.returncode,findings=len(current),same_sites=left==right)))
