"""Run the reviewed exact-candidate core/KB/UTF-8/portable-C union offline."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = ROOT / 'qa/core-admission-integration'
SOURCE = 'a8f698f6a1d075b673bc6ec94c991141113d2b30'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(name, value):
    with (OUT / name).open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


assert git('rev-parse', 'HEAD').decode().strip() == SOURCE and not git('status', '--porcelain')
OUT.mkdir(exist_ok=False)
prior = json.loads((ROOT / 'qa/kb-native-followup-integration-v2/command.json').read_text())
core = json.loads((ROOT / 'qa/core-admission-checkpoints/affected-v2.command.json').read_text())
owners = list(prior['reviewed_owner_files'])
core_source = '63ebc42746fbfbded311084288a339f26ed08d8c'
for path in ['src/patchtrace/service.py', 'src/patchtrace/persistence.py',
             'tests/test_project_creation_identity.py', 'tests/test_project_open_checkpoint.py',
             'tests/test_project_store_constructor_cleanup.py', 'docs/specs/core-held-inputs.md',
             'docs/specs/architecture.md']:
    owners.append(dict(path=path, reviewed=core_source,
                       sha256=hashlib.sha256(git('show', core_source + ':' + path)).hexdigest()))
assert len(owners) == 21
for row in owners:
    raw = git('show', row['reviewed'] + ':' + row['path'])
    assert raw == git('show', SOURCE + ':' + row['path']) == (REPO / row['path']).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == row['sha256']
core_root = Path(core['cwd'])
core_nodes = [Path(row['path']).relative_to(core_root).as_posix()
              if Path(row['path']).is_relative_to(core_root) else row['path']
              for row in core['test_files']]
external = {
    ROOT / 'qa/windows-dependency-encoding/test_encoding_boundary.py': '08fc908b2daa0b869f36a8e836f73e2285a90ad48a0bbb7681e5f8d1dcabbea3',
    ROOT / 'qa/kb-held-inputs-independent/test_short_reader_prefix.py': '672e1a2e13e990c1e1249d319f714ef8e91425d44fcafe63dd6fe32a3d9feee6',
    ROOT / 'qa/core-admission-checkpoints/test_open_failure_boundary.py': '715353bb34f604295abb1d04d1e286d144f01568143d5118ed75e4d663432c6c',
    ROOT / 'qa/core-held-inputs-cleanup/original-peer/test_core_reader_boundary.py': 'b7b5ad118cfd8b4b15fd6e1276d3dff0136c21f7b8df555b21db386fda49c1ed',
    ROOT / 'qa/core-initialization-independent/test_constructor_interrupt.py': 'e85126984ac9ddda43950387feee6cc4d7d1e79437595999cc3ee5831fb7428e',
    ROOT / 'qa/core-constructor-cleanup/test_constructor_cleanup_precedence.py': 'a35527922fcc4ba63f43e7023d454132e95c6805b329e6cca018b32811ef55c0',
}
for path, digest in external.items():
    assert sha(path) == digest
nodes = list(dict.fromkeys([*[r['path'] for r in prior['selected_files']], *core_nodes,
                           'tests/test_project_store_constructor_cleanup.py', *map(str, external)]))
assert len(nodes) == 45 and sum(not Path(n).is_absolute() for n in nodes) == 39
protected = {str(path): sha(path) for path in external}
for directory in ['qa/windows-dependency-encoding', 'qa/kb-held-inputs-independent',
                  'qa/core-admission-checkpoints', 'qa/core-initialization-independent']:
    for path in (ROOT / directory).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts:
            protected[str(path)] = sha(path)
owned = Path(tempfile.mkdtemp(prefix='patchtrace-core-admission-integration-'))
assert not any((p / '.git').exists() for p in (owned, *owned.parents))
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', QT_QPA_PLATFORM='offscreen',
           PYTHONPATH=os.pathsep.join(map(str, [REPO / 'src', REPO / 'tests', REPO, ROOT / 'ops'])),
           GIT_ALLOW_PROTOCOL='file', GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null',
           GIT_TERMINAL_PROMPT='0',
           PATCHTRACE_ENCODING_OBSERVATIONS=str(OUT / 'encoding-observations'),
           PATCHTRACE_KB_SHORT_READ_OBSERVATIONS=str(OUT / 'short-read-observations'),
           PATCHTRACE_OPEN_REVIEW_OUTPUT=str(OUT / 'open-observations'),
           PATCHTRACE_CONSTRUCTOR_REVIEW_OUTPUT=str(OUT / 'constructor-observations'),
           PATCHTRACE_CONSTRUCTOR_CLEANUP_OUTPUT=str(OUT / 'constructor-cleanup-observations'),
           PATCHTRACE_BATCH_COLLECTION_RECEIPT=str(OUT / 'collection.json'),
           PATCHTRACE_OFFLINE_GUARD_RECEIPT=str(OUT / 'offline-guard.json'))
argv = [sys.executable, str(ROOT / 'ops/continuation_offline_pytest.py'), '-q', '-ra',
        '-p', 'no:cacheprovider', '-p', 'project_and_tools_receipt', *nodes,
        '--basetemp=' + str(owned / 'pytest'), '--junitxml=' + str(OUT / 'result.xml')]
selected = [dict(path=n, sha256=sha(Path(n) if Path(n).is_absolute() else REPO / n)) for n in nodes]
write('command.json', dict(source=SOURCE, tree=git('rev-parse', 'HEAD^{tree}').decode().strip(),
    argv=argv, cwd=str(REPO), pythonpath=env['PYTHONPATH'], owned_temp=str(owned),
    started_utc=datetime.now(timezone.utc).isoformat(), timeout=180, selected_files=selected,
    reviewed_owner_files=owners, protected_original_files=protected,
    helper_hashes={str(p): sha(p) for p in (Path(__file__), ROOT / 'ops/continuation_offline_pytest.py',
                                         ROOT / 'ops/project_and_tools_receipt.py')},
    boundary='Reviewed offline Python scopes, inspected source-pinned headless CLI/import children and authored portable C formatter only; no downloaded target/native image execution or native Windows acceptance.'))
start = time.monotonic()
with (OUT / 'result.log').open('x') as stream:
    result = subprocess.run(argv, cwd=REPO, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=180)
collection = json.loads((OUT / 'collection.json').read_text())
drift = []
for name, row in collection['final_sources'].items():
    path = Path(row['path'])
    if not path.is_relative_to(REPO) or not (path.is_relative_to(REPO / 'src') or path.is_relative_to(REPO / 'tools')):
        drift.append(dict(module=name, path=str(path), reason='foreign import'))
    else:
        raw = git('show', SOURCE + ':' + path.relative_to(REPO).as_posix())
        if path.read_bytes() != raw or hashlib.sha256(raw).hexdigest() != row['sha256']:
            drift.append(dict(module=name, path=str(path), reason='Git byte mismatch'))
preserved = all(sha(path) == digest for path, digest in protected.items())
test_bytes_unchanged = all(sha(Path(r['path']) if Path(r['path']).is_absolute() else REPO / r['path']) == r['sha256']
                           for r in selected)
after = git('rev-parse', 'HEAD').decode().strip()
status = git('status', '--porcelain').decode()
valid = after == SOURCE and not status and not drift and preserved and test_bytes_unchanged
cases = list(ET.parse(OUT / 'result.xml').getroot().iter('testcase'))
counts = dict(tests=len(cases), failures=sum(c.find('failure') is not None for c in cases),
              errors=sum(c.find('error') is not None for c in cases),
              skipped=sum(c.find('skipped') is not None for c in cases))
removed = False
if result.returncode == 0 and valid:
    shutil.rmtree(owned)
    removed = True
receipt = dict(exit=result.returncode, elapsed=time.monotonic() - start, source_after=after,
    status_after=status, junit=counts, imported_source_count=len(collection['final_sources']), drift=drift,
    original_files_unchanged=preserved, selected_test_files_unchanged=test_bytes_unchanged,
    owned_temp=str(owned), temp_removed=removed)
write('exit.json', receipt)
normal_argv = [sys.executable, '-m', 'ruff', 'check', 'src', 'tests', 'tools']
normal = subprocess.run(normal_argv, cwd=REPO, capture_output=True, timeout=120)
write('normal-ruff.json', dict(source=SOURCE, argv=normal_argv, exit=normal.returncode,
    stdout=normal.stdout.decode(), stderr=normal.stderr.decode()))
assert valid and normal.returncode == 0
print(json.dumps(receipt))
print((OUT / 'result.log').read_text())
raise SystemExit(result.returncode)
