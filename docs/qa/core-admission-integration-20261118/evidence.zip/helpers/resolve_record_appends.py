"""Preserve both reviewed append-only QA/tracker conflict bodies."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

repo = Path(sys.argv[1])
allowed = {'docs/qa.md', 'tasks/todo.md', 'docs/modules.md',
           'docs/plans/patchtrace-completion-matrix.md',
           'docs/plans/autonomous-consolidation-20261118/consolidation-ledger.md'}
records = []
pattern = re.compile(r'^<<<<<<< [^\n]*\n(.*?)^=======\n(.*?)^>>>>>>> [^\n]*\n', re.M | re.S)
committed = sys.argv[2:3] == ['--committed']
names = sys.argv[3:] if committed else sys.argv[2:]
for name in names:
    assert name in allowed, name
    path = repo / name
    before = path.read_text()
    matches = list(pattern.finditer(before))
    assert matches and before.count('<<<<<<< ') == len(matches), name
    parts = []
    for match in matches:
        ours, theirs = match.group(1), match.group(2)
        assert ours.strip() and theirs.strip()
        parts.append({'ours': ours, 'theirs': theirs})
    after = pattern.sub(lambda m: m.group(1).rstrip('\n') + '\n\n' + m.group(2), before)
    assert not re.search(r'^(<<<<<<<|=======|>>>>>>>)', after, re.M)
    for part in parts:
        assert part['ours'].rstrip('\n') in after and part['theirs'] in after
    stages = {}
    for stage in (1, 2, 3):
        if committed:
            ref = subprocess.check_output(['git', '-C', str(repo), 'merge-base', 'HEAD^1', 'HEAD^2'], text=True).strip() if stage == 1 else f'HEAD^{stage - 1}'
            spec = f'{ref}:{name}'
        else:
            spec = f':{stage}:{name}'
        data = subprocess.check_output(['git', '-C', str(repo), 'show', spec])
        stages[str(stage)] = hashlib.sha256(data).hexdigest()
    path.write_text(after)
    records.append({'path': name, 'stages_sha256': stages,
                    'resolved_sha256': hashlib.sha256(after.encode()).hexdigest(),
                    'conflicts': parts})
receipt = repo.parent / 'qa/followup-integration/record-resolutions.jsonl'
receipt.parent.mkdir(parents=True, exist_ok=True)
with receipt.open('a') as stream:
    if committed:
        merge_head = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD^2'], text=True).strip()
    else:
        gitdir = Path(subprocess.check_output(['git', '-C', str(repo), 'rev-parse', '--absolute-git-dir'], text=True).strip())
        ref_file = gitdir / 'MERGE_HEAD'
        if not ref_file.exists():
            ref_file = gitdir / 'CHERRY_PICK_HEAD'
        merge_head = ref_file.read_text().strip()
    stream.write(json.dumps({'head': subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True).strip(),
                             'merge_head': merge_head, 'committed_marker_recovery': committed,
                             'records': records}) + '\n')
print(json.dumps([{'path': row['path'], 'hunks': len(row['conflicts'])} for row in records]))
