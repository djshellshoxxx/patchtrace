"""Independently verify the immutable constructor follow-up and retained reds."""
from __future__ import annotations

import ast
import hashlib
import io
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
OUT = ROOT / 'qa/core-admission-root-review'
BEFORE = 'fa4bebbb7a5a7095d4764066ffb73cd73cf85499'
SPEC = 'f40d14c1970bf45efba4de448c00c8c49b463ae7'
SOURCE = '63ebc42746fbfbded311084288a339f26ed08d8c'
QA = '0201a4c8a1ab715af8136d166bc29eb2985d13c7'
STEM = 'docs/qa/core-constructor-cleanup-20261118'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def blob(raw):
    return hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest()


manifest = json.loads(git('show', QA + ':' + STEM + '.manifest.json'))
archive = git('show', QA + ':' + STEM + '.zip')
assert len(archive) == manifest['archive_bytes'] == 313930
assert sha(archive) == manifest['archive_sha256'] == '11e14a85ac5dbd4f02abd610d274c4cf3e7766b08c3c52223b38e574319d5d6f'
assert manifest['source_commit'] == SOURCE
with zipfile.ZipFile(io.BytesIO(archive)) as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == 140
    assert set(z.namelist()) == {row['path'] for row in manifest['payloads']}
    for row in manifest['payloads']:
        raw = z.read(row['path'])
        assert len(raw) == row['bytes'] and sha(raw) == row['sha256']
    snapshots = json.loads(z.read('receipts/canonical-source.json'))
    assert len(snapshots) == 49
    for row in snapshots:
        raw = git('show', row['commit'] + ':' + row['path'])
        assert raw == z.read(row['member']) and len(raw) == row['bytes']
        assert sha(raw) == row['sha256'] and blob(raw) == row['git_blob']
    counts = {}
    expected = {'original-root/initial': (3, 2, 0, 0), 'secondary-red': (9, 6, 0, 0),
                'spec-red': (50, 31, 0, 0), 'focused-green': (50, 0, 0, 0), 'affected': (562, 0, 0, 0)}
    verification = json.loads(z.read('receipts/verification.json'))
    for label, wanted in expected.items():
        raw = z.read('receipts/' + label + '.xml')
        cases = list(ET.fromstring(raw).iter('testcase'))
        got = (len(cases), *(sum(c.find(tag) is not None for c in cases)
                            for tag in ('failure', 'error', 'skipped')))
        assert got == wanted
        assert sha(raw) == next(r['sha256'] for r in verification['xml'] if r['label'] == label)
        counts[label] = dict(zip(('tests', 'failures', 'errors', 'skipped'), got))
        counts[label]['passed'] = got[0] - sum(got[1:])
    imports = {}
    for label, ref in [('secondary-red', BEFORE), ('spec-red', SPEC),
                       ('focused-green', SOURCE), ('affected', SOURCE)]:
        receipt = json.loads(z.read(f'receipts/{label}.imports.json'))
        assert receipt['source_commit'] == ref and receipt['drift'] == []
        for row in receipt['modules']:
            raw = git('show', ref + ':' + row['relative_path'])
            assert blob(raw) == row['git_blob'] == row['expected_git_blob']
            assert sha(raw) == row['sha256']
        imports[label] = len(receipt['modules'])
    assert imports == {'secondary-red': 14, 'spec-red': 52, 'focused-green': 52, 'affected': 463}
    originals = json.loads(z.read('receipts/original-root-records.json'))
    assert len(originals) == 11
    for row in originals:
        raw = Path(row['path']).read_bytes()
        assert raw == z.read('receipts/' + row['copy']) and sha(raw) == row['sha256'] and len(raw) == row['bytes']
    assert sha(z.read('receipts/test_constructor_cleanup_precedence.py')) == verification['secondary_probe_sha256'] == 'a35527922fcc4ba63f43e7023d454132e95c6805b329e6cca018b32811ef55c0'
    assert z.read('receipts/test_constructor_cleanup_precedence.py') == (ROOT / 'qa/core-constructor-cleanup/test_constructor_cleanup_precedence.py').read_bytes()
    command = json.loads(z.read('receipts/affected.command.json'))
    assert len(command['test_files']) == 31 and command['source_commit'] == SOURCE
    for row in command['test_files']:
        path = Path(row['path'])
        raw = (git('show', SOURCE + ':' + path.relative_to(command['cwd']).as_posix())
               if path.is_relative_to(command['cwd']) else path.read_bytes())
        assert sha(raw) == row['sha256']
    final = json.loads(z.read('receipts/affected.exit.json'))
    assert final['exit_code'] == final['pytest_exit'] == 0
    assert final['drift'] == final['prohibited_attempts'] == []
    assert final['temporary_storage']['removed'] is True and len(final['children']) == 5
    for child in final['children']:
        assert child['argv'][0] == command['argv'][0]
        assert child['PYTHONPATH'] == command['cwd'] + '/src'
    assert z.read('receipts/exact-normal-ruff.log').strip() == b'All checks passed!'

assert git('diff', '--name-only', BEFORE, SOURCE, '--', 'src').decode().splitlines() == ['src/patchtrace/persistence.py']
assert not git('diff', '--name-only', BEFORE, SOURCE, '--', 'tools', '.github', 'docs/schemas', 'pyproject.toml')
assert not git('diff', '--name-only', SOURCE, QA, '--', 'src', 'tests', 'tools', '.github', 'docs/specs', 'docs/schemas', 'pyproject.toml')
test = 'tests/test_project_store_constructor_cleanup.py'
assert git('show', SPEC + ':' + test) == git('show', SOURCE + ':' + test)
old_ast, new_ast = [ast.parse(git('show', ref + ':src/patchtrace/persistence.py')) for ref in (BEFORE, SOURCE)]
for tree in (old_ast, new_ast):
    cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'ProjectStore')
    init = next(n for n in cls.body if isinstance(n, ast.FunctionDef) and n.name == '__init__')
    tries = [n for n in init.body if isinstance(n, ast.Try)]
    assert len(tries) == 1 and len(tries[0].handlers) == 1
    tries[0].handlers = []
assert ast.dump(old_ast) == ast.dump(new_ast)
old_archive = 'docs/qa/core-admission-checkpoints-20261118.zip'
assert git('show', BEFORE + ':' + old_archive) == git('show', QA + ':' + old_archive)
assert sha(git('show', QA + ':' + old_archive)) == verification['previous_archive_sha256'] == '89970d49ed048ee63c22c88601831c0a39aca96f0147edcfd7398944cfcc43d6'
record = dict(source=SOURCE, spec_tests=SPEC, qa=QA, archive_sha256=sha(archive), archive_bytes=len(archive),
    payloads=140, canonical_git_snapshots=49, junit=counts, canonical_import_counts=imports,
    original_root_records_unchanged=11, unchanged_old_packet=True, unchanged_tests_and_probes=True,
    only_existing_constructor_handler_changed=True, generic_close_discard_ownership_schema_unchanged=True,
    root_review='Read complete source/specification, all41 new meaningful controls and unchanged6-case secondary probe. Original3-case root probe passed unchanged inside the independent1200-case exact integration gate. Preserve actual unknown cleanup state and SQLite mapping; this does not claim coverage inside ProjectLock acquisition or native/package qualification.')
with (OUT / 'constructor-packet-verification.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
