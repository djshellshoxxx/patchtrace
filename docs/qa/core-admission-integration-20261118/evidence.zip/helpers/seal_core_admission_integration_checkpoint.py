"""Seal exact-source core integration and immutable source-specific external evidence."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

ROOT = Path(__file__).resolve().parent.parent
REPO = ROOT / 'continuation-integration'
BASE = '361dd495a7e050121f2b3cae4e7678faad7fee35'
SOURCE = 'a8f698f6a1d075b673bc6ec94c991141113d2b30'
DOCS = 'cf5f7301c735c6b6ca1c0d64242804bfb432dfa1'
REMOTE_BASE = '771e5a775f5bf60a8d9094232b51dcdbb47d6389'
MAIN = '9c411ca3d7b47f950be5f0c6f01b3c54184554c6'
Q = ROOT / 'qa/core-admission-integration'
DEST = REPO / 'docs/qa/core-admission-integration-20261118'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


assert git('rev-parse', 'HEAD').decode().strip() == DOCS and not git('status', '--porcelain')
assert not git('diff', '--name-only', SOURCE, DOCS, '--', 'src', 'tests', 'tools', '.github', 'docs/specs', 'docs/schemas', 'pyproject.toml')
tree = git('rev-parse', SOURCE + '^{tree}').decode().strip()
gate = json.loads((Q / 'exit.json').read_text())
assert gate['source_after'] == SOURCE and gate['exit'] == 0 and gate['drift'] == [] and gate['status_after'] == ''
assert gate['junit'] == dict(tests=1200, failures=0, errors=0, skipped=0)
assert gate['imported_source_count'] == 434 and gate['original_files_unchanged'] and gate['selected_test_files_unchanged'] and gate['temp_removed']
command = json.loads((Q / 'command.json').read_text())
assert len(command['selected_files']) == 45 and len(command['reviewed_owner_files']) == 21
for row in command['reviewed_owner_files']:
    assert sha((REPO / row['path']).read_bytes()) == row['sha256']
assert json.loads((Q / 'normal-ruff.json').read_text())['exit'] == 0
strict = json.loads((Q / 'strict-sites-comparison.json').read_text())
assert strict['exit'] == 1 and strict['findings'] == 80 and strict['same_path_code_selected_statement_multiset']
guard = json.loads((Q / 'offline-guard.json').read_text())
assert guard['network_audit_event_counts'] == {'socket.gethostname': 810} and guard['process_audit_count'] == 121
fresh = json.loads((ROOT / 'qa/core-admission-root-review/pre-checkpoint-state.json').read_text())
state = {r['key']: json.loads(r['response']['structuredContent']['content']) for r in fresh['reads']}
assert state['main']['object']['sha'] == MAIN and state['pr316']['head']['sha'] == REMOTE_BASE
assert all(state[key]['state'] == 'open' and not state[key]['merged'] for key in ['pr304', 'pr307', 'pr316'])
assert state['pr307']['base']['sha'] == state['pr304']['head']['sha']
published = json.loads((ROOT / 'qa/kb-native-followup-publication/final-readback.json').read_text())
assert published['head'] == REMOTE_BASE and published['main'] == MAIN
assert published['verified_remote_commits'] == 18 and published['body_exact'] and published['pr_open'] and not published['merged']
commits = git('rev-list', '--reverse', BASE + '..' + DOCS).decode().splitlines()
assert len(commits) == 8 and all('[no release]' in git('show', '-s', '--format=%B', c).decode() for c in commits)
note = (Q / 'checkpoint-note.md').read_text()
payloads = {'checkpoint-note.md': note.encode()}


def add_dir(label, path):
    for p in sorted(path.rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc':
            payloads[label + '/' + p.relative_to(path).as_posix()] = p.read_bytes()


for label, path in [('combined', Q), ('root-review', ROOT / 'qa/core-admission-root-review'),
                    ('original-root-constructor', ROOT / 'qa/core-initialization-independent'),
                    ('prior-publication', ROOT / 'qa/kb-native-followup-publication'),
                    ('cleanup', ROOT / 'qa/kb-native-space-review')]:
    add_dir(label, path)
for label, directory, files in [
        ('hosted-771e', 'qa/hosted-pr316-771e', ['README.md', 'seal.json', 'evidence.zip']),
        ('unified-refresh', 'qa/hosted-pr316-771e-gates-refresh', ['README.md', 'seal.json', 'evidence.zip']),
        ('tier-r-fb09-diagnosis', 'qa/tier-r-fb09-diagnosis', ['README.md', 'seal.json', 'evidence.zip']),
        ('durable-independent-review', 'qa/package-durable-admission-independent', ['review.md', 'review.json', 'manifest.json', 'evidence.zip'])]:
    for name in files:
        payloads[label + '/' + name] = (ROOT / directory / name).read_bytes()
for name in ['verify_core_admission_checkpoint_packet.py', 'verify_constructor_cleanup_packet.py',
             'verify_771e_hosted_packet.py', 'verify_durable_and_tier_r_design_packets.py',
             'verify_durable_and_tier_r_design_packets_v2.py', 'verify_durable_independent_review.py',
             'run_constructor_interrupt_probe.py', 'run_core_admission_integration_gate.py',
             'scan_core_admission_integration.py', 'verify_and_seal_unified_refresh.py',
             'continuation_offline_pytest.py', 'project_and_tools_receipt.py',
             'cleanup_completed_followup_worktrees.py', 'resolve_record_appends.py',
             'publish_kb_native_followup_objects.mjs', 'kb-native-followup-publication.json',
             'seal_core_admission_integration_checkpoint.py']:
    payloads['helpers/' + name] = (ROOT / 'ops' / name).read_bytes()
payloads['helpers/offline_replay.py'] = (ROOT / 'qa/full-batch-path-recheck/offline_replay.py').read_bytes()
for path in git('diff', '--name-only', BASE, SOURCE, '--', 'src', 'tests', 'tools', '.github', 'docs/specs', 'docs/schemas').decode().splitlines():
    payloads['candidate-source/' + path] = git('show', SOURCE + ':' + path)
payloads['integration/history.txt'] = git('log', '--reverse', '--format=fuller', BASE + '..' + DOCS)
payloads['integration/patch.diff'] = git('diff', BASE, SOURCE, '--', 'src', 'tests', 'tools', '.github', 'docs/specs', 'docs/schemas')
records = [json.loads(line) for line in (ROOT / 'qa/followup-integration/record-resolutions.jsonl').read_text().splitlines()]
payloads['integration/append-conflicts.json'] = (json.dumps([r for r in records if r['head'] in {BASE, *commits}], indent=2) + '\n').encode()
DEST.mkdir(exist_ok=False)
with zipfile.ZipFile(DEST / 'evidence.zip', 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path, data in sorted(payloads.items()):
        z.writestr(path, data)
with zipfile.ZipFile(DEST / 'evidence.zip') as z:
    assert z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == len(payloads)
    for path, data in payloads.items():
        assert z.read(path) == data
archive = (DEST / 'evidence.zip').read_bytes()
manifest = dict(source=SOURCE, tree=tree, documentation_parent=DOCS, remote_base=REMOTE_BASE,
    sealed_utc=datetime.now(timezone.utc).isoformat(), archive='evidence.zip', archive_bytes=len(archive),
    archive_sha256=sha(archive), payloads=[dict(path=p, bytes=len(d), sha256=sha(d)) for p, d in sorted(payloads.items())])
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
(DEST / 'README.md').write_text(note + f'\n## Archive integrity\n\n{len(payloads)} verified payloads; {len(archive):,} bytes. SHA-256 `{sha(archive)}`.\n')
short = f'''\n\n## Core admission and actual Windows evidence — 2026-11-18

Exact source `{SOURCE}` passes **1,200 checks with zero failures, errors or
skips in 17.85 seconds**. The 45-file scope preserves six original external probes,
434 canonical project/tool imports and 21 reviewed owner paths. Core expected ID,
explicit non-recovering checkpointed reads, acquired-open and constructor cleanup
are independently reviewed and integrated. Normal Ruff passes; strict S still
fails on 80 unchanged sites. Original failure evidence and both core author packets
remain immutable. [Complete checkpoint](../qa/core-admission-integration-20261118/README.md).

At published source 771e, both actual Windows dependency profiles now pass exact
inventory/audit/UTF-8 verification (17 runtime, 34 packaging distributions). Native
diagnostics compile and identify restricted NUL-open error 5 before descendant
creation; complete no-network acceptance still fails. Unified Windows has a new
preserved repeated-analysis digest mismatch, with the second-run records absent;
six full QA/Qt jobs remain pending at the separate 22:37 snapshot. Durable package
design is reviewed with an actual-connection non-initializing capture prerequisite.
Main remains `{MAIN}`; PR304/307/316 stay open and unmerged. No tag/release/deployment.
'''
with (REPO / 'docs/plans/patchtrace-completion-matrix.md').open('a') as f:
    f.write(short + '''

| Feature / bounded scope | Current state | Completion | Remaining work | Source | Dependencies | Tests | Security | Owner | Acceptance |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Core durable admission hooks | Implemented and independently integrated | D,R: 50% for this slice | Durable caller, native representative journey and final gates |441c47c2 /63ebc427; PR316 candidate|Existing core model/store and original reader checkpoint|Original open and constructor reds; author512/562; exact root1200|Strict early ID, complete verified reads, primary error and committed/foreign retention|Core + root|Per-call identity/ownership preserved through qualified durable/native journey and G|
| Isolated dependency JSON UTF-8 | Actual Windows inventory/audit verified | D,R,J: 75% for this slice|Final candidate gates, dependency lock closure and explicit unaudited categories|6dea194a; hosted771e|Existing isolated process and strict raw evidence contracts|Original CP1252 reds; root1200 union; actual Windows17/34-distribution audits|No environment fallback, skipped audit row or bound/pin relaxation|CI + root|Exact final-source profile/audit and G; no whole-package completion claim|
| Native failure diagnostics | Compiled and observed in actual Windows error path|D,R,J: 75% for diagnostics only|Trusted stdin transfer, effective-denial/descendant/adapter/lifecycle acceptance and final gates|9ca3c078; hosted771e|Existing C helpers, fixed bounded stderr protocol|Portable formatter controls; actual nine records/NUL error5; native overall failure retained|Timeout is not denial; source/handle/Job ownership remain required|CI + root|Complete native receipts at final source; diagnostics alone do not qualify isolation|
| Unified native repeatability | Implemented; current Windows determinism failure|D,R: 50%|Retain bounded first/second evidence, identify cause, repair only demonstrated defect, rerun native/final gates|771e run44409973392|Ghidra12.0.4/Java21.0.13/pyghidra3.0.2 and exact fixture hashes|CI pair passes; probe newer digest differs; Linux downstream skipped|No canonical-digest weakening or success from first-only metadata|Binary analysis + CI|Repeated exact inputs produce defensible stable identity under original assertions|
| Durable package intent/association/reconciliation|Reviewed design with confirmed capture prerequisite|None: 0% for implementation|Explicit non-initializing workspace mode; strict contracts, lazy storage/CAS/recovery/provenance and tests|efe68b18/988ce3f7 plus independent45-payload review|Accepted core hooks, original source budget and future native owner|Seven current-behavior positives; independent2-red/2-positive assumption counterexample|Legacy open writers remain possible; identity before sidecars; no stored-path revival|KB + core + root|Spec-first source, original/neighbor controls and representative durable journey|
| Whole PW02 local package fallback|Partial; no exposed package-to-project route|None: 0% of whole-feature milestones|Native stage/FDI/worker transfer, durable facade, Windows/frozen journey and all final gates|Portable slices and retained designs|Qualified Windows lane and existing services|Component evidence only; whole journey absent|Live lease/ownership, preserved provenance, finite original budgets and retained unknown outcome|KB + core + CI|Complete stated D/R/J/G journey before exposure|

These fractions count the existing named milestones for the stated bounded scope.
They do not add together or measure project coding progress. Frozen research,
real CVE matching/calibration, complete analyst, platform, packaging, security
and reproducibility acceptance remain incomplete.
''')
for path, prefix in [('docs/qa.md', 'qa/'), ('docs/plans/autonomous-consolidation-20261118/consolidation-ledger.md', '../../qa/')]:
    with (REPO / path).open('a') as f:
        f.write(short.replace('../qa/', prefix))
with (REPO / 'tasks/todo.md').open('a') as f:
    f.write('''\n\n### Core admission / hosted Windows evidence checkpoint — 2026-11-18

- [x] Independently verify and port the specification-first create/open/load hooks and constructor follow-up; preserve both immutable author packets and original probes.
- [x] Pass the exact a8f698f6 45-file gate: 1,200 checks, zero skips, 434 canonical imports and 21 owner paths. Preserve normal lint success and strict 80-site failure unchanged.
- [x] Verify prior 18-commit publication to771e, fresh main/priority heads, actual Windows UTF-8 inventories/audits and exact native error-path source.
- [x] Retain new unified Windows repeated-analysis failure and separate pending QA snapshot, without changing digests/acceptance or executing retained images.
- [x] Review the durable design and preserve its already-open legacy-client and non-initializing capture counterexamples; keep ordinary default behavior distinct.
- [ ] Publish this checkpoint append-only with exact remote tree/parent/ref/preview/body verification.
- [ ] Specify, implement and independently qualify the actual-connection non-initializing workspace seam, then strict durable package contracts/storage/association/reconciliation.
- [ ] Complete trusted stdin handoff and bounded first/second unified diagnostic retention, preserving native failures until actual-source acceptance.
- [ ] Repair the independently reproduced TierR exit1 diagnostic loss; original native causes and frozen outcomes remain separate.
- [ ] Complete full platform/Qt/native/frozen/package/dependency/security/reproducibility gates and real CVE/KB/analyst journeys; leave main and release blocked until qualified.
''')
print(json.dumps(dict(source=SOURCE, tree=tree, payloads=len(payloads), archive_bytes=len(archive), archive_sha256=sha(archive))))
