# PR316 `771e5a77`: bounded hosted Windows receipt review

## Disposition

The corrected UTF-8 child argv now has actual hosted Windows evidence: both the
runtime and packaging dependency profiles complete their inventories and strict
audits at this exact source. The Windows BinDiff native build succeeds, but the
actual `no_network` acceptance still fails behind a green advisory job. Its new
diagnostics identify an immediate `NUL` reopen failure in the restricted probe,
before descendant process creation. This packet does not qualify complete native
isolation, main QA/Qt, frozen packaging, the release, or local-package intake.

This is a read-only review. No workflow was dispatched or retried, no remote ref
was changed, no dependency was installed locally, and no retained native image
was extracted or executed. The diagnostic author checkout remains clean at
`dfdf1c488e242adc6b3a38eb6975e6503f1eb2b2`.

## Source ownership and observation boundary

| Identity | Value |
| --- | --- |
| Repository | `djshellshoxxx/patchtrace` |
| Actual PR316 head | `771e5a775f5bf60a8d9094232b51dcdbb47d6389` |
| Merge preview | `ac6632ad6de486ba16343f0eeb4a2b5a446e4ac1` |
| Shared tree | `ddf151c6ff8fb3f70b74378525fe1d8d5c9050e3` |
| Preview first parent / main | `9c411ca3d7b47f950be5f0c6f01b3c54184554c6` |
| Preview second parent | Exact actual PR head above |
| Initial metadata read completed by | `2026-11-18 22:18:24 UTC` |

The actual head contains literal `[no release]`. The head and preview tree match;
PR preview evidence still does not become canonical release-source qualification.
The initial snapshot contains 43 checks and 11 attempt-1 workflow runs. Completed
canonical-push Windows dependency jobs were selected for detailed review. After
useful offline dependency and Tier R work, one focused read retrieved the known
Windows BinDiff job and its completed artifact. There was no general check loop.
`dependency-findings.json` preserves the initial counts and pending list; it is
not silently rewritten with later job state. Full QA and Qt were pending at that
snapshot, and their later outcome is outside this packet.

Ten canonical Git source files are retained under `source/`, with tree/blob IDs
and SHA-256 values in `source-snapshots.json`. The dependency tool is byte-identical
to reviewed UTF-8 source `6dea194a`. The three C files are byte-identical to reviewed
diagnostic source `9ca3c078`. These identities distinguish this result from the
original f3 and fb09 failures, which remain immutable in their earlier packets.

## Hosted Windows dependency and encoding result

Both profiles belong to canonical push run **44409963273**, attempt **1**, workflow
`.github/workflows/dependency-security.yml`. The actual **Audit installed
dependencies** step succeeds in each job; this review also checks the underlying
process and inventory receipts.

| Profile | Job | Artifact | Bytes | Audited distributions |
| --- | --- | --- | ---: | ---: |
| Runtime | 135175146507 | 14475803357 | 327,206 | 17 |
| Packaging | 135175146843 | 14475753388 | 410,057 | 34 |

Artifact SHA-256 values:

- Runtime: `3ab9b20c3a999834aaa557bef4c2c1ef227d5bf366ddaded14fe5c71dd1b3c71`
- Packaging: `b09c7207ad1d1bd79543e72c51d5a6f2a9182322fcac753f6f087cca2a911871`

`verify_dependency_receipts.py` performs an offline comparison of the captured
bytes. It verifies repository/head/tree/event/workflow/run/attempt/profile/job
ownership, each process's stdout/stderr hashes, successful process status without
timeout/output-limit/error, and explicit `-I -X utf8` argv. It checks the exact
CPython **3.12.10**, Windows/AMD64, final pip **26.3**, and installation environment
crosschecks. It preserves the bootstrap issuer **25.0.1** separately from the
installed target **26.3**, including the retained hash-pinned wheel provenance.

The final raw installed closure, minus the separately proved repository-owned
PatchTrace distribution, equals both `audit-requirements.txt` and the audit's
name/version set. Runtime has 17 auditable dependencies; Windows packaging has
34. These are the Windows closure counts, not the earlier Linux packaging count.
Pip **26.3** is included in both product audits, using pip-audit **2.10.1**. Both
actual audits exit zero and contain zero vulnerability rows, skipped distributions
or fixes. The captured scanner inventory includes actual UTF-8 U+1F44B bytes—the
character that failed under CP1252 in the earlier captures.

This is the first repaired-source hosted Windows result in this review chain.
It supports the defined encoding/inventory/audit boundary. It does not establish
the absence of every vulnerability. Each original `unaudited.json` is retained:
external Ghidra/JDK/Rizin/BinDiff/NSIS and their closures; OS and vendored native
components; separate frozen/bundle BOM; calibration-dev; scanner tooling
dependencies; and exploitability/advisories absent from the chosen database.

The strict-static job **135175145901** fails in the canonical push run. Its new
artifact was not downloaded in this bounded Windows review. No new clean-scan
claim or new finding count is inferred from the job badge. Earlier automated
strict status and manual site dispositions remain attributable to their own
retained sources and reports.

## Hosted Windows BinDiff diagnostic result

Run **44409973491**, job **135175184142**, attempt **1**, completed at
`2026-11-18T22:19:02Z`. The job has a successful advisory badge, but actual pytest
reports **1 failed in 38.01s** and `bindiff.json` reports `status: failed`.

Artifact **14475538670** is **207,921 bytes**, SHA-256
`cc5927dd12b64ed6599a906d584bfe6961f8bd29215651b78b94a00ad158f251`.
It contains 50 members. The original ZIP stays inert; only bounded UTF-8 text
members are materialized. `network-build/build.json` and its source hashes match
the exact merge preview and canonical C snapshots. Compiler return code is zero;
the resulting launcher/probe hashes match the archived image bytes and runtime
receipt. This is actual Windows compile evidence for the diagnostic source.

Six other acceptance subchecks pass. The ordinary synthetic 20/21-function pair
produces 20 matches and complete semantic fingerprint
`77f36f7aac14a6e321c2c6aba9e0c7e3ca6cdba3f690fc18d188ca987b88e181`.
These observations do not qualify the failed restricted network path.

The unrestricted before-control completes depths 0/1/2, each with all five network
cases connected. The restricted launcher records actual zero-capability
AppContainer identity, explicit `nul/pipe/pipe` handles, image lock, Job assignment
and token validation before resume. Only its depth-zero probe is then observed.

The complete `network/01-probe-denied.stderr` is 1,837 bytes and contains nine
bounded structured diagnostic records. The restricted probe's sequence is:

| Sequence | Stage | Kind / error | Bytes |
| ---: | --- | --- | --- |
| 1–2 | `socket-connect-wait` | timeout / 10060 | sent 0, received 0 |
| 3–4 | `socket-receive-wait` | timeout / 10060 | sent 32, received 0 |
| 5 | `socket-error` | Winsock / 10013 | sent 0, received 0 |
| 6 | `nul-open` | Win32 / **5** | not a socket operation |
| 7 | `child-spawn` | Win32 / **5** | not a socket operation |

The outer launcher adds `child-exit` and `child-finish`, both **125**, tied to the
same restricted probe PID. The exact C call path matters: `pt_spawn` reopens `NUL`
before stdio duplication, attribute setup, Job creation and `CreateProcessW`.
The probe calls it to create depth one. Thus the captured immediate process-chain
failure is the restricted `NUL` open, before any descendant creation—not a
`CreateProcessW` failure inferred from a socket error.

The four loopback timeouts still do not establish effective denial. The two UDP
records report successful 32-byte sends but no received reply; delivery to the
listener is not proven by these records. External TCP reports 10013. The full
restricted descendant chain, adapter invocation, lifecycle checks and after-control
are not reached. Correcting the immediate stdin failure alone would not qualify
the remaining network controls.

The outer launcher finishes with `tree_empty: true`, return code 125 and
`timed_out: false`. The aggregate `cleanup.process_tree_empty: false` is retained
as incomplete full-flow evidence; it is not proof that a descendant remained
alive. Profile deletion and private-tree removal are true. No successful native
acceptance or general sandbox claim is made.

`verify_native_receipt.py` independently checks these source, image-hash,
identity, per-owner sequence, byte-bound, process, cleanup and subcheck relations.
Its output is `native-verification.log`; full structured observations are in
`native-findings.json`. The raw diagnostics remain authoritative if a shortened
top-level reason truncates their text.

## Evidence handling and handoff

The three original artifact ZIPs total **945,184 compressed bytes**. Their public
API size/SHA metadata, all member sizes/hashes/CRCs and text materialization records
are retained. Signed connector transfer/download URLs are not saved. The three
decoded job logs preserve the exact UTF-8 encoding of original connector content,
including line endings; original delivery objects remain alongside them.

`manifest.json` lists every payload with relative path, bytes and SHA-256;
`source-snapshots.json` carries canonical Git blob ownership. `verification.json`
records the final offline archive/source/member/log checks and stable branch.
`seal.json` records `evidence.zip` size, SHA-256 and manifest digest. This external
packet has no author-branch commit; root owns its immutable QA integration.

The separate old-source Tier R diagnosis is frozen under
`qa/tier-r-fb09-diagnosis`. It must not be attributed to this new-source Windows
native run. A parent-created inert-stdin handoff design is the next review item;
no native source changes are part of this packet.
