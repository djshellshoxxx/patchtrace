"""Reclaim only completed, clean branch-backed checkouts after byte verification."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

ROOT=Path('/workspace/scratch/c7a9e8d98848')
REPO=ROOT/'continuation-integration'
OUT=Path(__file__).resolve().parent/'evidence'
EXPECTED={'cvrf-pilot': 'afda4c069a3e4e98ba3e536ddb5448d51b0a1447', 'inventory': '713c348d12cc020967d6a7adae4a620dfd2f6502', 'object-publication': '01d92af145fde5cf776a36803725775cbbc54564', 'release-qualification': 'd27464d303bd0eaca219416c261ab6ba6869177e', 'security-contract-triage': '668cdd9dd73792208082759713a749ae3e2ef8c3', 'tooltip-review': '010b9e6170b9a882556d11aed0a3186873cd216f', 'integration307': '45a864017ae05dd6c4ab941747971c5668fedc3e'}


def git(path,*args):return subprocess.check_output(['git','-C',str(path),*args])


def sha(raw):return hashlib.sha256(raw).hexdigest()


def write(name,data):
    with (OUT/name).open('x') as f:json.dump(data,f,indent=2);f.write('\n')


def active_cwds():
    found=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdigit():continue
        try:target=(p/'cwd').resolve(strict=True)
        except (OSError,RuntimeError):continue
        if any(target.is_relative_to(ROOT/name) for name in EXPECTED):found.append(dict(pid=int(p.name),cwd=str(target)))
    return found


OUT.mkdir(exist_ok=False)
before=shutil.disk_usage(ROOT).free
assert not active_cwds()
records=[];support={}
for name,expected in EXPECTED.items():
    p=ROOT/name
    assert p.is_dir() and not p.is_symlink()
    assert not git(p,'status','--porcelain=v1','--untracked-files=all')
    assert git(p,'rev-parse','HEAD').decode().strip()==expected
    branch=git(p,'symbolic-ref','HEAD').decode().strip()
    assert branch.startswith('refs/heads/') and git(REPO,'rev-parse',branch).decode().strip()==expected
    files=[]
    for item in git(p,'ls-files','--stage','-z').split(b'\0'):
        if not item:continue
        header,path=item.split(b'\t',1)
        mode,blob,stage=header.decode().split()
        assert stage=='0' and mode in ('100644','100755','120000')
        relative=path.decode();target=p/relative
        data=target.readlink().as_posix().encode() if mode=='120000' else target.read_bytes()
        assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob,(name,relative)
        files.append(dict(path=relative,git_blob=blob,bytes=len(data),sha256=sha(data)))
    write(name+'-tracked-files.json',dict(head=expected,branch=branch,files=files))
    ignored=[];omitted=0
    for raw in git(p,'ls-files','--others','--ignored','--exclude-standard','-z').split(b'\0'):
        if not raw:continue
        relative=raw.decode();parts=Path(relative).parts;target=p/relative
        assert '__pycache__' in parts or parts[0] in ('.hypothesis','.pytest_cache','.ruff_cache'),(name,relative)
        assert target.is_file() and not target.is_symlink()
        ignored.append(relative)
        if '__pycache__' in parts:omitted+=1
        else:support[name+'/'+relative]=target.read_bytes()
    records.append(dict(name=name,head=expected,branch=branch,tracked_files=len(files),
        tracked_bytes=sum(r['bytes'] for r in files),ignored_files=ignored,reproducible_bytecode_files_omitted=omitted))
archive=OUT/'retained-test-support.zip'
with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for path,data in sorted(support.items()):z.writestr(path,data)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and set(z.namelist())==set(support)
    for path,data in support.items():assert z.read(path)==data
write('pre-removal.json',dict(at=datetime.now(timezone.utc).isoformat(),free_before=before,worktrees=records,
    active_process_cwds=[],process_scan_scope='Current execution namespace, supplemented by coordinator and agent worktree ownership confirmations.',support_archive_sha256=sha(archive.read_bytes()),
    support=[dict(path=p,bytes=len(d),sha256=sha(d)) for p,d in sorted(support.items())],
    omitted='Only reproducible Python bytecode; tracked canonical bytes and other test-support files verified first.'))
results=[]
for row in records:
    p=ROOT/row['name']
    assert not active_cwds() and not git(p,'status','--porcelain=v1','--untracked-files=all')
    assert git(p,'rev-parse','HEAD').decode().strip()==row['head']
    result=subprocess.run(['git','-C',str(REPO),'worktree','remove',str(p)],capture_output=True)
    after=git(REPO,'rev-parse',row['branch']).decode().strip()
    item=dict(name=row['name'],head=row['head'],branch=row['branch'],exit=result.returncode,
              stdout=result.stdout.decode(),stderr=result.stderr.decode(),branch_head_after=after,
              force=False,branch_deleted=False)
    results.append(item);write(row['name']+'-removal.json',item)
    assert result.returncode==0 and after==row['head']
receipt=dict(at=datetime.now(timezone.utc).isoformat(),removed_checkouts=len(results),
    branch_heads_unchanged=True,force=False,branch_deletion=False,free_before=before,
    free_after=shutil.disk_usage(ROOT).free,tracked_files_verified=sum(r['tracked_files'] for r in records),
    support_files_retained=len(support),support_archive_sha256=sha(archive.read_bytes()))
write('receipt.json',receipt)
print(json.dumps(receipt))
