# PR316 771e: completed unified Windows failure and pending QA snapshot

At **2026-11-18 22:37:08 UTC**, the exact head `771e5a775f5bf60a8d9094232b51dcdbb47d6389` had 32 successful,
3 failed, 4 skipped and 6 still-running check records. The full QA workflow's six
Linux/Windows QA/Qt jobs were still running; its artifact collection was empty.
One Qt shard was complete. The release gate was skipped. No pending/skipped job
is credited as passing, and this packet performs no dispatch or retry.

The completed new non-static failure is the Windows unified workflow
`44409973392`, job `135175184056`. Its CI fixture extraction step passes; the
probe-pair step fails. The downstream Linux job is skipped. The actual probe
newer side reports two different analyze digests:

- first: `a658ef9f00c21c74bac115a68414f8188206258c051a9c3ea9c484e0d0e65c0c`
- second: `b7dc355b73b3482f82fff8c81ba8d32e51e285a357dc39ba96ba0f6bcf3bf936`

The repeated ir_key agrees. GZF extraction and the Ghidriff-retained program
agree with the first run. Their positive checks do not satisfy the failed L1
determinism assertion. The first run has 383 functions. The full decoded log
preserves the exact connector text and both digests.

Original artifact `14477506098` has six members, 215,897 bytes, SHA-256
`f785fd27d473c0410c4bbd57459cedf94fbee7e8f45e9b6f4319c801c81e3e9d`. API metadata, every member hash/CRC and the two exact JSON
materializations are verified. The four authored fixture DLLs stay inert inside
the original ZIP; none was extracted or executed. All four input hashes and the
four first-run digests equal the earlier fb09 artifact. Six traced workflow,
checker and extractor/ingest files also match fb09 byte for byte. Engine scratch
state is not shown to be equal by those comparisons.

The uploaded JSON records only the first analyze run. The actual checker retains
both analyses temporarily, compares them, then removes the work directory in its
finally block. The second manifest/function records are absent from this artifact.
The original divergent field and its native cause therefore remain unknown.
The next assigned work is a bounded diagnostic-retention proposal with meaningful
portable tests; no digest/normalization, native engine or acceptance changes are
authorized by this evidence.

This refresh is separate from the immutable earlier 771e Windows dependency/native
packet. That packet's initial status snapshot remains unchanged. The first direct
job-detail retrieval was unsupported by the generic connector; the original
error is retained, and the supported run-jobs/log routes supplied the completed
job evidence. No setup failure is presented as a product test.

`findings.json`, `source-snapshots.json`, the original delivery objects and ZIP,
and the exact decoded log provide the reviewable data. No signed transfer URL is
retained. This result keeps unified/native qualification blocked.
