"""Schema is changed after pathname checks but before the initial SQLite transaction."""
import sqlite3

import pytest

from patchtrace import persistence
from patchtrace.sample import synthetic_pe
from patchtrace.service import ProjectService


def test_actual_connection_refuses_a_schema_added_before_begin(tmp_path, monkeypatch):
    root = tmp_path / 'case'
    persistence.ProjectStore(root, create=True).close()
    path = root / 'project.sqlite3'
    pair = tmp_path / 'old.dll', tmp_path / 'new.dll'
    for number, source in enumerate(pair):
        source.write_bytes(synthetic_pe(number))
    connect = sqlite3.connect
    expected = []

    class Altered(sqlite3.Connection):
        def execute(self, statement, *args):
            if statement == 'BEGIN IMMEDIATE' and not expected:
                with connect(path) as writer:
                    writer.execute('CREATE VIEW retained_operator_note AS SELECT 41 AS marker')
                expected.append(path.read_bytes())
            return super().execute(statement, *args)

    monkeypatch.setattr(persistence.sqlite3, 'connect',
                        lambda *args, **kwargs: connect(*args, factory=Altered, **kwargs))
    with pytest.raises(ValueError):
        with ProjectService.create(*pair, 'must preserve changed schema', root):
            pass
    assert expected and path.read_bytes() == expected[0]
    assert not (root / 'artifacts').exists()
