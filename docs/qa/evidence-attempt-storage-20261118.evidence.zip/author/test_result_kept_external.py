"""Authored SQLite controls for retained-result wording; no engine execution."""
from pathlib import Path

import pytest
from qt_support import join_gui_threads, main_window, settings  # noqa: F401
from test_evidence_view import mset, rz

from patchtrace.enrichment.storage import EnrichmentStore
from patchtrace.secondary.evidence_panel_service import RunRequest, latest_run
from patchtrace.secondary.evidence_view import EngineOutcomeView
from patchtrace.secondary.runs import EngineRun
from patchtrace.secondary.store import current_sets


def views(window):
    controller = window.panels.controller('evidence')
    project = window.service.project
    current = latest_run(project)
    sides = {a.side: a.sha256 for a in project.artifacts}
    controller.run_generation += 1
    controller.run_request = RunRequest(
        project.id, project.revision, controller.run_generation, ('rz-diff', 'bindiff'), 1, 60,
        Path('older'), Path('newer'), sides['older'], sides['newer'], current.id)
    match_set = mset('rz-diff', rz(16, 32), rz(48, 64),
                     older=sides['older'], newer=sides['newer'])
    output = []
    for engine, status in (('rz-diff', 'ok'), ('bindiff', 'failed')):
        record = EngineRun(
            run_id='kept-review-' + engine, engine=engine, engine_version='0.9.1' if engine == 'rz-diff' else '8',
            executable_path_sha256=None, argv_digest='a' * 64,
            older_sha256=sides['older'], newer_sha256=sides['newer'], orientation='older->newer',
            cache_key='b' * 64, status=status, error_code=None if status == 'ok' else 'PT-SECONDARY-RUN',
            returncode=0 if status == 'ok' else 3, started_utc='2026-11-18T12:00:00Z', duration_ms=1,
            stderr_tail='', output_sha256=match_set.file_sha256 if status == 'ok' else None,
            match_set_id=match_set.entry_id if status == 'ok' else None)
        output.append(EngineOutcomeView(
            engine, status, version=record.engine_version, error_code=record.error_code,
            message='' if status == 'ok' else 'authored engine failure', run=record,
            run_id=record.run_id, started_utc=record.started_utc,
            match_set=match_set if status == 'ok' else None))
    return controller, output


@pytest.mark.parametrize('persist_success', [False, True], ids=['unsaved-ok', 'saved-ok'])
def test_result_kept_requires_a_stored_set(main_window, persist_success, monkeypatch):
    controller, (success, failure) = views(main_window)
    messages = []
    original = controller.panel.set_run_status

    def capture(message):
        messages.append(message)
        original(message)

    monkeypatch.setattr(controller.panel, 'set_run_status', capture)
    connection = main_window.service.store.connection
    store = EnrichmentStore(main_window.service.store)
    try:
        if not persist_success:
            connection.execute('PRAGMA query_only=ON')
        controller._engine_finished(success, controller.run_generation)
        stored = current_sets(store)
        assert len(stored) == int(persist_success)
        connection.execute('PRAGMA query_only=ON')
        controller._engine_finished(failure, controller.run_generation)
        assert current_sets(store) == stored
        assert ('rz-diff result kept' in messages[-1]) is persist_success, messages
    finally:
        connection.execute('PRAGMA query_only=OFF')
