"""Bounded, source-pinned local pytest receipts for this review only."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time


parser = argparse.ArgumentParser()
parser.add_argument('--tree', required=True, type=Path)
parser.add_argument('--prefix', required=True, type=Path)
parser.add_argument('tests', nargs='+')
args = parser.parse_args()
tree = args.tree.resolve()
prefix = args.prefix.resolve()
prefix.parent.mkdir(parents=True, exist_ok=True)
python = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
env = dict(os.environ, PYTHONPATH=f'{tree}/src:{tree}/tests', QT_QPA_PLATFORM='offscreen')
command = [python, '-m', 'pytest', '-q', *args.tests, f'--junitxml={prefix}.xml']
source = tree / 'src/patchtrace/ui_evidence.py'
context = {
    'tree': str(tree), 'source_sha': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=tree, text=True).strip(),
    'source_file': str(source), 'source_file_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
    'command': command, 'PYTHONPATH': env['PYTHONPATH'], 'QT_QPA_PLATFORM': env['QT_QPA_PLATFORM'],
    'external_files': {p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
                       for p in args.tests if Path(p).is_absolute() and Path(p).is_file()},
}
Path(f'{prefix}-context.json').write_text(json.dumps(context, indent=2) + '\n')
started = time.monotonic()
with Path(f'{prefix}.log').open('wb') as log:
    result = subprocess.run(command, cwd=tree, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=180)
receipt = {'exit': result.returncode, 'elapsed_s': round(time.monotonic() - started, 3)}
Path(f'{prefix}-exit.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
print(Path(f'{prefix}.log').read_text()[-2500:])
raise SystemExit(result.returncode)
