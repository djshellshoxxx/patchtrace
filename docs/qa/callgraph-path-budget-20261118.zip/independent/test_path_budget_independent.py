"""Independent finite simple-path oracle, with varying allowed sets and query limits."""
from itertools import permutations
import random

from patchtrace.callgraph.algo import simple_paths
from patchtrace.callgraph.csr import build_csr


def test_bounded_partial_queries_preserve_oracle_prefix_across_membership_and_limits():
    rng = random.Random(2026111817)
    for case in range(200):
        count = rng.randrange(3, 9)
        edges = {(u, v) for u in range(count) for v in range(count)
                 if rng.random() < (0.16 + case % 5 * 0.09)}
        source, destination = rng.randrange(count), rng.randrange(count)
        allowed = (None if case % 3 == 0 else
                   frozenset(n for n in range(count) if rng.random() < 0.65))
        maximum_length = rng.randrange(0, 6)
        maximum_paths = rng.randrange(1, 6)
        if source == destination:
            expected = ((source,),)
        else:
            internal = [n for n in range(count) if n not in (source, destination)
                        and (allowed is None or n in allowed)]
            candidates = []
            for length in range(1, min(maximum_length, count - 1) + 1):
                for middle in permutations(internal, length - 1):
                    path = (source, *middle, destination)
                    if all(edge in edges for edge in zip(path, path[1:])):
                        candidates.append(path)
            expected = tuple(sorted(candidates, key=lambda p: (len(p), p))[:maximum_paths])
        graph = build_csr(count, reversed(sorted(edges)))
        for budget in (0, 1, 3, 8, 17, 32, 120, 2000):
            result = simple_paths(graph, source, destination, maximum_paths,
                                  maximum_length, budget, allowed=allowed)
            context = (case, count, source, destination, maximum_paths,
                       maximum_length, budget, allowed, sorted(edges), result)
            assert result.paths == expected[:len(result.paths)], context
            assert len(result.paths) <= maximum_paths, context
            if not result.truncated:
                assert result.paths == expected, context
            if budget == 2000:
                assert not result.truncated, context
