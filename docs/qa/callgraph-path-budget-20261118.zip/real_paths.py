"""Actual headless CLI paths on authored projects; no target/native/network execution."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

from callgraph_cli_support import make_project
from test_callgraph_path_budget import _hub_raw

QA = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/c7a9e8d98848/callgraph-path-budget')
SOURCE = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
NOTE = 'Path search reached its work limit; more paths may exist.'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    journey = QA / 'journey'
    journey.mkdir()
    hub = make_project(journey / 'synthetic-hub', _hub_raw())
    small = make_project(journey / 'synthetic-small', _hub_raw(k=1, dead=0))
    before = {str(root): digest(root / 'project.sqlite3') for root in (hub, small)}
    guard = journey / 'headless-guard'
    guard.mkdir()
    (guard / 'sitecustomize.py').write_text(
        "import sys\n"
        "class NoQt:\n"
        "    def find_spec(self, fullname, path=None, target=None):\n"
        "        if fullname.split('.')[0] in {'PySide6', 'PyQt6', 'PyQt5'}:\n"
        "            raise RuntimeError('headless path query imported Qt: ' + fullname)\n"
        "sys.meta_path.insert(0, NoQt())\n")
    cases = [
        ('capped-seed0', hub, 'src', 'dst', 3, 0),
        ('capped-seed1', hub, 'src', 'dst', 3, 1),
        ('complete', small, 'src', 'dst', 0, 0),
        ('empty', small, 'dst', 'src', 4, 0),
        ('identity', small, 'src', 'src', 0, 0),
    ]
    records, capped = [], []
    for name, project, source, target, expected_code, seed in cases:
        env = os.environ.copy()
        env.update(PYTHONPATH=str(guard) + ':' + str(ROOT / 'src'), PYTHONHASHSEED=str(seed))
        argv = [sys.executable, '-m', 'patchtrace', 'graph', 'paths', str(project),
                '--from', source, '--to', target, '--side', 'newer', '--json']
        done = subprocess.run(argv, cwd=ROOT, env=env, capture_output=True, text=True, timeout=30)
        (journey / (name + '.stdout')).write_text(done.stdout)
        (journey / (name + '.stderr')).write_text(done.stderr)
        assert done.returncode == expected_code, (name, done.returncode, done.stdout, done.stderr)
        document = json.loads(done.stdout)
        assert document['status'] == ('partial' if expected_code == 3 else 'complete')
        result, = document['result']['results']
        labels = [[result['labels'][node] for node in path] for path in result['paths']]
        assert result['truncated'] is (expected_code == 3)
        assert (NOTE in result['note']) is (expected_code == 3)
        assert labels == ([] if name == 'empty' else [['src']] if name == 'identity' else [['src', 'z', 'dst']])
        if expected_code == 3:
            capped.append(done.stdout)
        records.append({'name': name, 'argv': argv, 'hash_seed': seed, 'exit': done.returncode,
                        'status': document['status'], 'truncated': result['truncated'],
                        'paths_by_label': labels, 'note': result['note']})
    assert capped[0] == capped[1]
    after = {str(root): digest(root / 'project.sqlite3') for root in (hub, small)}
    assert before == after
    receipt = {'source': SOURCE, 'synthetic': True, 'native_engines': False, 'network': False,
               'qt_import_forbidden': True, 'commands': records, 'same_capped_stdout_across_hash_seeds': True,
               'database_before': before, 'database_after': after}
    (QA / 'real-paths.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'source': SOURCE, 'commands': len(records), 'capped_retained_path': ['src', 'z', 'dst'],
                      'hash_seed_stable': True, 'databases_unchanged': True}, indent=2))


if __name__ == '__main__':
    main()
