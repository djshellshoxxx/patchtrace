"""Download exact signed-index Ubuntu packages; no system installation or privilege change."""
from pathlib import Path
import concurrent.futures
import hashlib
import json
import subprocess
import urllib.request

ROOT = Path(__file__).resolve().parent
BASE = 'https://snapshot.ubuntu.com/ubuntu/20260828T000000Z/'
PACKAGES = ('clang-18', 'lld-18', 'llvm-18', 'libllvm18', 'libclang-cpp18', 'libclang1-18',
            'libclang-common-18-dev', 'llvm-18-runtime', 'llvm-18-linker-tools', 'libpfm4')

def metadata(package):
    text = subprocess.check_output(['apt-cache', 'show', '--no-all-versions', package], text=True)
    fields = dict(line.split(': ', 1) for line in text.splitlines() if ': ' in line and not line.startswith(' '))
    if fields['Package'] != package or not fields['Filename'].startswith('pool/'):
        raise RuntimeError('unexpected package metadata')
    return {'package': package, 'version': fields['Version'], 'bytes': int(fields['Size']),
            'sha256': fields['SHA256'], 'url': BASE + fields['Filename'],
            'path': str(ROOT / 'archives' / Path(fields['Filename']).name)}

def download(item):
    target = Path(item['path'])
    digest = hashlib.sha256()
    count = 0
    with urllib.request.urlopen(item['url'], timeout=60) as response, target.open('xb') as out:
        while block := response.read(1024 * 1024):
            count += len(block)
            if count > item['bytes']:
                raise RuntimeError('package exceeds published size')
            digest.update(block)
            out.write(block)
    if count != item['bytes'] or digest.hexdigest() != item['sha256']:
        raise RuntimeError('package differs from signed apt index')
    return item | {'verified': True}

items = [metadata(p) for p in PACKAGES]
(ROOT / 'planned-packages.json').write_text(json.dumps(items, indent=2) + '\n')
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
    verified = list(pool.map(download, items))
(ROOT / 'verified-packages.json').write_text(json.dumps(verified, indent=2) + '\n')
for item in verified:
    subprocess.run(['dpkg-deb', '-x', item['path'], str(ROOT / 'runtime')], check=True)
print(json.dumps({'verified_and_extracted': len(verified), 'bytes': sum(i['bytes'] for i in verified),
                  'system_packages_modified': False}))
