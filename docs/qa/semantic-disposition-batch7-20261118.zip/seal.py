"""Seal original-byte evidence, verifying every retained member and its source."""
from pathlib import Path
import hashlib,json,shutil,subprocess,zipfile
Q=Path(__file__).parent
R=Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
B='55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
assert git('rev-parse','HEAD').decode().strip()==B
assert not git('diff','--','src','tests','tools','.github')
subprocess.run(['git','diff','--check'],cwd=R,check=True)
ledger=json.loads((Q/'ledger.json').read_text());checks=json.loads((Q/'document-validation.json').read_text())
for file,current in [('current-source-manifest.json',True),('historical-source-manifest.json',False)]:
 for row in json.loads((Q/file).read_text()):
  data=(Q/('current-source/'+row['path'] if current else row['retained'])).read_bytes()
  assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
  assert data==git('show',(row['source'] if current else row['tip'])+':'+row['path'])
for row in json.loads((Q/'historical-control-source.json').read_text())['files']:
 data=(Q/row['retained']).read_bytes()
 assert data==git('show',row['tip']+':'+row['path'])
 assert hashlib.sha256(data).hexdigest()==row['sha256']
for row in ledger['branches']:
 for proof in row['replacement_proofs']:
  raw=git('show',B+':'+proof['path'])
  assert hashlib.sha256(raw).hexdigest()==proof['current_sha256'] and proof['needle'] in raw.decode()
union=json.loads((Q/'original-131-union.json').read_text())
assert union['selected']==131 and union['unselected']==0 and len({r['branch'] for r in union['rows']})==131
history_entries=sum(len(p['history']) for r in ledger['branches'] for p in r['replacement_proofs'])
parent_checks=sum(len(h['parent_presence']) for r in ledger['branches'] for p in r['replacement_proofs'] for h in p['history'])
readme=f'''# Semantic disposition batch7: final original focal partition

Frozen comparison **`{B}`**, tree **`{ledger['comparison_tree']}`**. Later PR316/continuation sources are separate. No source, tests, tools, workflows or remote refs were changed.

## Result and denominator

The final11 selected tips all have zero net src/tools delta against their own merge bases. The exact original inventory union is **20+20+20+20+20+20+11 =131 branch names**, each occurring once with the exact original tip, zero unselected. The access-test pair shares one tip and is explicitly counted as two branch names, not two distinct features. Batch1 remains pinned ac789, batch2 remains3be, batches3–7 remain55f3; this final document does not relabel earlier comparisons.

This is bounded focal accounting. It does not close whole branches, all307 remote tips, broader research/checkpoint work, native/platform acquisition, hosted jobs, release acceptance or manual desktop gates. Root independent review/selective integration remain open.

The packet contains **{checks['source_snapshots']} current source/spec/test files**, **{checks['historical_snapshots']} original changed files**, **{checks['proofs']} parent-aware replacement proofs**, **{history_entries} history entries** and **{parent_checks} parent-presence checks**. Full changed paths, merge bases, ahead/behind, git-cherry output, exact byte/AST comparisons and the original131 union are machine-readable. Seven nonancestral historical source commits on the haiku release branch have no final net production delta: the src/tools tree identities equal its merge base. Nonancestral commit count alone does not mean omitted code.

## Actual qualification

| Invocation | Passed | Failed | Errors | Expected failures | Skipped | Seconds |
|---|---:|---:|---:|---:|---:|---:|
'''
for label,run in ledger['executions'].items():
 readme+=f"| {label} | {run['passed']} | {run['failed']} | {run['errors']} | {run['expected_failures']} | {run['skipped']} | {run['summary_seconds']} |\n"
readme+='''
The current gate spans11 files, with one explicit real-launcher read-only deselection. It uses normal system-temp fixtures and absolute source PYTHONPATH. Static workflow/build assertions, authored PE parsing, injected acquisition transport, authored Python child supervision and offscreen own-load/stale-load controls ran. No compiler, native engine, target, real network/acquisition, package/frozen process or manual acceptance ran. The known uninjected backend-pin network fixture and long memory-stress experiment were not selected.

All49 executed original test outcomes plus the initial collection incident are classified. Original audit files and deadline file are unchanged Git bytes. Audit replay only routes their read ROOT/WORKFLOWS to the frozen source and uses --runxfail to expose the old assertions. The old CODEX15 blanket policy assertion fails against the current explicit owner-approved Temurin component/SPDX allowlist and enforced non-shipping Ghidra GPL policy; this is not permission to restore the old rule.

The initial original Phase2 collection failed because jsonschema was absent from the product-test venv. The distinct successful invocation uses already-installed primary-runtime jsonschema with existing venv pytest; no installation or product package execution. All20 schema references are internal fragments and replay blocks network. All reference provenance hashes pass. One installed anyio plugin deprecation warning remains in the successful log. These23 checks establish only reference schema/example conformance, not runtime compatibility.

## Material open boundaries and unretained proposals

- CODEX1: mutable action references remain despite the specifically pinned release action.
- CODEX5: dependency installation lacks complete artifact hash locks; exact version constraints are not the same guarantee.
- CODEX6: extracted rizin/Ghidra cache hits skip archive verification before corpus shard use.
- CODEX14: the Linux builder and downstream smoke omit the full frozen top-level CLI loader check.
- Current fixture isolation/GUI waits are retained, but xdist/cache and fresh-interpreter memory measurement proposals are unretained and unqualified.
- The original Phase2 spec/schema/example/provenance package is absent from the current tree, whose enrichment/1 spec explicitly leaves reconciliation open. Preserve the reference package; reconcile semantics/versioning separately after still-reachable runtime/workflow repairs.

A later-source-only comparison at c7d3f258 finds qa-windows.yml, corpus-tier-r.yml, build_linux.py and frozen_smoke.py byte-identical to frozen55. Dependency-security/live-bindiff workflows differ elsewhere. This routes the next investigation but is not a current-candidate test result. The four original probes remain intact for unchanged replay.

## Historical context and limits

The corrected KB fixture projection equals current source, while the original integration projection equals the previously inspected781b36fb tip. Encoding checks now call the importer, no-network fixtures are registered and type/confusable cases use valid shapes. Historical missing wiki/PR-gate documents are preserved as history; their October observations cannot authorize current merges.

Prior sealed batch5/batch6 exact55 observations are references for named inherited scopes, never reruns or additive totals. The batch5 caller erratum remains explicit: the COFF probe uses an optional developer API, and the factory calls apply_case without extra_check. Its original sealed archive is unchanged.

Proof-preflight.md preserves the missing-reference read, missing dependency collection incident, corrected draft parser path and the interim proof-count correction (final39, not40). Every current/historical snapshot and unchanged probe is verified against Git before sealing; every archive member is reopened, CRC/size/SHA256 checked. This checkpoint does not change or close any PR/branch, nor alter the approved owners of later runtime work.
'''
for a,b in [('final11','final 11'),('=131','= 131'),('Batch1','Batch 1'),('batch2','batch 2'),('remains3be','remains 3be'),('batches3–7','batches 3–7'),('remain55f3','remain 55f3'),('all307','all 307'),('original131','original 131'),('spans11','spans 11'),('All49','All 49'),('All20','All 20'),('These23','These 23'),('Phase2','Phase 2'),('CODEX15','CODEX-15'),('CODEX14','CODEX-14'),('CODEX1:','CODEX-1:'),('CODEX5:','CODEX-5:'),('CODEX6:','CODEX-6:'),('frozen55','frozen 55f3'),('inspected781','inspected 781'),('exact55','exact 55f3'),('final39','final 39'),('not40','not 40')]:readme=readme.replace(a,b)
(Q/'README.md').write_text(readme)
files=[p for p in sorted(Q.rglob('*')) if p.is_file() and not any(part in {'__pycache__','.pytest_cache','.hypothesis'} for part in p.parts) and p.name!='evidence-manifest.json']
manifest={str(p.relative_to(Q)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in files}
(Q/'evidence-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=R/'docs/qa/semantic-disposition-batch7-20261118.zip';assert not archive.exists()
with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as stored:
 for p in files+[Q/'evidence-manifest.json']:stored.write(p,str(p.relative_to(Q)))
with zipfile.ZipFile(archive) as stored:
 assert stored.testzip() is None and len(stored.namelist())==len(manifest)+1
 for name,record in manifest.items():
  data=stored.read(name);assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
size,digest=archive.stat().st_size,hashlib.sha256(archive.read_bytes()).hexdigest()
receipt=readme+f'\n## Sealed artifact\n\n[Archive](semantic-disposition-batch7-20261118.zip): **{len(files)+1} verified members**, **{size:,} bytes**, SHA256 **`{digest}`**.\n\n[Scoped ledger](../plans/autonomous-consolidation-20261118/semantic-disposition-batch7.md) and [machine-readable inventory](../plans/autonomous-consolidation-20261118/semantic-disposition-batch7.json).\n'
(R/'docs/qa/semantic-disposition-batch7-20261118.md').write_text(receipt)
shutil.copyfile(archive,Q.parent/'semantic-disposition-batch7-sealed.zip')
(Q.parent/'semantic-disposition-batch7-receipt.md').write_text(receipt)
print(json.dumps(dict(archive=str(archive),members=len(files)+1,bytes=size,sha256=digest,proofs=checks['proofs'],history_entries=history_entries,parent_checks=parent_checks),indent=2))
