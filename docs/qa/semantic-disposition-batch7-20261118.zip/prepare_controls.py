"""Extract exact original bytes, preserve source identity, and route read-only replay inputs."""
from pathlib import Path
import hashlib
import json
import subprocess

R = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
Q = Path(__file__).parent
B = '55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
def raw(tip, path):
    return subprocess.check_output(['git', 'show', tip + ':' + path], cwd=R)

groups = {
    'phase2': ('4522030ff3ff76d720a5efc33953aaa5e5837398', [
        'docs/specs/phase2/PROVENANCE.md',
        'docs/specs/phase2/PatchTrace-Extension-Specification-2026-10-11.md',
        'docs/schemas/phase2/PatchTrace-Phase2-Contracts-v1.schema.json',
        'docs/schemas/phase2/PatchTrace-Phase2-Synthetic-Examples-v1.json',
        'tests/test_phase2_contract_examples.py']),
    'audit': ('08b12f1b279d917736cfc17d4b8e447c8f552616', [
        'tests/test_codex_pkg_workflows.py', 'tests/test_codex_pkg_packaging.py']),
    'deadline': ('22ff025a7710d07d7ad74be2c8f7cc0b4db0daf7', [
        'tests/test_unified_decompile_runner.py']),
}
rows = []
for label, (tip, paths) in groups.items():
    for path in paths:
        data = raw(tip, path)
        target = Q / 'historical-replay' / label / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        rows.append(dict(group=label, tip=tip, path=path, retained=str(target.relative_to(Q)),
                         bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
(Q / 'historical-control-source.json').write_text(json.dumps({'files': rows, 'source': B}, indent=2) + '\n')
schema = json.loads(raw(groups['phase2'][0], groups['phase2'][1][2]))
refs=[]
def visit(item):
    if isinstance(item, dict):
        if '$ref' in item: refs.append(item['$ref'])
        for value in item.values():visit(value)
    elif isinstance(item,list):
        for value in item:visit(value)
visit(schema)
assert all(ref.startswith('#/') for ref in refs)
(Q/'phase2-reference-inspection.json').write_text(json.dumps({
    'tip': groups['phase2'][0], 'all_refs_internal': True, 'refs': refs,
    'contracts': {entry['$ref'].rsplit('/',1)[1]: {
        'fields': sorted(schema['$defs'][entry['$ref'].rsplit('/',1)[1]].get('properties', {})),
        'required': schema['$defs'][entry['$ref'].rsplit('/',1)[1]].get('required', [])}
        for entry in schema['oneOf']},
    'scope': 'Historical reference only; schema/example conformance does not establish runtime semantic equivalence.'
}, indent=2)+'\n')
print('Extracted',len(rows),'unchanged files; all',len(refs),'schema refs are internal')
