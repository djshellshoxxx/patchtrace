"""Actual trees, immutable helper bytes, and explicit zero-net-source ancestry evidence."""
from pathlib import Path
import hashlib
import json
import subprocess

R=Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
Q=Path(__file__).parent
B='55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
def git(*args):return subprocess.check_output(['git',*args],cwd=R,text=True).strip()
def compare(label,before,after,paths):
    a,b=git('rev-parse',before),git('rev-parse',after)
    diff=git('diff','--name-status',a,b,'--',*paths)
    return dict(label=label,before=a,after=b,path_scope=paths,differences=diff.splitlines(),
                byte_identical_scoped_tree=not diff,
                before_ancestor_of_after=subprocess.run(['git','merge-base','--is-ancestor',a,b],cwd=R).returncode==0)
snapshot=json.loads((Q/'snapshot.json').read_text())
rows=[]
for row in snapshot['branches']:
    item=compare('Net production tree at tip versus merge base: '+row['branch'],row['merge_base'],row['tip'],['src','tools'])
    assert item['byte_identical_scoped_tree']
    item['branch']=row['branch']
    item['trees']={side:git('ls-tree','-d',sha,'--','src','tools').splitlines()
                   for side,sha in [('merge_base',row['merge_base']),('tip',row['tip'])]}
    rows.append(item)
fixtures=['tests/fixtures/kb','tests/kb_crash_harness.py','tests/kb_fixture_performance_plan.md']
fixtures += [p for p in next(r for r in snapshot['branches'] if r['branch']=='integration/kb-fixtures-pr69-20261030')['changed_paths'] if p.startswith('tests/test_kb_')]
comparisons=[
 compare('Original integration KB fixture projection equals the batch6-inspected source', '781b36fb60e775ce01bf0c114e6a17b609fdb475','2fcd627e52a6d784d5c2e5b4ea8105e90b8589b3',fixtures),
 compare('Corrected KB fixture projection retained exactly', '820d70744dff58ef484299791d073b2e712f0524',B,[*fixtures,'tests/test_acquisition_hostile_20261029.py']),
 compare('Five stability fixture files inherited by CPU-budget branch', '64e8374d5d3ae97a719a2bb3ac800497c50892af','cb204f7625d4de496642926bbda37d07e2888131', ['tests/'+p for p in ['test_backend_symbol_local.py','test_jobs.py','test_ui_related_panel.py','test_ui_unified.py','test_unified_pipeline.py']]),
 compare('Deadline file retained byte for byte','22ff025a7710d07d7ad74be2c8f7cc0b4db0daf7',B,['tests/test_unified_decompile_runner.py']),
 compare('CPU-budget test and contract retained byte for byte','cb204f7625d4de496642926bbda37d07e2888131',B,['tests/test_pe_version_info.py','docs/specs/verification.md']),
]
assert all(x['byte_identical_scoped_tree'] for x in comparisons)
source_commits=[]
haiku=next(r for r in snapshot['branches'] if r['branch']=='claude/patchtrace-haiku-agent-motpbx')
for line in json.loads((Q/'catalogue.json').read_text())['branches']:
 if line['branch']!=haiku['branch']:continue
 for record in line['unique_source_commits']:
  sha,subject=record.split(' ',1)
  paths=git('diff-tree','--no-commit-id','--name-only','-r',sha,'--','src','tools').splitlines()
  source_commits.append(dict(sha=sha,subject=subject,paths=paths,
       current_ancestor=subprocess.run(['git','merge-base','--is-ancestor',sha,B],cwd=R).returncode==0,
       source_delta_against_common_base='Zero at final tip; see exact src/tools tree identities, not a patch-equivalence claim.',
       path_projection=[dict(path=p,tip_blob=git('rev-parse',haiku['tip']+':'+p),merge_base_blob=git('rev-parse',haiku['merge_base']+':'+p)) for p in paths]))
helper='tests/fake_exe.py'
helper_data=[subprocess.check_output(['git','show',sha+':'+helper],cwd=R) for sha in ['22ff025a7710d07d7ad74be2c8f7cc0b4db0daf7',B]]
assert helper_data[0]==helper_data[1]
result=dict(baseline=B,zero_net_source_scopes=rows,comparisons=comparisons,
            nonancestral_haiku_source_commits=source_commits,
            historical_deadline_helper=dict(path=helper,identical=True,sha256=hashlib.sha256(helper_data[0]).hexdigest()),
            boundary='Exact tree equality proves these selected net scopes only; unique commit identities, shared broad residue and native qualification remain distinct. No branch closure.')
(Q/'overlap.json').write_text(json.dumps(result,indent=2)+'\n')
print('11 zero-net-source branches,',len(comparisons),'exact scoped comparisons,',len(source_commits),'nonancestral historical source commits accounted for')
