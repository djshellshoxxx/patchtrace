"""One bounded offline shared gate for the inspected batch7 replacement scopes."""
from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import os
import subprocess
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
OUT = Path(__file__).resolve().parent
PY = '/workspace/scratch/3a6632a6e5ff/venv/bin/python'
BASE = '55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
files = ['test_codex_pkg_workflows.py', 'test_codex_pkg_packaging.py',
         'test_pe_version_info.py', 'test_acquisition_hostile_20261029.py']
selected = [
    'tests/test_release_gate.py::test_third_party_actions_in_the_release_job_are_pinned_to_a_commit',
    'tests/test_release_gate.py::test_a_tag_names_its_own_release_and_main_builds_keep_the_beta_name',
    'tests/test_unified_decompile_runner.py::test_the_deadline_of_the_run_caps_the_timeout',
    'tests/test_unified_decompile_runner.py::test_an_expired_budget_is_refused_before_spawning',
    'tests/test_unified_decompile_runner.py::test_a_hung_child_is_killed_at_the_timeout_and_nothing_is_left',
    'tests/test_jobs.py::test_cancel_and_timeout_terminate_children',
    'tests/test_jobs.py::test_precancel_does_not_start',
    'tests/test_backend_symbol_local.py::test_local_run_forces_empty_servers_and_records_provenance',
    'tests/test_unified_pipeline.py::test_children_get_absolute_argv_and_a_private_cwd',
    'tests/test_unified_pipeline.py::test_runs_leave_no_stray_files_behind',
    'tests/test_ui_unified.py::test_loaded_controller_waits_for_its_own_reload_not_the_hosts_first_load',
    'tests/test_ui_unified.py::test_a_code_load_is_shown_when_the_hosts_first_load_landed_before_the_reload',
    'tests/test_ui_unified.py::test_a_slow_code_load_for_an_earlier_row_is_dropped',
    'tests/test_ui_related_panel.py::test_shutdown_cancels_the_running_load_and_drops_its_result',
    'tests/test_ui_related_panel.py::test_a_new_selection_supersedes_the_load_in_flight',
]
deselected = ['tests/test_pe_version_info.py::test_agrees_with_pefile_on_real_windows_launchers']
all_files = sorted({'tests/' + p for p in files} | {s.split('::')[0] for s in selected})
command = [PY, '-m', 'pytest', '-q', '-ra', *('tests/' + p for p in files), *selected,
           *('--deselect=' + p for p in deselected), '--junitxml=' + str(OUT / 'current-affected.xml')]
env = {**os.environ, 'PYTHONPATH': str(ROOT / 'src') + ':' + str(ROOT / 'tests'),
       'QT_QPA_PLATFORM': 'offscreen'}
git = lambda *args: subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()
assert git('rev-parse', 'HEAD') == BASE
assert not git('diff', '--', 'src', 'tests', 'tools', '.github')
metadata = dict(source=BASE, source_tree=git('rev-parse', 'HEAD^{tree}'),
                started_utc=datetime.now(UTC).isoformat(), cwd=str(ROOT), command=command,
                environment={k: env[k] for k in ('PYTHONPATH', 'QT_QPA_PLATFORM')},
                test_files=all_files, selected_nodes=selected, explicit_deselections=deselected,
                excluded_network_fixture='tests/test_build_backend_bundle.py::test_cli_build_refuses_a_pin_with_a_placeholder_with_a_clear_exit_code (not selected)',
                limits='Offline synthetic/fake-runner mechanics only; no compiler, native engine, target execution, network, Windows package or manual acceptance. System-temp fixtures, no custom basetemp.',
                test_file_sha256={p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in all_files})
assert not (OUT / 'current-affected.log').exists()
with (OUT / 'current-affected.log').open('x') as log:
    run = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
metadata.update(exit_code=run.returncode, finished_utc=datetime.now(UTC).isoformat())
if (OUT / 'current-affected.xml').exists():
    xml = ET.parse(OUT / 'current-affected.xml').getroot()
    metadata['junit_suites'] = [s.attrib for s in xml.iter('testsuite')]
    metadata['nonpasses'] = [dict(node=c.get('classname') + '::' + c.get('name'),
                                kind=child.tag, message=child.get('message'))
                           for c in xml.iter('testcase') for child in c
                           if child.tag in ('failure', 'error', 'skipped')]
(OUT / 'current-command.json').write_text(json.dumps(metadata, indent=2) + '\n')
print('exit', run.returncode, 'files', len(all_files))
print('\n'.join((OUT / 'current-affected.log').read_text().splitlines()[-35:]))
