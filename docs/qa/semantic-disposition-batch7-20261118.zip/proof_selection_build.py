from pathlib import Path
import json
Q=Path(__file__).parent
proofs={
 'chatgpt/merge-first-handoff-20261016':[
  ['@docs/plans/chatgpt-merge-first-handoff-20261016.md','**PR #92 is now CLOSED UNMERGED**'],
  ['@docs/plans/chatgpt-merge-first-handoff-20261016.md','identical unreachable'],
 ],
 'claude/clever-clarke-s4nhi6':[
  ['@.github/workflows/qa-windows.yml','timeout-minutes: 120'],
  ['@tests/test_codex_pkg_workflows.py','def test_every_job_has_timeout():'],
 ],
 'claude/fix-deadline-test':[
  ['@tests/test_unified_decompile_runner.py','assert 0 < seen[0] <= 30.0 + 1e-6'],
  ['unified/extract/runner.py','seconds = min(float(seconds), remaining)'],
 ],
 'claude/patchtrace-haiku-agent-motpbx':[
  ['@.github/workflows/qa-windows.yml','softprops/action-gh-release@3bb12739c298aeb8a4eeaf626c5b8d85266b0e65'],
  ['@.github/workflows/qa-windows.yml',"format('PatchTrace {0} (Windows x64, Linux x86-64)', github.ref_name)"],
  ['@tests/test_release_gate.py','def test_third_party_actions_in_the_release_job_are_pinned_to_a_commit():'],
  ['@tests/test_release_gate.py','def test_a_tag_names_its_own_release_and_main_builds_keep_the_beta_name():'],
 ],
 'claude/ws-a2-ci-speed-20261104':[
  ['@tests/test_backend_symbol_local.py',"monkeypatch.setattr(backend.tempfile, 'tempdir', str(tmp_path_factory.mktemp('tmproot')))"],
  ['@tests/test_ui_unified.py','controller.vm is not before and not controller.tasks.busy(ui_unified.LOAD_CHANNEL)'],
  ['@tests/test_unified_pipeline.py','def test_runs_leave_no_stray_files_behind(project, private_tempdir):'],
  ['@tests/stress/test_cli_stress_perf.py','tracemalloc.start()'],
  ['@.github/workflows/qa-windows.yml','python -m pytest -q --junitxml=qa-results.xml'],
 ],
 'codex/audit-2':[
  ['@tests/test_codex_pkg_workflows.py',"@pytest.mark.xfail(strict=True, reason='CODEX-1')"],
  ['@tests/test_codex_pkg_workflows.py',"@pytest.mark.xfail(strict=True, reason='CODEX-5')"],
  ['@tests/test_codex_pkg_workflows.py',"@pytest.mark.xfail(strict=True, reason='CODEX-6')"],
  ['@tests/test_codex_pkg_packaging.py',"@pytest.mark.xfail(strict=True, reason='CODEX-14')"],
  ['@tools/backend_pin.json',"owner answered 'Yes, ship the JDK'"],
  ['@tests/test_codex_pkg_packaging.py',"assert allowed['ghidra-GPL-dir']['shipped'] is False"],
 ],
 'codex/parser-test-cpu-budget-20261104':[
  ['@tests/test_pe_version_info.py','CPU_BUDGET_S = 0.25'],
  ['@tests/test_pe_version_info.py','began = time.process_time()'],
  ['@docs/specs/verification.md','Hermetic malformed-input parser work budgets use CPU time'],
 ],
 'consolidate/kb-fixtures-20261104':[
  ['@.gitattributes','tests/fixtures/kb/cvrf_crlf.json -text -whitespace'],
  ['@tests/test_acquisition_hostile_20261029.py','def test_acq2_valid_surrogate_pair_is_accepted_in_index_entry():'],
  ['@tests/test_kb_fixture_encoding.py','from kbc_k1_support import NOW, no_sockets'],
  ['@tests/test_kb_cvrf_fixture_import.py','remediation["type"] = 99'],
  ['@tests/fixtures/kb/CONTRACT_CONFLICTS.md','A separate `confusable_kb.json` case'],
 ],
 'consolidate/test-stability-20261104':[
  ['@tests/test_jobs.py','process_state = state.read_text().split()[2]'],
  ['@tests/test_ui_unified.py','def host_load_landed(unified):'],
  ['@tests/test_ui_related_panel.py','timeout=30000'],
  ['@tests/test_unified_pipeline.py',"root = tmp_path_factory.mktemp('tmproot')"],
 ],
 'haiku/phase2-handoff-import-20261027':[
  ['@docs/specs/enrichment.md','When the supplied schema becomes available, reconcile it here first'],
  ['enrichment/contracts.py',"contract: Literal['enrichment/1']"],
  ['@docs/specs/REGISTRY.md','handoff-package validation'],
 ],
 'integration/kb-fixtures-pr69-20261030':[
  ['@tests/fixtures/kb/CONTRACT_CONFLICTS.md','The unknown-type CVRF test derives a type-99 case'],
  ['@tests/test_kb_fixture_properties.py','from kbc_k1_support import import_doc, no_sockets, projection'],
  ['@tests/test_kb_raw_adversarial_inputs.py','confusable_kb.json'],
 ],
}
(Q/'proof_selection.json').write_text(json.dumps(proofs,indent=2)+'\n')
