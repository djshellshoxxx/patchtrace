"""Replay unchanged reference-only tests with already-installed JSON Schema dependencies."""
from datetime import UTC, datetime
from pathlib import Path
import hashlib
import json
import os
import subprocess
import sys

Q = Path(__file__).parent.resolve()
R = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
PY = '/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python'
VENV_SITE = '/workspace/scratch/3a6632a6e5ff/venv/lib/python3.12/site-packages'
TARGET = Q/'historical-replay/phase2/tests/test_phase2_contract_examples.py'
LABEL='historical-phase2-with-runtime-dependency'
command=[PY,'-m','pytest','-q','-ra','-p','b7_replay',str(TARGET),'--junitxml='+str(Q/(LABEL+'.xml'))]
env={**os.environ,'PYTHONPATH':str(Q)+':'+VENV_SITE,'QT_QPA_PLATFORM':'offscreen'}
probe=[PY,'-c',"import importlib.metadata as m, jsonschema, pytest, referencing, rpds; import json; print(json.dumps({'versions':{k:m.version(k) for k in ['jsonschema','jsonschema-specifications','referencing','rpds-py','attrs','pytest']},'modules':{x.__name__:x.__file__ for x in [jsonschema,pytest,referencing,rpds]}}))"]
metadata={'started_utc':datetime.now(UTC).isoformat(),'cwd':str(R),'command':command,
          'environment':{k:env[k] for k in ('PYTHONPATH','QT_QPA_PLATFORM')},
          'dependency_probe':json.loads(subprocess.check_output(probe,cwd=R,env=env)),
          'original_test_sha256':hashlib.sha256(TARGET.read_bytes()).hexdigest(),
          'historical_source':'4522030ff3ff76d720a5efc33953aaa5e5837398',
          'comparison_source':'55f3d0742f7d4cf32357a42b8b1cc76d85875e71',
          'scope':'Reference document validation only. Existing primary-runtime jsonschema; existing venv pytest. No installation, production package execution or claim of contract compatibility. All schema refs internal and network blocked by replay plugin.',
          'retained_initial_failure':'historical-phase2.log: missing jsonschema in product-test venv, before any test ran.'}
with (Q/(LABEL+'.log')).open('x') as log:
    result=subprocess.run(command,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
metadata.update(exit_code=result.returncode,finished_utc=datetime.now(UTC).isoformat())
(Q/(LABEL+'.command.json')).write_text(json.dumps(metadata,indent=2)+'\n')
print('exit',result.returncode)
print((Q/(LABEL+'.log')).read_text()[-3500:])
