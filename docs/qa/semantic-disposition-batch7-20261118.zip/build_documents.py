"""Build the final bounded semantic checkpoint without relabeling its frozen baseline."""
from collections import Counter
from datetime import UTC,datetime
from functools import lru_cache
from pathlib import Path
import hashlib,json,re,subprocess,xml.etree.ElementTree as ET

R=Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4');Q=Path(__file__).parent
B='55f3d0742f7d4cf32357a42b8b1cc76d85875e71';PRIOR='27b4b4691b98b8671cbe0f973f1bf76e73542b1e'
P=R/'docs/plans/autonomous-consolidation-20261118'
def git(*a):return subprocess.check_output(['git',*a],cwd=R)
@lru_cache(None)
def blob(sha,path):return git('show',sha+':'+path)
def load(name):return json.loads((Q/name).read_text())
def append(path,text):path.write_text(blob(B,str(path.relative_to(R))).decode()+text)
assert git('rev-parse','HEAD').decode().strip()==B
assert not git('diff','--','src','tests','tools','.github')
snapshot=load('snapshot.json');decisions={r['branch']:r for r in load('dispositions.json')['branches']}
proofs={r['branch']:r['proofs'] for r in load('replacement-provenance.json')['branches']}
symbols={r['branch']:r['symbols'] for r in load('symbol-comparison.json')['branches']}
prior=json.loads(blob(PRIOR,'docs/plans/autonomous-consolidation-20261118/semantic-disposition-batch6.json'))
branches=[]
for raw in snapshot['branches']:
 name=raw['branch'];row={**raw,**decisions[name],'replacement_proofs':proofs[name],'symbols':symbols[name]}
 for key in ['current_paths','current_specs','current_tests']:
  assert all((R/p).is_file() for p in row[key]),(name,key)
 row['net_production_delta_paths']=[p for p in row['changed_paths'] if p.startswith(('src/','tools/'))]
 assert not row['net_production_delta_paths']
 row['whole_branch_closed']=False
 branches.append(row)
remaining=[r for r in prior['still_unselected_original_tips'] if r['branch'] not in decisions]
assert len(branches)==11 and not remaining and len({r['tip'] for r in branches})==11
assert all(r['tip_matches_inventory'] for r in branches)

def execution(label):
 root=ET.parse(Q/(label+'.xml')).getroot();cases=list(root.iter('testcase'))
 failures=sum(c.find('failure') is not None for c in cases);errors=sum(c.find('error') is not None for c in cases)
 xfails=sum(c.find('skipped') is not None and c.find('skipped').get('type')=='pytest.xfail' for c in cases)
 skips=sum(c.find('skipped') is not None for c in cases)-xfails
 times=re.findall(r'in (\d+\.\d+)s',(Q/(label+'.log')).read_text())
 return dict(source=B,passed=len(cases)-failures-errors-xfails-skips,failed=failures,errors=errors,
             expected_failures=xfails,skipped=skips,summary_seconds=float(times[-1]) if times else None,
             command='current-command.json' if label=='current-affected' else label+'.command.json',log=label+'.log',xml=label+'.xml')
labels=['current-affected','historical-audit','historical-deadline','historical-phase2','historical-phase2-with-runtime-dependency']
runs={label:execution(label) for label in labels}
runs['current-affected'].update(files=len(load('current-command.json')['test_files']),explicit_deselections=load('current-command.json')['explicit_deselections'])
runs['historical-phase2'].update(scope='Initial collection incident, no reference tests executed: product-test venv lacks jsonschema.')
runs['historical-phase2-with-runtime-dependency'].update(scope='Reference-only validation with installed primary-runtime jsonschema and existing venv pytest; no product package execution.',warning='One installed anyio plugin deprecation warning retained.')
fail_map={
 'test_remote_actions_are_immutable':('open_boundary_CODEX1','Mutable action references remain at the exact frozen source; the release action alone is pinned.'),
 'test_pip_downloads_require_hashes':('open_boundary_CODEX5','Workflow dependency installs lack complete hash locking; version constraints alone do not satisfy this audit.'),
 'test_corpus_cache_does_not_skip_verification':('open_boundary_CODEX6','Extracted cache hits skip archive verification before engines are used by corpus shards.'),
 'test_linux_package_runs_full_cli_smoke':('open_boundary_CODEX14','Linux builder/smoke omit the full frozen top-level CLI loader check.'),
 'test_full_bundle_pin_has_no_other_gpl_components':('historical_policy_mismatch_CODEX15','The old blanket rejection conflicts with the current explicit owner-approved component/SPDX allowlist and enforced Ghidra GPL-directory stripping. Do not port the old rejection.'),
}
history=[]
for label in labels[1:]:
 for case in ET.parse(Q/(label+'.xml')).getroot().iter('testcase'):
  fail,error=case.find('failure'),case.find('error');state='failed' if fail is not None else 'error' if error is not None else 'passed'
  name=case.get('name')
  if state=='failed':classification,meaning=fail_map[name]
  elif state=='error':classification,meaning='environment_collection_error','Initial reference suite could not import jsonschema. No original assertion ran. A separate invocation uses already-installed runtime dependencies without changing the original files.'
  elif label=='historical-phase2-with-runtime-dependency':classification,meaning='reference_document_conformance','Original schema/example/provenance assertion passes; not current runtime semantic compatibility.'
  else:classification,meaning='retained_original_control','Unchanged original authored control passes against the frozen comparison source; not whole-branch acceptance.'
  history.append(dict(invocation=label,node=case.get('classname')+'::'+name,outcome=state,classification=classification,meaning=meaning,
                      message=(fail if fail is not None else error).get('message') if state!='passed' else None))
assert len(history)==50 and sum(r['outcome']=='error' for r in history)==1
(Q/'historical-result-disposition.json').write_text(json.dumps({'source':B,'original_executed_test_outcomes':49,'initial_collection_incidents':1,'observations':history},indent=2)+'\n')

# Previous exact55 observations are references, not duplicate runs or additive totals.
refs=[]
for batch,commit,digest in [(5,'82d4ea017cd936b793dd8adfd50343a05df5629a','e6b63e2b7f39b85bb18790761fe8ff8ce11f65fdc82626590bf2c67cc1f02b16'),(6,PRIOR,'1216cd4ab10e13ed8b228146019807e83056767d813c4e19a252f98282af06a0')]:
 folder=Q.parent/f'semantic-disposition-batch{batch}';d=json.loads((folder/'ledger.json').read_text());assert d['comparison_source']==B
 refs.append(dict(batch=batch,checkpoint=commit,comparison_source=B,archive_sha256=digest,current_gate=d['executions']['current-affected'],command_sha256=hashlib.sha256((folder/'current-command.json').read_bytes()).hexdigest(),meaning='Prior same-source observation for specifically inherited KB/packaging/mutation scopes; not newly run or additive.'))
(Q/'prior-evidence-references.json').write_text(json.dumps(refs,indent=2)+'\n')

current_paths={'AGENTS.md','docs/modules.md','tests/fake_exe.py'}
for row in branches:
 current_paths.update(row['current_paths']+row['current_specs']+row['current_tests'])
 current_paths.update(p['path'] for p in row['replacement_proofs'])
 current_paths.update(p['path'] for p in row['source_projection'] if p['base_blob'] is not None)
current_paths.update(load('current-command.json')['test_files'])
current_paths.update(row['path'] for row in load('phase2-contract-surfaces.json')['current_enrichment'].values())
# Retain all static-audit source inputs, including workflows beyond the four focal calls.
current_paths.update(git('ls-tree','-r','--name-only',B,'--','.github/workflows','tools/pyinstaller_hooks').decode().splitlines())
current_paths.update(['tools/build_windows.py','docs/notices.md','src/patchtrace/cli_commands/__init__.py'])
current_manifest=[]
for path in sorted(current_paths):
 data=blob(B,path);target=Q/'current-source'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 current_manifest.append(dict(path=path,source=B,blob=git('rev-parse',B+':'+path).decode().strip(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(Q/'current-source-manifest.json').write_text(json.dumps(current_manifest,indent=2)+'\n')
historical_manifest=[]
for row in branches:
 for path in sorted({p['path'] for p in row['source_projection'] if p['tip_blob'] is not None}):
  data=blob(row['tip'],path);rel='historical-source/'+row['branch'].replace('/','__')+'/'+path
  target=Q/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  historical_manifest.append(dict(branch=row['branch'],tip=row['tip'],path=path,retained=rel,blob=git('rev-parse',row['tip']+':'+path).decode().strip(),bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
(Q/'historical-source-manifest.json').write_text(json.dumps(historical_manifest,indent=2)+'\n')
union=load('original-131-union.json')
assert union['selected']==131 and union['unselected']==0
ledger=dict(schema='patchtrace-semantic-disposition/1',batch=7,prepared_at_utc=datetime.now(UTC).isoformat(),
 comparison_source=B,comparison_tree=snapshot['comparison_tree'],
 comparison_identity='Actual PR316 source frozen at assignment. Later published/integration changes remain separately attributed; the read-only c7d3f comparison does not relabel any run.',
 inventory_observed_at=snapshot['inventory_observed_at'],inventory_source_sha256=snapshot['inventory_source_sha256'],remote_refresh=snapshot['remote_refresh'],
 previous_batches=prior['previous_batches']+[dict(batch=6,checkpoint=PRIOR,selected=20,comparison=B)],
 selection_denominator=dict(original_needs_reconciliation_tips=131,previously_selected=120,selected_this_batch=11,source_bearing_this_batch=0,workflow_test_or_docs_only_this_batch=11,cumulatively_selected=131,still_unselected=0,meaning='Original branch-name focal accounting only. Distinct features, whole branches, overall product acceptance and all307 original remote branches are different denominators.'),
 classification_counts=dict(Counter(r['classification'] for r in branches)),new_confirmed_product_defects=[],
 carried_forward_open_boundaries=['CODEX1 action immutability','CODEX5 reproducible dependency hashes','CODEX6 restored engine cache verification','CODEX14 Linux full frozen CLI smoke'],
 unretained_proposals=['CI xdist/cache/fresh-interpreter memory test strategy','Phase2 reference package and explicit current-contract reconciliation'],
 decision_criteria=['Exact patch/file/symbol/parent evidence precedes disposition.','Nonancestral commit count is not a net source delta or missing behavior.','Every executed historical failure/error is retained and classified.','Reference documents and synthetic controls never count as native/runtime acceptance.','No whole-branch closure or product completion percentage.'],
 executions=runs,prior_same_source_evidence=refs,historical_result_disposition='historical-result-disposition.json',
 overlap=load('overlap.json'),original_131_union=union,later_source_comparison=load('later-candidate-boundary-comparison.json'),
 source_manifest_count=len(current_manifest),historical_source_manifest_count=len(historical_manifest),branches=branches,still_unselected_original_tips=remaining,
 broad_residue='Earlier broad consolidation/research/native scopes remain open beyond the named focal behavior; approved repairs, reference reconciliation, current hosted/platform/desktop acceptance and final root integration remain distinct.')
(Q/'ledger.json').write_text(json.dumps(ledger,indent=2)+'\n');P.mkdir(parents=True,exist_ok=True)
(P/'semantic-disposition-batch7.json').write_text(json.dumps(ledger,indent=2)+'\n')

lines=['# Semantic branch disposition, final batch seven','',f'Frozen comparison: **`{B}`**, tree `{snapshot["comparison_tree"]}`. Later PR316 and continuation changes are separate evidence.','',
 '**All 131 original reconciliation branch names now have bounded focal dispositions.** This final batch contributes11 workflow, fixture, test or documentation tips with zero net src/tools change. Every tip is checked against the original inventory; the only exact-tip alias spans two already-recorded branch names. This is not131 distinct features, whole-branch closure, a product completion percentage or a claim about all307 original remote branches.','',
 '[Machine-readable ledger](semantic-disposition-batch7.json) · [Exact-source QA and archive](../../qa/semantic-disposition-batch7-20261118.md).','',
 '## Material findings','',
 'Four existing audit boundaries remain open at frozen55: immutable references for all remote actions, complete dependency artifact hash locking, validation of restored extracted engine caches, and full Linux frozen CLI smoke. The specific release-action pin and tag-derived naming are retained. Original CODEX15 blanket license rejection conflicts with the later explicit enforced owner-approved component policy and must not be restored.','',
 'The immutable Phase2 reference package is absent from current source. Its23 original reference tests pass, but current enrichment/1 explicitly leaves supplied-schema reconciliation open. Importing a schema package cannot establish runtime semantic compatibility. The unretained xdist/cache/fresh-interpreter memory proposal is a separate test-strategy experiment, not a confirmed product defect.','',
 '## Qualification','',
 'The fresh11-file focal gate passed100 cases in8.64seconds, with four known strict xfails and one explicit real-launcher deselection. It exercises static workflow/build assertions, authored PE parsing, injected acquisition transport, real authored Python child timeout/cancellation, private test paths and offscreen GUI own-load/stale-load behavior. It uses normal system temp; no compiler, native engine, target, network, frozen package or manual acceptance ran.','',
 'Original audit controls replayed unchanged with --runxfail:19 passed,5 failed. Four failures reproduce the known open boundaries; the fifth is the historical license-policy mismatch. Original deadline controls passed2. The Phase2 original suite first stopped collection because the product-test venv lacked jsonschema; that error is retained. A separate reference-only invocation using already-installed runtime dependencies passed23 checks, with one installed-plugin deprecation warning. The49 executed original outcomes and initial collection incident are individually classified.','',
 'Sealed prior same55 batch5/6 evidence is reused only for named inherited scopes, never rerun or added to these totals. The batch5 COFF erratum remains explicit: the reproduced helper is an optional developer API; the factory calls apply_case without extra_check.','',
 '## Exact tips and focal scope','', '| Branch | Exact tip | Focus |','|---|---|---|']
for row in branches:lines.append(f'| `{row["branch"]}` | `{row["tip"]}` | {row["focus"]} |')
lines+=['','## Per-tip dispositions','']
for n,row in enumerate(branches,1):
 lines += [f'### {n}. `{row["branch"]}`','',f'**{row["classification"].replace("_"," ")}.**','',
           '**Historical delta:** '+row['historical_behavior'],'','**Current behavior:** '+row['current_behavior'],'',
           '**Actual caller evidence:** '+row['caller_evidence'],'',
           'Current paths: '+', '.join('`'+p+'`' for p in row['current_paths'])+'.','',
           'Contract: '+', '.join('`'+p+'`' for p in row['current_specs'])+'.','',
           'Controls: '+(', '.join('`'+p+'`' for p in row['current_tests']) if row['current_tests'] else 'documentation comparison only')+'.','',
           'Qualification: '+'; '.join(row['verification'])+'.','',
           '**Selective decision:** '+row['recommendation'],'','**Residual scope:** '+row['residue'],'']
lines+=['## Original denominator and remaining obligations','',
 'The machine-readable original-131 union reads all six prior committed inventories plus this batch, checks each original branch name exactly once and verifies its exact original tip. The partition is20+20+20+20+20+20+11. There are zero unselected original focal tips. The access-test aliases share726a371a; both branch names remain in the denominator without pretending they are distinct functions.','',
 'Broader inherited checkpoint/research/analyst/acquisition scope remains open where earlier ledgers said so. No branch or PR is closed, merged or deleted by these records. Native Windows/engines, live sources, actual packages, current hosted workflows and manual journeys require their own evidence. Root independent review and selective integration remain necessary.','',
 'The read-only continuation comparison is pinned separately at c7d3f258: qa-windows.yml, corpus-tier-r.yml, build_linux.py and frozen_smoke.py match frozen55 bytes. That observation routes the next approved repair investigation; it is not a current-candidate test run, release result or replacement of the comparison baseline.','']
md='\n'.join(lines).replace('Phase2','Phase 2').replace('CODEX15','CODEX-15')
for a,b in [('contributes11','contributes 11'),('not131','not 131'),('all307','all 307'),('frozen55','frozen 55f3'),('Its23','Its 23'),('fresh11','fresh 11'),('passed100','passed 100'),('in8.64seconds','in 8.64 seconds'),('runxfail:19','runxfail: 19'),('passed,5','passed, 5'),('passed2','passed 2'),('passed23','passed 23'),('The49','The 49'),('same55','same 55f3'),('is20+20+20+20+20+20+11','is 20+20+20+20+20+20+11'),('share726','share 726')]:md=md.replace(a,b)
(Q/'ledger.md').write_text(md);(P/'semantic-disposition-batch7.md').write_text(md)
summary='''
## Semantic disposition batch7 — final original focal partition

The final 11 original tips have bounded workflow/test/documentation dispositions
against actual PR316 source55f3. All 131 original reconciliation branch names now
have one focal record; zero remain unselected. Exact original tips and the known
alias are checked. This is not whole-branch closure or a product percentage.

The fresh gate passed100 cases, with four known CODEX xfails and one explicit
real-launcher deselection. Original audit19 pass/5 classified failures, deadline2
pass, Phase2 reference23 pass, and its initial missing-dependency collection error
are preserved. CODEX1/5/6/14 remain open; the old license-policy assertion is
superseded by explicit enforced current policy. The unretained reference package
needs contract reconciliation, and xdist/memory-isolation proposals remain
unqualified. Broad research/native/platform/hosted/manual residue remains open.
See [batch7](autonomous-consolidation-20261118/semantic-disposition-batch7.md).
'''
for a,b in [('source55f3','source 55f3'),('passed100','passed 100'),('audit19','audit 19'),('deadline2','deadline 2'),('reference23','reference 23')]:summary=summary.replace(a,b)
append(R/'docs/plans/patchtrace-completion-matrix.md',summary)
append(P/'consolidation-ledger.md',summary.replace('(autonomous-consolidation-20261118/semantic-disposition-batch7.md)','(semantic-disposition-batch7.md)'))
append(R/'docs/qa.md','\n### Semantic disposition final batch7 (2026-11-18, frozen55f3)\n\nEleven focal records finish the exact original131 partition. Fresh100 passed /4 known xfails /1 explicit real-launcher deselection; original audit19 pass/5 classified failures, deadline2 pass, reference23 pass, initial missing-jsonschema collection error retained. No native/package/network/manual acceptance. See [receipt](qa/semantic-disposition-batch7-20261118.md).\n'.replace('frozen55f3','frozen 55f3').replace('original131','original 131').replace('Fresh100','Fresh 100').replace('/4','/ 4').replace('/1','/ 1').replace('audit19','audit 19').replace('deadline2','deadline 2').replace('reference23','reference 23'))
append(R/'tasks/todo.md','\n### Semantic disposition final batch7 (2026-11-18)\n\n- [x] Inspect the final 11 original focal scopes at frozen55; verify the exact 131-name/tip union without whole-branch closure.\n- [x] Retain current and every executed original historical outcome, dependency error and explicit policy mismatch.\n- [ ] Reproduce CODEX1/5/6/14 on the approved current candidate before narrowly reviewed repairs; map dependency lock coverage before installer changes.\n- [ ] Reconcile the unretained Phase2 reference package after still-reachable runtime/workflow defects; no silent contract reinterpretation.\n- [ ] Root independent review/selective docs integration; broad native/research/platform/hosted/manual obligations remain open.\n'.replace('frozen55','frozen 55f3'))
checks=dict(baseline=B,selected=11,previously_selected=120,cumulative=131,remaining=0,source_snapshots=len(current_manifest),historical_snapshots=len(historical_manifest),proofs=sum(len(v) for v in proofs.values()),executed_historical_outcomes=49,collection_incidents=1,current_paths_valid=True,product_delta=False,original_131_union_checked=True)
(Q/'document-validation.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(checks,indent=2))
