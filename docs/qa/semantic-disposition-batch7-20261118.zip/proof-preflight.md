# Draft/preflight and invocation chronology

The comparison source stayed at 55f3d0742f7d4cf32357a42b8b1cc76d85875e71 throughout.
No product, test, tool, workflow or existing evidence was changed.

- Initial file reads assumed the Phase 2 reference documents were in the current tree; the missing-file result prompted exact Git extraction from 4522030f. The missing reference package is recorded as an unresolved reconciliation obligation, not a missing runtime feature.
- The first original Phase 2 invocation failed collection because the product-test venv lacks jsonschema. Original log/XML/command are retained. The successful second invocation uses already-installed primary-runtime jsonschema plus existing venv pytest for reference-only checks, with network prohibited; no dependency was installed or product package executed. Its installed anyio plugin deprecation warning is retained.
- Original audit probes are byte-for-byte Git extractions. A small replay plugin changes only their read ROOT/WORKFLOWS to the exact comparison source, and --runxfail reveals all original assertions. It does not rewrite assertions, production code or observations. The five actual failures remain in the packet.
- A draft current parser path was corrected from nonexistent pe_version.py to the import actually used by the tests, pe_overview/version_info.py. All final narrative/proof/current snapshot paths are checked before sealing.
- An interim progress message estimated40 replacement proofs. The final generated manifest has exactly39 proofs; the final receipt and ledger use39.
- Current tests use normal system-temp fixtures. The known uninjected backend-pin network fixture, real compiler/native gates and long memory-stress experiment were not selected. One real-launcher read-only cross-check was explicitly deselected to keep this gate authored-only.
- Prior batch5/6 same-source receipts are references only. The batch5 original packet and separate caller erratum remain unchanged. Root's later candidate c7d3f comparison is explicitly source-only and separate from the frozen55 test observations.
