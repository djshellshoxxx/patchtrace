from pathlib import Path
from datetime import UTC,datetime
import hashlib,json,os,subprocess,sys
R=Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4'); Q=Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch7')
PY='/workspace/scratch/3a6632a6e5ff/venv/bin/python'
label,*targets=sys.argv[1:]
cmd=[PY,'-m','pytest','-q','-ra','-p','b7_replay',*targets,'--junitxml='+str(Q/(label+'.xml'))]
env={**os.environ,'PYTHONPATH':str(Q)+':'+str(R/'src')+':'+str(R/'tests'),'QT_QPA_PLATFORM':'offscreen'}
meta={'started_utc':datetime.now(UTC).isoformat(),'cwd':str(R),'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'source_tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=R,text=True).strip(),'working_diff_sha256':hashlib.sha256(subprocess.check_output(['git','diff','--','src','tests','tools'],cwd=R)).hexdigest(),'command':cmd,'environment':{k:env[k] for k in ('PYTHONPATH','QT_QPA_PLATFORM')},'test_files':[],'scope':'Offline authored controls; normal system-temp pytest fixtures. No target/native engine/acquisition invocation.'}
for target in targets:
 if target.startswith('-'):continue
 p=Path(target.split('::')[0]);p=p if p.is_absolute() else R/p
 meta['test_files'].append({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
assert not (Q/(label+'.log')).exists()
with (Q/(label+'.log')).open('x') as f:result=subprocess.run(cmd,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
meta.update(returncode=result.returncode,finished_utc=datetime.now(UTC).isoformat())
(Q/(label+'.command.json')).write_text(json.dumps(meta,indent=2)+'\n')
print(label,result.returncode)
print('\n'.join((Q/(label+'.log')).read_text().splitlines()[-30:]))
