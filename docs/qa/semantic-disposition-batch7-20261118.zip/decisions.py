"""Reviewed focal decisions; no branch-name or test-count completion inference."""
from pathlib import Path
import json
Q=Path(__file__).parent
rows=[]
def add(branch, focus, classification, historical_behavior, current_behavior, caller_evidence,
        current_paths, current_specs, current_tests, verification, recommendation, residue):
    rows.append(dict(branch=branch,focus=focus,classification=classification,
                     historical_behavior=historical_behavior,current_behavior=current_behavior,
                     caller_evidence=caller_evidence,current_paths=current_paths,current_specs=current_specs,
                     current_tests=current_tests,verification=verification,recommendation=recommendation,residue=residue))

add('chatgpt/merge-first-handoff-20261016','Historical integration handoff and supersession notes','retained_historical_documentation',
    'Five documentation commits add the October 16 coordination record and link it from the alpha handoff. The final note explicitly closes its own proposed PR92 COFF patch as superseded, records the redundant unreachable sort branch, and distinguishes old hosted jobs from approval.',
    'Both changed documents are byte-identical at frozen55. Current mutation/sort work was separately inspected in batches5/6; this handoff contributes no new production delta. The batch5 caller erratum remains controlling: make_masked_body_check is an exported optional developer API, and the normal factory calls apply_case without extra_check.',
    'These are retained coordination documents with no runtime caller. Their old GitHub job IDs, reviews, statuses and merge sequence are historical observations, not current instructions to publish or reopen branches.',
    ['docs/plans/chatgpt-merge-first-handoff-20261016.md','docs/plans/claude-autonomous-alpha-handoff-20261013.md'],
    ['docs/specs/verification.md'],[],
    ['Exact changed-file blobs and five-commit history retained; no new executable control is implied by a documentation comparison'],
    'Keep the existing audit trail; do not port the closed historical COFF implementation or redundant sorting block.',
    'The old handoff is not a current CI certificate. Later COFF/A/A repairs and native Windows acceptance are separately attributed; no wholesale historical branch closure.')

add('claude/clever-clarke-s4nhi6','QA job execution budget','retained_with_later_configuration',
    'The only change raises the qa-windows matrix job budget from30 to60 minutes.',
    'The frozen55 QA matrix declares120 minutes and retains full source QA, Ruff, Qt qualification, packaging and artifact steps. The old60-minute value is superseded by the actual current configuration, without a claim about hosted duration.',
    'GitHub Actions reads the qa job timeout. The source-only test_every_job_has_timeout checks all workflow jobs; it does not execute Actions or demonstrate that any job finishes within the budget.',
    ['.github/workflows/qa-windows.yml'],['docs/specs/windows-acceptance-and-milestone-builds.md'],
    ['tests/test_codex_pkg_workflows.py'],['Current static job-budget control passes in the bounded100-pass gate; exact YAML and replacement history retained'],
    'No selective port of the obsolete60-minute scalar.',
    'Hosted Linux/Windows completion, timeout adequacy and artifact acceptance remain unmeasured by this batch.')

add('claude/fix-deadline-test','Floating-point tolerance in remaining-time assertion','retained_exact_test',
    'One test changes the30-second upper assertion to30.0+1e-6 for floating subtraction at large monotonic readings. Production deadlines and resource limits are untouched.',
    'The complete decompile-runner test file is byte-identical to the historical tip. _bounded_timeout still rejects exhausted remaining time and takes min(configured seconds, remaining).',
    'runner.decompile_side calls _bounded_timeout before run_process; the inspected test injects spy_runner, records the passed timeout and cleans its owned staging path. Separate current authored hung-child and expired-budget controls exercise supervision/refusal.',
    ['src/patchtrace/unified/extract/runner.py','src/patchtrace/unified/limits.py'],
    ['docs/specs/verification.md'],['tests/test_unified_decompile_runner.py','tests/fake_exe.py'],
    ['Two unchanged original deadline/expired controls pass; fake_exe helper is byte-identical; current selected deadline/hung-child/refusal neighbors pass'],
    'No port needed; preserve the tiny numerical tolerance and real process deadlines.',
    'Authored Python child evidence is not native Ghidra decompilation or a Windows timing claim.')

add('claude/patchtrace-haiku-agent-motpbx','Pinned release action and tag-derived release naming','retained_release_configuration',
    'The final net patch pins softprops/action-gh-release to3bb12739c298aeb8a4eeaf626c5b8d85266b0e65, names pushed tags from github.ref_name, keeps automatic main beta names, and adds two static regressions. Its nonancestral history includes seven source commits.',
    'Both release behaviors and regression bodies remain at frozen55. All src/tools directory trees at this tip equal its merge base exactly, despite the seven distinct source-commit identities; those commits do not establish new net production work. Net changed files are workflow/spec/tests only.',
    'The release job consumes tag_name/name and runs the pinned action under the existing release/QA conditions. Static tests read the actual release block; no release invocation or upstream version lookup is performed.',
    ['.github/workflows/qa-windows.yml','tools/release_gate.py'],
    ['docs/specs/windows-acceptance-and-milestone-builds.md','docs/specs/windows-release-signing-policy.md'],
    ['tests/test_release_gate.py'],
    ['Both selected current release-regression nodes pass; parent-aware pin/naming provenance and all seven historical source-commit paths are retained'],
    'No feature port. Keep the specific release-action pin and correct tag label; audit-wide action immutability remains a separate openCODEX1 boundary.',
    'This does not attest every action pin, upstream integrity, signer enrollment, native Windows package quality or current hosted release acceptance.')

add('claude/ws-a2-ci-speed-20261104','Fixture isolation plus unretained CI parallelism experiment','partial_retention_with_deferred_test_strategy',
    'Adds shallow checkout/pip caching, pytest-xdist loadfile execution with a runner-temp base, a fresh-interpreter repeated-open memory probe, private temp roots, asynchronous child-reap observation, and waits for the controller own load. The memory limit and cycle count are preserved.',
    'Private symbol/unified temp fixtures, bounded child-state polling,30-second GUI settle waits and own-load completion controls are retained. Current jobs polling additionally handles a disappearing proc entry atomically. Current QA runs plain pytest without xdist/cache changes, dev dependencies omit xdist, and the memory growth test remains in-process. Those CI/memory-isolation proposals are genuinely unretained, not silently classified equivalent.',
    'The fixture changes affect authored tests, not product process supervision. The retained reload helper waits for a changed controller model and an idle load channel before interactions. GitHub workflow runs plain pytest; no worker-speed or fresh-interpreter memory measurement was performed here.',
    ['.github/workflows/qa-windows.yml','pyproject.toml','tests/stress/test_cli_stress_perf.py'],
    ['docs/specs/verification.md'],
    ['tests/test_backend_symbol_local.py','tests/test_jobs.py','tests/test_ui_related_panel.py','tests/test_ui_unified.py','tests/test_unified_pipeline.py'],
    ['Current authored local-symbol, child termination, private cwd/cleanup, own-reload and stale-load controls pass; exact per-symbol/file comparisons retained; long memory stress not run'],
    'Keep retained fixture guards. Treat xdist/cache and subprocess memory isolation as separate test-strategy proposals requiring measured benefit and cross-platform qualification, not a mandatory product port.',
    'The proposed concurrency configuration and memory-isolation harness remain unqualified. No300-second stress run, hosted speedup, native target or Windows acceptance claim.')

add('codex/audit-2','Historical workflow/packaging audit and remaining explicit gaps','retained_audit_with_open_boundaries',
    'Adds two audit reports and24 hermetic static controls for15 historical finding IDs; no production patch. The original reports clearly distinguish source facts, configured build policy and unavailable artifact evidence.',
    'Both reports are byte-identical. Current tests retain passing repairs and four strict expected failures:CODEX1 mutable action references,5 unhashed dependency installs,6 restored engine cache verification,14 missing full Linux frozen CLI smoke. The oldCODEX15 assertion forbids all extra GPL components; current policy explicitly permits the owner-approved Temurin match and refuses unapproved shipped Ghidra GPL content, so that old assertion is not the current policy.',
    'Actual callers are workflow uses/pip steps; corpus-tier-r cache-hit guards bypass archive verification before RZ_DIFF/GHIDRA_INSTALL_DIR feed run-shard; build_linux invokes only frozen --self-test and rank --help, then linux-smoke invokes two Qt self-test modes. check_backend_pin enforces explicit component/SPDX policy and stripping. No installer, cached engine, compiler or frozen payload was executed.',
    ['.github/workflows/qa-windows.yml','.github/workflows/corpus-tier-r.yml','tools/build_linux.py','tools/frozen_smoke.py','tools/check_backend_pin.py','tools/backend_pin.json','tools/release_gate.py','docs/audits/codex-workflows-1.md','docs/audits/codex-packaging-1.md'],
    ['docs/specs/program-e/BUNDLE-integration-plan.md','docs/specs/windows-acceptance-and-milestone-builds.md','docs/specs/verification.md'],
    ['tests/test_codex_pkg_workflows.py','tests/test_codex_pkg_packaging.py'],
    ['Unchanged original24 controls with --runxfail:19 pass,5 fail; every failure classified; current audit checks pass except the four recorded strict xfails','Later c7d3f read-only comparison finds qa-windows/corpus-tier-r/build_linux/frozen_smoke byte-identical; this is separate source evidence, not a rerun or relabeling'],
    'Preserve the historical audit and original probes. Reproduce the four still-reachable boundaries on the exact next candidate before scoped repairs; map reproducible locks forCODEX5. Do not port the obsolete license-policy rejection.',
    'Action/dependency/cache supply-chain gates and Linux frozen command loading remain open at frozen55. Source-level passing probes do not certify downloaded bytes, notices, binary closure, signing or native runtime behavior.')

add('codex/parser-test-cpu-budget-20261104','CPU work budget distinct from wall-clock parser scheduling','retained_exact_parser_test_contract',
    'Inherits the five test-stability files, then changes hostile PE version parser timing from perf_counter to process_time at the same0.25-second and fourfold mutated-input bounds. Adds the corresponding verification contract and historical QA notes.',
    'The parser test file and amended verification spec are byte-identical to the tip. Structural malformed-input assertions, parse caps and real elapsed subprocess deadlines remain. The inherited five fixture files equal the dedicated stability tip before later current fixture improvements.',
    'Tests call the actual resource/version parser on authored PE bytes, using process_time around its work. This excludes descheduling and fixture I/O pauses and is not the desktop latency or process supervision metric.',
    ['src/patchtrace/pe_overview/version_info.py','tests/test_pe_version_info.py'],
    ['docs/specs/verification.md'],['tests/test_pe_version_info.py'],
    ['Current authored PE version suite passes in the shared gate; one real distlib-launcher read-only case explicitly deselected to keep this gate authored-only; old302-pass report remains historical, not rerun'],
    'No selective source/test port; keep CPU and real elapsed contracts distinct.',
    'No recreated300ms scheduling experiment, real-launcher cross-check, platform performance acceptance or native parser isolation claim.')

add('consolidate/kb-fixtures-20261104','Corrected KB fixture imports and byte-preserving attributes','retained_corrected_fixtures',
    'Combines the KB fixture corpus with registered no-network fixtures, valid unknown-remediation/confusable cases, real BOM rejection/CRLF import checks, valid Unicode surrogate-pair acceptance and a longer GUI settling wait. Adds LF attributes with intentional raw-fixture exceptions.',
    'The complete corrected KB fixture/helper/test projection and hostile acquisition test equal frozen55 byte for byte. Current .gitattributes retains LF plus -text/-whitespace for intentional CRLF and -text for BOM. The unified fixture retains the longer wait and later asynchronous observation fixes.',
    'KB controls invoke import_bytes/strict index adapters on authored bytes. The transport progress-error test supplies an explicit Response/opener; it does not use the network. Encoding tests exercise both importer outcomes, not only file prefixes.',
    ['.gitattributes','src/patchtrace/kbcorrelation/sources/importer.py','src/patchtrace/kbcorrelation/sources/cvrf.py','src/patchtrace/acquisition/transport.py'],
    ['tests/fixtures/kb/CONTRACT_CONFLICTS.md','tests/fixtures/kb/README.md','docs/specs/program-e/KB-integration-plan.md'],
    ['tests/test_acquisition_hostile_20261029.py','tests/test_kb_fixture_encoding.py','tests/test_kb_cvrf_fixture_import.py','tests/test_kb_fixture_properties.py','tests/test_kb_raw_adversarial_inputs.py'],
    ['Current authored hostile acquisition controls pass; exact corrected projection proven; prior sealed batch6 same55 KB import gate reused explicitly, not rerun or additive'],
    'Retain current corrected fixtures; no reimport of malformed original assertions or normalization of intentional BOM/CRLF bytes.',
    'Synthetic corpus labels and helper crash points do not establish native MSU/CAB acquisition, live vendor compatibility or product-wide crash recovery.')

add('consolidate/test-stability-20261104','Private test roots and deterministic asynchronous completion','retained_test_stability',
    'Changes only five test files: isolate symbol/unified scratch checks; wait for real child death and GUI load completion; use30-second settling waits rather than scheduler-sensitive5-second waits. No CI-xdist or repeated-open-memory change is in this branch.',
    'Current keeps private roots and own-model/idle-channel reload waiting. Child-state polling also handles disappearance between read attempts, and explanation/clipboard controls await their asynchronous callbacks. The product source net delta of this branch is zero.',
    'Private temp fixtures confine before/after listings to the test owner. GUI helpers distinguish the host initial load from the explicit reload; real authored child controls check cancellation/timeout and permit a reaped or zombie child state. Wait allowances are not relaxed product timing thresholds.',
    ['tests/test_backend_symbol_local.py','tests/test_jobs.py','tests/test_ui_related_panel.py','tests/test_ui_unified.py','tests/test_unified_pipeline.py'],
    ['docs/specs/verification.md'],
    ['tests/test_backend_symbol_local.py','tests/test_jobs.py','tests/test_ui_related_panel.py','tests/test_ui_unified.py','tests/test_unified_pipeline.py'],
    ['Selected current own-load/stale-load, cancellation, private-temp and cleanup controls pass under normal system temp; source/AST comparisons retained'],
    'No port needed. Preserve the strengthened current asynchronous observations.',
    'This bounded offscreen run is not desktop manual acceptance, cross-platform teardown certification or a native engine timing benchmark.')

add('haiku/phase2-handoff-import-20261027','Unretained provenance-pinned Phase2 reference schema package','unretained_reference_reconciliation',
    'Imports unchanged extension specification, draft2020-12 schema and synthetic examples with provenance hashes, JSON Schema-only tests, LF attributes and a jsonschema dev extra. The provenance itself says runtime semantic validation is outside the import.',
    'All four reference documents and test file are absent at frozen55. Current enrichment/1 contracts and generated per-record schemas remain implemented under a spec that explicitly calls for later supplied-schema reconciliation. No field or runtime equivalence is inferred from similar names; the package has no net src/tools implementation.',
    'The historical test imports jsonschema and reads only its own retained reference files. All20 schema references are local fragments. Current runtime uses strict frozen Pydantic enrichment/1 records with separate identity/ownership validators, not these proposed schema_version=1 documents.',
    ['src/patchtrace/enrichment/contracts.py','src/patchtrace/enrichment/identity.py','docs/schemas/enrichment/SourceLocation.json','docs/schemas/enrichment/ChangeSignal.json','docs/schemas/enrichment/RankingConfig.json','docs/schemas/enrichment/CacheManifest.json','docs/schemas/enrichment/PipelineStatus.json'],
    ['docs/specs/enrichment.md','docs/specs/completeness-audit.md','docs/specs/REGISTRY.md'],
    ['tests/test_enrichment_core.py'],
    ['Original23 reference checks pass with existing runtime jsonschema and venv pytest; initial missing-jsonschema collection error and one dependency deprecation warning retained; all raw reference hashes verified','Current enrichment controls inspected as separate runtime boundary, not executed or claimed equivalent in this batch'],
    'Retain the original reference package as immutable evidence. After still-reachable runtime/CI repairs, reconcile it explicitly with current contracts; any incompatible runtime evolution needs a new contract version and migration plan, not a wholesale historical import.',
    'Reference validation is not feature implementation, semantic score/identity validation, CVE evidence authenticity or supplied-schema runtime acceptance. Reconciliation remains a real documented gap.')

add('integration/kb-fixtures-pr69-20261030','Original KB corpus plus historical PR/wiki checkpoint','retained_fixture_scope_with_historical_doc_residue',
    'Combines original KB fixture branch#69 with October30 branch/PR gates and wiki documentation. The original suite includes unregistered no_sockets fixture uses, empty-CVE/type-shape mismatches and encoding-prefix-only checks.',
    'The entire historical KB fixture projection equals the separately inspected781b36fb tip. Later corrected820d7074 projection is retained exactly at frozen55. Current encoding tests actually reject BOM and import CRLF, the no_sockets fixture is registered, type99 derives from a valid record, and confusable IDs have their own fixture. Missing old wiki/PR-gate pages remain preserved in this packet as historical documents rather than invented current acceptance.',
    'The fixture helpers use authored synthetic advisories and their own crash hooks. The old PR gate pages report exact October30 heads and explicitly require refresh before merging; neither those pages nor fixture scenario labels exercise a current hosted/production recovery path.',
    ['src/patchtrace/kbcorrelation/sources/importer.py','tests/kb_crash_harness.py','tests/test_kb_fixture_encoding.py','tests/test_kb_synthetic_fixture_corpus.py'],
    ['tests/fixtures/kb/CONTRACT_CONFLICTS.md','tests/fixtures/kb/README.md','docs/specs/program-e/KB-integration-plan.md'],
    ['tests/test_kb_crash_injection_protocol.py','tests/test_kb_cvrf_fixture_import.py','tests/test_kb_fixture_encoding.py','tests/test_kb_fixture_properties.py','tests/test_kb_synthetic_fixture_corpus.py'],
    ['Exact original-to781 and corrected820-to55 projections proven; previous same-source batch6 KB observations reused; missing/renamed old test AST symbols are explained by actual stronger replacements'],
    'Keep corrected current fixtures; preserve obsolete PR/wiki documents as history, not as a new implementation port or current check status.',
    'The old wiki/PR snapshot has broader historical documentation residue and is not automatically closed. Actual MSU/CAB extraction, native platform and full crash/recovery qualification remain separate.')

for row in rows:
 for key in ['historical_behavior','current_behavior','caller_evidence','recommendation','residue']:
  # Human-readable prose should keep counts and identifiers separated.
  for a,b in [('frozen55','frozen 55f3'),('from30','from 30'),('to60','to 60'),('declares120','declares 120'),('old60','old 60'),('obsolete60','obsolete 60'),('the30','the 30'),('to30','to 30'),('pin to3','pin to 3'),('action to3','action to 3'),('30-second','30-second'),('openCODEX','open CODEX'),('for15','for 15'),('and24','and 24'),('failures:CODEX','failures: CODEX'),('oldCODEX','old CODEX'),('forCODEX','for CODEX'),('same0.25','same 0.25'),('old302','old 302'),('recreated300','recreated 300'),('the300','the 300'),('No300','No 300'),('branch#','branch #'),('the separately inspected781','the separately inspected 781'),('corrected820','corrected 820'),('October30','October 30'),('draft2020','draft 2020'),('All20','All 20'),('Original23','Original 23'),('original24','original 24'),('19 pass,5','19 pass, 5')]:
   row[key]=row[key].replace(a,b)
def prose(text):
 for before,after in [('bounded100','bounded 100'),('Original23','Original 23'),('original24','original 24'),('CODEX1','CODEX-1'),('CODEX5','CODEX-5'),('CODEX6','CODEX-6'),('CODEX14','CODEX-14'),('CODEX15','CODEX-15'),('type99','type 99'),('Phase2','Phase 2'),('from30','from 30'),('than30','than 30'),('than5','than 5'),('own30','own 30'),('same0.25','same 0.25'),('and24','and 24'),('for15','for 15'),('original-to781','original-to-781'),('corrected820-to55','corrected-820-to-55'),('to3bb','to 3bb'),('23 reference','23 reference')]:
  text=text.replace(before,after)
 return text
for row in rows:
 for field in ['focus','historical_behavior','current_behavior','caller_evidence','recommendation','residue']:
  row[field]=prose(row[field])
 row['verification']=[prose(x) for x in row['verification']]
(Q/'dispositions.json').write_text(json.dumps({'branches':rows},indent=2)+'\n')
print('Wrote',len(rows),'scoped decisions')
