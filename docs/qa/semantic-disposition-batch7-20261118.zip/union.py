"""Original inventory denominator and exact per-branch/tip union across all seven focal batches."""
from pathlib import Path
from collections import Counter,defaultdict
import hashlib,json,subprocess
R=Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4');Q=Path(__file__).parent
B='55f3d0742f7d4cf32357a42b8b1cc76d85875e71'
commits={1:B,2:'1a07861f3d54dde6fce0bbd3c79fc772295c92ac',3:'aa90efbb8238d58817489377f05dc52af7f1e239',4:'4f71b811dbd1555ce5cb6cffe062dddc3bb801e5',5:'82d4ea017cd936b793dd8adfd50343a05df5629a',6:'27b4b4691b98b8671cbe0f973f1bf76e73542b1e'}
def blob(sha,p):return subprocess.check_output(['git','show',sha+':'+p],cwd=R)
invpath='docs/plans/autonomous-consolidation-20261118/branch-inventory.json'
invraw=blob(B,invpath);inventory=json.loads(invraw)
original={r['branch']:r['head_sha'] for r in inventory['branches'] if r['classification']=='needs_reconciliation'}
assert len(original)==131
rows=[];inputs=[]
for batch,sha in commits.items():
 p=f'docs/plans/autonomous-consolidation-20261118/semantic-disposition-batch{batch}.json'
 raw=blob(sha,p);data=json.loads(raw)
 inputs.append(dict(batch=batch,retrieved_from_commit=sha,path=p,sha256=hashlib.sha256(raw).hexdigest(),selected=len(data['branches'])))
 for r in data['branches']:
  rows.append(dict(batch=batch,branch=r['branch'],tip=r['tip'],classification=r.get('classification'),
                   focus=r.get('focus'),comparison_source=data.get('comparison_source',data.get('comparison_base')),
                   broader_scope_closed=False))
current=json.loads((Q/'snapshot.json').read_text());decisions={r['branch']:r for r in json.loads((Q/'dispositions.json').read_text())['branches']}
for r in current['branches']:
 d=decisions[r['branch']]
 rows.append(dict(batch=7,branch=r['branch'],tip=r['tip'],classification=d['classification'],focus=d['focus'],comparison_source=B,broader_scope_closed=False))
counts=Counter(r['branch'] for r in rows)
assert len(rows)==131 and set(counts)==set(original) and all(n==1 for n in counts.values())
assert all(r['tip']==original[r['branch']] for r in rows)
aliases=defaultdict(list)
for r in rows:aliases[r['tip']].append(r['branch'])
result=dict(inventory_source_commit=B,inventory_sha256=hashlib.sha256(invraw).hexdigest(),inventory_observed_at=inventory['observed_at_utc'],
            denominator=131,selected=131,unselected=0,branch_names_unique=True,every_tip_matches_original=True,
            batch_inputs=inputs,batch_counts=dict(Counter(r['batch'] for r in rows)),
            duplicate_tip_aliases={tip:names for tip,names in aliases.items() if len(names)>1},
            rows=rows,meaning='Exactly131 original branch names now have focal semantic records. This is not131 distinct features, whole-branch closure, release acceptance, all307 original remote branches completed, or a product completion percentage.',
            errata=[{'batch':5,'commit':'62338862b751eb863005ca557265e60d2a422a6f','meaning':'Original packet remains immutable. COFF probe is an optional developer API; factory has no extra_check caller.'}],
            broad_residue='Inherited consolidation/research/checkpoint scopes, unretained proposals, exact current-candidate repair review, platforms/native engines/acquisition, hosted gates and manual acceptance remain open.')
(Q/'original-131-union.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['denominator','selected','unselected','batch_counts','duplicate_tip_aliases']},indent=2))
