"""Read-only source/ancestry proofs for the selected semantic scopes, not equivalence by branch name."""
from concurrent.futures import ThreadPoolExecutor
from functools import lru_cache
from pathlib import Path
import ast
import hashlib
import json
import subprocess

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
OUT = Path('/workspace/scratch/c7a9e8d98848/qa/semantic-disposition-batch7')
SNAPSHOT = json.loads((OUT / 'snapshot.json').read_text())
BASE = SNAPSHOT['comparison_base']

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

@lru_cache(None)
def source(sha, path):
    result = subprocess.run(['git', 'show', sha + ':' + path], cwd=ROOT,
                            text=True, capture_output=True, check=False)
    return result.stdout if result.returncode == 0 else None

PROOFS = json.loads((OUT / 'proof_selection.json').read_text())

def proof(item):
    rel, needle = item
    path = rel[1:] if rel.startswith('@') else 'src/patchtrace/' + rel
    current = source(BASE, path)
    assert current is not None and needle in current, (path, needle)
    history = []
    commits = git('log', '--full-history', '-m', '--reverse', '--format=%H',
                  '-S' + needle, BASE, '--', path).splitlines()
    for sha in dict.fromkeys(commits):
        parents = git('rev-list', '--parents', '-n', '1', sha).split()[1:]
        value = source(sha, path)
        parent_value = source(parents[0], path) if parents else None
        history.append({
            'sha': sha, 'subject': git('show', '-s', '--format=%s', sha),
            'is_ancestor_of_comparison': subprocess.run(
                ['git', 'merge-base', '--is-ancestor', sha, BASE], cwd=ROOT, check=False).returncode == 0,
            'needle_present_in_commit': value is not None and needle in value,
            'needle_present_in_first_parent': parent_value is not None and needle in parent_value,
            'parent_presence': [{'sha': parent, 'needle_present': needle in (source(parent, path) or '')}
                                for parent in parents],
        })
    return {
        'path': path, 'needle': needle,
        'current_lines': [i for i, line in enumerate(current.splitlines(), 1) if needle in line],
        'current_blob': git('rev-parse', BASE + ':' + path),
        'current_sha256': hashlib.sha256(current.encode()).hexdigest(),
        'history': history,
    }

with ThreadPoolExecutor(max_workers=4) as pool:
    captured = dict(zip(PROOFS, pool.map(lambda items: list(map(proof, items)), PROOFS.values()), strict=True))

result = {'baseline': BASE, 'tree': SNAPSHOT['comparison_tree'],
          'meaning': 'Exact current source plus full merge history proves retained or changed implementation at ancestral commits; it does not establish whole-branch equivalence. Missing historical behavior is separately classified from source, caller and behavioral evidence.',
          'branches': [{'branch': name, 'proofs': items} for name, items in captured.items()]}
(OUT / 'replacement-provenance.json').write_text(json.dumps(result, indent=2) + '\n')
for name, items in captured.items():
    print(name, [(item['path'], [h['sha'][:10] for h in item['history'] if h['needle_present_in_commit']]) for item in items])
