"""Only route historical audit ROOT reads to exact current source; prohibit network."""
from pathlib import Path
import socket
import urllib.request

import pytest

ROOT = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')


def pytest_collection_modifyitems(items):
    for item in items:
        module = item.module
        if '/historical-replay/audit/' in str(item.path):
            module.ROOT = ROOT
            if hasattr(module, 'WORKFLOWS'):
                module.WORKFLOWS = ROOT / '.github/workflows'


@pytest.fixture(autouse=True)
def no_network(monkeypatch):
    def denied(*args, **kwargs):
        pytest.fail('Offline historical replay attempted network')
    monkeypatch.setattr(socket, 'socket', denied)
    monkeypatch.setattr(socket, 'create_connection', denied)
    monkeypatch.setattr(urllib.request, 'urlopen', denied)
