"""Independent minimal DTD-policy reproducer; all input is bounded authored text.

No target is executed. The resource-boundary control reads an authored PE fixture
through the existing metadata API. No external entity, file URL or network URL is
used; the only entity expands to a harmless fixed marker.
"""
from __future__ import annotations

import codecs

import pytest
from pe_rsrc_builder import LANG_EN_US, RT_MANIFEST, open_pe, rsrc_pe, tree

from patchtrace.pe_overview.manifest import observe_manifest
from patchtrace.pe_overview.metadata import inspect_metadata
from patchtrace.pe_overview.resources import ResourceLeaf

DTD = ('<!DOCTYPE assembly [<!ENTITY proof "AUTHORED_ENTITY_MARKER">]>'
       '<assembly xmlns="urn:schemas-microsoft-com:asm.v1">'
       '<assemblyIdentity name="&proof;"/></assembly>')
NORMAL = ('<assembly xmlns="urn:schemas-microsoft-com:asm.v1">'
          '<assemblyIdentity name="Authored.Normal"/></assembly>')


def observe(raw):
    leaf = ResourceLeaf(RT_MANIFEST, 'RT_MANIFEST', 1, LANG_EN_US, 0x2000, len(raw), 0, 0x400)
    return observe_manifest(leaf, raw)


@pytest.mark.parametrize('prefix', [' ', '\n', '\t'])
def test_utf16be_leading_whitespace_cannot_hide_a_doctype(prefix):
    raw = (prefix + DTD).encode('utf-16-be')
    assert len(raw) == 318
    result = observe(raw)
    assert result.identity is None
    assert 'manifest_dtd_rejected' in result.warnings


def test_actual_pe_metadata_boundary_rejects_the_same_hidden_doctype(tmp_path):
    raw = (' ' + DTD).encode('utf-16-be')
    data, _ = rsrc_pe(tree({RT_MANIFEST: {1: {LANG_EN_US: raw}}}))
    with open_pe(tmp_path, data) as pe:
        result = inspect_metadata(pe.reader, pe.overview)
    assert len(result.manifests) == 1
    assert result.manifests[0].identity is None
    assert 'manifest_dtd_rejected' in result.manifests[0].warnings


@pytest.mark.parametrize('encoding,bom', [('utf-8', b''), ('utf-16-le', codecs.BOM_UTF16_LE),
                                        ('utf-16-be', codecs.BOM_UTF16_BE)])
def test_normal_leading_whitespace_manifests_keep_their_identity(encoding, bom):
    result = observe(bom + (' \n\t' + NORMAL).encode(encoding))
    assert not result.warnings
    assert result.identity.name == 'Authored.Normal'
