"""Pin every imported PatchTrace module to the design commit; external QA only."""
from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

SOURCE_COMMIT = '27e4318b87e0af3be0fc11a1906b86d95c44f46b'
REPOSITORY = Path('/workspace/scratch/c7a9e8d98848/continuation-integration')
QA = Path(__file__).resolve().parent
SOURCE = REPOSITORY / 'src'
sys.path.insert(0, str(SOURCE))
os.environ['PYTHONPATH'] = str(SOURCE)
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
os.environ['PATCHTRACE_PW02_REVIEW_SOURCE'] = str(SOURCE)
os.environ['PATCHTRACE_PW02_REVIEW_OUTPUT'] = str(QA / 'existing-observations-v2')

import pytest


def main():
    arguments = ['-q', '-p', 'no:cacheprovider', '--confcutdir', str(QA),
                 str(QA / 'test_existing_admission_boundary_v2.py'),
                 f'--junitxml={QA / "existing-admission-v2.xml"}']
    started = time.monotonic()
    (QA / 'existing-admission-v2.command.json').write_text(json.dumps({
        'source_commit': SOURCE_COMMIT,
        'live_repository_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPOSITORY,
                                                        text=True).strip(),
        'production_diff_from_source': subprocess.check_output(
            ['git', 'diff', '--name-only', f'{SOURCE_COMMIT}..HEAD', '--', 'src'], cwd=REPOSITORY,
            text=True).splitlines(),
        'command': [sys.executable, str(Path(__file__).resolve())],
        'pytest_arguments': arguments,
        'environment': {key: os.environ[key] for key in ('PYTHONPATH', 'QT_QPA_PLATFORM',
                         'PATCHTRACE_PW02_REVIEW_SOURCE', 'PATCHTRACE_PW02_REVIEW_OUTPUT')},
        'started_at': datetime.now(timezone.utc).isoformat(),
        'scope': 'two existing public-path controls; no native package implementation or native execution',
    }, indent=2) + '\n')
    result = int(pytest.main(arguments))
    modules, drift = [], []
    for name, module in sorted(sys.modules.items()):
        if not name.startswith('patchtrace') or not getattr(module, '__file__', None):
            continue
        path = Path(module.__file__).resolve()
        item = {'module': name, 'path': str(path)}
        if not path.is_relative_to(SOURCE):
            drift.append(name)
            item['unexpected_source'] = True
        else:
            relative = path.relative_to(REPOSITORY).as_posix()
            actual = path.read_bytes()
            expected = subprocess.run(['git', 'show', f'{SOURCE_COMMIT}:{relative}'], cwd=REPOSITORY,
                                      capture_output=True, check=True).stdout
            item.update({'relative_path': relative, 'sha256': hashlib.sha256(actual).hexdigest(),
                         'expected_sha256': hashlib.sha256(expected).hexdigest()})
            if actual != expected:
                drift.append(name)
        modules.append(item)
    (QA / 'existing-admission-v2.imports.json').write_text(json.dumps({
        'source_commit': SOURCE_COMMIT, 'modules': modules, 'drift': drift,
    }, indent=2) + '\n')
    exit_code = 1 if drift else result
    (QA / 'existing-admission-v2.exit.json').write_text(json.dumps({
        'pytest_exit': result, 'exit_code': exit_code, 'module_count': len(modules),
        'source_drift': drift, 'seconds': time.monotonic() - started,
    }, indent=2) + '\n')
    return exit_code


if __name__ == '__main__':
    raise SystemExit(main())
