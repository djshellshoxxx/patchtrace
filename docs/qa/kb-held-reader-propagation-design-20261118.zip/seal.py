"""Verify fixed Git/source/probe provenance and seal this read-only proposal once."""
from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

Q = Path(__file__).resolve().parent
R = Path('/workspace/scratch/c7a9e8d98848/semantic-disposition-batch4')
provenance = json.loads((Q / 'source-provenance.json').read_text())
source = provenance['source']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == source
assert not subprocess.check_output(['git', 'diff', 'HEAD'], cwd=R)
for row in provenance['snapshots']:
    data = (Q / 'source' / row['path']).read_bytes()
    expected = subprocess.check_output(['git', 'show', row['git_commit'] + ':' + row['path']], cwd=R)
    assert data == expected and len(data) == row['bytes']
    assert hashlib.sha256(data).hexdigest() == row['sha256']
for row in json.loads((Q / 'source-seams.json').read_text())['proofs']:
    lines = (Q / 'source' / row['path']).read_text().splitlines(keepends=True)
    data = ''.join(lines[row['line'] - 1:row['end_line']]).encode()
    assert hashlib.sha256(data).hexdigest() == row['sha256']
for row in json.loads((Q / 'caller-searches.json').read_text()):
    result = subprocess.run(row['argv'], cwd=R, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    assert result.returncode == row['returncode'] and result.stdout == (Q / row['path']).read_bytes()
for row in json.loads((Q / 'prior-design-preservation.json').read_text())['files']:
    data = (Q / row['path']).read_bytes()
    assert data == Path(row['original_path']).read_bytes()
    assert hashlib.sha256(data).hexdigest() == row['sha256']
files = []
for path in sorted(Q.rglob('*')):
    if not path.is_file() or '__pycache__' in path.parts or path.suffix == '.pyc':
        continue
    data = path.read_bytes()
    files.append(dict(path=str(path.relative_to(Q)), bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
manifest = dict(schema=1, source=source, source_tree=provenance['source_tree'],
                sealed_utc=datetime.now(UTC).isoformat(), runtime_tests_executed=0, production_edits=0,
                files=files)
with (Q / 'manifest.json').open('x') as output:
    json.dump(manifest, output, indent=2)
    output.write('\n')
archive_path = Q.with_suffix('.zip')
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for row in files:
        archive.write(Q / row['path'], row['path'])
    archive.write(Q / 'manifest.json', 'manifest.json')
with zipfile.ZipFile(archive_path) as archive:
    assert len(archive.namelist()) == len(files) + 1
    assert set(archive.namelist()) == {row['path'] for row in files} | {'manifest.json'}
    for row in files:
        data = archive.read(row['path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
receipt = dict(source=source, source_tree=provenance['source_tree'], archive=str(archive_path),
               members=len(files) + 1, bytes=archive_path.stat().st_size,
               sha256=hashlib.sha256(archive_path.read_bytes()).hexdigest(), source_snapshots=40,
               symbol_proofs=51, exact_core_worker_checks=7, unchanged_prior_kb_files=16,
               prior_evidence_files=21, production_edits=0, runtime_tests_executed=0)
with Q.with_name(Q.name + '-seal.json').open('x') as output:
    json.dump(receipt, output, indent=2)
    output.write('\n')
print(json.dumps(receipt, indent=2))
