from __future__ import annotations

import ast
import importlib.util
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path('/workspace/scratch/837fe19aae3a/repair-tier-r-pin-contract')
BASE = 'a73cea498d93e353eb49ef08aff785bd0c0a768c'
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tests'))
SPEC = importlib.util.spec_from_file_location('reviewed_tier_r_shard', ROOT / 'tests/test_tier_r_shard.py')
CANDIDATE = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = CANDIDATE
SPEC.loader.exec_module(CANDIDATE)
TEXT = CANDIDATE.WORKFLOW.read_text()
CHECKOUT = 'actions/checkout@11d5960a326750d5838078e36cf38b85af677262'
MSVC = 'ilammy/msvc-dev-cmd@0b201ec74fa43914dc39ae48a89fd1d8cb592756'
GHIDRA = '9102249a9f0b6319c5334a2e5cf8d9cc3f2035e1d3def027c41f6a90f647e8cf'
RIZIN = 'c3b458661d69e26e203d739c0c82d143cc8a4a29d9e571f099c2cf4bda62a120'


def check_text(tmp_path, monkeypatch, text):
    workflow = tmp_path / 'corpus-tier-r.yml'
    workflow.write_text(text)
    monkeypatch.setattr(CANDIDATE, 'WORKFLOW', workflow)
    CANDIDATE.test_workflow_structure_and_pins()


def test_unchanged_baseline_test_body_reproduces_recorded_failure():
    source = subprocess.check_output(['git', 'show', BASE + ':tests/test_tier_r_shard.py'], cwd=ROOT, text=True)
    module = ast.parse(source)
    function = next(node for node in module.body
                    if isinstance(node, ast.FunctionDef) and node.name == 'test_workflow_structure_and_pins')
    isolated = ast.Module(body=[function], type_ignores=[])
    namespace = {'WORKFLOW': ROOT / '.github/workflows/corpus-tier-r.yml', 'pytest': pytest}
    exec(compile(isolated, BASE + ':tests/test_tier_r_shard.py', 'exec'), namespace)
    with pytest.raises(AssertionError, match='actions/checkout@11d5960a326750d5838078e36cf38b85af677262'):
        namespace['test_workflow_structure_and_pins']()


def test_candidate_accepts_exact_unchanged_workflow():
    CANDIDATE.test_workflow_structure_and_pins()


@pytest.mark.parametrize('pin', sorted(CANDIDATE.REVIEWED_ACTIONS))
def test_each_action_requires_its_exact_reviewed_commit(tmp_path, monkeypatch, pin):
    other = pin.split('@', 1)[0] + '@' + '0' * 40
    altered = TEXT.replace(pin, other, 1)
    assert altered != TEXT
    with pytest.raises(AssertionError):
        check_text(tmp_path, monkeypatch, altered)


@pytest.mark.parametrize('replacement', [
    'unreviewed-owner/unreviewed-action@11d5960a326750d5838078e36cf38b85af677262',
    'actions/checkout@v4',
])
def test_unknown_action_and_mutable_tag_are_refused(tmp_path, monkeypatch, replacement):
    with pytest.raises(AssertionError):
        check_text(tmp_path, monkeypatch, TEXT.replace(CHECKOUT, replacement, 1))


def test_comments_do_not_create_actions(tmp_path, monkeypatch):
    check_text(tmp_path, monkeypatch, '# - uses: unrelated/action@v1\n' + TEXT)


def test_readable_version_comment_is_not_a_reference(tmp_path, monkeypatch):
    check_text(tmp_path, monkeypatch, TEXT.replace(CHECKOUT + ' # v4.4.0',
                                                  CHECKOUT + ' # actions/checkout@v4.4.0'))


def test_required_action_cannot_be_replaced_with_comment_only_text(tmp_path, monkeypatch):
    altered = TEXT.replace('uses: ' + MSVC, 'run: echo omitted # uses: ' + MSVC)
    assert altered != TEXT
    with pytest.raises(AssertionError):
        check_text(tmp_path, monkeypatch, altered)


@pytest.mark.parametrize('old,new', [
    (GHIDRA, '0' * 64),
    (RIZIN, '1' * 64),
    ('  contents: read', '  contents: write'),
    ('    needs: plan', '    needs: missing-plan'),
    ('gcc-mingw-w64-x86-64', 'compiler-removed'),
])
def test_existing_archive_and_structure_checks_are_preserved(tmp_path, monkeypatch, old, new):
    assert old in TEXT
    altered = TEXT.replace(old, new)
    with pytest.raises(AssertionError):
        check_text(tmp_path, monkeypatch, altered)
