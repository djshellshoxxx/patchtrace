# Exact-tree Intel acceptance interpretation

Examined local commit `a52533251b8d39659f7eae5a3534e433339a7f0f` and verified tree `1c59af32db14e351c05e0be32c1dde59dc489d43`, the tree assigned for published head `a73cea498d93e353eb49ef08aff785bd0c0a768c`. Actual GitHub run and checkout identity verification belongs to the parent collector; this review made no GitHub request or tool/test execution.

## Acceptance meaning

Each capa/FLOSS/DIE passed record requires a supported pinned manifest, both older/newer synthetic fixture runs returning `ok`, and matching selected normalized evidence sets against the committed goldens. The fixtures are `capa-api`, `floss-static`, and `diec-same`; a new temporary project is created for each engine. This proves real pinned tool behavior for these authored pairs and default configurations, not broad binary compatibility or accuracy.

The comparison intentionally omits run identities, timestamps and paths. It compares capability rule/scope/RVA/function identity, string hash/type/encoding/file offset, and environment category/rule/certainty/version. It does not compare entire raw JSON or every record field.

Windows offline FLOSS is a distinct check: it records `blocked` and calls `pytest.skip` because `unshare -rn` is unavailable. It is not an engine failure. Linux offline may also block if user namespaces are unavailable. The Windows test step is advisory (`continue-on-error: true`), so read actual pytest/status results even when the workflow is green. The build-environment job runs only on explicit dispatch and is skipped for this pull request run.

## Probe evidence limits

The observer wraps existing initial `run_version_probe` calls for exactly `--version`, `--help`, or `-H`; it adds no process. Up to four calls are retained, and omitted calls are counted. Streams are redacted tails of at most 4,096 characters with truncation flags and captured decoded character counts; executable name is a basename capped at 128 characters. Return code, reason, spawn error, oversize, elapsed time or exception class accompany them.

This observer does not capture analysis subprocess argv/stdout/stderr. Analysis failure records may expose only sanitized generic errors. Full available artifact/log preservation must not be described as complete underlying raw analysis output when the harness did not retain it.

## Source verification

Intel `process.tool_env` in this exact tree contains the fixed Windows `USERNAME=patchtrace`; the extra allow-list cannot override it. Shared `secondary.engine_env` is byte-identical to the daee baseline. Workflow, live acceptance test and observer blobs are also identical to daee, so the acceptance criterion was not weakened for this repair. Exact blob IDs and SHA-256 values are in `review.json`, with byte-exact source copies under `source/`.

No blocking source interpretation finding. The workflow's historical comment saying tools have not yet run on Windows is stale and must not replace current native result evidence. No claim about the actual new run's pass/fail outcome is made here.
