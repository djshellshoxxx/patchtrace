# Intel native acceptance at a73cea498d93

**Actual result: Linux 4 passed; Windows 3 passed, 1 skipped; zero failed tests.** All three pinned engines passed on both platforms. This receipt qualifies only the exact source below, not a later published head.

Run: https://github.com/djshellshoxxx/PatchTrace/actions/runs/44880309380 (attempt 1, pull_request, completed/success).

| Source identity | Exact value |
| --- | --- |
| Published head | a73cea498d93e353eb49ef08aff785bd0c0a768c |
| Published and checkout tree | 1c59af32db14e351c05e0be32c1dde59dc489d43 |
| Actual checkout in both job logs | d6d08f6d97fb918507128e84dca94aee93923808 |
| Tree-equivalent local source | a52533251b8d39659f7eae5a3534e433339a7f0f |

| Platform | Job | Native outcome |
| --- | --- | --- |
| Linux | 136773951162 | 4 passed in 14.60 seconds |
| Windows | 136773951412 | 3 passed, 1 skipped in 52.11 seconds |

## Actual Windows evidence

capa --version and --help returned zero, with version stdout `capa.exe 9.4.0` plus CRLF. FLOSS --version and -H returned zero, with version stdout `floss.exe v3.1.1-0-g3cd3ee6` plus CRLF. DIE --version and --help returned zero, with version stdout `die 3.21` plus CRLF. All probe stderr streams are empty. Longer capa/FLOSS help tails are explicitly marked truncated by the bounded observer; actual help admission passed.

For each engine, both older/newer synthetic analyses returned ok and selected normalized evidence matched committed goldens. Fixtures are capa-api, floss-static and diec-same. The same checks passed on Linux, which also passed FLOSS static extraction in an empty network namespace.

Windows offline FLOSS records blocked and pytest skipped because `unshare -rn is unavailable on this platform`. These describe one check, not an engine failure. The separate dispatch-only live-build-environment job was skipped for this pull-request event and is not another pytest skip.

## Earlier failure and qualification boundaries

Prior daee run 44876415860 had Windows 2 failed, 1 passed, 1 skipped. Its FLOSS traceback directly identified getpass falling through to missing pwd. This exact new tree includes fixed synthetic Windows USERNAME=patchtrace only in Intel tool_env. Shared policy and live acceptance criteria are unchanged. Both the FLOSS startup failure and capa analysis failure no longer occur on these acceptance pairs. Capa's old generic error did not name its missing module, so the exact historical cause remains inference.

No previous-source passes were transferred here. This establishes native pinned-tool acceptance on these authored fixtures and default configurations, not arbitrary-binary accuracy, capa Ghidra, FLOSS deobfuscation, DIE heuristics or Windows offline isolation. The observer captures only bounded redacted version/help tails; complete raw analysis stdout/stderr are not retained by the harness. All available logs/statuses are preserved without claiming uncaptured output.

## Retained evidence

Included: exact artifact ZIPs, extracted byte-identical status JSON, complete decoded native logs, initial/final run/job/artifact metadata, actual checkout receipts, synthetic merge metadata, fixed-tree source snapshots, independent source-interpretation review, summary.json and per-file manifest. Both artifact SHA-256 values and byte sizes match GitHub metadata; ZIP CRC checks pass. Signed download URLs are not retained.

Linux artifact 14697597519: 5647 bytes; SHA-256 bd2075ea295e5504184410716c082ca9115945af97b94fb7e4ac9330bb28a9af.

Windows artifact 14698425360: 5752 bytes; SHA-256 f25fbd10aa46078b65d9e41260565055db211d62b1bb24f4fe1b8f68f16fa49a.

Original daee evidence remains under ../combined-intel-live; its archive SHA-256 is c5e4718313eb99fdca0da7739978097d30be65468173f533831132de9e3e0430.

Only existing CI was observed. No retry, dispatch, source/ref edit, local upstream execution or analyzed-target execution occurred. Observation of this run is complete; no background monitoring continues after this report.
