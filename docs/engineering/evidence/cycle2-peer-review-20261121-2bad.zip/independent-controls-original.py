"""Independent cycle2 controls; retained as review evidence, not product tests."""
from __future__ import annotations

import csv
import importlib.util
import io
import json
from pathlib import Path

import pytest
from PySide6.QtCore import Qt
from test_tooltips import settings as settings
from test_tooltips import test_every_registry_id_is_applied_somewhere as audit_registry
from test_tooltips import window as window
from test_ui_strings_panel import start

from patchtrace import tooltips
from patchtrace.gui.qt.table import VirtualTableModel

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("cycle2_peer_inventory", ROOT / "tools/branch_inventory.py")
inventory = importlib.util.module_from_spec(spec)
spec.loader.exec_module(inventory)


def test_quoted_snapshot_keeps_multiline_unicode_and_restores_nondefault_csv_limit(tmp_path):
    output = io.StringIO(newline="")
    writer = csv.writer(output, delimiter="\t")
    writer.writerow(["note", "tip_sha", "branch"])
    writer.writerow(['line one\t"quoted"\nline two\r\névidence', "a" * 40, "topic/one"])
    writer.writerow(["x" * 150000, "b" * 64, "topic/two"])
    path = tmp_path / "valid.tsv"
    path.write_bytes(output.getvalue().encode("utf-8"))
    calls = []

    class ExactCommits:
        def commit(self, oid):
            calls.append(oid)
            return oid

    original = csv.field_size_limit(17)
    try:
        assert inventory.branches(ExactCommits(), "origin", path) == [
            ("topic/one", "a" * 40), ("topic/two", "b" * 64)]
        assert csv.field_size_limit() == 17
        assert calls == ["a" * 40, "b" * 64]
    finally:
        csv.field_size_limit(original)


def test_invalid_utf8_snapshot_restores_limit_without_any_git_lookup(tmp_path):
    path = tmp_path / "invalid.tsv"
    path.write_bytes(b"branch\ttip_sha\tnote\nrow\t" + b"a" * 40 + b"\t\xc0\x80")

    class NoGit:
        def commit(self, oid):
            pytest.fail("decoding failure reached Git")

    original = csv.field_size_limit(19)
    try:
        with pytest.raises(UnicodeDecodeError):
            inventory.branches(NoGit(), "origin", path)
        assert csv.field_size_limit() == 19
    finally:
        csv.field_size_limit(original)


def test_json_rejects_semantically_duplicate_escaped_keys_but_keeps_constant_text(tmp_path):
    path = tmp_path / "pulls.json"
    path.write_bytes(br'[{"head":{"ref":"one","r\u0065f":"two"}}]')
    with pytest.raises(ValueError, match="duplicate JSON key") as caught:
        inventory.read_json(path)
    assert "one" not in str(caught.value) and "two" not in str(caught.value)
    accepted = [{"head": {"ref": "NaN Infinity -Infinity é"}}]
    path.write_text(json.dumps(accepted, ensure_ascii=False), encoding="utf-8")
    assert inventory.read_json(path) == accepted


def test_strings_header_help_survives_sort_filter_and_empty_result_without_cell_mutation(qtbot):
    controller, *_ = start(qtbot)
    model = controller.panel.table.table_model
    before = {model.key_at(i): model.texts_at(i) for i in range(model.rowCount())}
    model.sort(1, Qt.SortOrder.DescendingOrder)
    model.set_filter("nothing can match this exact query")
    assert model.rowCount() == 0
    headers = [model.headerData(i, Qt.Orientation.Horizontal, Qt.ItemDataRole.ToolTipRole)
               for i in range(8)]
    assert all(text.startswith("What: ") for text in headers)
    assert len(set(headers)) == 8
    model.set_filter("")
    assert {model.key_at(i): model.texts_at(i) for i in range(model.rowCount())} == before
    assert headers == [tooltips.tooltip("strings.col." + key)
                       for key in ("change", "string", "type", "older", "newer", "function", "cues", "source")]


def test_registry_audit_detects_registered_but_unserved_column_help(window, qtbot, tmp_path, settings, monkeypatch):
    original = VirtualTableModel.headerData

    def omit_source_tip(self, section, orientation, role=Qt.ItemDataRole.DisplayRole):
        if (orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.ToolTipRole
                and 0 <= section < len(self._p.columns)
                and self._p.columns[section].tip_id == "strings.col.source"):
            return self._p.columns[section].title
        return original(self, section, orientation, role)

    monkeypatch.setattr(VirtualTableModel, "headerData", omit_source_tip)
    with pytest.raises(AssertionError, match="strings.col.source"):
        audit_registry(window, qtbot, tmp_path, settings, monkeypatch)
