import json
import subprocess
import sys
import venv
from pathlib import Path

checkout, destination = map(Path, sys.argv[1:])
base = Path('/workspace/scratch/patchtrace-95fe-c3/venv/lib/python3.12/site-packages')
venv.EnvBuilder(with_pip=False, symlinks=True).create(destination)
site=next((destination/'lib').glob('python*/site-packages'))
(site/'reused-dependencies.pth').write_text(str(base)+'\n')
python=destination/'bin/python'
run=subprocess.run([str(python),'-m','pip','install','--no-deps','--no-build-isolation','-e',str(checkout)],capture_output=True,text=True)
if run.returncode:
    print(run.stdout+run.stderr)
    raise SystemExit(run.returncode)
out=subprocess.check_output([str(python),'-I','-c','import json,patchtrace,sys; print(json.dumps({"python":sys.executable,"source":patchtrace.__file__}))'],text=True,cwd=checkout)
record=json.loads(out)
assert Path(record['source']).resolve().is_relative_to(checkout.resolve()),record
print(out,end='')
