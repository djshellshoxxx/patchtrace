"""Source/YAML controls only; no frozen or hosted-platform acceptance."""
import ast
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys

import patchtrace
import yaml

ROOT = Path('/workspace/scratch/patchtrace-95fe-c3/linux-review')
OUT = Path('/workspace/scratch/patchtrace-95fe-c3/linux-review-evidence')
BASE = '6b6fcd3597a604212032ffc453477aeb6edc69ff'
EXPECTED = 'e4854b66ae37024d734e22ae978dedca90a7f3f7'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

checks = []
head, tree = git('rev-parse', 'HEAD'), git('rev-parse', 'HEAD^{tree}')
assert head == EXPECTED
assert git('status', '--porcelain=v1', '--untracked-files=all') == ''
assert Path(patchtrace.__file__).resolve() == ROOT / 'src/patchtrace/__init__.py'
workflow = yaml.safe_load((ROOT / '.github/workflows/qa-windows.yml').read_text())
jobs = workflow['jobs']
smoke, package = jobs['linux-smoke'], jobs['linux-package']
steps = smoke['steps']

def record(label, condition):
    checks.append({'control': label, 'passed': bool(condition)})

record('Both native smoke matrix entries retained',
       smoke['strategy']['matrix']['os'] == ['ubuntu-22.04', 'ubuntu-24.04']
       and smoke['runs-on'] == '${{ matrix.os }}')
record('Smoke depends on the same workflow package job', smoke['needs'] == 'linux-package')
checkout = next(s for s in steps if s.get('uses', '').startswith('actions/checkout@'))
build_checkout = next(s for s in package['steps'] if s.get('uses', '').startswith('actions/checkout@'))
record('Both checkouts use default workflow event source without ref/repository override',
       all(not ({'ref', 'repository'} & set(s.get('with', {}))) for s in (checkout, build_checkout)))
download = next(s for s in steps if s.get('uses', '').startswith('actions/download-artifact@'))
upload = next(s for s in package['steps'] if s.get('uses', '').startswith('actions/upload-artifact@'))
record('Same named artifact and default same-run download, after checkout',
       download['with']['name'] == upload['with']['name'] == 'PatchTrace-linux-x86_64'
       and set(download['with']) == {'name'} and steps.index(checkout) < steps.index(download))
frozen = next(s for s in steps if s.get('name') == 'Full frozen Linux CLI smoke (CODEX-14)')
record('Frozen invocation is direct and inherits no failure suppression',
       frozen['run'] == 'python tools/frozen_smoke.py "$PWD/PatchTrace/PatchTrace"'
       and not smoke.get('continue-on-error', False)
       and not frozen.get('continue-on-error', False)
       and 'if' not in frozen)
runs = [s.get('run', '') for s in steps]
record('Checksum and extraction/executable check precede frozen invocation',
       runs.index('sha256sum -c PatchTrace-0.1.0-linux-x86_64.tar.gz.sha256')
       < runs.index('tar xzf PatchTrace-0.1.0-linux-x86_64.tar.gz && test -x PatchTrace/PatchTrace')
       < steps.index(frozen))
record('Both GUI probes and frozen offscreen environment retained',
       any(s.get('run') == 'QT_QPA_PLATFORM=offscreen PatchTrace/PatchTrace --self-test'
           and s.get('env', {}).get('LANG') == 'C.UTF-8' for s in steps)
       and any(s.get('run') == 'QT_QPA_PLATFORM=xcb xvfb-run -a PatchTrace/PatchTrace --self-test'
               and s.get('env', {}).get('LANG') == 'C.UTF-8' for s in steps)
       and frozen.get('env') == {'QT_QPA_PLATFORM': 'offscreen', 'LANG': 'C.UTF-8'})

def runtime_dump(source):
    parsed = ast.parse(source)
    if (parsed.body and isinstance(parsed.body[0], ast.Expr)
            and isinstance(parsed.body[0].value, ast.Constant)
            and isinstance(parsed.body[0].value.value, str)):
        parsed.body.pop(0)
    return ast.dump(parsed, include_attributes=False)

before = runtime_dump(git('show', BASE + ':tools/frozen_smoke.py'))
after = runtime_dump((ROOT / 'tools/frozen_smoke.py').read_text())
record('Helper runtime AST equals baseline after removing module docstring', before == after)
receipt = {
    'scope': 'Independent parsed-YAML and AST source inspection, not frozen acceptance',
    'command': [sys.executable, '-I', str(Path(__file__).resolve())],
    'workdir': str(ROOT), 'head': head, 'tree': tree, 'baseline': BASE,
    'source_import': str(Path(patchtrace.__file__).resolve()),
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'helper_runtime_ast_sha256': hashlib.sha256(after.encode()).hexdigest(),
    'checks': checks, 'passed': all(c['passed'] for c in checks),
    'status_after': git('status', '--porcelain=v1', '--untracked-files=all'),
    'prior_control_correction': 'Initial reviewer-only GUI assertion incorrectly assumed '
        'QT_QPA_PLATFORM YAML env entries and an extra Xvfb screen argument. The actual '
        'preserved probes set QT_QPA_PLATFORM inline. Original script and failing receipt '
        'retained as independent-spec-controls.initial.py and '
        'independent-spec-controls.initial-failure.receipt.json. Repository was not edited.',
}
(OUT / 'independent-spec-controls.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
sys.exit(0 if receipt['passed'] and receipt['status_after'] == '' else 1)
