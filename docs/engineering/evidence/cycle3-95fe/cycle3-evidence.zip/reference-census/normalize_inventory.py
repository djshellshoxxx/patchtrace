"""Normalize saved REST census pages and compare immutable reference snapshots.

Read-only for the Git repository. Writes evidence only beside this script.
No ancestry or semantic-equivalence classification is performed.
"""
from __future__ import annotations

import hashlib
import io
import json
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/patchtrace-95fe-c3/PatchTrace')
BASE = '6b6fcd3597a604212032ffc453477aeb6edc69ff'
RECOVERED_SOURCE = '487e08113c86636ef9a87aaae8a1b88b224d9f04'
REPOSITORY = 'https://github.com/djshellshoxxx/PatchTrace'


def pairs_unique(pairs):
    obj = {}
    for key, value in pairs:
        if key in obj:
            raise ValueError(f'duplicate JSON key: {key}')
        obj[key] = value
    return obj


def strict_json(raw):
    def reject(value):
        raise ValueError(f'nonfinite JSON constant: {value}')
    return json.loads(raw, object_pairs_hook=pairs_unique, parse_constant=reject)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def save_json(relative, data):
    path = ROOT / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    return path


def git_bytes(path, ref=BASE):
    result = subprocess.run(
        ['git', 'show', f'{ref}:{path}'], cwd=REPO, capture_output=True, check=True
    )
    return result.stdout


def git_blob(path, ref=BASE):
    return subprocess.run(
        ['git', 'rev-parse', f'{ref}:{path}'], cwd=REPO,
        capture_output=True, text=True, check=True
    ).stdout.strip()


def normalize_pr(item):
    head = item.get('head')
    base = item.get('base')
    if isinstance(head, dict):
        head_ref, head_sha = head.get('ref'), head.get('sha')
        head_repo = (head.get('repo') or {}).get('full_name')
    else:
        head_ref, head_sha, head_repo = head, item.get('head_sha'), None
    if isinstance(base, dict):
        base_ref, base_sha = base.get('ref'), base.get('sha')
    else:
        base_ref, base_sha = base, item.get('base_sha')
    state = item['state']
    if state not in {'open', 'closed'}:
        raise ValueError(f'unexpected PR state: {state}')
    merged_at = item.get('merged_at')
    category = 'merged' if merged_at else ('open' if state == 'open' else 'closed_unmerged')
    return {
        'number': item['number'], 'title': item['title'], 'state': state,
        'classification': category, 'draft': item.get('draft'),
        'head_ref': head_ref, 'head_sha': head_sha, 'head_repository': head_repo,
        'base_ref': base_ref, 'base_sha': base_sha,
        'created_at': item.get('created_at'), 'updated_at': item.get('updated_at'),
        'closed_at': item.get('closed_at'), 'merged_at': merged_at,
        'merge_commit_sha': item.get('merge_commit_sha'),
        'url': item.get('html_url') or item.get('url'),
    }


def pr_counts(items):
    counts = {'all_state': len(items), 'open': 0, 'merged': 0, 'closed_unmerged': 0}
    for item in items:
        counts[item['classification']] += 1
    counts['open_draft'] = sum(p['classification'] == 'open' and p['draft'] is True for p in items)
    counts['open_ready'] = sum(p['classification'] == 'open' and p['draft'] is False for p in items)
    return counts


def branch_delta(old, new):
    a = {item['name']: item['sha'] for item in old}
    b = {item['name']: item['sha'] for item in new}
    return {
        'snapshot_count': len(a), 'current_count': len(b),
        'new': [{'name': name, 'sha': b[name]} for name in sorted(b.keys() - a.keys())],
        'missing': [{'name': name, 'previous_sha': a[name]} for name in sorted(a.keys() - b.keys())],
        'moved': [{'name': name, 'previous_sha': a[name], 'sha': b[name]}
                  for name in sorted(a.keys() & b.keys()) if a[name] != b[name]],
        'unchanged': sum(a[name] == b[name] for name in a.keys() & b.keys()),
    }


def pr_delta(old, new):
    a, b = ({p['number']: p for p in rows} for rows in (old, new))
    fields = ('state', 'draft', 'head_ref', 'head_sha', 'base_ref', 'base_sha', 'merged_at', 'closed_at')
    changed = []
    for number in sorted(a.keys() & b.keys()):
        changes = {f: {'previous': a[number][f], 'current': b[number][f]}
                   for f in fields if a[number][f] != b[number][f]}
        if changes:
            changed.append({'number': number, 'changes': changes})
    return {
        'snapshot_counts': pr_counts(old), 'current_counts': pr_counts(new),
        'new': [b[n] for n in sorted(b.keys() - a.keys())],
        'missing': [a[n] for n in sorted(a.keys() - b.keys())],
        'changed': changed,
    }


pending = strict_json((ROOT / 'capture-metadata.pending.json').read_bytes())
metadata = []
collections = {'branches': [], 'pulls': []}
for entry in pending:
    path = Path(entry['path'])
    data = path.read_bytes()
    # apply_patch added exactly one terminal LF to the connector body.
    # A completed marker prevents a later invocation stripping it again.
    marker = path.with_suffix('.capture.json')
    if not marker.exists():
        if not data.endswith(b'\n'):
            raise ValueError(f'missing serialization delimiter: {path}')
        data = data[:-1]
        if len(data.decode('utf-8').encode('utf-16-le')) // 2 != entry['body_text_code_units']:
            raise ValueError(f'connector text length mismatch: {path}')
        path.write_bytes(data)
    parsed = strict_json(data)
    if not isinstance(parsed, list) or len(parsed) != entry['items']:
        raise ValueError(f'page count mismatch: {path}')
    record = {k: v for k, v in entry.items() if k not in {'path', 'serialization'}}
    record.update({'path': str(path.relative_to(ROOT)), 'bytes': len(data), 'sha256': digest(data),
                   'serialization': 'Exact UTF-8 body returned by the GitHub REST connector.'})
    marker.write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
    metadata.append(record)
    for item in parsed:
        collections[entry['collection']].append((item, record))

for collection in collections:
    pages = sorted((x for x in metadata if x['collection'] == collection), key=lambda p: p['page'])
    if [p['page'] for p in pages] != list(range(1, 6)) or pages[-1]['items'] != 0:
        raise ValueError(f'incomplete page enumeration: {collection}')

branches = sorted([
    {'name': item['name'], 'sha': item['commit']['sha'], 'protected': item['protected'],
     'captured_at_utc': meta['captured_at_utc'], 'source_page': meta['path']}
    for item, meta in collections['branches']
], key=lambda b: b['name'])
pulls = sorted([
    normalize_pr(item) | {'captured_at_utc': meta['captured_at_utc'], 'source_page': meta['path']}
    for item, meta in collections['pulls']
], key=lambda p: p['number'])
if len({b['name'] for b in branches}) != len(branches) or len({p['number'] for p in pulls}) != len(pulls):
    raise ValueError('duplicate branch names or pull request numbers across API pages')

capture_window = {
    'started_at_utc': min(m['capture_started_at_utc'] for m in metadata),
    'completed_at_utc': max(m['captured_at_utc'] for m in metadata),
    'atomic': False,
}
common = {'schema': 'patchtrace-reference-census/1', 'repository': REPOSITORY,
          'capture_window': capture_window, 'collection_method': 'GitHub REST GET through GitHub connector',
          'limits': ['Paginated observation, not an atomic repository transaction.',
                     'No semantic supersession or live-worker ownership classification.',
                     'No tests, builds, native qualification, workflow dispatch, or ref mutations.']}
save_json('capture-manifest.json', common | {'pages': metadata})
save_json('branches.normalized.json', common | {'count': len(branches), 'branches': branches})
save_json('pulls.normalized.json', common | {'counts': pr_counts(pulls), 'pull_requests': pulls})

g30_path = 'docs/engineering/consolidation-inventory-20261120-g30.json'
g30_raw = git_bytes(g30_path)
g30 = strict_json(g30_raw)
frozen = ROOT / 'snapshots'
frozen.mkdir(exist_ok=True)
(frozen / 'g30-at-pr348.json').write_bytes(g30_raw)
g30_branches = [{'name': b['branch'], 'sha': b['head']} for b in g30['branches']]
g30_pulls = [normalize_pr(p) for p in g30['pull_requests']]

zip_path = 'docs/engineering/evidence/cycle95fe/cycle-95fe-evidence.zip'
zip_raw = git_bytes(zip_path, RECOVERED_SOURCE)
if digest(zip_raw) != '06e115ed85de8fd85315d2bef465d7eff60833179f520cbd9fa3801f95669525':
    raise ValueError('recovered cycle95fe archive differs from its retained identity')
selected = {}
with zipfile.ZipFile(io.BytesIO(zip_raw)) as archive:
    for name in ('raw/remote-branches.json', 'raw/pulls.json', 'raw/branch-inventory.json'):
        data = archive.read(name)
        target = frozen / ('cycle95fe-' + Path(name).name)
        target.write_bytes(data)
        selected[name] = {'path': str(target.relative_to(ROOT)), 'sha256': digest(data), 'bytes': len(data)}
cycle_branches = strict_json((frozen / 'cycle95fe-remote-branches.json').read_bytes())
cycle_pulls = [normalize_pr(p) for p in strict_json((frozen / 'cycle95fe-pulls.json').read_bytes())]
cycle_receipt = strict_json((frozen / 'cycle95fe-branch-inventory.json').read_bytes())
snapshots = {
    'g30_at_pr348': {
        'source_commit': BASE, 'source_path': g30_path, 'source_blob': git_blob(g30_path),
        'retained_copy': 'snapshots/g30-at-pr348.json', 'sha256': digest(g30_raw),
        'captured_at_utc_as_recorded': g30['observed_at_utc'],
        'generated_at_utc_as_recorded': g30['generated_at_utc'],
    },
    'recovered_cycle95fe': {
        'source_commit': RECOVERED_SOURCE, 'archive_path': zip_path,
        'archive_blob': git_blob(zip_path, RECOVERED_SOURCE),
        'archive_sha256': digest(zip_raw), 'members': selected,
        'captured_at_utc_as_recorded': None,
        'capture_time_limit': 'Raw branch/PR input arrays contain no capture timestamp; replay times below are not API collection times.',
        'associated_inventory_replay_started_at_utc': cycle_receipt['started_at'],
        'associated_inventory_replay_finished_at_utc': cycle_receipt['finished_at'],
        'associated_inventory_source_commit': cycle_receipt['head'],
    },
}
save_json('snapshot-identities.json', snapshots)
comparisons = {
    'g30_at_pr348': {'branches': branch_delta(g30_branches, branches), 'pull_requests': pr_delta(g30_pulls, pulls)},
    'recovered_cycle95fe': {'branches': branch_delta(cycle_branches, branches), 'pull_requests': pr_delta(cycle_pulls, pulls)},
}
save_json('comparison.normalized.json', common | {'snapshots': snapshots, 'comparisons': comparisons})

counts = pr_counts(pulls)
lines = [
    '# Remote reference census — 2026-11-21', '',
    f"REST capture window: **{capture_window['started_at_utc']} through {capture_window['completed_at_utc']}**.", '',
    f"Observed **{len(branches)} distinct remote branch names** and **{counts['all_state']} distinct all-state PRs**: "
    f"**{counts['open']} open**, **{counts['merged']} merged**, **{counts['closed_unmerged']} closed without merging**. "
    f"Open PRs comprise **{counts['open_draft']} drafts** and **{counts['open_ready']} non-draft PRs**; non-draft does not mean merge-qualified.", '',
    'Complete numbered REST pages 1–4 were retained for each collection, followed by an empty page 5. '
    'Branch page counts: ' + ', '.join(str(p['items']) for p in metadata if p['collection'] == 'branches') + '. '
    'PR page counts: ' + ', '.join(str(p['items']) for p in metadata if p['collection'] == 'pulls') + '.', '',
    '## Snapshot comparison', '',
    '| Explicit snapshot | Branches then | New names | Moved heads | Missing names | Unchanged heads |',
    '| --- | ---: | ---: | ---: | ---: | ---: |',
]
for name, comparison in comparisons.items():
    d = comparison['branches']
    lines.append(f"| {name} | {d['snapshot_count']} | {len(d['new'])} | {len(d['moved'])} | {len(d['missing'])} | {d['unchanged']} |")
lines += ['', 'The g30 snapshot was read from immutable PR348 commit `' + BASE + '`. '
          'The recovered cycle95fe ZIP is absent from that commit and was read from immutable local recovery commit `' + RECOVERED_SOURCE + '`, '
          'with its retained archive SHA-256 verified. Neither input was read from a moving working tree. '
          'g30 records observation at `' + g30['observed_at_utc'] + '`. Recovered cycle95fe inputs have no API capture timestamp; '
          'their associated inventory replay ran from `' + cycle_receipt['started_at'] + '` through `' + cycle_receipt['finished_at'] + '`. '
          'Those replay timestamps are not substituted for a collection timestamp.', '']

for name in ('recovered_cycle95fe', 'g30_at_pr348'):
    d = comparisons[name]['branches']
    lines += [f'### Branch changes versus {name}', '']
    if d['new']:
        lines += ['| New remote name | Exact observed head |', '| --- | --- |']
        lines += [f"| `{p['name']}` | `{p['sha']}` |" for p in d['new']]
        lines.append('')
    if d['moved']:
        lines += ['| Moved remote name | Snapshot head | Observed head |', '| --- | --- | --- |']
        lines += [f"| `{p['name']}` | `{p['previous_sha']}` | `{p['sha']}` |" for p in d['moved']]
        lines.append('')
    if d['missing']:
        lines += ['Missing names: ' + ', '.join('`' + p['name'] + '`' for p in d['missing']) + '.', '']
    else:
        lines += ['No snapshot names are missing from the current collection.', '']

lines += ['## Pull requests', '', '| Snapshot | All | Open | Merged | Closed unmerged | New PR numbers | Existing PRs with tracked metadata changes |',
          '| --- | ---: | ---: | ---: | ---: | --- | ---: |']
for name, comparison in comparisons.items():
    d = comparison['pull_requests']
    c = d['snapshot_counts']
    lines.append(f"| {name} | {c['all_state']} | {c['open']} | {c['merged']} | {c['closed_unmerged']} | "
                 + ', '.join('#' + str(p['number']) for p in d['new']) + f" | {len(d['changed'])} |")
lines += ['', 'Latest 12 PRs by number (all states); the complete normalized file includes every PR:', '',
          '| PR | State | Draft | Base | Head branch | Exact head |', '| --- | --- | --- | --- | --- | --- |']
for p in sorted(pulls, key=lambda p: p['number'], reverse=True)[:12]:
    lines.append(f"| [#{p['number']}]({p['url']}) | {p['classification']} | {p['draft']} | `{p['base_ref']}` | `{p['head_ref']}` | `{p['head_sha']}` |")

lines += ['', '## Boundaries and evidence', '',
          '- This is a reference census. Exact name/head changes do not establish semantic supersession, successful integration, or permission to delete a branch.',
          '- Branch names, commit subjects, PR authors, and draft flags do not identify a live worker. No live-worker ownership is assigned.',
          '- Paginated API reads cover a bounded interval and are not an atomic transaction. Later ref or PR updates require a new receipt.',
          '- REST GET collections were used through the authorized GitHub connector. Local `gh api` had no authentication; no login, GraphQL, dispatch, push, deletion, package, or test operation was performed.',
          '- No repository working tree, source file, local integration branch, or remote ref was changed. No Git fetch was needed.',
          '- PR CI results, native/manual acceptance, release readiness, and semantic donor review are outside this census.', '',
          'Evidence: `capture-manifest.json` binds URLs, per-page timestamps, sizes and SHA-256 values to unchanged REST JSON bodies in `raw/`. '
          '`branches.normalized.json`, `pulls.normalized.json`, and `comparison.normalized.json` retain every normalized record and exact comparison. '
          '`snapshot-identities.json` binds the two frozen inputs to their respective commits and preserves the recovered timestamp limitation.', '']
(ROOT / 'report.md').write_text('\n'.join(lines), encoding='utf-8')
summary = {'capture_window': capture_window, 'branches': len(branches), 'pull_requests': counts,
           'comparisons': {name: {'new_branches': len(c['branches']['new']), 'moved_branches': len(c['branches']['moved']),
                                  'missing_branches': len(c['branches']['missing']),
                                  'new_prs': [p['number'] for p in c['pull_requests']['new']],
                                  'changed_prs': [p['number'] for p in c['pull_requests']['changed']]}
                           for name, c in comparisons.items()},
           'latest_prs': [{k: p[k] for k in ('number', 'state', 'draft', 'head_ref', 'head_sha', 'base_ref')}
                          for p in sorted(pulls, key=lambda p: p['number'], reverse=True)[:8]],
           'generated_at_utc': datetime.now(timezone.utc).isoformat()}
save_json('summary.json', summary)
print(json.dumps(summary, ensure_ascii=False, indent=2))
