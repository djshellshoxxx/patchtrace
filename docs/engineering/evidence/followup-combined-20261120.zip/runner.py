"""Record one bounded, source-pinned diagnostic selection without changing the checkout."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

root = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
selection = sys.argv[3:]
out.mkdir(parents=True, exist_ok=False)
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()
def now():
    return datetime.now(timezone.utc).isoformat()
env = os.environ.copy()
env.update(QT_QPA_PLATFORM='offscreen', PYTHONPATH=str(root/'src')+':'+str(root/'tests'))
command = [sys.executable, '-m', 'pytest', '-q', *selection,
           '--junitxml='+str(out/'results.xml'), '--durations=10']
record = {'command': command, 'checkout': str(root), 'head': git('rev-parse', 'HEAD'),
          'tree': git('rev-parse', 'HEAD^{tree}'), 'status_before': git('status', '--porcelain'),
          'started_at': now(), 'qualification': 'bounded-diagnostic-selection',
          'environment': {k: env.get(k) for k in ('QT_QPA_PLATFORM', 'PYTHONPATH')}}
(out/'receipt.json').write_text(json.dumps(record, indent=2)+'\n')
started = time.monotonic()
with (out/'pytest.log').open('w') as log:
    result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
record.update(exit_code=result.returncode, elapsed_seconds=round(time.monotonic()-started,3),
              ended_at=now(), head_after=git('rev-parse','HEAD'),
              status_after=git('status','--porcelain'))
record['files'] = {p.name: {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
                   for p in out.iterdir() if p.name != 'receipt.json' and p.is_file()}
(out/'receipt.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps(record, indent=2))
print((out/'pytest.log').read_text()[-6000:])
raise SystemExit(result.returncode)
