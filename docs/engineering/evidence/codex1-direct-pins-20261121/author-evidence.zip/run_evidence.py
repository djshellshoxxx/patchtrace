import datetime
import json
import os
import subprocess
import sys
import time
from pathlib import Path

destination = Path(__file__).resolve().parent
name, *command = sys.argv[1:]
record = {
    "command": command,
    "source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(),
    "source_tree": subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], text=True).strip(),
    "working_tree_before": subprocess.check_output(["git", "status", "--porcelain"], text=True),
    "started_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
started = time.monotonic()
with (destination / (name + ".log")).open("w") as log:
    result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT,
                            env={**os.environ, "QT_QPA_PLATFORM": "offscreen"})
record.update(exit_code=result.returncode, seconds=time.monotonic() - started,
              ended_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              working_tree_after=subprocess.check_output(["git", "status", "--porcelain"], text=True))
(destination / (name + ".json")).write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps(record, indent=2))
print("\n".join((destination / (name + ".log")).read_text().splitlines()[-8:]))
raise SystemExit(result.returncode)
