"""One unchanged node, with source/phase and resource observations."""
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import time

import psutil

root = Path('/workspace/scratch/2bade0b323c3/PatchTrace-full-stop')
out = Path('/tmp/patchtrace-full-stop-2bad-evidence')
python = '/workspace/scratch/b1d1356aa953/patchtrace-venv/bin/python'
node = ('tests/stress/test_gui_stress_table.py::'
        'test_a_hundred_thousand_rows_sort_and_filter_with_exact_counts')


def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()


def source():
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain')}


def sample(pid=None):
    result = {'time_ns': time.time_ns(), 'monotonic': time.monotonic(),
              'memory_available': psutil.virtual_memory().available,
              'tmp_free': psutil.disk_usage('/tmp').free,
              'workspace_free': psutil.disk_usage(root).free}
    if pid is not None:
        try:
            child = psutil.Process(pid)
            result.update(rss=child.memory_info().rss, threads=child.num_threads())
        except psutil.NoSuchProcess:
            result['process_exited'] = True
    return result


cmd = [python, '-m', 'pytest', '-vv', '-p', 'no:cacheprovider', '-p', 'phase_receipts', node,
       '--basetemp=/tmp/patchtrace-full-stop-2bad-temp', '--junitxml=' + str(out / 'results.xml')]
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', QT_QPA_PLATFORM='offscreen',
           PYTHONUNBUFFERED='1', PYTHONPATH='/tmp/patchtrace-2bad-harness:' + str(root / 'src'),
           PATCHTRACE_PHASE_LOG=str(out / 'phases.jsonl'))
receipt = {'command': cmd, 'source_before': source(), 'before': sample(),
           'timeout_policy': 'No launcher timeout; one isolated original node only.',
           'resource_sample_interval_seconds': 0.2}
(out / 'start.json').write_text(json.dumps(receipt, indent=2) + '\n')
started = time.monotonic()
with (out / 'stdout.log').open('wb') as stdout, (out / 'resources.jsonl').open('w', buffering=1) as log:
    process = subprocess.Popen(cmd, cwd=root, env=env, stdout=stdout, stderr=subprocess.STDOUT)
    while process.poll() is None:
        log.write(json.dumps(sample(process.pid)) + '\n')
        time.sleep(0.2)
    receipt.update(returncode=process.returncode, elapsed_seconds=time.monotonic() - started,
                   after=sample(), source_after=source(),
                   child_high_water_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
receipt['source_unchanged'] = receipt['source_before'] == receipt['source_after']
receipt['stdout_sha256'] = hashlib.sha256((out / 'stdout.log').read_bytes()).hexdigest()
(out / 'completion.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
print((out / 'stdout.log').read_text(errors='replace'), flush=True)
raise SystemExit(process.returncode if process.returncode >= 0 else 128 - process.returncode)
