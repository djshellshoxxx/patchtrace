"""Record phase boundaries without changing pytest outcomes or test selection."""
import json
import os
import time

_stream = open(os.environ['PATCHTRACE_PHASE_LOG'], 'a', encoding='utf-8', buffering=1)


def _emit(kind, **fields):
    _stream.write(json.dumps({'kind': kind, 'monotonic': time.monotonic(), **fields}) + '\n')


def pytest_collection_finish(session):
    _emit('collection', count=len(session.items))


def pytest_runtest_logstart(nodeid, location):
    _emit('start', nodeid=nodeid)


def pytest_runtest_logreport(report):
    _emit('report', nodeid=report.nodeid, phase=report.when, outcome=report.outcome,
          duration=report.duration)


def pytest_sessionfinish(session, exitstatus):
    _emit('sessionfinish', exitstatus=int(exitstatus), collected=session.testscollected,
          failed=session.testsfailed)
