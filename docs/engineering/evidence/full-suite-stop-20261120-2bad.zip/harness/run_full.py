"""Run one unchanged full suite with source and termination/resource receipts."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import time

import psutil

ROOT = Path('/workspace/scratch/2bade0b323c3/PatchTrace')
OUT = Path('/tmp/patchtrace-2bad-full-evidence')
PYTHON = '/workspace/scratch/b1d1356aa953/patchtrace-venv/bin/python'


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def source():
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain')}


def resources(pid=None):
    row = {'time': utc(), 'monotonic': time.monotonic(),
           'memory_available': psutil.virtual_memory().available,
           'tmp_available': psutil.disk_usage('/tmp').free,
           'workspace_available': psutil.disk_usage(ROOT).free}
    if pid is not None:
        try:
            proc = psutil.Process(pid)
            children = proc.children(recursive=True)
            row['rss'] = proc.memory_info().rss
            row['child_count'] = len(children)
            row['child_rss'] = sum(p.memory_info().rss for p in children if p.is_running())
            row['threads'] = proc.num_threads()
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            row['process_sample_unavailable'] = True
    for name in ('memory.events', 'memory.current', 'memory.max'):
        try:
            row[name] = (Path('/sys/fs/cgroup') / name).read_text().strip()
        except OSError as exc:
            row[name] = type(exc).__name__
    return row


cmd = [PYTHON, '-m', 'pytest', '-q', '-p', 'no:cacheprovider', '-p', 'phase_receipts',
       '--basetemp=/tmp/patchtrace-2bad-full-temp', '--junitxml=' + str(OUT / 'results.xml')]
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', QT_QPA_PLATFORM='offscreen',
           PYTHONUNBUFFERED='1', PYTHONPATH='/tmp/patchtrace-2bad-harness:' + str(ROOT / 'src'),
           PATCHTRACE_PHASE_LOG=str(OUT / 'phases.jsonl'))
receipt = {'command': cmd, 'started_at': utc(), 'source_before': source(),
           'resource_before': resources(), 'timeout_policy': 'No launcher timeout; observe child exit.'}
(OUT / 'start.json').write_text(json.dumps(receipt, indent=2) + '\n')
started = time.monotonic()
print(json.dumps({'started': receipt['started_at'], 'head': receipt['source_before']['head']}), flush=True)
with (OUT / 'stdout.log').open('wb') as log, (OUT / 'resources.jsonl').open('w', buffering=1) as samples:
    child = subprocess.Popen(cmd, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT)
    while child.poll() is None:
        samples.write(json.dumps(resources(child.pid)) + '\n')
        time.sleep(10)
    receipt.update(returncode=child.returncode, elapsed_seconds=time.monotonic() - started,
                   completed_at=utc(), source_after=source(), resource_after=resources(),
                   child_high_water_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
receipt['source_unchanged'] = receipt['source_before'] == receipt['source_after']
receipt['stdout_sha256'] = hashlib.sha256((OUT / 'stdout.log').read_bytes()).hexdigest()
receipt['junit_present'] = (OUT / 'results.xml').exists()
(OUT / 'completion.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt), flush=True)
print((OUT / 'stdout.log').read_text(errors='replace')[-12000:], flush=True)
raise SystemExit(child.returncode if child.returncode >= 0 else 128 - child.returncode)
