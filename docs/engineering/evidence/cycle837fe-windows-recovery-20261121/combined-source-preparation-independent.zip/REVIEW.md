# Independent review of root-authored combined preparation

**The helper rebind is correct within this review's scope. Application remains blocked.**
This is review of root-authored preparation, not independent clearance of my
Ghidra implementation. C1 retains native-code and final assembled-record review.

## Exact reviewed inputs

- Helper `7f8026469f7b5251236fef89384ce4eb70b722c20ee3988e77e229109a926260`.
- Preserved Windows-only helper `3e79cb7b105939c433db86415e136365f08459e40d33e0834f5a587aae85b834`.
- Context `e727cfe9112d373d7b58cc32595ba3f92aa19c6e036ac12dbfdfa817bf3194a8`.
- Draft report `e43a9c3e2c6d88eb8be4e1d073a5936387deeb271b0c8999116204ada99ad6c9`.

Snapshots and their complete binding manifest are retained. This verdict does not
extend automatically to a subsequently edited context/report/helper.

## Verified preservation and source binding

The helper targets `f596471b8909ec8e28e0624041d60f03d520591d`, tree
`dffeed541749850ef54a130cec0fa56c0fd2f01c`. Read-only Git checks confirm exact
`1c70cd5f → 88df8cfb → f596471b` ancestry and the four-path net delta.
The Windows review stays bound to `1c70cd5f`, tree `a39d650c`; a separate native
review must name the corrective child/tree with no blockers. These checks bind
identities and scope; they do not independently assess the native implementation.

Removing only the intended binding constants and component-review block from
the comparison leaves the prior helper bytes identical. Existing actual-Git
promotion guards and the entire ledger/history/output logic are preserved.
The merge guard still requires PR351's reviewed source/tree, a fetched commit
object, exact ordered parents/tree and both holds in subject and body.

The ledger baseline remains 104 unique task IDs and 46 notes. Deepcopy/before-row,
order/history, unrelated-field and evidence-digest guards remain intact. All
37 prior evidence inputs remain identical; five are appended. Seven prior task
drafts retain all fields except the archive-assessment next_action, which now
points to separate native qualification while retaining the import-only
assessment as historical and BLOCKED. One new draft makes eight. The Windows
component results/review are retained exactly and are not attributed to the
combined source. The original 181/16 census remains unchanged.

## Blocked preparation and concrete evidence gap

The reviewed context has `apply_authorized_now=false`, nonempty blockers,
`release_ready=false`, `main_merge_eligible=false`, pending independent native
review and pending exact combined root qualification. The report still has
actual-merge, combined mapping and qualification placeholders. No actual PR351
merge or combined remote mapping is established by this review. All 27 PowerShell
cases are still explicitly required on Windows: 17 artifact and 10 archive cases.

**Before unblocking, append the corrected-child evidence.** The f596 task's native
links/static inputs currently point only to the original88 archive, candidate and
preservation proof. Retain those originals and add the f596 repair archive,
candidate/proof, terminal-LF finding and independent corrected-child review as
appropriate. This is an assembly evidence gap, not a source-code finding. Root
was notified; no context/helper/repository edit was made here.

## Bounded controls

Twenty-eight detached controls used the exact root-helper guard blocks: two
explicitly authored positive fixtures and 26 expected refusals. They cover wrong
component heads/trees/blockers, altered parent chains/path sets, promotion identity,
commit type, Git tree/parents and publication markers. The synthetic positive
merge is deliberately not an actual PR351 receipt. Running the complete helper
snapshot without `--apply` on the blocked context refused with
`Prerequisites incomplete` before record generation; the source remained clean.

No product suite, native/PowerShell/target, CI or remote operation ran. An initial
proof-script assumption that all prior draft next_action text and evidence-list
length were unchanged failed; its record is retained. Inspection accounted for
the one intentional next_action edit and five appended inputs before the final
controls passed. No assertion or root guard was weakened.

Final assembly remains subject to actual promotion/qualification evidence,
current context binding, and C1's separate final-record review.
