"""Review root-authored preparation snapshots; no record application or source edit."""
from __future__ import annotations

import ast
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import textwrap

ROOT = Path('/workspace/scratch/837fe19aae3a')
HERE = Path(__file__).resolve().parent
REPO = ROOT / 'repair-live-ghidra-archive'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


old = (HERE / 'helper-before-ghidra.py').read_text()
new = (HERE / 'helper-reviewed.py').read_text()
context = json.loads((HERE / 'context-reviewed.json').read_text())
prior = json.loads((HERE / 'context-before-ghidra.json').read_text())
report = (HERE / 'report-reviewed.md').read_text()
start = "    review = context['independent_windows_review']\n"
end = "    original_raw = (repo / LEDGER).read_bytes()\n"
source_constants = ('SOURCE = ', 'TREE = ', 'NATIVE_ORIGINAL = ', 'WINDOWS_SOURCE = ', 'WINDOWS_TREE = ')


def without_binding_constants(text):
    return ''.join(line for line in text.splitlines(keepends=True) if not line.startswith(source_constants))


assert without_binding_constants(old[:old.index(start)]) == without_binding_constants(new[:new.index(start)])
assert old[old.index(end):] == new[new.index(end):]
constants = {
    node.targets[0].id: ast.literal_eval(node.value)
    for node in ast.parse(new).body
    if isinstance(node, ast.Assign) and len(node.targets) == 1
    and isinstance(node.targets[0], ast.Name) and isinstance(node.value, ast.Constant)
}
head = 'f596471b8909ec8e28e0624041d60f03d520591d'
original = '88df8cfbe51f91a6bc08c6863cd5d63f86500ca0'
windows = '1c70cd5f8053f75c269da673a24a82f221180650'
assert constants['SOURCE'] == head and constants['TREE'] == 'dffeed541749850ef54a130cec0fa56c0fd2f01c'
assert constants['NATIVE_ORIGINAL'] == original and constants['WINDOWS_SOURCE'] == windows
assert constants['WINDOWS_TREE'] == 'a39d650ca7fa2b41ece017ea492396722a4142d9'
chain = git('rev-list', '--reverse', '--first-parent', windows + '..' + head).decode().splitlines()
assert chain == [original, head]
assert git('show', '-s', '--format=%P', original).decode().strip() == windows
assert git('show', '-s', '--format=%P', head).decode().strip() == original
assert git('rev-parse', head + '^{tree}').decode().strip() == constants['TREE']
assert git('rev-parse', windows + '^{tree}').decode().strip() == constants['WINDOWS_TREE']
paths = git('diff', '--name-only', windows, head).decode().splitlines()
assert set(paths) == {
    '.github/workflows/live-backend.yml', 'docs/specs/REGISTRY.md',
    'docs/specs/windows-acceptance-and-milestone-builds.md', 'tests/test_live_ghidra_archive.py',
}
ledger_bytes = git('show', head + ':docs/engineering/task-ledger.json')
assert ledger_bytes == git('show', windows + ':docs/engineering/task-ledger.json')
ledger = json.loads(ledger_bytes)
assert len(ledger['tasks']) == 104 and len(ledger['notes']) == 46
assert len({task['id'] for task in ledger['tasks']}) == 104
assert context['apply_authorized_now'] is False and context['blockers']
assert context['release_ready'] is False and context['main_merge_eligible'] is False
assert context['independent_windows_review'] == prior['independent_windows_review']
assert context['current_recovery_qualification']['windows_component_qualification'] == prior['current_recovery_qualification']
assert context['prior_windows_only_preparation']['qualification'] == prior['current_recovery_qualification']
assert context['prior_windows_only_preparation']['source_count_transfer'] is False
assert context['current_recovery_qualification']['exact_combined_selection'] == 'PENDING'
assert context['independent_ghidra_review']['blockers'] and context['independent_ghidra_review']['verdict'] == 'PENDING'
ids = context['proposed_new_task_ids']
assert ids == [task['id'] for task in context['additional_tasks']]
assert len(ids) == len(set(ids)) == 8 and not set(ids) & {task['id'] for task in ledger['tasks']}
assert context['original_census'] == {'unmatched': 181, 'patch_equivalent': 16, 'rewrite': False}
assert context['reviewed_legacy_reconciliation']['baseline_ledger_sha256'] == sha(ledger_bytes)
assert 'verified_pr351_promotion' not in context
assert all(placeholder in report for placeholder in (
    '<ACTUAL_PR351_MERGE>', '<COMBINED_REMOTE_CODE>', '<COMBINED_SOURCE_QUALIFICATION>',
))
assert 'All 27 PowerShell fixtures' in report
restored_drafts = deepcopy(context['additional_tasks'][:-1])
assert restored_drafts[5]['id'] == '837fe-ghidra-archive-acceptance-assessment'
changed_next_action = restored_drafts[5]['next_action']
assert 'historical and BLOCKED' in changed_next_action
restored_drafts[5]['next_action'] = prior['additional_tasks'][5]['next_action']
assert restored_drafts == prior['additional_tasks']
old_inputs = {item['destination']: item for item in prior['static_evidence_inputs']}
new_inputs = {item['destination']: item for item in context['static_evidence_inputs']}
assert len(new_inputs) == len(context['static_evidence_inputs'])
assert old_inputs.keys() <= new_inputs.keys()
assert all(new_inputs[name] == item for name, item in old_inputs.items())
added_inputs = {name: item for name, item in new_inputs.items() if name not in old_inputs}
assert len(added_inputs) == 5
for item in added_inputs.values():
    data = (ROOT / item['source']).read_bytes()
    assert len(data) == item['bytes'] and sha(data) == item['sha256']
assert not any('/live-ghidra-archive-pin-repair/' in item['source'] for item in new_inputs.values())


def check(condition, message):
    if not condition:
        raise RuntimeError(message)


# Execute only the exact detached root-authored validation blocks. Git responses
# are constructed/read-only fixtures; no records are assembled or written.
namespace = {**constants, 'check': check, 're': re}
component_source = textwrap.dedent(new[new.index(start):new.index(end)])
promotion_start = "    promotion = context['verified_pr351_promotion']\n"
promotion_source = textwrap.dedent(new[new.index(promotion_start):new.index(start)])
(HERE / 'detached-component-guard.txt').write_text(component_source)
(HERE / 'detached-promotion-guard.txt').write_text(promotion_source)
component_code = compile(component_source, 'root-helper-component-guard', 'exec')
promotion_code = compile(promotion_source, 'root-helper-promotion-guard', 'exec')
controls = []


def exercise(label, code, document, responses, rejection=None):
    def read_fixture(*args):
        assert args in responses, ('Unexpected Git request', args)
        return responses[args]
    try:
        exec(code, {**namespace, 'context': document, 'git': read_fixture})
    except RuntimeError as exc:
        assert rejection is not None and rejection in str(exc), (label, str(exc), rejection)
        controls.append({'id': label, 'outcome': 'expected-refusal', 'reason': str(exc)})
    else:
        assert rejection is None, ('Missing refusal', label)
        controls.append({'id': label, 'outcome': 'accepted-authored-fixture'})


component = {
    'independent_windows_review': {'head': windows, 'tree': constants['WINDOWS_TREE'], 'blockers': []},
    'independent_ghidra_review': {'head': head, 'tree': constants['TREE'], 'blockers': []},
}
responses = {
    ('show', '-s', '--format=%P', original): (windows + '\n').encode(),
    ('show', '-s', '--format=%P', head): (original + '\n').encode(),
    ('rev-list', '--reverse', '--first-parent', windows + '..' + head): ('\n'.join(chain) + '\n').encode(),
    ('rev-parse', windows + '^{tree}'): (constants['WINDOWS_TREE'] + '\n').encode(),
    ('diff', '--name-only', windows, head): ('\n'.join(paths) + '\n').encode(),
}
exercise('component-valid-identity-fixture', component_code, component, responses)
for kind, field, value, message in (
    ('independent_windows_review', 'head', head, 'Wrong Windows component review'),
    ('independent_windows_review', 'tree', constants['TREE'], 'Wrong Windows component review'),
    ('independent_windows_review', 'blockers', ['pending'], 'Wrong Windows component review'),
    ('independent_ghidra_review', 'head', original, 'Wrong Ghidra component review'),
    ('independent_ghidra_review', 'tree', constants['WINDOWS_TREE'], 'Wrong Ghidra component review'),
    ('independent_ghidra_review', 'blockers', ['pending'], 'Wrong Ghidra component review'),
):
    altered = deepcopy(component)
    altered[kind][field] = value
    exercise(kind + '-' + field, component_code, altered, responses, message)
for label, request, replacement, message in (
    ('wrong-original-parent', ('show', '-s', '--format=%P', original), b'wrong\n', 'Combined source must retain'),
    ('wrong-corrective-parent', ('show', '-s', '--format=%P', head), b'wrong\n', 'Combined source must retain'),
    ('extra-first-parent', ('rev-list', '--reverse', '--first-parent', windows + '..' + head),
     ('\n'.join([original, 'a' * 40, head]) + '\n').encode(), 'Unexpected combined source history'),
    ('wrong-windows-tree', ('rev-parse', windows + '^{tree}'), b'wrong\n', 'Windows source tree mismatch'),
    ('extra-net-path', ('diff', '--name-only', windows, head),
     ('\n'.join(paths + ['src/unexpected.py']) + '\n').encode(), 'Unexpected combined source changes'),
    ('missing-net-path', ('diff', '--name-only', windows, head),
     ('\n'.join(paths[:-1]) + '\n').encode(), 'Unexpected combined source changes'),
):
    exercise(label, component_code, component, {**responses, request: replacement}, message)

# This deliberately synthetic merge is not any actual PR351 promotion receipt.
merge = 'e' * 40
actual_parents = ['9023761a4066ac1c50c127ac09d0ba5f56cdc9e4', constants['PRIOR']]
promotion = {
    'merged': True, 'pr_number': 351, 'source_head': constants['PRIOR'],
    'source_tree': constants['PRIOR_TREE'], 'actual_tree': constants['PRIOR_TREE'],
    'actual_parents': actual_parents, 'all_applicable_automated_jobs_passed': True,
    'opt_outs_verified': True, 'merge_commit': merge,
}
header = 'tree ' + constants['PRIOR_TREE'] + '\n' + ''.join('parent ' + value + '\n' for value in actual_parents)
message = 'Authored synthetic merge [no release] [no deploy]\n\nAuthored body [no release] [no deploy]\n'
promotion_responses = {('cat-file', '-t', merge): b'commit\n', ('cat-file', 'commit', merge): (header + '\n' + message).encode()}
exercise('promotion-valid-authored-fixture', promotion_code, {'verified_pr351_promotion': promotion}, promotion_responses)
for field, value, reason in (
    ('merged', False, 'Actual PR351 merge proof required'),
    ('pr_number', 352, 'Actual PR351 merge proof required'),
    ('source_head', head, 'Wrong qualified source'),
    ('source_tree', constants['TREE'], 'Wrong qualified source'),
    ('actual_tree', constants['TREE'], 'Actual ancestry/tree mismatch'),
    ('actual_parents', actual_parents[::-1], 'Actual ancestry/tree mismatch'),
    ('all_applicable_automated_jobs_passed', False, 'Qualification missing'),
    ('opt_outs_verified', False, 'Qualification missing'),
    ('merge_commit', '<ACTUAL_PR351_MERGE>', 'Invalid actual merge identity'),
):
    altered = {**promotion, field: value}
    exercise('promotion-' + field, promotion_code, {'verified_pr351_promotion': altered}, promotion_responses, reason)
for label, responses_change, reason in (
    ('non-commit-object', {('cat-file', '-t', merge): b'tag\n'}, 'Actual merge must name a fetched commit object'),
    ('git-tree-mismatch', {('cat-file', 'commit', merge): (header.replace(constants['PRIOR_TREE'], 'a' * 40) + '\n' + message).encode()}, 'Git merge tree mismatch'),
    ('git-parent-mismatch', {('cat-file', 'commit', merge): (header.replace(actual_parents[0], 'a' * 40) + '\n' + message).encode()}, 'Git merge ordered parents mismatch'),
    ('holds-only-in-subject', {('cat-file', 'commit', merge): (header + '\nAuthored [no release] [no deploy]\n\nNo holds here\n').encode()}, 'Actual merge subject and body must each retain'),
    ('holds-only-in-body', {('cat-file', 'commit', merge): (header + '\nAuthored subject\n\n[no release] [no deploy]\n').encode()}, 'Actual merge subject and body must each retain'),
):
    exercise(label, promotion_code, {'verified_pr351_promotion': promotion}, {**promotion_responses, **responses_change}, reason)

before_status = git('status', '--porcelain=v1')
assert not before_status.strip()
command = [sys.executable, '-I', '-B', str(HERE / 'helper-reviewed.py'), '--repo', str(REPO), '--context', str(HERE / 'context-reviewed.json')]
blocked = subprocess.run(command, cwd=ROOT, capture_output=True, text=True, timeout=30, check=False)
(HERE / 'blocked-helper.stdout.txt').write_text(blocked.stdout)
(HERE / 'blocked-helper.stderr.txt').write_text(blocked.stderr)
assert blocked.returncode != 0 and 'Prerequisites incomplete' in blocked.stderr
assert not blocked.stdout
assert git('status', '--porcelain=v1') == before_status

result = {
    'scope': 'Root-authored helper/context/report preparation only; no independent clearance of reviewer-authored implementation',
    'helper_sha256': sha(new.encode()), 'source': head, 'tree': constants['TREE'],
    'preexisting_actual_git_merge_guards_unchanged': True,
    'all_ledger_history_output_guard_bytes_unchanged': True,
    'exact_local_source_chain': [windows, original, head], 'net_changed_paths': paths,
    'baseline_ledger_sha256': sha(ledger_bytes), 'baseline_tasks': 104, 'baseline_notes': 46,
    'prior_windows_review_and_qualification_retained_exactly': True,
    'prior_task_draft_change_only': {'task': restored_drafts[5]['id'], 'field': 'next_action', 'after': changed_next_action},
    'prior_evidence_inputs_preserved_exactly': len(old_inputs), 'added_evidence_inputs': list(added_inputs.values()),
    'draft_count': 8, 'apply_authorized_now': False, 'exact_combined_result': 'PENDING',
    'required_windows_powershell_cases': 27,
    'actual_pr351_promotion_verified_by_this_review': False,
    'combined_remote_mapping_verified_by_this_review': False,
    'detached_guard_controls': controls,
    'blocked_full_helper': {'argv': command, 'exit_code': blocked.returncode, 'reason': 'Prerequisites incomplete', 'apply_argument': False, 'source_status_before_after': ''},
    'pre_apply_evidence_gap': 'The f596 draft links only original88 native evidence; append corrected-child archive/candidate/proof and independent review without replacing88.',
    'initial_control_failure': 'initial-control-failure.json preserves the overbroad equality assumption; exact intentional next_action and five appended evidence inputs are now accounted.',
    'execution': {'product_tests': 0, 'PowerShell_native_target_execution': False, 'record_application': False, 'source_helper_context_edits': False, 'CI_or_remote_operations': False},
}
(HERE / 'review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'detached_controls': len(controls), 'accepted_authored_fixtures': sum(c['outcome'] == 'accepted-authored-fixture' for c in controls), 'expected_refusals': sum(c['outcome'] == 'expected-refusal' for c in controls), 'blocked_helper_exit': blocked.returncode, 'source_unchanged': True, 'pre_apply_evidence_gap': result['pre_apply_evidence_gap']}, indent=2))
