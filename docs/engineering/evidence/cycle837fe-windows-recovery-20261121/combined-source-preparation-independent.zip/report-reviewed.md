# Windows publication recovery and historical reconciliation — 2026-11-21

This is the prepublication record checkpoint for the next Windows recovery candidate. Reviewed Windows component code is local `1c70cd5f8053f75c269da673a24a82f221180650`, tree `a39d650ca7fa2b41ece017ea492396722a4142d9`, mapped to `0fd52f47f1d9c161d2c74746365c90b94e567985`. The combined successor adds the Ghidra original-archive adaptation at local `f596471b8909ec8e28e0624041d60f03d520591d`, tree `dffeed541749850ef54a130cec0fa56c0fd2f01c`, mapped to `<COMBINED_REMOTE_CODE>`. Final records publication, exact-source hosted qualification, and the next guarded main merge remain pending at this checkpoint. Release readiness is false.

## Prior qualified promotion

PR351 promoted `d6679abc6dfddbadce0391c8d18289f7f96338d6` to actual main commit **<ACTUAL_PR351_MERGE>**. The fetched actual Git commit has ordered parents `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4` and `d6679abc6dfddbadce0391c8d18289f7f96338d6`, and complete tree `6001ef506c38930fd590bd827f428b997c3b2797`, identical to the reviewed PR head and tested synthetic merge `a93005c69fe6091b940d7bc9ad1f5a38542e6e71`. The REST merge used the expected-head guard. Both actual commit subject and body contain `[no release] [no deploy]`.

<PR351_QUALIFICATION_SUMMARY>

<POST_PR351_PAGES_STATUS>

Only the two actually applicable PR351 workflows are attributed to that source. Other primary native lanes belong to the earlier qualified source and are not relabeled as fresh PR351 runs. No manual workflow dispatch or rerun was used to inflate coverage. Source completion remains distinct from wider release acceptance.

Evidence: [actual promotion](evidence/cycle837fe-windows-recovery-20261121/pr351-merge-proof.json), [PR351 qualification](evidence/cycle837fe-windows-recovery-20261121/pr351-final-qualification.json), [sealed PR351 receipts](evidence/cycle837fe-windows-recovery-20261121/pr351-qualification-evidence.zip).

## Recovered behavior and source identities

| Change | Local source | Equivalent remote source | Complete tree |
|---|---|---|---|
| Publication concurrency and required upload | `c4eb63c55a35a1c2a927f4aeb4d42c8b96ff45ff` | `a24d2aa08852eb6c48214155af3fbf8ceafcb48b` | `561befcde425c5de07e113128dc79c21b7616772` |
| Downloaded Windows artifact validation | `1c70cd5f8053f75c269da673a24a82f221180650` | `0fd52f47f1d9c161d2c74746365c90b94e567985` | `a39d650ca7fa2b41ece017ea492396722a4142d9` |

The first recovery adapts compatible controls from `claude/awesome-ramanujan-o3pxx3-ci` at `0bf1f8309e8425ba34199657009d3055215336f1`. Non-PR workflow runs have a unique run-ID concurrency group and are not canceled by a later run. PR updates keep their cancellation behavior. The required Windows upload fails when none of its declared paths resolves to a file; the later downloaded-artifact gate requires all four members. All existing jobs, triggers, immutable Action pins, Qt gates and publication holds remain intact.

The second recovery adds `windows-validate`, which depends on `qa`, uses a separate Windows runner job, and downloads the named `PatchTrace-windows-x64` artifact from the same workflow run. It requires the portable ZIP, installer EXE and both sidecars to be regular non-reparse files. Both sidecars must contain one strictly formed SHA-256 record with the exact expected basename. Both payload hashes must match before either acceptance script runs. The job then executes the unchanged portable and installer scripts against those downloaded bytes.

The new job installs no Python, application dependencies, NSIS or build environment. It is an additional hosted runner job, not a claim of a pristine Windows installation. The existing builder retains its entire 64-check frozen CLI suite; the downloaded job runs the existing portable and installer acceptance scripts and does not repeat all 64 checks. Release additionally depends on `windows-validate`; its prior dependencies and exact publication condition remain unchanged. Removing that new job and needs entry restores the preceding workflow byte for byte.

The reviewed code changes no runtime engine or user-data implementation. [Code mapping](evidence/cycle837fe-windows-recovery-20261121/code-publication-mapping.json), [actual Git object verification](evidence/cycle837fe-windows-recovery-20261121/code-git-object-verification.json), and the [two-commit source bundle](evidence/cycle837fe-windows-recovery-20261121/local-recovery-source.bundle) preserve local/remote provenance. The bundle requires the earlier local `2ae1bbad2ad9cc78c29541872381750e347c670e` baseline, whose tree equals published `d6679abc`.

## Source verification and independent audit

| Exact source and scope | Author result | Independent result | Limits |
|---|---|---|---|
| `c4eb63c5` concurrency/upload | 368 passed, 2 strict CODEX-5 xfailed; eight intended parent failures | Same overlapping 368/2; 101 source/evidence checks and 19 controls | No new hosted scheduler qualification inferred |
| `1c70cd5f` combined workflow/scanner/package contracts | 415 passed, 17 explicitly skipped without `pwsh`, 2 strict CODEX-5 xfailed; 434 cases | Same overlapping 415/17/2; 140 source/evidence checks, 27 separate shell/upstream checks, 35 in-memory controls (2 valid, 33 refused) | All 17 PowerShell fixtures still require actual Windows execution |
| Current documentation proposals | Exact three proposals | 210 source/evidence checks | Final report links and assembly checked separately |
| Record preparation | Actual-Git promotion and history guards | 61 parent checks and 25 preservation checks; 14 detached controls included. Extension: 24 checks and 20 detached controls | Preparation is not final assembled-record clearance |

Whole-tree Ruff, package dependency check and isolated editable source binding passed for frozen `1c70cd5f`. Five new workflow tests fail against unchanged parent `c4eb63c5`. PowerShell fixtures execute only the exact inline verifier on inert authored bytes: three accepted record formats, four missing-member cases, two altered payloads, two incorrect names/cases and six malformed records. They never extract or execute a target binary. Missing PowerShell on Windows is a failure, while its absence on this Linux host is explicitly skipped.

Preserved failures include the author's initial test collection syntax error, the independent reviewer’s initial tools-namespace collection error, and the earlier concurrency test path-boundary failure. They are retained before the corrected results. Earlier interrupted full-suite attempts, native/platform failures and historical donor failures remain in their original evidence. No limits were raised, expected-failure assertions weakened, or failures reclassified as passes.

The current bounded pip census is 21 workflows, 203 `run` scalars, 42 explicit installs and 41 lacking a recognized per-command hash flag. The earlier 200-scalar observations remain historical source receipts. The two strict CODEX-5 expected failures remain open; this source audit does not establish transitive artifact/hash closure.

See [Windows author archive](evidence/cycle837fe-windows-recovery-20261121/windows-artifact-author.zip), [independent review](evidence/cycle837fe-windows-recovery-20261121/windows-artifact-independent-review.json), [concurrency review](evidence/cycle837fe-windows-recovery-20261121/concurrency-independent-review.json), [document review](evidence/cycle837fe-windows-recovery-20261121/document-proposals-independent-review.json), and [helper extension review](evidence/cycle837fe-windows-recovery-20261121/helper-ledger-extension-independent-review.json).

## Existing native workflow: original Ghidra archive adaptation

The separate four-path adaptation at `88df8cfbe51f91a6bc08c6863cd5d63f86500ca0` retains only `ghidra-archive/ghidra.zip` through the existing pinned cache Action and namespace. It downloads only if the archive is absent, checks the pinned SHA-256 on every path before changing the old extraction, and extracts that same verified ZIP into a fresh runtime directory. A corrupt restored archive fails without silently downloading a replacement. All twelve other steps, five authored native cases, commands, assertions, triggers, permissions, limits and native helpers remain unchanged. The existing Tier R import-only path is unchanged.

Author qualification on this source was 260 passed / 9 explicit no-PowerShell skips / 2 strict CODEX-5 xfails, with 271 distinct cases in seven modules. Three intended parent failures reproduced the missing retention/fresh-extraction/conditional-download controls. Initial harness failures remain preserved. Independent review identified terminal-LF acceptance before download. Corrective child `f596471b8909ec8e28e0624041d60f03d520591d` retains88 as parent, uses absolute full-value anchors, and adds a terminal-LF no-download/runtime/export fixture. Corrected qualification:260 passed/10 no-PowerShell skipped/2 strict CODEX-5 xfailed,272 cases. New parent regression:one failed,three passed,ten unavailable-PowerShell skips. The fixed literal was valid and digest verification protected extraction throughout. <COMBINED_SOURCE_QUALIFICATION>

The ten additional PowerShell fixtures must execute on Windows alongside the seventeen downloaded-package fixtures. Actual hosted native runs must record whether the archive cache was hit or missed, whether an original archive was saved, and whether its checksum passed before fresh extraction and native analysis. A records-only push does not satisfy the native workflow path filter. Cache visibility/version across refs and operating systems must be observed, not inferred. Each unobserved cold/warm mode remains open; fixture and raw-analysis-cache successes cannot substitute for original-archive cache receipts.

See the [native adaptation author archive](evidence/cycle837fe-windows-recovery-20261121/live-ghidra-archive-author.zip) and [source preservation proof](evidence/cycle837fe-windows-recovery-20261121/live-ghidra-archive-source-proof.json).

## Complete historical branch accounting

| Branch and exact head | Exact merge base | Classification | Bounded conclusion |
|---|---|---|---|
| `claude/awesome-ramanujan-o3pxx3-ci` — `0bf1f8309e8425ba34199657009d3055215336f1` | `99f8328ce89d02f200cf9fbc5852d9801761af28` | PORT, partial | All 11 paths accounted; compatible controls recovered separately; old exact build/dev pins remain unvalidated |
| `claude/awesome-ramanujan-o3pxx3-win1` — `7ac57759f3b9b332eaafb48c82f366566892f1b1` | `99f8328ce89d02f200cf9fbc5852d9801761af28` | SUPERSEDED | All 13 paths accounted; 30/43 symbols AST-identical, remaining behavior retained or strengthened |
| `feat/artifact-bytes-seam` — `91b35d09afd29e9c78169a3b095d9ea3be6c31b1` | `f0086f797556afca5848c2b68a3819be5c0c0064` | SUPERSEDED | All four paths accounted; maintained reader has stronger content and short-read verification |
| `feat/byte-representations` — `303bc452d0bb6cd46ee67f731f64ec951e1ee215` | `0ec471016d2838a90753e014a0d647dd90168e87` | SUPERSEDED | All eight paths accounted; five implementation modules byte-identical |
| `codex/windows-setup-installer-20261017` — `9c5fe67bd10a5d1342440bb8ea6a524cca3ce1f2` | `04d57c72eced716b6c163d29f80b6cd5543c6582` | SUPERSEDED | All 31 nonmerge commits plus one merge, 13 net paths and 14 historical paths accounted, including retired Inno script |

CI and WIN1 review retained 65 source snapshots and 41 introduced Git objects, with 314 independent checks. Maintained tests passed 198 cases; original CI tests had five passes and seven disclosed failures; original WIN1 tests had 33 passes and two failures from the stronger current checker API. Counts overlap.

Byte-reader/representation review retained 26 source snapshots and 27 introduced objects; 206 independent checks plus 20 separate representation checks passed. Maintained 81 and original donor 70 passes overlap. Initial missing-temporary-parent harness failures remain preserved. These two heads belong to the original **16 patch-equivalent** bucket, not the **181 unmatched** bucket.

Installer history retained 41 snapshots and 135 introduced objects; 499 independent checks passed. Its NSIS script and both PowerShell acceptance scripts are byte-identical to the maintained source. The retired Inno file is preserved as history, not restored. A destructive historical QA truncation is explicitly rejected while the donor blob remains archived. Four original tests passed on both donor and current helpers; the current five-test result overlaps those checks. This source/history review executed no native installer.

These are complete reviews of the five named branches, not a claim that all historical branches are exhausted. The original 181/16 census, prior classifications and all branch refs remain preserved. [CI/WIN1 review](evidence/cycle837fe-windows-recovery-20261121/historical-packaging-independent-review.json), [reader/representation review](evidence/cycle837fe-windows-recovery-20261121/historical-integrity-independent-review.json), and [installer review](evidence/cycle837fe-windows-recovery-20261121/historical-installer-independent-review.json) contain the source-bound details and unchanged original receipts.

## Actual main902 evidence and truthful record reconciliation

The earlier actual main commit `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4` completed its automatic QA and native runs separately from PR351. Its full Linux result was 24,190 passed / 53 skipped / 3 xfailed; Windows was 24,059 passed / 185 skipped / 2 xfailed. Both JUnit artifacts contain 24,246 cases with zero failures/errors. All five Qt gates passed. Windows builder-side frozen64, portable and NSIS install/uninstall checks passed; the same Linux distribution passed 64 frozen checks after extraction on each Ubuntu22.04/24.04 job.

Main902’s release-gate output was `publish=true`; the independent commit-message condition skipped the actual release job. The automatic Pages configuration step failed with its retained 404 after successful site tests/build, and deployment skipped. Those outcomes are not rewritten by the later Pages source repair. Main902’s Tier R rizin archive cache had one miss/save followed by one hit; the earlier primary source had two hits. Both used verified original archive hashes. Ghidra provisioning remained skipped. Native warning/result limits remain explicit, including Tier R’s five completed of eleven with six tiny-input failures.

Nine small artifacts were locally digest/CRC verified. Large product archives have API/upload-digest evidence and were not downloaded locally. [Sealed main902 evidence](evidence/cycle837fe-windows-recovery-20261121/main902-postmerge-evidence.zip) and [summary](evidence/cycle837fe-windows-recovery-20261121/main902-postmerge-qualification.json) remain immutable.

This checkpoint preserves the existing 104 task IDs/order, 46 notes and all prior histories. It promotes the two existing CODEX-5/Pages task rows and the current CODEX-5 follow-up object after actual PR351 promotion, preserving their complete before state. Separately, it adds eight scoped tasks and reconciles exactly seven fields in three legacy rows: Buildenv becomes MERGED; aggregate historical packaging gates remain BLOCKED; aggregate registered-header work remains TESTING. The bounded eight Strings, six Search and five Buildenv mappings are qualified; other panels and native accessibility remain open. Original 90-site/8-ID and 391-pass observations remain historical.

Complete before rows and the previous ledger are retained. Existing handoff, QA and TODO prose remains an exact suffix behind a new current checkpoint. The dated package-audit remains an exact prefix. Current Windows instructions now name NSIS3.13 and the real Windows Apps/installed `Uninstall.exe` entry points. The release-process Pipeline section describes the actual jobs and checksum sequence. [Ledger reconciliation review](evidence/cycle837fe-windows-recovery-20261121/legacy-ledger-independent-review.json), [normalized proposal](evidence/cycle837fe-windows-recovery-20261121/normalized-ledger-proposal.json), and [prior ledger](evidence/cycle837fe-windows-recovery-20261121/prior-ledger-d667.json) preserve the changes and limits.

## Remaining qualification and next actions

The next integration must preserve both reviewed Windows commits, their native-archive successor, and actual PR351 main ancestry. Final records need independent review, followed by a fresh PR/head/tree binding and all applicable automatic full-suite, Qt, Windows build, downloaded-Windows, Linux frozen and original-archive native checks. All 27 PowerShell fixtures (17 downloaded-package and ten original-archive controls) must run on Windows; skipped Linux fixtures cannot substitute for that acceptance. After those gates pass, use the REST merge mechanism with the expected final head and both publication markers in subject and body.

Broader release gates remain open: repository-wide dependency/hash closure; actual Ghidra original-archive cold/warm provisioning; full native engine/corpus coverage; clean Windows/manual accessibility/DPI/trust/signing acceptance; offline bundle/provenance limits; and unverified L1/L2/L3 accuracy scopes. The original archive assessment found an import-only Ghidriff provider, absent fresh-store producer, success-dependent cold-cache save, and an existing workflow plan that cannot satisfy a wholly authored fixture scope. Raw-analysis-cache success does not close those archive gates. See the [archive assessment](evidence/cycle837fe-windows-recovery-20261121/ghidra-archive-plan.json).

The authoritative ledger and existing hourly continuation retain these next actions. No release, deployment, tag, force-push or historical branch deletion is part of this checkpoint. All included evidence bytes are indexed by the [manifest](evidence/cycle837fe-windows-recovery-20261121/manifest.json); this record does not invent its own future publication SHA or future successful merge.
