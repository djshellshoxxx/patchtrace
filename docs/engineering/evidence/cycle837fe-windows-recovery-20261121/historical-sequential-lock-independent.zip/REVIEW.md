# Independent sequential-lock branch disposition

**Clear for the bounded whole-branch disposition: SUPERSEDED.** No missing compatible contribution or blocker was found. This is a semantic accounting result, not a new native Windows acceptance or a claim that the donor tip is present by Git ancestry.

## Exact scope

| Identity | Reviewed value |
| --- | --- |
| Branch | `chatgpt/ghidriff-sequential-lock-fix-20261017` |
| Donor | `f6b7545bcc7a161440ab7119233c204510571370` |
| Donor tree | `af5312f2802e1ba926104df7df189549b5a63c0e` |
| Merge base | `70e33fd77570329ba23afc58a38616270636d37c` |
| Current source | `f596471b8909ec8e28e0624041d60f03d520591d` |
| Current tree | `dffeed541749850ef54a130cec0fa56c0fd2f01c` |
| Complete donor scope | Five linear unique commits, no unique merge commits, three net paths and three historical paths |

All five raw commit objects, complete patches, ordered parents, trees, changed-path sets and the full historical path union were independently compared with actual Git objects. Nineteen selected source snapshots match their Git blobs. The 23-object introduced-history pack verifies and contains exactly the expected object set. The standalone bounded donor fixture archive and all four 518-file source snapshots match Git blobs.

## Semantic retention

| Path | Finding |
| --- | --- |
| `src/patchtrace/backend.py` | The complete donor change is the sequential argv builder and call site plus raw adapter `/1` to `/2`. Reversing precisely those changes yields the complete base AST. Current direct and local launch paths share the same original argument suffix, including exactly one `--no-threaded`, and production passes the built argv to `run_process`. Adapter `/2` still enters `RuntimeFingerprint` and its serialized raw-cache key. Later unconditional isolation, executable-symlink preservation, local-symbol routing and optional force-diff preserve the donor behavior. |
| `tests/test_ghidriff_threading.py` | The entire current file equals the original four-mode fixture after replacing exactly one obsolete bundle-only isolation assertion with the current mandatory `-I -X utf8` assertion. Sequential count, lack of the enabling option, symbol-mode policy and option ordering remain. |
| `docs/qa/ghidriff-windows-lock-20261017.md` | The entire nine-line dated note is byte-identical. It preserves causal uncertainty and the required real Windows repeat/cancellation checks. Private incident logs were never committed and are not reconstructed. |

## Retained test evidence

The reviewer ran **zero product tests**. Existing source-bound receipts, stdout imports, XML outcomes, unchanged test bytes and invocation boundaries were independently checked. Counts overlap and must not be summed.

| Retained execution | Result | Interpretation |
| --- | --- | --- |
| First test-only commit | One collection error, exit 2 | Helper did not yet exist. |
| First implementation | 1 passed | Original helper fixture. |
| Intermediate refactor | One collection error, exit 2 | Old test still imported the removed helper. |
| Final donor tip | 4 passed | All original bundle/symbol combinations. |
| Unchanged donor test on current | 2 passed, 2 failed | Both failures are the old non-bundled isolation expectation; sequential and symbol assertions preceding it pass. |
| Maintained current fixture | 4 passed | Stronger unconditional interpreter isolation is expected. |
| Maintained adapter-version cache selector | 1 passed | Synthetic cache identity/invalidation fixture. |

The shared dependency environment was not rebound: the retained runner inserted the selected source and asserted the actual backend import path before pytest. This audit checked those source hashes against immutable Git objects. No Java, Ghidra, upstream engine, target, network download, full suite or additional native check was run.

## Integrity and accounting

The author archive is preserved unchanged as `author-original.zip`: **2,661,030 bytes, 90 members**, SHA-256 `907abba74b2de63202f138048266b4202a5d96e68549252c70342c737c63dfb1`. CRC, exact member set, manifest hash, all 89 payload hashes and equality with external retained files passed. All prior input snapshots match current Git bytes. The selected original inventory row matches its original source; the selected technical row matches the canonical compressed technical inventory included here.

The branch remains part of the original unmatched inventory, with five unmatched commits and no patch-equivalent commits. This named disposition preserves the historical **181 unmatched / 16 patch-equivalent** snapshot. It neither rewrites that census nor authorizes branch deletion, blanket ancestry claims or closure of unrelated native/product gates. The author’s failed metadata URL and discovery parse attempt remain inside the unchanged archive. A reviewer-only schema-selection assertion was corrected and retained in `review-harness-correction.json`; it was not a source or test failure.

**230 independent checks passed.** The comparison worktree stayed clean at the exact current source. No source, ledger, helper, ref, PR or CI mutation occurred. Actual PR351 qualification and the final assembled promotion-bound records remain separate reviews.
