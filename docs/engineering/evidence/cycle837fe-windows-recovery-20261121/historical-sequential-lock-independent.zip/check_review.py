"""Read-only object/evidence audit; writes only this independent evidence folder."""
from pathlib import Path
import ast
import copy
import datetime
import gzip
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/837fe19aae3a')
OUT = Path(__file__).parent
AUTHOR = ROOT / 'evidence/historical-after-f596-next-review'
REPO = ROOT / 'PatchTrace-windows-recovery-followup'
CURRENT = 'f596471b8909ec8e28e0624041d60f03d520591d'
DONOR = 'f6b7545bcc7a161440ab7119233c204510571370'
BASE = '70e33fd77570329ba23afc58a38616270636d37c'
BRANCH = 'chatgpt/ghidriff-sequential-lock-fix-20261017'
PATHS = ['docs/qa/ghidriff-windows-lock-20261017.md', 'src/patchtrace/backend.py', 'tests/test_ghidriff_threading.py']
CHECKS = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def oid(data, kind='blob'):
    return hashlib.sha1(f'{kind} {len(data)}\0'.encode() + data).hexdigest()

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def txt(*args):
    return git(*args).decode().strip()

def blob(commit, path):
    return git('show', f'{commit}:{path}')

def read(name):
    return json.loads((AUTHOR / name).read_text())

def check(name, condition, detail=None):
    CHECKS.append({'check': name, 'passed': bool(condition), 'detail': detail})
    if not condition:
        raise AssertionError(name)

def function(tree, name):
    return next(x for x in tree.body if isinstance(x, (ast.FunctionDef, ast.AsyncFunctionDef)) and x.name == name)

def assignment(tree, name):
    return next(x for x in ast.walk(tree) if isinstance(x, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in x.targets))

def dump(node):
    return ast.dump(node, include_attributes=False)

history = read('source-history.json')
classification = read('classification.json')
start_status = txt('status', '--porcelain=v1')
check('current complete tree', txt('rev-parse', CURRENT + '^{tree}') == 'dffeed541749850ef54a130cec0fa56c0fd2f01c')
check('donor complete tree', txt('rev-parse', DONOR + '^{tree}') == 'af5312f2802e1ba926104df7df189549b5a63c0e')
check('exact merge base', txt('merge-base', CURRENT, DONOR) == BASE)
commits = txt('rev-list', '--reverse', f'{CURRENT}..{DONOR}').splitlines()
check('entire unique five-commit list', commits == [x['sha'] for x in history['all_unique_commits']] == classification['unique_commits'] and len(commits) == 5)
check('no omitted unique merge commits', not txt('rev-list', '--merges', f'{CURRENT}..{DONOR}'))
check('entire net three-path list', txt('diff', '--name-only', BASE, DONOR).splitlines() == PATHS == history['net_changed_paths'])
historical_paths = set()
for row in history['all_unique_commits']:
    commit = row['sha']
    raw = git('cat-file', 'commit', commit)
    check(f'raw commit {commit}', raw == (AUTHOR / 'commits' / f'{commit}.txt').read_bytes() and oid(raw, 'commit') == commit and sha(raw) == row['raw_commit_sha256'])
    check(f'ordered parent/tree {commit}', txt('show', '-s', '--format=%P', commit) == row['parent'] and txt('rev-parse', commit + '^{tree}') == row['tree'])
    changes = txt('diff-tree', '--no-commit-id', '--name-status', '-r', commit).splitlines()
    check(f'complete per-commit paths {commit}', changes == row['changed_paths'])
    historical_paths.update(x.split('\t')[-1] for x in changes)
    patch = git('show', '--format=fuller', commit)
    check(f'complete retained patch {commit}', patch == (AUTHOR / 'commits' / f'{commit}.patch').read_bytes())
check('historical union includes all three paths', sorted(historical_paths) == PATHS == history['all_historical_changed_paths'])

snapshots = history['source_snapshots'] + read('current-cache-context-source.json')
check('all nineteen selected snapshots counted', len(snapshots) == 19)
for row in snapshots:
    actual = blob(row['commit'], row['path'])
    selected = AUTHOR / 'source' / row['commit'] / row['path']
    check(f"selected source {row['commit']}:{row['path']}", actual == selected.read_bytes() and len(actual) == row['bytes'] and sha(actual) == row['sha256'] and oid(actual) == row['blob'])

base_backend = ast.parse(blob(BASE, 'src/patchtrace/backend.py'))
donor_backend = ast.parse(blob(DONOR, 'src/patchtrace/backend.py'))
current_backend = ast.parse(blob(CURRENT, 'src/patchtrace/backend.py'))
check('adapter /1 to /2 preserved', assignment(base_backend, 'RAW_ADAPTER_VERSION').value.value == 'patchtrace-ghidriff-adapter/1' and assignment(donor_backend, 'RAW_ADAPTER_VERSION').value.value == assignment(current_backend, 'RAW_ADAPTER_VERSION').value.value == 'patchtrace-ghidriff-adapter/2')
base_run = function(base_backend, 'run_comparison')
base_argv = assignment(base_run, 'argv')
base_symbol_if = next(x for x in ast.walk(base_run) if isinstance(x, ast.If) and ast.unparse(x.test) == 'not config.allow_symbol_downloads')
class RestoreDonor(ast.NodeTransformer):
    def visit_FunctionDef(self, node):
        if node.name == '_ghidriff_argv':
            return None
        return self.generic_visit(node)
    def visit_Assign(self, node):
        if any(isinstance(t, ast.Name) and t.id == 'RAW_ADAPTER_VERSION' for t in node.targets):
            return copy.deepcopy(assignment(base_backend, 'RAW_ADAPTER_VERSION'))
        if any(isinstance(t, ast.Name) and t.id == 'argv' for t in node.targets) and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name) and node.value.func.id == '_ghidriff_argv':
            return [copy.deepcopy(base_argv), copy.deepcopy(base_symbol_if)]
        return self.generic_visit(node)
check('entire donor backend differs only by reviewed builder/call/version', dump(RestoreDonor().visit(copy.deepcopy(donor_backend))) == dump(base_backend))
donor_fn = function(donor_backend, '_ghidriff_argv')
current_fn = function(current_backend, '_ghidriff_argv')
donor_args = assignment(donor_fn, 'argv').value.elts[4:]
current_args = assignment(current_fn, 'args').value.elts
check('complete original argument suffix retained structurally', [dump(x) for x in donor_args] == [dump(x) for x in current_args])
strings = [x.value for x in ast.walk(current_fn) if isinstance(x, ast.Constant) and isinstance(x.value, str)]
check('exactly one sequential option and no enabling option', strings.count('--no-threaded') == 1 and '--threaded' not in strings)
returns = [x for x in ast.walk(current_fn) if isinstance(x, ast.Return)]
check('both direct and local returns use shared sequential args', len(returns) == 2 and all(isinstance(x.value, ast.List) and any(isinstance(e, ast.Starred) and isinstance(e.value, ast.Name) and e.value.id == 'args' for e in x.value.elts) for x in returns))
mutations = [x for x in ast.walk(current_fn) if isinstance(x, ast.Call) and isinstance(x.func, ast.Attribute) and isinstance(x.func.value, ast.Name) and x.func.value.id == 'args']
check('only compatible argument appends', sorted(ast.unparse(x) for x in mutations) == ["args.append('--force-diff')", "args.append('--no-symbols')"])
python_args = assignment(current_fn, 'python').value
check('stronger unconditional isolated Python retained', [x.value for x in python_args.elts[1:]] == ['-I', '-X', 'utf8'] and ast.unparse(python_args.elts[0]) == 'os.path.abspath(config.python_executable)')
current_run = function(current_backend, 'run_comparison')
builder_calls = [x for x in ast.walk(current_run) if isinstance(x, ast.Call) and isinstance(x.func, ast.Name) and x.func.id == '_ghidriff_argv']
process_calls = [x for x in ast.walk(current_run) if isinstance(x, ast.Call) and isinstance(x.func, ast.Name) and x.func.id == 'run_process' and x.args and isinstance(x.args[0], ast.Name) and x.args[0].id == 'argv']
check('production uses builder once and passes argv to process', len(builder_calls) == len(process_calls) == 1)
fingerprints = [x for x in ast.walk(function(current_backend, '_open_raw_cache')) if isinstance(x, ast.Call) and isinstance(x.func, ast.Name) and x.func.id == 'RuntimeFingerprint']
check('actual raw cache key receives adapter version', len(fingerprints) == 1 and any(k.arg == 'adapter_version' and isinstance(k.value, ast.Name) and k.value.id == 'RAW_ADAPTER_VERSION' for k in fingerprints[0].keywords))
cache = ast.parse(blob(CURRENT, 'src/patchtrace/enrichment/cache.py'))
runtime = next(x for x in cache.body if isinstance(x, ast.ClassDef) and x.name == 'RuntimeFingerprint')
check('runtime fingerprint has adapter field', any(isinstance(x, ast.AnnAssign) and isinstance(x.target, ast.Name) and x.target.id == 'adapter_version' for x in runtime.body))
check('fingerprint serialization/key include complete fields', 'fields(self)' in ast.unparse(function(runtime, 'as_dict')) and 'self.as_dict()' in ast.unparse(function(runtime, 'raw_key')) and 'adapter_version' in ast.literal_eval(assignment(cache, '_VERSION_FIELDS').value))
old_test = blob(DONOR, 'tests/test_ghidriff_threading.py')
new_test = blob(CURRENT, 'tests/test_ghidriff_threading.py')
old_line = b"assert ('-I' in argv) is bundled"
new_line = b"assert argv[1:4] == ['-I', '-X', 'utf8']"
check('entire test changes only stronger isolation assertion', old_test.count(old_line) == 1 and old_test.replace(old_line, new_line) == new_test)
note = blob(DONOR, PATHS[0])
check('entire dated nine-line incident note unchanged', note == blob(CURRENT, PATHS[0]) and len(note.splitlines()) == 9)
spec = blob(CURRENT, 'docs/specs/ghidriff-launcher-symbols.md').decode()
check('current specification explicitly retains sequential and isolated launch', '--no-threaded' in spec and '-I -X utf8' in spec)
for path in ['src/patchtrace/backend.py', 'tests/test_ghidriff_threading.py']:
    check('documentation-only epoch preserves ' + path, blob('a660dcf515a99adeeef145520e1c37f1d42aef48', path) == blob('ef9262cb8883e49a5d8af3c776a87524ca9a352f', path))

receipt = read('archive-receipt.json')
archive = AUTHOR / receipt['archive_file']
check('author archive exact size/hash', archive.stat().st_size == 2661030 == receipt['archive_bytes'] and sha(archive.read_bytes()) == receipt['archive_sha256'] == '907abba74b2de63202f138048266b4202a5d96e68549252c70342c737c63dfb1')
manifest_data = (AUTHOR / 'evidence-manifest.json').read_bytes()
manifest = json.loads(manifest_data)
check('author manifest exact hash', sha(manifest_data) == receipt['manifest_sha256'] == '3762ed0994ff1ca6b32908b82914ddebfffd35ae81b0b09c65547a5c9d223896')
with zipfile.ZipFile(archive) as z:
    check('author ZIP CRC/member set', z.testzip() is None and len(z.namelist()) == 90 and set(z.namelist()) == {x['path'] for x in manifest['files']} | {'evidence-manifest.json'})
    check('archived manifest exact external bytes', z.read('evidence-manifest.json') == manifest_data)
    for row in manifest['files']:
        data = z.read(row['path'])
        check('archive payload ' + row['path'], data == (AUTHOR / row['path']).read_bytes() and len(data) == row['bytes'] and sha(data) == row['sha256'])

def tree_blobs(commit):
    result = {}
    for record in git('ls-tree', '-r', '-z', commit).split(b'\0'):
        if record:
            metadata, path = record.split(b'\t', 1)
            mode, kind, object_id = metadata.decode().split()
            result[path.decode()] = object_id
    return result

bindings = read('fixture-source-bindings.json')
source_zip = AUTHOR / bindings['archive']['path']
check('full donor source archive size/hash', source_zip.stat().st_size == bindings['archive']['bytes'] == 1764897 and sha(source_zip.read_bytes()) == bindings['archive']['sha256'])
with zipfile.ZipFile(source_zip) as z:
    members = [x for x in z.infolist() if not x.is_dir()]
    source_paths = {x.filename for x in members}
    lookup = tree_blobs(DONOR)
    check('donor source ZIP CRC and full bounded 518-file source selection', z.testzip() is None and len(members) == 518 and source_paths == {p for p in lookup if p.startswith('src/') or p in ['pyproject.toml', 'tests/test_ghidriff_threading.py']})
    check('all donor fixture source files equal Git blobs', all(oid(z.read(x.filename)) == lookup[x.filename] for x in members))
for row in bindings['snapshots']:
    source_root = Path(row['snapshot'])
    lookup = tree_blobs(row['commit'])
    check('all 518 source-bound runtime files ' + row['commit'], row['git_blob_verified_files'] == 518 and all((source_root / path).is_file() and oid((source_root / path).read_bytes()) == lookup[path] for path in source_paths))
    check('runtime backend/test binding ' + row['commit'], sha((source_root / 'src/patchtrace/backend.py').read_bytes()) == row['backend_sha256'] and sha((source_root / 'tests/test_ghidriff_threading.py').read_bytes()) == row['original_test_sha256'])

objects = {x.split()[0] for x in txt('rev-list', '--objects', DONOR, '^' + BASE).splitlines()}
check('all 23 introduced Git objects listed', len(objects) == 23 and objects == set((AUTHOR / 'introduced-object-ids.txt').read_text().splitlines()))
pack_receipt = read('history-pack-receipt.json')
pack = (AUTHOR / 'introduced-objects.pack').read_bytes()
check('introduced object pack bytes/hash', len(pack) == pack_receipt['pack_bytes'] == 32375 and sha(pack) == pack_receipt['pack_sha256'])
verification = subprocess.run(['git', 'verify-pack', '-v', str(AUTHOR / 'introduced-objects.idx')], cwd=REPO, capture_output=True, text=True)
(OUT / 'pack-verification.stdout.txt').write_text(verification.stdout)
(OUT / 'pack-verification.stderr.txt').write_text(verification.stderr)
packed = {x.split()[0] for x in verification.stdout.splitlines() if len(x.split()[0]) == 40}
check('pack verifies and contains exactly introduced objects', verification.returncode == 0 and packed == objects)

prior = read('final-source-binding.json')['prior_inputs_exactly_match_comparison_git_tree']
for row in prior:
    data = (AUTHOR / 'prior-inputs' / row['path']).read_bytes()
    check('unchanged prior input ' + row['path'], data == blob(CURRENT, row['path']) and sha(data) == row['sha256'] and len(data) == row['bytes'])
for selected, inventory in [('selected-original-inventory-record.json', 'consolidation-inventory.json')]:
    record = read(selected)
    data = read('prior-inputs/docs/engineering/' + inventory)
    check('original whole inventory row ' + selected, [x for x in data['branches'] if x['branch'] == BRANCH] == [record])
technical_path = 'docs/engineering/evidence/cycle837fe-20261121/references/technical-inventory.compact.json.gz'
technical_bytes = blob(CURRENT, technical_path)
(OUT / 'technical-inventory.compact.json.gz').write_bytes(technical_bytes)
technical = json.loads(gzip.decompress(technical_bytes))
check('exact technical inventory row against correct canonical gzip', [x for x in technical['branches'] if x['branch'] == BRANCH] == [read('selected-technical-inventory-record.json')])
(OUT / 'review-harness-correction.json').write_text(json.dumps({
    'original_failure': 'AssertionError: original whole inventory row selected-technical-inventory-record.json',
    'cause': 'Reviewer initially paired the technical schema with the older consolidation-inventory-20261120-g30.json schema.',
    'correction': 'Compare the complete selected technical row with its canonical Git-bound technical-inventory.compact.json.gz source instead.',
    'technical_source_commit': CURRENT, 'technical_source_path': technical_path,
    'technical_source_blob': oid(technical_bytes), 'technical_source_sha256': sha(technical_bytes),
    'author_source_or_test_failure': False, 'product_tests_run': 0
}, indent=2) + '\n')
record = read('selected-original-inventory-record.json')
check('branch belongs to unmatched census, not patch-equivalent sixteen', record['comparison']['unmatched_nonmerge_commits'] == commits and record['comparison']['equivalent_nonmerge_commits'] == [] and record['disposition'] == 'retained-for-semantic-review')
check('author keeps original census snapshot without closure', classification['original_census_preserved'] == {'unmatched': 181, 'patch_equivalent': 16} and classification['branch_deletion_authorized'] is False and classification['inventory_exhausted'] is False)
ref = read('ref-refresh.json')
ref_object = json.loads(ref['result']['structuredContent']['content'])
check('retained fresh exact ref observation', ref_object['object']['sha'] == DONOR and ref_object['ref'] == 'refs/heads/' + BRANCH and ref['observed_at_utc'] == '2026-11-21 12:11:02 UTC')

results = read('test-outcomes.json')['results']
expected_counts = {'initial-red-import': (0, 0, 1, 0), 'first-implementation': (1, 0, 0, 0), 'intermediate-refactor-import': (0, 0, 1, 0), 'final-donor': (4, 0, 0, 0), 'original-tip-test-on-current': (2, 2, 0, 0), 'maintained-current': (4, 0, 0, 0), 'current-adapter-cache-provenance': (1, 0, 0, 0)}
check('all seven retained execution receipts included', {x['label'] for x in results} == set(expected_counts))
verified_results = []
for row in results:
    label = row['label']
    check('receipt preserved ' + label, read(label + '-receipt.json') == row)
    cases = ET.parse(AUTHOR / (label + '.xml')).findall('.//testcase')
    failed = sum(c.find('failure') is not None for c in cases)
    errors = sum(c.find('error') is not None for c in cases)
    skipped = sum(c.find('skipped') is not None for c in cases)
    counts = (len(cases) - failed - errors - skipped, failed, errors, skipped)
    check('independent XML outcomes ' + label, counts == expected_counts[label] == tuple(row['counts'][k] for k in ['passed', 'failed', 'errors', 'skipped']))
    check('exit semantics ' + label, row['exit_code'] == (2 if errors else 1 if failed else 0))
    source = json.loads((AUTHOR / (label + '.stdout.txt')).read_text().splitlines()[0])
    check('actual backend import binding ' + label, source['source_root'] == row['source_root'] and source['backend'] == str(Path(row['source_root']) / 'src/patchtrace/backend.py') and source['backend_sha256'] == sha(blob(row['source_commit'], 'src/patchtrace/backend.py')))
    check('bounded isolated invocation ' + label, row['argv'][1:3] == ['-I', '-B'] and '--noconftest' in row['argv'] and '--disable-plugin-autoload' in row['argv'] and 'no:cacheprovider' in row['argv'])
    if 'test_file' in row:
        test = Path(row['test_file']).read_bytes()
        test_commit = DONOR if label == 'original-tip-test-on-current' else row['source_commit']
        check('unchanged fixture bytes ' + label, test == blob(test_commit, 'tests/test_ghidriff_threading.py') and sha(test) == row['test_sha256'])
    if errors:
        error_text = '\n'.join(c.find('error').text or '' for c in cases if c.find('error') is not None)
        check('historical missing-helper collection failure retained ' + label, "cannot import name '_ghidriff_threading_args'" in error_text)
    if failed:
        failures = [c for c in cases if c.find('failure') is not None]
        check('both current original failures are stronger isolation only', {c.get('name') for c in failures} == {'test_ghidriff_launch_serializes_analysis[False-False]', 'test_ghidriff_launch_serializes_analysis[False-True]'} and all("assert ('-I' in argv) is bundled" in (c.find('failure').text or '') for c in failures))
    verified_results.append({'label': label, 'source_commit': row['source_commit'], 'counts': row['counts'], 'exit_code': row['exit_code']})
runner = (AUTHOR / 'run_bound_pytest.py').read_text()
check('runner binds source before invoking pytest', "sys.path[:0]" in runner and "assert Path(backend.__file__).resolve()==source / \"src/patchtrace/backend.py\"" in runner and 'runpy.run_module("pytest",run_name="__main__")' in runner)
check('current worktree remains clean and unchanged', start_status == '' and txt('status', '--porcelain=v1') == '' and txt('rev-parse', 'HEAD') == CURRENT)

review = {
    'schema': 'patchtrace/independent-historical-branch-review/1',
    'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer': '/root/codex1_independent_review',
    'branch': BRANCH, 'donor_head': DONOR, 'donor_tree': txt('rev-parse', DONOR + '^{tree}'),
    'merge_base': BASE, 'comparison_source': CURRENT, 'comparison_tree': txt('rev-parse', CURRENT + '^{tree}'),
    'verdict': 'CLEAR: SUPERSEDED for the complete five-commit/three-path branch scope',
    'blockers': [], 'missing_compatible_contribution_found': False,
    'checks': CHECKS, 'check_count': len(CHECKS),
    'unique_commits': commits, 'all_historical_and_net_paths': PATHS,
    'source_snapshots_verified': 19, 'introduced_objects_verified': 23,
    'author_archive': receipt, 'verified_prior_execution_results': verified_results,
    'independent_product_tests_run': 0, 'counts_additive': False,
    'original_census_snapshot_preserved': {'unmatched': 181, 'patch_equivalent': 16},
    'limits': [
        'Semantic retention only; current donor head is not asserted merged by ancestry and no branch deletion is authorized.',
        'Current unconditional -I -X utf8 is intentional stronger isolation; do not port the obsolete bundle-only expectation.',
        'Original import failures and two current isolation-policy failures remain in the sealed author archive.',
        'Pure argv/cache fixture receipts do not prove the private Windows lock incident resolved; no native, target, full-suite or new product test execution.',
        'No source/ref/PR/CI/ledger mutations; original 181/16 snapshot remains historical, not a recalculated backlog.',
        'Actual PR351 qualification and assembled promotion-bound records review remain separate and outstanding.'
    ]
}
(OUT / 'review.json').write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps({'verdict': review['verdict'], 'checks': len(CHECKS), 'source_snapshots': 19, 'introduced_objects': 23, 'test_runs': 0, 'review_sha256': sha((OUT / 'review.json').read_bytes())}))
