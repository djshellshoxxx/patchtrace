from pathlib import Path
import hashlib
import json
import shutil
import zipfile

root = Path(__file__).parent
author = root.parent / 'historical-after-f596-next-review'
shutil.copyfile(author / 'historical-ghidriff-sequential-lock-review.zip', root / 'author-original.zip')
shutil.copyfile(author / 'archive-receipt.json', root / 'author-archive-receipt.json')
archive_name = 'historical-ghidriff-sequential-lock-independent.zip'
excluded = {archive_name, 'evidence-manifest.json', 'archive-receipt.json'}
files = []
for path in sorted(root.rglob('*')):
    if path.is_file() and path.name not in excluded and '__pycache__' not in path.parts:
        data = path.read_bytes()
        files.append({'path': str(path.relative_to(root)), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
manifest = {'schema': 'patchtrace/independent-evidence-manifest/1', 'source': 'f596471b8909ec8e28e0624041d60f03d520591d', 'donor': 'f6b7545bcc7a161440ab7119233c204510571370', 'files': files}
manifest_path = root / 'evidence-manifest.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
archive = root / archive_name
with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for row in files:
        z.write(root / row['path'], row['path'])
    z.write(manifest_path, manifest_path.name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == {x['path'] for x in files} | {'evidence-manifest.json'}
    for row in files:
        data = z.read(row['path'])
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
receipt = {
    'archive_file': archive_name,
    'archive_bytes': archive.stat().st_size,
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'zip_member_count': len(files) + 1,
    'manifest_sha256': hashlib.sha256(manifest_path.read_bytes()).hexdigest(),
    'review_sha256': hashlib.sha256((root / 'review.json').read_bytes()).hexdigest(),
    'crc_and_all_member_hashes_verified': True,
}
(root / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
