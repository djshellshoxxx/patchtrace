"""Read-only source and retained-evidence check of three proposed documents."""
from __future__ import annotations

import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import zipfile

import yaml

ROOT = Path('/workspace/scratch/837fe19aae3a')
OUT = ROOT / 'evidence/windows-recovery-records-independent/document-proposals'
PROPOSED = ROOT / 'evidence/windows-recovery-record-preparation/document-proposals'
REPO = ROOT / 'PatchTrace-codex5-followup'
SOURCE = '1c70cd5f8053f75c269da673a24a82f221180650'
PRIMARY = '9023761a4066ac1c50c127ac09d0ba5f56cdc9e4'
checks = []


def check(name, ok):
    checks.append({'name': name, 'passed': bool(ok)})
    if not ok:
        (OUT / 'failed-checks.json').write_text(json.dumps(checks, indent=2) + '\n')
        raise AssertionError(name)


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args],
                                   env=dict(os.environ, GIT_OPTIONAL_LOCKS='0'))


def blob(commit, path):
    return git('show', commit + ':' + path)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


context_bytes = (ROOT / 'windows-recovery-records-context.json').read_bytes()
context = json.loads(context_bytes)
(OUT / 'context-observed.json').write_bytes(context_bytes)
before = {'head': git('rev-parse', 'HEAD').decode().strip(),
          'status': git('status', '--porcelain=v1').decode()}
check('frozen source tree', git('rev-parse', SOURCE + '^{tree}').decode().strip() == 'a39d650ca7fa2b41ece017ea492396722a4142d9')
check('preparation remains unapplied', context['apply_authorized_now'] is False and bool(context['blockers']))
paths = ['docs/package-audit.md', 'docs/release-process.md', 'docs/windows.md']
check('exactly three proposed paths', sorted(p.relative_to(PROPOSED).as_posix() for p in PROPOSED.rglob('*') if p.is_file()) == paths)
check('context exact same three replacements', sorted(r['path'] for r in context['reviewed_document_replacements']) == paths)
docs = {}; identities = []
for path in paths:
    original = blob(SOURCE, path); primary = blob(PRIMARY, path); proposed = (PROPOSED / path).read_bytes()
    row = next(r for r in context['reviewed_document_replacements'] if r['path'] == path)
    check('before hash guard ' + path, sha(original) == row['before_sha256'])
    check('same old bytes at main902 ' + path, original == primary)
    check('context exact proposal bytes ' + path, proposed == row['after_text'].encode())
    for prefix, raw in [('before', original), ('proposed', proposed)]:
        destination = OUT / prefix / path; destination.parent.mkdir(parents=True, exist_ok=True); destination.write_bytes(raw)
    docs[path] = (original.decode(), proposed.decode())
    identities.append({'path': path, 'source_commit': SOURCE, 'source_blob': git('rev-parse', SOURCE + ':' + path).decode().strip(),
                       'before_sha256': sha(original), 'proposal_sha256': sha(proposed), 'proposal_bytes': len(proposed)})
diff = ''.join(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='1c70/' + path, tofile='proposal/' + path))
               for path, (old, new) in docs.items())
(OUT / 'proposed-documents.patch').write_text(diff)

old, new = docs['docs/release-process.md']
check('release changes only Pipeline section', old.split('## Pipeline\n', 1)[0] == new.split('## Pipeline\n', 1)[0] and
      old.split('## The release gate\n', 1)[1] == new.split('## The release gate\n', 1)[1])
old, new = docs['docs/windows.md']
first = 'or its Start Menu uninstaller'
second = 'installer/PatchTrace.iss with Inno Setup into PatchTrace-Windows-x64-Setup.exe'
check('Windows prior findings have unique locations', old.count(first) == 1 and old.count(second) == 1)
expected = old.replace(first, 'or by running `Uninstall.exe` in the installation directory').replace(
    second, '`installer/PatchTrace.nsi` with pinned NSIS 3.13 into `PatchTrace-Windows-x64-Setup.exe`')
addition = ('The separate `windows-validate` job downloads the uploaded ZIP and installer to a fresh Windows runner. '
            'It requires all four artifact files and verifies both sidecars against the exact filenames and bytes before running '
            'the maintained portable and installer smoke scripts. This job installs no application/development dependencies or '
            'compiler; the full frozen CLI harness remains on the builder. A pristine Windows profile and manual desktop acceptance '
            'remain separate.\n\n')
expected = expected.replace('Clean-machine QA procedure:', addition + 'Clean-machine QA procedure:')
check('only intended Windows changes', new == expected)
old, new = docs['docs/package-audit.md']
check('full historical audit remains exact prefix', new.startswith(old))
appendix = new[len(old):]
check('audit addition is explicitly dated', '## Current installer implementation and retained history (2026-11-21 UTC)' in appendix)
check('audit keeps historical and new source qualification separate', 'historical checkpoints' in appendix and
      'This proves that exact source and builder-side workflow.' in appendix and
      'separately added downloaded-artifact job requires its own exact-source hosted qualification' in appendix)
check('audit preserves broader gates', 'signing/trust, upgrade and manual desktop/accessibility acceptance remain separate gates' in appendix)

source_paths = ['.github/workflows/qa-windows.yml', '.github/workflows/pages.yml',
                'installer/PatchTrace.nsi', 'tools/package_windows_installer.py',
                'tools/test_windows_portable.ps1', 'tools/test_windows_installer.ps1',
                'docs/specs/windows-acceptance-and-milestone-builds.md']
for path in source_paths:
    dest = OUT / 'source' / path; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(blob(SOURCE, path))
workflow = yaml.safe_load(blob(SOURCE, '.github/workflows/qa-windows.yml'))
jobs = workflow['jobs']
expected_needs = {'qa': [], 'qt-gate': [], 'windows-validate': ['qa'], 'linux-package': ['qa', 'qt-gate'],
                  'linux-smoke': ['linux-package'], 'release-gate': [],
                  'release': ['qa', 'qt-gate', 'windows-validate', 'linux-smoke', 'release-gate']}
check('exact seven jobs documented', set(jobs) == set(expected_needs))
for name, needs in expected_needs.items():
    actual = jobs[name].get('needs', []); actual = [actual] if isinstance(actual, str) else actual
    check('documented dependency graph ' + name, actual == needs)
    check('release table row exists ' + name, '| `' + name + '` |' in docs['docs/release-process.md'][1])
check('source triggers', workflow.get('on', workflow.get(True)) == {'push': {'branches': ['main'], 'tags': ['v*']}, 'pull_request': None, 'workflow_dispatch': None})
check('cadence gate push-only', jobs['release-gate']['if'] == "github.event_name == 'push'")
check('release hold and no status override', jobs['release']['if'] == "(startsWith(github.ref, 'refs/tags/v') || needs.release-gate.outputs.publish == 'true') && !contains(github.event.head_commit.message, '[no release]')")
check('PR-only cancellation expression', workflow['concurrency'] == {
    'group': "${{ github.workflow }}-${{ github.event_name == 'pull_request' && github.ref || github.run_id }}",
    'cancel-in-progress': "${{ github.event_name == 'pull_request' }}"})
check('QA both systems', jobs['qa']['strategy']['matrix']['os'] == ['ubuntu-latest', 'windows-latest'])
qt_matrix = jobs['qt-gate']['strategy']['matrix']['include']
check('four Linux Qt shards and one Windows leg', [r['shard'] for r in qt_matrix if r['os'] == 'ubuntu-latest'] == ['1/4', '2/4', '3/4', '4/4'] and
      len([r for r in qt_matrix if r['os'] == 'windows-latest']) == 1)
check('Linux build host and smoke hosts', jobs['linux-package']['runs-on'] == 'ubuntu-22.04' and
      jobs['linux-smoke']['strategy']['matrix']['os'] == ['ubuntu-22.04', 'ubuntu-24.04'])
qa_commands = '\n'.join(s.get('run', '') for s in jobs['qa']['steps'])
check('full QA tests and Ruff defined', 'python -m pytest -q' in qa_commands and 'python -m ruff check' in qa_commands)
check('builder frozen CLI and NSIS checks defined', all(x in qa_commands for x in ['python tools/frozen_smoke.py dist/PatchTrace/PatchTrace.exe',
      'choco install nsis --version=3.13 --yes --no-progress', 'python tools/package_windows_installer.py',
      './tools/test_windows_portable.ps1', './tools/test_windows_installer.ps1']))
linux = '\n'.join(s.get('run', '') for s in jobs['linux-smoke']['steps'])
check('Linux checksum and full frozen harness defined', 'sha256sum -c' in linux and 'tools/frozen_smoke.py' in linux and
      '--self-test' in linux and 'xvfb-run' in linux)
win = jobs['windows-validate']; steps = win['steps']; verify = steps[2]['run']
check('fresh Windows job current-run download', win['runs-on'] == 'windows-latest' and
      steps[0]['uses'].startswith('actions/checkout@') and steps[1]['uses'].startswith('actions/download-artifact@') and
      steps[1]['with'] == {'name': 'PatchTrace-windows-x64', 'path': 'dist'})
check('all four files and both digests before smoke', all(x in verify for x in ['PatchTrace-0.1.0-windows-x64.zip',
      'PatchTrace-Windows-x64-Setup.exe', '.sha256', 'Get-FileHash', 'ReparsePoint']) and
      'test_windows_portable.ps1' in steps[3]['run'] and 'test_windows_installer.ps1' in steps[4]['run'])
check('downloaded runner has no dependency/compiler setup', all(x not in '\n'.join(s.get('run', '') for s in steps) for x in
      ['pip install', 'choco install', 'package_windows_installer.py', 'build_windows.py']))
check('downloaded job remains required', all('continue-on-error' not in s and 'if' not in s for s in steps) and
      'continue-on-error' not in win)
release_steps = jobs['release']['steps']; alias = next(s for s in release_steps if s.get('name', '').startswith('Verify Windows portable hash'))['run']
alias_lines = [line for line in alias.splitlines() if line]
check('canonical alias exact checksum/copy sequence', alias_lines == ['set -euo pipefail', 'cd release',
      'sha256sum -c PatchTrace-0.1.0-windows-x64.zip.sha256', 'sha256sum -c PatchTrace-Windows-x64-Setup.exe.sha256',
      'cp PatchTrace-0.1.0-windows-x64.zip PatchTrace-Windows-x64-Portable.zip',
      'sha256sum PatchTrace-Windows-x64-Portable.zip > PatchTrace-Windows-x64-Portable.zip.sha256',
      'sha256sum -c PatchTrace-Windows-x64-Portable.zip.sha256'])
release = next(s for s in release_steps if s.get('uses', '').startswith('softprops/action-gh-release@'))['with']
check('documented exact release names', release['name'] == "${{ startsWith(github.ref, 'refs/tags/') && format('PatchTrace {0} (Windows x64, Linux x86-64)', github.ref_name) || format('PatchTrace beta {0} (Windows x64, Linux x86-64)', github.run_number) }}")
check('prerelease target tag and assets', release['prerelease'] is True and release['target_commitish'] == '${{ github.sha }}' and
      release['tag_name'] == "${{ startsWith(github.ref, 'refs/tags/') && github.ref_name || format('v0.1.0-beta.{0}', github.run_number) }}" and release['files'] == 'release/*')
notes = next(s for s in release_steps if s.get('name') == 'Generate release notes')['run']
check('notes failure fallback retained', 'tools/milestone_notes.py' in notes and
      '|| { echo "::warning::milestone_notes failed; using static preamble only"; cp "$RUNNER_TEMP/preamble.md" "$RUNNER_TEMP/notes.md"; }' in notes)
nsi = blob(SOURCE, 'installer/PatchTrace.nsi').decode()
check('actual uninstaller entry points', 'WriteUninstaller "$INSTDIR\\Uninstall.exe"' in nsi and
      'Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\PatchTrace' in nsi and
      len([line for line in nsi.splitlines() if 'CreateShortcut' in line]) == 1)
check('per-user NSIS and generated manifest', 'RequestExecutionLevel user' in nsi and 'SetShellVarContext current' in nsi and
      '!include "${REPO_ROOT}\\dist\\PatchTrace-Uninstall.nsh"' in nsi)
helper = blob(SOURCE, 'tools/package_windows_installer.py').decode()
check('actual pinned compiler and source script', 'NSIS_VERSION = "3.13"' in helper and 'version != NSIS_VERSION' in helper and
      'root / "installer" / "PatchTrace.nsi"' in helper)
check('new spec link target heading exists', '### 1.1.2 Downloaded Windows artifact acceptance (2026-11-21)' in
      blob(SOURCE, 'docs/specs/windows-acceptance-and-milestone-builds.md').decode())

observed = ROOT / 'evidence/main-9023761-publication-holds'
archive = observed / 'main-9023761-postmerge-evidence.zip'
archive_expected = next(row for row in context['static_evidence_inputs'] if row['source'].endswith(archive.name))
check('retained post-main archive exact hash and size', sha(archive.read_bytes()) == archive_expected['sha256'] ==
      '74d7390d7ded8087bc6869bab34c997e16e63a4a77d5b7f75d8291da0c3052bf' and archive.stat().st_size == archive_expected['bytes'])
with zipfile.ZipFile(archive) as z:
    check('post-main139-member archive CRC', len(z.namelist()) == 139 and z.testzip() is None)
    manifest = json.loads(z.read('evidence-manifest.json'))
    for row in manifest['files']:
        raw = z.read(row['path'])
        check('post-main archive member ' + row['path'], len(raw) == row['bytes'] and sha(raw) == row['sha256'])
    qualified = json.loads(z.read('post-main-qualification.json'))
    job = json.loads(z.read('raw-job-136802040648.json'))
    log = z.read('logs/136802040648.log').decode(errors='replace')
check('actual main immutable commit tree/parents', git('rev-parse', PRIMARY + '^{tree}').decode().strip() == qualified['source']['complete_tree_sha'] and
      git('show', '-s', '--format=%P', PRIMARY).decode().strip().split() == qualified['source']['parents'])
check('actual main source identity', qualified['source']['actual_main_merge_sha'] == PRIMARY and
      job['head_sha'] == PRIMARY and job['job_id'] == 136802040648 and job['run_id'] == 44889511435 and
      job['name'] == 'qa (windows-latest)' and job['conclusion'] == 'success' and job['checkout_matches_expected'] is True)
check('64 original frozen CLI passes and no failures', len(re.findall(r'^\S+ PASS ', log, re.M)) == 64 and
      not re.search(r'^\S+ FAIL ', log, re.M))
for name in ['Frozen EXE headless smoke (A1-A4) and self-test', 'Extract and run portable Windows ZIP outside checkout',
             'Build per-user Windows installer', 'Install, launch, and uninstall the setup package']:
    check('main successful step ' + name, next(s for s in job['job_record']['steps'] if s['name'] == name)['conclusion'] == 'success')
check('main log confirms package acceptance messages', all(x in log for x in ['Portable checksum, clean extraction, Qt plugin, dependencies, and frozen executable smoke passed.',
      'NSIS 3.13 installer:', 'Installer registration, Qt/runtime checks, frozen self-test, non-destructive uninstall passed.']))
check('observed actual release skipped', qualified['publication']['release']['conclusion'] == 'skipped' and
      qualified['release_baseline_comparison']['published_since_main_merge'] == [] and
      qualified['release_baseline_comparison']['newest_three_releases_unchanged'] is True)
check('actual main holds', all(m in git('show', '-s', '--format=%B', PRIMARY).decode() for m in ['[no release]', '[no deploy]']))
check('installer scripts unchanged since qualified main', all(blob(SOURCE, path) == blob(PRIMARY, path) for path in
      ['installer/PatchTrace.nsi', 'tools/package_windows_installer.py', 'tools/test_windows_installer.ps1', 'tools/test_windows_portable.ps1']))
shutil.copyfile(archive, OUT / archive.name)
(OUT / 'actual-main-commit.txt').write_bytes(git('cat-file', 'commit', PRIMARY))
check('proposal and context unchanged during review', context_bytes == (ROOT / 'windows-recovery-records-context.json').read_bytes() and
      all((OUT / 'proposed' / path).read_bytes() == (PROPOSED / path).read_bytes() for path in paths))
check('source worktree unchanged', before == {'head': git('rev-parse', 'HEAD').decode().strip(), 'status': git('status', '--porcelain=v1').decode()})
result = {'schema': 'patchtrace/windows-recovery-document-proposals-independent/1',
          'reviewed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'verdict': 'CLEAR for the exact three scratch proposals; final assembled records/promotion not approved',
          'blockers': [], 'source': SOURCE, 'source_tree': 'a39d650ca7fa2b41ece017ea492396722a4142d9',
          'historical_qualification_source': PRIMARY, 'context_sha256': sha(context_bytes),
          'proposals': identities, 'checks_passed': len(checks), 'checks': checks,
          'source_worktree_before_after': before, 'product_tests_run': 0, 'native_execution': False,
          'future_link_dependency': 'engineering/cycle837fe-windows-recovery-20261121.md must exist in final assembled records; it is an intended helper output.',
          'scope': 'Only Pipeline section replaced; Windows guide receives two corrections and new job paragraph; full old package-audit bytes remain prefix.',
          'qualification_limit': 'Actual main902 builder-side evidence only; no transfer to new1c70 downloaded-artifact qualification or final record merge.',
          'no_mutations': 'Only own scratch evidence; no source, helper, context, ledger, refs, PRs, CI or environment changes.'}
(OUT / 'review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'verdict': result['verdict'], 'checks_passed': len(checks), 'context_sha256': result['context_sha256'], 'proposals': identities}, indent=2))
