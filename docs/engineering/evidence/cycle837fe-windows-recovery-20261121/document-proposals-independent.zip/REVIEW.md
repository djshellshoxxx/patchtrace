# Independent review of Windows recovery document proposals

## Verdict

**CLEAR for the exact three scratch proposals below.** No document correction remains outstanding. This is preparation-only review: it does not approve a final ledger/record assembly, new-source hosted qualification or a main merge.

Source: `1c70cd5f8053f75c269da673a24a82f221180650`, tree `a39d650ca7fa2b41ece017ea492396722a4142d9`. All three old document blobs are byte-identical at actual primary main `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4`. Context snapshot SHA256: `37ffe2f879a9890033f19465e6a81ffce207b754dd97de0e5e5eec84703e76a3`. The context remains blocked and unapplied.

| Proposal | Exact SHA256 | Bytes |
| --- | --- | ---: |
| `docs/package-audit.md` | `1a4f6204dcb2e1e211c30e7fca96d7ce32a51cb1a46bbaacb4c808b2aaa74eb4` | 7,918 |
| `docs/release-process.md` | `57d573b9092f7b00ab143adeccdc64478e99895fafbd41f13a597ba187f46e66` | 10,949 |
| `docs/windows.md` | `aff71e51afb1b74a51fc19be861899b3b096aea6ebbb71e5e1bae2e815a731da` | 4,929 |

## Scope and source checks

**210 source/evidence checks passed; zero product tests were run.** The count includes member-hash validation of the retained main evidence archive. Source and scratch proposals remained unchanged during the review.

- **Release process:** Only the Pipeline section changes. Its seven jobs and dependencies match the parsed frozen workflow. The four Ubuntu Qt shards and Windows leg, Linux build/smoke platforms, builder-side full frozen CLI harness, fresh downloaded-package gate, push-only cadence gate and full required release graph are correct. Main/tag naming, prerelease flag, target commit and artifact selection match the pinned release action inputs. The canonical portable asset is copied from the verified ZIP and its new sidecar is verified. The current release hold and PR-only cancellation are accurately described. Every later section, including publication/deployment holds, remains byte-identical.
- **Windows guide:** Exactly two existing statements are corrected: the compiler/source is pinned NSIS 3.13 with `installer/PatchTrace.nsi`, and uninstall is available through Windows Apps or the installed `Uninstall.exe`. The script creates only the application Start Menu shortcut. The only addition is the paragraph describing the fresh downloaded-package gate. That paragraph accurately separates the job's checks from builder-side full CLI testing and manual pristine-profile acceptance.
- **Package audit:** The complete old document remains an exact byte prefix. The new dated appendix distinguishes the retired Inno history, present NSIS implementation, actual primary builder-side qualification and the new job's still-separate exact-source qualification. Dated pending/failure statements are preserved.

## Actual main claim verification

The appendix cites main 902, run 44889511435, job 136802040648. The retained raw job identifies that exact checkout and a successful Windows QA job. I independently counted 64 `PASS` and zero `FAIL` lines from the frozen CLI output; checked successful portable/build/installer steps; and verified the corresponding completion messages. The log and immutable source preserve the inside/outside user-data sentinel checks. The observed release job was skipped, and the retained release comparison contains no publication since that merge. This is evidence for that historical source and workflow only.

The original post-main evidence archive is retained unchanged in this review: 139 members, 3,038,331 bytes, SHA256 `74d7390d7ded8087bc6869bab34c997e16e63a4a77d5b7f75d8291da0c3052bf`. All CRCs and manifest-listed member hashes were verified. No hosted request, dispatch, native/package execution, installation or test rerun occurred.

## Final assembly dependency

The new audit link points to `docs/engineering/cycle837fe-windows-recovery-20261121.md`, an intended helper output. Its existence and final contents must be checked in the final assembled tree. This review does not transfer main 902 results to 1c70 or to any later records commit.

`review.json` contains named checks and exact hashes; `proposed-documents.patch` shows the full bounded delta; source, before/proposed documents and context are retained. Only this review's scratch evidence was written. No source, helper, context, ledger, ref, PR, CI or environment was changed.
