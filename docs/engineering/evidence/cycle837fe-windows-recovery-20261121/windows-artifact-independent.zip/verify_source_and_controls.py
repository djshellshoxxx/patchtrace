"""Read-only source/evidence proof and in-memory workflow rejection controls."""
import ast
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
import yaml

ROOT = Path('/workspace/scratch/837fe19aae3a')
SOURCE = ROOT / 'repair-windows-artifact-validation'
OUT = ROOT / 'evidence/windows-artifact-validation-independent'
AUTHOR = ROOT / 'evidence/windows-artifact-validation-recovery'
HEAD = '1c70cd5f8053f75c269da673a24a82f221180650'
TREE = 'a39d650ca7fa2b41ece017ea492396722a4142d9'
PARENT = 'c4eb63c55a35a1c2a927f4aeb4d42c8b96ff45ff'
WF = '.github/workflows/qa-windows.yml'
checks, controls = [], []


def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args])


def blob(ref, path):
    return git('show', ref + ':' + path)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def check(name, ok, **detail):
    checks.append({'name': name, 'passed': bool(ok), **detail})
    if not ok:
        (OUT / 'source-verification-failure.json').write_text(json.dumps(checks, indent=2) + '\n')
        raise AssertionError(name)


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, SOURCE / path)
    loaded = importlib.util.module_from_spec(spec)
    sys.modules[name] = loaded
    spec.loader.exec_module(loaded)
    return loaded


check('Exact immutable identity and clean worktree', git('rev-parse', 'HEAD').decode().strip() == HEAD
      and git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE
      and git('show', '-s', '--format=%P', HEAD).decode().strip() == PARENT
      and not git('status', '--porcelain=v1', '--untracked-files=all').strip())
message = git('show', '-s', '--format=%B', HEAD).decode()
check('Both publication opt-outs in commit', all(x in message for x in ['[no release]', '[no deploy]']))
paths = {WF, 'docs/specs/REGISTRY.md', 'docs/specs/windows-acceptance-and-milestone-builds.md',
         'tests/test_codex5_command_audit_20261121.py', 'tests/test_release_gate.py', 'tests/test_windows_downloaded_artifacts.py'}
check('Exactly six allowed paths', set(git('diff', '--name-only', PARENT, HEAD).decode().splitlines()) == paths)
text, old_text = blob(HEAD, WF).decode(), blob(PARENT, WF).decode()
start, end = text.index('  windows-validate:\n'), text.index('  # Repeats the GUI')
restored = (text[:start] + text[end:]).replace('needs: [qa, qt-gate, windows-validate, linux-smoke, release-gate]', 'needs: [qa, qt-gate, linux-smoke, release-gate]')
check('All old workflow bytes restored by removing only new job and need', restored == old_text)
data, old_data = yaml.safe_load(text), yaml.safe_load(old_text)
neutral = copy.deepcopy(data)
del neutral['jobs']['windows-validate']
neutral['jobs']['release']['needs'].remove('windows-validate')
check('Every other parsed field and job is equal', neutral == old_data)
check('Runtime and tools unchanged', not git('diff', '--name-only', PARENT, HEAD, '--', 'src', 'tools', 'pyproject.toml').strip())
for path in ['tools/test_windows_portable.ps1', 'tools/test_windows_installer.ps1', 'tools/frozen_smoke.py']:
    check('Unchanged acceptance script: ' + path, blob(HEAD, path) == blob(PARENT, path))
old_funcs = {n.name: n for n in ast.parse(blob(PARENT, 'tests/test_release_gate.py')).body if isinstance(n, ast.FunctionDef)}
new_funcs = {n.name: n for n in ast.parse(blob(HEAD, 'tests/test_release_gate.py')).body if isinstance(n, ast.FunctionDef)}
updated = {'test_the_helpers_split_the_real_workflow_into_its_jobs', 'test_the_release_job_needs_the_gate_and_runs_for_a_tag_or_a_gate_yes_only', 'test_publication_hold_keeps_all_acceptance_jobs_and_artifact_uploads_enabled'}
check('Original release test inventory preserved', set(old_funcs) == set(new_funcs))
for name in sorted(set(old_funcs) - updated):
    check('Prior release function unchanged: ' + name, ast.dump(old_funcs[name], include_attributes=False) == ast.dump(new_funcs[name], include_attributes=False))
census = 'tests/test_codex5_command_audit_20261121.py'
check('C5 changes only three actual run count', blob(HEAD, census).decode().replace('"qa-windows.yml": (36, 4, 4)', '"qa-windows.yml": (33, 4, 4)') == blob(PARENT, census).decode())

win = load_module('peer_windows_downloaded_artifacts', 'tests/test_windows_downloaded_artifacts.py')
release = load_module('peer_release_gate', 'tests/test_release_gate.py')
win_tests = [win.test_downloaded_artifact_job_uses_a_fresh_windows_runner_and_this_runs_bytes, win.test_both_downloaded_checksums_precede_required_portable_and_installer_smokes]
release_tests = [release.test_the_helpers_split_the_real_workflow_into_its_jobs,
                 release.test_the_release_job_needs_the_gate_and_runs_for_a_tag_or_a_gate_yes_only,
                 release.test_publication_hold_keeps_all_acceptance_jobs_and_artifact_uploads_enabled,
                 release.test_every_needs_target_exists_and_the_job_graph_has_no_cycle,
                 release.test_gui_gate_blocks_packaging_and_publication_even_when_the_cadence_gate_says_yes,
                 release.test_a_pull_request_cannot_reach_the_release_job,
                 release.test_only_the_release_job_can_write_repository_contents]


class TextSource:
    def __init__(self, value):
        self.value = value

    def read_text(self, **_kwargs):
        return self.value


def exercise(label, workflow, functions, valid, release_source=None):
    win.WORKFLOW = TextSource(workflow)
    release.TEXT = text if release_source is None else release_source
    release.BLOCKS = release.job_blocks(release.TEXT)
    results = []
    for test in functions:
        try:
            test()
        except (AssertionError, KeyError, IndexError, ValueError) as exc:
            results.append({'test': test.__name__, 'accepted': False, 'error': type(exc).__name__, 'detail': str(exc)})
        else:
            results.append({'test': test.__name__, 'accepted': True})
    accepted = all(r['accepted'] for r in results)
    controls.append({'label': label, 'expected_valid': valid, 'accepted': accepted, 'passed': accepted == valid,
                     'outcomes': results, 'workflow_sha256': sha(workflow.encode())})
    assert accepted == valid, label


def mutate(label, change):
    candidate = copy.deepcopy(data)
    change(candidate['jobs']['windows-validate'])
    exercise(label, yaml.safe_dump(candidate, sort_keys=False), win_tests, False)


exercise('Exact frozen candidate', text, win_tests + release_tests, True)
exercise('Harmless verifier comment', text.replace('$ErrorActionPreference = "Stop"\n          $artifactDirectory', '$ErrorActionPreference = "Stop"\n          # Peer comment only\n          $artifactDirectory'), win_tests, True)
mutate('Wrong dependency', lambda j: j.update(needs='linux-smoke'))
mutate('Wrong runner', lambda j: j.update({'runs-on': 'ubuntu-latest'}))
mutate('Missing timeout', lambda j: j.pop('timeout-minutes'))
mutate('Job failure suppressed', lambda j: j.update({'continue-on-error': True}))
mutate('Job publication hold', lambda j: j.update({'if': "!contains(github.event.head_commit.message, '[no release]')"}))
mutate('Wrong artifact name', lambda j: j['steps'][1]['with'].update(name='Other-artifact'))
mutate('Wrong destination', lambda j: j['steps'][1]['with'].update(path='other'))
mutate('Cross-run override', lambda j: j['steps'][1]['with'].update({'run-id': '123'}))
mutate('Cross-repository override', lambda j: j['steps'][1]['with'].update(repository='example/other'))
mutate('Token override', lambda j: j['steps'][1]['with'].update({'github-token': '${{ github.token }}'}))
mutate('Mutable download pin', lambda j: j['steps'][1].update(uses='actions/download-artifact@v4'))
mutate('Mutable checkout pin', lambda j: j['steps'][0].update(uses='actions/checkout@v4'))
mutate('Persistent checkout credentials', lambda j: j['steps'][0]['with'].update({'persist-credentials': True}))
mutate('Checkout after download', lambda j: j['steps'].__setitem__(slice(0, 2), list(reversed(j['steps'][:2]))))
mutate('Missing verifier', lambda j: j['steps'].pop(2))
mutate('Verification after portable execution', lambda j: j['steps'].__setitem__(slice(2, 4), list(reversed(j['steps'][2:4]))))
mutate('Verification failure suppressed', lambda j: j['steps'][2].update({'continue-on-error': True}))
mutate('Verification conditional', lambda j: j['steps'][2].update({'if': 'false'}))
mutate('Wrong checksum algorithm', lambda j: j['steps'][2].update(run=j['steps'][2]['run'].replace('-Algorithm SHA256', '-Algorithm SHA1')))
mutate('Package execution during verification', lambda j: j['steps'][2].update(run=j['steps'][2]['run'] + '\nStart-Process .\\fixture.exe\n'))
mutate('Dependency install during verification', lambda j: j['steps'][2].update(run=j['steps'][2]['run'] + '\npip install example\n'))
mutate('Portable wrong archive', lambda j: j['steps'][3].update(run='./tools/test_windows_portable.ps1 -Archive other.zip'))
mutate('Installer wrong artifact', lambda j: j['steps'][4].update(run='./tools/test_windows_installer.ps1 -Installer other.exe'))
mutate('Installer omitted', lambda j: j['steps'].pop())
mutate('Installer failure suppressed', lambda j: j['steps'][4].update({'continue-on-error': True}))
for label, changed_text in [
    ('Release omits new validation', text.replace('needs: [qa, qt-gate, windows-validate, linux-smoke, release-gate]', 'needs: [qa, qt-gate, linux-smoke, release-gate]')),
    ('Release loses old Qt dependency', text.replace('needs: [qa, qt-gate, windows-validate, linux-smoke, release-gate]', 'needs: [qa, windows-validate, linux-smoke, release-gate]')),
    ('Release status override', text.replace("if: (startsWith(github.ref, 'refs/tags/v')", "if: always() && (startsWith(github.ref, 'refs/tags/v')")),
]:
    exercise(label, changed_text, release_tests, False, changed_text)
for test in release_tests[:3] + win_tests:
    exercise('Parent red: ' + test.__name__, old_text, [test], False, old_text)
check('All workflow controls meet expectations', all(c['passed'] for c in controls), count=len(controls))
(OUT / 'workflow-controls.json').write_text(json.dumps({'controls': controls, 'count': len(controls), 'valid': 2,
    'rejected': len(controls) - 2, 'baseline_expected_reds': 5,
    'limits': 'Maintained source assertions over in-memory workflows; no PowerShell/package/Actions execution.'}, indent=2) + '\n')
sys.path.insert(0, str(SOURCE))
from tools.ci_pip_install_audit import pip_installs, run_scalars, unhashed_installs
workflows = [p.read_text() for p in sorted((SOURCE / '.github/workflows').glob('*.yml'))]
totals = (len(workflows), sum(len(list(run_scalars(s))) for s in workflows), sum(len(pip_installs(s)) for s in workflows), sum(len(unhashed_installs(s)) for s in workflows))
check('Actual scanner corpus21/203/42/41', totals == (21, 203, 42, 41))

archive_receipt = json.loads((AUTHOR / 'archive-receipt.json').read_text())
archive = AUTHOR / archive_receipt['archive']
check('Author archive exact hash/size', len(archive.read_bytes()) == 107875 and sha(archive.read_bytes()) == 'ad51b0d521d9d35cd90c185f575fffabcae5cc88676b442ae0acde7e7b12596d')
manifest_raw = (AUTHOR / 'evidence-manifest.json').read_bytes()
check('Author manifest exact hash', sha(manifest_raw) == '1e41d20ed8039449f7f8b090a8915c8c50f6cb1fb010acbfc50746977f087be7')
manifest = json.loads(manifest_raw)
with zipfile.ZipFile(archive) as z:
    check('Complete archive member set/CRC', len(z.namelist()) == 35 and z.testzip() is None and set(z.namelist()) == {r['path'] for r in manifest['payloads']} | {'evidence-manifest.json'})
    for row in manifest['payloads']:
        raw = z.read(row['path'])
        check('Author payload: ' + row['path'], raw == (AUTHOR / row['path']).read_bytes() and sha(raw) == row['sha256'] and len(raw) == row['bytes'])
for path in (AUTHOR / 'source').rglob('*'):
    if path.is_file():
        relative = path.relative_to(AUTHOR / 'source').as_posix()
        check('Archived source: ' + relative, path.read_bytes() == blob(HEAD, relative))
final = json.loads((AUTHOR / 'final-focused.json').read_text())
check('Tested author bytes equal final source', final['staged_tree'] == TREE and all(sha(blob(HEAD, p)) == h for p, h in final['source_sha256'].items()))
red_source = json.loads((AUTHOR / 'spec-first-and-red-source.json').read_text())
check('Spec-first receipt binds unchanged parent workflow', red_source['base'] == PARENT and red_source['workflow_sha256'] == sha(blob(PARENT, WF)) and all(red_source['amended_before_workflow'][p] == sha(blob(HEAD, p)) for p in ['docs/specs/REGISTRY.md', 'docs/specs/windows-acceptance-and-milestone-builds.md']))
red_xml = ET.parse(AUTHOR / 'red.xml')
check('Five original intended failures retained', len(red_xml.findall('.//testcase')) == 5 and len(red_xml.findall('.//failure')) == 5 and not red_xml.findall('.//error'))
initial = (AUTHOR / 'red-initial-collection.log').read_text()
check('Author initial syntax error retained', 'SyntaxError' in initial and 'unmatched' in initial and (AUTHOR / 'initial-test-collection-error.py.txt').is_file())
bundle = subprocess.run(['git', '-C', str(SOURCE), 'bundle', 'verify', str(AUTHOR / 'local-recovery-source.bundle')], capture_output=True)
(OUT / 'bundle-verification.log').write_bytes(bundle.stdout + bundle.stderr)
check('Local source recovery bundle verifies', bundle.returncode == 0)
check('Source remains frozen and clean', git('rev-parse', 'HEAD').decode().strip() == HEAD and not git('status', '--porcelain=v1', '--untracked-files=all').strip())
report = {'head': HEAD, 'tree': TREE, 'parent': PARENT, 'checks_passed': len(checks), 'checks': checks,
          'workflow_controls': len(controls), 'baseline_expected_reds': 5,
          'source_mutations': False, 'native_execution': False, 'hosted_windows_acceptance': 'pending', 'author_archive': archive_receipt}
(OUT / 'source-review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ['head', 'tree', 'checks_passed', 'workflow_controls', 'baseline_expected_reds']}, indent=2))
