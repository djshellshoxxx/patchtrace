# Independent Windows downloaded-artifact review

**CLEAR for exact-source hosted qualification. No concrete source blocker was found.** This clearance does not claim that the Windows verifier fixtures or downloaded packages have executed on Windows.

| Identity | Exact value |
|---|---|
| Candidate commit | `1c70cd5f8053f75c269da673a24a82f221180650` |
| Complete tree | `a39d650ca7fa2b41ece017ea492396722a4142d9` |
| Parent | `c4eb63c55a35a1c2a927f4aeb4d42c8b96ff45ff` |

## Verified change and preserved behavior

The six changed paths are the Windows workflow, its existing acceptance specification and registry row, release-gate tests, the C5 current-corpus regression, and the new downloaded-artifact test module. The retained spec-first receipt binds the amended contract to the unchanged parent workflow; all five intended source regressions fail on that parent.

The new five-step `windows-validate` job waits for both `qa` matrix legs, uses a fresh Windows runner, has a 45-minute timeout, checks out before downloading and uses the already-reviewed full Action commits. Exact pinned download-action sources confirm that the named no-token download resolves the current run's artifact directly into `dist`; no repository/run/token override exists in this job.

The verifier first requires all four ZIP/Setup/sidecar members as regular, non-reparse files. It then checks both sidecars as single SHA-256 records with the exact corresponding basename, and hashes both fixed artifacts. Neither smoke step begins until both checks finish. Errors terminate the verifier. The unchanged portable and installer scripts use the packaged application and native PowerShell/Windows facilities; the validation job installs no Python/application/development dependencies or NSIS compiler and rebuilds nothing.

Release directly needs the new job in addition to every old dependency. Its condition and publication hold are unchanged. Removing only the new job and this needs entry restores the entire parent workflow byte-for-byte. All prior jobs, concurrency, upload behavior, triggers, permissions, paths, defaults, pins, `[no release]`/`[no deploy]` holds, source code and tools remain unchanged. Existing release-test functions outside the three required job-list assertions are AST-identical. The C5 test changes only the Windows run-step count 33→36; the actual corpus is 21 workflows, 203 run scalars, 42 explicit installs and 41 unprotected installs. The two strict CODEX-5 expected failures retain their meaning.

## Independent validation

- 140 source/evidence checks passed.
- 27 separate shell/upstream-source checks passed; all six retrieved official source blobs were rehashed independently by the parent reviewer.
- 35 in-memory workflow controls behaved as expected: two valid forms accepted and 33 invalid forms rejected, including the five original parent regressions. Controls cover runner/dependencies, exact pins and artifact identity, cross-run overrides, checkout ordering, required verification, failure suppression, wrong package paths and preserved release dependencies.
- The exact-source ten-module selection completed in 2.864 seconds: **415 passed, 17 explicit PowerShell-unavailable skips, 2 strict CODEX-5 xfails; 434 cases total**, zero failures/errors. Source remained clean before and after. The dedicated environment's editable package path was checked under `-I -B`, with the repository tools namespace explicitly bound to the same frozen source root.

The 17 skipped fixture cases must execute on hosted Windows. Their fixture bytes are inert and never extracted or executed. No local PowerShell, package, installer, target binary, native engine or full test suite was executed. Counts overlap the author selection and are not additive coverage.

## PowerShell error-format assessment

The negative fixtures separately assert the error prefix and exact filename in stderr. Official PowerShell 7.4.6/7.5.0 formatter sources wrap at whitespace and place ANSI controls in line prefixes. At 80 columns or wider, the longest asserted prefix plus margin is 51 columns and the longest basename plus margin is 46, so those substrings remain contiguous when the full message wraps. No concrete formatting defect was demonstrated. This is a primary-source assessment, not execution evidence or a claim that either inspected tag is the eventual hosted runner version. Actual hosted fixture execution remains required.

## Preserved failures and evidence

The author ZIP retains the first unmatched-parenthesis test collection error (exit 4), its corrected source, and the subsequent five intended regression failures against the unchanged parent. The independent review also preserves its first isolated-import collection error (exit 2, zero executed assertions): Python `-I` omitted the repository tools namespace. The reviewer harness was corrected only by explicitly inserting the exact frozen source root before `pytest.main`; no source or environment changes were made. The subsequent maintained run passed with the counts above.

The original author archive has 35 members / 107,875 bytes, SHA-256 `ad51b0d521d9d35cd90c185f575fffabcae5cc88676b442ae0acde7e7b12596d`. Every payload, CRC, source snapshot and manifest hash was checked. Manifest SHA-256 is `1e41d20ed8039449f7f8b090a8915c8c50f6cb1fb010acbfc50746977f087be7`. The local source bundle verifies against its retained 2ae prerequisite. This portable independent archive includes the author archive unchanged, source/evidence proofs, maintained receipts, controls, both reviewer-harness attempts and the six upstream sources.

## Scope and remaining acceptance

Root may proceed to exact-source hosted qualification. Actual hosted Windows verifier fixtures and the new downloaded portable/installer job must pass before claiming package acceptance. No source/ref/PR/CI/ledger mutations, installs, environment rebinding, release or deployment occurred in this review. The work remains a narrow recovery from the historical CI donor; broader build/dev pinning, CODEX-5 closure, original 181/16 census accounting, pristine Windows/manual acceptance, signing and publisher authenticity remain separate.
