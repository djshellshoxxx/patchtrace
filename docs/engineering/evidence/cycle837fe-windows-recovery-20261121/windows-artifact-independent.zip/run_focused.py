"""Replay only the reviewed ten contract/packaging modules with exact-source binding."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/837fe19aae3a')
SOURCE = ROOT / 'repair-windows-artifact-validation'
OUT = ROOT / 'evidence/windows-artifact-validation-independent'
PYTHON = ROOT / 'windows-artifact-validation-venv/bin/python'
HEAD = '1c70cd5f8053f75c269da673a24a82f221180650'
TREE = 'a39d650ca7fa2b41ece017ea492396722a4142d9'


def git(*args):
    return subprocess.check_output(['git', '-C', str(SOURCE), *args]).decode().strip()


before = {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
          'status': git('status', '--porcelain=v1', '--untracked-files=all')}
assert before == {'head': HEAD, 'tree': TREE, 'status': ''}
bind_code = '''import hashlib, importlib.metadata, json, pathlib, sys, shutil
import patchtrace, pytest, yaml
p = pathlib.Path(patchtrace.__file__)
print(json.dumps({"python":sys.executable,"isolated":sys.flags.isolated,"bytecode_disabled":sys.dont_write_bytecode,
"patchtrace_file":str(p),"patchtrace_sha256":hashlib.sha256(p.read_bytes()).hexdigest(),
"direct_url":json.loads(importlib.metadata.distribution("patchtrace").read_text("direct_url.json")),
"pytest":pytest.__version__,"yaml":yaml.__version__,"pwsh":shutil.which("pwsh")}))'''
binding_run = subprocess.run([str(PYTHON), '-I', '-B', '-c', bind_code], cwd=SOURCE, capture_output=True, text=True, check=True)
binding = json.loads(binding_run.stdout)
assert binding['isolated'] == 1 and binding['bytecode_disabled']
assert binding['direct_url'] == {'dir_info': {'editable': True}, 'url': SOURCE.as_uri()}
assert binding['patchtrace_file'] == str(SOURCE / 'src/patchtrace/__init__.py')
(OUT / 'source-binding.json').write_text(json.dumps(binding, indent=2) + '\n')
modules = ['tests/test_windows_downloaded_artifacts.py', 'tests/test_release_gate.py',
           'tests/test_codex_pkg_packaging.py', 'tests/test_milestone_notes.py',
           'tests/test_windows_installer_manifest.py', 'tests/test_codex_pkg_workflows.py',
           'tests/test_codex5_command_audit_20261121.py', 'tests/test_spec_registry.py',
           'tests/test_site_workflow.py', 'tests/test_workflows.py']
(OUT / 'temporary-test-data').mkdir(exist_ok=True)
bootstrap = ('import sys; sys.path.insert(0, ' + repr(str(SOURCE)) + '); '
             'import tools.ci_pip_install_audit as audit; '
             'assert audit.__file__ == ' + repr(str(SOURCE / 'tools/ci_pip_install_audit.py')) + '; '
             'import pytest; raise SystemExit(pytest.main(sys.argv[1:]))')
argv = [str(PYTHON), '-I', '-B', '-c', bootstrap, '-q', '-ra', *modules,
        '-o', 'cache_dir=' + str(OUT / 'pytest-cache'),
        '--basetemp=' + str(OUT / 'temporary-test-data/maintained'),
        '--junitxml=' + str(OUT / 'maintained.xml')]
env = dict(os.environ, QT_QPA_PLATFORM='offscreen')
started = time.time()
run = subprocess.run(argv, cwd=SOURCE, env=env, text=True, capture_output=True)
duration = time.time() - started
(OUT / 'maintained.log').write_text(run.stdout + run.stderr)
cases = []
for node in ET.parse(OUT / 'maintained.xml').findall('.//testcase'):
    state = 'passed'
    detail = ''
    for tag in ('failure', 'error', 'skipped'):
        found = node.find(tag)
        if found is not None:
            state = 'xfailed' if tag == 'skipped' and found.get('type') == 'pytest.xfail' else tag
            detail = (found.get('message') or '') + '\n' + (found.text or '')
            break
    cases.append({'class': node.get('classname'), 'name': node.get('name'), 'status': state, 'detail': detail.strip()})
counts = {state: sum(c['status'] == state for c in cases) for state in ('passed', 'failure', 'error', 'xfailed', 'skipped')}
after = {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
         'status': git('status', '--porcelain=v1', '--untracked-files=all')}
receipt = {'argv': argv, 'cwd': str(SOURCE), 'before': before, 'after': after, 'exit_code': run.returncode,
           'seconds': duration, 'counts': counts, 'total_cases': len(cases), 'cases': cases,
           'test_file_sha256': {p: hashlib.sha256((SOURCE / p).read_bytes()).hexdigest() for p in modules},
           'native_execution': False, 'overlaps_author_selection': True}
(OUT / 'maintained.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
assert after == before
assert run.returncode == 0
assert counts == {'passed': 415, 'failure': 0, 'error': 0, 'xfailed': 2, 'skipped': 17}
assert all('PowerShell unavailable' in c['detail'] for c in cases if c['status'] == 'skipped')
assert all('CODEX-5' in c['detail'] for c in cases if c['status'] == 'xfailed')
print(json.dumps({k: receipt[k] for k in ['exit_code', 'seconds', 'counts', 'total_cases', 'before', 'after']}, indent=2))
