# Windows downloaded-artifact shell subreview

**Verdict: no concrete source-scope blocker.** This is a read-only subreview of commit `1c70cd5f8053f75c269da673a24a82f221180650`, tree `a39d650ca7fa2b41ece017ea492396722a4142d9`, exact parent `c4eb63c55a35a1c2a927f4aeb4d42c8b96ff45ff`. The worktree was clean before and after inspection, and both publication hold markers are present in the commit. All 27 recorded source/hash checks passed.

## Source findings

The exact six changed paths are recorded in `review.json` and the complete immutable delta is preserved in `source-delta.patch`. Removing only the added `windows-validate` job and its new `release.needs` entry reproduces the parent workflow byte for byte. Existing triggers, concurrency, permissions, QA/Qt/Linux jobs, upload paths, native smoke calls, release condition and publication holds remain unchanged.

The new job runs on a separate Windows runner after both QA matrix legs. Checkout precedes the download. It uses the same reviewed full action commits and asks for the single same-run artifact `PatchTrace-windows-x64`, extracting it directly into `dist`. No token, run-id, repository override, interpreter setup, dependency install, rebuild or NSIS compiler install appears in the job.

All four expected regular, non-reparse files must exist before any digest checking. Both sidecars must consist of a single filename-bound SHA-256 record; both digests must match before either smoke begins. The fixed paths, case-sensitive basename comparison, exact record boundaries, independent file hashes, terminating PowerShell errors and required steps match the declared bounded contract. A valid ZIP cannot let a missing or corrupt installer through to either smoke.

The existing portable and installer scripts, both builders and the full frozen CLI harness have identical Git blobs to the parent. The portable script uses packaged executable startup/CLI checks; the installer script uses native Windows/PowerShell facilities for install, installed runtime checks, registry/shortcut checks, uninstall and project-data sentinels. Their calls do not require installing project Python/dev dependencies or the installer compiler in this fresh job. Standard hosted-image software may still be present; no pristine-machine claim is made.

## Exact pinned download action

Read-only GitHub connector fetches retained these official files at `d3f86a106a0bac45b974a628896c90dbdf5c8093`:

- [action.yml](https://github.com/actions/download-artifact/blob/d3f86a106a0bac45b974a628896c90dbdf5c8093/action.yml), Git blob `7fc4fb55c7d0c7b198b1c7466e1efd7c7d05fb26`.
- [src/download-artifact.ts](https://github.com/actions/download-artifact/blob/d3f86a106a0bac45b974a628896c90dbdf5c8093/src/download-artifact.ts), Git blob `5cc6b1704fb5ef0d4487ed63d910d4f8a9f2fbd2`.

The manifest documents current-repository/current-run behavior when no GitHub token is supplied. The implementation only adds a cross-run `findBy` override when a token is supplied. The named-artifact path resolves the exact name, refuses an absent artifact and passes the resolved destination directly to the download client, without an extra artifact-name directory. Rejected operations are handled with `core.setFailed`.

These facts concern current-run selection and transport/extraction behavior. The new checksum gate establishes equality to sidecars from that run. It does not claim signing, publisher authenticity or protection against a concurrent hostile writer.

## PowerShell negative-fixture stderr assessment

No PowerShell executable was installed or executed. Official PowerShell formatter source was inspected at explicit tags `v7.4.6` and `v7.5.0`; exact fetched blob hashes were independently recomputed and retained in `upstream-index.json`. Those tags are comparative source evidence, not a claim about the version on a future hosted runner.

Both inspected ConciseView implementations wrap the error message at whitespace and insert ANSI controls in display prefixes, not arbitrarily inside the asserted message tokens. The error prefixes are 35, 37 and 44 characters; with the seven-character display margin they occupy 42, 44 and 51 columns. Artifact basenames are 32 characters and sidecar basenames 39 characters, all without whitespace. At an 80-column display or wider, the asserted prefixes and complete basenames survive the formatter's wrapping as contiguous substrings. A missing sidecar message can wrap before the basename while both separately asserted substrings remain intact.

This establishes no demonstrated stderr-formatting blocker in the reviewed implementations. An unusually narrow host, unavailable Windows console or different future formatter remains outside this source-only observation. Actual hosted execution of the exact inert-fixture tests is still required.

## Validation boundary and preservation

This subreview executed zero maintained tests, zero PowerShell fixtures, zero packages/installers and zero native engines. It made no source, index, ref, PR, CI or environment changes. Only immutable Git reads, standard-library source/hash comparisons and public GitHub file GETs were performed. All written files are in this dedicated scratch evidence directory.

The parent reviewer owns maintained tests and overall evidence validation. This result does not establish hosted downloaded-package acceptance, pristine Windows 11/manual GUI/accessibility acceptance, signing/trust, upgrade behavior or full offline-backend acceptance. Existing historical evidence and broader unresolved pin/dependency work remain unaffected.

