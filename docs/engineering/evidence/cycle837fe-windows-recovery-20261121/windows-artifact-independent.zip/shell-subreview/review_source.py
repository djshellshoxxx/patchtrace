"""Read-only immutable source inspection; no maintained tests or native execution."""
from __future__ import annotations

import datetime
import hashlib
import json
import subprocess
from pathlib import Path

REPO = Path("/workspace/scratch/837fe19aae3a/repair-windows-artifact-validation")
OUT = Path(__file__).resolve().parent
HEAD = "1c70cd5f8053f75c269da673a24a82f221180650"
TREE = "a39d650ca7fa2b41ece017ea492396722a4142d9"
PARENT = "c4eb63c55a35a1c2a927f4aeb4d42c8b96ff45ff"

def git(*args: str) -> bytes:
    return subprocess.check_output(["git", "-C", str(REPO), *args])

def blob(ref: str, path: str) -> bytes:
    return git("show", f"{ref}:{path}")

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

checks: list[dict] = []
def check(name: str, condition: bool, evidence: object) -> None:
    checks.append({"name": name, "passed": bool(condition), "evidence": evidence})
    if not condition:
        raise AssertionError(name)

before = git("status", "--porcelain=v1").decode()
check("clean_before", before == "", before)
check("exact_head", git("rev-parse", "HEAD").decode().strip() == HEAD, HEAD)
check("exact_tree", git("rev-parse", HEAD + "^{tree}").decode().strip() == TREE, TREE)
check("exact_parent", git("show", "-s", "--format=%P", HEAD).decode().strip() == PARENT, PARENT)
message = git("show", "-s", "--format=%B", HEAD).decode()
check("both_holds_in_commit", "[no release]" in message and "[no deploy]" in message, message)
expected_paths = [
    ".github/workflows/qa-windows.yml",
    "docs/specs/REGISTRY.md",
    "docs/specs/windows-acceptance-and-milestone-builds.md",
    "tests/test_codex5_command_audit_20261121.py",
    "tests/test_release_gate.py",
    "tests/test_windows_downloaded_artifacts.py",
]
changed = git("diff", "--name-only", PARENT, HEAD).decode().splitlines()
check("exact_six_paths", changed == expected_paths, changed)
workflow = blob(HEAD, expected_paths[0]).decode()
old_workflow = blob(PARENT, expected_paths[0]).decode()
start = workflow.index("  windows-validate:\n")
end = workflow.index("  # Repeats the GUI test files", start)
job = workflow[start:end]
restored = (workflow[:start] + workflow[end:]).replace(
    "needs: [qa, qt-gate, windows-validate, linux-smoke, release-gate]",
    "needs: [qa, qt-gate, linux-smoke, release-gate]",
)
check("workflow_exact_reverse_delta", restored == old_workflow,
      "Removing only the new job and its release dependency reproduces the parent workflow byte for byte.")
check("job_same_run_download_shape", all(s in job for s in [
    "    needs: qa\n", "    runs-on: windows-latest\n", "    timeout-minutes: 45\n",
    "actions/checkout@11d5960a326750d5838078e36cf38b85af677262",
    "persist-credentials: false", "actions/download-artifact@d3f86a106a0bac45b974a628896c90dbdf5c8093",
    "name: PatchTrace-windows-x64", "path: dist",
]), job)
check("job_has_no_failure_or_hold_bypass", all(s not in job for s in [
    "continue-on-error:", "    if:", "      - if:", "        if:", "github-token:",
    "run-id:", "repository:", "pip install", "setup-python", "choco install",
    "tools/build_windows.py", "tools/package_windows_installer.py",
]), "No bypass, cross-run/repo/token input, interpreter/dependency install, or package rebuild.")
presence = job.index("foreach ($memberName")
hashloop = job.index('$artifactPath = Join-Path $artifactDirectory $artifactName')
portable = job.index("- name: Extract and run")
installer = job.index("- name: Install, launch, and uninstall")
check("all_presence_before_both_hashes_before_smokes",
      presence < hashloop < portable < installer, [presence, hashloop, portable, installer])
check("checksum_step_is_fail_closed", all(s in job for s in [
    '$ErrorActionPreference = "Stop"', "Test-Path -LiteralPath $memberPath -PathType Leaf",
    "Get-Item -LiteralPath $memberPath -Force", "[IO.FileAttributes]::ReparsePoint",
    "-cne $artifactName", "Get-FileHash -LiteralPath $artifactPath -Algorithm SHA256",
    "-ine $recordMatch.Groups[1].Value",
]), "Required files, reparse refusal, case-sensitive name binding, independent SHA-256 comparison, terminating errors.")
script_paths = [
    "tools/test_windows_portable.ps1",
    "tools/test_windows_installer.ps1",
    "tools/build_windows.py",
    "tools/package_windows_installer.py",
    "tools/frozen_smoke.py",
]
unchanged = []
for path in script_paths:
    current = blob(HEAD, path)
    old = blob(PARENT, path)
    equal = current == old
    unchanged.append({
        "path": path, "identical_to_parent": equal, "bytes": len(current),
        "git_blob": git("rev-parse", f"{HEAD}:{path}").decode().strip(),
        "sha256": sha256(current),
    })
    check("preserved_" + path, equal, unchanged[-1])
builders = "\n".join(blob(HEAD, p).decode() for p in script_paths[2:4])
check("actual_builders_emit_contract_records",
      "  {archive.name}\\n" in builders and '  {path.name}\\n' in builders,
      "Both tracked builders write ASCII digest, two spaces, exact basename and one LF.")

upstream_index = json.loads((OUT / "upstream-index.json").read_text())
for row in upstream_index:
    path = OUT / row["file"]
    data = path.read_bytes()
    def git_blob_sha(value: bytes) -> str:
        return hashlib.sha1(b"blob " + str(len(value)).encode() + b"\0" + value).hexdigest()
    if git_blob_sha(data) != row["git_blob_sha"] and data.endswith(b"\n"):
        candidate = data[:-1]
        if git_blob_sha(candidate) == row["git_blob_sha"]:
            path.write_bytes(candidate)
            data = candidate
    row.update({"bytes": len(data), "sha256": sha256(data), "recomputed_git_blob": git_blob_sha(data)})
    check("upstream_blob_" + row["file"], row["git_blob_sha"] == git_blob_sha(data), row)
(OUT / "upstream-index.json").write_text(json.dumps(upstream_index, indent=2) + "\n")
action = (OUT / "upstream/download-artifact-action.yml").read_text()
action_ts = (OUT / "upstream/download-artifact.ts").read_text()
check("pinned_download_default_current_run",
      "current repository and the current workflow run" in action
      and "default: ${{ github.repository }}" in action
      and "default: ${{ github.run_id }}" in action
      and "if (inputs.token) {" in action_ts and "options.findBy = {" in action_ts,
      "No supplied token: no cross-run findBy override; manifest specifies current repo/run.")
check("pinned_named_download_direct_path",
      "const isSingleArtifactDownload = !!inputs.name" in action_ts
      and "artifactClient.getArtifact(" in action_ts
      and "if (!targetArtifact)" in action_ts
      and "isSingleArtifactDownload || inputs.mergeMultiple" in action_ts
      and "? resolvedPath" in action_ts,
      "Exact name chooses a single artifact, absence throws, and named downloads use resolved dist directly.")
check("pinned_download_failure_sets_failed",
      "run().catch(err =>" in action_ts and "core.setFailed(" in action_ts,
      "Action rejects unresolved artifacts and download failures rather than continuing.")
prefixes = [
    "Missing downloaded artifact member:",
    "Downloaded artifact SHA-256 mismatch:",
    "Invalid downloaded artifact SHA-256 sidecar:",
]
names = ["PatchTrace-0.1.0-windows-x64.zip", "PatchTrace-Windows-x64-Setup.exe"]
formatting = {
    "scope": "Primary-source formatting assessment only; no PowerShell process was executed.",
    "formatter_tags": ["v7.4.6", "v7.5.0"],
    "asserted_prefix_lengths": {p: len(p) for p in prefixes},
    "filename_lengths": {n: len(n) for n in names} | {n + ".sha256": len(n + ".sha256") for n in names},
    "concise_view_margin": 7,
    "reasoning": [
        "ConciseView truncates at whitespace; complete filenames contain no whitespace.",
        "ANSI sequences decorate prefixes/whole message lines, not arbitrary characters inside asserted tokens.",
        "The longest asserted error prefix plus display margin is 51 columns; longest basename plus margin is 46.",
        "At 80 columns or wider, each asserted prefix and filename survives the formatter's wrapping as one substring.",
        "A host narrower than 51 columns, unavailable Windows console, or different future formatter is untested here.",
        "PowerShell sources were read at two explicit version tags and their exact blob hashes were independently recomputed; neither tag is claimed to identify the eventual hosted runner version.",
    ],
    "verdict": "No demonstrated formatting blocker; actual hosted Windows fixtures remain required."
}
after = git("status", "--porcelain=v1").decode()
check("clean_after", after == "", after)
path_metadata = []
for path in changed:
    data = blob(HEAD, path)
    path_metadata.append({"path": path, "bytes": len(data), "git_blob": git("rev-parse", f"{HEAD}:{path}").decode().strip(), "sha256": sha256(data)})
(OUT / "source-delta.patch").write_bytes(git("diff", "--binary", PARENT, HEAD))
(OUT / "windows-validate-job.yml").write_text(job)
report = {
    "schema": "windows-artifact-shell-independent/v1",
    "generated_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "source": {"commit": HEAD, "tree": TREE, "parent": PARENT, "worktree": str(REPO)},
    "verdict": "CLEAR_SOURCE_SCOPE_NO_CONCRETE_BLOCKER",
    "checks": checks, "check_count": len(checks), "all_passed": all(c["passed"] for c in checks),
    "changed_paths": path_metadata, "unchanged_runtime_scripts_and_builders": unchanged,
    "pinned_upstream_sources": upstream_index,
    "powershell_stderr_assessment": formatting,
    "execution_limits": {
        "maintained_tests_executed": 0, "native_processes_executed": 0,
        "fixture_artifacts_executed": 0, "source_ref_ci_mutations": False,
        "environment_installs": False, "hosted_acceptance_claim": False,
        "checks_executed": "Git reads, local standard-library source/hash comparisons, read-only public GitHub source GETs."
    },
    "findings": [
        "The six-path delta adds a five-step Windows job and one release dependency; reverse-delta equality proves other workflow bytes unchanged.",
        "Presence of all four regular/non-reparse members is checked before both filename-bound sidecars and both artifact digests; verification completes before either smoke.",
        "The pinned action's named no-token download uses the current workflow run and extracts directly into dist.",
        "Both unchanged smoke scripts use packaged executable payloads and PowerShell/Windows facilities; the new job needs no project Python/dev install or NSIS compiler installation.",
        "Terminating verification errors and required smoke failures block the job and existing release dependency graph.",
        "Same-run digest equality is not publisher authenticity, concurrent-hostile-writer protection, pristine-machine acceptance, or a full offline-backend claim.",
    ],
}
(OUT / "review.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({"verdict": report["verdict"], "checks": len(checks), "source": report["source"], "review_sha256": sha256((OUT / "review.json").read_bytes())}, indent=2))

