# Historical Ghidriff sequential-launch branch accounting

## Disposition

**SUPERSEDED — complete unique branch delta accounted for.** No missing compatible implementation was found in `chatgpt/ghidriff-sequential-lock-fix-20261017` relative to the frozen comparison source. The maintained implementation retains the sequential Ghidriff option and the adapter-version cache provenance change. Its stronger interpreter-isolation contract explains the two failures when the unchanged historical final test is replayed against current source. The dated QA note remains byte-identical.

This is a read-only branch disposition for the next independently reviewed authoritative checkpoint. It neither changes the original **181 unmatched / 16 patch-equivalent** census nor authorizes branch deletion. It makes no claim that the remaining inventory is exhausted.

## Exact source identities

| Identity | Value |
| --- | --- |
| Branch | `chatgpt/ghidriff-sequential-lock-fix-20261017` |
| Freshly read remote head | `f6b7545bcc7a161440ab7119233c204510571370` |
| Donor tree | `af5312f2802e1ba926104df7df189549b5a63c0e` |
| Exact merge base | `70e33fd77570329ba23afc58a38616270636d37c` |
| Frozen comparison source | `f596471b8909ec8e28e0624041d60f03d520591d` |
| Frozen comparison tree | `dffeed541749850ef54a130cec0fa56c0fd2f01c` |
| Complete unique history | Five linear commits; no unique merge commits |
| Complete changed-path union | Three net paths and three historical paths |

The successful read-only Git ref response is retained in `ref-refresh.json`. An earlier encoded-branch URL was rejected with HTTP 400; that refusal is retained separately in `ref-refresh-invalid-url.json`. No remote or local reference was moved.

## Selection boundary

The authoritative ledger, original inventory files, prior semantic dispositions and 116 top-level completed review/report files were inspected before selection. The selected branch was present in inventory metadata without a completed semantic disposition. Its concrete value is dependency compatibility and raw-cache provenance: sequential Ghidriff analysis and an adapter revision that distinguishes the changed behavior in cache identity.

The offline-bundle no-overwrite branch was excluded because the cycle-95fe review already classified it. A small timeout-only packaging candidate received metadata/patch inspection and was not classified in this task. `metadata-shortlist.json` retains this search boundary. An initial metadata parsing error involving compact rename records is preserved in `discovery-errors.json`; it caused no source or test changes.

## Entire unique history

| Commit | Unique contribution and accounting |
| --- | --- |
| `ff3afa5a44fcf54a9c6acf3e8bb1d3552f59955e` | Adds the original sequential-threading test before its helper exists. Its source-bound replay retains the missing-helper collection failure. |
| `ef9262cb8883e49a5d8af3c776a87524ca9a352f` | Adds the helper returning `--no-threaded`, uses it in the actual engine argv, and changes `RAW_ADAPTER_VERSION` from `/1` to `/2`. The original test passes on this source. |
| `a660dcf515a99adeeef145520e1c37f1d42aef48` | Adds the dated Windows-lock QA note. Runtime and test blobs equal the preceding implementation commit; no redundant replay was needed. |
| `4156565476b3c2aeea48bc513d9ec40ea0128246` | Refactors the temporary helper into `_ghidriff_argv` and makes `run_comparison` call it. The then-existing test still imports the removed helper; its collection failure is retained. |
| `f6b7545bcc7a161440ab7119233c204510571370` | Repairs that test seam and tests all four bundle/symbol combinations against the argv builder. All four unchanged original cases pass on the donor tip. |

Raw commit objects, full per-commit patches, the original test versions and all changed source versions are preserved. The 23 introduced Git objects are retained in a pack, strictly verified against existing base objects. This introduced-object pack requires the existing base history to reconstruct ancestry; the separate donor fixture-source ZIP preserves the complete source needed for the bounded historical fixture replays without that dependency.

## Complete changed-path comparison

| Path | Disposition | Complete semantic comparison |
| --- | --- | --- |
| `src/patchtrace/backend.py` | SUPERSEDED | Current `RAW_ADAPTER_VERSION` remains `patchtrace-ghidriff-adapter/2`. The shared argv list contains exactly one `--no-threaded` and no enabling `--threaded`; both direct and local-symbol launcher paths use it. `run_comparison` obtains this builder's argv and passes it to `run_process`. The raw cache receives the adapter version through `RuntimeFingerprint`; that fingerprint participates in cache keys. Later launch isolation, venv-symlink handling, local-symbol support and force-identical handling preserve the sequential option. |
| `tests/test_ghidriff_threading.py` | SUPERSEDED | The final donor file and maintained file are byte-identical after one assertion replacement: the old bundle-only `-I` expectation becomes mandatory `['-I', '-X', 'utf8']`. All original sequential-flag, symbol-policy, ordering and four-combination coverage remains. The unchanged original has two non-bundled isolation-policy failures on current source; the maintained four cases pass. |
| `docs/qa/ghidriff-windows-lock-20261017.md` | DUPLICATE | All nine lines remain byte-identical. This is explicitly dated historical evidence, with causal uncertainty and future native validation requirements preserved. |

The current `docs/specs/ghidriff-launcher-symbols.md` contract requires isolated Python for direct and local launchers, private per-run scratch, verified staged inputs and preservation of `--no-threaded`. The old non-bundled isolation expectation is incompatible with that current contract and should not be restored. `os.path.abspath` also preserves the chosen venv interpreter symlink instead of resolving it to another interpreter path.

The historical QA note reports user-log observations of threaded analysis, a Ghidra overlapping-file-lock exception, later timeouts and cancellation. It explicitly does not establish that the lock warning caused cancellation. The original private logs were never committed and have not been reconstructed. Its requirement for real Windows repetitions and a separate cancellation exercise is not satisfied by these source fixtures.

## Bounded source-bound checks

The existing frozen `pages-config-hold-venv` was reused without installation or editable rebinding. Each process ran with `-I -B`, explicitly inserted the selected source before importing it, and asserted the exact `patchtrace.backend` source path. The unchanged editable metadata and the selected backend hash were printed in each receipt. Exact argv, source/test identities, durations, stdout, stderr and JUnit are retained in the per-run receipts and `test-outcomes.json`.

| Replay | Actual result | Meaning |
| --- | --- | --- |
| Initial test-only commit | One collection error; exit 2 | Missing `_ghidriff_threading_args` preserved. |
| First implementation | 1 passed | Original helper contract satisfied. |
| Intermediate argv refactor | One collection error; exit 2 | Test still imports the removed helper; preserved. |
| Final donor source and original final test | 4 passed | Final historical branch is coherent for all four authored combinations. |
| Current source and unchanged original final test | 2 passed, 2 failed | Both failures concern the obsolete non-bundled isolation expectation. |
| Current source and maintained threading test | 4 passed | Current isolation and all retained sequential/symbol assertions hold. |
| Current adapter-version cache-key selector | 1 passed | A changed adapter fingerprint misses the cache using synthetic payload bytes. |

These counts overlap and must remain separate. They are present-day replays of exact historical source, not reconstructed historical CI outcomes. The cache selector was `tests/test_enrichment_cache.py::test_each_fingerprint_field_change_misses[adapter_version]`; other runs used the unchanged original or maintained `tests/test_ghidriff_threading.py` file.

All checks were limited to Python argument construction and one synthetic cache fixture. No Java, Ghidra, Ghidriff engine, native package, untrusted target, full suite, hosted workflow or manual dispatch was executed. There is no new native acceptance claim.

## Preservation and handoff

`classification.json` is the machine-readable full-branch disposition. `source-history.json`, `semantic-proofs.json`, `fixture-source-bindings.json`, `current-cache-context-source.json` and `final-source-binding.json` provide source and proof bindings. Nineteen selected source snapshots are preserved, together with the original donor-source ZIP, all five commits/patches, the introduced-object pack, prior authoritative inputs and every failed/successful check output.

The portable archive includes a SHA-256 manifest; the external archive receipt records the archive digest, size, member count, CRC verification and member-hash verification. Unpacked reproducible `runtime-snapshots/` and temporary fixture directories are excluded from the archive; their exact source archive and source-binding records are included. Product source, workflows, ledgers, documentation, refs and active integration worktrees were not edited.

No compatible recovery patch is recommended. Root can submit this complete-branch SUPERSEDED disposition for independent review and later ledger reconciliation while preserving the original census and the open native/product gates.
