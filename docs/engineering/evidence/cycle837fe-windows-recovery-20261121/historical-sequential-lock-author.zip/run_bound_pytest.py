from pathlib import Path
import hashlib
import importlib.metadata
import json
import runpy
import sys

source=Path(sys.argv[1]).resolve()
sys.path[:0]=[str(source / "src"),str(source),str(source / "tests")]
import patchtrace
import patchtrace.backend as backend
assert Path(backend.__file__).resolve()==source / "src/patchtrace/backend.py"
print(json.dumps({"source_root":str(source),"python":sys.executable,"patchtrace":patchtrace.__file__,"backend":backend.__file__,"backend_sha256":hashlib.sha256(Path(backend.__file__).read_bytes()).hexdigest(),"editable_metadata":importlib.metadata.distribution("patchtrace").read_text("direct_url.json"),"note":"Shared frozen dependency environment not rebound; explicit exact source import verified."}),flush=True)
sys.argv=["pytest",*sys.argv[2:]]
runpy.run_module("pytest",run_name="__main__")
