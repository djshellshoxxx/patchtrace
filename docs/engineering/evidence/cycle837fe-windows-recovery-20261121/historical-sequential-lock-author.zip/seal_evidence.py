"""Seal only this read-only review's evidence; never modify repository source."""

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1] / 'repair-live-ghidra-archive'
CURRENT = 'f596471b8909ec8e28e0624041d60f03d520591d'
TREE = 'dffeed541749850ef54a130cec0fa56c0fd2f01c'
DONOR = 'f6b7545bcc7a161440ab7119233c204510571370'
BASE = '70e33fd77570329ba23afc58a38616270636d37c'
ARCHIVE = 'historical-ghidriff-sequential-lock-review.zip'
MANIFEST = 'evidence-manifest.json'
RECEIPT = 'archive-receipt.json'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


def main():
    history = json.loads((ROOT / 'source-history.json').read_text())
    classification = json.loads((ROOT / 'classification.json').read_text())
    assert git('rev-parse', 'HEAD').decode().strip() == CURRENT
    assert git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE
    assert git('status', '--porcelain=v1') == b''
    assert git('merge-base', CURRENT, DONOR).decode().strip() == BASE
    unique = git('rev-list', '--reverse', f'{CURRENT}..{DONOR}').decode().splitlines()
    assert unique == [row['sha'] for row in history['all_unique_commits']]
    assert len(unique) == 5
    assert git('rev-list', '--merges', f'{CURRENT}..{DONOR}') == b''
    paths = git('diff', '--name-only', BASE, DONOR).decode().splitlines()
    assert sorted(paths) == sorted(history['net_changed_paths'])
    historical_paths = set()
    for sha in unique:
        historical_paths.update(
            git('diff-tree', '--no-commit-id', '--name-only', '-r', sha)
            .decode().splitlines()
        )
        raw = (ROOT / 'commits' / f'{sha}.txt').read_bytes()
        object_bytes = f'commit {len(raw)}\0'.encode() + raw
        assert hashlib.sha1(object_bytes).hexdigest() == sha
    assert sorted(historical_paths) == sorted(paths)

    snapshots = history['source_snapshots'] + json.loads(
        (ROOT / 'current-cache-context-source.json').read_text()
    )
    for entry in snapshots:
        data = (ROOT / 'source' / entry['commit'] / entry['path']).read_bytes()
        assert digest(data) == entry['sha256']
        assert len(data) == entry['bytes']
        assert git('show', f"{entry['commit']}:{entry['path']}") == data
        assert git('rev-parse', f"{entry['commit']}:{entry['path']}").decode().strip() == entry['blob']
    assert len(snapshots) == 19

    prior_bindings = []
    for path in sorted((ROOT / 'prior-inputs').rglob('*')):
        if not path.is_file():
            continue
        rel = path.relative_to(ROOT / 'prior-inputs').as_posix()
        data = path.read_bytes()
        assert git('show', f'{CURRENT}:{rel}') == data
        prior_bindings.append({'path': rel, 'sha256': digest(data), 'bytes': len(data)})
    assert classification['classification'] == 'SUPERSEDED'
    assert classification['missing_compatible_contribution_found'] is False
    assert classification['original_census_preserved'] == {'unmatched': 181, 'patch_equivalent': 16}
    fixture = json.loads((ROOT / 'fixture-source-bindings.json').read_text())['archive']
    assert digest((ROOT / fixture['path']).read_bytes()) == fixture['sha256']
    with zipfile.ZipFile(ROOT / fixture['path']) as donor_zip:
        assert donor_zip.testzip() is None
    assert git('status', '--porcelain=v1') == b''
    write_json('final-source-binding.json', {
        'checked_at_utc': datetime.now(timezone.utc).isoformat(),
        'head': CURRENT, 'tree': TREE, 'worktree_clean': True,
        'donor': DONOR, 'merge_base': BASE,
        'all_five_unique_commits_verified': True,
        'all_three_historical_and_net_paths_verified': True,
        'all_nineteen_source_snapshot_bytes_verified': True,
        'all_raw_commit_ids_verified': True,
        'prior_inputs_exactly_match_comparison_git_tree': prior_bindings,
        'native_acceptance_claim': False,
        'original_census_preserved': {'unmatched': 181, 'patch_equivalent': 16},
    })

    excluded_dirs = {'runtime-snapshots', 'tmp', '__pycache__', '.pytest_cache'}
    excluded_files = {ARCHIVE, MANIFEST, RECEIPT}
    members = []
    for path in sorted(ROOT.rglob('*')):
        rel = path.relative_to(ROOT)
        if (not path.is_file() or set(rel.parts) & excluded_dirs
                or rel.as_posix() in excluded_files):
            continue
        assert not path.is_symlink()
        data = path.read_bytes()
        members.append({'path': rel.as_posix(), 'bytes': len(data), 'sha256': digest(data)})
    write_json(MANIFEST, {
        'schema': 'patchtrace/evidence-manifest/1',
        'scope': 'Complete read-only sequential-launch historical branch accounting',
        'head': CURRENT, 'donor_head': DONOR,
        'excluded_reproducible_directories': sorted(excluded_dirs),
        'files': members,
    })
    with zipfile.ZipFile(ROOT / ARCHIVE, 'w', zipfile.ZIP_DEFLATED, compresslevel=6) as output:
        for entry in members:
            output.write(ROOT / entry['path'], entry['path'])
        output.write(ROOT / MANIFEST, MANIFEST)
    with zipfile.ZipFile(ROOT / ARCHIVE) as sealed:
        assert sealed.testzip() is None
        assert len(sealed.namelist()) == len(members) + 1
        assert len(set(sealed.namelist())) == len(sealed.namelist())
        assert set(sealed.namelist()) == {entry['path'] for entry in members} | {MANIFEST}
        for entry in members:
            data = sealed.read(entry['path'])
            assert len(data) == entry['bytes']
            assert digest(data) == entry['sha256']
        assert sealed.read(MANIFEST) == (ROOT / MANIFEST).read_bytes()
    archive_data = (ROOT / ARCHIVE).read_bytes()
    receipt = {
        'archive_file': ARCHIVE, 'archive_sha256': digest(archive_data),
        'archive_bytes': len(archive_data), 'manifest_file': MANIFEST,
        'manifest_sha256': digest((ROOT / MANIFEST).read_bytes()),
        'payload_file_count': len(members), 'zip_member_count': len(members) + 1,
        'archive_crc_verified': True, 'all_manifest_members_verified': True,
        'classification': 'SUPERSEDED', 'head': CURRENT, 'head_tree': TREE,
        'donor_head': DONOR, 'missing_compatible_contribution_found': False,
    }
    write_json(RECEIPT, receipt)
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
