"""Resolve the reviewer-owned temp parent omission; rerun only setup-error cases."""

import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

sys.path.insert(0, str(Path(__file__).resolve().parent))
from run_review_checks import OUT, PARENT, WORK, run


(OUT / 'tmp').mkdir(exist_ok=True)
initial = json.loads((OUT / 'validation.json').read_text())
initial_cases = list(ET.parse(OUT / 'current-maintained.xml').getroot().iter('testcase'))
selectors = [case.get('classname').replace('.', '/') + '.py::' + case.get('name')
             for case in initial_cases if case.find('error') is not None]
assert len(selectors) == 16 and len(set(selectors)) == 16
red = run('author-regressions-before-fix-resumed', PARENT, [
    'tests/test_intel_transport.py::test_cache_body_stale_stat_does_not_bypass_resource_read_limit',
    'tests/test_intel_transport.py::test_cache_url_index_uses_explicit_read_cap',
])
green = run('current-setup-errors-resumed', WORK, selectors)
rerun_cases = list(ET.parse(OUT / 'current-setup-errors-resumed.xml').getroot().iter('testcase'))
initial_passes = {(case.get('classname'), case.get('name')) for case in initial_cases
                  if case.find('error') is None and case.find('failure') is None and case.find('skipped') is None}
rerun_passes = {(case.get('classname'), case.get('name')) for case in rerun_cases
                if case.find('error') is None and case.find('failure') is None and case.find('skipped') is None}
all_selected = {(case.get('classname'), case.get('name')) for case in initial_cases}
receipt = {
    'cause': 'Reviewer omitted parent OUT/tmp; pytest tmp_path fixtures failed at setup before their test bodies.',
    'correction': 'Created only the reviewer-owned temp parent; no product or test source changed.',
    'initial': {'passed': 142, 'setup_errors': 16},
    'retained_initial_receipt': 'validation.json',
    'red': red, 'green': green,
    'passed_unchanged_original_cases': len(initial_passes), 'passed_rerun_cases': len(rerun_passes),
    'distinct_selected_cases': len(all_selected),
    'all_selected_have_passing_outcome': initial_passes | rerun_passes == all_selected,
    'successful_subsets_disjoint': not (initial_passes & rerun_passes),
    'one_clean_158_case_invocation_claimed': False,
    'worktree_clean_after': subprocess.check_output(['git', '-C', str(WORK), 'status', '--porcelain=v1']) == b'',
    'source_or_tests_modified': False,
}
(OUT / 'validation-resumed.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: receipt[k] for k in ['passed_unchanged_original_cases', 'passed_rerun_cases',
                                        'distinct_selected_cases', 'all_selected_have_passing_outcome',
                                        'successful_subsets_disjoint', 'worktree_clean_after']}), flush=True)
