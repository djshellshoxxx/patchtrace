# PR353 independent bounded source review

**No blocking source finding identified in the reviewed bounded scope.** The exact-head source repairs the two reproduced cache read-limit gaps, preserves the surrounding behavior, and passes the focused maintained cases and lint checks described below. This is not merge approval or hosted/full qualification. The author's explicit **NOT VERIFIED** hold remains unchanged.

## Identity, ownership and separate main observation

| Item | Exact value |
| --- | --- |
| PR | `353` |
| Branch | `codex/patchtrace-csaf-cache-read-limits-20261121-assistant` |
| Reviewed head | `d0a4bdf439775999340ea760d96a087e032ee6dd` |
| Complete reviewed tree | `9ccd50655b7456d1f09618e63775c5f68d649d1f` |
| Original base / exact merge base | `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4` |
| Unique history | Six linear commits; five complete net and historical changed paths |
| Isolated checkout | `/workspace/scratch/837fe19aae3a/review-pr353-csaf-cache-read-limits-837fe`, detached and clean |

Fresh PR reads before review and on resumption confirm the assigned head and retain the author's statement that the authoring environment ran no tests or Ruff. The reviewer has not edited that body, its hold, the branch, source, ledger or active integration worktrees.

During the review, root separately merged PR351 to main `3a16290c0fcc4e0c21712fe10474a3ff33fad336`. Its local Git object independently verifies tree `6001ef506c38930fd590bd827f428b997c3b2797`, ordered parents `[9023761a, d6679abc]` and both publication markers. Its merge base with the reviewed PR353 head remains `9023761a`. That main promotion is separate context and does not qualify PR353 or alter the tested source. See `new-main-separate-context.json`.

## Complete unique commit accounting

| Commit | Changed path and purpose |
| --- | --- |
| `d3628353658ac8b31f9c50b2df7dd6a1df409431` | CSAF specification: define read-level limits before implementation. |
| `07488438cd899460f47a148eb340e5533c7a3912` | Transport tests: add the stale-stat oversized-body and bounded-index-stream regressions before changing runtime code. |
| `2fba26edec79a010ca2d3ca89fc8ac274ad16691` | Transport: bound binary reads and reject excessive returned bytes before decoding/hash admission. |
| `6585f7431dbb7814ad4a1f3454f6a2b86eb34a95` | Transport comment: state the intentionally unchanged direct no-limit API behavior. |
| `4c2a741ecac7f10d58a5b46a11cc64db79f065d0` | QA append: describe the change and authoring-session qualification limits. |
| `d0a4bdf439775999340ea760d96a087e032ee6dd` | Task append: record implemented scope and outstanding qualification/merge gates. |

Raw commit objects, their verified object IDs and all six full patches are retained. The Git bundle retains the exact six-commit history and verifies successfully with prerequisite base `9023761a`; it does not duplicate the entire repository history.

## Entire changed-path review

| Path | Finding |
| --- | --- |
| `src/patchtrace/intelligence/csaf/transport.py` | Only `OfflineCache._map` and `OfflineCache.get` bodies differ in the runtime AST. The index read requests `MAX_MAP_BYTES + 1` binary bytes and rejects over-cap data before UTF-8 decoding/JSON parsing. A body with a supplied limit requests `limit + 1` and raises `PT-INTEL-LIMIT` before hashing/returning excess bytes. The existing early stat refusal remains. |
| `tests/test_intel_transport.py` | Adds exactly two tests. Every pre-existing function/class AST is unchanged. The test-before-fix commit contains the exact final test bytes and the original runtime bytes, making the retained red replay meaningful. |
| `docs/specs/csaf-cve-interpretation-engine.md` | The normative transport/cache section explicitly makes stat an early check and defines bounded reads plus post-read checks. Existing cache format, strict writes, SHA-256 checks and offline behavior remain required. Its existing REGISTRY path/alias is preserved; no new spec allocation is needed. |
| `docs/qa.md` | An exact-prefix-preserving append records the author's unverified checkpoint. It does not overwrite prior evidence or claim tests that the author did not run. |
| `tasks/todo.md` | An exact-prefix-preserving append retains full/hosted/lint/review and guarded-merge requirements. This review does not check those boxes. |

The two changed method bodies preserve unreadable-index handling, strict `PT-INTEL-CONFIG` refusal, legacy-index fallback, shard precedence, hash mismatch rejection and I/O miss behavior. `_map` still feeds the unchanged strict `put` path, so an over-cap result is refused before cache replacement. The direct `OfflineCache.get(..., limit=None)` API deliberately retains an unbounded read; normal resource-kind transport calls still supply their existing limits. There is no dependency, workflow, network-path, persistence-schema or module-layout delta.

## Source-bound validation and preserved failures

The existing frozen Pages environment was reused without installation or editable rebinding. Each test process ran with `-I -B`, explicitly selected the source root before imports, asserted the exact transport module path, and logged its digest plus unchanged editable metadata. The pre-fix source snapshot contains 674 Git-blob-verified files and is preserved as an original source ZIP.

The first invocation exposed a **reviewer setup error**: the parent of the dedicated pytest temporary directory did not exist. Both pre-fix cases errored at setup; the maintained selection recorded 142 passes and 16 setup errors. Those outputs and receipts are retained unchanged. After creating only that scratch parent directory, the reviewer reran the two pre-fix cases and only the 16 affected current-source cases. Product and test source remained unchanged.

| Check | Actual outcome |
| --- | --- |
| Exact original two regressions on test-before-fix commit `07488438` | **2 intended failures**, no errors: the oversized matching-hash body is admitted, and the index requests an unbounded read. |
| Initial maintained selection at `d0a4bdf` | **142 passed / 16 setup errors** from the missing reviewer-owned temp parent. |
| Same 16 setup-error cases after scratch correction | **16 passed**, including both new regressions. |
| Distinct selected case identities with passing outcomes | **158**: transport 25, offline cache 11, discovery 12, registry 110. The two successful subsets are disjoint. |
| Whole `src`, `tests`, `tools` Ruff | Passed. |
| Existing environment `pip check` | Passed. |
| Source status after checks | Clean at exact `d0a4bdf`. |

No single clean 158-case invocation is claimed. Initial setup errors are not product failures; the later two red failures are the actual regression demonstration. These are focused Python fake/local fixtures, not hosted, full-suite, native or packaged compatibility evidence. No live CSAF request, native engine or analyzed target was executed.

## Disposition and remaining qualification

The complete six-commit/five-path source scope is reviewed with no blocking finding. The smallest compatible change is the one already present; no replacement implementation or additional source edit is recommended by this review.

Required exact-head hosted Linux/Windows QA, applicable Qt/native/package gates and final merge conditions are not established by these local fixtures. Any later combined source must be qualified on its actual identity. The author's hold, guarded merge requirements and both `[no release]` / `[no deploy]` requirements remain in force. Root owns any eventual integration, author coordination and remote action.

Key receipts: `source-history.json`, `semantic-preservation.json`, `validation.json`, `validation-resumed.json`, `bundle-receipt.json` and the per-run stdout/stderr/JUnit files. The portable manifest excludes the reproducible private Git object cache, unpacked parent-source copy and temporary fixture data; it includes the verified source ZIP, exact history bundle, source snapshots and all failures/results.
