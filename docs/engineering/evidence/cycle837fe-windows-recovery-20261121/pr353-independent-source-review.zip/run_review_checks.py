"""Execute only inspected local fixtures/lint with exact source bindings."""

import json
import os
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
WORK = ROOT / 'review-pr353-csaf-cache-read-limits-837fe'
PYTHON = ROOT / 'pages-config-hold-venv/bin/python'
WRAPPER = OUT / 'run_bound_pytest.py'
PARENT = OUT / 'parent-source'


def run(label, source, args):
    output_xml = OUT / f'{label}.xml'
    command = [str(PYTHON), '-I', '-B', str(WRAPPER), str(source), '-q',
               '--noconftest', '--disable-plugin-autoload', '--import-mode=importlib',
               '-p', 'no:cacheprovider', '--rootdir', str(source),
               '--basetemp', str(OUT / 'tmp' / label), f'--junitxml={output_xml}', *args]
    start = time.monotonic()
    result = subprocess.run(command, cwd=source, capture_output=True, text=True,
                            env={**os.environ, 'PYTHONDONTWRITEBYTECODE': '1', 'QT_QPA_PLATFORM': 'offscreen'},
                            timeout=120)
    (OUT / f'{label}.stdout.txt').write_text(result.stdout)
    (OUT / f'{label}.stderr.txt').write_text(result.stderr)
    cases = list(ET.parse(output_xml).getroot().iter('testcase'))
    failed = [c.get('name') for c in cases if c.find('failure') is not None]
    errors = [c.get('name') for c in cases if c.find('error') is not None]
    skipped = [c.get('name') for c in cases if c.find('skipped') is not None]
    receipt = {'label': label, 'command': command, 'cwd': str(source),
               'exit_code': result.returncode, 'seconds': time.monotonic() - start,
               'cases': len(cases), 'passed': len(cases) - len(failed) - len(errors) - len(skipped),
               'failed': failed, 'errors': errors, 'skipped': skipped,
               'scope': 'Inspected synthetic/fake transport, local cache and registry fixtures; no native or live request.'}
    (OUT / f'{label}-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt), flush=True)
    return receipt


def main():
    red = run('author-regressions-before-fix', PARENT, [
        'tests/test_intel_transport.py::test_cache_body_stale_stat_does_not_bypass_resource_read_limit',
        'tests/test_intel_transport.py::test_cache_url_index_uses_explicit_read_cap',
    ])
    maintained = run('current-maintained', WORK, [
        'tests/test_intel_transport.py', 'tests/test_intel_offline_cache.py',
        'tests/test_intel_discovery.py', 'tests/test_spec_registry.py',
    ])
    tooling = []
    for label, command in [('whole-ruff', [str(PYTHON), '-I', '-B', '-m', 'ruff', 'check', '--no-cache', 'src', 'tests', 'tools']),
                           ('pip-check', [str(PYTHON), '-I', '-B', '-m', 'pip', 'check'])]:
        start = time.monotonic()
        result = subprocess.run(command, cwd=WORK, capture_output=True, text=True, timeout=60)
        (OUT / f'{label}.stdout.txt').write_text(result.stdout)
        (OUT / f'{label}.stderr.txt').write_text(result.stderr)
        item = {'label': label, 'command': command, 'cwd': str(WORK), 'exit_code': result.returncode,
                'seconds': time.monotonic() - start}
        tooling.append(item)
    clean = subprocess.check_output(['git', '-C', str(WORK), 'status', '--porcelain=v1']) == b''
    receipt = {'red': red, 'maintained': maintained, 'tooling': tooling, 'worktree_clean_after': clean,
               'counts_overlap': True, 'full_suite_run': False, 'dependencies_installed': False,
               'author_unverified_hold_preserved': True, 'hosted_qualification_claim': False}
    (OUT / 'validation.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'tooling': tooling, 'worktree_clean_after': clean}), flush=True)


if __name__ == '__main__':
    main()
