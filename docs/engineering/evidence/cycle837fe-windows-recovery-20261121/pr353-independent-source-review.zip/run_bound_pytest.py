"""Run inspected fixture tests against an explicitly asserted immutable source."""

import hashlib
import importlib.metadata
import json
from pathlib import Path
import sys


source = Path(sys.argv[1]).resolve()
sys.path[:0] = [str(source / 'src'), str(source)]
from patchtrace.intelligence.csaf import transport

actual = Path(transport.__file__).resolve()
expected = source / 'src/patchtrace/intelligence/csaf/transport.py'
assert actual == expected, (actual, expected)
print(json.dumps({
    'source_root': str(source),
    'transport_file': str(actual),
    'transport_sha256': hashlib.sha256(actual.read_bytes()).hexdigest(),
    'python': sys.executable,
    'unchanged_environment_editable_metadata': importlib.metadata.distribution('patchtrace').read_text('direct_url.json'),
}), flush=True)

import pytest

raise SystemExit(pytest.main(sys.argv[2:]))
