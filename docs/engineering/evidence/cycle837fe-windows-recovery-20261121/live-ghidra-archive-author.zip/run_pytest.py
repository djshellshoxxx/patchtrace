from pathlib import Path
import importlib.metadata
import json
import runpy
import sys

root=Path(sys.argv[1]).resolve()
args=sys.argv[2:]
sys.path[:0]=[str(root),str(root / "src"),str(root / "tests"),str(root / "tools")]
import patchtrace
import patchtrace.backend
for module in (patchtrace, patchtrace.backend):
    resolved=Path(module.__file__).resolve()
    assert resolved.is_relative_to(root / "src"), (module.__name__, resolved, root)
print(json.dumps({"source_root":str(root),"python":sys.executable,"patchtrace":patchtrace.__file__,"backend":patchtrace.backend.__file__,"editable_metadata":importlib.metadata.distribution("patchtrace").read_text("direct_url.json"),"note":"Frozen shared environment is not rebound; explicit current source paths are verified before pytest."}),flush=True)
sys.argv=["pytest",*args]
runpy.run_module("pytest",run_name="__main__")
