# Native Ghidra original-archive candidate

## Frozen source

- Commit: `88df8cfbe51f91a6bc08c6863cd5d63f86500ca0`.
- Tree: `f22f034f92c0c82c59c86665e8b70acb87974448`.
- Exact parent: `1c70cd5f8053f75c269da673a24a82f221180650`.
- Branch: `codex/patchtrace-live-ghidra-archive-20261121-837fe`.
- Clean worktree: `/workspace/scratch/837fe19aae3a/repair-live-ghidra-archive`.
- Both `[no release]` and `[no deploy]` commit markers are present.

Source is frozen for independent review. Root owns integration/publication and
every remote action. Exactly four owned paths changed:

1. `.github/workflows/live-backend.yml`
2. `docs/specs/windows-acceptance-and-milestone-builds.md`
3. That spec's existing row in `docs/specs/REGISTRY.md`
4. `tests/test_live_ghidra_archive.py`

No ledger, QA, handoff, runtime, dependency, other workflow or module-index change.
`candidate-complete.patch`, `candidate-commit.txt`, `candidate-source/` and
`frozen-candidate.json` retain the complete candidate. The earlier `candidate.diff`
is the unstaged tracked-only diff; it excludes the then-untracked test. Use the
complete patch for recovery.

## Behavior and preservation

Reuse the existing Tier R pinned cache Action, `ghidra-archive` path and
`ghidra-archive-v1-${{ env.GHIDRA_SHA256 }}` exact key. Retain the original
`ghidra-archive/ghidra.zip`, without an extracted tree or fallback restore key.
The existing Ghidra URL/digest move unchanged to workflow environment values.
Python, Java and Ghidriff identities remain unchanged.

On every variant, the PowerShell provisioning step refuses malformed pins,
downloads only an absent ZIP, verifies the original bytes, removes prior
extraction only after a matching digest, extracts that ZIP afresh and exports
the existing runtime path. Errors terminate. A corrupt restored ZIP fails and
is not redownloaded to conceal the mismatch. A successful job's cache hook can
retain the verified original ZIP.

The preservation receipt compares the entire parsed workflow after removing
the two new environment values/cache step and restoring only the parent's
archive step. All twelve other steps are identical: authored fixture compilation,
symbol setup, strict expected-failure reproduction, native backend checks, raw
analysis cache check and diagnostic upload. All five variants, triggers,
permissions, concurrency, runner, fail-fast setting and 25-minute limit match.
Thirteen protected paths include native helpers, authored C sources, corpus
workflow, both CODEX-5 tests, ledger, QA/todo and existing handoff.

The spec preceded implementation; `contract-before-implementation.json` and
`red-source/` preserve that boundary. Validation ran on explicitly recorded
uncommitted candidate bytes at parent HEAD. It is not represented as a clean
parent test run. All four tested source files were subsequently verified equal
to the final commit, without changing code after validation.

## Validation and retained failures

| Receipt | Outcome | Scope |
|---|---|---|
| `red-parent-receipt.json` | 2 failed, 1 passed, 9 skipped | Initial contract against unchanged parent; preserved |
| `red-parent-final-receipt.json` | 3 failed, 1 passed, 9 skipped | Final parent regressions: missing retention, fresh extraction and conditional download |
| `green-focused-receipt.json` | 260 passed, 9 skipped, 2 strict xfails | 271 distinct cases, 7 modules, 1.84 seconds pytest time |
| `ruff-receipt.json` | exit 2 | Invalid `RUFF_NO_CACHE=1` harness option; preserved |
| `ruff-corrected-receipt.json` | exit 0 | Whole `src tests tools`; explicit `--no-cache`; no source edit |
| `pip-check-receipt.json` | exit 0 | Existing environment dependencies consistent; no install |

Counts overlap; do not add the red, green or later peer runs. Both original
strict CODEX-5 expected failures remain. The nine skips are the new exact
PowerShell fixtures because this Linux host has no `pwsh`. They cover valid and
corrupt downloaded/restored authored ZIPs, malformed/missing pins, and extraction
failure after a matching digest. Windows QA explicitly fails if PowerShell is
missing. These fixtures contain no executable archive payload; only downloading
is doubled, while hashing/removal/extraction/export use the actual YAML scalar.
No skipped fixture is claimed passed.

The existing Tier R shell tests ran only tiny authored archives with a
network-refusing curl double. Diagnostic tests used controlled processes and
projects. None is native, hosted-cache, air-gap or comparative-accuracy evidence.

### Exact focused invocation

```sh
/workspace/scratch/837fe19aae3a/pages-config-hold-venv/bin/python -I -B \
  /workspace/scratch/837fe19aae3a/evidence/live-ghidra-archive-recovery/run_pytest.py \
  /workspace/scratch/837fe19aae3a/repair-live-ghidra-archive \
  -q --disable-plugin-autoload --import-mode=importlib -p no:cacheprovider \
  --basetemp /workspace/scratch/837fe19aae3a/evidence/live-ghidra-archive-recovery/tmp/green \
  --junitxml=/workspace/scratch/837fe19aae3a/evidence/live-ghidra-archive-recovery/green-focused.xml \
  tests/test_live_ghidra_archive.py \
  tests/test_corpus_cache_archive_integrity_20261121.py \
  tests/test_corpus_archive_cache_hit_shell_20261121.py \
  tests/test_live_cache_diagnostics.py \
  tests/test_codex_pkg_workflows.py \
  tests/test_codex5_command_audit_20261121.py \
  tests/test_spec_registry.py
```

CWD is the isolated worktree; environment sets `QT_QPA_PLATFORM=offscreen` and
`PYTHONDONTWRITEBYTECODE=1`. The bootstrap explicitly selects this worktree's
root/src/tests/tools and asserts that `patchtrace` and `patchtrace.backend`
resolve to this source before pytest. The reused environment's editable metadata
still names the frozen Pages checkout and is reported truthfully; it was not
rebound. Source selection is the explicit checked bootstrap. The unchanged
`pyproject.toml` is covered by the source proof. No environment was installed or
altered.

Ruff: same Python, `-I -B -m ruff check --no-cache src tests tools`.
Pip: same Python, `-I -B -m pip check`. Both use this worktree CWD.
`git diff --check` and the staged equivalent passed.

## Pending qualification and archive

Independent review is pending at freeze. Root must obtain fresh exact-source
automatic hosted evidence of a cold archive miss, pinned download/checksum/fresh
extraction and successful save, followed by an observed exact-key restore with
repeated verification/fresh extraction. Retain all five native outcomes and
actual source/checkout identities. Complete the first run/save hook before the
next: existing same-event/ref concurrency can cancel earlier runs. Cache ref
scope, internal version and concurrent matrix writers mean a key alone proves
neither a hit nor a new save.

No dispatch, rerun, native/target execution, Ghidra/dependency download, install,
CI/ref/PR/site mutation occurred. No cold/warm/native gate is claimed closed.
The import-only Tier R evaluator and raw-analysis cache remain separate. Broad
CODEX-5, Java/Ghidriff dependency closure, manual/accessibility/trust/air-gap and
accuracy gates retain their existing limits.

The portable archive retains source, outputs, JUnit, receipts, proof and the
prior plan/action-source evidence. Reproducible temporary fixtures under `tmp/`
stay outside the ZIP; all failure stdout and receipts are included. Its external
receipt supplies archive/manifest SHA-256, member count and CRC/hash verification
without a circular hash.
