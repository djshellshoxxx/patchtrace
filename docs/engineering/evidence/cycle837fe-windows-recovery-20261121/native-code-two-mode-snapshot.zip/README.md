# Native 4202 cold/warm original-archive checkpoint

Immutable observation cut: **2026-11-21 13:05:43 UTC**. This checkpoint covers two completed native cases only.

Source 4202e5e79e2aea6366c75261d74544ea48368ca5, complete tree dffeed541749850ef54a130cec0fa56c0fd2f01c; automatic push run 44901791862, attempt 1. Both actual checkout logs name 4202. The retained decoded workflow bytes match Git blob 88cf7d8da5a5ba95084e913f862d0728b020c622 in the complete source tree.

## Actual two-mode evidence

| Mode | Job | Actual result |
| --- | --- | --- |
| Cold miss | 136839042813, no adjacent PDB | Cache miss; original ZIP hash verified; fresh extraction step success; one known-patch change accepted; cache successfully saved. |
| Warm hit | 136839043092, clean | Exact primary-key restore; original ZIP hash verified; fresh extraction step success; one known-patch change accepted; post step truthfully skipped saving because the primary key hit. |

Both runner-side original ZIP checks verify c3b458661d69e26e203d739c0c82d143cc8a4a29d9e571f099c2cf4bda62a120. The cache retains the original archive, while extraction rebuilds the runtime directory. The two downloaded analysis-artifact ZIPs are different evidence objects: 14707871761 (9267d7fa4263bbdaff4d26f9478bfd3ea175e4301bf141bdbf8b5685b11ebcb8) and 14708920069 (f81d87a9fd8f52ad0fcfab741a30cf2f76bfa2e9b5481c596d6448f2657460d2). Both original ZIP lengths, API digests, CRCs and every recorded member hash were reverified locally.

## Gates deliberately still open

- The remaining three native cases are outside this checkpoint. At the observation cut, the application raw-cache and expected-negative cases were in progress, and the seeded-store case was queued.
- Application raw-analysis caching is a separate feature and has no accepted result in this checkpoint.
- The final record-bearing source, its fresh five-case native run, actual Windows 27-case PowerShell gate, full Linux/Windows suites, five Qt gates, Windows package/install/uninstall and both Ubuntu frozen CLI jobs remain pending final-source qualification.
- These two positive fixtures each accepted one known change; they do not establish general analysis accuracy or cross-ref/OS cache behavior. Their backend records report successful exit but JVM version unverified.

## Contents

summary.json contains exact source, job, cache, artifact and open-gate details. Raw completed case JSON and logs are retained alongside the exact original small analysis artifact ZIPs. The original Ghidra tool archive and large product binaries are not downloaded or included.

native-4202-cache-mode-snapshot.zip contains the payload and evidence-manifest.json; archive-receipt.json remains external. No workflow dispatch/retry/cancel, source mutation, or local native/target execution occurred. This snapshot remains unchanged when the remaining live run progresses.
