"""Run the bounded maintained selection against explicit immutable-source paths."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/837fe19aae3a')
REPO = ROOT / 'repair-ci-publication-concurrency'
OUT = ROOT / 'evidence/ci-publication-concurrency-independent'
PYTHON = ROOT / 'pages-config-hold-venv/bin/python'
HEAD = 'c4eb63c55a35a1c2a927f4aeb4d42c8b96ff45ff'
MODULES = ['test_release_gate.py', 'test_codex_pkg_packaging.py', 'test_milestone_notes.py',
           'test_windows_installer_manifest.py', 'test_codex_pkg_workflows.py',
           'test_codex5_command_audit_20261121.py', 'test_spec_registry.py', 'test_site_workflow.py']


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True)


before = {'head': git('rev-parse', 'HEAD').strip(), 'tree': git('rev-parse', 'HEAD^{tree}').strip(),
          'status': git('status', '--porcelain=v1')}
assert before['head'] == HEAD and not before['status']
args = ['--noconftest', '--disable-plugin-autoload', '-q', '-ra',
        *['tests/' + m for m in MODULES], '-p', 'no:cacheprovider',
        '--basetemp=' + str(OUT / 'test-temp'), '--junitxml=' + str(OUT / 'maintained.xml')]
code = '''import sys,json
from pathlib import Path
from importlib.metadata import distribution
r=Path(sys.argv[1]);o=Path(sys.argv[2]);sys.path[:0]=[str(r/'src'),str(r),str(r/'tests')]
import patchtrace
from tools import ci_pip_install_audit
assert Path(patchtrace.__file__).resolve()==r/'src/patchtrace/__init__.py'
assert Path(ci_pip_install_audit.__file__).resolve()==r/'tools/ci_pip_install_audit.py'
binding={'patchtrace':patchtrace.__file__,'audit':ci_pip_install_audit.__file__,'interpreter':sys.executable,'existing_editable_unchanged':json.loads(distribution('patchtrace').read_text('direct_url.json')),'binding_mode':'python -I -B with explicit current src/repo/tests paths; no install or rebind'}
(o/'binding.json').write_text(json.dumps(binding,indent=2)+'\\n')
import pytest
raise SystemExit(pytest.main(sys.argv[3:]))
'''
command = [str(PYTHON), '-I', '-B', '-c', code, str(REPO), str(OUT), *args]
env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', QT_QPA_PLATFORM='offscreen')
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
result = subprocess.run(command, cwd=REPO, env=env, capture_output=True, text=True)
seconds = time.monotonic() - clock
(OUT / 'maintained.stdout.txt').write_text(result.stdout)
(OUT / 'maintained.stderr.txt').write_text(result.stderr)
after = {'head': git('rev-parse', 'HEAD').strip(), 'tree': git('rev-parse', 'HEAD^{tree}').strip(),
         'status': git('status', '--porcelain=v1')}
cases = ET.parse(OUT / 'maintained.xml').findall('.//testcase')
xfails = [{'classname': c.get('classname'), 'name': c.get('name'), 'type': c.find('skipped').get('type'),
           'message': c.find('skipped').get('message')} for c in cases if c.find('skipped') is not None]
failed = sum(c.find('failure') is not None for c in cases)
errors = sum(c.find('error') is not None for c in cases)
receipt = {'source': HEAD, 'before': before, 'after': after, 'command': command, 'cwd': str(REPO),
           'started_at_utc': started, 'seconds': round(seconds, 3), 'exit_code': result.returncode,
           'cases': len(cases), 'passed': len(cases) - len(xfails) - failed - errors,
           'failures': failed, 'errors': errors, 'skipped_or_xfailed': xfails,
           'environment_installed_or_rebound': False, 'full_suite': False, 'native_engine_execution': False,
           'stdout_sha256': hashlib.sha256(result.stdout.encode()).hexdigest()}
(OUT / 'maintained-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
assert result.returncode == 0 and before == after and failed == errors == 0
assert len(cases) == 370 and len(xfails) == 2 and all(c['type'] == 'pytest.xfail' and 'CODEX-5' in c['message'] for c in xfails)
print(json.dumps({k: receipt[k] for k in ['source', 'seconds', 'exit_code', 'cases', 'passed', 'failures', 'errors', 'skipped_or_xfailed']}, indent=2))
