"""Independent source invariants and in-memory maintained-regression controls."""
from pathlib import Path
import ast
import copy
import datetime
import hashlib
import importlib.util
import io
import json
import re
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/837fe19aae3a')
REPO = ROOT / 'repair-ci-publication-concurrency'
OUT = ROOT / 'evidence/ci-publication-concurrency-independent'
AUTHOR = ROOT / 'evidence/ci-publication-concurrency-recovery'
SOURCE = 'c4eb63c55a35a1c2a927f4aeb4d42c8b96ff45ff'
TREE = '561befcde425c5de07e113128dc79c21b7616772'
BASE = '2ae1bbad2ad9cc78c29541872381750e347c670e'
DONOR = '0bf1f8309e8425ba34199657009d3055215336f1'
WIN1 = '7ac57759f3b9b332eaafb48c82f366566892f1b1'
MERGE_BASE = '99f8328ce89d02f200cf9fbc5852d9801761af28'
WORKFLOW = '.github/workflows/qa-windows.yml'
TEST = 'tests/test_release_gate.py'
SPEC = 'docs/specs/windows-acceptance-and-milestone-builds.md'
REGISTRY = 'docs/specs/REGISTRY.md'
sys.path[:0] = [str(REPO / 'src'), str(REPO), str(REPO / 'tests')]
import yaml

checks = []


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def blob(ref, path):
    return git('show', ref + ':' + path)


def check(name, ok, **details):
    checks.append({'check': name, 'passed': bool(ok), **details})
    assert ok, name


def functions(raw):
    return {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(raw).body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}


check('Exact frozen commit/tree/parent and clean worktree', git('rev-parse', 'HEAD').decode().strip() == SOURCE and git('rev-parse', SOURCE + '^{tree}').decode().strip() == TREE and git('show', '-s', '--format=%P', SOURCE).decode().strip() == BASE and git('status', '--porcelain=v1') == b'')
check('Both commit hold markers retained', all(t in git('show', '-s', '--format=%B', SOURCE) for t in [b'[no release]', b'[no deploy]']))
paths = git('diff', '--name-only', BASE, SOURCE).decode().splitlines()
check('Exactly four authorized paths', set(paths) == {WORKFLOW, TEST, SPEC, REGISTRY}, paths=paths)
before = blob(BASE, WORKFLOW).decode()
after = blob(SOURCE, WORKFLOW).decode()
old_group = '  group: ${{ github.workflow }}-${{ github.event_name }}-${{ github.ref }}'
new_group = "  group: ${{ github.workflow }}-${{ github.event_name == 'pull_request' && github.ref || github.run_id }}"
old_cancel = '  cancel-in-progress: true'
new_cancel = "  cancel-in-progress: ${{ github.event_name == 'pull_request' }}"
error_line = '          if-no-files-found: error\n'
neutral = after.replace(new_group, old_group, 1).replace(new_cancel, old_cancel, 1).replace(error_line, '', 1)
check('Exact byte delta is two concurrency fields plus one upload input', after.count(new_group) == after.count(new_cancel) == after.count(error_line) == 1 and neutral == before)
old_y = yaml.load(before, Loader=yaml.BaseLoader)
new_y = yaml.load(after, Loader=yaml.BaseLoader)
expected = copy.deepcopy(old_y)
expected['concurrency'] = new_y['concurrency']
uploads = [s for s in expected['jobs']['qa']['steps'] if s.get('with', {}).get('name') == 'PatchTrace-windows-x64']
check('Exactly one actual required upload step', len(uploads) == 1)
uploads[0]['with']['if-no-files-found'] = 'error'
check('Parsed workflow exact except authorized concurrency/upload fields', expected == new_y)
check('Concurrency expressions identical to original donor', new_y['concurrency'] == yaml.load(blob(DONOR, WORKFLOW), Loader=yaml.BaseLoader)['concurrency'])
base_f, final_f, donor_f = (functions(blob(ref, TEST)) for ref in [BASE, SOURCE, DONOR])
check('Every pre-existing test/helper function AST unchanged', all(final_f.get(n) == v for n, v in base_f.items()), preserved_function_count=len(base_f))
check('Original donor concurrency regression AST identical', final_f['test_runs_that_can_publish_are_never_cancelled_by_a_newer_run'] == donor_f['test_runs_that_can_publish_are_never_cancelled_by_a_newer_run'])
check('Only expected three tests and one bounded helper added', set(final_f) - set(base_f) == {'test_runs_that_can_publish_are_never_cancelled_by_a_newer_run', '_concurrency_for_event_fixture', 'test_concurrency_groups_only_newer_runs_of_the_same_pull_request', 'test_required_windows_artifact_upload_refuses_an_empty_result'})
check('All original test module AST nodes retained, additions only', all(ast.dump(n, include_attributes=False) in [ast.dump(v, include_attributes=False) for v in ast.parse(blob(SOURCE, TEST)).body] for n in ast.parse(blob(BASE, TEST)).body))
check('Original spec retained with one bounded section insertion', blob(SOURCE, SPEC).decode().replace(blob(SOURCE, SPEC).decode().split('### 1.1.1 Run concurrency')[1].split('### 1.2 Which commits')[0].join(['### 1.1.1 Run concurrency', '']), '', 1) == blob(BASE, SPEC).decode())
for path in paths:
    data = blob(SOURCE, path)
    snap = OUT / 'source' / path
    snap.parent.mkdir(parents=True, exist_ok=True)
    snap.write_bytes(data)
    check('Author frozen snapshot matches actual Git blob: ' + path, data == (AUTHOR / 'final-source' / path).read_bytes())

author_zip = AUTHOR / 'ci-publication-concurrency-recovery-c4eb63c5.zip'
check('Author archive exact expected identity/size', hashlib.sha256(author_zip.read_bytes()).hexdigest() == '2cfe01d16d4f3f0d443208bfaffc8c45594c959f63d3991b749ac273b2ffdd58' and author_zip.stat().st_size == 2118583)
with zipfile.ZipFile(author_zip) as z:
    check('Author archive CRC and unique member inventory', z.testzip() is None and len(z.namelist()) == len(set(z.namelist())) == 46)
    manifest = json.loads(z.read('evidence-manifest.json'))
    check('Author manifest exact 45 payload inventory', set(z.namelist()) == {r['path'] for r in manifest['files']} | {'evidence-manifest.json'} and len(manifest['files']) == 45)
    for row in manifest['files']:
        raw = z.read(row['path'])
        check('Author payload digest: ' + row['path'], len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'] and raw == (AUTHOR / row['path']).read_bytes())
    historical_zip = z.read('historical/historical-packaging-next-review.zip')
    check('Complete historical archive unchanged', hashlib.sha256(historical_zip).hexdigest() == 'b8bd30fc05950a052f46e867866aab8b16e9970af1942384a90e37c98677e2f8')
    with zipfile.ZipFile(io.BytesIO(historical_zip)) as h:
        check('Nested historical archive CRC', h.testzip() is None)
for filename, expected_count, expected_fail, expected_xfail in [('red.xml', 8, 8, 0), ('focused-initial-path-boundary.xml', 370, 1, 2), ('focused.xml', 370, 0, 2)]:
    cs = ET.parse(AUTHOR / filename).findall('.//testcase')
    check('Retained actual JUnit outcomes: ' + filename, len(cs) == expected_count and sum(c.find('failure') is not None for c in cs) == expected_fail and sum(c.find('error') is not None for c in cs) == 0 and sum(c.find('skipped') is not None for c in cs) == expected_xfail)
check('Validated precommit diff equals frozen source diff', (AUTHOR / 'validated-candidate.diff').read_bytes() == git('diff', BASE, SOURCE))
red = json.loads((AUTHOR / 'red-receipt.json').read_text())
check('Preserved red-stage receipt records contract/tests first on baseline workflow', red['base'] == BASE and red['workflow_byte_identical_to_base'] and 'Updated contract/registry' in red['source_state'])
check('Pinned action input defaults warn and accepts error', "if-no-files-found:" in (OUT / 'upstream/upload-action.yml').read_text() and "default: 'warn'" in (OUT / 'upstream/upload-action.yml').read_text())
runtime = (OUT / 'upstream/upload-artifact.ts').read_text()
check('Pinned action code explicitly fails only zero resolved files for error', 'if (searchResult.filesToUpload.length === 0)' in runtime and re.search(r'case NoFileOptions\.error: \{\s+core\.setFailed\(', runtime) is not None)

history = json.loads((AUTHOR / 'historical/classification.json').read_text())
check('Historical census is unchanged 181/16', history['original_census'] == {'unmatched_heads': 181, 'patch_equivalent_heads': 16} and history['original_census_rewritten'] is False)
for record in history['records']:
    head = record['head']
    actual_paths = git('diff', '--name-only', MERGE_BASE, head).decode().splitlines()
    check('Whole historical changed-path accounting: ' + record['branch'], set(actual_paths) == {p['path'] for p in record['paths']} and len(actual_paths) == record['path_count'] and git('rev-list', BASE + '..' + head).decode().splitlines() == [head])
check('CI remains partial and WIN1 superseded, no wholesale closure', [(r['head'], r['classification']) for r in history['records']] == [(DONOR, 'PARTIALLY_INTEGRATED_WITH_RECOVERY_CANDIDATES'), (WIN1, 'SUPERSEDED')])
spec = blob(SOURCE, SPEC).decode()
check('Spec preserves downloaded-artifact/member completeness/pin gaps', 'does not prove that every required member exists' in spec and 'downloaded\nartifacts pass the Windows smoke tests' in spec and 'CODEX-5 closure' in spec)

module_spec = importlib.util.spec_from_file_location('independent_ci_release_gate', REPO / TEST)
module = importlib.util.module_from_spec(module_spec)
sys.modules[module_spec.name] = module
module_spec.loader.exec_module(module)
events = [
    ('pull_request', 'refs/pull/7/merge', 'refs/pull/7/merge', True, True),
    ('pull_request', 'refs/pull/7/merge', 'refs/pull/8/merge', False, True),
    ('push', 'refs/heads/main', 'refs/heads/main', False, False),
    ('push', 'refs/tags/v0.1.0-alpha.1', 'refs/tags/v0.1.0-alpha.1', False, False),
    ('workflow_dispatch', 'refs/heads/main', 'refs/heads/main', False, False),
    ('workflow_dispatch', 'refs/tags/v0.1.0-alpha.1', 'refs/tags/v0.1.0-alpha.1', False, False),
]


class MemoryFile:
    def __init__(self, text):
        self.text = text

    def read_text(self, **_):
        return self.text


def exercise(text):
    module.TEXT = text
    module.BLOCKS = module.job_blocks(text)
    module.WORKFLOW = MemoryFile(text)
    calls = [('original_donor', lambda: module.test_runs_that_can_publish_are_never_cancelled_by_a_newer_run())]
    calls += [('event_' + str(i), lambda args=args: module.test_concurrency_groups_only_newer_runs_of_the_same_pull_request(*args)) for i, args in enumerate(events)]
    calls += [('required_upload', lambda: module.test_required_windows_artifact_upload_refuses_an_empty_result())]
    outcomes = []
    for name, call in calls:
        try:
            call()
            outcomes.append({'case': name, 'outcome': 'passed'})
        except AssertionError:
            outcomes.append({'case': name, 'outcome': 'rejected'})
    return outcomes


controls = []


def control(name, text, accept):
    outcomes = exercise(text)
    observed = all(r['outcome'] == 'passed' for r in outcomes)
    controls.append({'name': name, 'expected_accept': accept, 'observed_accept': observed, 'outcomes': outcomes})
    check('In-memory maintained control: ' + name, observed == accept)


control('exact frozen candidate', after, True)
control('unchanged parent workflow', before, False)
check('Unchanged parent independently reproduces all eight red cases', all(o['outcome'] == 'rejected' for o in controls[-1]['outcomes']))
control('ordinary following job comment remains outside path scalar', after.replace('  # Repeats the GUI test files', '  # Added explanatory comment\n  # Repeats the GUI test files', 1), True)
control('unconditional cancellation', after.replace(new_cancel, old_cancel, 1), False)
control('cancellation disabled for PR too', after.replace(new_cancel, '  cancel-in-progress: false', 1), False)
control('group remains shared by ref for pushes', after.replace(new_group, '  group: ${{ github.workflow }}-${{ github.ref }}', 1), False)
control('PRs use run id and cannot replace earlier PR run', after.replace(new_group, '  group: ${{ github.workflow }}-${{ github.run_id }}', 1), False)
control('event condition incorrectly selects push', after.replace("github.event_name == 'pull_request'", "github.event_name == 'push'"), False)
control('head ref substitutes different declared grouping', after.replace('&& github.ref || github.run_id', '&& github.head_ref || github.run_id'), False)
control('missing empty-upload input', after.replace(error_line, '', 1), False)
control('empty-upload input warns', after.replace(error_line, '          if-no-files-found: warn\n', 1), False)
control('empty-upload input ignores', after.replace(error_line, '          if-no-files-found: ignore\n', 1), False)
control('comment-only empty-upload input', after.replace(error_line, '          # if-no-files-found: error\n', 1), False)
control('Windows successful-only upload condition removed', after.replace("        if: runner.os == 'Windows' && success()", '        if: always()', 1), False)
control('one required checksum path absent', after.replace('            dist/PatchTrace-Windows-x64-Setup.exe.sha256\n', '', 1), False)
control('unexpected fifth artifact path', after.replace('            dist/PatchTrace-Windows-x64-Setup.exe.sha256\n', '            dist/PatchTrace-Windows-x64-Setup.exe.sha256\n            dist/extra.zip\n', 1), False)
control('artifact path broadened to wildcard', after.replace('            dist/PatchTrace-0.1.0-windows-x64.zip\n', '            dist/*.zip\n', 1), False)
control('required artifact renamed', after.replace('          name: PatchTrace-windows-x64\n', '          name: other-windows\n', 1), False)
control('required upload action pin changed', after.replace('actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02', 'actions/upload-artifact@' + '1' * 40), False)
exercise(after)
for event in ['push', 'workflow_dispatch']:
    one = module._concurrency_for_event_fixture(event, 'refs/heads/main', '100')
    two = module._concurrency_for_event_fixture(event, 'refs/heads/main', '100')
    check('Same-run rerun preserves id group but no running cancellation: ' + event, one == two and one == ('100', False))
(OUT / 'controls.json').write_text(json.dumps({'source': SOURCE, 'in_memory_only': True, 'bounded_fixture_not_github_expression_engine': True, 'controls': controls}, indent=2) + '\n')
check('Frozen worktree remains clean and unchanged', git('rev-parse', 'HEAD').decode().strip() == SOURCE and git('status', '--porcelain=v1') == b'')
receipt = {'schema': 'patchtrace/independent-ci-publication-review/1', 'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'source': SOURCE, 'tree': TREE, 'parent': BASE, 'verdict': 'CLEAR: no blocker in the bounded concurrency and empty-upload source change',
           'blockers': [], 'checks_passed': len(checks), 'checks': checks, 'in_memory_controls': len(controls),
           'baseline_red_cases': 8, 'maintained_receipt': 'maintained-receipt.json',
           'original_functions_preserved': len(base_f), 'author_archive_sha256': hashlib.sha256(author_zip.read_bytes()).hexdigest(),
           'historical_scope': 'CI PORT(partial) for two selected controls; uploaded-artifact validation and dependency-pin closure remain open. WIN1 stays SUPERSEDED. Original181/16 snapshot unchanged.',
           'hosted_scheduling_upload_acceptance': 'Pending; no GitHub expression-engine or live scheduler/upload execution performed.',
           'source_or_refs_modified': False, 'full_suite_or_native_execution': False}
(OUT / 'review.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: receipt[k] for k in ['verdict', 'source', 'tree', 'parent', 'checks_passed', 'in_memory_controls', 'baseline_red_cases', 'original_functions_preserved']}, indent=2))
