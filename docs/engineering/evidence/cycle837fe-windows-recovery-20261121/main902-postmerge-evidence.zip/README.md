# Actual main902 post-merge evidence

This record is separate from the sealed successful PR349 premerge qualification. It records the actual merge and subsequent hosted execution, including the newly observed Pages configuration failure. It does not claim every post-main workflow succeeded.

## Source and result

- PR349 merged at **2026-11-21T09:25:16Z** as `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4`.
- Complete tree: `c3f09435deb99ca0ddb3406e27ab315dba7740cf`.
- Parents: `fdc2696c23bdbfe7668348f25e3b336ce33039f7` and `ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e`.
- Both `[no release]` and `[no deploy]` appear in the actual merge title and body.
- All **26 captured executed-job checkout logs** verify the actual main merge.
- Final main observation: **10:36:55 UTC**. Six automatic attempt-1 runs completed: **five success, one Pages failure**. Across 29 jobs: **25 success, one failure, three skips**.

| Workflow | Run | Actual conclusion |
| --- | --- | --- |
| QA and Windows standalone | 44889511435 | success |
| Native Windows Ghidriff | 44889511349 | success |
| Live rizin | 44889511427 | success |
| Corpus Tier R | 44889511400 | success wrapper; coverage warning remains |
| Live unified extraction | 44889511388 | success |
| GitHub Pages | 44889511406 | failure at configuration; deploy skipped |

## QA and platform evidence

All ten required QA jobs succeeded.

| Full suite | Passed | Skipped | Xfailed | Warnings |
| --- | ---: | ---: | ---: | ---: |
| Linux | 24,190 | 53 | 3 | 21 |
| Windows | 24,059 | 185 | 2 | 22 |

Both JUnit reports contain 24,246 cases with zero failures and errors. JUnit skipped totals include xfails: 56 Linux and 187 Windows. Separate boundary controls passed 108/2 skipped on Linux and 107/3 skipped on Windows; those are not added to full-suite totals.

The four Ubuntu Qt shards passed **13,320 / 10,860 / 9,840 / 8,460** tests. Windows Qt passed **10,620**. Warning counts were 40 for Ubuntu shard1 and 10 for Windows; raw logs retain their details.

Windows build, frozen CLI (**64 PASS / 0 FAIL**), portable checksum/extraction/runtime checks, NSIS installer build, actual registration/self-test, and non-destructive uninstall succeeded. Installer build SHA-256: `7c2928fe0635f2ec640fbd7200840a7b04d7d9b3c116077d6b36633182401df2`.

Linux packaging succeeded. Both Ubuntu22.04 and Ubuntu24.04 frozen jobs independently recorded **64 PASS / 0 FAIL**, verified the downloaded product ZIP digest and tar checksum, and passed offscreen/XCB self-tests. Neither emitted an unresolved-library warning.

## Publication holds and actual Pages failure

Release-gate job **136802040681** truthfully returned `publish=true`. Actual release job **136818878992** was **skipped**. The pinned release condition excludes the actual marked merge message.

Pages build job **136802040292** passed 247 site tests with one skip and completed the static site build. It then failed in pinned configure-pages `983d7736d9b0ae728b81ab479565c72886d7745b`: the Pages site lookup returned HTTP404 with enablement=false. Artifact upload was skipped. Deploy job **136802309849** was skipped and its marker predicate is false; the build failure also independently prevents deployment, so that skip alone cannot isolate the marker as its sole cause.

The 404 does not distinguish absent Pages configuration from token visibility/permission limitations. The separate PR351 configure-only repair was not executed in this main902 run. No Pages enablement or dispatch occurred.

A fresh release listing at **10:38:43 UTC** was compared with the retained **08:24:43 UTC premerge baseline**. The newest three release identities, tags, publication times, draft/prerelease flags, and URLs are unchanged. No visible release has a publication time since this merge. The newest remains release **445877110**, `v0.1.0-beta.1035`, published November15. The prior baseline contained three release identities, not prior asset metadata or the complete release count; equality for those absent baseline fields is not claimed.

## Actual native coverage and remaining limits

Ghidriff recorded three positive known-patch variants, one expected cached-PDB negative control, and one raw-cache test. Cache first/second raw SHA-256 was `d79b7dd03b2a425876da27c319c9254f3045485fa0371cd6ac0ff7f0f909f116`, with completed records and one match each. This is within-run reuse, not independent-analysis determinism.

Rizin completed actual unmocked Linux/Windows fixtures with 30/322 matches; those are counts, not accuracy estimates.

Tier R's wrapper succeeded while its actual report remained **warning: 5/11 pairs completed, six failed, zero blocked**. Windows advisory had 11 findings, each exit1, with no substantive native reports; MSVC advisory was skipped. This main run observed one original-rizin-archive cache miss/save and one hit. Both original archive hashes were verified; Ghidra/Java steps were skipped. Primary premerge cache observations remain separate.

Unified extraction passed 45 Windows and 46 Linux checks per authored fixture pair, with zero failures, matching four input hashes/content digests, and retained-GZF content agreement. Its informational hash-class limitations remain; this is not a general accuracy assessment.

Full-suite expected failures remain open: CODEX-5 on both platforms, absent llvm-pdbutil on Linux, and missing `--ghidra-dir` on both platforms. Synthetic native engine success does not close these gates.

## Evidence integrity

`post-main-qualification.json` is the final receipt. The portable ZIP contains complete executed-job log receipts, timestamped API snapshots, nine selected small original artifact ZIPs with digest/CRC verification, extracted evidence, source/assessment records, and the release comparison.

Large Windows/Linux product binaries were not downloaded locally and are excluded. Their artifact IDs, downloadable API URLs, sizes, and digests remain in the receipt. Windows API/upload digests agree; Linux additionally agrees with both actual hosted download logs.

`evidence-manifest.json` records every payload file's size and SHA-256. `archive-receipt.json` sits outside the ZIP to avoid a circular archive hash. The original primary PR349 ZIP was rehashed before sealing and remains unchanged at `8eb127426bcf216b840bc10d5243fccdb8964d4ba17bf53b6282920406b57859`.

No retry, dispatch, cancel, source/ref change, or local native/target execution was performed.

