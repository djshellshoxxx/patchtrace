"""Independent immutable-source audit. Writes only owned scratch evidence."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile
import yaml

BASE = Path('/workspace/scratch/837fe19aae3a')
REPO = BASE / 'repair-live-ghidra-archive'
OUT = BASE / 'evidence/live-ghidra-archive-independent/v1'
ROOT = OUT / 'immutable-source'
AUTHOR = BASE / 'evidence/live-ghidra-archive-recovery'
HEAD = '88df8cfbe51f91a6bc08c6863cd5d63f86500ca0'
PARENT = '1c70cd5f8053f75c269da673a24a82f221180650'
TREE = 'f22f034f92c0c82c59c86665e8b70acb87974448'
PATHS = ['.github/workflows/live-backend.yml', 'docs/specs/REGISTRY.md',
         'docs/specs/windows-acceptance-and-milestone-builds.md', 'tests/test_live_ghidra_archive.py']
OUT.mkdir(parents=True, exist_ok=True)
checks = []

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

def verify(name, value):
    checks.append({'name': name, 'passed': bool(value)})
    assert value, name

def sha(value):
    return hashlib.sha256(value).hexdigest()

def blob(ref, path):
    return git('show', f'{ref}:{path}')

verify('exact immutable commit object', git('cat-file', '-t', HEAD).decode().strip() == 'commit')
verify('exact tree', git('rev-parse', f'{HEAD}^{{tree}}').decode().strip() == TREE)
verify('ordered parent', git('show', '-s', '--format=%P', HEAD).decode().strip() == PARENT)
source_manifest = json.loads((OUT / 'immutable-source-manifest.json').read_text())
verify('private archived source pristine before', all(sha((ROOT / f['path']).read_bytes()) == f['sha256'] for f in source_manifest['files']))
verify('four changed paths only', git('diff', '--name-only', PARENT, HEAD).decode().splitlines() == PATHS)
message = git('show', '-s', '--format=%B', HEAD).decode()
verify('both publication holds', '[no release]' in message and '[no deploy]' in message)
snapshots = []
for path in PATHS:
    value = blob(HEAD, path)
    dest = OUT / 'source' / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(value)
    verify(f'working source equals commit: {path}', (ROOT / path).read_bytes() == value)
    verify(f'author source equals commit: {path}', (AUTHOR / 'candidate-source' / path).read_bytes() == value)
    snapshots.append({'path': path, 'git_blob': git('rev-parse', f'{HEAD}:{path}').decode().strip(), 'bytes': len(value), 'sha256': sha(value)})
old = blob(PARENT, PATHS[0]).decode()
new = blob(HEAD, PATHS[0]).decode()
(OUT / 'parent-workflow.yml').write_text(old)
old_doc, new_doc = yaml.safe_load(old), yaml.safe_load(new)
parent_steps = old_doc['jobs']['native']['steps']
candidate_steps = new_doc['jobs']['native']['steps']
old_archive = [s for s in parent_steps if 'Expand-Archive' in s.get('run', '')][0]
new_archive = [s for s in candidate_steps if 'Expand-Archive' in s.get('run', '')][0]
cache = [s for s in candidate_steps if s.get('id') == 'ghidra-cache'][0]
projection = copy.deepcopy(new_doc)
projection.pop('env')
projection_steps = projection['jobs']['native']['steps']
projection_steps.remove(cache)
projection_steps[projection_steps.index(new_archive)] = copy.deepcopy(old_archive)
verify('entire parsed workflow exact after allowed projection', projection == old_doc)
verify('all twelve other step objects exact and ordered',
       [s for s in candidate_steps if s not in (new_archive, cache)] == [s for s in parent_steps if s != old_archive]
       and len(parent_steps) - 1 == 12)
env_block = new[new.index('env:\n'):new.index('concurrency:\n')]
projected_text = new.replace(env_block, '', 1)
start = projected_text.index('      # Retain the original archive, never the extracted runtime.')
end = projected_text.index('      - run: python -m pip install', start)
old_start = old.index('      - shell: pwsh\n        run: |\n          Invoke-WebRequest')
old_end = old.index('      - run: python -m pip install', old_start)
projected_text = projected_text[:start] + old[old_start:old_end] + projected_text[end:]
verify('entire workflow bytes exact after allowed projection', projected_text == old)
for key in ('GHIDRA_URL', 'GHIDRA_SHA256'):
    verify(f'original literal retained: {key}', new_doc['env'][key] in old_archive['run'])
verify('fixed current pin exact lowercase hex', len(new_doc['env']['GHIDRA_SHA256']) == 64 and all(c in '0123456789abcdef' for c in new_doc['env']['GHIDRA_SHA256']))
verify('exact pinned cache inputs', cache['uses'] == 'actions/cache@0057852bfaa89a56745cba8c7296529d2fc39830' and cache['with'] == {'path': 'ghidra-archive', 'key': 'ghidra-archive-v1-${{ env.GHIDRA_SHA256 }}'})
verify('cache and install unconditional and required', all('if' not in s and 'continue-on-error' not in s for s in (cache, new_archive)))

spec = importlib.util.spec_from_file_location('independent_native_archive_tests', ROOT / PATHS[-1])
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
source_tests = [getattr(module, name) for name in (
    'test_native_workflow_reuses_the_original_archive_cache_and_existing_pins',
    'test_actual_step_verifies_one_archive_before_removing_the_extracted_tree',
    'test_restored_archive_is_not_overwritten_by_an_unconditional_download',
    'test_archive_reuse_preserves_native_cases_and_required_acceptance')]
original_workflow = module.WORKFLOW
fixture = OUT / 'control-workflow.yml'
module.WORKFLOW = fixture
controls = []

def control(name, value, reject):
    fixture.write_text(value)
    failed = []
    for test in source_tests:
        try:
            test()
        except (AssertionError, KeyError, StopIteration, ValueError) as exc:
            failed.append({'test': test.__name__, 'error': type(exc).__name__, 'message': str(exc)})
    accepted = not failed
    verify(f'control {name}', accepted != reject)
    controls.append({'name': name, 'expected': 'refuse' if reject else 'accept', 'accepted': accepted, 'failures': failed})

control('exact candidate', new, False)
control('unchanged parent', old, True)
mutations = [
    ('cache extracted runtime', 'path: ghidra-archive', 'path: ghidra-runtime'),
    ('fallback restore key', 'path: ghidra-archive', 'path: ghidra-archive\n          restore-keys: ghidra-archive-'),
    ('mutable cache action', 'actions/cache@0057852bfaa89a56745cba8c7296529d2fc39830', 'actions/cache@v4'),
    ('wrong digest', new_doc['env']['GHIDRA_SHA256'], '0' * 64),
    ('wrong URL', new_doc['env']['GHIDRA_URL'], 'https://example.invalid/wrong.zip'),
    ('skip verification on hit', '        shell: pwsh\n        run: |\n          $ErrorActionPreference', '        if: steps.ghidra-cache.outputs.cache-hit != \'true\'\n        shell: pwsh\n        run: |\n          $ErrorActionPreference'),
    ('advisory install', '        shell: pwsh\n        run: |\n          $ErrorActionPreference', '        continue-on-error: true\n        shell: pwsh\n        run: |\n          $ErrorActionPreference'),
    ('wrong shell', '        shell: pwsh\n        run: |\n          $ErrorActionPreference', '        shell: bash\n        run: |\n          $ErrorActionPreference'),
    ('nonterminating errors', "$ErrorActionPreference = 'Stop'", "$ErrorActionPreference = 'Continue'"),
    ('removed digest read', 'Get-FileHash -LiteralPath $archive -Algorithm SHA256', 'Get-Item -LiteralPath $archive'),
    ('removed mismatch throw', "throw 'Ghidra archive digest mismatch'", "Write-Host 'Ghidra archive digest mismatch'"),
    ('unconditional download', 'if (-not (Test-Path -LiteralPath $archive -PathType Leaf))', 'if ($true)'),
    ('stale runtime retained', 'Remove-Item -LiteralPath ghidra-runtime -Recurse -Force', 'Write-Host retained'),
    ('different extracted archive', 'Expand-Archive -LiteralPath $archive -DestinationPath ghidra-runtime', "Expand-Archive -LiteralPath 'other.zip' -DestinationPath ghidra-runtime"),
    ('budget drift', 'timeout-minutes: 25', 'timeout-minutes: 60'),
    ('lost native matrix case', 'raw-cache-hit]', 'removed-cache-hit]'),
    ('raw cache command weakened', 'python tools/live_cache_check.py --diagnostics-dir live-cache-diagnostics', 'echo skipped'),
    ('strict reproduction weakened', '$code -eq 0 -or -not', '$code -eq 0 -and -not'),
]
for name, before, after in mutations:
    assert before in new, name
    control(name, new.replace(before, after, 1), True)
fixture.unlink()
module.WORKFLOW = original_workflow
verify('private archived source pristine after controls', all(sha((ROOT / f['path']).read_bytes()) == f['sha256'] for f in source_manifest['files']))

archive_path = AUTHOR / 'live-ghidra-archive-recovery.zip'
raw_archive = archive_path.read_bytes()
verify('author ZIP hash', sha(raw_archive) == 'c096caf608c442a51de958701acff3346709349bc024b96e79ffadcd2fc91bd9')
verify('author ZIP length', len(raw_archive) == 312675)
manifest_bytes = (AUTHOR / 'MANIFEST.json').read_bytes()
verify('author manifest hash', sha(manifest_bytes) == '773bca11ff54563bd0382e981c72280a182428173c5d31ecfec8ddb440058f65')
manifest = json.loads(manifest_bytes)
with zipfile.ZipFile(archive_path) as z:
    verify('author ZIP CRC', z.testzip() is None)
    verify('author ZIP complete member set', set(z.namelist()) == {f['path'] for f in manifest['files']} | {'MANIFEST.json'})
    verify('author ZIP member count', len(z.namelist()) == 62)
    verify('embedded manifest equals external', z.read('MANIFEST.json') == manifest_bytes)
    for entry in manifest['files']:
        raw = z.read(entry['path'])
        verify(f'author sealed payload {entry["path"]}', len(raw) == entry['bytes'] and sha(raw) == entry['sha256'] and raw == (AUTHOR / entry['path']).read_bytes())
xml_counts = {}
for name in ('green-focused', 'red-parent', 'red-parent-final'):
    cases = ET.parse(AUTHOR / f'{name}.xml').findall('.//testcase')
    counts = {'total': len(cases), 'passed': 0, 'failed': 0, 'errors': 0, 'skipped': 0, 'xfail': 0}
    ids = []
    for case in cases:
        ids.append((case.attrib['classname'], case.attrib['name']))
        failure, error, skip = case.find('failure'), case.find('error'), case.find('skipped')
        key = 'failed' if failure is not None else 'errors' if error is not None else ('xfail' if skip.attrib.get('type') == 'pytest.xfail' else 'skipped') if skip is not None else 'passed'
        counts[key] += 1
    verify(f'unique author case identities {name}', len(ids) == len(set(ids)))
    xml_counts[name] = counts
verify('author green exact scope counts', xml_counts['green-focused'] == {'total': 271, 'passed': 260, 'failed': 0, 'errors': 0, 'skipped': 9, 'xfail': 2})
report = {'source': HEAD, 'tree': TREE, 'parent': PARENT, 'checks': checks, 'source_snapshots': snapshots,
          'controls': controls, 'author_xml_counts': xml_counts,
          'finding': {'status': 'BLOCKED', 'kind': 'source-contract edge', 'guard': '^[0-9a-f]{64}$',
                      'input': '64 lowercase hexadecimal characters followed by LF',
                      'effect': 'guard admits malformed pin before potential download; digest comparison still prevents extraction',
                      'fixed_workflow_literal_affected': False,
                      'primary_reference': 'https://learn.microsoft.com/en-us/dotnet/standard/base-types/anchors-in-regular-expressions',
                      'recommended_guard': r'\A[0-9a-f]{64}\z'},
          'native_execution': False, 'powershell_execution': False, 'remote_mutations': False}
(OUT / 'source-review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'controls': len(controls), 'source': HEAD, 'status': 'BLOCKED guard edge; all other checks pass', 'author_counts': xml_counts}))


