# Independent original Ghidra archive review

**Clear for integration and exact-source hosted qualification:** `f596471b8909ec8e28e0624041d60f03d520591d`, tree `dffeed541749850ef54a130cec0fa56c0fd2f01c`, direct parent `88df8cfbe51f91a6bc08c6863cd5d63f86500ca0`; original base `1c70cd5f8053f75c269da673a24a82f221180650`.

The original candidate had one narrow contract error. Its `$` regex anchor allowed a match before final LF, so a malformed 64-hex-plus-LF value could reach downloading on a miss. The later checksum comparison still stopped extraction, and the fixed source pin was exact 64 characters. The corrective child uses absolute `\A` and `\z` anchors. Its sole workflow delta is that guard; its new terminal-LF fixture requires nonzero exit and no download, runtime or environment export. Microsoft documents the relevant [absolute and final-newline anchor semantics](https://learn.microsoft.com/en-us/dotnet/standard/base-types/anchors-in-regular-expressions). The original red finding is retained.

## Source and control proof

The combined change touches four paths only: native workflow, existing acceptance specification and registry row, and its focused test module. Restoring the old provisioning step and removing only the new pin environment/cache additions reconstructs the entire original workflow byte-for-byte and as parsed YAML. All twelve other steps, five variants, runtime pins, fixture compilation, strict cached-PDB reproduction, native and raw-cache commands, diagnostics, events, permissions, concurrency and the 25-minute limit remain exact.

The original review records 115 checks and 20 workflow controls. The corrected review records 108 checks, 22 workflow controls and two platform controls: missing PowerShell fails on Windows and explicitly skips on Linux. These are overlapping source checks, not additional native tests. Every retained author ZIP member matches its manifest, CRC and external bytes. The corrective archive includes the exact original author archive and original reviewer finding.

## Exact-source test result

The independent clean-source run completed **260 passed, 10 explicit PowerShell-unavailable skips and 2 existing strict CODEX-5 expected failures**, 272 distinct cases across seven modules, in 2.438 command seconds. Candidate `patchtrace` and backend imports were checked explicitly using isolated Python; the shared environment was not rebound. Both strict expected failures preserve the broader missing hash-boundary issue. The workflow census remains **21 workflows / 203 run steps / 42 explicit pip installs / 41 unprotected installs**.

The terminal-LF runtime fixture is among the ten unexecuted PowerShell cases. No PowerShell, engine, target, hosted-cache or native acceptance was exercised here. Actual Windows execution, a cold original-ZIP save followed by an exact-key restored ZIP verification/fresh extraction, and all five native outcomes remain required. Cache scope/version and existing same-event/ref cancellation still apply. Raw-analysis cache proof remains separate. Manual, air-gap and broader dependency/pin gates remain open.

## Retained unsuccessful attempts

The evidence keeps the original 88 guard finding; author parent-red runs; the review clean-source guard refusal after authorized author correction began; an initial reviewer control that selected the wrong quoted token; and an initial final-source pytest attempt with 244 passes, 2 expected failures and 26 fixture setup errors from a missing scratch temp parent. The corrected command used the same frozen source and argv after creating only that scratch parent. These attempts are not aggregate success claims. No source, environment, Git ref, PR or CI mutation was performed by the reviewer.

The final promotion-bound records/helper/remote-object audit is still outstanding. Earlier `1c` or PR351 Windows results must retain their own source identities.
