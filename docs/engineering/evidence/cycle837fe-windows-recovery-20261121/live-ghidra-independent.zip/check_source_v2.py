"""Bounded independent review of the immutable absolute-anchor descendant."""
from pathlib import Path
import ast
import hashlib
import importlib.util
import json
import subprocess
import sys
import xml.etree.ElementTree as ET
import zipfile
from unittest.mock import patch
import pytest
import yaml

BASE = Path('/workspace/scratch/837fe19aae3a')
ROOT = BASE / 'repair-live-ghidra-archive'
OUT = BASE / 'evidence/live-ghidra-archive-independent/v2'
AUTHOR = BASE / 'evidence/live-ghidra-archive-pin-repair'
HEAD = 'f596471b8909ec8e28e0624041d60f03d520591d'
PARENT = '88df8cfbe51f91a6bc08c6863cd5d63f86500ca0'
TREE = 'dffeed541749850ef54a130cec0fa56c0fd2f01c'
PATHS = ['.github/workflows/live-backend.yml', 'docs/specs/REGISTRY.md',
         'docs/specs/windows-acceptance-and-milestone-builds.md', 'tests/test_live_ghidra_archive.py']
OUT.mkdir(parents=True, exist_ok=True)
checks = []

def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args])

def verify(name, value):
    checks.append({'name': name, 'passed': bool(value)})
    assert value, name

def sha(value):
    return hashlib.sha256(value).hexdigest()

def blob(ref, path):
    return git('show', f'{ref}:{path}')

verify('exact clean head', git('rev-parse', 'HEAD').decode().strip() == HEAD and git('status', '--porcelain=v1') == b'')
verify('exact tree', git('rev-parse', f'{HEAD}^{{tree}}').decode().strip() == TREE)
verify('exact ordered parent', git('show', '-s', '--format=%P', HEAD).decode().strip() == PARENT)
verify('only same four paths changed', git('diff', '--name-only', PARENT, HEAD).decode().splitlines() == PATHS)
verify('only four paths changed versus original 1c', git('diff', '--name-only', '1c70cd5f8053f75c269da673a24a82f221180650', HEAD).decode().splitlines() == PATHS)
message = git('show', '-s', '--format=%B', HEAD).decode()
verify('both publication holds', '[no release]' in message and '[no deploy]' in message)
snapshots = []
for path in PATHS:
    data = blob(HEAD, path)
    dest = OUT / 'source' / path
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    verify(f'working source equals immutable commit: {path}', (ROOT / path).read_bytes() == data)
    verify(f'author snapshot equals immutable commit: {path}', (AUTHOR / 'candidate-source' / path).read_bytes() == data)
    snapshots.append({'path': path, 'git_blob': git('rev-parse', f'{HEAD}:{path}').decode().strip(), 'bytes': len(data), 'sha256': sha(data)})
old = blob(PARENT, PATHS[0]).decode()
new = blob(HEAD, PATHS[0]).decode()
old_guard, new_guard = '^[0-9a-f]{64}$', r'\A[0-9a-f]{64}\z'
verify('sole workflow change is exact absolute guard', old.count(old_guard) == 1 and new == old.replace(old_guard, new_guard, 1))
new_doc = yaml.safe_load(new)
install = next(s for s in new_doc['jobs']['native']['steps'] if 'Expand-Archive' in s.get('run', ''))
verify('absolute guard precedes directory creation/download/hash/extraction', install['run'].index(new_guard) < install['run'].index('New-Item') < install['run'].index('Invoke-WebRequest') < install['run'].index('Get-FileHash') < install['run'].index('Remove-Item') < install['run'].index('Expand-Archive'))
old_test, new_test = blob(PARENT, PATHS[-1]).decode(), blob(HEAD, PATHS[-1]).decode()
expected_test = old_test.replace('        "$env:GHIDRA_SHA256 -cnotmatch \'^[0-9a-f]{64}$\'",', '        r"$env:GHIDRA_SHA256 -cnotmatch \'\\A[0-9a-f]{64}\\z\'",', 1)
expected_test = expected_test.replace('@pytest.mark.parametrize("digest", ("", "a" * 63, "A" * 64, "not-a-sha256"))', '@pytest.mark.parametrize("digest", (\n    "", "a" * 63, "A" * 64, "not-a-sha256",\n    pytest.param("a" * 64 + "\\n", id="terminal-lf"),\n))', 1)
verify('only static guard and terminal-LF parameter changed in maintained tests', new_test == expected_test)
verify('actual fixture has strict no-download/runtime/export assertions', all(s in new_test for s in ('assert result.returncode != 0', 'assert not (tmp_path / "downloads.txt").exists()', 'assert not (tmp_path / "ghidra-runtime").exists()', 'assert not (tmp_path / "github-env").exists()')))
registry_old, registry_new = blob(PARENT, PATHS[1]).decode(), blob(HEAD, PATHS[1]).decode()
verify('registry only existing row clarification', registry_new == registry_old.replace('native-matrix original Ghidra archive verification have source/fixture regressions;', 'native-matrix original Ghidra archive verification with strict entire-value pin validation have source/fixture regressions;', 1))
spec_text = blob(HEAD, PATHS[2]).decode()
verify('spec names exact guard and continued external acceptance', all(s in spec_text for s in (new_guard, 'with no terminal LF', 'hosted cache or native acceptance', 'successful cache\nsave', 'actual exact-key restore')))

spec = importlib.util.spec_from_file_location('independent_native_archive_v2', ROOT / PATHS[-1])
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
source_tests = [getattr(module, name) for name in (
    'test_native_workflow_reuses_the_original_archive_cache_and_existing_pins',
    'test_actual_step_verifies_one_archive_before_removing_the_extracted_tree',
    'test_restored_archive_is_not_overwritten_by_an_unconditional_download',
    'test_archive_reuse_preserves_native_cases_and_required_acceptance')]
fixture = OUT / 'control-workflow.yml'
original_workflow = module.WORKFLOW
module.WORKFLOW = fixture
controls = []

def control(name, value, reject):
    fixture.write_text(value)
    failed = []
    for test in source_tests:
        try:
            test()
        except (AssertionError, KeyError, StopIteration, ValueError) as exc:
            failed.append({'test': test.__name__, 'error': type(exc).__name__, 'message': str(exc)})
    accepted = not failed
    verify(f'control {name}', accepted != reject)
    controls.append({'name': name, 'expected': 'refuse' if reject else 'accept', 'accepted': accepted, 'failures': failed})

control('exact corrective child', new, False)
control('original 88 guard', old, True)
review_ast = ast.parse((OUT.parent / 'check_source_v1.py').read_text())
assignment = next(n for n in review_ast.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'mutations' for t in n.targets))
mutations = eval(compile(ast.Expression(assignment.value), '<owned review controls>', 'eval'), {'new_doc': new_doc})
mutations += [('missing pin guard', new_guard, '[0-9a-f]{64}'), ('nonabsolute final anchor', new_guard, r'\A[0-9a-f]{64}\Z')]
for name, before, after in mutations:
    assert before in new, name
    control(name, new.replace(before, after, 1), True)
fixture.unlink()
module.WORKFLOW = original_workflow
platform_controls = []
for platform, exception in [('win32', pytest.fail.Exception), ('linux', pytest.skip.Exception)]:
    with patch.object(module.shutil, 'which', lambda _: None), patch.object(module.sys, 'platform', platform):
        with pytest.raises(exception) as caught:
            module.powershell.__wrapped__()
    platform_controls.append({'platform': platform, 'outcome': type(caught.value).__name__, 'message': str(caught.value)})
verify('Windows missing PowerShell fails; Linux explicitly skips', len(platform_controls) == 2)

archive_path = next(AUTHOR.glob('*.zip'))
raw_archive = archive_path.read_bytes()
verify('author repair ZIP hash', sha(raw_archive) == 'dfefa8aedef0c6758c54dae9843fc2e35ec4446af12af0315395b481ba2194cf')
verify('author repair ZIP length', len(raw_archive) == 442323)
manifest_bytes = (AUTHOR / 'MANIFEST.json').read_bytes()
verify('author repair manifest hash', sha(manifest_bytes) == 'f581033a7ba517c0ab675cbf40d784534969099784e4dcdd2f2bee06c464c255')
manifest = json.loads(manifest_bytes)
with zipfile.ZipFile(archive_path) as z:
    verify('author repair ZIP CRC', z.testzip() is None)
    verify('author repair ZIP exact member set', set(z.namelist()) == {f['path'] for f in manifest['files']} | {'MANIFEST.json'})
    verify('author repair ZIP member count', len(z.namelist()) == 42)
    verify('author repair embedded manifest equals external', z.read('MANIFEST.json') == manifest_bytes)
    for entry in manifest['files']:
        data = z.read(entry['path'])
        verify(f'author repair payload {entry["path"]}', len(data) == entry['bytes'] and sha(data) == entry['sha256'] and data == (AUTHOR / entry['path']).read_bytes())

phase = json.loads((AUTHOR / 'contract-before-repair.json').read_text())
for entry in phase['files']:
    ref = PARENT if entry['path'] == PATHS[0] else HEAD
    data = blob(ref, entry['path'])
    verify(f'spec-first retained phase bytes {entry["path"]}', sha(data) == entry['sha256'] and len(data) == entry['bytes'])

def xml_counts(path):
    cases = ET.parse(path).findall('.//testcase')
    counts = {'total': len(cases), 'passed': 0, 'failed': 0, 'errors': 0, 'skipped': 0, 'xfail': 0}
    ids, exceptions = [], []
    for case in cases:
        ids.append((case.attrib['classname'], case.attrib['name']))
        failure, error, skip = case.find('failure'), case.find('error'), case.find('skipped')
        key = 'failed' if failure is not None else 'errors' if error is not None else ('xfail' if skip.attrib.get('type') == 'pytest.xfail' else 'skipped') if skip is not None else 'passed'
        counts[key] += 1
        if key != 'passed':
            exceptions.append({'case': ids[-1], 'outcome': key, 'xml': ET.tostring(case, encoding='unicode')})
    verify(f'unique XML cases {path.parent.name}/{path.name}', len(ids) == len(set(ids)))
    return {'counts': counts, 'case_ids': ids, 'exceptions': exceptions}

independent = xml_counts(OUT / 'focused.xml')
author_green = xml_counts(AUTHOR / 'green-focused.xml')
author_red = xml_counts(AUTHOR / 'red-parent.xml')
initial_harness = xml_counts(OUT / 'initial-missing-temp-parent-focused.xml')
expected_counts = {'total': 272, 'passed': 260, 'failed': 0, 'errors': 0, 'skipped': 10, 'xfail': 2}
verify('independent exact focused counts', independent['counts'] == expected_counts)
verify('independent IDs match author exact source cases', independent['case_ids'] == author_green['case_ids'])
verify('author red remains one static guard failure', author_red['counts'] == {'total': 14, 'passed': 3, 'failed': 1, 'errors': 0, 'skipped': 10, 'xfail': 0})
verify('all ordinary skips explicitly missing PowerShell', all('PowerShell unavailable' in e['xml'] for e in independent['exceptions'] if e['outcome'] == 'skipped'))
verify('two CODEX5 expected failures remain distinct', {e['case'][1] for e in independent['exceptions'] if e['outcome'] == 'xfail'} == {'test_pip_downloads_require_hashes', 'test_all_explicit_workflow_pip_installs_are_protected'})
verify('terminal LF runtime fixture explicitly skipped here', any(e['case'][1].endswith('[terminal-lf]') and e['outcome'] == 'skipped' for e in independent['exceptions']))
command = json.loads((OUT / 'focused-command.json').read_text())
verify('exact clean focused command source', command['source'] == HEAD and command['tree'] == TREE and command['exit_code'] == 0 and command['clean_before'] and command['status_after'] == '')
sys.path.insert(0, str(ROOT))
from tools.ci_pip_install_audit import pip_installs, run_scalars, unhashed_installs
corpus = {}
for path in sorted((ROOT / '.github/workflows').glob('*.y*ml')):
    source = path.read_text()
    corpus[path.name] = [len(list(run_scalars(source))), len(pip_installs(source)), len(unhashed_installs(source))]
census = [len(corpus), *(sum(row[i] for row in corpus.values()) for i in range(3))]
verify('current workflow census unchanged', census == [21, 203, 42, 41])
verify('final clean source', git('status', '--porcelain=v1') == b'' and git('rev-parse', 'HEAD').decode().strip() == HEAD)
result = {'source': HEAD, 'tree': TREE, 'parent': PARENT, 'checks': checks, 'source_snapshots': snapshots,
          'controls': controls, 'missing_powershell_platform_controls': platform_controls,
          'independent_tests': independent, 'author_tests': author_green, 'author_red': author_red,
          'initial_harness_failure_preserved': initial_harness, 'workflow_census': census, 'workflow_detail': corpus,
          'verdict': 'CLEAR FOR INTEGRATION AND EXACT-SOURCE HOSTED QUALIFICATION',
          'original_finding': 'V1 trailing-LF guard gap corrected by absolute anchors; original fixed literal was unaffected.',
          'pending': ['Actual Windows PowerShell fixture execution', 'Cold original-archive save and exact-key warm restore', 'All five native matrix outcomes', 'Manual/air-gap and broader dependency/pin gates'],
          'native_execution': False, 'powershell_execution': False, 'remote_mutations': False,
          'primary_reference': 'https://learn.microsoft.com/en-us/dotnet/standard/base-types/anchors-in-regular-expressions'}
(OUT / 'source-review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'source': HEAD, 'tree': TREE, 'checks': len(checks), 'workflow_controls': len(controls), 'platform_controls': len(platform_controls), 'tests': independent['counts'], 'census': census, 'verdict': result['verdict']}))
