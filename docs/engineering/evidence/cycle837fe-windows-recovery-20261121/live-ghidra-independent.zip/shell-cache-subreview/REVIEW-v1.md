# Native Ghidra original-archive shell/cache subreview

**88df8cfb is blocked on one narrow pre-download pin-validation contract gap.** Source tree f22f034f92c0c82c59c86665e8b70acb87974448 and exact parent1c70 were verified.

The pin guard uses `^[0-9a-f]{64}$`. The .NET `$` anchor can match before a final LF, so lowercase64hex plus LF passes the early guard and can reach the download on a miss. The later digest comparison rejects it before extraction, but section2.1 explicitly requires malformed pins be refused before download. Use absolute anchors `\A[0-9a-f]{64}\z` and add an inert trailing-LF regression asserting no download/extraction/export. This is a source-level finding; no PowerShell reproduction is claimed.

Other inspected boundaries are consistent: a present original ZIP is never redownloaded; a corrupt hit remains available as evidence and cannot clear the prior extraction or export a runtime. Both hash verification and logging precede fresh runtime removal/extraction. All four cold/restored valid/corrupt fixture combinations use inert authored ZIPs and replace only downloading. Missing PowerShell fails on Windows and explicitly skips elsewhere.

The pinned cache receipts were hash-bound to the sealed author archive. They specify a success-only post-save hook and cache scope by key, internal version and branch. Current input uses only the original archive directory and full digest key, without a fallback restore key or extracted-runtime cache. No cache output bypasses verification. Cross-OS restore is not enabled. Actual cold download/checksum/extraction/save followed by exact-scope warm restore/checksum/extraction and all five native outcomes remain required; a matching literal key or raw-analysis cache hit does not close those gates.

Review files retain exact source/test bytes, original pinned action receipts and decoded content hashes. Zero tests, PowerShell/native processes, downloads, source/environment/ref/PR/CI mutations occurred. Parent owns whole-workflow/spec projection, maintained tests and final corrected-source review.
