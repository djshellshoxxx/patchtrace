"""Seal exact-source independent receipts; exclude reproducible source/temp trees."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import subprocess
import zipfile

BASE = Path('/workspace/scratch/837fe19aae3a')
OUT = BASE / 'evidence/live-ghidra-archive-independent'
HEAD = 'f596471b8909ec8e28e0624041d60f03d520591d'
TREE = 'dffeed541749850ef54a130cec0fa56c0fd2f01c'
v1 = json.loads((OUT / 'v1/source-review.json').read_text())
v2 = json.loads((OUT / 'v2/source-review.json').read_text())
command = json.loads((OUT / 'v2/focused-command.json').read_text())
support = OUT / 'retained-author-evidence'
support.mkdir(exist_ok=True)
author_zip = next((BASE / 'evidence/live-ghidra-archive-pin-repair').glob('*.zip'))
shutil.copy2(author_zip, support / author_zip.name)

def sha(data):
    return hashlib.sha256(data).hexdigest()

review = {
    'schema': 'patchtrace/independent-live-ghidra-archive-review/1',
    'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'verdict': 'CLEAR FOR INTEGRATION AND EXACT-SOURCE HOSTED QUALIFICATION',
    'head': HEAD, 'tree': TREE,
    'ordered_parents': ['88df8cfbe51f91a6bc08c6863cd5d63f86500ca0'],
    'original_base': '1c70cd5f8053f75c269da673a24a82f221180650',
    'original_base_tree': 'a39d650ca7fa2b41ece017ea492396722a4142d9',
    'original_candidate': {'head': v1['source'], 'tree': v1['tree'], 'status_at_review': 'BLOCKED',
                           'finding': v1['finding'], 'finding_resolved_by': HEAD,
                           'checks': len(v1['checks']), 'workflow_controls': len(v1['controls'])},
    'corrected_candidate': {'checks': len(v2['checks']), 'workflow_controls': len(v2['controls']),
                            'platform_controls': len(v2['missing_powershell_platform_controls']),
                            'source_snapshots': v2['source_snapshots']},
    'source_preservation': {
        'four_changed_paths_only': True, 'all_other_tracked_paths_unchanged_from_1c': True,
        'original_workflow_restores_byte_exactly_after_allowed_projection': True,
        'all_twelve_other_steps_exact_and_ordered': True, 'all_five_native_variants_preserved': True,
        'only_corrective_workflow_delta': '^[0-9a-f]{64}$ -> \\A[0-9a-f]{64}\\z',
        'both_commit_opt_outs': True, 'workflow_census': v2['workflow_census'],
        'census_order': ['workflows', 'run_steps', 'explicit_pip_installs', 'unprotected_pip_installs'],
    },
    'independent_validation': {
        'counts': v2['independent_tests']['counts'], 'distinct_cases': 272, 'modules': 7,
        'elapsed_seconds': command['elapsed_seconds'], 'clean_before': command['clean_before'],
        'clean_after': command['status_after'] == '',
        'source_binding': 'Isolated Python explicitly imports candidate patchtrace/backend. Frozen shared environment metadata still points at Pages checkout and was not rebound.',
        'native_execution': False, 'powershell_execution': False,
        'ordinary_skips': 'Ten actual PowerShell archive fixtures unavailable on this host, including terminal-LF.',
        'strict_expected_failures': 'Two existing CODEX-5 tests retain known missing hash-boundary meaning; parser/discovery errors are not reclassified.',
    },
    'author_evidence_independently_verified': {
        'original_zip_sha256': 'c096caf608c442a51de958701acff3346709349bc024b96e79ffadcd2fc91bd9',
        'original_zip_bytes': 312675, 'original_zip_members': 62,
        'corrective_zip_sha256': sha(author_zip.read_bytes()), 'corrective_zip_bytes': author_zip.stat().st_size,
        'corrective_zip_members': 42, 'all_crc_manifest_and_external_member_bytes_equal': True,
        'original_parent_red': v1['author_xml_counts']['red-parent'],
        'original_parent_final_red': v1['author_xml_counts']['red-parent-final'],
        'corrective_parent_red': v2['author_red']['counts'],
        'validation_provenance': 'Author tests used precommit candidate bytes, each exactly matched to final commit; independent rerun used clean frozen final commit.',
    },
    'review_harness_history_preserved': [
        'V1 clean-source guard refused before tests when authorized author correction began; reviewer then materialized all 4727 tracked files from immutable 88 Git objects.',
        'An initial missing-variant control selected a different earlier quoted condition; retained and corrected to exact unquoted matrix token. Whole-workflow preservation proof was unchanged.',
        'Initial final-source pytest had 244 pass, 2 xfail and 26 fixture setup errors because scratch --basetemp parent was absent; exact command reran after scratch-only directory creation.',
    ],
    'pending': v2['pending'],
    'cache_acceptance_limits': 'Pinned key does not prove cache existence: branch scope/internal version still apply. Complete cold job save before warm same-event/ref run to avoid existing cancellation. Original archive proof and Ghidriff raw-analysis cache proof are distinct.',
    'root_final_records_review': 'Still required after actual PR351 promotion and final source/context/remote mapping; prior 1c or d667 Windows counts must not be attributed to this child.',
    'mutations': {'source': False, 'environment': False, 'git_refs': False, 'remote': False, 'PR': False, 'CI': False},
    'primary_reference': v2['primary_reference'],
}
(OUT / 'review.json').write_text(json.dumps(review, indent=2) + '\n')
(OUT / 'REVIEW.md').write_text('''# Independent original Ghidra archive review

**Clear for integration and exact-source hosted qualification:** `f596471b8909ec8e28e0624041d60f03d520591d`, tree `dffeed541749850ef54a130cec0fa56c0fd2f01c`, direct parent `88df8cfbe51f91a6bc08c6863cd5d63f86500ca0`; original base `1c70cd5f8053f75c269da673a24a82f221180650`.

The original candidate had one narrow contract error. Its `$` regex anchor allowed a match before final LF, so a malformed 64-hex-plus-LF value could reach downloading on a miss. The later checksum comparison still stopped extraction, and the fixed source pin was exact 64 characters. The corrective child uses absolute `\\A` and `\\z` anchors. Its sole workflow delta is that guard; its new terminal-LF fixture requires nonzero exit and no download, runtime or environment export. Microsoft documents the relevant [absolute and final-newline anchor semantics](https://learn.microsoft.com/en-us/dotnet/standard/base-types/anchors-in-regular-expressions). The original red finding is retained.

## Source and control proof

The combined change touches four paths only: native workflow, existing acceptance specification and registry row, and its focused test module. Restoring the old provisioning step and removing only the new pin environment/cache additions reconstructs the entire original workflow byte-for-byte and as parsed YAML. All twelve other steps, five variants, runtime pins, fixture compilation, strict cached-PDB reproduction, native and raw-cache commands, diagnostics, events, permissions, concurrency and the 25-minute limit remain exact.

The original review records 115 checks and 20 workflow controls. The corrected review records 108 checks, 22 workflow controls and two platform controls: missing PowerShell fails on Windows and explicitly skips on Linux. These are overlapping source checks, not additional native tests. Every retained author ZIP member matches its manifest, CRC and external bytes. The corrective archive includes the exact original author archive and original reviewer finding.

## Exact-source test result

The independent clean-source run completed **260 passed, 10 explicit PowerShell-unavailable skips and 2 existing strict CODEX-5 expected failures**, 272 distinct cases across seven modules, in 2.438 command seconds. Candidate `patchtrace` and backend imports were checked explicitly using isolated Python; the shared environment was not rebound. Both strict expected failures preserve the broader missing hash-boundary issue. The workflow census remains **21 workflows / 203 run steps / 42 explicit pip installs / 41 unprotected installs**.

The terminal-LF runtime fixture is among the ten unexecuted PowerShell cases. No PowerShell, engine, target, hosted-cache or native acceptance was exercised here. Actual Windows execution, a cold original-ZIP save followed by an exact-key restored ZIP verification/fresh extraction, and all five native outcomes remain required. Cache scope/version and existing same-event/ref cancellation still apply. Raw-analysis cache proof remains separate. Manual, air-gap and broader dependency/pin gates remain open.

## Retained unsuccessful attempts

The evidence keeps the original 88 guard finding; author parent-red runs; the review clean-source guard refusal after authorized author correction began; an initial reviewer control that selected the wrong quoted token; and an initial final-source pytest attempt with 244 passes, 2 expected failures and 26 fixture setup errors from a missing scratch temp parent. The corrected command used the same frozen source and argv after creating only that scratch parent. These attempts are not aggregate success claims. No source, environment, Git ref, PR or CI mutation was performed by the reviewer.

The final promotion-bound records/helper/remote-object audit is still outstanding. Earlier `1c` or PR351 Windows results must retain their own source identities.
''')
(OUT / 'primary-anchor-reference.json').write_text(json.dumps({
    'url': v2['primary_reference'], 'retrieval_reference': 'turn575078612view0',
    'paraphrase': 'Microsoft documents that the default dollar anchor can match before a final LF; backslash-A and backslash-z require the actual start and end of the input.',
    'runtime_validation': False,
}, indent=2) + '\n')
archive_path = OUT / 'live-ghidra-archive-independent-f596471b.zip'
excluded_names = {'MANIFEST.json', 'archive-receipt.json', archive_path.name}
files = [p for p in OUT.rglob('*') if p.is_file() and not (p.parent == OUT and p.name in excluded_names)
         and 'immutable-source' not in p.relative_to(OUT).parts and 'tmp' not in p.relative_to(OUT).parts
         and '__pycache__' not in p.relative_to(OUT).parts]
manifest = {'schema': 'patchtrace/independent-evidence-manifest/1', 'head': HEAD, 'tree': TREE,
            'excluded': ['v1/immutable-source reproducible complete Git archive', 'v2/tmp reproducible pytest fixtures', 'top-level archive and receipt'],
            'files': [{'path': str(p.relative_to(OUT)), 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in sorted(files)]}
manifest_path = OUT / 'MANIFEST.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(archive_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for p in sorted(files) + [manifest_path]:
        archive.write(p, str(p.relative_to(OUT)))
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(files) + 1
    for p in files + [manifest_path]:
        assert archive.read(str(p.relative_to(OUT))) == p.read_bytes()
status = subprocess.check_output(['git', '-C', str(BASE / 'repair-live-ghidra-archive'), 'status', '--porcelain=v1'])
assert status == b''
receipt = {'archive': str(archive_path), 'bytes': archive_path.stat().st_size, 'members': len(files) + 1,
           'sha256': sha(archive_path.read_bytes()), 'manifest_sha256': sha(manifest_path.read_bytes()),
           'review_sha256': sha((OUT / 'review.json').read_bytes()), 'CRC_and_member_bytes_verified': True,
           'source_clean_after_seal': True}
(OUT / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
