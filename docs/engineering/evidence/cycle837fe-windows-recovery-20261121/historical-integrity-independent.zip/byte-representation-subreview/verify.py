"""Read-only complete branch check; evidence output only, no tests/imports."""
import ast
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/837fe19aae3a')
REPO = ROOT / 'PatchTrace-codex5-followup'
OUT = ROOT / 'evidence/historical-integrity-independent/byte-representation-subreview'
HEAD = '303bc452d0bb6cd46ee67f731f64ec951e1ee215'
CURRENT = '2ae1bbad2ad9cc78c29541872381750e347c670e'
BASE = '0ec471016d2838a90753e014a0d647dd90168e87'
TREE = '6001ef506c38930fd590bd827f428b997c3b2797'
SPEC = 'docs/specs/byte-representations.md'
INIT = 'src/patchtrace/representations/__init__.py'
TEST = 'tests/test_representations.py'
RUNTIME = ['src/patchtrace/representations/' + p + '.py' for p in ['compare', 'formatters', 'paging', 'render', 'scope']]
EXPECTED = {SPEC, INIT, TEST, *RUNTIME}
checks = []


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def blob(ref, path):
    return git('show', ref + ':' + path)


def check(name, value, **details):
    checks.append({'check': name, 'passed': bool(value), **details})
    assert value, name


check('Exact comparison tree', git('rev-parse', CURRENT + '^{tree}').decode().strip() == TREE)
check('Actual parent and common merge base exact', git('show', '-s', '--format=%P', HEAD).decode().strip() == BASE and git('merge-base', HEAD, CURRENT).decode().strip() == BASE)
check('One unique branch-side commit', git('rev-list', CURRENT + '..' + HEAD).decode().splitlines() == [HEAD])
names = git('diff', '--name-status', BASE, HEAD).decode().splitlines()
check('Whole branch contains exactly eight added paths', len(names) == 8 and {line.split('\t', 1)[1] for line in names} == EXPECTED and all(line.startswith('A\t') for line in names))
files = []
for path in sorted(EXPECTED):
    row = {'path': path, 'versions': {}}
    for label, ref in [('donor', HEAD), ('current', CURRENT)]:
        raw = blob(ref, path)
        row['versions'][label] = {'blob': git('rev-parse', ref + ':' + path).decode().strip(), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
    row['byte_identical'] = blob(HEAD, path) == blob(CURRENT, path)
    files.append(row)
for path in RUNTIME:
    check('Full runtime file byte-identical: ' + path, blob(HEAD, path) == blob(CURRENT, path))

old_init = ast.parse(blob(HEAD, INIT))
new_init = ast.parse(blob(CURRENT, INIT))
old_imports = [n for n in old_init.body if isinstance(n, (ast.Import, ast.ImportFrom))]
new_imports = [n for n in new_init.body if isinstance(n, (ast.Import, ast.ImportFrom))]
dump = lambda n: ast.dump(n, include_attributes=False)
check('Every original import remains AST-identical in original order', [dump(n) for n in new_imports if not (isinstance(n, ast.ImportFrom) and n.module == 'alignment')] == [dump(n) for n in old_imports])
new_alignment = [n for n in new_imports if isinstance(n, ast.ImportFrom) and n.module == 'alignment']
added_names = ['AlignmentLimits', 'AlignmentSpan', 'ByteAlignment', 'align_bytes', 'align_pages']
check('Exactly one distinct alignment import added', len(new_imports) == len(old_imports) + 1 and len(new_alignment) == 1 and [a.name for a in new_alignment[0].names] == added_names and all(a.asname is None for a in new_alignment[0].names))


def exports(tree):
    assignments = [n for n in tree.body if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == '__all__' for t in n.targets)]
    assert len(assignments) == 1
    return ast.literal_eval(assignments[0].value)


old_exports, new_exports = exports(old_init), exports(new_init)
check('Original exports preserved verbatim in order without name shadowing', new_exports == added_names + old_exports and not set(added_names) & set(old_exports), original_exports=len(old_exports), added_exports=added_names)
old_other = [n for n in old_init.body if not isinstance(n, (ast.Import, ast.ImportFrom, ast.Assign))]
new_other = [n for n in new_init.body if not isinstance(n, (ast.Import, ast.ImportFrom, ast.Assign))]
check('Initializer has no other changed statements', [dump(n) for n in old_other] == [dump(n) for n in new_other])
old_test = blob(HEAD, TEST)
new_test = blob(CURRENT, TEST)
check('Entire original test file preserved as exact byte prefix', new_test.startswith(old_test), original_bytes=len(old_test), appended_bytes=len(new_test) - len(old_test))
appended_ast = ast.parse(new_test[len(old_test):])
check('Only appended past-end shorter-side regression', len(appended_ast.body) == 1 and isinstance(appended_ast.body[0], ast.FunctionDef) and appended_ast.body[0].name == 'test_page_past_end_of_shorter_side_is_not_clamped_to_its_last_page')

old_spec = blob(HEAD, SPEC).decode()
new_spec = blob(CURRENT, SPEC).decode()
neutral = new_spec
amendment = next(line for line in neutral.splitlines() if line.startswith('> **SPEC-31 status amendment'))
neutral = neutral.replace(amendment + '\n\n', '', 1)
start = neutral.index('### RD-F03:')
end = neutral.index('### Formats', start)
extension = neutral[start:end]
neutral = neutral[:start] + neutral[end:]
changes = []
for prefix in ['The only source of bytes is', 'Code-line evidence navigation']:
    old = next(p for p in old_spec.split('\n\n') if p.startswith(prefix))
    new = next(p for p in new_spec.split('\n\n') if p.startswith(prefix))
    neutral = neutral.replace(new, old, 1)
    changes.append({'kind': prefix, 'original': old, 'current': new})
old_io = next(line for line in old_spec.splitlines() if line.startswith('* A single read is'))
new_io = next(line for line in new_spec.splitlines() if line.startswith('* Returned bytes are'))
neutral = neutral.replace(new_io, old_io, 1)
changes.append({'kind': 'physical I/O and memory bounds updated for verified block reader', 'original': old_io, 'current': new_io})
check('Spec neutralizes exactly to original after bounded extensions', neutral == old_spec)
check('New alignment extension explicitly retains original comparison/default consumers', 'byte_diff_mask` and all existing consumers\nretain their equal-logical-offset behavior' in extension and 'Default fixed-offset rendering, Base64, evidence navigation restrictions and\nproject persistence remain unchanged' in extension)
check('Verified-reader specification narrows no old scope/format/error/interface contract', 'Every nonempty read re-reads and checks each touched block' in new_spec and 'less than 8 KiB of I/O' in new_spec and all(section in new_spec for section in ['## Interface', '### Formats', '## Error contract', '## Bounds', '## Not covered']))

classification = json.loads((ROOT / 'evidence/historical-integrity-next-review/classification.json').read_text())
item = next(b for b in classification['branches'] if b['head'] == HEAD)
check('Retained author path accounting matches independent full delta', set(item['changed_paths']) == EXPECTED and {r['path'] for r in item['paths']} == EXPECTED and item['missing_compatible_contributions'] == [])
check('Original census scope remains 181 unmatched and16 patch-equivalent', classification['original_census'] == {'unmatched_heads': 181, 'patch_equivalent_semantics_unreviewed_heads': 16, 'rewritten': False, 'scope_of_new_findings': 'Two named heads from the original 16; no reduction of the 181 unmatched-head census.'} and item['original_census_bucket'] == 'patch-equivalent-semantics-unreviewed (original 16)')
report = {
    'schema': 'patchtrace/independent-byte-representation-branch-subcheck/1',
    'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'reviewer': '/root/codex1_independent_review/byte_representation_check',
    'head': HEAD, 'head_tree': git('rev-parse', HEAD + '^{tree}').decode().strip(),
    'comparison_head': CURRENT, 'comparison_tree': TREE, 'merge_base': BASE,
    'classification': 'SUPERSEDED', 'whole_unique_branch_delta_accounted': True,
    'missing_compatible_contributions': [], 'blockers': [], 'checks_passed': len(checks), 'checks': checks,
    'paths': files, 'spec_changes': changes,
    'test_execution': 'None; parent owns test provenance review. Existing donor/current test evidence is not recounted here.',
    'source_ref_ci_pr_environment_mutations': False,
    'scope': 'This named head belongs to the original16 patch-equivalent semantics-unreviewed bucket. No reduction or rewrite of181 unmatched and no global historical closure.',
}
(OUT / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
(OUT / 'source-delta.patch').write_bytes(git('diff', HEAD, CURRENT, '--', *sorted(EXPECTED)))
print(json.dumps({k: report[k] for k in ['classification', 'whole_unique_branch_delta_accounted', 'missing_compatible_contributions', 'checks_passed', 'head', 'comparison_head']}, indent=2))
print('review_sha256', hashlib.sha256((OUT / 'review.json').read_bytes()).hexdigest())
