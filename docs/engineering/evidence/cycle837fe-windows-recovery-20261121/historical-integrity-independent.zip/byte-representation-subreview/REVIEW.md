# Byte representations: independent complete-branch subreview

**Verdict: SUPERSEDED; no missing compatible contribution or blocker found.**

Exact head `303bc452d0bb6cd46ee67f731f64ec951e1ee215` / tree `60a2ab753407986c95113d1ce92d1cc5b70c1ad1` has parent and merge base `0ec471016d2838a90753e014a0d647dd90168e87`. It contributes one unique branch-side commit and exactly eight added paths. Comparison source is `2ae1bbad2ad9cc78c29541872381750e347c670e` / tree `6001ef506c38930fd590bd827f428b997c3b2797`.

All **20 independent structural checks passed**. Five runtime modules are byte-identical. The initializer retains every original import and export in order, with five separately named opt-in alignment exports added. The entire original test file remains an exact byte prefix; only the past-end shorter-side regression is appended.

| Path | Donor blob | Current blob | Finding |
|---|---|---|---|
| `docs/specs/byte-representations.md` | `b782d78fde7dd0dda8dfd43171bd1e1075b6fb95` | `6d0d01c1e9fe679d34c9a5aaffdad762538d776c` | Compatible documented extensions |
| `src/patchtrace/representations/__init__.py` | `5b216f30f1020b6b98ba503420baba220965665e` | `885d7c29461831c4bb706773dfc7f608f34ebce5` | Imports/exports retained plus separate alignment API |
| `src/patchtrace/representations/compare.py` | `3aa057c0b240d47f696090489d8551f149d177ca` | `3aa057c0b240d47f696090489d8551f149d177ca` | Byte-identical |
| `src/patchtrace/representations/formatters.py` | `8932024f4e85bc9703c2ccae6dadc3a71a18f431` | `8932024f4e85bc9703c2ccae6dadc3a71a18f431` | Byte-identical |
| `src/patchtrace/representations/paging.py` | `6e89013edf9d07ab11dbc15e85f72fb7f08118bf` | `6e89013edf9d07ab11dbc15e85f72fb7f08118bf` | Byte-identical |
| `src/patchtrace/representations/render.py` | `9dc9198da5388f589f6f58bdb838786b697fb5cf` | `9dc9198da5388f589f6f58bdb838786b697fb5cf` | Byte-identical |
| `src/patchtrace/representations/scope.py` | `050d9c7e111b6edd31bdfd6c193e7ddcca544637` | `050d9c7e111b6edd31bdfd6c193e7ddcca544637` | Byte-identical |
| `tests/test_representations.py` | `2cd3a217c2765e18038585483c3ec722a2c0cdd1` | `e20ef141d9b5b2c354a85bf4603a658a9f476d48` | Original tests retained as exact prefix |

The current specification neutralizes exactly to the original after removing the named alignment/status addenda and reversing three explicit paragraph changes. Those changes describe touched-block reader verification, an opt-in alignment extension that preserves fixed-offset defaults, and the accurate physical I/O/memory costs of the stronger reader. Original scopes, formats, error propagation, caps, captions, copy attribution and public interfaces are retained.

This review covers this named head from the **original16 patch-equivalent, semantically unreviewed** bucket. It does not reduce or rewrite the **181 unmatched** census and does not declare global historical closure. No test was rerun; the parent reviewer owns the retained harness/test provenance assessment. No source/ref/PR/CI/environment changes occurred.

`review.json` contains all exact byte sizes, Git blobs, SHA-256 values and checks. `verify.py` reproduces the read-only checks; `source-delta.patch` preserves the complete donor-to-current differences for the eight paths.
