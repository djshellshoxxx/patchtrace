"""Read-only source/evidence verification; writes only this review directory."""
import ast
import copy
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/837fe19aae3a')
REPO = ROOT / 'PatchTrace-codex5-followup'
E = ROOT / 'evidence/historical-integrity-next-review'
OUT = ROOT / 'evidence/historical-integrity-independent'
CURRENT = '2ae1bbad2ad9cc78c29541872381750e347c670e'
TREE = '6001ef506c38930fd590bd827f428b997c3b2797'
checks = []


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(name):
    return json.loads((E / name).read_text())


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def blob(ref, path):
    return git('show', ref + ':' + path)


def check(name, condition, **details):
    checks.append({'name': name, 'passed': bool(condition), **details})
    if not condition:
        (OUT / 'verification-failure.json').write_text(json.dumps(checks, indent=2) + '\n')
        raise AssertionError(name)


def dump(node):
    return ast.dump(node, include_attributes=False)


classification = read('classification.json')
check('Exact comparison source and tree', classification['comparison_head'] == CURRENT
      and classification['comparison_tree'] == TREE
      and git('rev-parse', CURRENT + '^{tree}').decode().strip() == TREE)
old_inventory = read('prior-inputs/docs/engineering/branch-recovery-20261120-2bad.json')
counts = old_inventory['counts']['classifications']
check('Original census remains181 unmatched and16 patch-equivalent',
      counts['unmatched-patches-review-required'] == 181
      and counts['patch-equivalent-semantics-unreviewed'] == 16)
compact = json.loads(gzip.decompress((E / 'prior-inputs/docs/engineering/evidence/cycle837fe-20261121/references/technical-inventory.compact.json.gz').read_bytes()))
selected = read('selected-original-inventory-records.json')
check('Selected inventory records remain exact copies', all(row in compact['branches'] for row in selected))

for kind, head, base, count in [
    ('reader', '91b35d09afd29e9c78169a3b095d9ea3be6c31b1', 'f0086f797556afca5848c2b68a3819be5c0c0064', 4),
    ('representations', '303bc452d0bb6cd46ee67f731f64ec951e1ee215', '0ec471016d2838a90753e014a0d647dd90168e87', 8),
]:
    item = next(row for row in classification['branches'] if row['head'] == head)
    old = next(row for row in old_inventory['branches'] if row['head'] == head)
    paths = git('diff', '--name-only', base, head).decode().splitlines()
    check(kind + ': exact whole branch scope', len(paths) == count and set(paths) == set(item['changed_paths'])
          and set(paths) == {row['path'] for row in item['paths']})
    check(kind + ': sole unique commit and base', git('rev-list', CURRENT + '..' + head).decode().splitlines() == [head]
          and git('merge-base', CURRENT, head).decode().strip() == base)
    check(kind + ': original patch-equivalent classification', old['classification'] == 'patch-equivalent-semantics-unreviewed'
          and old['equivalent_nonmerge_commits'] == [head] and old['unmatched_nonmerge_commits'] == []
          and git('cherry', CURRENT, head).decode().splitlines() == ['- ' + head])
    check(kind + ': no deletion or global closure', item['classification'] == 'SUPERSEDED'
          and not item['delete_authorized'] and not old['delete_authorized']
          and item['missing_compatible_contributions'] == [])
    check(kind + ': complete branch patch preserved', (E / kind / 'branch.patch').read_bytes() == git('diff', base, head))
    check(kind + ': exact donor-to-current delta preserved', (E / kind / 'donor-to-current.patch').read_bytes()
          == git('diff', head, CURRENT, '--', *paths))

snapshots = read('snapshot-verification.json')
check('Exactly26 source snapshots', snapshots['verified_blob_count'] == len(snapshots['files']) == 26)
for row in snapshots['files']:
    raw = (E / row['path']).read_bytes()
    path = '/'.join(row['path'].split('/')[2:])
    check('Exact snapshot: ' + row['path'], raw == blob(row['source_commit'], path)
          and sha(raw) == row['sha256'] and len(raw) == row['bytes']
          and git('rev-parse', row['source_commit'] + ':' + path).decode().strip() == row['git_blob'])

donor_reader = (E / 'reader/donor/src/patchtrace/artifact_bytes.py').read_bytes()
current_reader = (E / 'reader/current/src/patchtrace/artifact_bytes.py').read_bytes()
old_ast, new_ast = ast.parse(donor_reader), ast.parse(current_reader)
old_class = next(n for n in old_ast.body if isinstance(n, ast.ClassDef) and n.name == 'VerifiedArtifactReader')
new_class = next(n for n in new_ast.body if isinstance(n, ast.ClassDef) and n.name == 'VerifiedArtifactReader')
old_methods = {n.name: n for n in old_class.body if isinstance(n, ast.FunctionDef)}
new_methods = {n.name: n for n in new_class.body if isinstance(n, ast.FunctionDef)}
check('Reader original methods retained', set(old_methods) <= set(new_methods))
for name in ['open_artifact', 'size', 'sha256', 'label', '__enter__', '__exit__']:
    check('Reader method AST retained: ' + name, dump(old_methods[name]) == dump(new_methods[name]))
for name in set(old_methods) - {'__init__'}:
    check('Reader documented signature retained: ' + name, dump(old_methods[name].args) == dump(new_methods[name].args))
check('Original reader module documentation retained', ast.get_docstring(old_ast) == ast.get_docstring(new_ast))
old_error = next(n for n in old_ast.body if isinstance(n, ast.ClassDef) and n.name == 'ArtifactBytesError')
new_error = next(n for n in new_ast.body if isinstance(n, ast.ClassDef) and n.name == 'ArtifactBytesError')
check('Stable reader error class retained', dump(old_error) == dump(new_error))
old_read, new_read = old_methods['read'].body, new_methods['read'].body
old_prefix = old_read[:next(i for i, n in enumerate(old_read) if isinstance(n, ast.With))]
new_prefix = new_read[:next(i for i, n in enumerate(new_read) if isinstance(n, ast.With))]
check('Type, bounds, EOF and cap validation retained', [dump(n) for n in old_prefix] == [dump(n) for n in new_prefix])
old_test = ast.parse((E / 'reader/donor/tests/test_artifact_bytes.py').read_bytes())
new_test = ast.parse((E / 'reader/current/tests/test_artifact_bytes.py').read_bytes())
new_funcs = {n.name: n for n in new_test.body if isinstance(n, ast.FunctionDef)}
for func in [n for n in old_test.body if isinstance(n, ast.FunctionDef)]:
    current_func = copy.deepcopy(new_funcs[func.name])
    if func.name == 'test_closed_reader':
        additions = [n for n in current_func.body if isinstance(n, ast.Assert) and '_block_digests' in ast.unparse(n)]
        check('Only added reader close test assertion is digest release', len(additions) == 1 and ast.unparse(additions[0]) == "assert reader._block_digests == b''")
        current_func.body.remove(additions[0])
    check('Original reader test/helper retained: ' + func.name, dump(func) == dump(current_func))
proof = read('structural-proof.json')
old_modules = (E / 'reader/donor/docs/modules.md').read_text()
new_modules = (E / 'reader/current/docs/modules.md').read_text()
base_modules = (E / 'reader/merge-base/docs/modules.md').read_text()
added_rows = [line for line in old_modules.splitlines() if line.startswith('|') and line not in base_modules.splitlines()]
check('Four module declarations retained verbatim', len(added_rows) == 4 and added_rows == proof['module_rows_added_by_donor_and_retained_verbatim']
      and all(row in new_modules.splitlines() for row in added_rows))
seam = (E / 'reader/donor/docs/specs/gui-preflight-inspection.md').read_text().split('## Alpha shared byte seam', 1)[1]
check('Full introduced byte seam specification retained', '## Alpha shared byte seam' + seam in (E / 'reader/current/docs/specs/gui-preflight-inspection.md').read_text())

for row in read('prior-input-manifest.json')['inputs']:
    raw = (E / row['path']).read_bytes()
    check('Prior input preserved: ' + row['path'], len(raw) == row['bytes'] and sha(raw) == row['sha256'])
summary = read('validation-summary.json')
carrier = summary['carrier_head']
check('Carrier source equals exact comparison source', not git('diff', '--name-only', carrier, CURRENT, '--', 'src', 'tools', 'tests', '.github/workflows').strip()
      and summary['source_directory_diff_exit_code'] == 0 and summary['carrier_status'] == '')
binding = read('source-binding.json')
check('Recorded isolated editable source binding', binding['isolated'] == 1 and binding['dont_write_bytecode']
      and binding['direct_url']['dir_info']['editable']
      and binding['direct_url']['url'] == 'file:///workspace/scratch/837fe19aae3a/repair-pages-config-hold')
for name, row in binding['modules'].items():
    path = row['path'].split('/repair-pages-config-hold/', 1)[1]
    check('Imported exact source: ' + name, sha(blob(CURRENT, path)) == row['sha256'])
test_results = {}
for prefix, expected in [('', {'maintained': (81, 0), 'original-donor': (70, 0)}),
                         ('initial-harness-temp-parent-error/', {'maintained': (41, 40), 'original-donor': (41, 29)})]:
    for label, (passes, errors) in expected.items():
        receipt = read(prefix + label + '.receipt.json')
        tree = ET.parse(E / (prefix + label + '.xml'))
        cases = tree.findall('.//testcase')
        counts = {'passed': 0, 'failed': 0, 'error': 0, 'skipped': 0}
        for case in cases:
            state = next((s for tag, s in [('failure', 'failed'), ('error', 'error'), ('skipped', 'skipped')] if case.find(tag) is not None), 'passed')
            counts[state] += 1
        check(prefix + label + ': exact JUnit outcomes', counts == receipt['counts'] == {'passed': passes, 'failed': 0, 'error': errors, 'skipped': 0}
              and receipt['exit_code'] == (1 if errors else 0))
        check(prefix + label + ': exact source-bound test files', all(sha(Path(row['path']).read_bytes()) == row['sha256'] for row in receipt['test_files'])
              and '-I' in receipt['command'] and '-B' in receipt['command'] and '--noconftest' in receipt['command'])
        if errors:
            check(prefix + label + ': fixture parent errors only', all('FileNotFoundError' in ET.tostring(e, encoding='unicode') and 'temporary-test-data' in ET.tostring(e, encoding='unicode') for e in tree.findall('.//error')))
        test_results[prefix + label] = counts
old_runner = (E / 'initial-harness-temp-parent-error/run_bounded_tests.py').read_text()
new_runner = (E / 'run_bounded_tests.py').read_text()
correction = '    (EVIDENCE / "temporary-test-data").mkdir(exist_ok=True)\n'
check('Harness repair only creates owned temporary parent', new_runner.replace(correction, '', 1) == old_runner and new_runner.count(correction) == 1)
check('Overlapping replays and no native claims', summary['counts_are_overlapping_replays_not_additive']
      and summary['no_install_native_run_or_full_suite'] and not classification['native_or_platform_acceptance_claimed'])

archive_receipt = read('archive-receipt.json')
archive_path = E / archive_receipt['archive_file']
check('Author archive exact bytes and digest', archive_path.stat().st_size == 910931 == archive_receipt['archive_bytes']
      and sha(archive_path.read_bytes()) == archive_receipt['archive_sha256'] == 'e571a7d348139fcfc651e3a80e69c1365db4418ab02ec05383751ca0b4e4668a')
manifest = read('evidence-manifest.json')
check('Author manifest exact digest', sha((E / 'evidence-manifest.json').read_bytes()) == archive_receipt['manifest_sha256'] == 'c85a0b922f356669a29828beb7cf22131dba8f5111ac234a18f86b1796388197')
with zipfile.ZipFile(archive_path) as z:
    check('Author archive complete and CRC-valid', z.testzip() is None and len(z.namelist()) == 93
          and len(manifest['files']) == 92 and set(z.namelist()) == {r['path'] for r in manifest['files']} | {'evidence-manifest.json'})
    for row in manifest['files']:
        raw = z.read(row['path'])
        check('Archive payload: ' + row['path'], sha(raw) == row['sha256'] and len(raw) == row['bytes'] and raw == (E / row['path']).read_bytes())
pack = E / 'preserved-git-objects/historical-integrity-introduced.pack'
check('Exact nonthin introduced-object pack', len(pack.read_bytes()) == 29517 and sha(pack.read_bytes()) == 'dbb1c7588043aeea208270456568191fca838aece3a2d0219f7665fff113b24c'
      and not read('preserved-git-objects/receipt.json')['thin'])
pack_verify = subprocess.run(['git', 'verify-pack', '-v', str(pack.with_suffix('.idx'))], capture_output=True)
(OUT / 'verify-pack.log').write_bytes(pack_verify.stdout + pack_verify.stderr)
packed = {line.split()[0] for line in pack_verify.stdout.decode().splitlines() if len(line.split()[0]) == 40}
expected_objects = set()
for head, base in [('91b35d09afd29e9c78169a3b095d9ea3be6c31b1', 'f0086f797556afca5848c2b68a3819be5c0c0064'),
                   ('303bc452d0bb6cd46ee67f731f64ec951e1ee215', '0ec471016d2838a90753e014a0d647dd90168e87')]:
    expected_objects.update(line.split()[0] for line in git('rev-list', '--objects', head, '--not', base).decode().splitlines())
check('All27 introduced Git objects independently verified', pack_verify.returncode == 0 and len(packed) == 27 and packed == expected_objects)

subreview_path = OUT / 'byte-representation-subreview/review.json'
subreview = json.loads(subreview_path.read_text())
check('Separate representation whole-branch review sealed', sha(subreview_path.read_bytes()) == 'fa034d6ed8232e7e889694b7919910d480343d4173f7bdb4f45d4920682d67b0'
      and subreview['checks_passed'] == 20 and subreview['blockers'] == []
      and subreview['whole_unique_branch_delta_accounted'] and all(c['passed'] for c in subreview['checks']))
report = {
    'schema': 'patchtrace/historical-integrity-independent/1',
    'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'comparison_head': CURRENT, 'comparison_tree': TREE,
    'verdict': 'CLEAR: both complete named branch deltas are SUPERSEDED',
    'branches': [{k: b[k] for k in ['branch', 'head', 'tree', 'merge_base', 'changed_paths', 'classification']} for b in classification['branches']],
    'blockers': [], 'missing_compatible_contributions': [],
    'checks_passed': len(checks), 'checks': checks,
    'representation_subreview': {'checks_passed': 20, 'path': 'byte-representation-subreview/review.json', 'sha256': sha(subreview_path.read_bytes())},
    'original_census': {'unmatched_heads': 181, 'patch_equivalent_semantics_unreviewed_heads': 16, 'rewritten': False,
                        'scope': 'Two named heads from original16. No181 decrement, global remaining count or deletion authorization.'},
    'test_provenance_verified': test_results,
    'reviewer_tests_executed': 0, 'test_counts_additive': False,
    'native_platform_qualification_claimed': False,
    'author_archive': archive_receipt,
    'pack_limits': 'Exact27 introduced objects, not full historical parent ancestry.',
    'mutations': 'Only own scratch evidence files; no source, ref, PR, CI, ledger or environment changes.',
}
(OUT / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ['verdict', 'checks_passed', 'reviewer_tests_executed', 'blockers']}, indent=2))
