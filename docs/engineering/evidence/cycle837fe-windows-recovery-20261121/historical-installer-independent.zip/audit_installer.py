"""Read-only independent accounting of a historical installer branch.

No product module is imported; no installer, package, smoke script or test is run.
All generated output remains in this review's scratch directory.
"""
from __future__ import annotations

import ast
import copy
import datetime
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

import yaml

ROOT = Path('/workspace/scratch/837fe19aae3a')
OUT = ROOT / 'evidence/historical-installer-independent'
AUTHOR = ROOT / 'evidence/historical-next-bounded-review'
REPO = ROOT / 'PatchTrace-codex5-followup'
HEAD = '9c5fe67bd10a5d1342440bb8ea6a524cca3ce1f2'
BASE = '04d57c72eced716b6c163d29f80b6cd5543c6582'
CURRENT = '2ae1bbad2ad9cc78c29541872381750e347c670e'
NEXT = '1c70cd5f8053f75c269da673a24a82f221180650'
PRIMARY = '9023761a4066ac1c50c127ac09d0ba5f56cdc9e4'
BRANCH = 'codex/windows-setup-installer-20261017'
checks = []


def check(name, condition):
    checks.append({'name': name, 'passed': bool(condition)})
    if not condition:
        (OUT / 'failed-checks.json').write_text(json.dumps(checks, indent=2) + '\n')
        raise AssertionError(name)


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args],
                                   env=dict(os.environ, GIT_OPTIONAL_LOCKS='0'))


def obj(commit, path):
    return git('show', f'{commit}:{path}')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def readj(path):
    return json.loads(path.read_bytes())


before = {'head': git('rev-parse', 'HEAD').decode().strip(),
          'status': git('status', '--porcelain=v1').decode()}
identity = readj(AUTHOR / 'identity.json')
classification = readj(AUTHOR / 'classification.json')
paths = git('diff', '--name-only', BASE, HEAD).decode().splitlines()
commits = git('rev-list', '--reverse', f'{BASE}..{HEAD}').decode().splitlines()
check('exact head tree', git('rev-parse', HEAD + '^{tree}').decode().strip() ==
      identity['head_tree'] == '338518965bdfb7d10eaa8c3ba8d1a65035cad897')
check('exact comparison tree', git('rev-parse', CURRENT + '^{tree}').decode().strip() ==
      identity['comparison_tree'] == '6001ef506c38930fd590bd827f428b997c3b2797')
check('exact merge base', git('merge-base', '--all', CURRENT, HEAD).decode().splitlines() == [BASE])
check('all unique commits also unique versus comparison', commits ==
      git('rev-list', '--reverse', f'{CURRENT}..{HEAD}').decode().splitlines())
check('32 exact authored commit identities', len(commits) == 32 and commits == identity['unique_commits'])
check('13 complete net paths', len(paths) == 13 and paths == identity['changed_paths'])
check('whole branch classification covers paths once', classification['whole_branch_scope'] is True and
      classification['classification'] == 'SUPERSEDED' and
      [r['path'] for r in classification['paths']] == paths)
history = readj(AUTHOR / 'unique-commit-path-accounting.json')
check('32 history rows exact and ordered', [r['sha'] for r in history['commits']] == commits)
unions = set()
merge_count = 0
empty = []
for row in history['commits']:
    parents = git('show', '-s', '--format=%P', row['sha']).decode().strip().split()
    check('parents ' + row['sha'], parents == row['parents'])
    check('subject ' + row['sha'], git('show', '-s', '--format=%s', row['sha']).decode().strip() == row['subject'])
    if len(parents) > 1:
        merge_count += 1
        check('merge delta is complete final delta', row['merge_against_final_merge_base_paths'] == paths)
    else:
        lines = git('diff-tree', '--no-commit-id', '--name-status', '-r', row['sha']).decode().splitlines()
        check('nonmerge path accounting ' + row['sha'], lines == row['changed_paths'])
        unions.update(line.split('\t')[-1] for line in lines)
        if not lines:
            empty.append(row['sha'])
check('31 nonmerge plus one merge', merge_count == 1)
check('empty historical commit preserved', empty == ['77e797c01015778394eba6e50563314a7d0b44a8'])
check('complete14-path union', sorted(unions) == history['nonmerge_path_union'] and len(unions) == 14)
check('only transient extra path is retired ISS', unions - set(paths) == {'installer/PatchTrace.iss'})
for commit in [HEAD, CURRENT, NEXT]:
    check('ISS absent at ' + commit, not git('ls-tree', commit, '--', 'installer/PatchTrace.iss').strip())
check('explicit Inno removal commit', 'D\tinstaller/PatchTrace.iss' in
      git('diff-tree', '--no-commit-id', '--name-status', '-r', '70ae6eb8ff8718cc8a149e0efb4cfa084b35f894').decode().splitlines())

snapshots = readj(AUTHOR / 'snapshot-verification.json')['files']
check('41 complete source snapshots', len(snapshots) == 41)
for row in snapshots:
    relative = row['path']
    source_path = relative.split('/', 2)[2] if relative.startswith('transient-source/') else relative.split('/', 1)[1]
    raw = (AUTHOR / relative).read_bytes()
    check('snapshot metadata ' + relative, len(raw) == row['bytes'] and digest(raw) == row['sha256'])
    check('snapshot Git blob ' + relative, git('rev-parse', row['source_commit'] + ':' + source_path).decode().strip() == row['git_blob'])
    check('snapshot immutable source ' + relative, raw == obj(row['source_commit'], source_path))
transient = [r for r in snapshots if r['path'].startswith('transient-source/')]
check('8 retired Inno snapshots same original blob', len(transient) == 8 and
      len({r['git_blob'] for r in transient}) == 1)

prior = readj(AUTHOR / 'prior-input-manifest.json')['files']
for row in prior:
    raw = (AUTHOR / row['path']).read_bytes()
    check('prior captured input ' + row['path'], len(raw) == row['bytes'] and digest(raw) == row['sha256'])
    if row['path'].startswith('prior-inputs/PatchTrace-codex5-followup/'):
        check('prior input exact comparison source ' + row['path'], raw ==
              obj(CURRENT, row['path'].split('prior-inputs/PatchTrace-codex5-followup/', 1)[1]))
census = readj(AUTHOR / 'prior-inputs/PatchTrace-codex5-followup/docs/engineering/branch-recovery-20261120-2bad.json')
check('original181 and16 counts preserved', census['counts']['classifications']['unmatched-patches-review-required'] == 181 and
      census['counts']['classifications']['patch-equivalent-semantics-unreviewed'] == 16)
census_row = next(r for r in census['branches'] if r['branch'] == BRANCH)
check('installer belongs to original181 bucket', census_row['head'] == HEAD and
      census_row['classification'] == 'unmatched-patches-review-required' and
      census_row['unmatched_nonmerge_commits'] == [c for c in commits if c != HEAD] and
      census_row['delete_authorized'] is False)
inventory = json.loads(gzip.decompress((AUTHOR / 'prior-inputs/PatchTrace-codex5-followup/docs/engineering/evidence/cycle837fe-20261121/references/technical-inventory.compact.json.gz').read_bytes()))
inventory_row = next(r for r in inventory['branches'] if r['branch'] == BRANCH)
check('technical census head/base match', inventory_row['head'] == HEAD and inventory_row['main']['merge_bases'] == [BASE])
check('historical PR95 metadata retained', any(r['number'] == 95 and r['state'] == 'closed' and r['merged_at']
      for r in inventory_row['pull_requests']))
ref = readj(AUTHOR / 'fresh-branch-ref.json')
fresh = json.loads(ref['result']['structuredContent']['content'])
check('retained fresh REST head', fresh['ref'] == 'refs/heads/' + BRANCH and fresh['object']['sha'] == HEAD and fresh['object']['type'] == 'commit')

comparison = readj(AUTHOR / 'source-comparison.json')
check('13 comparison rows complete', [r['path'] for r in comparison] == paths)
path_rows = []
for row in comparison:
    path = row['path']; old = obj(HEAD, path); current = obj(CURRENT, path)
    check('comparison hash/size ' + path, len(old) == row['donor_bytes'] and len(current) == row['current_bytes'] and
          digest(old) == row['donor_sha256'] and digest(current) == row['current_sha256'])
    check('comparison equality/prefix ' + path, (old == current) == row['byte_identical'] and
          current.startswith(old) == row['current_starts_with_donor'])
    path_rows.append({'path': path, 'donor_blob': git('rev-parse', HEAD + ':' + path).decode().strip(),
                      'current_blob': git('rev-parse', CURRENT + ':' + path).decode().strip(),
                      'donor_byte_identical': old == current,
                      'current_to_next_byte_identical': current == obj(NEXT, path),
                      'disposition': next(r['classification'] for r in classification['paths'] if r['path'] == path)})
check('only workflow of13 differs in later recovery source',
      [r['path'] for r in path_rows if not r['current_to_next_byte_identical']] == ['.github/workflows/qa-windows.yml'])
proof = readj(AUTHOR / 'structural-proof.json')
check('six identical paths accurate', [r['path'] for r in path_rows if r['donor_byte_identical']] == proof['byte_identical_paths'])
for path in ['tests/test_windows_installer_manifest.py', 'tools/package_windows_installer.py']:
    old_ast = ast.parse(obj(HEAD, path)); new_ast = ast.parse(obj(CURRENT, path))
    old_funcs = {n.name: n for n in old_ast.body if isinstance(n, ast.FunctionDef)}
    new_funcs = {n.name: n for n in new_ast.body if isinstance(n, ast.FunctionDef)}
    for name, func in old_funcs.items():
        same = ast.dump(func, include_attributes=False) == ast.dump(new_funcs[name], include_attributes=False)
        check('AST ' + path + ':' + name, proof['functions'][path][name] == {'present': True, 'ast_identical': same})
        if name != 'main':
            check('original function retained ' + name, same)
    if path.startswith('tools/'):
        old_main = old_funcs['main']
        at = next(i for i, stmt in enumerate(old_main.body) if isinstance(stmt, ast.Assign) and
                  any(isinstance(t, ast.Name) and t.id == 'checksum' for t in stmt.targets))
        old_main.body[at:at + 2] = ast.parse('write_checksum(installer)').body
        check('main only checksum call replacement', ast.dump(old_main, include_attributes=False) == ast.dump(new_funcs['main'], include_attributes=False))
        old_ast.body.insert(next(i for i, n in enumerate(old_ast.body) if isinstance(n, ast.FunctionDef) and n.name == 'sha256'),
                            new_funcs['write_checksum'])
        check('entire helper AST only LF writer extension', ast.dump(old_ast, include_attributes=False) == ast.dump(new_ast, include_attributes=False))
check('entire original tests exact prefix', obj(CURRENT, 'tests/test_windows_installer_manifest.py').startswith(obj(HEAD, 'tests/test_windows_installer_manifest.py')))
notice = 'third_party/notices/nsis-3.13/COPYING'
check('notice only trailing whitespace differs', [line.rstrip() for line in obj(HEAD, notice).splitlines()] ==
      [line.rstrip() for line in obj(CURRENT, notice).splitlines()])

workflows = {label: yaml.safe_load(obj(commit, '.github/workflows/qa-windows.yml')) for label, commit in [('base', BASE), ('donor', HEAD), ('current', CURRENT), ('next', NEXT)]}
names = proof['exact_retained_workflow_steps']
def named(wf, job, name):
    matches = [s for s in wf['jobs'][job]['steps'] if s.get('name') == name]
    check('unique workflow step ' + name, len(matches) == 1)
    return matches[0]
for name in names:
    donor_step = named(workflows['donor'], 'qa', name)
    check('retained donor step ' + name, donor_step == named(workflows['current'], 'qa', name) == named(workflows['next'], 'qa', name))
def artifact(wf):
    return next(s for s in wf['jobs']['qa']['steps'] if s.get('with', {}).get('name') == 'PatchTrace-windows-x64')
old_artifact = artifact(workflows['donor']); current_artifact = artifact(workflows['current'])
check('artifact path name and condition exact', old_artifact['with'] == current_artifact['with'] and old_artifact['if'] == current_artifact['if'])
check('artifact reviewed commit pin', current_artifact['uses'] == 'actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02')
alias_name = 'Verify Windows portable hash and add canonical Portable.zip release asset'
old_alias = named(workflows['donor'], 'release', alias_name)
new_alias = copy.deepcopy(named(workflows['current'], 'release', alias_name))
new_alias['run'] = new_alias['run'].replace('sha256sum -c PatchTrace-Windows-x64-Setup.exe.sha256\n', '')
check('alias only adds Setup checksum', new_alias == old_alias)
reverse = copy.deepcopy(workflows['donor'])
reverse['jobs']['qa']['steps'] = [s for s in reverse['jobs']['qa']['steps'] if s.get('name') not in names]
artifact(reverse)['with']['path'] = artifact(workflows['base'])['with']['path']
reverse['jobs']['release']['steps'] = [s for s in reverse['jobs']['release']['steps'] if s.get('name') != alias_name]
notes_old = 'Windows x64 desktop package. Extract the entire ZIP before launching PatchTrace.exe.'
notes_new = 'Windows x64 desktop package. Run the per-user Setup.exe installer or extract the portable ZIP before launching PatchTrace.exe.'
named(reverse, 'release', 'Generate release notes')['run'] = named(reverse, 'release', 'Generate release notes')['run'].replace(notes_new, notes_old)
check('all donor workflow behavior accounted exactly', reverse == workflows['base'])
check('installer description remains current', notes_new in named(workflows['current'], 'release', 'Generate release notes')['run'])
check('current release hold retained', '[no release]' in workflows['current']['jobs']['release']['if'])

doc_additions = {}
for path in ['docs/qa.md', 'tasks/todo.md']:
    diff = git('diff', '--unified=0', BASE, HEAD, '--', path).decode()
    added = [line[1:] for line in diff.splitlines() if line.startswith('+') and not line.startswith('+++') and line[1:].strip()]
    if path == 'docs/qa.md':
        added = [line for line in added if not line.startswith(('Warning: truncated output', 'Total output lines:')) and 'tokens truncated' not in line]
        check('five substantive donor QA additions', len(added) == 5)
        check('historical failed Windows run retained', any('39012939220 failed compiling' in line for line in added))
        check('historical pending Windows state retained', any('Not verified yet:' in line for line in added))
    current_text = obj(CURRENT, path).decode()
    check('all meaningful donor additions remain ' + path, all(line in current_text for line in added))
    doc_additions[path] = added
check('current release document retains NSIS/data-retention/asset behavior', all(x in obj(CURRENT, 'docs/release-process.md').decode()
      for x in ['NSIS 3.13', 'retaining user-created project files', 'Setup.exe', 'Portable.zip', 'tools/verify_release.py']))
check('stale Start Menu uninstaller finding exact', 'Start Menu uninstaller' in obj(CURRENT, 'docs/windows.md').decode() and
      len([line for line in obj(CURRENT, 'installer/PatchTrace.nsi').decode().splitlines() if 'CreateShortcut' in line]) == 1 and
      'CreateShortcut "$SMPROGRAMS\\PatchTrace\\PatchTrace.lnk"' in obj(CURRENT, 'installer/PatchTrace.nsi').decode())

binding = readj(AUTHOR / 'test-source-binding.json')
test_results = []
for label, count in [('original-on-donor', 4), ('original-on-current', 4), ('maintained-current', 5)]:
    receipt = readj(AUTHOR / (label + '.receipt.json'))
    b = binding[label]
    check('retained isolated exact binding ' + label, b == receipt['binding'] and b['isolated'] == 1 and
          b['dont_write_bytecode'] is True and b['packaging_main_called'] is False and
          digest(Path(b['test_file']).read_bytes()) == b['test_sha256'] and
          digest(Path(b['helper_file']).read_bytes()) == b['helper_sha256'])
    cases = list(ET.parse(AUTHOR / (label + '.xml')).getroot().iter('testcase'))
    check('retained XML result ' + label, len(cases) == count and all(not list(c) for c in cases))
    check('retained command count exit ' + label, receipt['exit_code'] == 0 and
          receipt['counts'] == {'passed': count, 'failed': 0, 'error': 0, 'skipped': 0} and
          receipt['command'][-1] == b['test_file'] and '--noconftest' in receipt['command'] and
          '--disable-plugin-autoload' in receipt['command'])
    check('retained names match XML ' + label, [c.attrib['name'] for c in cases] == [r['name'] for r in receipt['cases']])
    check('retained stdout confirms count ' + label, f'{count} passed' in (AUTHOR / (label + '.stdout.txt')).read_text())
    test_results.append({'label': label, 'passed': count, 'replayed_independently': False})
for path in ['tests/test_windows_installer_manifest.py', 'tools/package_windows_installer.py', 'installer/PatchTrace.nsi']:
    original = HEAD if path.startswith('tests/') else CURRENT
    check('unchanged original-on-current source ' + path, (AUTHOR / 'original-on-current-source' / path).read_bytes() == obj(original, path))
check('retained test counts explicitly overlap', readj(AUTHOR / 'test-summary.json')['counts_overlap'] is True)
primary_binding = readj(AUTHOR / 'primary-main-packaging-byte-binding.json')
for path in primary_binding['paths']:
    check('primary main byte binding ' + path, obj(PRIMARY, path) == obj(CURRENT, path))

pack_dir = AUTHOR / 'preserved-git-objects'
pack_receipt = readj(pack_dir / 'receipt.json')
pack = pack_dir / 'installer-original-introduced.pack'
check('preserved pack hash and bytes', digest(pack.read_bytes()) == pack_receipt['pack_sha256'] == '4057f7df8212c7d072321182c7cdac9c0be0afdc68753ce879e20070615d155e' and len(pack.read_bytes()) == 133892)
expected_objects = {line.split()[0] for line in git('rev-list', '--objects', HEAD, '^' + BASE).decode().splitlines()}
listed_objects = set((pack_dir / 'objects.txt').read_text().splitlines())
check('all135 introduced objects preserved', expected_objects == listed_objects and len(listed_objects) == 135)
pack_result = subprocess.run(['git', 'verify-pack', '-v', str(pack.with_suffix('.idx'))], capture_output=True, text=True)
(OUT / 'verify-pack.stdout.txt').write_text(pack_result.stdout)
(OUT / 'verify-pack.stderr.txt').write_text(pack_result.stderr)
actual_pack_objects = {line.split()[0] for line in pack_result.stdout.splitlines() if re.match(r'^[0-9a-f]{40} ', line)}
check('independent read-only pack verification', pack_result.returncode == 0 and actual_pack_objects == listed_objects)

archive_receipt = readj(AUTHOR / 'archive-receipt.json')
archive = AUTHOR / archive_receipt['archive_file']
check('author archive exact hash/size', digest(archive.read_bytes()) == archive_receipt['archive_sha256'] ==
      '000ce8ee3f67ebe9107867c71298930896bae93d5bce58aa2c9ca0eca2e46921' and archive.stat().st_size == 1556208)
manifest_bytes = (AUTHOR / 'evidence-manifest.json').read_bytes()
check('author manifest hash', digest(manifest_bytes) == archive_receipt['manifest_sha256'])
manifest = json.loads(manifest_bytes)
with zipfile.ZipFile(archive) as z:
    check('author111-member archive CRC', len(z.namelist()) == 111 and z.testzip() is None)
    check('author member names match complete manifest', set(z.namelist()) ==
          {r['path'] for r in manifest['files']} | {'evidence-manifest.json'})
    check('author archive manifest bytes match disk', z.read('evidence-manifest.json') == manifest_bytes)
    for row in manifest['files']:
        raw = z.read(row['path'])
        check('author archive member ' + row['path'], raw == (AUTHOR / row['path']).read_bytes() and
              len(raw) == row['bytes'] and digest(raw) == row['sha256'])
check('source worktree unchanged', before == {'head': git('rev-parse', 'HEAD').decode().strip(),
      'status': git('status', '--porcelain=v1').decode()})

result = {
    'schema': 'patchtrace/historical-installer-independent-source-proof/1',
    'reviewed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'branch': BRANCH, 'head': HEAD, 'head_tree': identity['head_tree'], 'merge_base': BASE,
    'comparison_head': CURRENT, 'comparison_tree': identity['comparison_tree'],
    'later_recovery_source': NEXT, 'source_worktree_before_after': before,
    'checks_passed': len(checks), 'checks': checks, 'paths': path_rows,
    'history': {'commits': commits, 'nonmerge': 31, 'merges': 1, 'empty_commits': empty,
                'path_union': sorted(unions), 'retired_path': 'installer/PatchTrace.iss',
                'retired_snapshots': 8, 'snapshots': 41, 'preserved_introduced_objects': 135},
    'original_census': {'unmatched': 181, 'patch_equivalent': 16, 'branch_bucket': census_row['classification'], 'snapshot_changed': False},
    'retained_test_results': test_results, 'counts_overlap': True, 'independent_product_tests_run': 0,
    'native_or_installer_execution': False, 'doc_additions': doc_additions,
    'author_archive': archive_receipt,
    'nonblocking_current_doc_findings': ['Undated Inno build paragraph already identified by author/root.',
       'Opening docs/windows.md paragraph promises a Start Menu uninstaller; NSIS creates only the application shortcut and HKCU Apps uninstall registration. Root notified.'],
    'boundaries': ['Whole named branch disposition only; original181/16 census unchanged.',
       'Retired Inno-only wizard/platform settings are retained as retired source, not asserted to be current NSIS settings.',
       'No new Windows/native/legal/release acceptance claim.',
       'No source, ref, PR, CI, ledger or environment mutation.'],
}
(OUT / 'source-proof.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['head', 'comparison_head', 'checks_passed', 'counts_overlap', 'independent_product_tests_run', 'native_or_installer_execution']}, indent=2))
