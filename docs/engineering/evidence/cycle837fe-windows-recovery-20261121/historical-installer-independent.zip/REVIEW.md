# Independent historical installer branch review

## Verdict

**CLEAR — SUPERSEDED** for the complete branch `codex/windows-setup-installer-20261017`. No missing compatible final-tip contribution was found. This is one named historical disposition; it does not reduce or rewrite the original **181 unmatched / 16 patch-equivalent** census, authorize deletion, or supply a new Windows/native/release acceptance result.

| Identity | Exact value |
| --- | --- |
| Donor head | `9c5fe67bd10a5d1342440bb8ea6a524cca3ce1f2` |
| Donor tree | `338518965bdfb7d10eaa8c3ba8d1a65035cad897` |
| Exact merge base | `04d57c72eced716b6c163d29f80b6cd5543c6582` |
| Author and independent comparison | `2ae1bbad2ad9cc78c29541872381750e347c670e` |
| Comparison tree | `6001ef506c38930fd590bd827f428b997c3b2797` |
| Separately checked recovery descendant | `1c70cd5f8053f75c269da673a24a82f221180650` |

The retained fresh REST snapshot names the exact donor head. Local Git objects independently establish the donor tree, merge base, ordered parents, all 32 unique commits and complete path sets. The original technical inventory also records PR95 as closed/merged; this does not turn the historical donor head into an ancestry claim.

## Complete path accounting

| Path | Independent finding |
| --- | --- |
| `.github/workflows/qa-windows.yml` | All four introduced build/smoke steps remain exactly, with the artifact name/paths/condition and canonical Portable alias logic. Current pins, Setup hash check and publication hold extend the donor. Reversing only the identified donor additions reconstructs the complete parsed merge-base workflow. |
| `docs/package-audit.md` | Exact donor bytes retained, including the dated Inno-to-NSIS progression and original pending qualification. Later clarification must preserve this history. |
| `docs/qa.md` | All five meaningful added PR95 follow-up lines remain, including the original failed NSIS relative-LICENSE run and pending Windows acceptance. The donor’s literal output-truncation corruption is preserved as evidence and correctly rejected as a restoration candidate. |
| `docs/release-process.md` | NSIS, user-data retention and installer assets remain. Current verification and publication holds supersede the old instructions; the duplicate Inno table row was removed. |
| `docs/windows.md` | Exact donor bytes retained. The undated Inno build paragraph and Start Menu uninstaller promise are stale current guidance, separately reported to root for its planned document correction. |
| `installer/PatchTrace.nsi` | Exact donor bytes: per-user execution, HKCU Apps registration, application shortcut, rooted build paths and generated explicit uninstall manifest. |
| `tasks/claude-progress.md` | Exact dated donor handoff retained, including queued CI, provenance and release limits. |
| `tasks/todo.md` | Every nonblank donor addition remains in the historical checkpoints. Original pending states are not rewritten by this disposition. |
| `tests/test_windows_installer_manifest.py` | Entire original module is an exact prefix; all four original functions are AST-identical. Current source adds the LF-only checksum regression. |
| `third_party/notices/nsis-3.13/COPYING` | Only trailing whitespace differs. No licensing acceptance is inferred. |
| `tools/package_windows_installer.py` | Compiler discovery, streaming digest and explicit uninstall-manifest functions are AST-identical. Whole-module AST matches after the single checksum writer extension; version/preflight/compiler/output checks remain. |
| `tools/test_windows_installer.ps1` | Exact donor bytes. Installer, registration, shortcut, runtime and inside/outside data-retention checks were inspected; no PowerShell or package was executed. |
| `tools/test_windows_portable.ps1` | Exact donor bytes. Sidecar, clean Unicode/spaces extraction, notice/runtime and isolated frozen startup/CLI definitions were inspected only. |

The source comparison above binds to exact 2ae, as the author report states. Twelve of the 13 paths remain byte-identical through 1c70. The only later difference is the previously reviewed QA workflow recovery (concurrency/required upload and fresh downloaded-package validation), which does not remove the historical installer contribution. The seven packaging/workflow/test/notice paths in the author’s primary-main binding were also independently byte-compared against 9023761; that is source equality, not a new execution result.

## History, preserved exceptions and tests

All **31 nonmerge commits and one merge** are accounted for, including the empty 77e797c commit. Their union contains 14 paths: the 13 final changed paths plus `installer/PatchTrace.iss`. The latter was introduced by 104bbc90 and explicitly removed by 70ae6eb8 during the donor’s own NSIS migration. Eight retained snapshots bind the retired script to its original Git blob. Its Inno-only wizard/platform settings are not claimed to be current NSIS behavior; the original source remains available rather than being restored from an intermediate version.

The original `docs/qa.md` deletion replaced 744 old lines with tool-output truncation text. The full original/base/current blobs and branch patch remain in the author archive. The five substantive new follow-up lines are retained, including Windows run 39012939220’s relative-LICENSE failure and the original statement that NSIS/Windows lifecycle acceptance was still pending. Historical failures and pending states remain historical.

The exact original test module was used with both original and current helper/NSIS snapshots. Its `runpy` helper binding is source-local and does not run the packaging `main` entry point. The receipts preserve isolated Python arguments, disabled external pytest configuration/plugins, exact test/helper hashes, JUnit names and process exit codes.

| Retained selection | Result | Scope |
| --- | --- | --- |
| Original donor test bytes on donor helper/NSIS | 4 passed | Pure authored temporary-file manifest generation and static source assertions |
| Same original test bytes on exact 2ae helper/NSIS | 4 passed | Same original assertions against current implementation |
| Current maintained module on exact 2ae snapshots | 5 passed | The four original cases plus LF checksum regression |

These selections overlap. They are not 13 distinct coverage cases. Every retained result is exit 0 with no failures/errors/skips. No rerun was needed to resolve the bounded review, so the independent reviewer ran **zero product tests**, invoked no NSIS/PowerShell/package/native target and installed or rebound no environment.

## Current-document correction

The undated Inno build paragraph was already identified by the author/root. This independent review additionally found that the opening Windows guide promises a “Start Menu uninstaller,” while the exact NSIS source creates only the application shortcut. Uninstall is registered in Windows Apps and written as `Uninstall.exe` in the installation directory. Root was notified for the planned current-document reconciliation. This wording issue does not establish an unmerged implementation contribution or block the historical SUPERSEDED disposition. Dated package-audit/todo/handoff history remains untouched.

## Integrity and limits

**499 source/history/evidence checks passed.** This count is mechanical independent verification, not product tests. It includes all 41 source snapshots against Git blobs, all 20 prior-input hashes, full branch history/path accounting, original 181 bucket membership, helper/test AST and whole donor-workflow reconstruction, exact test receipts, all 135 introduced Git objects and the complete author archive.

The author archive has 111 members and 1,556,208 bytes, SHA256 `000ce8ee3f67ebe9107867c71298930896bae93d5bce58aa2c9ca0eca2e46921`. Its 110 payload hashes, manifest and all ZIP CRCs were independently verified against disk. The non-thin introduced-object pack has 135 objects, 133,892 bytes and SHA256 `4057f7df8212c7d072321182c7cdac9c0be0afdc68753ce879e20070615d155e`; independent read-only `git verify-pack` succeeded. That pack is incremental relative to the recorded merge base, not a complete repository clone.

`source-proof.json` provides named checks and exact path identities. `audit_installer.py` is a reproducible read-only verifier that imports no product module and runs no product tests. The sealed review includes the unchanged author archive, so the historical sources, original test results and exceptions remain portable. No source/ref/PR/CI/ledger changes were made. Native, manual GUI/accessibility, signing/trust, external runtime/provenance, upgrade and release gates remain separate.
