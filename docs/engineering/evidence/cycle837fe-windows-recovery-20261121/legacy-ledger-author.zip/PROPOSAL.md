# Legacy ledger reconciliation proposal

**Proposal only. No ledger or repository file was changed.** Exactly three frozen 2ae task rows and seven current fields are proposed for replacement. Full before objects and guarded JSON Patch data are retained.

## Source and evidence boundary

- Frozen ledger: `2ae1bbad2ad9cc78c29541872381750e347c670e`, tree `6001ef506c38930fd590bd827f428b997c3b2797`; 104 existing task IDs/order preserved.
- Qualified primary source: `ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e`, tree `c3f09435deb99ca0ddb3406e27ab315dba7740cf`.
- Actual main promotion: `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4`, parents `fdc2696c23bdbfe7668348f25e3b336ce33039f7` + exact ae69, same tree c3; actual local commit and both publication-hold markers verified against retained root context.
- Primary evidence archive SHA-256: `8eb127426bcf216b840bc10d5243fccdb8964d4ba17bf53b6282920406b57859`. All 159 ZIP members/CRCs and 158 manifest payload digests were reread and verified.
- No new tests or CI observations were performed. Assertions below describe existing source and sealed receipts, not a newly qualified run.

The primary qualification is explicitly `qualified_with_documented_open_gates`. It belongs to the premerge PR349 tree, then promoted without a tree change. This proposal does not convert later CODEX5/Pages/concurrency changes or pending PR351 checks into primary qualification.

## Exact recommended field replacements

### `registered-header-help` — `status`

**Before**

```text
strings-eight-columns-complete-other-panels-open
```

**Proposed after**

```text
strings-search-buildenv-scopes-MERGED-other-panels-native-accessibility-open
```

Current qualified scope is eight Strings, six Search and five Buildenv mappings. This is not a complete application-header census or native accessibility acceptance.

**Proof IDs:** `promotion`, `qualified_source`, `hosted_cases`, `strings`, `search`, `buildenv`.

### `registered-header-help` — `result_or_next_action`

**Before**

```text
All eight Strings headers use registered escaped help before/after results; global real-host audit fails when a mapping is removed.90 direct construction sites, 8 explicit IDs; other panels and native screen-reader acceptance remain open.
```

**Proposed after**

```text
Eight Strings, six Search and five Build environment header mappings are present in qualified source ae69f1e6 (tree c3f09435) and merged through main commit 9023761a. Existing labels/cells/copy and real-host positive/missing-mapping controls are retained. These are three bounded table scopes; other panels and native screen-reader/accessibility acceptance remain open. The earlier 90-site/8-ID observation is retained as historical inventory, not a current application-wide coverage total.
```

Updates the aggregate row without claiming that every header has registered help, and stops presenting the earlier construction-site/ID count as a current total.

**Proof IDs:** `promotion`, `qualified_source`, `hosted_cases`, `strings`, `search`, `buildenv`.

### `registered-header-help` — `parallel_scope_837fe.qualification`

**Before**

```text
exact-source hosted pending
```

**Proposed after**

```text
Search source is included in qualified ae69f1e6 (tree c3f09435) and merged through main commit 9023761a; exact-tree Linux/Windows QA and Qt gates passed. Native screen-reader/accessibility acceptance remains open.
```

Replaces the explicit Search exact-source-hosted-pending value while preserving its original code checkpoint, completed scope and remaining gates.

**Proof IDs:** `promotion`, `qualified_source`, `hosted_cases`, `search`, `primary`.

### `historical-audit-gates-cycle2` — `status`

**Before**

```text
CODEX1-5-open-CODEX6-14-reviewed-local-source-hosted-pending
```

**Proposed after**

```text
CODEX1-6-14-source-MERGED-CODEX5-and-Ghidra-archive-acceptance-open
```

The archived CODEX1/6/14 contracts pass on both OSes; direct pins/source repairs are promoted. CODEX5 remains strict xfail and actual Ghidra archive provisioning was skipped.

**Proof IDs:** `promotion`, `hosted_cases`, `direct_pins`, `cache`, `frozen_linux`.

### `historical-audit-gates-cycle2` — `result_or_next_action`

**Before**

```text
CODEX1 mutable Action tags and CODEX5 unhashed package installs remain strict expected failures. CODEX6 and CODEX14 have separate reviewed source repairs and passing actual-source tests, now combined; their hosted acceptance remains open. Previous audit findings/failed source receipts stay historical.
```

**Proposed after**

```text
CODEX-1 direct Action pins and CODEX-6/14 source repairs are present in ae69f1e6 (tree c3f09435) and merged through main commit 9023761a. CODEX-14's extracted Linux artifact passed 64 checks with zero failures on each Ubuntu 22.04/24.04 smoke job. CODEX-6 verified both rizin archive-cache hits; Ghidra archive provisioning was skipped, so that gate remains open and separate Ghidriff raw-cache success does not close it. Broad CODEX-5 hash closure remains open with its strict expected failure. Preserve original audit/failure receipts and all wider native/manual/accessibility gates.
```

Removes the false current CODEX1 xfail and CODEX14 hosted-pending claims. Keeps source completion distinct from archive-specific Ghidra acceptance and broader open gates.

**Proof IDs:** `promotion`, `hosted_cases`, `direct_pins`, `cache`, `frozen_linux`, `primary`.

### `buildenv-header-help-20261121-95fe` — `status`

**Before**

```text
implemented-independently-reviewed-local-qualified
```

**Proposed after**

```text
MERGED
```

The local 8c5e77e2 content maps to ancestral remote commit 2162708d with the same tree; its two production files and maintained header test are byte-identical in qualified ae69 and promoted main 902. Fifteen Buildenv cases passed in each archived full OS suite.

**Proof IDs:** `promotion`, `qualified_source`, `hosted_cases`, `buildenv`.

### `buildenv-header-help-20261121-95fe` — `result_or_next_action`

**Before**

```text
All five actual headers registered; original labels/cells/copy and production ASTs preserved. Real-host audit detects a removed Basis mapping. Included in 391-pass final selection; exact combined hosted/native acceptance remains separate.
```

**Proposed after**

```text
All five Build environment headers are registered; original labels/cells/copy and production ASTs are preserved. The retained real-host control detects a removed Basis mapping. The 391-pass C4 selection remains historical and overlaps later qualification. This bounded source is included in ae69f1e6 (tree c3f09435), passed exact-tree Linux/Windows QA and repeated Qt gates, and was merged through main commit 9023761a. Native screen-reader, high-contrast/DPI and broader manual acceptance remain separate.
```

Replaces only obsolete combined-hosted-pending wording; preserves local-result history and native/manual limits.

**Proof IDs:** `promotion`, `qualified_source`, `hosted_cases`, `buildenv`, `primary`.

## Proof and limits

| Proof | Existing evidence |
| --- | --- |
| Buildenv source inclusion | Original local commit 8c5e77e2 and mapped remote commit 2162708d have the same tree; mapped remote is an ae69 ancestor. Two production files and the maintained header test are byte-identical across local source, ae69, main 902 and frozen 2ae. |
| Search source inclusion | Original commit 0069d0d2 controller, tooltip registration/data and maintained header test are byte-identical to qualified ae69/main 902/frozen 2ae. The independent correction receipt preserves the original failed semantic control and closed S-H1. |
| Current bounded header coverage | Archived Linux and Windows JUnit each records 15 Buildenv cases, 4 Search cases, 17 Strings header cases and 1 global registry audit passing. These observations support 5/6/8 mappings only, not an application-wide coverage claim. |
| CODEX1/6/14 source assertions | Each named maintained gate is an ordinary pass in both archived OS suites. CODEX5 is a strict expected failure on both. The primary source contract and unchanged frozen 2ae test/workflow blobs are preserved. |
| CODEX14 hosted acceptance | Exact primary Linux package succeeded; Ubuntu 22.04 and 24.04 extracted-artifact jobs each recorded 64 CLI checks passed, 0 failed, with checksum and offscreen/XCB self-tests. |
| CODEX6 partial native boundary | Tier R 44881741002 verified both rizin archive-cache hits. Both Ghidra provisioning sets were skipped. Ghidriff raw-result cache success is a different layer and cannot qualify Ghidra archive provisioning. |
| Historical local evidence | C4 391-pass selection and original Strings/Search author/reviewer records remain source-specific; none is summed with archived full-suite or repeated Qt counts. Original baseline/control failures remain in their archives. |

Sixteen relevant source files are bound by exact Git blobs and SHA-256 values in `qualified-source-binding.json`. The current Strings scope is established directly from qualified ae69 source and its passing archived cases; this proposal makes no unsupported ancestry claim for the older source_commit field. Original source_commit, owner, evidence and unrelated nested fields are unchanged.

The old 90-construction-site/8-ID statement remains in the full before object as a historical census. No replacement application-wide header census was performed, and no claim is made that all headers are registered. Native screen readers, high-contrast/DPI, other panels, broad CODEX5 dependency/hash closure and wider native/manual/accessibility gates stay open.

## Review and application boundary

`before-rows.json` preserves all three full original objects. `proposed-rows.json` carries deep-copied before/after objects. `proposed-fields.json` provides the seven field-level replacements and their proof catalog. `guarded-proposal.jsonpatch` contains three complete-row precondition tests followed by seven replacements; it was not executed.

Root owns any later application in the separately reviewed final records checkout. Retain full before objects as historical checkpoints before changing current fields. If any guarded row has changed, reconcile that change instead of applying stale replacements. Every other task ID/order, all histories, top-level publication/release eligibility fields and pending follow-up records remain outside this proposal.

No installs, source/ledger/ref/PR/CI mutations, native execution or new pytest invocation occurred.

**`promotion`:** promotion-proof.json; primary/primary-promotion-context.json; primary/actual-main-merge-commit.txt

**`qualified_source`:** qualified-source-binding.json

**`hosted_cases`:** archived-relevant-junit-cases.json (read-only extraction from hash-verified primary archive)

**`primary`:** primary/final-qualification.json

**`buildenv`:** retained/docs/engineering/evidence/cycle4-95fe/qualification.json; retained/docs/engineering/evidence/cycle4-95fe/buildenv-spec-review.md; retained/docs/engineering/evidence/cycle4-95fe/buildenv-standards-review.md; retained/docs/engineering/evidence/cycle4-95fe/code-publication-mapping.json

**`search`:** retained/docs/engineering/cycle837fe-recovery-and-search-20261121.md; retained/search-independent/review-addendum.json

**`strings`:** retained/docs/engineering/cycle2-strings-header-help-20261121-2bad.md

**`direct_pins`:** retained/docs/engineering/codex1-direct-action-pins-20261121.md

**`cache`:** primary/tier-r-cache-evidence.json; retained/docs/engineering/codex6-corpus-cache-archive-20261121.md

**`frozen_linux`:** primary/linux-smoke-136798676256-receipt.json; primary/linux-smoke-136798676259-receipt.json; primary/linux-package-receipt.json
