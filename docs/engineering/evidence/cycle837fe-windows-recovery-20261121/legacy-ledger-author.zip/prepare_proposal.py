"""Prepare guarded JSON data only; never apply changes to a repository ledger."""
from __future__ import annotations

import copy
import hashlib
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent


def main() -> None:
    before_bytes = (ROOT / "frozen2ae-task-ledger.json").read_bytes()
    ledger = json.loads(before_bytes)
    originals = json.loads((ROOT / "before-rows.json").read_text())
    by_id = {item["row"]["id"]: item for item in originals}
    evidence = {
        "promotion": "promotion-proof.json; primary/primary-promotion-context.json; primary/actual-main-merge-commit.txt",
        "qualified_source": "qualified-source-binding.json",
        "hosted_cases": "archived-relevant-junit-cases.json (read-only extraction from hash-verified primary archive)",
        "primary": "primary/final-qualification.json",
        "buildenv": "retained/docs/engineering/evidence/cycle4-95fe/qualification.json; retained/docs/engineering/evidence/cycle4-95fe/buildenv-spec-review.md; retained/docs/engineering/evidence/cycle4-95fe/buildenv-standards-review.md; retained/docs/engineering/evidence/cycle4-95fe/code-publication-mapping.json",
        "search": "retained/docs/engineering/cycle837fe-recovery-and-search-20261121.md; retained/search-independent/review-addendum.json",
        "strings": "retained/docs/engineering/cycle2-strings-header-help-20261121-2bad.md",
        "direct_pins": "retained/docs/engineering/codex1-direct-action-pins-20261121.md",
        "cache": "primary/tier-r-cache-evidence.json; retained/docs/engineering/codex6-corpus-cache-archive-20261121.md",
        "frozen_linux": "primary/linux-smoke-136798676256-receipt.json; primary/linux-smoke-136798676259-receipt.json; primary/linux-package-receipt.json",
    }
    updates = {
        "buildenv-header-help-20261121-95fe": [
            ("status", "MERGED", ["promotion", "qualified_source", "hosted_cases", "buildenv"],
             "The local 8c5e77e2 content maps to ancestral remote commit 2162708d with the same tree; its two production files and maintained header test are byte-identical in qualified ae69 and promoted main902. Fifteen Buildenv cases passed in each archived full OS suite."),
            ("result_or_next_action",
             "All five Build environment headers are registered; original labels/cells/copy and production ASTs are preserved. The retained real-host control detects a removed Basis mapping. The 391-pass C4 selection remains historical and overlaps later qualification. This bounded source is included in ae69f1e6 (tree c3f09435), passed exact-tree Linux/Windows QA and repeated Qt gates, and was merged through main commit 9023761a. Native screen-reader, high-contrast/DPI and broader manual acceptance remain separate.",
             ["promotion", "qualified_source", "hosted_cases", "buildenv", "primary"],
             "Replaces only obsolete combined-hosted-pending wording; preserves local-result history and native/manual limits."),
        ],
        "historical-audit-gates-cycle2": [
            ("status", "CODEX1-6-14-source-MERGED-CODEX5-and-Ghidra-archive-acceptance-open",
             ["promotion", "hosted_cases", "direct_pins", "cache", "frozen_linux"],
             "The archived CODEX1/6/14 contracts pass on both OSes; direct pins/source repairs are promoted. CODEX5 remains strict xfail and actual Ghidra archive provisioning was skipped."),
            ("result_or_next_action",
             "CODEX-1 direct Action pins and CODEX-6/14 source repairs are present in ae69f1e6 (tree c3f09435) and merged through main commit 9023761a. CODEX-14's extracted Linux artifact passed 64 checks with zero failures on each Ubuntu 22.04/24.04 smoke job. CODEX-6 verified both rizin archive-cache hits; Ghidra archive provisioning was skipped, so that gate remains open and separate Ghidriff raw-cache success does not close it. Broad CODEX-5 hash closure remains open with its strict expected failure. Preserve original audit/failure receipts and all wider native/manual/accessibility gates.",
             ["promotion", "hosted_cases", "direct_pins", "cache", "frozen_linux", "primary"],
             "Removes the false current CODEX1 xfail and CODEX14 hosted-pending claims. Keeps source completion distinct from archive-specific Ghidra acceptance and broader open gates."),
        ],
        "registered-header-help": [
            ("status", "strings-search-buildenv-scopes-MERGED-other-panels-native-accessibility-open",
             ["promotion", "qualified_source", "hosted_cases", "strings", "search", "buildenv"],
             "Current qualified scope is eight Strings, six Search and five Buildenv mappings. This is not a complete application-header census or native accessibility acceptance."),
            ("result_or_next_action",
             "Eight Strings, six Search and five Build environment header mappings are present in qualified source ae69f1e6 (tree c3f09435) and merged through main commit 9023761a. Existing labels/cells/copy and real-host positive/missing-mapping controls are retained. These are three bounded table scopes; other panels and native screen-reader/accessibility acceptance remain open. The earlier 90-site/8-ID observation is retained as historical inventory, not a current application-wide coverage total.",
             ["promotion", "qualified_source", "hosted_cases", "strings", "search", "buildenv"],
             "Updates the aggregate row without claiming that every header has registered help, and stops presenting the earlier construction-site/ID count as a current total."),
            ("parallel_scope_837fe.qualification",
             "Search source is included in qualified ae69f1e6 (tree c3f09435) and merged through main commit 9023761a; exact-tree Linux/Windows QA and Qt gates passed. Native screen-reader/accessibility acceptance remains open.",
             ["promotion", "qualified_source", "hosted_cases", "search", "primary"],
             "Replaces the explicit Search exact-source-hosted-pending value while preserving its original code checkpoint, completed scope and remaining gates."),
        ],
    }
    changes = []
    after_rows = []
    guards = []
    replacements = []
    for original in originals:
        index = original["index"]
        before = original["row"]
        task_id = before["id"]
        assert ledger["tasks"][index] == before
        after = copy.deepcopy(before)
        guards.append({"op": "test", "path": f"/tasks/{index}", "value": copy.deepcopy(before)})
        for field, value, proofs, reason in updates[task_id]:
            keys = field.split(".")
            target = after
            for key in keys[:-1]:
                target = target[key]
            old_value = copy.deepcopy(target[keys[-1]])
            target[keys[-1]] = value
            pointer = f"/tasks/{index}/" + "/".join(keys)
            changes.append({"task_id": task_id, "field": field, "json_pointer": pointer,
                            "before": old_value, "after": value, "reason": reason,
                            "proof_ids": proofs})
            replacements.append({"op": "replace", "path": pointer, "value": value})
        for key in ("id", "owner", "source_commit", "evidence"):
            assert after[key] == before[key]
        if task_id == "registered-header-help":
            for key in ("completed", "code_checkpoint", "remaining"):
                assert after["parallel_scope_837fe"][key] == before["parallel_scope_837fe"][key]
        after_rows.append({"index": index, "before": copy.deepcopy(before), "proposed_after": after})
    assert len(changes) == 7 and len(after_rows) == 3
    assert (ROOT / "frozen2ae-task-ledger.json").read_bytes() == before_bytes
    proposal = {
        "schema": "patchtrace/legacy-ledger-reconciliation-proposal/1",
        "state": "PROPOSAL_ONLY_NOT_APPLIED", "permission_to_apply": False,
        "base_ledger_head": "2ae1bbad2ad9cc78c29541872381750e347c670e",
        "base_ledger_tree": "6001ef506c38930fd590bd827f428b997c3b2797",
        "base_ledger_sha256": hashlib.sha256(before_bytes).hexdigest(),
        "base_task_count": len(ledger["tasks"]),
        "qualified_source_head": "ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e",
        "qualified_source_tree": "c3f09435deb99ca0ddb3406e27ab315dba7740cf",
        "actual_main_merge": "9023761a4066ac1c50c127ac09d0ba5f56cdc9e4",
        "changes": changes, "proof_catalog": evidence,
        "preserve": ["Every task ID and original order", "All unrelated rows and fields", "All original source_commit/evidence/owner values",
                     "Full before objects and their source-specific history", "Broad CODEX5 and Ghidra archive-cache acceptance gates",
                     "Other header scopes and native/manual/accessibility limits", "Top-level publication/release eligibility fields"],
        "application_boundary": "Root owns any separately reviewed application. First retain the full before objects as historical checkpoints; reject if any guarded before row changed. These updates do not qualify the later CODEX5/Pages/concurrency follow-up source or PR351.",
        "new_tests_executed": 0,
    }
    (ROOT / "proposed-fields.json").write_text(json.dumps(proposal, indent=2) + "\n")
    (ROOT / "proposed-rows.json").write_text(json.dumps(after_rows, indent=2) + "\n")
    (ROOT / "guarded-proposal.jsonpatch").write_text(json.dumps(guards + replacements, indent=2) + "\n")
    print(json.dumps({"proposal_only": True, "changed_rows": len(after_rows), "field_replacements": len(changes),
                      "complete_before_guards": len(guards), "original_task_count_preserved": len(ledger["tasks"]),
                      "new_tests_executed": 0}))


if __name__ == "__main__":
    main()
