"""Read sealed source/receipts for a proposal; do not execute tests or edit a ledger."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile


ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parents[1]
REPO = WORKSPACE / "PatchTrace-codex5-followup"
BASE = "2ae1bbad2ad9cc78c29541872381750e347c670e"
SOURCE = "ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e"
TREE = "c3f09435deb99ca0ddb3406e27ab315dba7740cf"
MAIN = "9023761a4066ac1c50c127ac09d0ba5f56cdc9e4"
PARENT = "fdc2696c23bdbfe7668348f25e3b336ce33039f7"


def git(*args: str) -> bytes:
    return subprocess.check_output(["git", "-C", str(REPO), *args])


def save(name: str, data: object) -> None:
    destination = ROOT / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(data, indent=2) + "\n")


def main() -> None:
    original = WORKSPACE / "evidence/final-ae69-qualification"
    receipt = json.loads((original / "archive-receipt.json").read_text())
    archive_path = original / "final-ae69-evidence.zip"
    archive_data = archive_path.read_bytes()
    assert hashlib.sha256(archive_data).hexdigest() == receipt["archive_sha256"] == "8eb127426bcf216b840bc10d5243fccdb8964d4ba17bf53b6282920406b57859"
    assert len(archive_data) == receipt["archive_bytes"]
    copied = ROOT / "primary"
    copied.mkdir(exist_ok=True)
    for name in ("final-ae69-evidence.zip", "archive-receipt.json", "evidence-manifest.json", "final-qualification.json"):
        shutil.copyfile(original / name, copied / name)
    with zipfile.ZipFile(archive_path) as archive:
        assert archive.testzip() is None
        manifest_data = archive.read("evidence-manifest.json")
        assert hashlib.sha256(manifest_data).hexdigest() == receipt["manifest_sha256"]
        manifest = json.loads(manifest_data)
        assert len(manifest["files"]) == receipt["payload_file_count"] == 158
        assert len(archive.namelist()) == receipt["archive_member_count"] == 159
        for entry in manifest["files"]:
            data = archive.read(entry["path"])
            assert len(data) == entry["bytes"] and hashlib.sha256(data).hexdigest() == entry["sha256"]
        qualification = json.loads(archive.read("final-qualification.json"))
        assert qualification["source"]["head_sha"] == SOURCE
        assert qualification["source"]["head_tree_sha"] == TREE
        assert qualification["verdict"]["source_consistent"] is True
        assert qualification["verdict"]["all_required_qa_jobs_successful"] is True
        assert qualification["verdict"]["qualification_status"] == "qualified_with_documented_open_gates"
        case_records = {}
        for platform, member in (("Linux", "artifacts/14699678427/qa-results.xml"),
                                 ("Windows", "artifacts/14701205328/qa-results.xml")):
            data = archive.read(member)
            selected = []
            for case in ET.fromstring(data).iter("testcase"):
                cls, name = case.get("classname", ""), case.get("name", "")
                matches = cls in ("tests.test_buildenv_header_help", "tests.test_search_header_help")
                matches |= cls == "tests.test_ui_strings_panel" and ("header" in name or "column_help" in name)
                matches |= cls == "tests.test_tooltips" and name == "test_every_registry_id_is_applied_somewhere"
                matches |= name in ("test_remote_actions_are_immutable", "test_corpus_cache_does_not_skip_verification",
                                    "test_linux_package_runs_full_cli_smoke", "test_pip_downloads_require_hashes")
                if matches:
                    skipped = case.find("skipped")
                    status = "failed" if case.find("failure") is not None else (
                        "error" if case.find("error") is not None else (
                            "xfailed" if skipped is not None and skipped.get("type") == "pytest.xfail" else (
                                "skipped" if skipped is not None else "passed")))
                    selected.append({"class": cls, "name": name, "status": status,
                                     "skip_attributes": skipped.attrib if skipped is not None else None})
            assert len(selected) == 41
            assert sum(case["status"] == "passed" for case in selected) == 40
            expected = [case for case in selected if case["status"] == "xfailed"]
            assert len(expected) == 1 and expected[0]["name"] == "test_pip_downloads_require_hashes"
            assert expected[0]["skip_attributes"]["message"] == "CODEX-5"
            case_records[platform] = {"source_member": member, "source_member_sha256": hashlib.sha256(data).hexdigest(),
                                      "cases": selected, "scope": "Read from the sealed prior full-suite JUnit; no test executed during this reconciliation."}
        save("archived-relevant-junit-cases.json", case_records)
        for member in ("tier-r-cache-evidence.json", "linux-package-receipt.json",
                       "linux-smoke-136798676256-receipt.json", "linux-smoke-136798676259-receipt.json"):
            (copied / member).write_bytes(archive.read(member))
    context_path = "docs/engineering/evidence/cycle837fe-codex5-20261121/primary-promotion-context.json"
    context_data = git("show", f"{BASE}:{context_path}")
    context = json.loads(context_data)
    assert context["merged"] is True and context["merge_commit"] == MAIN
    assert context["source_head"] == SOURCE and context["source_tree"] == TREE
    assert context["actual_parents"] == [PARENT, SOURCE]
    assert context["actual_tree"] == TREE
    assert context["qualification_archive_sha256"] == receipt["archive_sha256"]
    (copied / "primary-promotion-context.json").write_bytes(context_data)
    raw_commit = git("cat-file", "commit", MAIN)
    headers, message = raw_commit.decode().split("\n\n", 1)
    parents = [line.split()[1] for line in headers.splitlines() if line.startswith("parent ")]
    tree = next(line.split()[1] for line in headers.splitlines() if line.startswith("tree "))
    assert parents == [PARENT, SOURCE] and tree == TREE
    assert "[no release]" in message.lower() and "[no deploy]" in message.lower()
    (copied / "actual-main-merge-commit.txt").write_bytes(raw_commit)
    save("promotion-proof.json", {"source_head": SOURCE, "source_tree": TREE, "actual_main_merge": MAIN,
         "actual_parents": parents, "actual_tree": tree, "both_opt_out_markers": True,
         "sealed_primary_archive_sha256": receipt["archive_sha256"],
         "all_primary_members_and_crc_verified": True, "no_fresh_ci_observation_or_test_run": True})
    retained = [
        "docs/engineering/evidence/cycle4-95fe/README.md",
        "docs/engineering/evidence/cycle4-95fe/qualification.json",
        "docs/engineering/evidence/cycle4-95fe/code-publication-mapping.json",
        "docs/engineering/evidence/cycle4-95fe/buildenv-spec-review.md",
        "docs/engineering/evidence/cycle4-95fe/buildenv-standards-review.md",
        "docs/engineering/evidence/cycle4-95fe/cycle4-review-evidence.zip",
        "docs/engineering/cycle2-strings-header-help-20261121-2bad.md",
        "docs/engineering/evidence/cycle2-strings-header-help-20261121-2bad.zip",
        "docs/engineering/cycle837fe-recovery-and-search-20261121.md",
        "docs/engineering/codex1-direct-action-pins-20261121.md",
        "docs/engineering/codex6-corpus-cache-archive-20261121.md",
        "docs/engineering-handoffs/codex6-cache-hit-fixture-20261121.md",
        "docs/engineering/evidence/codex6-archive-cache-controls-20261121.json",
        "docs/engineering/codex14-linux-frozen-cli-smoke-20261121.md",
        "docs/engineering/evidence/codex14-linux-smoke-static-review-20261121.json",
        "docs/engineering/cycle2-historical-ui-review-20261121-2bad.md",
    ]
    copied_sources = []
    for relative in retained:
        data = git("show", f"{BASE}:{relative}")
        target = ROOT / "retained" / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        copied_sources.append({"path": str(target.relative_to(ROOT)), "source": f"{BASE}:{relative}",
                               "git_blob": git("rev-parse", f"{BASE}:{relative}").decode().strip(),
                               "sha256": hashlib.sha256(data).hexdigest()})
    for filename in ("review-addendum.json", "review-addendum-initial-failure.json", "review-receipt.json"):
        source = WORKSPACE / "evidence/search-independent" / filename
        target = ROOT / "retained/search-independent" / filename
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        copied_sources.append({"path": str(target.relative_to(ROOT)), "source": str(source),
                               "sha256": hashlib.sha256(target.read_bytes()).hexdigest()})
    bindings = []
    production = {
        "Buildenv": ("8c5e77e2c1ad3f6cfa62c2e474f7bcc2f4af1dd5", [
            "src/patchtrace/buildenv/panel_model.py", "src/patchtrace/buildenv/tooltip_entries.py", "tests/test_buildenv_header_help.py"]),
        "Search": ("0069d0d28a8a8695d72f6ca960beaa7756b082ce", [
            "src/patchtrace/search/qt_panel.py", "src/patchtrace/search/tooltip_entries.py", "src/patchtrace/search/tooltip_data.py", "tests/test_search_header_help.py"]),
        "Strings": (None, ["src/patchtrace/strings/qt_panel.py", "src/patchtrace/strings/panel.py",
                            "src/patchtrace/strings/tooltip_entries.py", "tests/test_ui_strings_panel.py"]),
        "Audit": (None, ["tests/test_tooltips.py", "tests/test_codex_pkg_workflows.py", "tests/test_codex_pkg_packaging.py",
                          ".github/workflows/corpus-tier-r.yml", ".github/workflows/qa-windows.yml"]),
    }
    for scope, (original_head, paths) in production.items():
        for relative in paths:
            data = git("show", f"{SOURCE}:{relative}")
            assert git("show", f"{BASE}:{relative}") == data
            assert git("show", f"{MAIN}:{relative}") == data
            if original_head:
                assert git("show", f"{original_head}:{relative}") == data
            target = ROOT / "qualified-source" / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            bindings.append({"scope": scope, "path": relative,
                             "qualified_git_blob": git("rev-parse", f"{SOURCE}:{relative}").decode().strip(),
                             "sha256": hashlib.sha256(data).hexdigest(),
                             "same_in_frozen2ae_and_main902": True,
                             "original_source_head_with_byte_identity": original_head})
    c4_mapping = json.loads((ROOT / "retained/docs/engineering/evidence/cycle4-95fe/code-publication-mapping.json").read_text())
    mapped = next(item for item in c4_mapping["source_mapping"] if item["local_commit"] == production["Buildenv"][0])
    assert git("rev-parse", mapped["local_commit"] + "^{tree}") == git("rev-parse", mapped["remote_commit"] + "^{tree}")
    ancestor = subprocess.run(["git", "-C", str(REPO), "merge-base", "--is-ancestor", mapped["remote_commit"], SOURCE]).returncode
    assert ancestor == 0
    save("qualified-source-binding.json", {"files": bindings, "c4_source_mapping": mapped,
         "mapped_C4_head_is_primary_ancestor": True,
         "historical_string_worker_object_not_required_for_current_scope": "Current Strings mappings are bound directly to qualified ae69 bytes and its archived 17 passing header-related cases on each OS; no ancestry assertion is made for the original source_commit field."})
    save("retained-input-manifest.json", copied_sources)
    print(json.dumps({"primary_archive_verified": True, "primary_members": 159,
                      "qualified_source_files": len(bindings), "retained_inputs": len(copied_sources),
                      "archived_cases_per_platform": 41, "new_tests_executed": 0}))


if __name__ == "__main__":
    main()
