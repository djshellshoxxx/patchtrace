"""Static packaging checks for codex-packaging-1.md; never freeze or run binaries."""
from __future__ import annotations

import ast
import json
import re
import tomllib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def source(relative):
    return (ROOT / relative).read_text(encoding='utf-8')


def tree(relative):
    return ast.parse(source(relative), filename=relative)


def function(relative, name):
    return next(node for node in tree(relative).body
                if isinstance(node, ast.FunctionDef) and node.name == name)


def assignment(relative, name):
    return next(node.value for node in tree(relative).body
                if isinstance(node, ast.Assign)
                and any(isinstance(target, ast.Name) and target.id == name for target in node.targets))


def manifest():
    return tomllib.loads(source('pyproject.toml'))


def runtime_requirements():
    project = manifest()['project']
    return project['dependencies'] + [requirement for extra in ('search', 'rules')
                                      for requirement in project['optional-dependencies'][extra]]


# CODEX-9 fixed: every runtime requirement (core and optional extras) is an exact pin
def test_runtime_requirements_have_exact_pins():
    loose = [requirement for requirement in runtime_requirements()
             if not re.fullmatch(r'[\w.-]+==[^*,;\s]+', requirement)]
    assert not loose, loose


def test_all_declared_dependencies_have_pin_or_upper_bound():
    document = manifest()
    requirements = document['build-system']['requires'] + document['project']['dependencies']
    requirements += [requirement for extra in document['project']['optional-dependencies'].values()
                     for requirement in extra]
    loose = [requirement for requirement in requirements
             if not re.search(r'==[^*,;\s]+|<', requirement)]
    assert not loose, loose


def test_optional_runtime_dependencies_have_notice_rows():
    rows = '\n'.join(line.lower() for line in source('docs/notices.md').splitlines()
                     if line.startswith('|'))
    names = ast.literal_eval(assignment('tools/build_linux.py', 'OPTIONAL_DISTRIBUTIONS'))
    assert all(name.lower() in rows for name in names), names


def test_license_copy_loops_require_nonempty_license_sets():
    permissive = []
    for path in ('tools/build_linux.py', 'tools/build_windows.py'):
        for node in ast.walk(function(path, 'main')):
            if not isinstance(node, ast.For) or not isinstance(node.iter, ast.BoolOp):
                continue
            values = node.iter.values
            if (isinstance(node.iter.op, ast.Or) and len(values) == 2
                    and isinstance(values[0], ast.Attribute) and values[0].attr == 'files'
                    and isinstance(values[1], ast.List) and not values[1].elts):
                permissive.append(f'{path}:{node.lineno}')
    assert not permissive, permissive


def test_full_payload_validation_parses_manifest():
    functions = [function('tools/build_linux.py', name) for name in ('payload_problems', 'attach_backend')]
    calls = [node.func for func in functions for node in ast.walk(func) if isinstance(node, ast.Call)]
    # Currently there is no JSON/strict verifier call at all. A repair should use
    # the canonical validator, with behavioral tests, rather than an ad hoc parser.
    validates = any((isinstance(call, ast.Attribute) and call.attr in {'load', 'loads', 'model_validate'})
                    or (isinstance(call, ast.Name) and call.id in
                        {'validate_manifest', 'verify_bundle', 'inspect_offline_bundle'}) for call in calls)
    assert validates, 'Backend attachment checks presence but never parses/verifies the manifest'


def _linux_smoke_job():
    workflow = source('.github/workflows/qa-windows.yml')
    return workflow.split('  linux-smoke:\n', 1)[1].split('  # Decides', 1)[0]


def test_linux_package_runs_full_cli_smoke():
    """CODEX-14: qualify the unpacked release artifact, not a source CLI or the build folder."""
    smoke = _linux_smoke_job()
    checkout = 'actions/checkout@11d5960a326750d5838078e36cf38b85af677262'
    download = 'actions/download-artifact@d3f86a106a0bac45b974a628896c90dbdf5c8093'
    interpreter = 'actions/setup-python@a26af69be951a213d495a4c3e4e4022e16d87065'

    def action_position(action):
        # Match the actual uses field, never a readable version/comment elsewhere.
        match = re.search(r'^\s*(?:- )?uses: ' + re.escape(action) + r'(?: +#[^\n]*)?$', smoke, re.M)
        assert match is not None, f'linux-smoke missing {action}'
        return match.start()

    required = [
        "pip install --only-binary=:all: -e '.[dev,search,rules]'",
        'sha256sum -c PatchTrace-0.1.0-linux-x86_64.tar.gz.sha256',
        'tar xzf PatchTrace-0.1.0-linux-x86_64.tar.gz',
        'test -x PatchTrace/PatchTrace',
        'python tools/frozen_smoke.py "$PWD/PatchTrace/PatchTrace"',
    ]
    for term in required:
        assert term in smoke, f'linux-smoke missing {term}'
    assert action_position(checkout) < action_position(download)
    assert 'persist-credentials: false' in smoke
    assert action_position(interpreter) < smoke.index('python tools/frozen_smoke.py')
    assert smoke.index('sha256sum -c ') < smoke.index('tar xzf ') < smoke.index('python tools/frozen_smoke.py')
    assert 'QT_QPA_PLATFORM: offscreen' in smoke
    assert 'LANG: C.UTF-8' in smoke
    assert 'matrix:\n        os: [ubuntu-22.04, ubuntu-24.04]' in smoke


def test_full_linux_frozen_smoke_preserves_both_qt_modes():
    smoke = _linux_smoke_job()
    assert 'QT_QPA_PLATFORM=offscreen PatchTrace/PatchTrace --self-test' in smoke
    assert 'QT_QPA_PLATFORM=xcb xvfb-run -a PatchTrace/PatchTrace --self-test' in smoke
    frozen = source('tools/frozen_smoke.py')
    assert 'run_checks([exe], frozen=True)' in frozen
    assert 'binexport_checks(launcher, frozen=frozen, check=check)' in frozen
    assert 'intelligence_checks(launcher, frozen=frozen, check=check)' in frozen


def test_full_bundle_pin_has_no_other_gpl_components():
    """CODEX-15 repaired by an explicit, enforced policy (tools/check_backend_pin.py), not by loosening the scan.

    Every GPL-family SPDX outside ghidriff must be named in license_policy, with an identical SPDX and an
    explicit owner_approved boolean; Ghidra's GPL/** directory must be stripped, not kept.
    """
    pins = json.loads(source('tools/backend_pin.json'))
    allowed = pins['license_policy']['allowed']

    def forbidden(node, path=''):
        findings = []
        if isinstance(node, dict):
            spdx = node.get('spdx', '')
            if re.search(r'(?<!L)\b(?:A?GPL)-', spdx) and not path.startswith(('ghidriff', 'license_policy')):
                component = path.split('.')[-1]
                listed = [name for name, entry in allowed.items()
                          if component in entry['match'] and entry['spdx'] == spdx
                          and isinstance(entry['owner_approved'], bool)]
                if not listed:
                    findings.append((path, spdx))
            for key, value in node.items():
                findings.extend(forbidden(value, f'{path}.{key}' if path else key))
        elif isinstance(node, list):
            for index, value in enumerate(node):
                findings.extend(forbidden(value, f'{path}[{index}]'))
        return findings

    assert not forbidden(pins), forbidden(pins)
    assert set(allowed) == {'ghidriff', 'temurin-jdk', 'ghidra-GPL-dir'}
    assert 'GPL/**' in pins['strip']['ghidra'] and 'GPL/**' not in pins['strip']['keep']
    assert allowed['ghidra-GPL-dir']['shipped'] is False


def test_core_runtime_declarations_are_exactly_pinned():
    for requirement in manifest()['project']['dependencies']:
        assert re.fullmatch(r'[\w.-]+==[^*,;\s]+', requirement), requirement


def test_frozen_smoke_enumerates_registry_names():
    commands = assignment('tools/frozen_smoke.py', 'COMMANDS')
    assert isinstance(commands, ast.Call) and isinstance(commands.func, ast.Name)
    assert commands.func.id == 'names'
    registry = function('src/patchtrace/cli_commands/__init__.py', 'names')
    identifiers = {node.id for node in ast.walk(registry) if isinstance(node, ast.Name)}
    assert {'COMMANDS', '_modules'} <= identifiers
    smoke = function('tools/frozen_smoke.py', 'run_checks')
    assert any(isinstance(node, ast.For) and isinstance(node.iter, ast.Name)
               and node.iter.id == 'COMMANDS' for node in ast.walk(smoke))


def test_dynamic_loader_hooks_cover_known_runtime_imports():
    imports = ast.literal_eval(assignment(
        'tools/pyinstaller_hooks/hook-patchtrace.secondary.binexport_proto.py', 'hiddenimports'))
    assert {'google._upb._message', 'google.protobuf.descriptor_pool',
            'google.protobuf.message_factory'} <= set(imports)
    optional = source('tools/pyinstaller_hooks/hook-patchtrace.optional_deps.py')
    assert "collect_submodules('rapidfuzz')" in optional and "'yara_x'" in optional
    verbs = source('tools/pyinstaller_hooks/hook-patchtrace.cli_commands.py')
    assert "collect_submodules('patchtrace.cli_commands', on_error='raise')" in verbs
    assert 'if _missing:' in verbs
    extractor = source('tools/pyinstaller_hooks/hook-patchtrace.unified.extract.py')
    assert "datas = [(str(_SCRIPT), 'patchtrace/unified/extract')]" in extractor


def test_freezer_source_does_not_import_external_gpl_engines():
    paths = ['tools/build_windows.py', 'tools/build_linux.py']
    paths += [str(path.relative_to(ROOT)) for path in (ROOT / 'tools/pyinstaller_hooks').glob('*.py')]
    imports = set()
    for path in paths:
        for node in ast.walk(tree(path)):
            if isinstance(node, ast.Import):
                imports.update(alias.name.split('.')[0] for alias in node.names)
            elif isinstance(node, ast.ImportFrom) and node.module:
                imports.add(node.module.split('.')[0])
    assert not {'ghidriff', 'diaphora', 'pyghidra'} & imports
