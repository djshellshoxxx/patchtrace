## Current combined source checkpoint — CODEX-5 and Pages configuration hold

Implementation source `0cdd5bf37130206c2ddec399450be6338ae8e4fd` / tree `6d532dd606a1fdf987245a03271970758a03fe57` maps exactly to remote code object `06b5ed67c78aac30972e657b4a7ae5a17de739b8`. Both bounded source changes have independent signoff. Earlier `5b5328ee` evidence below remains source-specific; its scanner, tests and runtime bytes are unchanged. Independent records review passed 141 mechanical checks on tree `e7ecad2c0b1128a83876bf137634cf9f64d29f1f`, with zero blockers; these are record checks, not product test cases. Applicable hosted qualification and main merge remain pending. Resolve the final published head from live PR/CI metadata; this checkpoint does not assert future success.

The first held main Pages run [44889511406](https://github.com/djshellshoxxx/PatchTrace/actions/runs/44889511406) passed hashed installation, **247 site tests / one optional-GUI skip**, and static build, then failed configuration GET with HTTP404; deployment skipped. The repair adds only the existing deployment predicate to configuration. Tests/build/upload, pins, permissions, triggers and the deploy job stay unchanged. Validation: intended red regression **one failed / seven passed**; **249 site passes**; separate **226 passes / two strict CODEX-5 expected failures**; overlapping author and independent **119-pass** confirmations, plus **12 independent controls**. Hosted configure-skip/upload proof awaits the next automatic held main push.

Seven older acceptance rows are now reconciled with before-snapshots: CODEX-14 records both actual 64-check Ubuntu passes; CODEX-6 retains verified rizin hits and the open Ghidra archive path; original Pages source work is merged while its new configuration defect is tracked separately. Broader dependency closures, native limits, manual/trust/accessibility/provenance and separate L1/L2/L3 gates remain open. **Release readiness and new-source merge eligibility remain false.**

The final local record commit preserves ordered parents `0cdd5bf37130206c2ddec399450be6338ae8e4fd`, actual main `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4`, and original donor `36b58a7d857690a8bf0093bcee1edd5036189b30`, retaining selected source and the authoritative ledger without replacing it with the donor ledger. Earlier sections are immutable checkpoint history.

---

## Current CODEX-5 follow-up after qualified primary promotion

Primary PR #349 source `ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e` / tree `c3f09435deb99ca0ddb3406e27ab315dba7740cf` is merged through `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4`, with actual ordered parents/tree and both **[no release] [no deploy]** verified. Its final evidence retains documented native/environment limits and expected failures.

New code `5b5328ee83ee4990b3311f7ac90e2f5e5f76f800` / tree `1e12edd510399fd92da6867cd071394ceb7fc95b` maps to static remote code object `92dfc4d4d2ef9d604bc9db1a639d4f19add535a8`. Root: **1,548 passed / 2 strict CODEX-5 xfailed**, **1,550 distinct cases**, **66 selectors**, **84.021s**; whole-tree Ruff/pip/isolated binding passed. Final peer: **226 passed / 2 strict xfailed**, **20 lexical / 3 YAML controls**, plus typed failure controls. Counts overlap. The repaired task is **implementation COMPLETE / TESTING**; final follow-up publication, hosted qualification and guarded main merge remain pending. Static mapped identities are not live final PR/CI outcomes. Release readiness and new-source merge eligibility remain false.

The first-repair full attempt remains incomplete: modified working tree, SIGKILL **-9**, wrapper **247**, **498.536s**, unknown cause, no aggregate summary. No second local full run occurred. Broader CODEX-5, Ghidra archive-cache acceptance, Tier R/Tier W/native limits, manual/trust/accessibility, full provenance and separate L1/L2/L3 gates remain open. The original **181/16** census is retained.

[Current report](engineering/cycle837fe-codex5-20261121.md) · [Ledger](engineering/task-ledger.json). Root owns publication/qualification; authoring and independent review are released.

### Preserved historical checkpoints

All earlier text below remains verbatim as source-specific history. Its earlier pending-main/current-owner wording is superseded only by the scoped current record above.

## Current PR349 Tier R test repair

[Current report](engineering/cycle837fe-native-c4-20261121.md) and [ledger](engineering/task-ledger.json): tested 829600f8 / tree 306c4d58, **1,444 passed / 1 CODEX-5 xfailed**, 1,445 distinct cases, 65 selectors. Whole-tree Ruff, dependencies, isolated binding and independent 67-case review pass. The missed Tier R mutable-tag assertion is repaired; all original workflow/digest/permissions/compiler requirements remain. The cancelled predecessor's partial 1 failed / 19,776 passed result and the original review coverage miss are retained.

Actual predecessor a73 Intel checks pass on Linux (4) and Windows (3), with one Windows offline namespace skip. Final revised-head full/Qt/native/package/frozen qualification and main merge remain pending. Root owns PR349; main/release readiness remains false. Earlier current-state sections below are source-specific history.

## Current PR349 Intel + C4 follow-up

[Current report](engineering/cycle837fe-native-c4-20261121.md) and [ledger](engineering/task-ledger.json):tested `6bf79fef` / `dc659c7e`, 1,396 passes/1 CODEX-5xfail, zero failures/errors/ordinary skips, required lint/dependencies/source binding and independent whole-tree review. ExistingPR349 combines fixed Windows identity, five Build environment help mappings and bounded Pages lock/isolation with earlier storage/Search/pinning/cache/frozen work. Exact new-source hosted/native/package gates remain pending;main/release readiness is not claimed.

Original Windows failures and Tier R 5/11 coverage gap remain evidence; the same Tier R gap occurred on original PR349. Four more historical scopes need no port;whole branches remain partly reviewed and 181/16 census unchanged. Root owns PR349 qualification;C4/Intel histories are retained. Earlier current-state paragraphs are historical for these scopes.

## Cycle4 parent integration update — 2026-11-21 UTC

The separate C4 follow-up includes PR349 `daee337c` and preserves both implementations
and histories. Source `111803d5` / REST code checkpoint `7ddb1130` passed 580 cases,
with one CODEX-5 expected failure and no ordinary skips; all 110 registry cases are
included. Required Ruff/pip/source binding and independent merge/history reviews
passed. CODEX-1 is closed by the parent; wider CODEX-5 and hosted/native/manual/release
gates remain open. [Current report](engineering/cycle4-consolidation-20261121-95fe.md) and [exact qualification](engineering/evidence/cycle4-parent-20261121/qualification.json)
supersede the earlier pending C4 combination state. PR349 ownership stays with 837FE;
resolve final follow-up head/checks from its live PR. Main/release eligibility remains
false. A qualified main commit requires `[no release] [no deploy]`. Earlier sections
remain source-specific history.

## Cycle4 bounded follow-up qualification

Clean combined source 8c5e77e2 passed 391 affected tests, with 2 existing CODEX-1/5
expected failures and 0 ordinary skips. Whole-tree Ruff, pip consistency, isolated
source binding and whitespace passed. Four independent source reviews passed;
their README prerequisite finding was fixed and rechecked. The separate clean
Pages environment passed 247 with1 existing optional GUI skip, and actual hashed
install/build and both intended pip refusals passed. The GUI case passed in the
combined full-dependency environment. Counts overlap and are not additive.

Original14-failure header baseline, hidden-host audit failure, Pages setup error,
four source-contract failures and deliberate negative controls are preserved.
Actual installation used verified offline wheels; hosted index/build and new-head
full QA remain separate. [Report and evidence](engineering/cycle4-consolidation-20261121-95fe.md).
PR #349's integration and remaining qualification belong to the parallel 837FE owner.

## Cycle 2 current checkpoint

Clean reviewed source 3cf7ad23 passes 188 affected cases with no skips/failures, whole-tree Ruff, dependencies and isolated import binding. The initial 187-pass/1-audit-failure run and Ruff finding are retained alongside corrected results. The fresh peer confirms the audit fails when an actual header mapping is removed. [Complete qualification](engineering/cycle2-consolidation-20261121-2bad.md).

PR #346 completed all automated QA/Qt/native/package/smoke checks on its own source. PR #345's original NSIS 503 is retained and a single failed-job-only retry is active; PR #347 Windows QA remains active at the last read. These are predecessor receipts, not new-source full acceptance. Historical SIGKILL causes remain unestablished.

## Historical source-specific checkpoints

The dated entries below retain their original observations. Use the current task ledger and checkpoint above for present status.

## Current qualification — 20 November 2026

See [the consolidated report](engineering/session-20261120-2bad.md). Final-source batch 3 completed 429 passes and two native Windows skips across 16 files. Full/combined attempts and two bounded batches ended SIGKILL without JUnit and remain incomplete. Scoped reviews and earlier focused successes are separate. Ruff and dependencies pass; no main/release acceptance. Older entries below retain their historical observations.

## Generation 39 — KB investigation Create junction preflight (2026-11-20)

Four repository regression functions authored on isolated g39: mocked final-component junction, ordinary empty destination, preserved symlink refusal and native Windows junction to a real empty target. A hand-copied Python 3.13.5 source-equivalent control reproduced prior admission, corrected refusal and unchanged ordinary acceptance (three expectations passed). It is **not** a repository-source pytest run; no full pytest, Ruff, native Windows, separate review or exact-head hosted QA was performed. PR343 full QA remained active, so no duplicate job was launched. No false-passing nonempty-junction fixture is retained. See [g39](engineering-handoffs/generation-39-20261120.md). The earlier Windows Qt, SIGKILL and native Java failure receipts remain unchanged.

# QA and audit record

## Final reviewed checkpoint — generation33

Source `bbdef5a6` passed **606 affected tests with one native Windows skip**. Whole-tree Ruff, dependency validation, complete-range whitespace and independent source-scope checks pass. Five product repair areas and the CI diagnostic-retention fix are reviewed. The original native `java=unverified` cache failure and earlier unexplained full-suite SIGKILL remain unresolved; final-head hosted/native/package and standing release gates remain required. [Final qualification](engineering/generation33-qualification-20261120.md).


## Latest five-area checkpoint

Source `71b535cc` passed **493 affected cases with one native Windows skip**, whole-tree Ruff and complete-range whitespace. Initial remote `5cc3f2a` has an unresolved native cache gate failure (`java=unverified`); diagnostic retention is under independent review. Full/current-native/package and existing release blockers remain open. [Details](engineering/generation33-qualification-20261120.md).


## 2026-11-20 generation 33

Exact clean source `ad891694` / tree `23ad5e52` passed **397 combined affected tests with no skips, failures or errors**, whole-tree Ruff and dependency validation. The added Strings shutdown guard has two actual Qt baseline failures, 96 author affected passes and independent 100 passes (96 replayed plus four extra controls). Earlier full frozen `a024f9ec` qualification ended SIGKILL after 563.257508 seconds, with no final summary/JUnit and unestablished cause. Its two-node diagnostic passed without changing assertions; this is not aggregate acceptance. The raw-log whitespace finding was corrected by byte-preserving gzip, with the original failure retained. [Qualification record](engineering/generation33-qualification-20261120.md) and [current handoff](engineering-handoffs/generation-33-20261120.md).


## 2026-11-20 generations 30–31

Reviewed code checkpoint `c0108749e8813dfa6165e953b1a2dc2ad736e982` recovers two narrow donor scopes and one new UI repair. Receipt baseline: 18 failures/11 passes; affected recovery: 140 passes/one optional psutil skip, followed by a separate pass of that resource control. Search: 58 affected passes. Strings: 102 disjoint affected passes. Recent input guards: 96 disjoint focused passes. Independent replays overlap these numbers and must not be summed. Combined local and final-head hosted qualification remain pending at this checkpoint. Native Windows/FLOSS, Qt disposition and the forced-export race remain separate.

See [handoff](engineering-handoffs/generation-30-31-20261120.md), [census](engineering/consolidation-inventory-20261120-g30.md), [receipt recovery](engineering/receipt-source-recovery-20261120.md), [Search review](engineering/search-cancel-independent-review-20261120.md), and [Strings recovery](engineering/strings-stored-source-recovery-20261120.md).


## 2026-11-18 advisory anchor compatibility and final frozen L1 evidence

The current successor preserves actual #305/#306 heads and repairs the reproduced
long-anchor budget regression and default stored-advisory CLI owner mismatch.
Seven new controls failed before repair; the broader frozen-source selection at
`b9fac06b` passed **942 tests**. Independent 85-test and three-head boundary/digest/
cursor checks passed; these overlapping invocations are not summed. Whole Ruff
and whitespace passed. The preserved source-specific L1 replay at `f69614fa` is
**73 PASS, 6 FAIL, 8 excluded**, exit 1; the six expected failures and all frozen
inputs remain intact. Final-head hosted full/Windows/Qt/package/native gates are
still mandatory. See [the integration and evidence record](qa/search-anchor-integration-20261118.md).


## 2026-11-18 CVE consolidation successor and real L1 replay

The second independent review repaired Windows ZIP path identity, uncertain
chronology/fix boundaries, rejected advisory source scoring and pair-output
ownership. A real source replay exposed mixed-architecture predecessor selection,
now repaired, and supported `.tsp` inputs were added. Combined local verification:
**2,089 passed, 3 skipped** at `06c8ca0c`. Frozen source-backed L1 expected-file
replay: **73 PASS, 6 FAIL, 8 excluded**; no percentage/bound and no L2/L3 claim.
Four Server coverage cases and two unchanged-preview cases remain failures.
Exact-head hosted Windows/full/package gates remain mandatory. See the
[source, repair and continuation record](qa/cve-consolidation-20261118.md).


## 2026-11-18 current consolidation correctness follow-up

The #302 continuation selectively incorporates six independently reviewed
correctness fixes from concurrent #304, then repairs ZIP separator handling,
ambiguous chronology/change provenance and unbounded variant evaluation.
Independent final core review at `bce67e93`: **239 passed** (225 project cases
plus 14 independent controls). Separate verifier/L1/schema selection: **242
passed**. Whole Ruff, schema regeneration and whitespace checks pass. A broader
combined local process ended 137 without a summary and is not a passing run.
Exact source/continuation trees, old-head hosted counts and remaining gates are
in [the follow-up record](qa/consolidation-correctness-20261118.md). Existing
automatic prerelease policy is unchanged; fresh published-head CI remains the
merge gate. PRs #304, #305 and #306 retain their separate remaining scope.

## 2026-11-18 independently reviewed consolidation successor

`codex/consolidation-reviewed-20261118` directly continues #301, preserving #297
and its source ancestry. The corrected full-clone inventory contains **300 topic
branches**, of which **113** are ancestors of starting main; all 300 have a merge
base. All remote branches remain intact. Independent core and security review
reproduced and repaired zero-address normalization, L-39 cap asymmetry,
recent-query JSON ingress, and release archive type/link validation. The unsafe
archive/delete helper is excluded. See the exact references, scope, focused test
counts and deferred work in the [decision log](qa/branch-consolidation-20261118.md).
Current-successor full QA and hosted gates remain pending until recorded against
their exact commit; the historical section below is not current qualification.

## 2026-11-18 full branch consolidation (PR #301)

Historical author report (branch-count claims corrected by the decision log):
carried #297 and ported eight initially listed never-merged
items (release verifier, parser fuzz harness, KB scope retention #118 P1a, R8
typed-literal canon/2 with EH-EQ, Windows batch-launch hardening, saved
searches, RD-F03 alignment core, A-32 Ghidriff one-to-many abstention).
Local Linux, Python 3.13, pytest-xdist `-n 3 --dist loadfile`, CI extras
installed: `main` + #297 baseline **21,692 passed, 7 failed** (6 need the
`rapidfuzz` extra, 1 xdist ordering; all 7 pass with extras installed); head
`a59891cf` (before A-32) **22,348 passed, 48 skipped, 5 xfailed, 0 failed**;
A-32 affected selection **2,918 passed** plus UI and seam tests; final code
head `4534b763` (all ports, including A-32, rz-diff flood stop and
bundle-acceptance fixes) **22,477 passed, 48 skipped, 5 xfailed, 0 failed**.
Whole Ruff passed. Exact-head #301 hosted results were subsequently refreshed in
the decision log; they do not qualify the successor. Targeted native RB-01,
Windows desktop and release acceptance remain open. See
[consolidation record](qa/branch-consolidation-20261118.md).

## 2026-11-16 local KEV CLI context completion

Completed the remaining K4 context wiring through verified local catalogs,
including snapshot staleness and provenance without function-ranking changes.
Final combined affected selection: **1,224 passed**. Broader local acceptance
still encounters the documented AF_UNIX runner restriction and grouped process
terminations; hosted Windows/full-suite/release gates remain open. See
[KEV continuation evidence](qa/kev-cli-continuation-20261116.md).

## 2026-11-16 path, KB CLI and historical research continuation

Repaired both observed Windows CLI path failures, completed metadata-sync help
and stored-product catalogue CLI access, and recovered the isolated R7 research
slice from #282. Combined affected verification: **724 passed**; whole Ruff,
dependency and whitespace checks passed. The full single-process attempt was
killed (137); hosted/current Windows and release gates remain open. See
[source-pinned evidence and limits](qa/continuation-paths-kb-r7-20261116.md).

## 2026-11-16 research integrity recovery

See [research recovery evidence](qa/research-integrity-followup-20261116.md):
Tier R provenance/labels/immutable receipts (155 passed, 8 native skips), native
IO research validator (136 passed), and independent scoped reviews. Fresh pinned
Linux API controls matched all six expected stock/corrected/negative outcomes;
prior failures and worker-count diagnosis are preserved with raw receipts.
Final-head hosted/platform gates remain separate; no real-binary accuracy claim is made.

## 2026-11-16 consolidation follow-up

See [follow-up evidence](qa/consolidation-followup-20261116.md): timeout entry
controls, benchmark/parity and release repairs, independent review, 480 combined
passes/3 expected failures plus 13 backup checks, and ten redundant PR closures.
Hosted final-head qualification remains pending.

## 2026-11-16 continuation

See [continuation evidence](qa/continuation-20261116.md), including independent
review findings, branch dispositions and explicit native/release blockers.

## 2026-11-11 SPEC-31 unified-engine soundness follow-up (PR #259 open defects) — Linux, synthetic only

Branch `claude/funny-feynman-d2m0b5` (`main` `882d1ca0` + #259's five commits merged cleanly + four fixes). Plan and worker briefs: [unified-soundness-swarm-prompt-20261111](plans/unified-soundness-swarm-prompt-20261111.md); spec amendments A-28..A-31 in `docs/specs/unified-engine/10-amendments.md`. Each defect had a red test before its fix (counts in the commit messages `78c0c544`, `3bf12d61`, `c0bf3d05`, `a28676c8`).

| Defect | Fix | Red/green evidence |
| --- | --- | --- |
| p1 raw Ghidriff table read the wrong way round after `swap_orientation` | document identity (`old_meta`/`new_meta`) recorded by `load_raw`; table flipped when crosswise; new raw failure kind `identity-mismatch`; `ENGINE_VERSION` ude/2 | `tests/test_unified_followup_orientation.py`: 6 failed before, 6 pass after |
| p7 IR-only runs dropped one-sided functions | ladder leftovers of kind function/thunk become one-sided `pt-ladder` atoms and rows; `LADDER_VERSION` ladder/5 | `tests/test_unified_followup_ironly.py`: 4 failed before, 6 pass after |
| p15 coordinated retarget to an existing global became COS-ADDR/1; p11 asymmetric function vote | competing-claim abstention, leave-one-out among the other voters with explained dissents ignored, symmetric votes and region shift; `datamap` 3 | `tests/test_unified_followup_datamap.py`: 6 of 7 failed before, 9 pass after (300-example mirror property) |
| p17 alignment tie-breaks differed when the sides were swapped | symmetric block-pairing seed, canonical-orientation LCS/patience ties, symmetric layout edge check; `align` 2 | `tests/test_unified_followup_align.py`: 7 failed before, 10 pass after (300-example mirror property, 60-example end-to-end verdict mirror) |

Whole unified set plus neighbours at head `a28676c8` (Python 3.13.18, PySide6 6.12.0, offscreen): `QT_QPA_PLATFORM=offscreen python -m pytest -q -p no:cacheprovider -n 8 --dist loadfile tests/test_unified_*.py tests/test_ui_unified*.py tests/test_evalcore_unified.py tests/test_context_unified_notes.py tests/test_search_sources_unified.py tests/test_pilot*.py tests/test_report2*.py` → **4,236 passed, 0 failed, 0 skipped in 129 s** (baseline before the fixes on `fb038ab9`: 2,628 passed for the unified files alone). `python -m ruff check src tests tools` clean; `python tools/generate_schemas.py` produced no drift; `git diff --check` clean.

Expectation changes made on purpose (each keeps the test's purpose): `test_the_residual_stage_runs_and_backup_b07_switches_it_off` now expects the two ladder leftovers as one-sided rows; `test_a_capped_vote_table_never_turns_a_dissenter_into_a_proof` runs on a lone-dissenter fixture (two competing claimants with two voters each now abstain by design); S0 fixtures carry a document identity like every imported raw file; key golden and CLI status pins follow ude/2; the fct-audit version pin includes datamap 3 and align 2.

Not evidence of: live Ghidriff, Windows, real-pair accuracy, or the unified live gates. Known coverage cost of A-30 (two functions retargeted together to a brand-new global make every referrer of the old datum `review`) is to be measured on the next live gate run. Independent adversarial review of the combined diff (fresh Opus agent, attack scripts over a stub reader plus end-to-end `run_facts`): four CONFIRMED findings in the DATA-MAP implementation, all fixed in `a81bc814` with red tests (a stationary existing global with one referrer still mapped >= 3 retargeters; two swapped globals explained each other's blocker away; a non-voter row mapped on one witness; leave-one-out was O(V*P), 9.6 s at 4,000 partners, now 0.04 s); one PLAUSIBLE comment nit fixed. Verified OK by the reviewer: p1 owner/worker agreement and cache identity, p7 leftovers never contest and stay bounded, p17 mirror symmetry over 200k random token pairs, all version bumps reach `config_digest`. Documented residuals (never a wrong `cosmetic` for a stationary global): >= 3 retargeters to a MOVED existing global with exactly one referrer, and a pure two-global swap with no keepers, still map. After the fix, the DATA-MAP/facts/orientation/ironly/align/wire/worker files: 213 passed (the whole-set rerun at `a81bc814` was not repeated: the owner paused the project on 2026-11-11 01:06 UTC; PR CI is the exact-head evidence).

## 2026-11-06 PT-TIMEOUT-1: live progress and execution diagnostics

Implemented [SPEC-01a](specs/ghidriff-timeout-progress.md) on `fix/ghidriff-timeout-progress-20261106`, based on `d8cfd7b1d8bffa90af1c7af94dda012b89886b76`. Process observations are bounded to 16 KiB per captured stream, delivered on the supervisor thread outside the reader lock at most once per second plus a final snapshot. The UI shows the effective subprocess budget, elapsed time, last observed stage and output age with indeterminate progress. Heartbeats do not fill the log; cancellation, terminal text and exact-worker identity take precedence. Timeout errors include the Setup route and project-relative diagnostics directory. Atomic best-effort `backend-execution.json` receipts record process outcome and available safe runtime identifiers without claiming normalized comparison success or inventing unprobed versions. No matching, argv, timeout-default, cache-key or threading changes.

Regression evidence: the existing UI elapsed timer overwrote terminal messages while the worker was still active. Independent review also reproduced misclassification of the supplied `Starting Ghidra analysis of ...` sequence and acceptance of credential-shaped single-token version metadata. Those cases now have passing regression coverage. Review corrected two timing-test assumptions by synchronizing the child's quiet interval with the observer and avoiding an invalid child-sleep lower bound on the narrower supervisor clock.

Focused verification: **13 supervisor tests passed**, including real authored children, quiet heartbeats, fixed deadlines despite output, callback failures, bounded separate streams, cancellation/descendant cleanup, output flooding and cleanup-excluded duration. **41 backend diagnostics tests passed**, including a real authored child that cannot finish until progress is observed, receipt-write failures, version redaction, cache/identical skips and prior-result preservation. **11 offscreen Qt tests passed** for live main-thread delivery, no heartbeat log growth, indeterminate percentages, stale-event rejection, normalization/reset and terminal/cancel priority. An earlier combined integration run passed **255 tests with 3 skips** before the two pure-parser review fixes. These are synthetic process/UI controls, not live Ghidriff compatibility or performance evidence.

Full local integration run: **18,705 passed, 3 failed, 134 skipped, 7 xfailed, 1 warning and 3 teardown errors in 2,333.40 seconds**. Before this completed run, the editable install was rebound to this checkout and verified with an isolated `python -I` import; earlier stopped attempts are not counted. The failures identified the existing `ui.py` size ceiling, a GZF regression assertion that did not allow the new observational events, and the environment's `AF_UNIX` restriction. The `ui.py` relay was extracted into `ui_job_events.py`, retaining the existing 3,077-line ceiling (current file: 3,076); the GZF test now preserves its original core lifecycle/settings assertions while allowing progress/stage observations. The affected host-seam/GZF suites pass **49 tests**.

The three new Qt fixture teardown errors were reproduced independently and traced to pytest-qt scheduling the window for deletion before yield-fixture finalizers. Instrumentation confirmed the worker stopped, then the window was destroyed before its queued `job_finished` callback could clear the Python worker reference. Cleanup now uses the supported `before_close_func` hook, joins the actual worker within the unchanged 5,000 ms bound, dispatches completion while the window is still valid, and asserts the normal callback cleared `window.worker`; it never clears that state manually. All test bodies remain unchanged. Three repeated collections in one process passed **33 tests in 31.47 seconds**.

The Unix-socket failure is independently reproduced by isolated stdlib `socket.socket(socket.AF_UNIX)` with **no PatchTrace module imported**, raising the same `PermissionError: [Errno 1] Operation not permitted` before the network guard runs. The test is retained without changing environment access controls. The only warning is the intentional duplicate-ZIP-entry test; native-tool/platform acceptance remains separately blocked or skipped as reported by the suite. This local full run is not green and is not claimed as final-head hosted acceptance.

Initial corrected-tree combined regression run: **315 passed, 3 skipped in 69.69 seconds**, covering supervisor/progress, backend diagnostics, existing jobs/UI/bundle setup, host-seam rules, GZF retention, spec registry and tracker integrity. Whole-tree Ruff and `git diff --check` pass. Schema regeneration produced no changes to the existing public schemas. Independent re-review approved the production changes, event assertions and fixture lifecycle repair.

PR #251 automated-review follow-up: use explicit `stage not yet observed` until a marker is recognized; preserve the known `unsafe-output-path` receipt reason; emit `analysis-stopped` immediately after supervision returns/raises and before diagnostics/cleanup/validation, letting the ordinary desktop job clock continue; omit only `analysis-progress` heartbeats from both CLI listeners. Seven backend regression cases and seven CLI cases first failed before repair. The backend suite then passed **48 tests**, the CLI/series group passed **61**, and the updated UI/host-seam group passed **36**. CLI cases simulate 7,200 heartbeats per scenario while checking exact retained events, real normalization/persistence and JSON exit envelopes without sleeping or running an external engine.

Combined regression run after the four review follow-ups at `a908f90`: **362 passed, 3 skipped in 71.78 seconds**. Whole-tree Ruff and whitespace checks pass, and independent review found no remaining blocker in those four fixes. The existing core lifecycle assertions still reject unexpected events while allowing the explicitly specified observational events.

A further review identified that infrequent CLI stage messages still wrote to stderr synchronously during process supervision. Four production-wiring regressions reproduced attempted stderr writes during real-child timeout/cancellation in both series and selftest. A per-comparison adapter now suppresses heartbeats and retains at most the latest 64 stage observations without I/O; it flushes them in order, with an explicit omission count after overflow, when supervision ends. Desktop signals remain live. This preserves process deadline/cancellation checks even when the CLI writer is blocked; it does not promise non-blocking terminal output after process stop.

Receipt persistence now flushes and syncs the temporary file before atomic replacement. Three injected sync-failure cases failed before repair; afterward, **51 backend diagnostics tests passed in 2.55 seconds**, including unchanged analysis outcome, preservation of an earlier receipt on final-write failure, temporary-file removal and fixed warning text. This file-only sync is best effort, without a full filesystem/power-loss guarantee. Independent review found no blocker in the receipt follow-up.

Final combined regression run including the CLI stage-deferral and receipt-sync follow-up: **377 passed, 3 skipped in 176.28 seconds**. This includes four real-child blocked-writer cases, bounded backlog/omission ordering and fresh-adapter isolation, along with the earlier backend/UI/CLI and integration checks. Cancellation cases allow five seconds for slower Windows startup; timeout cases retain their shorter fixed budget. Whole-tree Ruff and whitespace checks pass. Independent final review found no blocker in the adapter, both production call sites, tests or amended contract.

Hosted full-suite follow-up at `d4255840c56eebfb168d9506ff49e9d181dc8a9f`: [Linux QA](https://github.com/djshellshoxxx/patchtrace/actions/runs/42232172111/job/127941286463) completed with **18,824 passed, 1 failed, 47 skipped, 7 xfailed and 1 warning in 1,629.36 seconds**. The sole failure was `test_cli_registry.py::test_cli_seam_budget`: the cumulative CLI callback changes grew `cli.py` by nine lines against the unchanged six-line allowance. The earlier focused group did not include this separate CLI registry gate. No runtime test failed in this hosted Linux run; its lint/package steps did not execute after pytest failed.

The CLI seam repair replaces the nested stderr callback and its redundant heartbeat filter with a two-line fresh `CliBackendProgress` listener assignment. The adapter already owns heartbeat filtering and stage deferral; formatting, event ordering, normalization, persistence and exit behavior remain unchanged. This naturally reduces file growth from nine to six lines, meeting the existing gate without changing its cap. A focused rerun including CLI progress, registry, backend CLI, series and headless-entry tests passed **129 tests with 1 skip in 15.87 seconds**. Whole-tree Ruff and whitespace checks pass, and independent review approved the repair and unchanged gate. Hosted acceptance is still required on the resulting repair head.

Hosted acceptance at `3b488913b177dd63a6a42c8eef51a03fe2526824` confirmed the CLI gate repair: [full Linux QA](https://github.com/djshellshoxxx/patchtrace/actions/runs/42237741377/job/127960075756) passed **18,825 tests, with 47 skips, 7 xfails and 1 warning**, followed by clean Ruff. All GUI repeat gates passed: **37,740 test executions across four Linux shards with 20 repetitions**, and **9,435 executions with five Windows repetitions**. [Native Windows Ghidriff acceptance](https://github.com/djshellshoxxx/patchtrace/actions/runs/42237741478) and [unified extraction on both platforms](https://github.com/djshellshoxxx/patchtrace/actions/runs/42237741832) also passed for this head.

[Full Windows QA](https://github.com/djshellshoxxx/patchtrace/actions/runs/42237741377/job/127960076037) at `3b488913` reported **18,788 passed, 4 failed, 81 skipped, 6 xfailed and 1 warning in 2,816.50 seconds**. All four failures were new `test_jobs_progress.py` assertions: three expected LF-only print output and a hard-coded byte count although Windows preserved CRLF; the cleanup-duration test compared its requested 0.4-second sleep against separately sampled clock intervals, which produced a 0.391-second gap. The preceding process/observer/exit assertions passed. The trace does not establish a production timing defect. Windows lint, build and package smoke steps were skipped after pytest failed, so this run did not produce an accepted Windows distributable.

The Windows portability repair changes only those regression assertions: derive native print output from `os.linesep`, compare exact text and raw bytes without normalization, and derive byte totals from the expected bytes. The raw-stream UTF-8 boundary fixture remains unchanged. The cleanup test measures the injected interval on the same monotonic clock, retains a 0.3-second minimum induced delay, and allows only `1e-6` for subtraction precision when comparing wall-minus-execution time with that measured interval. Final snapshot/result equality is retained. The affected jobs-progress, jobs, CLI-progress and backend-progress group passed **134 tests with 3 existing skips in 23.19 seconds** locally; whole-tree Ruff and whitespace checks pass. Independent review approved the test-only correction. No production code or skips changed; fresh Windows and package acceptance remains required.

Initial PR head `9e554dba2bcdfa7b9e080c3521cdf6b647eff2f3` passed all five [native Windows Ghidriff fixture jobs](https://github.com/djshellshoxxx/patchtrace/actions/runs/42226182868) and [unified extraction on Windows and Linux](https://github.com/djshellshoxxx/patchtrace/actions/runs/42226182885). These are fixture results for that specific head; the review follow-up requires fresh hosted checks before merge.

Intermediate head `a908f90c3066999db8bb9b7e03de192307acb1ec` also passed all five [native Windows jobs](https://github.com/djshellshoxxx/patchtrace/actions/runs/42228604908) and [unified extraction on Windows and Linux](https://github.com/djshellshoxxx/patchtrace/actions/runs/42228604838). These results precede the CLI stage-deferral/receipt-sync follow-up and cannot qualify its final head.

Replaying the supplied log through the fixed-stage observer identifies candidate processing at line 419 and enhanced-symbol processing at line 420, without promoting the final percentage to comparison completion; no owner binary was rerun. Hosted full-suite, Windows/package and native-backend gates on the corrected PR head remain required. The high-priority timeout incident and exact owner input-pair rerun remain **OPEN**; a longer budget or these diagnostics do not demonstrate repair of the structural-candidate slow path.

## 2026-11-06 P1: owner-reported Windows Ghidriff timeout — OPEN

Reviewed the supplied `failure.txt`, `analysis.log`, and `ghidriff.log` against main `dc53b529560453e84cf45e356a40432ff3fc6725`. Both initial analyses completed; a structural correlator reported 2,161,955 entries and later result processing contained a 28m 41.755s quiet interval. Final observed progress was an enhanced-symbol (`esym`) substage at roughly 54 minutes, not overall success. Effective timeout, termination time and the exact installed application/backend versions remain unverified.

The [incident record](qa/ghidriff-timeout-20261106.md) documents the existing 7,200/14,400-second desktop retry options, separate per-function timeout, missing symbols, nonfatal parser warnings, performance investigation and Windows acceptance checklist. The item is prioritized at the top of `tasks/todo.md`. This initial incident review was documentation only; the diagnostic implementation follow-up is recorded above. The binary pair was not supplied or rerun and no matching-performance repair is claimed.

## Independent parallel development checkpoint — 2026-11-05

Own integration branch `integrate/independent-wave4-20261105`, source merge
`ec48810c41530d787cfbd44b38406427062a5442`, based on published #218
`afc8a296`. Source slices #225–#234 were independently reviewed, focused-tested,
committed/pushed as separate draft PRs and integrated once here. Exact source SHAs,
reviewers, overlapping counts and remaining boundaries are in the
[current handoff](handoff/AUTONOMOUS-DEVELOPMENT-LATEST.md); historical #218 evidence
was preserved before replacing this branch's handoff.

Completed integrated focused checks: **248 passed in 26.99 s** across source/GUI/
lock/correlation/metrics/package; after advisory-sync/acceptance merge, **122 passed
in 25.17 s** across online/offline/current-input/binary-only/lock paths. Raw logs:
`/tmp/pt-independent-integration-first-focused.log` and
`/tmp/pt-independent-integration-online-focused.log`. These explicit selections
overlap worker/independent review counts; none is a full-suite result.

Whole `python -m ruff check src tests tools` and `git diff --check` passed. General,
KB, calibration, Tier R corpus and report schemas regenerated without drift.
Deterministic tests reproduced source deadline/redirect, keyboard/focus, lock alias,
candidate chronology and metric arithmetic defects before fixes. Package security
review also reproduced a ZIP64 directory-bound bypass and malformed DEFLATE failure
mapping before repair; all seven concrete review findings now have regressions.
Worker QA receipts preserve exact original failures and limitations.

NOT RUN here: another `QT_QPA_PLATFORM=offscreen python -m pytest -q` full suite or
broad GUI stress/native build, because the user's latest instruction reserves
those processes to the existing qualification owners. Frozen #205 remains clean at
`f33e2a0a`. At 23:43 UTC the existing run exit receipt recorded **143** and the log
ended around 94% without a pytest summary: **NOT COMPLETE**, cause unknown. This
session sent no signal/restart; raw owner logs/exit receipt remain untouched. No
result is inferred from progress. Native #222/#224 and their logs/
worktrees/builds remain reserved and untouched. Hosted required current-head jobs,
main-relative scanner review, live sources, Windows/native/package/manual and
disconnected-bundle acceptance remain open. No live provider, target execution,
actual corpus/model fit, cost or prompt-cache evidence is invented.

Subsequent reviewed #236 (`8975c517`) refuses incomplete PE manifest leaves before
parsing closed XML prefixes: four baseline failures, 168 author and 197 independent
authored-byte passes (one actual launcher excluded). Combined affected PE/package
checks **257 passed, one deselected in 6.84 s**, log
`/tmp/pt-independent-integration-pe-focused.log`. No launcher or target executed.
Active next slices: saved-index candidate inspection, explicit consented Winbindex
metadata refresh and cache staging publication hardening; each needs independent
review and focused integration before its result enters this checkpoint.

Subsequent #237/#238/#239 are reviewed/published/integrated: metadata deadline,
exclusive cache publication plus review-discovered raw-fd cleanup, and exact-consent
metadata refresh. Combined checks **283 passed in 3.63 s**,
`/tmp/pt-independent-integration-index-focused.log`. SHAs/reviews are in the handoff.
Candidate snapshot and desktop metadata follow-ups remain separate.

Public #235 scanner query: one OPEN `pythonsecurity:S8707` issue
`AaGuFuc-a2s4H-WIcBuh` on package preflight CLI archive path, new security rating 3.
Independent triage found no unauthorized traversal in the explicit local CLI
surface; normal authorized disposition remains needed. Status/rules/gate and
suppression configuration remain unchanged.

Reviewed #240 (`bf366196` atop `5cdf0e83`) now supplies coherent saved-index
inspection/selection: an independently reproduced in-operation record replacement
cannot mix old pair decisions with new provenance. Author339, independent106 and
coordinator30 focused checks passed; integration **170 passed in 15.87 s**, log
`/tmp/pt-independent-integration-candidate-focused.log`. No actual download or
project creation is enabled by metadata-only candidate preview. #241 retains the
independent scanner boundary receipt; finding remains OPEN and gate not bypassed.

## Current evidence
2026-10-11: source inspection of pinned upstream revisions completed. Linux Qt offscreen desktop self-test starts and displays the synthetic project. Integrated Linux QA: 91 tests passed, 2 Windows-only tests skipped; Ruff and Qt offscreen desktop self-test passed. Domain, transport, worker, schema and UI tests are included. Synthetic fixtures and mocked providers verify wiring and validation, not real matching accuracy or model interpretation correctness.

## 2026-11-02 PR #153 advisory review follow-up

At PR head `0cf22c9520da6d2841d27c0aa8136f36657aecc6`, review found that every single native snapshot without a zoned date was labelled order-ambiguous, and that multiple unorderable snapshots could leave an edge from only one snapshot presented as current. A single snapshot no longer warns. When ambiguous same-month snapshots disagree on KB/CVE/product applicability, discrepant rows are retained as disputed with deterministic conflict IDs and a `REVISION_EDGE_CONFLICT` warning; they are not called current or superseded. The MSRC specification records this limit. No revision sequence is inferred from unverified values.

Other review controls: missing native fields resolve diagnostics to an existing parent pointer; the offline XML namespace audit now constructs prefix-to-URI pairs; context construction tries a JSON-locatable CSAF card when a preferred CVRF/XML card cannot be bound and explicitly reports when no card can be sourced. Added regressions cover these cases and preserve raw source dependencies.

Validation on the local PR #153 tree: `PYTHONPATH=.:src:tests QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_kbc_*.py` passed **1,054 tests**; whole-tree Ruff and `git diff --check` passed. The first focused run had transient failures because existing tests still expected disagreeing snapshots to remain current; the updated behavior and regressions pass in the final KB/CVE run. Current-head hosted checks and independent re-review are pending; this does not qualify the PR for merge or release.

## Repaired audit defects
- Ghidra rejected `runs/.quarantine-<uuid>/raw` with `Path element starting with '.' is not permitted`. Active and normalization-failed run directories now use `quarantine-<uuid>`. Preflight validates every resolved output ancestor, with an actionable error for dot-prefixed names and excessively long Windows output paths. The fake backend reproduces this exact rejection; native Ghidriff confirmation on Windows and clean-user reinstall remain release checks.
- Artifact storage could escape project roots: pure models and disk paths now reject traversal, absolute/drive paths and symlinks.
- Same-run evidence could be cited against the wrong function match: exact match/function and explicit neighbor associations are enforced.
- Repeated content-addressed contexts could conflict with global uniqueness: identical context/evidence can be shared; conflicting identities rejected.
- Backend module imports could be shadowed by project-local modules: configured trusted runtime cwd and removal of PYTHONPATH/PYTHONHOME.
- Windows process descendants require containment before running: suspended launch, Job Object assignment, kill-on-close then resume; failure terminates suspended child.
- Identical analysis result and failed runs needed separate transactional persistence rather than treating a directory as completed JSON.
- SQLite connections must remain on their creating thread; background project creation closes its connection before GUI reopens.
- Split/merged code view line offsets must map exact evidence lines rather than equal addresses/line numbers.
- Dynamic imported labels use plain text rather than automatic rich text.
- Large import parsing/normalization moved behind prepare/apply worker seam; atomic project changes on GUI thread.
- Ghidra/Python/pyghidra versions and dependency diagnostics are recorded, with unverified Java compatibility visible.
- Missing persisted instruction arrays are displayed as unavailable, never fabricated assembly.

- Unchanged Windows inputs were incorrectly rejected because path and open-handle ctime semantics differ: compare each source consistently, with native ChangeTime protecting against hidden edits.
- Large repetitive code could spend excessive time in line matching: bounded strategies and a disclosed linear fallback now cap the expensive path.
- Failed normalization after native execution needed quarantine and a persisted failed attempt; late cancellation cannot promote output.
- Export preview and actual bytes needed identical option handling and deterministic rendering.
- Optional Qt image/input plugins pulled unused PDF and virtual-keyboard dependencies into the freeze: custom desktop plugin collection now prevents those imports, with an executable-component rejection gate and post-build ZIP inspection.
- Qt wheels lacked redistributed license texts: exact upstream notice sources are vendored; the builder refuses missing required notices and excluded WebEngine/PDF collection.

- Native Ghidra workspace isolation: new regression tests require Ghidriff to receive an external private `--project-location` and `--gzfs-path`, check cleanup on success/failure, and preserve case-owned JSON/logs. Temporary engine workspaces should not be inside synced project directories; new Windows native compatibility must be rerun after this change.

- Ghidriff symbol-server behavior is now opt-in via an explicit saved GUI setting. The backend passes `--no-symbols` by default and records the choice in run provenance. Tests exercise both modes and reject ambiguous types. A passing no-symbols CLI fixture is not proof of OS-enforced network isolation.

- Local runtime discovery is a separate, read-only stdlib module with bounded direct-child scanning and no process execution. Setup prefills only unique existing candidates and preserves analyst-selected paths. This reduces manual path navigation but does not install or validate the full runtime; automated fixture coverage is distinct from real Windows/OneDrive acceptance.

- Native backend failure classifier maps supported error signatures to fixed actionable guidance (JDK mismatch, missing Ghidriff, Ghidra path, heap/disk/permissions), preserving original exit code and sanitized log. Unknown signatures retain the generic inspect-analysis.log message. Regression tests assert no tokens from raw upstream output are echoed.

- Offline bundle importer: strict versioned manifest/ZIP inventory SHA-256 checks, Windows path/type checks, per-user atomic staging/lock with cancellation/rollback, no network or payload execution in the install path, dedicated child-only Java environment. Synthetic payload fixtures verify importer plumbing, not a functional relocatable Ghidriff distribution. Spec-06 full disconnected Windows bundle acceptance remains pending.

## 2026-10-12 delivery session

- Cached-PDB `FileExistsError` under `--no-symbols` (PR #9): root cause traced in pinned Ghidriff `setup_project()` (skips `setup_symbol_server` then calls `get_pdb(allow_remote=False)`, which consults the persisted SymbolServerService) and Ghidra 12.0.4 `ApplicationUtilities.getDefaultUserSettingsDir` (`application.settingsdir`, then `XDG_CONFIG_HOME` on every OS). Fix: per-run `XDG_CONFIG_HOME` in private scratch. Native Windows CI matrix: plain Ghidriff with a persisted store **reproduces** the failure; PatchTrace analysis **passes** with the persisted store (with and without PDBs at the embedded path) and clean. The user's clfs.sys pair and Ghidra 12.1.4 were not available; the fixture is the compiled bounds-check DLL. A CI fixture regression (MSVC `/DEBUG` implying `/INCREMENTAL` thunks) was fixed with `/INCREMENTAL:NO`.
- Linux x86-64 onedir package: CI smoke on Ubuntu 22.04/24.04 offscreen and Xvfb/xcb (initial failure: missing Qt xcb libraries on runners; full list now installed and documented). Frozen Linux binary runs `rank` end to end locally.
- Offline installer (PR #7) security review: 8 defects fixed with regression tests (non-normalized/system install roots, junctions, PT-CANCEL, cleanup masking, zlib errors, extended device names, POSIX replace race, plan contract). Real relocatable runtime payload and air-gapped Windows acceptance remain open.
- Phase 2 enrichment (SPEC-07, PatchTrace-authored; supplied handoff schema/examples absent): B1 detectors, B2 WIL, B3 CVE normalization/transport/contextual ranking, B4 cache, additive storage, pipeline, CLI, desktop and report wiring. Independent review found 6 defects, all fixed with reproducing tests: cancelled stages cached as empty results (scores later dropped to 0); non-default CLI profiles shown as the default in GUI/export; cache hits not revalidated against live ownership; file-loaded CVE snapshots trusted for feature IDs and stale snapshots unreported; non-object weights traceback; stale rows recording the live revision. Storage tests also caught non-atomic DDL in Python's legacy sqlite3 mode (fixed with explicit `BEGIN IMMEDIATE`). Benchmark found the WIL stage never hit the cache when empty (fixed).
- CVE endpoints probed live once by the B3 implementer (2026-10-12): NVD CVE API 2.0 and MSRC `sug/v2.0` per-CVE; fixtures are trimmed real responses for CVE-2024-38063. No live fetch runs in tests. Model/transport success does not validate CVE relevance.
- Benchmark (`tools/bench_enrichment.py`, synthetic 10,000 pairs / 110,000 lines, 4 vCPU Linux container, Python 3.12.3): cold pipeline 6.6 s and 240 MiB peak RSS in a fresh process (objectives 10 s / 512 MiB met on this machine); derived-cache hit 3.1 s, **objective 500 ms not met** (dominated by input hashing and ownership revalidation, which are required for correctness). UI responsiveness at this scale not measured. Windows timings not measured.

- Release `v0.1.0-beta.80` (prerelease) built by CI from merge commit `0d22e9c` (PR #10), tag verified to point at that commit. Downloaded assets: `PatchTrace-0.1.0-windows-x64.zip` 47,682,397 bytes and `PatchTrace-0.1.0-linux-x86_64.tar.gz` 74,017,268 bytes; both `.sha256` sidecars verified locally. Extracted Linux artifact in a clean `env -i`: `--self-test` exit 0, `rank` on the synthetic sample returns `read_item` (score 26), `flags` exit 4 (no results), missing project exit 2. Windows ZIP: 452 entries, contains `PatchTrace.exe`, enrichment schemas and updated README; the Windows frozen self-test and `rank --help` CLI smoke ran in CI `qa (windows-latest)`. No hands-on Windows GUI session was performed.
- Remote branches already integrated into `main` but not deleted (the session's branch deletion was refused by the environment): `access-test-noprefix`, `claude/access-test-1791773355`, `claude/symbol-policy-isolated-settings` (#9), `feat/verified-offline-runtime-bundle` (#7), `feat/enrichment-contracts` (#10), `feat/enrichment-{signals,wil,cve,cache}` (in #10), `fix/*` (#2-#6), `feat/local-runtime-discovery` (#5), `codex/patchtrace-beta` (#1). Retained with unmerged work: `claude/patchtrace-cli-dotpath-spec-er6hha` (SPEC-05 CLI/config/build-provenance draft; its exit-code table conflicts with the Phase 2 contract and its config/buildinfo modules are not integrated).

## 2026-10-12 full code audit (5 areas) and repairs

Every fix has a test that fails before and passes after. Confirmed defects fixed:
- Runtime (A): URL credential redaction leaked partial passwords and missed non-HTTP schemes; backend probe failed whenever the interpreter wrote a stderr warning (wrong "install ghidriff" diagnosis); Ghidra discovery could miss installs in crowded folders; a scratch-cleanup failure turned a completed analysis into a failure (now bounded retries + warning); post-kill wait timeouts and output-inspection OSErrors escaped without failure.txt; quoted secret values and bare GitHub/AWS/Bearer tokens were not redacted.
- Core (B): project database creation was not atomic (failed create left an unusable folder); strict JSON accepted overflowing floats and raised untyped errors on huge integers; save accepted a foreign project or lower revision; public annotate could forge match-override records; failed-backup cleanup could fail on read-only files; backup publish had a POSIX replace race; service.project went stale after backup recovered interrupted runs.
- AI/reports (C): provider requests had no total deadline (slow-drip servers held them open, ignoring Cancel); Windows paths with spaces leaked usernames into reports; Markdown ranking cells could be broken by line breaks.
- Desktop (D): untrusted bundle names rendered as rich text in the install consent prompt; tooltips fed binary names, model summaries and signal rationales could render rich text; empty export destination crashed on format change; failed self-test leaked the project lock; corrupt numeric settings crashed window construction.
- Enrichment/CLI (E): BND missed Ghidra cast pointer arithmetic and `else if` guards; SIZE fired on decompiler temporary spills; WIL qualified whitespace/rename-only edits and treated string/comment text as sites; WIL qualifying-hunk recomputation was quadratic (121 s on a 4,100-site function, now ~1 s); cancelled correlate and Ctrl-C in JSON mode broke the exit/envelope contract; zero-pairing rank could never exit 4; misleading stale note for non-default profiles; quarantine could move a just-republished valid cache entry; leased entries could be evicted when the lease file failed; prune trash was unreclaimable; one failed or malformed provider response discarded the others; any CWE dispute blocked agreed CWEs; duplicate snapshots double-counted; cancelled rankings were published.
- CLI/GUI/export agreement for the default ranking: verified identical (rank, match, score, raw, evidence, status, config digest).

Documented hypotheses left open (not reproduced): POSIX killpg PID-reuse race, setsid descendants holding pipes, Windows environment block sort order, diagnostic phrase false positives, Ghidra-directory sys.path shadowing, duplicate upstream addresses in Ghidriff JSON, ignored extra modified-entry keys, undo limited to the latest correction, off-thread `prepare_*` reads of service state (safe while mutating controls are disabled), export overwrite without confirmation for typed paths, positional project-directory argument (unspecified). Windows-only confirmations pending: tooltip/QMessageBox rendering, read-only backup cleanup, scratch retry sufficiency, pid liveness and junction checks in the cache.

Phase 3a acquisition (SPEC-08, headless): Winbindex parsing, consented msdl download with blob-only redirect, quarantine and PE/PA30 identification, CLI `acquire search|fetch`. Manual live probe: afd.sys `D37888A1b2000` downloaded through the transport, 744,832 bytes, SHA-256 matched Winbindex. `delta.py` (msdelta ctypes) has not run on Windows. Desktop dialog not yet built.

- Phase 2 completion (PR #12): profiles and raw-output cache; native Windows CI `raw-cache-hit` ran real Ghidra 12.0.4 / Temurin 25 twice and verified the second run was a cache hit with byte-identical raw JSON and identical matches.
- Phase 3 (PR #13): N-way series, acquisition dialog, BinDiff/rz-diff secondary engines. Windows CI ran the msdelta `CreateDeltaB` → `ApplyDeltaB` round trip successfully. Two Windows-only test defects found by per-test CI jobs and fixed: a 64 MiB pytest parameter id stalled the Windows console (QA hung 18+ minutes), and a POSIX path literal in an rz-diff probe test. QA jobs are now capped at 30 minutes.
- Release `v0.1.0-beta.90` built from `7eea001` (tag verified): Windows ZIP 47,861,849 bytes, Linux tar.gz 74,215,035 bytes, both sidecar checksums verified after download; extracted Linux artifact passes `--self-test` and every headless command answers `--help` with exit 0. No live BinDiff/rizin run, no hands-on Windows GUI session.

## 2026-10-13 SPEC-26 alpha session (Claude Code)

Merged: #19 (recorded file overview), #20 (handoff docs), #21 (verified artifact byte seam), #22 (PE overview + Authenticode probe), #23 (Hex/Binary/Base64 providers), #24 (tooltip registry). Each merged only after its own green GitHub Actions run: Ubuntu and Windows pytest + Ruff, Windows onedir freeze, Linux package + 22.04/24.04 smoke, and the native Windows Ghidriff matrix.

Automated evidence (actual results):
- Baseline main `f0086f7` before work: Linux local 774 passed / 5 skipped, Ruff clean.
- PR #22 Windows `qa (windows-latest)`: 875 passed / 10 skipped. JUnit shows `test_native_unsigned_file_does_not_raise` **passed** on the Windows runner, i.e. a real `WinVerifyTrust` call on an unsigned temp file returned without error. This is not acceptance of signed/trusted/revoked samples.
- Integration branch (PE comparison in File overview, raw views, Authenticode row): Linux local 973 passed / 6 skipped, Ruff clean. Windows result: see the integration PR checks.

Release publication (handoff B1) root cause: run 38492874312 (commit `64fda061`) built and tested successfully but `softprops/action-gh-release` got HTTP 403 `Resource not accessible by integration` although the job token had `contents: write`. That commit added `.github/workflows/import-agent-skills-once.yml`. GitHub refuses to let `GITHUB_TOKEN` create refs/tags on a commit whose diff adds or changes workflow files (the token can never hold the `workflows` permission). The next main runs 101 and 103 published `v0.1.0-beta.101` and `v0.1.0-beta.103` normally, and the repository has no rulesets. Conclusion: not a standing permission problem; no settings change required. Expect the same 403 on any future main push whose head commit edits `.github/workflows/*`; that run's ZIP stays available as an Actions artifact. A maintainer PAT with `workflow` scope would avoid it but is not recommended for an automated job.

Not performed in this session: interactive clean-Windows GUI walk-through, DPI/theme checks, signed/trusted/revoked Authenticode samples, fuzzing beyond the synthetic hostile-PE fixtures, live Ghidriff on new inputs beyond the CI fixture matrix.

## Acceptance gates
- Windows unit/Qt suite: 93 passed; Ruff passed ([run](https://github.com/djshellshoxxx/patchtrace/actions/runs/38126515355)). Frozen desktop smoke passed on the final curated package ([run](https://github.com/djshellshoxxx/patchtrace/actions/runs/38127040440)). That run repeats 93 Windows passes and 91 Linux passes with 2 Windows-only skips.
- Real native Ghidriff known bounds-check DLL patch: passed ([run](https://github.com/djshellshoxxx/patchtrace/actions/runs/38126512208)). Python 3.12.10, Ghidra 12.0.4, Temurin Java 25; pinned Ghidriff revision from research. Both MSVC-built DLLs were statically analyzed, never executed. One modified change record contains the expected check. This single fixture does not establish general matching accuracy.
- Live Ollama and remote provider paths: unverified; no configured model/credentials supplied. Mocked HTTP request/envelope/schema tests are present. Follow SPEC-03 acceptance procedures; successful transport does not validate model truth.
- Clean Windows interactive resize/keyboard/code/evidence test: pending actual package and user testing.
- Matching precision/recall, held-out real patch corpus and resource targets: unmeasured. No accuracy or speed benchmark claimed.
- Dependency archive audit: CI ZIP downloaded and inspected; SHA-256 matched, all listed files existed, 47 Core/GUI attribution pages and required notice texts were present; two Qt Network attribution pages were subsequently added for the linked Network DLL. Curated package: 46,370,158 bytes, 417 ZIP entries; SHA-256 `c5783e25146029a741a5450209638a15cf9f955e6e24582c04277325079e95b2`. Qt Core/Gui/Network/Widgets and Windows/offscreen/style/network/TLS plugins remain. No PDF/WebEngine/QML/Quick/virtual-keyboard executable components. Final release is rebuilt from the merged commit and has its own accompanying checksum.

## Practical limits
Provider cancellation is cooperative around network reads; an active read can wait until the 120-second timeout, and transmitted remote context cannot be recalled. Native decompiler crashes/timeouts preserve logs and quarantined output; process isolation is not an OS sandbox. Backend output contracts are pinned to inspected Ghidriff; unknown output fields fail clearly. Only static PE AMD64 is initially supported. Call graph visualization, runtime debugging, automatic reproduction, auto-download and additional formats are deferred. The synthetic sample is authored and explicitly labeled.

## 2026-10-14 rz-diff stream separation
`jobs.run_process(separate_streams=True)` drains stdout and stderr on independent bounded threads (Windows: second inheritable pipe, Job Object containment unchanged). rz-diff parses stdout only and reports stderr on non-zero exit. Local Linux: 981 passed, 6 skipped; Ruff clean. Windows pipe path and real rizin remain unverified until CI/live runs.

## 2026-10-14 full code audit
See `docs/plans/audit-20261014-and-next-phase.md` for findings, fixes, deferred items and the next-phase plan. Local Linux: 1004 passed, 6 skipped; Ruff clean. Windows pytest, freeze and native Ghidriff results are those of the PR's CI run; clean-profile interactive GUI acceptance remains unverified.

## 2026-10-14 enrichment hardening (SPEC-07h correctness slice)
Re-baselines (deliberate): `signals`/`wil` group keys change because `_TEMP` is now a closed table (H6); SignalSet/ranking status semantics (H3: missing code is `partial`, one-sided pairings no longer degrade the run); contextual identifier points need binary evidence (H4, e.g. a signal-less pairing with a matching name no longer gains +16); `select_latest` merges providers (H13). Stage versions signals 2, wil 2, ranking 2, contextual 2 invalidate derived caches and stored rows by design. Local Linux: full suite and Ruff clean; Windows CI not run from this worktree.
## 2026-10-14 enrichment hardening H7 / H2 / H8 / H9 / H10
Local Linux automated evidence only (see PR checks for CI): new tests `test_child_env.py`, `test_history_bound.py`, `test_raw_single_copy.py`, `test_cancel_latency.py`, `test_nvd_pacing.py`; `test_enrichment_intelligence.py` re-baselined deliberately (NVD retry sleeps now include 6 s keyless pacing top-ups; keyed 403 is retried and ends as recoverable `PT-ENRICH-NETWORK`).
- H7: `backend.build_child_env` + `BackendConfig.restrict_env` / `env_passthrough` (Setup: checkbox and field). **Default OFF**: the Windows variable list is unvalidated by a native run, so the allowlist stays opt-in; `PATCHTRACE_CHILD_ENV=inherit` overrides. Open gate: native Windows `raw-cache-hit` job with `restrict_env=True` and a seeded `JAVA_TOOL_OPTIONS`/fake token probe; flip the default only after it is green. rz-diff CLI path still inherits (builder supports `for_tool='rizin'`, not wired).
- H2: history keeps newest 100 rows / 512 MiB, never the current snapshot or the newest row of each revision; identical-hash re-saves add no row. Not done: pre-prune verified backup.
- H8: backend output inside `runs/<id>/` is reused in place; staged import copies are deleted on `discard_import`. Not done: startup cleanup of duplicate files in legacy projects.
- H9: `netutil.interruptible` (daemon thread, cap of 4 abandoned) on CVE and LLM provider connects/reads; cancel observed in about 0.1 s in fake-blocker tests. Not verified on native Windows sockets.
- H10: NVD spaced 6 s keyless / 0.6 s keyed, 403 from NVD retried with backoff, overall deadline (`expected + 120 s`), CLI consent preview prints the expected duration. NVD's real enforcement is unverified live.
## 2026-10-14 CI additions: live rizin and frozen EXE smoke (not yet run in CI)
Live engine acceptance (not mocked): `.github/workflows/live-rizin.yml` (workflow_dispatch plus paths-filtered push/PR) installs rizin 0.9.1 on ubuntu-latest (`rizin-v0.9.1-static-x86_64.tar.xz`) and windows-latest (`rizin-windows-static-v0.9.1.zip`), verifies the pinned archive SHA-256 and fails closed on a missing, malformed or mismatched hash, builds a synthetic PE pair from `tests/fixtures/old.c`/`new.c` (MinGW on Linux, MSVC on Windows; no Microsoft binaries), runs `tools/live_rzdiff_check.py` (probe, version equals pin, `-C -j -t` present in `-h`, `run_rzdiff` match count > 0, hash round trip) and uploads `live-rzdiff-<os>.json`. Its results are never summed with pytest counts.
- Pinned SHA-256 gap: GitHub's API and release page were not reachable from the authoring session, so no upstream-published digest was compared. The two digests in the workflow were computed by downloading the official release assets on 2026-10-14 (Linux 137,626,404 bytes `9102249a...e8cf`; Windows 115,391,593 bytes `2d14e0a6...1d28`). Trust is therefore trust-on-first-use; cross-check against the release's displayed asset digests before treating the pin as independently verified.
- Unverified until a CI run: the extracted layout (`bin/rz-diff` on Linux; `rz-diff.exe` located by search on Windows), MinGW/MSVC build of the fixtures, whether `-h` lists `-C -j -t` verbatim, and `match_count > 0` on a one-function DLL pair. Rows under "Live engine acceptance (not mocked)" are added by hand from the artifact after green runs on both OSes; none exist yet. BinDiff remains blocked (no licensed install on runner).
- Frozen EXE smoke: `tools/frozen_smoke.py` (A1 `--help` for every registered command (`names()`), A2 unknown command exit 2, A3 missing project exit 2, A4 `--self-test` exit 0 and temp directory removed) runs as a Windows step in `qa-windows.yml` after `tools/build_windows.py` (which already runs the frozen `--self-test` and `rank --help`). Verified locally on Linux only against `python -m patchtrace` as a stand-in; the frozen `PatchTrace.exe` run is verified only by Windows CI. A5 to A12 remain open.

## 2026-10-14 Live engine acceptance (not mocked) and acceptance-automation additions
| Engine | Where it ran | What the workflow asserts (`.github/workflows/live-rizin.yml`, `tools/live_rzdiff_check.py`) | Result |
|---|---|---|---|
| rz-diff, rizin 0.9.1 | PR #32 workflow run 38525316107, jobs `live rz-diff (ubuntu-latest)` and `live rz-diff (windows-latest)` | Pinned archive SHA-256 verified before install (fail closed); fixture pair built from `tests/fixtures/old.c`/`new.c` (MinGW on Linux, MSVC on Windows); the two fixture SHA-256 differ; `probe` reports supported and version equal to the 0.9.1 pin; `rz-diff -h` mentions `-C`, `-j` and `-t`; `run_rzdiff` returns at least one function match; the match set's old/new hashes equal the fixture hashes | Passed on both jobs, as reported by the maintainer for that run. This session did not re-fetch the run; the per-OS `live-rzdiff-<os>.json` artifact holds the match count, output hash and duration |

Scope of this row, stated narrowly: real-tool acceptance of rz-diff 0.9.1 on one synthetic CI fixture pair per OS. Both pinned archive digests are trust-on-first-use (computed from the official release assets on 2026-10-14, not compared with an upstream-published digest). It does not show match correctness or accuracy, agreement with Ghidriff, behaviour on real Windows binaries, or any BinDiff behaviour (BinDiff live run: still open). The workflow is paths-filtered, so a pass applies to the SHA it ran on and is not carried to later SHAs.

Acceptance automation added (verified locally on Linux against `python -m patchtrace`; the frozen `PatchTrace.exe` and native Windows runs are verifiable only in CI):
- `tools/frozen_smoke.py` now also covers A5 (`rank --json --dry-run`: one JSON document, exit 0/4), A10 (spaces, Cyrillic, CJK, OneDrive-style and a 200-character path through the CLI; ranking equal to the ASCII baseline, compared on rank, pairing id, score, raw and function because match ids are random per project) and A6s (a 3-build series through `series create`/`series chains --json` with synthetic Ghidriff results imported, so no Ghidra runs). Not covered: A6 with a real `--run`, A7-A9, A11, A12, trailing-dot/space and reserved-name (`CON`, `NUL`) paths (Windows cannot create them through ordinary APIs).
- `tests/test_acceptance_smoke.py` runs the same checks against the source CLI on every OS (so on `windows-latest` natively, without the frozen package) plus a no-Qt import check of every command's `--help`.
- `tools/milestone_notes.py` renders spec section 4 release-notes text from supplied results only. Anything not supplied renders as not run or open; manual M01-M18 stay not-run without a pass and an evidence link. The `release` job now writes it to `body_path` (checkout with `persist-credentials: false` and a `qa-*` artifact download added; `permissions`, `needs` and gates unchanged; on generator failure the old static text is used). The qa job result is applied to both OS rows because the matrix reports one aggregate.

## Second audit fixes (2026-10-14, items 3-13; local Linux evidence, CI pending)
- `tests/test_audit2_fixes.py` plus one case in `tests/test_ui_setup_dialog.py`. Restricted child env keeps inherited `JAVA_HOME`/`JDK_HOME` (ghidra only, when no private JDK is configured); `env_passthrough` now rejects `PYTHON*`, `LD_*`, `DYLD_*`, `BASH_ENV`, `ENV`.
- Stored default/profile pipeline rows are served only when every recorded stage version equals `STAGE_VERSIONS` (a v1 row after the v2 bump reads as stale).
- `extension_version` 2 is understood; stores are still created at 1 and stamped 2 only when the first `engine-run` or `secondary/2` row is written, so v1 clients keep full access to projects that never used SPEC-28. `load_secondary` skips an invalid or hash-corrupt row with a warning; `cache_snapshot` treats a corrupt engine-run row as a miss.
- `engine-run` rows are pruned to the newest 8 per engine/pair after each run (rows tied to a stored set are kept) and are the first thing the 128 MiB cap fallback evicts; `secondary-matches` is never evicted. `secondary run` records a storage failure (row over 32 MiB, cap) as a failed EngineRun plus warning for that engine only (exit 3); `PT-SECONDARY-INPUT` from engine output is exit 3.
- Rank: `pipeline.prepare_publish` makes the verified pre-enrichment/pre-retention backup on the worker thread (own read-only connection, `.part` then rename); the owner-thread backup is skipped only when a backup of the identical snapshot exists, otherwise it still runs. Not done: the publish itself still runs on the GUI thread (it must use the owner connection); an empty NVD key variable is now no key.

## C6 multi-engine evidence panel (2026-10-14, builder worktree, Linux only)

| Check | Evidence | Result |
|---|---|---|
| Full gate | `QT_QPA_PLATFORM=offscreen timeout 900 python -m pytest -q` run twice on the C6 branch | 1318 passed, 6 skipped, both runs |
| Lint | `python -m ruff check src tests tools` | clean |
| Qt flake / abort check | `tests/test_evidence_ui.py` + `tests/test_tooltips.py` run 20 times in a row with `PYTHONFAULTHANDLER=1` | 20/20 green (65 tests each), no SIGABRT |
| Perf, pure build | `tests/test_evidence_perf.py`: 10k matches, 2 secondary engines, `build_view_model` | about 1.0 s locally (gate 7.5 s = 5x the 1.5 s target) |
| Perf, Qt model | `test_large_models_stay_lazy_with_data_call_ceilings` (900x500 panel, offscreen, PySide6 6.12.0) | data() calls = visible cells (16) for first paint and filter, 0 for sort, at both 10k and 100k rows; 10k reset/sort/filter about 28/9/9 ms; 100k about 130/122/20 ms |

Scope: offscreen Linux evidence only. Not covered and still open (C8): Windows runs of these tests, real screen-reader announcements (Qt offscreen reports `QAccessible.isActive()` False), 125/150/200% DPI rendering, glyph fonts on Windows, contrast against the live palette (only palette constants are checked), frozen-EXE dock smoke, and the GUI-thread cost of reading very large stored secondary sets (SQLite is thread-confined, so `load_secondary` stays on the GUI thread).
## 2026-10-14 C4 BinDiff execution (mocked evidence only)
- Automated (Linux authoring host, fake `bindiff` over `tests/fake_exe.py`, fake BinExport stand-ins): probe table, every SPEC-29 §6 failure kind reachable, exact argv, allow-listed env (sentinel secrets absent), private workdir removed, raw `.BinDiff` preserved before import, timeout/cancel kill the process tree (heartbeat stops), reversed/unbound inputs refused before spawn, explicit override recorded in provenance, CLI exit codes 0/2/3 and previous set kept on failure. These are not live compatibility evidence.
- Importer fuzz found a real defect: corrupt text in a `.BinDiff` raised an uncaught `UnicodeDecodeError`; now `PT-SECONDARY-INPUT`.
- Live BinDiff: **blocked**. `tools/bindiff_pin.json` has no verified asset URL/size/SHA-256 (v8 release asset names not obtainable here), so `live-bindiff.yml` records `blocked` (`pin-missing`) in its summary; no real BinDiff, no real `.BinExport` pair, no live golden. Not run on Windows CI yet.
- Shared env allow-list: rz-diff now uses `backend.build_child_env(for_tool='rizin')` via `engine_env` (keeps PATHEXT, ComSpec, TMPDIR, LANG, LC_*, RZ_*); `tools/live_rzdiff_check.py` runs through `run_engines`; live rizin job must be re-run to confirm on both OSes.
## C9 calibration build (2026-10-14) - synthetic evidence only
No real-data claim: every number below comes from generated worlds with known ground truth; no Microsoft binary, label or engine output was used, and no artifact ships (`display_level()` returns 'ordinal').
- Local Linux, Python 3.13: `QT_QPA_PLATFORM=offscreen python -m pytest -q` = 1347 passed, 6 skipped (pre-existing skips); `python -m ruff check src tests tools` clean. Calibration subset: 116 passed (tests/test_calibration_{runtime,math,metrics,cv,tools}.py).
- scikit-learn 1.9.1 (optional `calibration-dev` extra, installed locally only): weighted L2 logistic within 1e-4 relative at C in {0.05, 1, 100}, isotonic knots equal, Platt within 1e-3. Without scikit-learn these 3 tests skip (CI default).
- Simulations: well-specified world OOF ECE excess over null within 0.02, slope/intercept CIs contain 1/0, LTT-certified tau has true precision >= 0.95; planted lineage leakage: random-split AUC exceeds grouped by > 0.15 (observed 0.825 vs 0.511); lineage shift fails the shift criterion; overconfident model fails H1 (ECE excess and slope); inverse-probability weights recover population precision; pipeline artifact/report byte-identical on rerun and under row permutation (same platform).
- Not verified here (CI/Windows/real data only): cross-platform byte-identical report SHA; Windows run of the calibration tests; frozen-EXE loading of a bundled artifact (none exists); any Tier R or Tier W result; G0-G3 on real data (all `insufficient-data`).
## 2026-10-14 C3 BinExport2 support (SPEC-10b) - automated evidence (Linux only) and open gates
- Re-verified pin: `protobuf` 7.36.2 is still the latest release on PyPI (2026-09-17). Wheel SHA-256s: win_amd64 `a300819d...d353`, manylinux2014_x86_64 `89f23aa5...bfd2`; full list in `third_party/notices/protobuf-7.36.2/MANIFEST.txt`. Installed with `--only-binary=:all:`; `api_implementation.Type()` reports `upb`.
- Measured on Linux x86-64 (CPython 3.13.16):

| Measurement | Result |
|---|---|
| 13.35 MiB / 2 M-record DoS-shaped file | Pre-scan 1.34 s, parse 0.08 s, checker 0.78 s. VmPeak 137 MiB, RSS 126 MiB. |
| Worker caps (`tools/qa_binexport_memcap.py`, `accept_binexport`) | 48-120 MiB give `worker_oom`; 140 MiB and above succeed. |
| upb under a cap | Raises `DecodeError("Arena alloc failed")`, not `MemoryError`. |
| pydantic-core under a cap | Aborts with SIGABRT. Classified as `worker_oom` from its stderr text. |
| `bytearray` child under the cap | Gets `MemoryError`. |

- Linux frozen build: the `_upb/_message.abi3.so` inventory guard passed (412 KiB delta). Frozen smoke: 30/30 PASS, including B1/B2 through the frozen self-spawned worker.
- Tests added: 8 descriptor, 25 pre-scan, 48 checker (one per reason slug), 26 pipeline/snapshot/identity, 28 isolation, 3 CLI, 9 property/boundary (hypothesis 2000 + 1000 + 150-example runs), 7 fixtures.
- Fuzz: `tools/fuzz_binexport.py`, 60 s random-mutation run: 1.6 M inputs, 0 findings. Atheris was not installed.
- All goldens are synthetic: 4 files bound to `synthetic_pe()` hashes, with `PROVENANCE.json`. None of this is live-compatibility evidence.
- Open: the Windows CI run (U7 child behaviour at `ProcessMemoryLimit`, `PeakProcessMemoryUsed`, idle commit of the frozen worker, frozen `PatchTrace.exe` B1/B2, size delta, AV). Also open: real Ghidra/IDA goldens (U1, U3, U5, U6, U9, U12) and the CI workflow steps (`pip check`, pin + upb assertion step, nightly Linux fuzz).
- Unreproduced fatal interpreter error. One of 15 full `pytest -q` runs on this branch ended in a Python fatal error: the faulthandler `Extension modules: shiboken6, PySide6.QtCore/QtGui/QtWidgets/QtTest, google._upb._message` line was the last output. The traceback was lost because the output was piped through `tail -1`. Attempts to reproduce found no crash:
  - 13 further full runs of this branch;
  - 40 runs of the in-process BinExport tests (about 126 k hypothesis inputs);
  - a 7.44 M-input in-process `inspect_bytes` stress with the input recorded before each parse;
  - 8 full runs of the base commit `29a4d3f`.

  Cause unknown, whether Qt teardown flakiness or upb (T3). Production parsing runs only in the capped worker, where a crash surfaces as `worker_crash`. Re-run CI with `python -X faulthandler -m pytest` and keep full logs.

## 2026-10-14 C4 follow-up: real BinDiff 8 measured and run (Linux, local container; not a CI run)
Real tool, not mocked, but only in this session's Linux container (uid 65534, environment built from scratch). Every input pair is SYNTHETIC (the stdlib encoder `tests/bindiff_live_pair.py`, or C3's committed synthetic fixtures), so this is real-tool behaviour on synthetic input, not real-driver (Ghidra/IDA export) evidence. Nothing ran on Windows. Supersedes the "Live BinDiff: blocked" line of the C4 block above for Linux only.

| What ran | How | Result |
|---|---|---|
| Asset re-verification | fresh downloads of `bindiff_8_amd64.deb`, `bindiff8.msi`, `bindiff_8_amd64.deb.asc` from the v8 release into a new directory | 62,663,460 B `821990e3…4dda`, 72,237,056 B `688831e4…b15f`, 819 B `1efbb4c6…f0f5`: identical to the research note. Same egress proxy, GitHub API 403, no upstream digest, `.asc` not verified: trust-on-first-use |
| Provisioning | `tools/provision_bindiff.py --os linux` (its own download, stdlib ar+tar, outside the repo tree) | passed: 117 files, 50 dirs, 3 links skipped; regular-file tree byte-identical to `dpkg-deb -x`; `opt/bindiff/bin/bindiff` `eb0a88eb…d0fb` equals the pin |
| CLI contract | direct runs | `--version` exit 0 `BinDiff 8 (@568181968, Sep 25 2023)`; `--nologo --help` exit 1, stdout only; no `--primary` exit 1 `Need primary input`; `--primary` alone prints usage and exits 0 with no file; non-database file at the target name exit 1 `file is not a database` |
| Config isolation | one-step `function_matching` list as user config (`$HOME/.bindiff/bindiff.json`) and as machine config (`/etc/opt/bindiff/bindiff.json` in a private mount namespace; host `/etc/opt` untouched) | without `--config`: 19 matches, 85.34% in both cases; with `--config` `{}`: 20 matches, 97.19% = baseline in both cases. A user `log.to_file` config wrote nothing in either case |
| Environment / network | strace, `unshare -n`, no `HOME` | zero socket/connect calls from bindiff; identical result in an empty network namespace and without `HOME`; `$HOME/.bindiff` created (empty) |
| Kill hazard | SIGKILL about 50 ms after the output appeared (100k-function pair) | 53,248-byte file, valid header, 7 tables, 0 `function` rows (no journal left in that run) |
| Live harness | `tests/test_live_bindiff.py` with `PATCHTRACE_REQUIRE_LIVE_BINDIFF=1`, `PATCHTRACE_LIVE_SYNTHETIC_PAIR=1`, pinned version text; after rebasing onto the C3 integration head the synthetic files go through C3 `accept_binexport` inside `BinDiffAdapter` (production path) | passed (four runs, the last on the rebased head with C3 acceptance): probe and pinned version; reversed pair refused before spawn; end-to-end through `run_engines` + `BinDiffAdapter` 20 of 20/21 matched, similarity 97.19%, raw `.BinDiff` preserved once, the two patched functions flagged; cancel at the first output byte (out/ held the 0-byte database and a 512-byte journal) and a 0.5 s timeout both discarded the output unread and removed the workdir; `unshare -rn` gave the same 20 matches |
| C3 fixtures | C3 branch's committed `synthetic-{older,newer}.BinExport` through `BinDiffAdapter` | ok, 3 of 3/4 matched, similarity 87.47% |
| Resources (synthetic) | wall clock and peak RSS | 2k functions 0.08 s / 17.6 MiB; 20k 0.9 s / 77 MiB; 50k 2.7 s (first output after 1.9 s) |
| MSI static inspection | `msiextract`, PE header and import parse (no execution) | `ProgramFiles/BinDiff/bin/bindiff.exe` 3,396,896 B `b1d4844d…47dd`, PE32+ x86-64 console; imports `VCRUNTIME140_1.dll`, which the MSI does not ship |

Committed from this run: the real v8 `--help` text and the real v8 `.BinDiff` + stdout produced on the synthetic pair (`tests/fixtures/secondary/bindiff-8-help.txt`, `bindiff-v8-real-on-synthetic.*`, provenance JSON). Still live-only/open: the GitHub `live-bindiff` run (Linux required leg and the advisory Windows leg: `msiexec /a` layout, `bindiff.exe` start, VC++ runtime on `windows-latest`, Windows config paths and network), real-driver runtime/memory and `executable_id` formats (U8/U9), and the independent pin re-hash plus `.asc` verification.

### [K:28a-28b] CSAF engine QA (2026-10-14, local Linux worktree; synthetic only)
- Automated: 188 `tests/test_intel_*.py` tests (validator, normalization, lexicon, hypotheses, anchors, identity, applicability, transport, discovery, storage, schemas), all on SYNTHETIC fixtures; every network test uses a fake opener. These are not live evidence.
- BLOCKED live sources (egress policy 403): msrc.microsoft.com, docs.oasis-open.org, cwe.mitre.org. OASIS normative text and schemas came from the OASIS TC repository (hashes in docs/schemas/intelligence/oasis-csaf-2.0/NOTICE.md).
- Known gaps: CVSS (6.1.8-6.1.10), CWE catalog (6.1.11), language registry (6.1.12), PURL (6.1.13), optional tests other than 6.2.1/6.2.20, OpenPGP signatures, ROLIE feeds; Windows runs not performed.
### [W:tier-w-w1] Tier W local-only corpus (SPEC-33), 2026-10-14 - synthetic/self-made evidence only
- Network: winbindex.m417z.com and msdl.microsoft.com BLOCKED from the build sandbox (egress proxy CONNECT 403, one attempt each); all network code is tested only against the recorded afd.sys fixture and fakes. No Microsoft binary or PDB was fetched, parsed or committed.
- Real tools on self-made input (not Microsoft evidence): clang 18.1.3 + lld-link built the committed fixtures byte-reproducibly; `llvm-pdbutil` 18 output agrees with the stdlib MSF reader on names, RVAs, sizes and the ICF alias; a manual Ghidra 12.0.4 headless run (Jython 2.7.4, PDB force-loaded, no symbol server) gave function sizes equal to the PDB code sizes (not yet a committed live test).
- Guard: the repository-wide Tier-W/Microsoft check runs in tests/test_tier_w_guard.py on every test run.
### [T:core] SPEC-29 tools capa/FLOSS/diec (2026-10-14, builder worktree, Linux only)
| Check | Evidence | Result |
|---|---|---|
| Upstream CLI/JSON verification | pinned source (PyPI sdists flare_capa 9.4.0 `c4f421ab…`, flare_floss 3.1.1 `4f74458b…`, digests equal PyPI's) + real `--help`/`--version` | flags and schemas in spec T1-T5 |
| Real runs on SYNTHETIC PE pairs (Ubuntu 24.04, `unshare -rn`, private HOME/TMPDIR) | capa 9.4.0 linux, FLOSS 3.1.1 linux, diec 3.21 (24.04 deb + Qt 5.15.13 Core/Script) | goldens `tests/fixtures/intel_tools/` (manifest.json); not evidence about real binaries |
| Asset SHA-256 (trust-on-first-use, one download, GitHub API 403) | capa linux zip 47,477,971 B `07800a1d…81e4`, windows zip 35,994,071 B `670ab1a5…3bb5`; FLOSS linux 40,571,555 B `40c05a86…2666`, windows 31,580,022 B `6c71089b…c2fb`; DiE 22.04 deb 11,806,884 B `c59e2fca…6007`, windows zip 25,197,854 B `078f2934…b3b9` | pin file not yet written (deferred) |
| DiE databases (tree/1 digest) | linux deb `301b24a7…2b86`, windows zip `a862337e…dda` (CRLF-only differences, 1511 files) | in `diec.KNOWN_DATABASES` |
| Unit tests | `tests/test_intel_tools_common.py`, `tests/test_intel_tools_parsers.py` | 30 passed |
| Not run | fake-executable runner tests, CLI, provisioning, live workflow, Windows, Ghidra backend | BLOCKED/deferred (next wave) |
### [D:known-answer-factory] SPEC-32 factory evidence (local, Linux, 2026-10-14; not CI, not Windows)
Toolchain: Ubuntu clang/lld 18.1.3, LLVM 18 tools, mingw-w64 gcc 13-win32 (apt), rizin 0.9.1 pinned asset (sha256 9102249a...e8cf). Synthetic tests compile C inside pytest (`tests/test_tier_r_factory.py`); they are factory evidence, not engine evidence. Real-source run: zlib v1.3 -> v1.3.1 fetched by pinned commit (09155eaa, 51b7f2ab; licence sha256 845efc77...3243), mingw-gcc O2: 128 project functions = 60 byte-identical, 62 address-only, 2 changed (inflateSync, deflateCopy), 9 ambiguous (inactive LIT_MEM `#ifdef` edits, ERR_MSG macro, constprop clones), 1 added (gz_intmax). msvc-free builds are byte-reproducible across scratch directories (template suite and synthetic two-file project). Not run: rz-diff/BinDiff/Ghidriff scoring (evaluator deferred), Windows leg.
### [B:hardening] Phase D track B (2026-10-14, builder worktree, local Linux only; Windows/CI not run)
- Automated (mocked or synthetic, not live evidence): `tests/test_prune_backup.py` (H2: 9 of 10 red on the pre-change code), `test_raw_legacy_cleanup.py` (H8: 8 red), `test_enrichment_p1_gaps.py` (B1/WIL truncation, `validate_location`), `test_algorithm_digests.py`, `test_identity_equivalence.py` (byte-identical identities vs the original implementation), `test_enrichment_perf.py`, `test_rzdiff_cli_env.py` (already wired: green on first run), `test_live_nvd_probe.py` (recorded 2026-10-12 provider fixtures through the real CLI parsing path, fake transport).
- Deliberate re-baselines: every derived stage id gains an `algorithm` digest and pipeline rows record `algorithms`, so caches miss and stored rankings are recomputed once ("computed by an older PatchTrace version"); truncated pairings become `partial` in B1 and WIL.
- Benchmark `tools/bench_enrichment.py --repeat 3` (synthetic 10,000 pairs / 110,000 lines, best of 3, same shared 4 vCPU Linux container, Python 3.13.16): before (branch base `5dfc17f`) cold 11.06 s, derived-cache hit 4.49 s; after cold 8.95 s, hit 1.79 s; peak RSS about 775 MiB both. **Objective 500 ms still not met**: strict re-validation of the cached records (about 0.35 s with the collector paused) plus view rebuilding, ownership revalidation and ranking remain, by design. Host is noisy (other agents); earlier 4 vCPU figures (3.1 s) came from another machine. Windows timings unmeasured.
- Live NVD/MSRC probe, run once from this container 2026-10-14T10:39Z: **BLOCKED** (no direct DNS/egress: `gaierror` for both hosts). First real result must come from the `live-nvd` workflow (manual or weekly); none exists yet.
- Full suite: see the PR/integration run; local runs listed in the builder report.
### [G:bindiff-gui-setup] Phase D track G BinDiff GUI setup (2026-10-14, builder worktree, Linux offscreen only)

| Check | Evidence | Result |
|---|---|---|
| Full gate | `QT_QPA_PLATFORM=offscreen python -X faulthandler -m pytest -q`, twice | 1883 passed, 6 skipped, both runs (LIVE ACCEPTANCE BLOCKED: bindiff, as before) |
| Lint | `python -m ruff check src tests tools` | clean |
| Qt abort check | `test_ui_engine_setup.py` + `test_tooltips.py` + `test_evidence_ui.py` listed 20 times in ONE pytest session (`--keep-duplicates`, `PYTHONFAULTHANDLER=1`) | 1900 passed (20 x 95), no SIGABRT |
| Validation path | REAL C3 `accept_binexport` worker on the committed SYNTHETIC fixtures: valid pair, swapped, foreign SHA-256, MD5 id with/without the confirmation, same file, oversized (sparse 256 MiB + 1), architecture mismatch, cancel | as specified; synthetic input, not live evidence |
| Probe / run | FAKE `bindiff` launcher (mocked): pinned, other v8 build, newer major, v7, missing option, no version, relative path; GUI run end to end, GUI provenance equals the CLI's on identical inputs, C6 Cancel stops a hanging run | as specified |
| Responsiveness | GUI-thread 20 ms heartbeat during a real C3 validation (max gap < 0.5 s), probe/validate slots < 0.25 s, `changed` emitted at most 3 times per probe+validate | passed |
| Regression | unconfigured panel vs `EvidencePanel(bindiff_setup=False)`: identical widget states through E0-E6/run; same Engines page minimum width; C6 widgets keep width and x position at 680x600 and 460x420 | passed |

Found and fixed while building: a toggle in the run-controls row widened the Engines page minimum (440 to 533 px); a page-level scroll area clipped the bottom rows (Qt height-for-width); the BinDiff engine row kept a stale "not configured" reason until a reload; a late worker result after the dock was deleted raised in a Qt slot (red test first). Not verifiable here: Windows runs, real BinDiff/Ghidra exports through the GUI, DPI rendering, screen-reader output.
### [S0a:contracts-store] SPEC-31 S0a (2026-10-14, Linux container, Python 3.13.16; synthetic data only)
- `tests/test_unified_{contracts,keys,store}.py`: 82 passed; `ruff check src tests tools` clean. Covers schema round trips, every invalid example (02 s8 list plus extras) rejected for its reason, regenerate-and-compare of all generated schemas (pre-SPEC-31 schemas byte-identical: additive only), key determinism across processes and hash seeds, `test_unified_rows_survive_enrichment_retention`, `test_old_reader_ignores_unified_kinds` (no `extension_version` bump).
- Not verified here: Windows (CI) and Python 3.12 (CI pin); no live data involved.
- Full gate once on 420e9f2: `QT_QPA_PLATFORM=offscreen python -m pytest -q` 1908 passed, 6 skipped (live BinDiff BLOCKED: not installed), 160 s.
### [AM1:kb-amendments] KB plan amendments A-5, A-6, A-10, A-12 (2026-10-14, local Linux worktree on 059c8b1, Python 3.13.16; synthetic data only)
- Red first, then green. `tests/test_enrichment_kb_kinds.py` (2 tests): failed with `unknown enrichment kind`; a scratch-copy mutation (`kb-context` added to `DERIVED_KINDS`, and separately the six AM1 kinds removed from `KINDS`) fails both tests, so they have teeth. `tests/test_backup_sidecars.py` (5 items): 4 failed before the change (sidecars missing from the backup; a restored project lost its CSAF advisories with `PT-INTEL-INTEGRITY ... missing or unreadable`; a symlink under `kb/` or `intelligence/` was silently ignored), the layout-unchanged test passed before and after. `tests/test_intel_text_anchors.py` (10 items): all failed before. `tests/test_intel_schemas.py` regenerate-and-compare went red after the contract edit and green after `tools/generate_intelligence_schemas.py` (diff: three enum values in each of `AnchorSet.json` and `IntelligenceReport.json`; `examples.json` and `schema_data.py` unchanged).
- `verified_backup.py` holds no directory manifest (it verifies only the pre-prune and pre-create SQLite copies and is not used by `backup()`), so nothing was added there. The round trip is checked by SHA-256 of every file under `kb/` and `intelligence/` in the project, the backup and the reopened backup, and by reading real (synthetic) CSAF advisories back from a reopened backup through their recorded hashes.
- Full gate once on the final code tree: `QT_QPA_PLATFORM=offscreen python -X faulthandler -m pytest -q` 2456 passed, 6 skipped (none of them new tests: the focused runs of the new files skipped nothing; live BinDiff BLOCKED: not installed), 1 pre-existing warning, 213 s. `python -m ruff check src tests tools` clean; `PYTHONPATH=src python tools/generate_intelligence_schemas.py --check` exit 0; `git check-attr` resolves the two new `.gitattributes` patterns to `text` and `eol=lf`.
- Not verified here: Windows and Python 3.12 (CI). The symlink-refusal test skips on a host that cannot create symlinks (it ran here). No live data involved.

### Algorithm digest re-baseline (2026-10-14, integration owner)
`tests/fixtures/algorithm_digests.json`: the `contextual` digest changed because `CVE_PATTERN` in `enrichment/cve.py` (and `enrichment/intelligence.py`) now uses `re.ASCII`, so Unicode digits (fullwidth, Arabic-Indic) are rejected as CVE identifiers (finding A5 of the KEV research). Cached `contextual` results keyed by the old digest are recomputed; nothing else changed.

## 2026-10-14 GitHub Pages site (site/, tools/site/; local Linux evidence only)
- `python -m ruff check src tests tools` clean. `QT_QPA_PLATFORM=offscreen python -m pytest -q` at the site commit: 2611 passed, 6 skipped in 227 s (the same 6 skips as the 2368 passed, 6 skipped baseline at 67e5a6c; the difference is the 243 new site tests). `pytest tests/test_site_*.py` alone: 243 passed.
- The main QA matrix installs neither Pillow nor segno (they live in `tools/site/requirements.txt`, never in `pyproject.toml`). Emulating that (both imports blocked): 232 passed, 11 skipped with explicit reasons. Those 11 (logo pipeline, real QR, Qt screenshot render) run in `pages.yml`, except the Qt render, which needs a local PySide6 and Pillow.
- Layout check with QtWebEngine offscreen on Linux (not a browser matrix): no horizontal page overflow at 1440 px and at a 360 px viewport, for the plain build (no logo, no address) and the full build (stand-in logo image, synthetic address, QR). Both pass the static gate `tools/site/checks.py`: local links and ids resolve, alt text, one stylesheet, no external request outside the allow-list.
- Screenshots: five real GUI renders from `ProjectService.sample` (`tools/site/render_screenshots.py`, Linux offscreen). Windows fonts and window frames differ.
- Claims: every public statement of fact cites repository files (`tests/site_claims.md`, generated from `site/content.json`). Statements about live runs were copied from this file and `tasks/todo.md`; they were not re-run.
- NOT verified: the first run of `.github/workflows/pages.yml` on GitHub (the owner must set Pages source to GitHub Actions; action majors `configure-pages@v5`, `upload-pages-artifact@v3`, `deploy-pages@v4` were pinned without API access to check the latest tags); rendering in Windows browsers and Safari; keyboard and screen-reader behaviour on the live page; scanning the donation QR with a phone (only its inline SVG structure is tested); the owner's logo and Monero address (not supplied: the page falls back to a text wordmark and hides the donation block).
### [K-FIX:audit-C] Audit C corrections (2026-10-14, Linux container, Python 3.13.16; synthetic data only)
- Regression tests red first, then green: validate (C-01, C-02, C-08, C-13, oversized versions, over-long and unpaired property names), discovery safety net, anchors (C-06), lexicon (C-07, CWE-134/193), applicability (C-03, C-12), storage (C-21, store-wide applicability), transport (C-22), enrichment (C-04, C-05, C-09, C-10, `tests/test_intel_audit_c_enrichment.py`), and a seeded mutation sweep `tests/test_intel_hostile_input.py` (500 mutated documents through the whole chain; before the fixes 4 percent of mutations ended in a raw exception).
- Re-baselined `tests/fixtures/algorithm_digests.json` stage `contextual` (67b35dd9... to bd569918...): the constants of `enrichment/cve.py` changed (CWE id token boundary, snapshot size cap, surrogate-escape pattern), so stored contextual rows and derived caches self-invalidate once. The `signals`, `wil` and `ranking` digests are unchanged.
- Scratch fuzzing (not committed): 12,000 mutations after the validator fixes found one more raw exception class, the anchors case (C-06, fixed); 16,000 more after that fix ended only in success or `IntelError`.
- Not verified here: Windows (CI), live Microsoft documents (BLOCKED, section A of the CSAF spec). Measured on this container only: 15 MiB hostile inputs (`[{},{},...]`, `["a",...]`, `[1,...]`, escaped quotes) are refused in 0.06 to 1.2 s without parsing and without memory growth (the unfixed parse took 16 s and 758 MiB for 5M objects); a valid document of 1.9M values still costs a full parse (3.3 s, 357 MiB), which the 2,000,000-value spec limit allows.
### [S2:ladder] SPEC-31 S2 (2026-10-14, Linux container, 4 vCPU, Python 3.13.16; SYNTHETIC data and a FAKE bindiff only)
| Check | Evidence | Result |
|---|---|---|
| S2 unit/property tests | `tests/test_unified_{ir_builder,ladder_core,ladder_propagate,ladder_groups,ladder_props,ladder_perf,parity}.py` = 12 + 53 + 24 + 11 + 16 + 4 + 16 tests; hypothesis tests derandomised | 136 passed |
| Full gate, once, foreground, on 33e4b18 (code identical to the final commit; only docs follow) | `QT_QPA_PLATFORM=offscreen python -m pytest -q` | 2504 passed, 6 skipped, 1 pre-existing warning, 314 s (LIVE ACCEPTANCE BLOCKED: bindiff, as before) |
| Lint | `python -m ruff check src tests tools` | clean |
| G-U5, 10k functions (printed by `tests/test_unified_ladder_perf.py -s`, isolated run) | generator of tests/unified_ir_builder.py, 35 % address-shifted, 3 % edited, 0.5 % duplicates, power-law call graph | side snapshot 0.38 s, ladder 1.18 s (L-35: 15 s; gate with 5x slack: 75 s), 61,944 budget ticks, 9,888 pairs, 0 wrong, 0 spurious |
| G-U5, 60k functions | same generator | side snapshot 2.64 s, ladder 9.56 s (L-35: 120 s; gate 600 s), 374,507 ticks (6.05x the 10k ticks: linear), 59,382 pairs of 59,424 true, 0 wrong, 0 spurious, 10 propagation waves |
| Informational, not gated | 250k functions, same generator, one run | ladder 56 s; process peak RSS 1.48 GiB including the generated rows (60k: 380 MiB including them) |
| Harder generator settings (scratch script, 6k functions each, 30-50 % edited, 5-10 % duplicates, hubs) | pairs checked against the generator's ground truth | 0-1 wrong pair per run, always tier B (one `P09` pair for a structurally edited function, one `P11` pair for a function that was removed); no tier-A or tier-C pair was wrong. A property of the synthetic generator, not an accuracy claim |
| Mutation sweep (scratch script, not committed) | 31 textual mutants of the ladder sources, each run against the four ladder test files | 31 killed, 0 survived (three weak spots found and fixed on the way: 3-deep tier cap, ICF-suspect exclusion, hub vote token) |
| Determinism | `test_result_digest_is_stable_across_hash_seeds_and_processes` (3 interpreters, PYTHONHASHSEED 0/1/4242), row-order permutation property, side-swap mirror property | identical digests |
| Not verified here | Windows and the frozen EXE; Python 3.12 (CI pin); IR from real Ghidra (S1) or MSVC binaries; parity against a real BinDiff or Ghidriff run (the `--md_index` dump layout is unverified, the parser counts unparsable lines); G-U3 precision on Tier R (S6) | open, see tasks/todo.md [S2:ladder] |
### [S0a-FIX:audit-c] SPEC-31 S0a-FIX (2026-10-14, Linux container, Python 3.13; synthetic data only)
- `tests/test_unified_{contracts,keys,store}.py`: 259 passed (82 before). The new tests were first run against the unmodified S0a sources and 144 of them failed there for the audited reasons (missing validation, wrong retention group, a `zlib.error` escaping the verifier on a corrupt part, a reused backup that lacked the rows being deleted); `ruff check src tests tools` clean; all generated schemas regenerate byte-identically (the pointer `/2` schema and two examples are new files).
- Property and sweep tests (hypothesis, bit-flip sweep over every hashed byte of a published result): synthetic only, not live evidence.
- Full gate on the finished slice: `QT_QPA_PLATFORM=offscreen python -m pytest -q` 2545 passed, 6 skipped (live BinDiff BLOCKED: not installed), 220 s.
- Not verified here: Windows (device-name run ids, CRLF checkout, 240-character path budget, `os.replace` retry) and Python 3.12 (CI pin).
### [K:K1-K2] CSAF explain, exports and CLI QA (PIL-K1/PIL-K2, 2026-10-14, local Linux worktree; synthetic only)
- Automated: `tests/test_intel_explain.py` (16), `tests/test_intel_reports.py` (66: 33-row escape table, hypothesis property test, three scenarios x JSON/Markdown goldens, structure and no-active-content checks, atomic export), `tests/test_intel_cli.py` (65: envelope, exit codes 0/2/3/4/5 incl. real processes, consent and allowlist, fake opener, offline cache, no Qt). Injection fixture: markup, Markdown, URLs as text, bidi, C0/C1, tag and format characters, long cells. All fixtures SYNTHETIC; none of this is live evidence.
- Mutation check (throwaway script, not committed): removing the pipe, colon, `<`, `>`, flatten, control or bidi handling from the escaper fails the injection assertions; removing only the bracket escape is caught by the escape table, not by the document-level check.
- Found while building: literal U+2028/U+2029/U+202E characters had slipped into three of the new source files (replaced by `chr()` and rescanned: 0 hidden characters in the new files); a lone surrogate escape in an advisory is rejected by the normalizer with the generic `PT-INTEL-LIMIT` message (exit 2, nothing written; message wording belongs to the CSAF audit worker).
- Not verified here: Windows (CRLF checkout of goldens, `os.replace`, console encoding), Python 3.12, the frozen executable (`tools/frozen_smoke.py` C1-C4 ran only against `python -m patchtrace`), a real `Ctrl+C` during a network read, any live Microsoft host or document (BLOCKED, as in the K block above).
### [PIL-A1:contracts] Patch-intent localization contract freeze (2026-10-14, builder worktree on work/a 8fcdd3d; Linux container, synthetic data only)
- Red first: both new test files failed at collection (`No module named 'patchtrace.pilot'`) before the package existed. Green: `tests/test_pilot_{contracts,keys}.py` 359 passed in about 4 s on Python 3.13.16 and on Python 3.12.3 (scratchpad venv, pydantic 2.13.5, the CI pin); `ruff check src tests tools` clean.
- Gates: regenerate-and-compare of 7 schemas, 50 examples and the index (byte-identical under Python 3.12 and 3.13 and under different hash seeds); 40 invalid examples, each rejected for its recorded reason; `test_strong_is_unreachable`; `test_assessment_has_no_floats` (no `number` in any schema, no float token in the example or its canonical bytes, and every integer leaf of the example refuses 1.0 and 1.5); `test_old_reader_ignores_patch_intent` plus survival of the rows through enrichment retention (no `extension_version` bump).
- Test strength: 25 single-point mutations of a scratch copy of `src` (strong validator, `strong` assignable, gate caps, contested pairing, component rule, float rank, strict mode off, dangling ids, counts, orientation, die-as-shape, newline in detail, `result_id`/`obs_id`/`candidate_key` inputs, origin merging, empty origin set, part digest, `>=` deadline, review bytes, ports gaining behaviour, three forbidden imports): all 25 caught (one needed its test repointed at the imported module, now done).
- Measured: strict validation of an assessment with 5,000 leads (8.9 MB JSON) takes 0.29 s, about 60 us per lead (about 2.7 s at the P-04 maximum of 44,800 persisted leads; to be read on a worker thread). Longest sidecar path is 54 characters (limit 120).
- Full suite once (Python 3.13.16, `QT_QPA_PLATFORM=offscreen`): 2800 passed, 6 skipped, 1 failed in 215 s. The failure, `tests/test_algorithm_digests.py::test_algorithm_digests_are_pinned`, is pre-existing: it fails identically on an unmodified export of work/a 8fcdd3d (the `re.ASCII` change to `CVE_PATTERN` in `enrichment/cve.py` changed the `contextual` digest and `tests/fixtures/algorithm_digests.json` was not re-baselined). Not touched by this slice.
- Not verified here: Windows (CRLF checkout, short ids, path length) and CI; frozen smoke (nothing imports `patchtrace.pilot` yet); `ports.py` signatures are provisional until PIL-A2/A3/B2; no live data was involved.
### [S0b:unified-s0] SPEC-31 S0b (2026-10-14, Linux container, Python 3.13; synthetic data only, none of it live evidence)
- `tests/test_unified_{registry,addressing,sources,fusion,facts,worker,pipeline,cli,import_dag}.py`: 278 tests (30, 17, 28, 31, 30, 48, 48, 34, 12). Named acceptance tests present: the 06 s9 list except the two Diaphora tests (DA-01 adapter, not S0b) and `test_bindiff_algorithm_tier_map_and_basicblocks_zero`, whose stub-row half is impossible (A-16 gap, 02 s10 item 8a; the tier map and the recorded limitation are tested as `test_bindiff_algorithm_tier_map_and_stub_rows_are_a_recorded_limitation`), the 05 s1/s2.6 tests, `test_same_class_never_corroborates_across_components`, G-U4 (two runs, three input permutations, swap older/newer, `created_utc` the only difference), G-U1 for X versus X in S0, `test_unified_run_never_mutates_project_snapshot`, `test_cancel_keeps_previous_result`, `test_worker_output_is_validated_before_publish`, `test_worker_spawn_reuses_c3_argv_environment_and_memory_cap`, `test_children_get_absolute_argv_and_a_private_cwd`, `test_no_network_during_unified_run` (audit hook on socket events, in-process runs), `test_unified_import_dag` (AST; its checker is shown to fail on planted violations), `test_unified_has_no_qt` (fresh interpreter, PySide6 blocked), `test_cli_unified_run_exit_codes` (0/2/3/4/5), `test_cli_unified_show_json_single_document`, `test_cli_unified_worker_hidden_from_help`, `test_cli_unified_never_imports_qt`, banned-word and hostile-name sweeps, `test_unknown_source_id_renders_generically` (CLI level).
- Real child process: `test_a_real_child_process_produces_the_same_result_as_the_same_code_in_process` and `test_cli_unified_run_with_the_real_worker_child_process` run `python -P -m patchtrace unified _worker` through `jobs.run_process` (Linux: RLIMIT_AS by prlimit). Failure classification (cancel, timeout, exit 22, OOM text, Job Object peak, crash, signal, silent exit, error document, spawn failure) uses a stub runner, so what a Windows child reports at the memory limit (U7) is NOT verified here.
- Found while building: S0a `store._lines` did not catch `zlib.error` (a damaged byte inside a deflate stream escaped as an untyped exception); S0a-FIX fixed it and the owner-side mapping S0b had added was removed (02 s10 item 12). After merging S0a-FIX the store's `result-drift` check exposed a real gap in the S0b identity (a set refused for another pair and the three raw failure kinds changed the content but not the id): fixed, with `test_every_unusable_input_has_its_own_result_id_so_the_store_never_sees_drift`. `ProjectService.open` refuses a project whose raw output changed, so the partial-result paths for a changed or missing raw file are reachable only for an already open project (tested through the pipeline API). C3's `secondary --help` prints `==SUPPRESS==` for its hidden worker (not touched).
- Not verified here: Windows (CI) and Python 3.12; the frozen `PatchTrace.exe unified --help` and `unified _worker --self-check`; real Ghidriff/BinDiff/rz-diff data; whether real BinExport sets carry import vertices outside the image; MSVC output styles in the decompiler text (canon/1 is tested on imitated text).
- Run from a git worktree with `PYTHONPATH=src`: the editable install points at the main checkout, so subprocess-based tests (for example `tests/test_acceptance_smoke.py`) would otherwise import another tree. CI, with a clean checkout, is unaffected.
- Full gate once on 4802756: `QT_QPA_PLATFORM=offscreen PYTHONPATH=src python -m pytest -q` 2646 passed, 6 skipped (live BinDiff BLOCKED: not installed), 212 s; `python -m ruff check src tests tools` clean.
- After merging `work/a` (S0a-FIX, S2, PIL-K) and adapting S0b to it, full gate once on 675fa36: 4170 passed, 6 skipped (live BinDiff BLOCKED), 281 s; ruff clean. Four S0b tests had failed after the merge: three for the changed store contract (a refused set / raw failure kind changing content but not the id: fixed in the identity; U+FFFD instead of removal for hostile names; content limits only in `limits_digest`) and the import-cycle scan, which now counts import-time imports only (S2 imports under `TYPE_CHECKING`).
### [S1:extraction-ir] SPEC-31 S1 (2026-10-14, Linux container, CPython 3.13.16 and 3.12.3)
Toolchain for every live line: Ghidra 12.0.4 PUBLIC (archive SHA-256 `c3b458661d69e26e203d739c0c82d143cc8a4a29d9e571f099c2cf4bda62a120`, the digest the repository workflows pin), OpenJDK 21.0.12, pyghidra 3.0.2, JPype1 1.5.2, ghidriff 1.0.0 at the pinned commit `4f5d895`. Fetched into a scratch directory outside the repository, never committed. No target binary was executed.
| Check | Command / method | Result |
|---|---|---|
| S1 tests | 11 files (`tests/test_unified_{ir_operands,ir_graph,ir_pe_tables,ir_ingest,ir_reader,ir_records,extract_runner,retain_gzf,ghidra_script,packaging,live_tool}.py`) | 438 tests; 519 with the S0a unified files, also green on CPython 3.12.3 (the CI pin, scratch venv with pydantic 2.13.5) |
| Full gate | `QT_QPA_PLATFORM=offscreen python -m pytest -q`, once, in the foreground | 2806 passed, 6 skipped, 225 s on the final code commit (LIVE ACCEPTANCE BLOCKED: bindiff, as before) |
| Lint | `ruff check src tests tools` | only the pre-existing I001 in `tests/test_calibration_tools.py` (not S1) |
| Live, probe pair | `tools/live_unified_check.py` on clang/lld-link MSVC-ABI DLLs (7 functions per side, no `.pdata`) | L0-L5 all PASS: two fresh `analyze` runs give the same `content_digest`; `gzf` mode of the packed program gives the same digest and identical function records; no unlocated address operand; real Ghidriff with `retain_gzf` retained exactly two GZFs (`<artifact name>-<sha1[:6]>.gzf`), SHA-256 equal to the recorded value, and their `gzf` extraction gives the digest of the own analysis on both sides |
| Live, MinGW pair | same tool on `x86_64-w64-mingw32-gcc -shared -O0` builds of `tests/fixtures/{old,new}.c` (61 functions, 38 with `.pdata`) | all PASS; `pdata_confirmed` 38; extraction 17.6 s, ingest 0.1 s (older side) |
| Live, large pair | same tool, MinGW DLLs of about 900 KB (4,060 functions, 174,388 / 174,516 instructions) | all PASS incl. L5: h0 / h3 / hm induce the same equivalence classes as Ghidra's own ExactBytes / ExactInstructions / ExactMnemonics hashers (4,047 / 3,831 / 3,810 classes older; 4,047 / 3,846 / 3,828 newer); `pdata_confirmed` 4,037; `mask_unlocated` 0; extraction 91.0 s / 93.8 s, ingest 8.9 s / 10.1 s |
| Live, MSVC CI pair (first run, 2026-10-14) | `windows` job of `live-unified.yml` on PR #49: `cl /O2 /GS-` builds of `tests/fixtures/{old,new}.c` (377 functions per side), real Ghidra 12.0.4 | L0-L4 PASS, including Ghidriff with `retain_gzf` and gzf == analyze; the original L5 FAILED for h3 and hm (Ghidra splits functions that differ only by a NOP, the stored keys skip NOPs by design), so L5 was redefined (A-27): export fidelity against Ghidra-style keys plus refinement of the stored keys; verified with real Ghidra locally on a synthetic NOP / INT3 DLL pair (69 functions, 16 with skipped instructions, which failed the original L5) and the MinGW pair (61 functions, 13); the MSVC re-run and the Linux job (L6 cross-OS digests) are CI evidence still to come. The "large pair" row above passed the original L5 only because no function in those builds differed by a skipped instruction alone |
| Ingest cost | `ingest` of the 27.7 MB extractor output (4,060 functions, 174,388 instructions) | 9.9 s, peak RSS 52 MiB (16 MiB above the import baseline); SQLite 12.6 MB |
| MD index parity | independent C++ transcription of `graph_util.h` arithmetic (`std::sort` + `std::accumulate`), 3,000 random graphs | 0 mismatches (bit-identical); builtin `sum()` differs from the plain loop in 303 of 500 graphs. NOT compared with the real `bindiff --md_index` (no pinned BinDiff here) |
| Mutation sanity check | 28 deliberate one-line mutations (hash choice, masks, extents, orientation, guards, retention, seam conditions, script helpers) each run against the focused tests | 27 killed; 1 equivalent (a count guard made redundant by the name-set check). One real gap found and closed by a new test: unreachable blocks in back-edge counting |
| Frozen probe (Linux, PyInstaller 6.22.3) | a one-module entry importing only `patchtrace.backend`, built with the repository hooks directory | the hook fires from `backend.py`'s lazy import; the data file lands at `_internal/patchtrace/unified/extract/ghidra_script.py` and is byte-identical; `importlib.resources.files(...).read_bytes()` works in the frozen process |
Found and fixed while building: `collect_data_files` collected nothing when a stale editable install shadowed the source tree (the hook now uses its own repository path); a sibling directory named `ghidra` next to the script would shadow Ghidra's Java package (the script now lives alone in `script/`); strict `.pdata` union equality confirmed only 17 of 38 MinGW primaries (alignment padding: tolerance rule, 38 of 38); a bare `[disp32]` / `[GS:0x30]` displacement was unlocated; `Ordinal_<n>` export placeholders were taken as aliases; raw bidi characters in regex literals were replaced by escapes; `.gitattributes` gaps closed (script LF so its hash is the same on every OS, notice bytes, fixtures).
Not verified here, only the `live-unified` workflow can: everything on Windows (JVM, Job Object, pyghidra and paths on `windows-latest`), MSVC-built fixtures (operand typing and RVA-form switches were seen on clang and MinGW code only), a real Ghidriff-written GZF on Windows through `retain_gzf`, `content_digest` equality across operating systems on the same DLL bytes, the Windows frozen smoke U1 (and U2 once S0b lands) and the Windows PyInstaller hook, the FID `lib` marker, and BinDiff `--md_index` parity. Scale beyond 4,060 functions per side (L-35: 60k) was not measured.

### [WB3-S0:strings-core] strings table gate
Linux, Python 3.x shared host, synthetic rows: load of two 200k-row sides 0.2-0.3 s (limit 4 s); tracemalloc peak 52 MiB (limit 400 MiB); sidecar 16.9 MiB per side. Windows leg and real-binary string counts not measured.
### [WB3-S1-S3:strings-sources-scan]
| check | evidence |
|---|---|
| built-in scan equals FLOSS 3.1.1 static goldens (synthetic pairs) | `tests/test_strings_scan.py::test_scan_matches_floss_goldens` and `test_scan_matches_the_decode_goldens` |
| scan throughput, 64 MiB, Linux, shared host | code-like data about 125 MB/s, all-zero data about 320 MB/s, pathological random data (a string every ~80 bytes) about 47 MB/s; the 100 MB/s target holds for sparse data only; real binaries and the Windows leg are unmeasured |
### [G1:callgraph-kernel]
Automated only: 400-trial differential vs NetworkX (SCC, ancestors, descendants, BFS, multi-source, distance, simple-path lengths), hash-seed determinism, 60k node / 447k edge build and algorithm gates (budgets 5x-10x measured). No manual gate.
### [G0:fixtures] WB2 G0 fixture gate (2026-10-14, Haiku 5.5, worktree; Linux)
| Check | Method | Result |
|---|---|---|
| Strict JSON and normalizer | every committed fixture loaded with duplicate-key and NaN/Infinity rejection, round-tripped to its builder, and passed through `normalize_ghidriff` with a project built from the fixture's SHA-256 pair | 6 of 6 pass (18 tests) |
| Shape guards | svc known-answer call sets, hostile names (bidi, U+2028, CR/LF, quote and backslash, NUL, 600-char label), ambiguous qualified name, absent `matches`, count-suffix inferable vs ambiguous stem, cycle plus 66-caller hub | 6 tests pass |
| Byte stability | committed files equal builder output byte-for-byte, LF, ASCII-escaped | pass |
Not verified: the real Ghidriff `matches` label forms (live gate, owner or CI).
### [WB1-S0:search-foundation]
Run `python tools/check_search_runtime.py` (add `--require-native-rapidfuzz` on release builds) on Linux and Windows CI; it must print `search-runtime: ok` with fts5, unicode61 and trigram true. UNVERIFIED on Windows until the first CI run.

### [WB1-S1:search-query]
No manual step. Automated: `pytest tests/test_search_query.py` (property test over arbitrary Unicode and grammar fragments against real FTS5 tables).

### [WB1-S2:search-segment]
No manual step. Windows CI must run `tests/test_search_segment.py`; Linux evidence: 100k names build in about 2.7 s (30 MB), hardened open in 0.36 s.
### [K2:kbcorrelation-store] KB correlator K2 crash consistency (2026-10-14, local Linux worktree; synthetic only)
| Check | Method | Result |
|---|---|---|
| Hard kill at 8 crash points | child process SIGKILLs itself (os._exit(137) where SIGKILL is missing) at `index_after_doc`, `index_before_commit`, `after_project_create`, `before_cas` 1 and 2, `after_sidecar_write`, `attach_before_row` 1 and 2; parent opens the project with `ProjectService.open`, repairs twice, then with a rebuilt context | all valid; second repair changes no revision or attempt |
| Not verified | Windows (file replace, SQLite WAL) and a real power loss (fsync is requested, not provable here) | open |
### [CAP-0:cap-evidence] CAP evidence rows 19-21 and open gates (2026-10-14, docs only; no test run, no live evidence)
- Evidence rows carried over from `docs/specs/program-e/CAP-integration-plan.md` section 2 (own measurements, not committed; synthetic PEs and a shared container):
  - Row 19: time on tiny synthetic PEs is 8.38-9.51 s per file (Linux, onefile start, embedded cache, vivisect); real-binary time and memory are unmeasured [unverified]. Source: `tests/fixtures/intel_tools/manifest.json` `elapsed_s`. Confidence: high for the synthetic, none for real.
  - Row 20: existing strict parser on a 27.8 MB document with 20,000 matches: JSON load 1.95 s, pydantic 2.61 s, `parse()` 5.61 s, peak RSS 745 MiB (Python 3.13.16, pydantic 2.13.5, shared container, throw-away script). Confidence: medium.
  - Row 21: prototype two-level custom `QAbstractItemModel` with model-owned filter and sort (no proxy), PySide6 6.12.0 offscreen, 100,000 rows: reset 6 ms, first paint 25 ms with 1,650 `data()` calls (identical at 10,000 rows), filter 10 ms, sort 25-40 ms, `expandAll` 0.4 s; a model reset collapses expansion and selection. Confidence: medium.
- Open gates (CI or owner only; none closed by CAP-0): L1 Linux required leg (probe, pinned version text, end-to-end pair delta on synthetic pairs equals the goldens) and Windows advisory leg; L2 coverage on a self-built DLL (share of capa function starts equal to a Ghidriff start on the same side); L3 time and memory of vivisect on a real driver on the owner's machine (the Microsoft binary stays local); L4 Ghidra backend with Ghidra 12.0.4 and JDK 25; L5 antivirus and SmartScreen behaviour for `capa.exe`; L6 onefile extraction under 60- and 120-character scratch roots; L7 NVDA/Narrator, 125/150/200% DPI, glyph fonts, frozen-EXE dock smoke.
- Goldens planned, not present: `expected-pairs-capa-api.json`, `expected-pairs-capa-move.json`, CLI JSON goldens (timestamps and paths ignored).
### [CAP-1:capa-parser-v2]
| check | evidence |
|---|---|
| coverage, features and labels on REAL capa 9.4.0 output (synthetic PEs) and DERIVED library/unrecovered variants | `tests/test_capa_parser_v2.py`; derived files labelled in `tests/fixtures/intel_tools/capa/MANIFEST.capa-v2.json` |
| rows stored before CAP-1 stay readable and keep their content ids | `test_records_stored_before_cap1_stay_readable_and_keep_their_ids` |
| not verified here: memory cap against a real capa run (RLIMIT_AS counts virtual memory), Ghidra 12.0.4 backend (live gate L3, L4) | CAP plan section 10 |

### [CAP-2:capa-pairs]
| check | evidence |
|---|---|
| plan section 5 expectation (2 gained, 1 lost, 2 unchanged, 0 moved, 2 unattributed) on REAL capa output | `test_pair_delta_equals_the_committed_golden`, `test_the_combined_channel_names_four_changes_and_two_unplaced_behaviours` |
| moved, detection noise, library, unrecovered, orientation swap, control pair | `tests/test_capa_synergy.py` (moved and library cases use DERIVED variants) |
| not verified here: capa-move on REAL capa output, coverage against Ghidriff function starts (live gate L2) | needs the pinned capa and Ghidriff |

### [CAP-3:capa-view]
| check | evidence |
|---|---|
| exact state copy C0-C13, footer, accessible names and texts | `tests/test_capa_view.py` |
| banned stems and words absent from every UI-authored string | `test_banned_strings_never_appear` |
| badge contrast (text >= 4.5:1, fill >= 3:1 on the dark theme) | `test_badges_are_neutral_with_enough_contrast` |
| not verified here: NVDA/Narrator output, glyph fonts, DPI, the Qt `data()` cost budgets (CAP-6a) | manual gate L7 |

### [D1:diec-hardening]
Fixtures `nested-overlay`, `empty-result`, `vocabulary` are hand-authored from the upstream writer, not captured. G-L1 must confirm both shapes with real diec 3.21 and replace them.
### [D2:pe-build-facts] PE build facts (2026-10-14)
Automated only, on synthetic PEs from `tests/pe_build_fixtures.py` (Rich equals pefile 2024.8.26 on generated headers; header fields equal pefile's). Not verified: any real MSVC, lld or .NET binary (no Microsoft binary is committed), Rich headers with (0,0) entries or non-0x80 starts beyond the unit cases, Windows.
### [SPEC-07-hit:derived-cache-hit]
Profile (10,000 pairs, Linux, cProfile): payload parse 0.82 s, build_views 0.73 s, rank 0.69 s, locations/input digest 0.35 s; cache.get itself 35 ms. After: payload parse 0.35 s; bench hit 1.92 s -> 1.44 s (best of 5, shared host). Ids, digests and ranking pinned by tests/test_enrichment_hit_golden.py.

### [CAP-4:capa-cache]
Hermetic: 17 tests in tests/test_capa_cache.py (hit does not spawn, corrupt/bomb/trailing/key-change are misses, private cache dir). Real-binary cache timing not measured.
### [CAP-5:capa-cli]
Automated only: fake capa executables printing committed real output on synthetic PE pairs, project matches added in-test (`tests/test_capa_cli.py`). Not verified: a real capa run, Windows.
### [WB1:S3:sources-build]
Synthetic project (tests/search_builders.py: invented names, bytes-only PE files). Open gates: a real Ghidriff JSON for the `raw` section shapes; first-index latency on a 100k-function project (owner machine); Windows CI run of the segment publish over an open file.
### [WB3-S4:strings-links]
Automated only, on the SYNTHETIC pair of `tests/strings_pe.py` and a hand-written Ghidriff-shaped document (not Ghidriff output). F13 escape behaviour is checked against a reference encoder written from the spec, not against a real Ghidra decompile; the hex-escape width rule is a heuristic until a real decompile is compared.
### [G2:callgraph-snapshot]
Automated: tests/test_callgraph_{input,pairing,snapshot}.py (raw missing, reader failure, malformed tables, ladder rungs, count-suffix, ambiguity, pair precedence, claim cap, cancel, key sensitivity, hash-seed byte identity, import boundary). Open: real Ghidriff `name_matches` shape and `EXTERNAL:` label forms on a synthetic PE pair (CI or owner).
### [G7:callgraph-evolution]
Automated: tests/test_callgraph_evolution.py (4-build matrix with dropped and reverted, rename lineage, missing pair and missing record = unknown, same-build inconsistency, deleted callee, no raw matches, hostile labels, limits, cancel). Open: read-only open and close of real pair projects (composition, with the CLI/tab); real Ghidriff name_matches shape.
### [D3:buildenv-core] Build-environment core (2026-10-14)
Automated only, on synthetic PEs and the committed real diec 3.21 JSON goldens (no tool is run, no Microsoft binary). The synergy test asserts annotation, counts and ordering rules on hand-authored rows, not effectiveness (G-DIE-1 is open). Not verified: real-binary fingerprints, the UPX diec golden (live gate), the 1 MiB large-overlay threshold (PatchTrace's own choice).
### [WB3-S5:strings-delta]
Automated only, on SYNTHETIC inputs (built-in scan of the `tests/strings_pe.py` pair, hand-made rows, the hand-written Ghidriff-shaped document, a hand-written cue context). The emulation row of SYN-WB3-1 uses hand-made decoded rows, not FLOSS output. Properties are seeded loops (swap symmetry, offset-shift invariance, row-order invariance), not hypothesis. Blocked: real FLOSS 3.1.1 / Ghidriff goldens (S9), measured delta time and memory at 200k rows (budget: delta <= 1 s).
### [G3:callgraph-deltas]
Automated: tests/test_callgraph_{delta,leads,synergy}.py (exact svc classes, renumber-only, set semantics, unknown is not removed, caps, cancel, swap-symmetry and rename-invariance properties, hub and API-hint lookups, groups, blast, entry, paths, banned-string and unsafe-text sweep over every fixture). Open: hub-registry spellings and import label forms need a real Ghidriff run.
### [K3:kbcorrelation-service] KB correlator K3 QA (2026-10-14, local Linux worktree; synthetic only)
Automated: `tests/test_kbc_{components,pairs,context,service,cli,e0_e2e}.py` (sockets denied; real `ProjectService`, `EnrichmentStore` and reused `intelligence` rules). The E0 script runs steps 1-4 and 6; step 6 kills a child `kb import-pair` at `after_project_create`, `before_cas` (4th and 5th), `after_sidecar_write` and `attach_before_row`, then `kb attach --repair` twice (second run changes nothing), `kb explain`, `kb export` (escaped, no local path) and a `ProjectService.backup` round trip of `kb/`. Not verified: step 5 (K4a), Windows runs (`os._exit(137)` replaces SIGKILL), any real MSRC/CSAF/Winbindex bytes, a project held open by the GUI (typed attach failure), antivirus holds on the project sqlite file.
### [WB1:S4:service-rank]
Synthetic known-answer project (tests/search_synergy_builders.py: invented names; FLOSS-shaped and advisory segments injected through `extra_specs`). Open gates: 100k-function project latency on the owner machine through the real build path (the test uses a 100k-document segment); Windows CI; real tool and advisory sources (S8).
### [D4:buildenv-store-cli-report]
Automated only: tests/test_buildenv_store.py (round trip, republish, unknown kind refused, size limit, corrupt row skipped, other project ignored, old reader), tests/test_buildenv_cli.py (exit codes 0/2/3/4/5 per verb, envelope, basenames only, stale and one-sided DiE rows, read-only project, hostile text, no Qt import), tests/test_buildenv_report.py (orientation guard, size cap, redaction, Markdown and HTML injection, banned words). Manual and live gates unchanged (G-L1 to G-L4, G-DIE-1).

### [WB3-S7a:strings-view-model]
Automated only (`tests/test_strings_{view_model,copy}.py`, hand-built StringChange rows): filters, review order, hostile-text escaping, banned-word sweep over all visible text, one teach entry per id, tooltip ids equal the card list. Screen-reader wording is not verified.

### [WB3-S6:anchors-export-cli]
Automated only, on the SYNTHETIC `tests/strings_pe.py` pair and hand-made rows; no tool is run. The CLI is exercised through the real `cli.main` with a test-local copy of the integrator hook. Not verified: function links through the CLI on a project with a completed analysis run, stored FLOSS evidence through `--source floss|auto`, Windows.

### [K6:kbcorrelation-cvrf-fetch]
Mocked only: a fake opener serves the synthetic 2099-Feb fixture; no real MSRC bytes, no socket. Open gates: live probe L1 (URL shape, `Accept`, document size, gzip, rate limit, whether 404 marks an unpublished month), Windows CI, a real hard cancel on a dripping server (covered by the shared transport's own tests, not repeated here).

### [WB1:S5S6:search-cli-view]
Automated: tests/test_search_cli.py (exit table, envelope, probe, status, invalid input, no Qt) and tests/test_search_view_model.py (states Q0-Q12 exact copy, banned-word sweep, hostile text, 1M-hit paging cap, tooltip data). Open gates: frozen `search --probe` and `search --help` on the Windows bundle (needs the cli.py hook); real-project `search` on a project opened by ProjectService (the CLI tests use a stand-in service).
### [G4:callgraph-cli]
Automated: tests/test_callgraph_{cli,dot,schemas}.py through the dispatcher over synthetic projects on disk (exit table 0/2/3/4/5, one JSON document, read-only project tree, overwrite refusal, series matrix with a dropped, an appeared and an unknown cell), a lexer-oracle round trip of every Unicode code point (a deterministic sweep: hypothesis is not installed here), DOT golden with the random match id masked, and schema regenerate-and-compare. Not verified: Graphviz parsing of the output (the oracle ports scan.l and labels.c rules from the plan, not from a Graphviz run), `cli.main` end to end (hook pending), Windows.

### [K5:kbc-lineage-resolver]
Automated: `tests/test_acquisition_winbindex_rows.py`, `tests/test_kbc_{lineage,resolver}.py` on synthetic Winbindex-shaped records (no network, no Microsoft data). Open gate: parse a freshly fetched real record once on the owner's machine and compare the row counts with `parse` (expect rows for every 64-hex key).

### [K4a:kbcorrelation-leads] KB correlator K4a QA (2026-10-14, local Linux worktree; synthetic only)
Automated: `tests/test_kbc_{leads,view_model,synergy}.py` (sockets denied; real `ProjectService`, `rank`, `correlate --dry-run` for the baseline). Not verified: Windows run; a real MSRC document; the dock (K4b) on top of the view model.

### [CAP-7:capa-hints] capability hints QA (2026-10-14, local Linux worktree; synthetic and derived only)
Automated: `tests/test_capa_hints.py`. Not verified: any hint against the real capa-rules pack (not obtainable offline); hint semantics are unvalidated by design.
### [K7:acquire-workflow]
Automated: `tests/test_acquisition_workflow.py` (25 tests; fake opener, no sockets): pair acquired and imported, consent equality, cancel leaves no project or staging, hash mismatch discarded. Not verified: a live symbol-server download, Windows run.
### [S8:search-tool-advisory-sources]
Automated: tests/test_search_sources_tools.py (presence absent/present/unknown through the real `SearchService`, secret redaction in segment bytes, advisory markup, supersession flags, permutation-stable docs and digests). Owner gate: none beyond the integrator wiring above.
### [K7v:kb-acquire-cli]
Automated: `tests/test_kbc_acquire_cli.py` (25 tests; fake transport, sockets denied): plan printed with exit 2 and zero requests for missing, wrong-host, wrong-plan and offline consent; consented acquire verifies, imports, attaches (`kb attach --repair`, `kb explain`); hash mismatch and non-empty directory leave nothing; Winbindex record import validation, size bounds, gz replace. Not verified: a live Winbindex or symbol-server download.
### [K1a:kev-core] KEV core QA (2026-10-14, local Linux worktree)
Automated: `tests/test_kev_*.py` (hermetic, no sockets); the full real catalog (1,741 entries, fetched 2026-10-14, not committed) parses with 0 skipped in about 0.07 s. Not verified: Windows run; screen-reader reading of cells; cisa.gov feed URL and licence text (gate K6/owner).

### [K4:kev-kb-adapter]
Automated: `pytest tests/test_kev_synergy.py tests/test_kev_kb_integration.py` (22 tests). Open at the KB wave merge: synergy item 9 and the real KB view-model.
### [F2:qt-runtime]
| Check | Method | Result |
|---|---|---|
| Qt runtime teardown | `python tools/qt_gate.py --repeat 20 tests/test_gui_tasks.py tests/test_gui_announce.py tests/test_gui_settings.py`, ONE session, `--keep-duplicates`, `PYTHONFAULTHANDLER=1`, Linux offscreen | 2260 passed (20 x 113), no abort |
| Legacy coexistence | the same gate x3 over `test_evidence_ui.py` and `test_ui_engine_setup.py` plus the new files | 411 passed |
### [GUI:framework] Program E GUI framework: gates and manual rows (2026-10-14; GUI-F0, documentation only)
- GUI-F0 (documentation only, no code or test change): `python -m pytest tests/test_spec_registry.py tests/test_workflows.py -q -p no:cacheprovider` gave 93 passed (Linux, Python 3.13.16). Link check of the 27 changed files: 54 references, 0 broken relative links; 18 planned module paths named in the amendments do not exist yet (expected until their slices land).
- Slice gates for F1 to F9 (GUI plan section 9; every slice: ruff clean, red then green tests, full suite twice, Qt test files 20x, no stray files, a `docs/modules.md` row). F1: hypothesis on `sanitize_text`, ids and manifest; no-Qt subprocess; CLI exits 0/2/3/4/5. F1b: registry tests of 8.12, `test_cli_seam_budget`, frozen smoke A1 over `names()` (Windows CI, reported separately). F2: teardown matrix x20 with faulthandler; repaint under load; progress flood; lane state opened and closed on the lane thread. F3: dark stylesheet equals `DARK_STYLE`; contrast; hostile text; `a11y_audit`. F4: 10k and 100k call and time gates. F5: all of 8.8 for the host; seam budget; layout suite; full suite twice; 20x. F6a: caps, layers, hunk API, truncation, stub highlighter. F6b: 500/2,000 and 2,000/8,000 budgets. F7: simulated contrast provider; contrast per variant. F8: C6 and G suites unchanged, 20x. F9: `test_no_new_top_level_window`; series and overview suites.
- Manual gates M19 to M28 (`docs/specs/windows-acceptance-and-milestone-builds.md` section 3; `not-run`): NVDA walk; Narrator; keyboard-only walk; each Windows contrast theme; layout persistence with a floating panel on a second monitor and Reset; 100/150/200% and monitor moves; Accessibility Insights FastPass and Live Inspect per panel; a 100k-row table under Narrator; panel shortcuts while floating; frozen style plugin record. Blocked here (no Windows, no screen reader, no second monitor); reported separately, never counted as done. Numbers are provisional: the owner renumbers on merge if another plan claims M19 or higher (GUI plan open question 12).
- `A1 --help` wording: the frozen smoke A1 check covers every registered command (`names()`), not a fixed list of seven, once F1b lands.
### [RG:release-gate] Release gate for prerelease publication (2026-10-14, local Linux worktree on fd6cdba, Python 3.13.16; synthetic data, a stub `gh` and git history only, no Actions run)
`tools/release_gate.py` plus the `release-gate` job of `.github/workflows/qa-windows.yml` (spec `windows-acceptance-and-milestone-builds.md` section 1.1): `release` now runs only for a `v*` tag or when the gate prints `publish=true`, which it does at the third counted merge to `main` since the latest published `v0.1.0-beta.*` prerelease, for `[release]` in the head message, with no earlier prerelease or an anchor off the first-parent history, and on any gate failure (fail open; the count and the reason go into the release notes). A commit whose whole message holds one of the five GitHub skip markers is not counted, a late line of a squash body included; the head always is. Evidence: `tests/test_release_gate.py` 99 tests (the rule, markers in subject and body, fail-open for every tool failure and usage error, `$GITHUB_OUTPUT` injection, a throwaway real git repository with a side-branch merge, and no-YAML-library checks of the job graph, permissions, outputs and the shell-injection boundary), 126 passed together with `tests/test_workflows.py` and `tests/test_milestone_notes.py`; `ruff check` clean; `actionlint` clean and the edited workflow parsed with PyYAML; 33 deliberate one-line mutations of the tool and 23 of the workflow all caught (two survivors found on the way were closed by new assertions); the real CLI replayed over the first-parent history of origin/main at `fd6cdba` with each of the 44 local `v0.1.0-beta.*` tags as the anchor gave the same count as an independent `git rev-list --grep` in all 44 (anchor beta.225 gives 1 of 3: the head counts although its own squash body carries a marker, and the commit before it is excluded by a marker in its subject). Not verified here, only GitHub can: the gate job on a real push (`gh api` with the job token, the output hand-over to `release`, a skipped gate on `pull_request` skipping `release`, the notes line), the Windows run of the new tests, and the real release list (a stub `gh` stood in for it). Do not write the literal skip markers or `[release]` in commit messages or PR bodies unless intended: a squash body that quotes a skip marker skips the whole push run (PR #48), and `[release]` publishes.
### [F1b:cli-registry] CLI-extension registry (2026-10-14; local Linux evidence, Windows CI pending)
| Check | How | Result |
|---|---|---|
| Registry and smoke tests | `python -m pytest tests/test_cli_registry.py tests/test_acceptance_smoke.py -q` | 70 passed, 1 skipped (the opt-in freeze), Python 3.13.16 and 3.12.3 |
| Existing CLI-related tests | 20 files (`test_cli*.py`, `test_*_cli.py`, `test_audit*.py`, `test_enrichment_review_regressions.py`, `test_nway_series.py`, `test_profiles.py`, ...) | 415 passed, 1 skipped; 355 passed on the unchanged base; the Qt files that import `cli` (3 files) 53 passed |
| Lint | `ruff check` on the touched files and the hook | clean |
| Mutation check | 24 one-line breakages of the registry (escape, label default, duplicate and built-in rules, summary and name rules, private skip, exit code, message, lazy build, order), the `cli.py` seam, the hook guard and the smoke list | all 24 caught |
| Real freeze, Linux | PyInstaller 6.22.3; `patchtrace.cli` frozen without Qt from a copy of the tree holding two fake verbs and this hook (opt-in test, 22 s on 3.13 and 25 s on 3.12 with a shared CPU) | `--help` lists the verb and marks the broken one unavailable; the verb answers one JSON envelope; the broken one exits 3 with `PT-CLI-COMMAND`; built-ins work. Control build without the hook: the verbs are silently absent (`invalid choice`, exit 2). The shipped tree itself (no verb files) also freezes: the hook accepts the empty registry, `--help` and `rank --help` exit 0, an unknown verb exits 2 without a traceback |
Not verified here: anything frozen on Windows (this hook in `tools/build_windows.py`, `pkgutil.iter_modules` over the PYZ on Windows, `tools/frozen_smoke.py` A1 over `names()`), and `tests/test_cli_registry.py` on Windows (temporary fake verb files, a hook subprocess). Until the first adapter file exists A1 covers only the 11 built-ins.
### [WBQ-S4:pe-exports-api] WBQ slice S4 (2026-10-14, Linux container, Python 3.13.16; synthetic PEs only, none of it live evidence)
| Gate | Command | Result |
|---|---|---|
| Focused | `QT_QPA_PLATFORM=offscreen python -m pytest tests/test_pe_exports_table.py tests/test_pe_api_delta.py -q -p no:cacheprovider` | 83 passed, 2 skipped (the two pefile oracle tests, no pefile installed); two consecutive runs; 3 s |
| With oracle | same, `PYTHONPATH` at a scratch `pefile==2024.8.26` install (outside the repo) | 85 passed; a one-off scratch run of the oracle comparison over 3,820 random valid tables (gaps, aliases, forwarders, any Base, PE32 and PE32+) matched pefile slot for slot with no warning and no truncation |
| Existing PE tests | `tests/test_pe_overview.py tests/test_pe_overview_map_compare.py` | 92 passed, 1 skipped, unchanged (no existing file was edited; the source-scan test passes for the new modules) |
| Lint | `ruff check` on the five new files | clean |
| Mutation sanity | 36 one-line mutants of `exports_table.py` and `api_delta.py` (range ends, Base, unnamed-slot rule, caps, null RVA, loop skip, orientation, truncation, placeholders, ordinal form, sort, counts, keyword-only) | 29 killed first time; the 7 survivors exposed missing tests (entry cap through alias fan-out, names-only over-cap count, null table pointer, cut name, duplicate name text, names-only oversize count, asymmetric reason counts), added and then killed; none left |
| Cost (this machine) | `parse_export_entries` alone | 20,000 named exports 236 ms (12 microseconds per name); 20,000 ordinal-only 28 ms; 20,000 distinct 210-character forwarders 493 ms; 20,000 unreadable name pointers 177 ms; 20,000 pointers to one name 9 ms |
Found while building, both checked on the existing `parse_exports`: a hypothesis case showed its plausibility rule (more names than addresses) flags a valid alias table (status `partial`, `export_count_implausible`), so the new parser bounds both counts by what the file could hold instead; RVA 0 lies in the header region, so a null name pointer is listed as the export `MZ` with status `ok` and no warning, while the new parser reads RVA 0 as nothing (which also stops a null address table from producing exports out of header bytes).
Not verified here: Windows and Python 3.12; real Microsoft or MSVC-built export tables (synthetic builders only; pefile agreement is the only independent check); the call from `inspect_pe` and the compare row (S5); the flagged difference between `parse_exports` and `parse_export_entries` on alias tables and null pointers until S5 unifies them.
### [WBQ-S10:symbols-decoration] WBQ S10 symbol decoration (2026-10-14, Linux container, CPython 3.13.16; known answers also on 3.12.3 and 3.11.17)
The "decoder" below is pydemumble 0.1.3 (LLVM's MicrosoftDemangle.cpp) in a scratch virtual environment, never a repository dependency. The licence check is recorded in `tests/fixtures/wbq/ms_kat.NOTICE`.
| Check | Command / method | Result |
|---|---|---|
| Focused tests | `QT_QPA_PLATFORM=offscreen PYTHONPATH=src python -m pytest tests/test_symbols_decoration.py -q -p no:cacheprovider` | 180 passed, 1 skipped (the oracle test skips without pydemumble) |
| Same, decoder on the path | `PYTHONPATH=src:<scratch venv site-packages>` | 181 passed: 59 of 59 `demangled` cells identical, 32 of 32 name parts decode alone to `int <qualified_name>` |
| Lint | `ruff check src/patchtrace/symbols tests/test_symbols_decoration.py` | clean |
| Corpus differential | parser against decoder on all 1,083 distinct names of the 18 `ms-*.test` files | 371 derived, 337 complex, 375 not derived (string literals, RTTI), 0 disagreements |
| Mutation differential | 300,000 random 1-4 character edits of those names (seed 20261014); a derived name part must decode alone to `int <qualified_name>` | 75,885 derived, 0 disagreements |
| Chain differential | 100,000 generated scope chains (random digit back references, duplicates, `??0`/`??1`) | 24,362 derived, all rendered identically by the decoder |
| Chain differential, both directions | 150,000 generated chains with a valid type encoding | decoder and parser accept exactly the same names: 37,838 both accept with the same rendering, 112,162 both reject |
| Defect sanity check | 18 deliberate one-line defects applied to a copy of the package | 18 killed (the rule that a truncated `?` scope is complex first survived and is now pinned by two cases) |
| Interpreters | the 59 known answers through a bare harness on CPython 3.12.3 (the CI pin) and 3.11.17 | 59 of 59, 0 mismatches |
Found while building: a 510-character name can repeat a 252-character scope 252 times through digit back references (about 65,000 characters), so derived names are capped at 1,024 characters before the join (`test_back_references_cannot_expand_a_name_past_the_cap`). Real names end in `@<digit>` (`??_R3Base@@8`, `?foo@@9`, `??_B?1??getS@@YAAAUS@@XZ@51`), so the trailing `@N` byte count is stripped only after a character other than `@`. The 10-entry name table cap cannot be seen through the digits 0-9 (an equivalent mutant); it only bounds the work.
Not verified here: Windows, the Linux-versus-Windows decoder equality on the known answers (S11), the frozen build (nothing imports the package yet) and any real MSVC export table (the names are the LLVM test names and synthetic ones).
### [PIL-B1:rules] Patch-intent rule table (2026-10-14, builder worktree on fd6cdba; Linux container, synthetic data only)
- Red first: `tests/test_pilot_rules.py` failed at collection (`No module named 'patchtrace.pilot.rules'`) before the package existed. Green: 261 passed in about 3 s on Python 3.13.16 and on Python 3.12.3 (scratchpad venv, pydantic 2.13.5, the CI pin); together with the neighbouring suites (`test_pilot_{contracts,keys}`, `test_intel_{hypotheses,lexicon}`, `test_enrichment_{signals,cve}`) 789 passed; `ruff check` clean on the new files. The full suite was not run (integrator).
- Gates: `test_every_k_rule_has_expected_changes` (22 K rules, no orphan row); one positive and one negative fixture per family (ids = family names, 22 each); `test_cwe_detector_map_consistent_with_rules` (B3 `CWE_DETECTORS` credits no detector or confidence the rows would reject; CWE-680 is the only B3-only CWE). Also: every leaf of every row meets exactly its own change; strings and DiE flags never meet or contradict a change; the vocabulary is pinned to B1 (detector ids and confidence ceilings, including the one `INT` override found by an AST scan of `signals.py`) and to SPEC-31 (semantic classes, materiality); the digest is pinned and identical under three hash seeds; every kind a leaf reads is a valid A1 `Observation` kind; import purity (AST rules plus a subprocess with Qt blocked).
- Test strength: 47 single-point mutations of a scratch copy (role filter, confidence floor, unknown level, API key lower-casing, module prefix, trailing A or W folding both ways, capa namespace boundary, channel completeness, conflict handling, string `api_hints`, P-07 limits off by one, validation checks, digest inputs, lookup by revision, eight table edits): all 47 caught; two (an optional-change leaf swapped, a floor raised) are caught only by the pinned digest, which is its job (any edited row makes stored results stale).
- Measured: `evaluate_rule` costs 17 to 22 microseconds per call (3 changes, up to 8 pieces of evidence), so 40,000 calls (5,000 pairs x 8 CVEs, one hypothesis each) take 0.7 to 0.9 s of the 5 s localization target; PIL-B2 can skip candidates that have no evidence at all.
- Found while building: the card's K edits and "20 K rules" were stale (audit C added R-FORMAT-STRING and R-OFF-BY-ONE, see docs/modules.md [PIL-B1:rules]); B1's `INT` reports `moderate` for a strictness flip on identical operands and `weak` otherwise, which is why `b1:` leaves carry a floor; B3 maps CWE-1284 to (VAL, BND), which the plan's INPUT row did not cover (the row now accepts `BND`); the shared scratchpad holds other workers' files (a `mutate.py` and a `mut/` directory of PIL-A2 collided with mine; mine now live in their own subdirectory).
- Not verified here: Windows (CI); behaviour on real B1 `SignalSet`s through the PIL-A3 adapter (no adapter exists yet, so the carriers of `Evidence.level` and `Evidence.subject` are unproven); the plan s5 synergy oracle (PIL-T) and fusion (PIL-B2).
### [K1b:kev-store] KEV store QA (2026-10-14, local Linux worktree)
Automated: `tests/test_kev_store.py` (21 tests, temp dirs, injected `os.replace` faults, no sockets): crash at each of the three install steps keeps the previous current, older mirror never replaces a newer current, damaged pointer, snapshot or meta falls back and says so, gzip bomb capped, three-step `PermissionError` retry, prune needs `confirmed`. Not verified: a real Windows sharing violation.
### [K2:kev-transport-cli] KEV transport, service and CLI QA (2026-10-14, local Linux worktree)
Automated: `tests/test_kev_{transport,service,cli}.py` (hermetic: scripted opener, sockets denied for `plan`): cross-host and non-https/port/userinfo/query redirects refused, 16 MiB cap with a lying Content-Length, fixed headers, env proxy ignored, cancel and deadline abort a blocked read, retries (Retry-After at most 60 s), exact consent host, shrink and older-mirror rules, one JSON document and exit codes 0/2/3/4/5. Not verified (open gates): the canonical CISA URL and its acceptance of the `PatchTrace` User-Agent (K6 live probe); real TLS and the proxy-ignoring default opener against a live server; Windows.

### [PIL-A2:advisory-sources] Patch-intent localization advisory-side adapters (2026-10-14, builder worktree on fd6cdba; Linux container, synthetic data only)
- Red first: the new test file failed at collection (`No module named 'patchtrace.pilot.sources'`) before the package existed. Green: `tests/test_pilot_sources_advisory.py` 174 passed in about 2 s on Python 3.13.16 and on Python 3.12.3 (the CI pin; scratch venv); `ruff check` clean on the new files.
- Gates: `test_cve_gate_table` (35 named rows) plus `test_cve_gate_agrees_with_the_table_for_every_combination` (an independently written decision list over 1,350 combinations of resolution, mapping, contradiction count and assumption); `test_kev_absence_is_unknown_context`; `test_unified_beats_secondary_for_identity` (every unified x secondary combination); `test_confounding_counts_cves_fixed_on_newer`; every `detail` passes `sanitize_text`, `plain_line` and a banned-word sweep (hostile and conflicting CSAF fixtures, a real trimmed NVD/MSRC snapshot, hostile record text).
- Test strength: a throwaway sweep of 105 single-point mutations of a scratch copy of `src` (gate precedence, assumption, summaries, observation shapes and provenance, note cap and de-duplication, source cap, orientation and cancel translation, `facts_ids` grouping, channel status, KEV rank/order/snapshot checks, window set, threshold and limits, identity tables and branch, snapshot language, CWE explicit rule and pointers, excerpt refusals): 5 survived the first version of the tests (ignored-CWE note, pointer index of an explicit CWE, exact excerpt refusal reason, one-element CWE list, cleaned provider label), each now has a test; on the final code all 105 are killed. Not committed.
- Found while building: B3's `CveSnapshot.cve_id` pattern uses `\d`, which also matches non-ASCII digits (K's `CveId` does not), so a snapshot can carry a CVE id K refuses; the adapter turns that into `PT-PILOT-INPUT` / `snapshot-record` (test). A contradiction on products mapped to neither side still makes the CVE gate `conflict` (the synthetic rev1 + rev2 + VEX set shows it), as the plan's table says.
- Full suite: not run (focused slice, no shared file touched). Existing neighbours run once with the new file: `tests/test_pilot_contracts.py`, `tests/test_pilot_keys.py`, `tests/test_intel_explain.py`, `tests/test_enrichment_cve.py`.
- Not verified here: Windows (CRLF checkout of the fixtures, short ids) and CI; the frozen executable (nothing imports `patchtrace.pilot` yet); any real Microsoft CSAF, NVD or MSRC data (BLOCKED as K); the KEV and KB tracks (ports and fakes only).
### [WBQ-S7:codetext-core] WBQ S7 (2026-10-14, Linux container, 4 vCPU, CPython 3.13.16 and 3.12.3 (throwaway venv, wheels only), Pygments 2.21.0, hypothesis 6.169.1; SYNTHETIC text only, none of it live evidence)
| Check | Evidence | Result |
|---|---|---|
| Slice tests | `tests/test_codetext_tokens.py` (218) and `tests/test_codetext_palette.py` (88), `QT_QPA_PLATFORM=offscreen nice -n 10 python -m pytest ... -q -p no:cacheprovider`; hypothesis `FAST` profile, five seeds (1, 7, 42, 2026, 31337) | 3.13.16: 305 passed, 1 skipped (the optional colorspacious oracle), 9 s; 3.12.3: 304 passed, 2 skipped (that one and the PySide6 parity test), 7 s |
| Lint | `python -m ruff check` on the package and both test files | clean |
| Lossless and total | hypothesis over arbitrary text (lone surrogates, NUL, astral characters) and over a soup of quotes, comment markers, controls and bidi characters, both languages: contiguous, non-empty, known kinds, a newline only in its own `ws` | holds |
| Pygments agreement (comment, string, number boundaries) | hypothesis in the test; scratch sweep of 40,000 generated programs per language with another generator (CLexer, NasmLexer) | 0 differences; the known differences are pinned by `test_documented_differences_from_pygments` |
| Time, 200,000 characters (best of 5; gate 150 ms) | `test_200k_characters_tokenize_within_the_budget` | C 57 ms, assembly 53 ms; `open_comment_lines` 3.7 ms; worst of 15 hostile inputs (78-120k characters, both languages) 126 ms against a 3 s bound that a backtracking string rule exceeds |
| Contrast | the WCAG formula recomputed in the test; parity with `ui_evidence.contrast_ratio` on random colours | every text role >= 4.5:1 on `#10151c`, `#263a43`, `#33392b` (minimum: comment on the replace hunk, 4.81); marks >= 3:1 (changed 8.98 on the hunks); the plan's printed table reproduces within 0.05 |
| Colour-blind distances | CIEDE2000 (reproduces 10 published Sharma-Wu-Dalal pairs to four decimals) on Machado 2009 severity-1.0 simulations | scalar vs address: deutan 35.58, protan 42.73, tritan 8.42; register vs address: minimum 10.27 (protan); the plan prints 35.6, 8.4 and 10.3 |
| Matrix provenance (scratch checks) | the 27 entries in the test file against `MACHADO_ET_AL_MATRICES[...][100]` of colorspacious 1.1.2 (AST read, no execution); the simulation against `cspace_convert` (library scanned for I/O and dynamic code first, imported from a scratch directory) on 300 random colours | all 27 entries exactly equal; outputs equal within 1e-9 |
| Mutation check (scratch script, not committed) | 21 textual mutants: coverage, window state, caps, string/number/comment lexing, the word memo, name patterns, the mnemonic slot, palette contrast, the binding to ui.py, the guard boundary, the contrast formula, colour-blind distance | all killed; one weak spot found and fixed on the way (the guard threshold was not tested at equality) |
| Not verified here | Windows and the frozen EXE; the Windows runner's timing; real SPEC-31 instruction text and real Microsoft-built decompiler output; screen-reader announcement, DPI and high contrast (S9's gates); the full suite (the integrator runs it) | open, see tasks/todo.md [WBQ-S7:codetext-core] |
### [PIL-T:oracle] Patch-intent oracle (2026-10-14, builder worktree on `worktree-agent-a73e5a716ab3ade24`; Linux container; synthetic data only)
- Red first: the oracle was written against the A1 contracts before an engine exists, so the 22 engine tests are red by construction: each reaches `localize()` and stops with `EngineMissing` (`patchtrace.pilot.service` missing), which `xfail(strict=True, raises=EngineMissing)` expects and nothing else. A wrong fixture, a bug in a fake port or a changed plan therefore fails normally instead of hiding behind the marker. Green: `tests/test_pilot_synergy.py` and `tests/test_pilot_sample_e2e.py` give 40 passed, 22 xfailed in about 3 s on Python 3.13.16 and on CPython 3.12.3 with pydantic 2.13.5 (the CI pin, scratch venv); `ruff check` clean on the four new Python files; the tests are also clean under `python -X dev -W error`.
- Oracle validity (not committed): a throwaway reference engine implementing one reading of plan s7 (gate, expected changes, components over supporting shape observations, the two caps, contested, the order key and the code-only key) reproduces all nine rows of the s5 arm table exactly (F1 ranks 1, 1-3, 1-5, 3-5, 2-8, 1-2, 1, 1, 1 and the FITS sets), the full-arm classes and the second CVE, and passes all 22 engine tests with the markers ignored. 12 deliberate defects of that engine were each caught by at least one test: advisory repeats counted as independent, B1 and ChangeFacts as two witnesses, call labels as a third witness, window cap off, toolchain cap off, a cap that applies only with typed support (a tier rises when support is removed), a tier raised when one observation is dropped, KEV changing function order, RVA as the tie-break, nuisance ignored, contested pairing not sorted last, a tool that did not run read as a negative vote.
- Plan s5 reading that the fixtures fix (reported to the owner): the "2-8" row of the FLOSS arm needs F3's DiE `toolchain-changed` nuisance in every arm; a binary-level toolchain flag in the full arm would cap F9 (lexical B1 evidence only) and contradict "F9 NEEDS REVIEW", so it is attached to F3 and the cap test broadcasts it explicitly; the F1 "why" text says capa and FLOSS were not run while the full arm holds F2's FLOSS evidence and the "drop capa" test needs capa available, so the full arm has both available and the text is kept as `unknown_when_tools_not_run`; the description "heap-based buffer overflow" also yields CWE-122, a second hypothesis of the same rule, so `fits[0]` is the explicit CWE-787 one.
- Not verified here: a real PIL-B2 (none exists), Windows (CRLF checkout, `PYTEST_CURRENT_TEST` length, subprocess check) and CI, live Microsoft CSAF (the fixtures are synthetic and say so), Tier W.
### [PIL-A3:code-adapters] Patch-intent localization code-side adapters (2026-10-14, builder worktree on fd6cdba; Linux container, CPython 3.13, synthetic data only)
- Red first: `tests/test_pilot_sources_code.py` failed at collection (`cannot import name 'pe'`, then `code`, `tools`, `unified`) before each module existed. Green: 159 passed in about 3 s together with `tests/test_pilot_{contracts,keys}.py` and `tests/test_unified_import_dag.py` (531 passed on CPython 3.13.16); the new tests and the two PIL-A1 files also pass on CPython 3.12.3 in a private venv (pydantic 2.13.5, protobuf, pytest, hypothesis; no PySide6 installed): 518 passed. Neighbouring suites `test_kbc_contracts`, `test_unified_parity`, `test_intel_tools_audit`, `test_enrichment_signals` 198 passed; `ruff check` clean on `src/patchtrace/pilot` and the test file. The full suite was not run (no existing file changed).
- Gates: cosmetic proof kept as a `conflict` next to the B1 guard it contradicts; unlocalized capa (file scope, no function, a link that only carries an address) never attaches and appears only as bounded pair context; FLOSS static and language strings never attach (even with a function's RVA on the link), stack/tight/decoded strings attach to the function that builds or decodes them; Ghidriff call labels are `label-only` with and without a PE import delta, the import fact being a separate `verified-bytes` observation with origin `D_pe_tables`.
- Real code paths, synthetic inputs: B1 is the real detector set on imitated decompiler text; T deltas come from T's own `delta.compute` over evidence sets built in code (so the attachment rules meet T's real `newly-introduced`/`newly-detectable`/`unlocalized` classes); the unified result is produced by the real in-process S0 pipeline on `unified_s0_fixtures.make_project` and read back through `unified.store`; PE layouts and import tables come from `pe_overview.inspect_pe` on `tests/pe_builder.py` images. The Ghidriff row key equals the unified `row_id` of the same functions on that project.
- Mutation check (throwaway script, not committed): 29 single-point mutations of a scratch copy of the five modules (label-only to tool-reported, cosmetic or unchanged to shape, the LOCALIZED gate, the static-string gate, contested identity, mixed address basis, the text-only ceiling, truncated tables, tool orientation, review obligation, per-candidate cap, auto labels, heuristic-only flag, capa backend origin, stale unified result, B1 role and coverage, secret redaction, PE witness without a gained import, reversed secondary set, unified pair check, candidate limit, key ordering, library capabilities, newly-detectable, wide rows): 28 killed; the survivor removes the equal-callee-list shortcut, an equivalent mutant (a speed-up with no visible effect). One test was strengthened after the key-order mutation survived the first round.
- Scale (shared container, 100,000 modified pairs of one callee change each, before this note): `GhidriffRows.resolve` 3.2 s, `GhidriffPairing` 4.0 s, `CandidateIndex` 0.9 s, `GhidriffCalls` 9.0 s (100,000 observations at about 70 us each, most of it `keys.make_observation`); an unchanged callee list is skipped without cleaning. Targets in plan s7 belong to `localize` (PIL-B2).
- Found while building: the editing tool turned `‮` escapes typed in a test into the literal bidirectional character (the same slip as in PIL-K1/K2); fixed with escapes built from `chr()`, and `test_the_new_files_hold_no_hidden_or_bidirectional_characters` now scans the five modules and the test for Cc, Cf, Zl, Zp. `GhidriffRows` follows the unified basis rule: one address outside the image makes the whole set not comparable (nothing resolves, the status says so).
- Not verified here: Windows (path handling of unified result directories, the child process of the purity test, CRLF), the frozen executable (nothing imports `pilot.sources` yet), real Ghidriff output (callee label spelling decides whether the PE witness ever applies), real capa/FLOSS/DiE runs, a unified result with ProgramIR.
### [R0:rules-contracts] YRX R0 contract freeze (2026-10-14, Linux container, Python 3.13.16; synthetic data only, none of it live evidence)
- `pytest tests/test_rules_contracts.py`: 279 passed in 1.7 s; `ruff check` clean on the new files; `PYTHONPATH=src python tools/generate_rules_schemas.py --check` clean. Hypothesis (200 examples each) checks that any bytes escape to text the contract accepts and counts, and that an unescaped quote, backslash or non-printable never passes as escaped text.
- Not verified here: Windows (CI), the full suite (the integrator runs it), and any behaviour of YARA-X itself (R2).
### [R2:rules-engine] YRX R2 engine, worker and runner (2026-10-14, Linux container 4 vCPU, Python 3.13.16, yara-x 1.21.0 from the wheel; SYNTHETIC images only, none of it live evidence)
- `pytest tests/test_rules_contracts.py tests/test_rules_engine.py tests/test_rules_worker.py`: 422 passed in 21 s (294 contracts, 42 engine, 86 worker); three consecutive runs identical; `ruff check` clean on the new files. The engine tests run the real YARA-X (no mocks); the worker tests include real children (golden grid, missing engine, memory caps) and fake children (every wrong result, hang, flood, cancel, grandchild kill).
- Measured: see tasks/todo.md [R2:rules-engine] (start-up, memory caps by RLIMIT_AS, timeout granularity). Probe in-process 18 ms.
- Not verified here: Windows (CI), the frozen worker, the full suite (the integrator runs it), the decoder path with a real iced-x86 wheel, behaviour of the engine's JIT under Defender, EDR or Arbitrary Code Guard.
### [WBQ-S1:pe-rsrc] WBQ S1 (2026-10-14, Linux container, CPython 3.13.16 and 3.12.3; synthetic PEs, plus real third-party PEs read in place and never committed)
| Check | Method | Result |
|---|---|---|
| Tests | `tests/test_pe_resources.py` (52), `tests/test_pe_version_info.py` (57), with `tests/test_pe_overview.py` (54 existing, unchanged) | 163 pass on CPython 3.12.3 (scratch venv) and on 3.13.16; pefile 2024.8.26 was installed outside the repository so the oracle tests ran instead of skipping. The combined S1 + S2 run is in [WBQ-S2:pe-manifest] |
| Real PEs, whole readers | a scratch script (not committed) over every distinct PE found on this machine: 16 with a resource directory (MSVC-built distlib and setuptools launchers for x86, x64, ARM64 and ARMNT; MinGW-w64 `libwinpthread-1.dll` in 32 and 64 bit, built by GNU ld and windres) and 40 without one | 0 disagreements with pefile on leaves (type, name, language, RVA, size, code page), fixed file info, string tables (case-insensitive table key), manifest SHA-256; primary block equal to `csaf.identity.read_version_info`. Real quirks seen and handled: a StringTable key `080904B0` beside a Translation of `0409/04B0`; windres writing `1, 0, 0, 0` as the FileVersion string. The same parity is a test over pip's vendored launchers (`test_agrees_with_pefile_on_real_windows_launchers`, skips when pip carries none, as Debian's does); it ran on 3.12.3 against pip 26.2.1's six launchers |
| Hostile timings (walk only, best of 5) | fan of 4,096 entries; 4,096 entries sharing one 65,535-character name; 4,096 distinct 256-character names; 2**31-path DAG of 63 directories; 3,999 directories with 3 leaves (16k nodes) | 22 ms; 48 ms; 73 ms; 0.9 ms; 110 ms. The gate is 250 ms each; the tests assert it on the best of 3 runs |
| Mutation sanity | 30 one-line mutations of the two parsers (visited set, caps and their off-by-one boundaries, id mask, alignment, NUL parity, key checks, clamp, rules) | 25 killed on the first run; the 5 survivors were real test gaps (node-cap boundary, unbounded name reads, id high bits, window edge, fixed value past the root length) and got tests; 30 of 30 killed after |
| Lint | `ruff check` on the five files | clean |
Not verified here: Windows (clock granularity, file handling), real Microsoft PEs, the loader's count-versus-bit classification of entries.
### [WBQ-S2:pe-manifest] WBQ S2 (2026-10-14, Linux container, CPython 3.13.16 and 3.12.3, expat 2.6.1; synthetic manifests, plus the manifests of the real PEs listed in [WBQ-S1:pe-rsrc])
| Check | Method | Result |
|---|---|---|
| Tests | `tests/test_pe_manifest.py` (141), with the S1 files, `tests/test_pe_overview*.py` and `tests/test_unified_ir_pe_tables.py` | 362 passed, 1 skipped on 3.12.3 (pefile and pip 26.2.1's launchers present) and 359 passed, 4 skipped on 3.13.16 (pefile present; the 3 launcher tests skip because Debian's pip strips the executables; the 4th skip is the Windows-only WinVerifyTrust test) |
| Real manifests | the 14 launcher PEs with a manifest, read in place | SHA-256 equal to the bytes pefile reads at the same RVA and size; all parse with no warning; every one reads as the linker's bare UAC fragment (`asInvoker`, `uiAccess` false, no `assemblyIdentity`, no `supportedOS`, no DPI settings); the one printed in full (`t64.exe`) uses CRLF and `<x></x>` elements. Real manifests with an identity, dependencies, `supportedOS` or DPI settings were not available here |
| Entity expansion measured | `ET.fromstring` on `<!DOCTYPE r [<!ENTITY e "hello">]><r>&e;</r>`; on a three-level declaration set | the internal entity expands (`'hello'`; 100,000 characters from three declarations in 0.7 ms). Only external (SYSTEM) and undefined entities raise ParseError. The plan's table row "ElementTree never expands entities" is therefore wrong for internal entities, which is why DTDs are refused before parsing, not left to the parser |
| Encoding and parser behaviour | `ET.fromstring(str)` with five different declared encodings | the declaration is ignored for text input, so the bytes are decoded once here and the scanned text is the parsed text |
| Hostile shapes within 2 MiB | 11 shapes: 100k-deep nesting, 400k siblings, 100k attributes, 60k xmlns declarations, 150k unique tag names, 150k dependency elements, a namespace redeclared at 40k levels, and others | 34 to 486 ms each. One shape (400k namespaced siblings) took 2.0 s until the fact extraction made one pass over the root's children instead of about ten; fixed |
| Mutation sanity | 34 one-line mutations (DTD scan and its case and entity halves, scanning bytes instead of text, parsing bytes, UTF-32, NUL padding, caps and budgets, namespaces and years, root and depth checks, list caps, sorting, cleaning) | 29 killed on the first run; the 5 survivors were test gaps (UTF-16 BOM padding, stage-level cancel, GUID order, identities under the wrong parent, nested identity first) and got tests; 34 of 34 killed after |
| Lint | `ruff check` on the two files | clean |
Not verified here: Windows, real manifests from Microsoft binaries, the Windows loader's tolerance for the inputs this reader calls invalid.
### [FAB-0:fabric-core] Anchor fabric pure core (2026-10-14, builder worktree on fd6cdba; Linux container, synthetic data only)
- Red first: all six new test files failed at collection (`No module named 'patchtrace.fabric'`) before the package existed. Green: `tests/test_fabric_{contracts,ids,origins,memory,synergy,plan}.py` 331 passed in about 2 s on Python 3.13.16, and on Python 3.12.3 (scratch venv, pydantic 2.13.5, the CI pin) together with `tests/test_pilot_keys.py`; `ruff check` clean on `src/patchtrace/fabric` and the new tests.
- Gates: the identity formulas against an independent re-implementation of the domain-id formula plus pinned literal goldens; `pair_key` equal to `unified.keys.row_id` and `pilot.keys.candidate_key`; `components` equal to `pilot.origins.components` on random tag sets and the default table a superset of PIL's; `clean_line` equal to `sanitize_text`, code point by code point over the BMP; the plan's kind table, roles, vocabularies, error codes and limits equal to the code (`test_fabric_plan.py`); the synergy scenario of plan s5; order independence of publishes (all 24 orders of 4 batches), idempotent republish, atomic failure, replacement per (producer, batch), concurrent writers.
- Test strength: 71 single-point mutations of a scratch copy of `src` (identity payloads, key folding and grammar, role and side rules, orientation reasons, origin guard, replacement, merge, limits, atomicity, locking, strictness, vocabularies, exit codes). First run 65 killed and 4 survived: tie-breaking by subject was exercised by too few rows, the writer lock was not exercised, `extra='forbid'` was tested through a payload that failed for another reason, and the `Resolution` status check was untested. Each is now closed by a test (an 8-row tie test, a deterministic writer-gating test, JSON-mode strictness cases, a status test); second run 71 of 71 killed.
- Measured at F-01 (20,000 one-witness anchors with facets, CPython 3.13.16, one machine): building 2.26 s, `publish` 0.52 s, a 500-row `find` page 71 ms, `resolve` 14 ms, `digest` 0.07 s, `verify_anchor` over all 0.74 s; the JSON is 11.1 MiB (583 bytes per anchor) and revalidates in 0.75 s. Budgets to re-measure on Windows CI.
- Found and fixed while building: the authoring tool turned typed `\u` escapes into the raw characters, which put 25 invisible characters (bidirectional controls, U+2028 and U+2029, a combining mark) into the sources; they are now built from code points and `test_no_fabric_file_hides_an_invisible_character` scans every FAB file; `api_key` is not idempotent (a second fold), so it is documented as applied once to a producer's raw name; the plan's first draft claimed a 20,000-anchor batch always fits the 32 MiB row, which only holds for typical one-witness anchors (the store, not F-01, must refuse a body above 24 MiB).
- Regression subset (existing tests that scan source trees or docs: unified packaging, import DAG and contracts, calibration runtime, PE overview, KBC contracts, backend bundle build, spec registry, pilot contracts and keys): 884 passed, 1 skipped (pre-existing). The full suite was not run (the integrator runs it twice). GitHub was not consulted (worker brief rule: no GitHub access).
- Not verified here: Windows (CRLF checkout, short ids, path handling) and CI; the frozen smoke (nothing imports `patchtrace.fabric` yet); behaviour with the enrichment store, the GUI and the CLI (later slices); no live or Microsoft data was involved.
### [K1a:kev-core] KEV K0 + K1a (2026-10-14, Linux container, CPython 3.13.16 and 3.12.3)
| Check | Command / method | Result |
|---|---|---|
| K0 data | LF bytes and no BOM; README inventory (file and 12 entry SHA-256); every trimmed entry identical to the upstream entry; vendored schema pinned | all equal. The upstream catalog fetched again on 2026-10-14 (1,780,479 bytes, 1,741 entries) has the SHA-256 `136904f1...` of plan fact F1; the schema `0d5865c9...` (F2) |
| K1a tests | `QT_QPA_PLATFORM=offscreen python -m pytest tests/test_kev_{contracts,parse,join,view_model,boundaries,schemas}.py -q` | 415 passed in about 4 s on 3.13.16, and the same 415 on the CI pin 3.12.3 (scratch venv, pydantic 2.13.5) |
| Lint | `ruff check` on the K1a files | clean |
| Red, then green | contracts and parse, join, view model and schemas were written before the code; red was ModuleNotFoundError or missing generated files | yes |
| Mutation sanity | 39 one-line mutations (CVE regex, duplicate and count checks, digest inputs, text cleaning, surrogates, freshness boundaries, time zone, reading order, copy, tooltip rules, forbidden imports, clock read) plus one no-op control | 39 killed, the control survived as designed. Found while writing and reviewing: a validator that rejected the cleaned echo of a padded ID (fixed); a process-wide import check that cannot hold on 3.12, where `pathlib` imports `urllib.parse` (narrowed to the modules that can do network I/O); a lone-surrogate escape in `cveID`, `dateAdded` or `dueDate` that raised `UnicodeEncodeError` from the hashing before the model checked the field (fixed with an ASCII check; Hypothesis seldom draws surrogates, so the property adds one to every example) |
| Budget | parse of 3.0 MB / 1,741 entries; 20,000 entries; 100,000 `cell()` calls over 3,000 CVEs; filter plus reading order over 100,000 cells | 0.13 s (target 0.2 s, ceiling 1.0 s); 1.1 s; 0.04 s (ceiling 1.5 s); 0.03 s (ceiling 1.0 s) |
Not verified here: Windows (CI), the canonical `www.cisa.gov` feed URL and its licence text (this sandbox reaches only the GitHub mirror), anything with Qt (K3), Narrator and NVDA reading of the cell sentences.
### [K1b:kev-store] KEV K1b snapshot store (2026-10-14, Linux container, CPython 3.13.16 and 3.12.3)
| Check | Command / method | Result |
|---|---|---|
| K1b tests | `QT_QPA_PLATFORM=offscreen python -m pytest tests/test_kev_store.py -q`; with the K1a files, `tests/test_kev_{contracts,parse,join,view_model,boundaries,schemas,store}.py` | 56 passed; 473 passed in about 9 s, the same on 3.13.16 and on the CI pin 3.12.3 (scratch venv) |
| Lint, schemas | `ruff check` on the KEV sources, tests and `tools/generate_kev_schemas.py`; `generate_kev_schemas.py --check` | clean; unchanged (the store adds no persisted contract) |
| Red, then green | the store tests were written before `store.py` (red was ModuleNotFoundError); two late additions (the usual case lists no snapshots, a size sum that tolerates a file pruned meanwhile) were red first as well | yes |
| Crash points | `test_install_crash_points_keep_previous_current`: simulated process death (a `BaseException`, nothing cleans up) before the snapshot, the meta and the pointer are published and at each of the three `os.replace` calls; a Hypothesis run of up to 8 installs with random crash points | the previous catalog stays in use and loads without notes, a new snapshot is listed only as a whole pair, repeating the install succeeds; the catalog in use never gets older and `load_current` never raises |
| Windows behaviour | `os.replace` raising `PermissionError` twice, then three times | the third attempt succeeds (back-off 100 ms times the attempt, injected `sleep`); three failures give `PT-KEV-STORAGE`, leave no temporary file and keep the previous catalog in use. Real sharing violations are not reproduced here |
| Hostile store | garbage, truncated, wrong-hash and foreign gzip files; a description that is valid but describes other bytes; a gzip bomb of 64 MiB zeros in about 64 KiB; ids such as `../../etc/passwd` | each falls back to the previous snapshot with a note, or is refused; the bomb is cut at 16 MiB (tracemalloc peak under 40 MiB) and nothing is parsed before the hash matches |
| Mutation sanity | 27 one-line mutations (release comparison, shrink boundary, `accept_shrink`, write order, pointer last, prune confirmation and the catalog in use, bomb cap, id check, hash check, description check, back-off, retry count, orphan removal, listing, newest by release, fallback notes, size sum, a leftover temporary counted as a catalog) | all killed. The first runs left survivors that became tests: install order, hash before parse, a description that lies, listing hides descriptions without a snapshot, one load per failed snapshot, a pointer that disagrees with its catalog, a leftover temporary is not a catalog, release order judged against the catalog in use |
| Budget | `install`, `load_current` (best of 3, includes the parse) and `status` on synthetic catalogs, shared 23-worker machine | 1,741 entries (1.1 MB): 34 ms, 85 ms, 106 ms (plan target: load under 1.0 s); 20,000 entries (12.6 MB, the limit): 167 ms, 1.5 s, 1.8 s. `status` loads the catalog in use to prove it is readable, so it costs one load |
Not verified here: Windows (CI), real sharing violations (an antivirus scanner holding a file), two processes installing at once (the unlocked check-then-replace is documented), disks that do not honour `fsync`.

### [FAB-2:converters] Anchor converters and registry rows (2026-10-14, worker worktree on b4fdd2b; Linux container, synthetic data only)
- Red first: `tests/test_fabric_convert.py` failed at collection (no `patchtrace.fabric.convert`); the four new registry-row tests and the exact-additions test failed on unknown sources; the package file list test failed on the missing `convert.py`. The golden digest then moved with the four rows and was updated in the same change.
- Green: `tests/test_fabric_{convert,contracts,ids,memory,origins,plan,synergy}.py` 363 passed on CPython 3.13.16 and 363 passed on CPython 3.12 (scratch venv, pydantic 2.13.5, hypothesis 6.169.1, pytest 9.1.1, binary-only wheels). `ruff check` clean on `src/patchtrace/fabric/{convert,origins}.py` and `tests/test_fabric_{convert,origins,contracts}.py`.
- Mutation spot-check: ten deliberate defects in `convert.py` (PDB source, pointer reference, string hash, pair key, feature role, phrase-kind facet, PDB name, PDB side, CVE key, prefix check), each applied alone to the worktree file for one run: 10 of 10 failed the converter tests; the file was restored and its SHA-256 compared equal.
- Samples: K from `tests/fixtures/csaf/synthetic-advisory-rev1.json` (CVE-2099-10001: module, feature, component, two hypothesis API hints, a verified PDB name) plus a quoted note string; PIL from the synergy-1 anchor id (`api:RtlSizeTAdd`), a candidate key from `pilot.keys.candidate_key` with its pair record, and CWE and CVE ids. Every converted anchor passes `verify_anchor` and `check_origins` and is accepted by `MemoryAnchorStore.publish` and `find`.
- Parity: `ids.pair_key_of` equals `pair:` plus `pilot.keys.candidate_key` for the sample pair; the default table contains every PIL source with equal tags and adds exactly the four FAB-2 sources; `capa` is unchanged.
- Not verified here: Windows and CI; the full suite (the integrator runs it); the enrichment store (FAB-1); the DiE `BuildFactAnchor` (not built). No live, network or Microsoft data was involved.
### [GUI-F1:core] GUI framework F1 (2026-10-14, local Linux worktree, CPython 3.13.16 with PySide6 6.12.0 and CPython 3.12.3 without PySide6; pure tests, nothing live)
| Check | Command / method | Result |
|---|---|---|
| F1 tests | 13 files `tests/test_gui_core_{text,theme_math,shortcuts,capabilities,state,projection,anchors,ports,registry,lint,manifest,cli,isolation}.py`, `QT_QPA_PLATFORM=offscreen python -m pytest <files> -q -p no:cacheprovider` | 507 passed on 3.13.16; 506 passed on 3.12.3 (the CI pin; scratch venv without PySide6, the one `ui_evidence` parity test deselected) |
| Lint | `ruff check src tests` | clean |
| Properties | hypothesis (derandomized, no example database): `sanitize_text` bounded, idempotent, control and bidi free, equal to a loop oracle; the whole BMP plus a stride through the other planes in both modes; panel id grammar and prefix-freeness; manifest lint against a naive oracle and its order invariance; shortcut normalisation; navigation history; match index against a brute-force scan | pass |
| Mutation sanity check | about 270 deliberate one-line mutations over the 11 pure modules and the isolation gates, each run against the F1 tests | all killed except 6 equivalents (a float boundary no 8-bit channel can hit, a redundant `bool(name)` guard, a one-element dict lookup, a `push` of the already current anchor, the order of two mutually exclusive state kinds, a no-op strip). Real gaps found and closed by tests: negative limits, overlapping allowed phrases, non-ASCII key names, slot shortcut spelling, `source` and `availability` angle brackets, command title length, framework keys for commands, empty teach steps, finding code of the imports rule, warnings for unknown anchor kinds |
| Fresh process | `panels list --json` and `panels check --json` through `add_parser` and `run` in a new interpreter | no Qt, networkx, pygments, rapidfuzz or yara imported (checked in the process); exit 4 because no panel is built yet; 14 rows |
| Import cost | importing `patchtrace.gui.registry` in a new interpreter | adds only the stdlib and the pure core (no tooltips table, models, pydantic, cli or manifest) |
Found while building: the Write tool decodes a lowercase backslash-u escape in file content into the raw character, so the sources use the 8-digit form; a same-size mutation restored within one second keeps its `.pyc` key (the scratch harness now purges bytecode).
Not verified here: Windows, the frozen build, `patchtrace panels` through `cli.main` (needs the F1b registry adapter), the full suite twice (integrator).
### [AI-FIX:ai-provider-fixes] SPEC-41 provider and interpretation fixes (2026-10-14, Linux container, CPython 3.13.16 and 3.12.3; loopback servers and fakes only, none of it live evidence)
| Check | Command / method | Result |
|---|---|---|
| Focused tests | `python -m pytest tests/test_providers_endpoint.py tests/test_providers_transport.py tests/test_interpretation.py tests/test_audit_ai_reports.py tests/test_cancel_latency.py -q -p no:cacheprovider` | 244 passed (39 in the same files before this slice); also 244 passed on CPython 3.12.3 (scratch venv, pytest 9.1.1, pydantic 2.13.5, no Qt) |
| Neighbours | `tests/test_core.py` and `tests/test_ui.py`, selected with `-k` for interpretation, context, evidence and provider | 14 passed |
| Lint | `ruff check` on the changed files | clean |
| Load | ten runs of the five files (244 tests) with eight busy loops competing for CPU | 10 of 10 passed after one flake was fixed (a 50 ms timer cancelled before the request had started, so nothing was abandoned) |
| R11 on the real interpreters | endpoint matrix on `python3.12` (3.12.3) and `python3.13` (3.13.16) | identical verdicts; `[::ffff:127.0.0.1]` and `[::ffff:7f00:1]` rejected on both |
| R7 on the real stack | scratch loopback server that sends the headers and stalls; cancel after 0.3 s, socket timeout 4 s | 4.07 s before, 0.33 s after |
| R14 on the real stack | scratch loopback server that sends the headers, one byte at 1.2 s, then stalls; deadline 2 s | 3.24 s before (the read that began at 1.2 s ran its own full timeout), 2.05 s after |
| Mutation checks | 48 one-line mutations of `providers.py` and `interpretation.py`, one at a time, each against the focused tests (10 wire-format, redirect and cap; 5 deadline and cancel; 8 credential rule, 4 against the Latin-1 version and 4 against the final printable-ASCII version; 4 error text; 21 claims) | all killed; two survivors in the claims set were closed with new rows and one malformed mutation was redone |
Not verified here: Windows and GitHub Actions; any live Ollama or OpenAI-compatible provider (mocked and loopback tests are not live compatibility evidence); real certificate-verification failures (only a plain-text answer to a TLS ClientHello was driven through the real stack, the certificate cases use synthetic `ssl` exceptions); the full suite (not run, per the worker brief).
### [S5:residual] SPEC-31 S5 (2026-10-14, Linux container, 4 vCPU shared with other workers, Python 3.13.16; SYNTHETIC data only)
| Check | Evidence | Result |
|---|---|---|
| S5 unit/property tests | `tests/test_unified_ladder_{assign,blocking,residual,residual_table,residual_perf}.py` = 14 + 29 + 60 + 29 + 7 tests; hypothesis derandomised | 139 passed |
| With the rest of the unified suite | `pytest tests -k test_unified` without the two perf files (S0a..S2 files, S5 fast files, import DAG, packaging) | 1258 passed |
| Lint | `python -m ruff check src tests tools` | clean |
| Not run | the full suite (the integrator runs it twice per wave) | - |
| Mutation sweep (scratch script, not committed) | 73 textual mutants of `assign.py`, `blocking.py`, `residual.py` run against the four fast S5 test files on a copy of `src/` (61 in the first sweep, 12 in a second batch) | 70 killed, 2 equivalent (`count >= total` vs `>` in `nats_nano` both give 0 at equality; `b2 <= b1` vs `<` in P18, equal newer fids cannot occur), 1 redundant line removed (the row-minimum duals of the LAP: identical optimum and speed on 300 negative-cost matrices). The first sweep left 18 survivors, 15 of them real test gaps (band width, bucket-cap boundary, n_bb ranking term, newer-direction top-K, exact cosine / confidence / margin edges, the mutual-best test, column-side LAP margin, P19 softness, P18 hub exclusion, P17 strict majority, P18 soft proposals, bucket-cap sides), the second batch two more (P18 ICF exclusion, P17 eligibility); all are tested now |
| Review finding, fixed | the LAP clock of L-24 first started before blocking, so a slow mnemonic source could trip the 30 s cap before any LAP ran | `test_the_lap_clock_starts_after_blocking_not_before` |
| G-U5, 10k functions (generator of tests/unified_ir_builder.py: 50 % edited, 20 % address-shifted, 1 % duplicates; mnemonic streams derived from the ground truth) | printed by `tests/test_unified_ladder_residual_perf.py -s` | ladder 1.37 s (L-35: 15 s; gate with 5x slack: 75 s), residual stage 0.20 s (P16 0.17), 99,502 budget ticks, 9,821 pairs, residual pools 424 / 407 functions, 223 blocked pairs (a full matrix: 172,568), 29 LAP buckets |
| G-U5, 60k functions, same generator | same | ladder 11.2 s (L-35: 120 s; gate 600 s), residual stage 1.70 s (P16 0.98, P17 0.01, P18 0.06, P19 0.64), 632,764 ticks (10.5 per function), 59,010 pairs, pools 2,732 / 2,762, 1,566 blocked pairs (a full matrix: 7.5 M), 187 LAP buckets, `limits_hit` only `neighbour-cap` |
| G-U5, all-residual worst case, 60k per side | `dense_world`: no content key agrees between the sides, each function calls 3 of 10 common imports (token buckets of thousands) and has 2 rare strings that only its twin shares | ladder 30.6 s, all of it the stage (P16 30.0 s: blocking, 120k MinHash signatures and vectors); 267,371 blocked pairs (a full matrix: 3.6 billion), 7.7 M bucket members enumerated, 160 buckets abstained (`block-cap`), 60,000 of 60,000 twins found, none wrong |
| Informational, not gated: 250k functions, same generator as the 60k run | one run via `run_generated(250_000)` | ladder 94.1 s, residual stage 7.4 s (P16 4.4, P19 2.5), pools 11,169 / 11,138, 7,064 blocked pairs, 722 LAP buckets; process peak RSS 2,009 MiB including the generated rows |
| Precision per pass and tier at 60k, against the generator's ground truth | S2 tier A 35,312 of 35,312 right; S2 tier B 21,894 of 21,896; S2 tier C 395 of 395; P16 tier C 162 of 162; P17 tier C 1 of 1; P18 tier C 1,213 of 1,214 (0.9992); P19 tier C 30 of 30. At 10k every pair right (P16 30, P18 178, P19 3). The stage adds 739 pairs at 60k (59,010 vs 58,271 for the S2 table alone on the same world) | REPORTED, not a claim: the generator keeps most of the layout (P18 contributes most pairs), edits whole functions at once, and has no hostile near-duplicates; the gate only asserts that the stage's own tier-B pairs are all right and that its pairs are >= 95 % right on this generator |
| Determinism | `test_the_result_digest_is_stable_across_hash_seeds_and_processes` (3 interpreters, PYTHONHASHSEED 0/1/4242), row-order permutation, side-swap mirror and budget-prefix properties with the stage on; the MinHash golden vector was verified once against a naive loop sharing no code | identical digests |
| Not verified here | Windows and the frozen EXE; Python 3.12 (CI pin); IR from real Ghidra or MSVC binaries (the mnemonic streams are synthetic); the cost of decoding real `ins` blobs; per-pass precision on Tier R (G-U3, S6); the spec constants (16 permutations, 4 x 4 bands, floor 0.6, margins 0.05, cosine 0.95, 1 nat) are untuned on real data | open, see tasks/todo.md [S5:residual] |

### [F4:virtual-table] VirtualTable gates
| Check | Method | Result |
|---|---|---|
| `data()` calls independent of N | `assert_lazy_model` at 10k and 100k, plus reset, sort and filter ceilings of 7 x visible cells x 1.2 + 20 | 462 calls at both sizes (ceiling about 725) |
| Time | reset, sort, filter after processEvents, ceilings 0.5 s (10k) and 1.5 s (100k) | 7 to 39 ms measured on Linux |
| Not verified here | Windows timings, real UI Automation output for the table | open |
### [GUI-F3:widgets] GUI framework F3 (2026-10-14, local Linux worktree, PySide6 offscreen)
| Check | Evidence |
|---|---|
| Dark stylesheet equals ui.DARK_STYLE | tests/test_gui_theme.py golden; every dark token pair meets 4.5:1 text and 3:1 non-text (contrast_problems empty) |
| State copy, precedence, actions, announcements, hostile text, a11y_audit in all 12 states | tests/test_gui_state_view.py |
| qt_gate repeat 10 over the five F3 files | 1,770 passed, no abort or surviving thread |
| Not verified here | Windows, real screen readers, high contrast, DPI scaling, the frozen build |
### [F6b:graph-canvas]
| Check | Result |
|---|---|
| test_gui_graph_view.py and test_gui_qt_canvas.py, qt_gate repeat 5 | 295 passed, no abort or surviving thread |
| Not verified here | Windows timings, real screen readers, DPI scaling |

### [F6a:codediff]
| Check | Evidence |
|---|---|
| Layers, hunk API, caps, truncation, hostile text, scroll sync, stub windowed highlighter survives set_pair | tests/test_gui_codediff.py, tests/test_gui_pair_text.py |
| Not verified here | Windows rendering, screen readers, high contrast, highlighter cost at 65k lines |

### [GUI-F5:host] GUI framework F5 (2026-10-14, local Linux worktree, PySide6 offscreen)
| Check | Evidence |
|---|---|
| Shells, lazy build, replay, dirty, debounce, blocked, failed factory, ports, anchors | tests/test_gui_host.py (26 tests) |
| Layout round trip, damaged blob (digest, schema, oversize, garbage, missing), reset, no "objectName not set" warning, tab bar names, View menu, central wrapper | tests/test_gui_host_layout.py |
| Palette filter, recent, unavailable reasons, Enter, Escape (does not fire Cancel job), arrows, announcement, hostile titles, host commands, F6 cycle, Ctrl+Shift+P | tests/test_gui_host_palette.py |
| ui.py budget, forbidden APIs (new code zero, legacy counts only shrink), one main window, accessibility audit of host widgets, legacy evidence dock survives the saved layout, shutdown | tests/test_gui_host_seam.py |
| qt_gate repeat 5 over all GUI test files (1,133 per pass) | 5,665 passed, no abort or surviving thread (an earlier run on a loaded CPU failed F4's timing ceiling test `test_data_calls_are_independent_of_the_row_count` once, 0.095 s against 0.057 s; it passed on rerun) |
| Not verified here | Windows, real screen readers, frozen build self-check, the 20x gate |

CI job text for the integration owner (`.github/workflows/qa-windows.yml`, after the existing Qt steps; Linux PR job uses `--repeat 20`):
```yaml
      - name: GUI repeat gate
        run: python tools/qt_gate.py --repeat 5
        env:
          QT_QPA_PLATFORM: offscreen
```

### [F8:evidence-migration]
- Automated: tests/test_evidence_host.py, the C6 suites (test_evidence_ui.py, test_ui_engine_setup.py), test_tooltips.py, test_gui_host_seam.py; Qt gate `python tools/qt_gate.py --repeat 5` over them.
- Manual, not run: the evidence panel as a dock in the saved layout on Windows (shortcut Ctrl+Shift+E, dock tabs with Unified later, floating on a second monitor), part of M23.
### [F7:theme] Theme variants (manual M22 on Windows)
1. View > Theme > System, then switch Windows between light and dark: window, tables, chips and code panes follow without restart; text stays readable.
2. Turn on a Windows high-contrast theme (Alt+Left Shift+PrtScn): the stylesheet is gone, chips are outlined text with a 2 px edge and no fill, diff hunks are underlined, the focus ring is visible on every control; the Theme submenu shows the disabled note. Turn it off: the chosen variant returns.
3. Settings > Accessibility > Visual effects > Animation effects off: menus and tooltips appear without fade or slide.
Automated evidence uses a simulated provider only; no test touches real OS settings.

### [F9:series-files-docks]
- Automated: tests/test_ui_m3_docks.py, test_ui_series.py, test_alpha_integration.py, test_preflight_overview.py, test_ui_audit_p2.py, test_tooltips.py, test_gui_host_seam.py (incl. `test_no_new_top_level_window`); `python tools/qt_gate.py --repeat 5` over the default GUI set: 6,260 passed.
- Manual, not run: Series tabs (open two files, close with the tab button and the keyboard) and the Files dock in the saved layout, floating and docked, on Windows.
### [RA-FIX-1:audit-fixes] Random audit 1 fixes RA-1, RA-4, RA-8, RA-9, RA-10 (2026-10-14, worktree on f94875c; Linux container, synthetic data only)
- Red first: each new test file failed before its fix (entropy budget and layout 9 of 10, offline cache 10 of 11, hostile text 3 failures after the predicate existed, bench RSS 4 of 4, `-0.0` 1 of 1), for the reason the audit named (for example 263,024 bytes read by `layout_from_reader` on a 128 KiB image; `0.0 is None` for the RSS report). Green: 53 new tests in 1.5 s (`tests/test_pe_entropy_budget.py` 11, `test_intel_offline_cache.py` 11, `test_hostile_text.py` 27, `test_bench_enrichment_report.py` 4); no test measures wall time.
- Recipe R1 at full size (96 sections over one 8 MiB range, 8,392,776 bytes): 34.3 s before (audit), 1.4 s after, status `partial`, warning `entropy_budget_exhausted`; the honest one-section file of the same size 0.5 s before and after. Recipe R4 and R6 are covered by scaled tests (`test_an_over_cap_legacy_index_survives_a_put_untouched`, `test_the_report_says_null_not_zero_without_the_resource_module`).
- Regression subset: two overlapping selections (67 and 34 test files) of the tests that touch `pe_overview`, `inspect_pe`, the tool adapters, `tier_w`, unified, preflight and the inspection UI (3378 and 856 passed; the skips and xfails are existing markers); `tests/test_intel_transport.py`, `test_intel_cli.py`, `test_intel_discovery.py` and `test_enrichment_perf.py` pass; `ruff check` clean on every file changed. The full suite was not run (the integrator runs it twice).
- Test strength: four one-line mutations (budget off by one, budget never spent, `put` reading its shard leniently, format characters dropped from the hostile rule) each failed 3 to 11 of the new tests.
- Cost of the budget: a file whose sections and overlay hold more than 32 MiB of raw data (each range counts at most 8 MiB) now reports `entropy` None, or a shorter sample, for the ranges after that and status `partial`; typical Windows binaries (one or two sections above 8 MiB) are unchanged.
- Not verified here: Windows (shard file names, `os.replace` over an existing shard, the macOS `ru_maxrss` unit is tested with a stand-in module only), real Microsoft binaries, a cache written by the first version on a user's machine (only a synthetic `urls.json`), more than one process writing one cache.
### [CONSENT:network-consent-tests] Network consent tests (2026-10-14, builder worktree on 994c336; Linux container; CPython 3.13.16; synthetic data only)
- Red first: `tests/test_network_consent_guard.py` failed at collection (`No module named 'network_guard'`) before the guard existed. The credential scan was red before the `redact_log` change: `AWS_SECRET_ACCESS_KEY=` and a fine-grained `github_pat_` token reached `analysis.log` and the UI log event of a real fake-child run. The other tests pin behaviour that already held, so their evidence is the mutation check below.
- Green: the five new files 119 passed in about 8 s; `ruff check` clean on them and on `diagnostics.py`; the 23 existing files that import `diagnostics` or exercise the code the new tests touch (`test_jobs`, `test_audit_*`, `test_child_env`, `test_calibration_tools`, `test_ui*`, `test_acquisition_transport`, `test_enrichment_intelligence`, `test_intel_*`, `test_spec_registry`, the unified, secondary and backend CLI files) 709 passed, 3 skipped (the skips are existing).
- Mutation check (scratch plugin outside the repository, nothing committed): 67 single-point mutants of the guard, `corpus.py`, `tier_r/fetch.py`, `tier_r/toolchain.py`, `acquisition/transport.py`, `enrichment/intelligence.py`, `intelligence/csaf/transport.py`, `backend.py`, `diagnostics.py`, `ui.py` and `cli.py` (consent gates removed, defaults flipped, secrets copied into settings or output, redaction stages removed); 66 killed. The survivor removes the CSAF host-consent check, an equivalent mutant while the URL allowlist names the only consentable host. Six cases were added after survivors (connect and sendto by host name, `Authorization: Token`, a bare `bearer`, the exit hint, the acquisition allowlist).
- Findings: the default `restrict_env=False` child inherits proxy and CA variables and tokens whatever the symbol setting (only restricted and bundle runs follow SPEC-42 row 9); `redact_log` leaves Cookie, SAS, Slack, JWT and `--password value` shapes; `cli.main` echoes unexpected exception text unredacted.
- Not verified here: Windows and CPython 3.12 (the new tests avoid POSIX-only calls and were written for both), the frozen executable, what Ghidriff does on the wire with `--no-symbols` (SPEC-42 E5), the full suite (the integrator runs it).
### [PIL-B2:engine] Patch-intent localization fusion, tiers, ranking and the service (2026-10-14, builder worktree on 994c336 (work/a); Linux container, CPython 3.13.16 and 3.12.3, synthetic data only)
- Focused run: `tests/test_pilot_{fusion,ranking,properties,synergy,sample_e2e}.py` 175 passed (fusion 48, ranking 50, properties 15, the PIL-T oracle 62 of which 22 were `xfail(strict)` and now pass for real) on both interpreters (3.12.3 in a throwaway venv without Qt); all ten `tests/test_pilot_*.py` files together 1128 passed in 46 s; `ruff check src/patchtrace/pilot tests/test_pilot_*.py tests/pilot_*.py` clean. The full suite was not run (no existing source file changed). `ruff check src tests tools` reports 4 import-order findings in four files this slice did not touch (`test_calibration_tools`, `test_site_build`, `test_unified_ladder_core`, `tools/build_windows.py`).
- Oracle: only the 11 `@PIL_B2` decorators and 2 imports were removed and two docstring sentences refreshed; no assertion changed; `tests/pilot_synergy_support.py` is untouched (its `localize()` seam works because `LocalizeInputs` is structural). The T track's note that a reference engine passes all 22 is confirmed independently by this implementation.
- Invariants, each with a test that fails when the rule is broken: shared origin counts once (advisory repeated 1 to 4 times, B1 plus ChangeFacts plus call label, never summed); no float, division or rounding in the six modules (AST scan) and an integer-tuple order key; the tier derivation over all 15,360 fact combinations returns only assignable mechanisms (never `strong`) and is monotone in every flag; removing shape evidence or adding doubt never raises a class on random scenarios; a change is "not seen" only where every channel it reads is complete and the candidate is a one-to-one pair; ties are the equal-key groups and the ranks tile 1..n; canonical JSON round trip and `verify_assessment`; the result is byte-identical across `PYTHONHASHSEED` 1 and 2; cancel before and during a run, the deadline, P-01 and P-03; the P-04 cut (700 partial and 300 queue candidates give 500 + 200 leads, true counts 700 + 300).
- Mutation check (throwaway script `mutate.py`, mutate one source line, run the five test files with `-x`, restore): 18 single-point mutations: toolchain cap removed, window cap removed, label-only firmness removed, the two-code-origins rule removed, one-sided candidates compared, tie order by input order, every advisory entry its own origin, a proof no longer forces review, `-met` sign flipped, unusable channels read, locality threshold `>=` to `>`, duplicates not collapsed, queue cut off by one, the advisory entry no longer protected from the P-02 cut, an unusable pairing channel not abstaining, counts taken from the kept leads, the advisory listed for a lead it does not back: 17 killed (the P-02 one only after its test was made deterministic by choosing the entry that sorts first); the survivor (`window.state != 'no'` for `== 'yes'`) is equivalent because an `unknown` window lists no CVEs and the CVE-count test follows it.
- Found while building: (1) a P-02 cut made the result `partial` with no limitation line, which the contract refuses; the status is now derived from the limitation lines so the two cannot disagree. (2) The plan's fixed header "Provenance" contains the stem of the banned word "proven"; the sweep follows the repo's convention (stems as prefixes, the rest as whole words). (3) An observation of a channel that did not run is not read, so a test that expects a build fact must make the Build channel `available` (the helper does).
- Scale (this container, CPU time): 5,000 pairs x 8 CVEs, half of the pairs with evidence: 1.2 s; every pair with four observations and two hypotheses per CVE: 2.2 s (plan s7 target 5 s); before the pattern-shared evaluation the heavy case took 3.9 s.
- Not verified here: Windows (the hash-seed test spawns Python; paths are not used), real Ghidriff/capa/FLOSS/DiE/unified data, the frozen executable (nothing imports `pilot.service` yet), the 250,000-candidate limit and the 1 GiB bound (P-01 and P-08 are exercised at 3 candidates and by design: only keys are kept per candidate and context, the kept leads are rebuilt), multi-origin observations (none exist; the connected-component calculus is not monotone under removal for them).
### [S3:ir-facts] SPEC-31 S3 (2026-10-14, Linux container, 4 vCPU, CPython 3.13.16; hand-assembled IR through the real ingest, recorded real-Ghidra fixtures and two LIVE real-Ghidra pairs)
Toolchain of the live lines: Ghidra 12.0.4 PUBLIC, OpenJDK 21.0.12.1, pyghidra 3.0.2, extractor script SHA-256 `8e21a0b1e4251e58b35a6087b7c742a353d36d8c01b0f03bdea46717943efb58` (S1 script, `analyze` mode, own analysis), extraction by `tools/live_unified_check.py --record` (all L0-L3 checks PASS on both pairs). The DLLs are MinGW-w64 builds (no MSVC): nothing was executed. Scratch scripts (not committed) read the recorded `*.ir.jsonl` / `*.pe.json` through the real `ingest` and judged every same-named pair as a name matcher would (tier-A rows).
| Check | Evidence | Result |
|---|---|---|
| S3 tests | `tests/test_unified_{facts_align,datamap,ir_facts,operands,layout_eh,anchors,gu_mutants,verdict_ir,facts_robust}.py` = 16 + 20 + 25 + 18 + 41 + 19 + 38 + 30 + 5 tests, `tests/unified_facts_builder.py` (the hypothesis tests are derandomised, T-29) | 212 passed |
| Neighbours | `tests/test_unified_{facts,import_dag,registry,worker,pipeline,cli,fusion,sources,addressing,contracts,keys,store}.py` (S0a/S0b, unchanged; the registry versions move `config_digest`) together with the 212 new tests | 755 passed in 43 s, `PYTHONPATH=src` |
| Lint | `python -m ruff check src/patchtrace/unified tests/unified_facts_builder.py tests/test_unified_<the nine>.py` | clean |
| G-U1, X versus X on REAL output | recorded fixtures `probe_old` (7 functions) and `mingw_old` (61), `identical=True`; plus every function of the hand-assembled images | 100 % `unchanged` / UNCH/1 (7/7, 61/61) |
| Hostile matcher | all 3,721 ordered pairs of the 61 real MinGW functions judged as if paired | no exception; `unchanged` only for byte-identical bodies |
| LIVE pair 1: MinGW build of `tests/fixtures/{old,new}.c` | `ci_old.dll` sha256 `c5e3e2de8d164777301fa256cdbd5378c33cde5446be15d7c22bcbcec4b0c3ba`, `ci_new.dll` `2a907aaf45021b2786e693473a77179d698011c2222e565734fd8617ddd64f90`; 61 functions and 1,290 / 1,301 instructions per side; the only source edit is a guard in `read_item` | 15 `unchanged`, 38 `cosmetic` COS-ADDR/1 (every function after `read_item` moved), 7 `review` with no delta (CRT start-up functions whose single-use globals and ctor list have no confirmed neighbour: unmapped targets), 1 `material` (`read_item`, three added blocks with a store or call, anchored by the C3 counts) |
| LIVE pair 2: 4,060-function pair (scale) | `big_a.dll` sha256 `1085c0f07e8cc90f8145a1325cff4666061d5a770b876c55e2e33cc05cc44e72`, `big_b.dll` `f0823782d5739d13777f1cfa7333a6497f0b44d9f4423a462522df72825603ae`; 174,388 / 174,516 instructions; generated source (S1 scratch `gen_big.py`): `big_b` adds `s += 4` to every function whose index is a multiple of 17 (236 matched edited functions) | edited 236/236 `review` (a constant-only edit stays `review` until S3b gives C6; none hidden); untouched 3,824: 3,797 `cosmetic` COS-ADDR/1 + 21 `unchanged` + 6 `review` (the same CRT start-up functions); 0 `material`, 0 exceptions, no limit hit. Before the equal-`h1` positional alignment 12 untouched switch functions (twin case bodies) were `review` too |
| Cost, pair 2 | ingest 8.6-9.6 s per side (27.6 MB of extractor output), DATA-MAP vote table 0.27 s for 4,060 pairs, collect + judge | 1.4 ms per pair (5.7 s for 4,060); about 8 microseconds per decoded instruction; synthetic 371-instruction functions 10-20 ms per pair |
| G-U2 at unit level | every class of the 08 s1 table incl. R-01..R-04, R-07, R-16: 13 classes x 20 random members + the named cases (`tests/test_unified_gu_mutants.py`) | leakage into `cosmetic` / `unchanged` = 0; the planted class is among the deltas in every member; frame-only and trace-arg members are `review` |
| G-U4 | swap property (100 generated programs: verdict and proof independent of which build is older), the recorded probe pair swapped, generated programs judged twice | identical |
| Mutation check (scratch script, not committed) | 35 textual single-edit mutants of `facts/{verdict,eh,datamap,layout,align,operands,irchannels,anchors,trace}.py` (target consistency, EH-EQ, caps, anchors, consensus, region shift, header rule, inversion table, fall-through jump, family substitution, identical mode, code/data conflict, C3/C5, trace table) each run against the focused tests | 27 killed at first; the 8 survivors were weak spots (verdict-level cap rule, non-inverse condition with swapped successors, jump replaced by a fall, twin block pairing, identical-mode conflict, code versus data, C3 body multiset, non-tracing callee) and got tests: 35 of 35 killed |
Found and fixed while building: equal masked bytes at a moved RVA say nothing about where a relative operand points (R-03), so UNCH/1 needs the target consistency of every address operand; a function must not prove its own data references (consensus needs two voters, region shift needs nobody else to have voted); the identical-artifact shortcut and the PE-header rule were needed for X versus X to be 100 % `unchanged` on real output; thunk collapse had to run before the exclusive-partner conflict; switch successors needed the CFG-position pairing; bodies without instructions (a lone jump) pair by the key `None`; equal-`h1` pairs align positionally (the first rule of 05 s2.3) because switch cases with equal bodies have no unique key.
Not verified here: Windows and MSVC-built IR (RVA-form switches, CFG dispatch, /GS), Python 3.12 (CI pin), the frozen executable; no end-to-end `unified run` with IR (`compute.py` does not pass `ir_sides` yet: integration owner); G-U1 P0 / P1 and G-U2 recall at >= 20 mutants per class on the real Tier R corpus, G-U6 and G-U7 (S6); BinDiff parity; the 6 CRT start-up functions of both live pairs show that single-use data without a confirmed neighbour stays `unmapped` (a candidate extra DATA-MAP rule is listed in tasks/todo.md [S3:ir-facts]).
### [S3b:decompile] SPEC-31 S3b (2026-10-14, Linux container, 4 vCPU, CPython 3.13.16; fakes, real Ghidra 12.0.4 text pinned in a test, and one LIVE end-to-end run)
Toolchain of the live line: Ghidra 12.0.4 PUBLIC, OpenJDK 21.0.12.1, pyghidra 3.0.2, extractor script SHA-256 `7676f631fb825551569f04f6b32828b771694a8d49d86e8d15a0a120f6f26fd9` (the S3b script). The DLLs are MinGW-w64 builds of the S1 probe sources (`probe_old.c` / `probe_new.c`), nothing was executed.
| Check | Evidence | Result |
|---|---|---|
| S3b tests | `tests/test_unified_{ghidra_decompile,decomp_reader,decompile_runner,refacts,refacts_recorded}.py` = 18 + 16 + 22 + 23 + 3 tests (script mode against fakes of Ghidra and its decompiler, the strict reader, the runner against fake interpreters incl. tree kill on timeout and cancel, the row selection and the C6 seam, real decompiler text) | 82 passed |
| Earlier slices | the S1 script and runner tests, `test_unified_packaging.py` and the import rules, adapted only where the new mode changed a fact (`fake_importer`, a `decompile` request without GZF and RVAs is `bad-request`, `extract/decomp` in the import-rule table) | green; the whole unified suite without the 10k / 60k perf file: 1437 passed in 105 s (`PYTHONPATH=src`) |
| Lint | `python -m ruff check src/patchtrace/unified` and the S3 / S3b test files | clean |
| Mutation check (scratch script, not committed) | 38 textual single-edit mutants of the script mode, the reader, the runner entry, the C6 seam and the selection (statuses, caps, budgets, cancel, dispose, hash checks, validation, ranking, limit) | 36 killed; 2 equivalent (`parse_float` and the L-41 bound in `decompile_side` are enforced a second time by the type check of the reader and by the S0a request model) |
| LIVE, end to end | `tools/live_unified_check.py` Side + the repository runner: own analysis of `probe_old.dll` sha256 `a2b12b5ebd48e57c79381d036ba654141843032f31a324216a64d85325f8a2de` and `probe_new.dll` `6dbf820b6e13c86bab720ab79a5f1ea2b2a904bdcd3d890f79f21595c746ce5a` (68-95 s for both sides), IR facts, `select_for_decompile`, then `decompile_side` per side over the program packed by the `analyze` run | the facts chose `dispatch` and `add_clamped` (constant-only edits, `review`, C6 `unavailable`; `say` and `use_data` are not eligible); both sides decompiled in 22.7 s / 24.1 s for the two runs (two children, JVM start included); statuses `ok`, `ok`, and `failed` for a function-less RVA (`0x1`) |
| LIVE, facts with the C text | the same run, `FactsContext.build(decompiled=)` | `add_clamped` (0x3e8 to 0x400) and `dispatch` (0x55 to 0x56) became `material` with `second_channel` C6 (Ghidra prints `1000` and `0x400`; the literal forms of MAT-ANCHOR match them) |
| Real decompiler text in a regression test | `tests/test_unified_refacts_recorded.py`: the C Ghidra 12.0.4 printed for the two functions (MinGW build) over the recorded Ghidra IR of the clang probe pair | `material` with C6 while no other row of the 7-function pair moves; the same C on both sides or the other function's C leaves them `review` |
Not verified here: Windows (the JVM, the native decompiler process and the Job Object on `windows-latest`), MSVC-built programs, a decompiler timeout or crash on a real function (the fakes provoke them, the live run did not), the 64-pair / 600 s bounds at scale (two pairs measured), Python 3.12 (CI pin), the frozen executable, the `refacts` worker stage itself (integration owner), and the shape of the text on MSVC code (`canon/1` is tested on MinGW and clang decompiler output only).
### [S4a:read-model] SPEC-31 S4a (2026-10-14, Linux container, 4 vCPU shared with other workers (load average 4.6-5.9 during the timings), CPython 3.13.16; SYNTHETIC data only, none of it live evidence)
| Check | Evidence | Result |
|---|---|---|
| Slice tests | `python -m pytest tests/test_unified_read_model.py tests/test_unified_cli_show.py tests/test_unified_cli.py tests/test_unified_import_dag.py -q -p no:cacheprovider` | 107 passed: read model 51 (44 functions, 8 hostile-name cases), CLI show 8, S0b CLI 35 (three tests updated, see the spec 07 s13 notes), import DAG 13 |
| Neighbours | `tests/test_unified_{worker,pipeline,store,registry,sources,packaging,contracts,keys}.py`, `tests/test_cli_registry.py`, `tests/test_acceptance_smoke.py` | 521 passed, 1 skipped (the opt-in nightly freeze check, `PATCHTRACE_TOY_FREEZE=1`) |
| Lint | `python -m ruff check .` | clean |
| Literal non-ASCII | scratch scan of every source, test and spec file of this slice | none (hostile and non-ASCII text is written as escapes) |
| Red first | the 8 tests of `tests/test_unified_cli_show.py` run against the pre-slice `unified/cli.py` (a copy of the tree in a scratch directory); the read model tests on the parent commit | 8 failed on the old CLI; the read model tests cannot be collected there (`unified/read_model.py` does not exist) |
| Mutation check (scratch scripts, not committed) | 36 textual mutants: order (contested demoted, trace-argument, library, severity list, attention, secondary key, None last), U-03 collapse (cosmetic pseudo, `show_collapsed`, explicit `--change`, the hidden count), cells (on-pair test, support order, source filter, search incl. hex, limit), stale vs partial precedence, cancel, evidence breakdown and summary, provenance and TSV caps, sidecar scan (find limit, early stop), detail footer and stale note, unknown-source tooltip id, JSON keys, milli parsing | all 36 killed; the first run left 6 survivors (5 targeted tests added, one equivalent mutant removed by simplifying `_select`) |
| Time at 100,000 rows (L-35: filter <= 100 ms, sort <= 150 ms) | `test_filter_and_sort_budget_at_100000_rows` (asserts 0.5 s filter, 0.75 s sort, 50 ms for 1,050 cell reads: the 5x slack) and a scratch script | filter 14-17 ms (default, search, three filters), sort 39-68 ms (default order, by BinDiff cell, by function, by change), 1,050 `cell_text` calls 0.18 ms, building 100,000 views 0.45 s |
| Load, 20,000 and 100,000 stored rows (two atoms each) | scratch script writes a result with `store.write_result`, then times `load_unified` | 20,000 rows 3.4-4.7 s (2.4 s when the box was idle); 100,000 rows 17.6 s on the loaded box; a profile at 5,000 rows puts about two thirds in `store.read_rows` (pydantic, JSON, row-id check) and a fifth in row building; load is a worker-thread job with progress and cancel, outside the filter and sort budgets |
| Memory | `test_load_stays_light_per_row` (tracemalloc over 2,000 stored rows; bound 2,048 bytes per row) | 748 bytes retained per row at 20,000 rows (peak 23 MB); about 75 MB at 100,000 rows (extrapolated, not measured); identical cells and source sets are shared |
| Lazy text | scratch script on the 20,000 and 100,000 row results | one detail 44 ms / 102 ms; a 200 row provenance block 85 ms / 56 ms |
| Not verified here | the Qt panel (S4b, not built); Windows and CI (timings with the 15.6 ms clock, `copytree` of a project); the frozen EXE; screen readers, DPI and high contrast; real Ghidriff, BinDiff and rz-diff output (every row here is synthetic); IR-mode rows (pt-ladder, pt-bytes, structural proofs, collapsed rows) on real S2 / S3 output; an attention map built from the enrichment store; the full suite (the integrator runs it) | open |

### [S6a:corpus-gates] SPEC-31 S6a (2026-10-14, Linux container, 4 vCPU Xeon 2.10 GHz, 16 GiB, Python 3.13.16; clang, lld, LLVM tools 18.1.3; x86_64-w64-mingw32-gcc 13-win32; git 2.43.0; Ghidra 12.0.4, pyghidra 3.0.2, Java 21.0.12; OPEN-SOURCE TEST BUILDS AND SYNTHETIC DATA ONLY, local run, not CI)
| Check | Evidence | Result |
|---|---|---|
| New tests | `tests/test_unified_corpus_{catalogue,manifest,cli,workflow}.py`, `test_unified_{mutations,bench,gates}.py` = 14 + 10 + 9 + 11 + 84 + 16 + 22 tests; compile-based ones record BLOCKED when a tool is missing | 166 passed, about 70 s |
| Neighbouring existing suites | `test_workflows`, `test_spec_registry`, `test_tier_r_{catalogue,contracts,csrc,factory}`, `test_corpus_check`, `test_tier_w_corpus`, `test_unified_{parity,ladder_perf,import_dag,registry}` | 215 passed, 44 s |
| Lint | `python -m ruff check tools/unified` and the new test files | clean |
| Fetch with pin check (network) | `python -m tools.unified.corpus fetch` on the four pairs; a second fetch of two pairs into an EMPTY store | every source tree digest equals `pins.json` in both runs (commit equality is verified by the SPEC-32 fetcher) |
| Release pairs (`python -m tools.unified.corpus build`, mingw-gcc -O2 -g) | project functions: zlib 1.3 to 1.3.1 128 (116 unchanged, 2 changed, 9 ambiguous, 1 no-counterpart); libpng 1.6.43 to 1.6.44 460 (453, 2, 5); Lua 5.4.6 to 5.4.7 692 (624, 30, 27, 2 cosmetic, 9 no-counterpart); mbedTLS 3.6.0 to 3.6.1 1,571 (1,405, 42, 109, 15 no-counterpart) | 0 disagreements in all four; zlib reproduces the counts SPEC-32 recorded; the declared fix functions are confirmed changed (libpng `png_xy_from_XYZ`, `png_XYZ_from_xy`; mbedTLS `mbedtls_ecdsa_der_to_raw`, `mbedtls_ecdsa_raw_to_der`, CVE-2024-45158 per the pinned ChangeLog) |
| A/A pairs (`aa`) | P0 rebuild in two scratch directories; P1 reversed and rotated link order; P2 O0 to O1, O1 to O2, O2 to O3, O2 to Os and gcc to clang | P0 byte-identical for all four projects (a true X versus X). P1 turns many bodies address-only: zlib 73 and 72 of 128, libpng 300 and 255 of 460, Lua 549 and 466 of 687, mbedTLS 1,105 and 862 of 1,569 (the rest identical). P2 changes most bodies (zlib O0 to O1: 138 of 138 matched functions differ). 12 of the 1,569 mbedTLS functions are identity-ambiguous even in the byte-identical rebuild (a key repeats inside one image): excluded from scoring by SPEC-32 design |
| Planted mutants (`mutate`, 24 per class, seed 1) | 12 classes; instruction-level inspection of one mutant per class (signedness flips `cmovb`/`cmovl`, index-swap changes the SIB index register inside the address operand, branch-swap trades whole arms under an unchanged `jb`, buf-resize changes only `sub`/`add rsp`, callee-swap and global-swap change only the `<symbol>`) | 288 of 288 accepted on the first attempt, no induced ambiguity, about 20 s per class |
| Live extraction of the recipe-built, symbol-stripped zlib pair (`tools/live_unified_check.py --no-ghidriff --no-hashers`, real Ghidra 12.0.4) | L0 self-check; L1 determinism; L2 gzf equals analyze; L3 facts | all 24 lines PASS. older 247 functions, 20,501 instructions, extract 46.7 s, ingest 1.5 s; newer 248, 20,522, 87.5 s, 0.9 s (JVM start and analysis included, so about 2.3 to 4.3 ms per instruction end to end) |
| G-U5 bench (`python -m tools.unified.bench`, synthetic) | ladder: generate, sides, ladder timed apart; ingest: 60k functions x 50 instructions streamed to disk, then the real `ingest()` | ladder 10k sides 0.37 s + ladder 0.92 s (L-35 15 s; gate with 5x slack 75 s); 60k 2.39 s + 9.77 s = 12.17 s (120 s; 600 s), peak RSS 507 MiB including the generated rows (1.5 GiB); ingest 10k 20.8 s / 55 MiB, 60k (3.0 M instructions) 116.7 s / 62 MiB (600 s, 5x slack 3,000 s; 1.5 GiB). These agree with the S2 figures (60k ladder 9.56 s) |
| Gate-report skeleton on the real manifest (324 pairs), bench reports and the JUnit of the 327 integrity tests | `python -m tools.unified.gates_u` | G-U5 pending (measured parts pass; facts and read model wait for S3 and S4, no Windows report, largest Tier R pair needs S3); G-U8 pending (only the S4 UI-policy check and the frozen-smoke attestation are open); G-U1..G-U4, G-U6, G-U7 pending. No gate passes and none is claimed |
Not verified here: any GitHub Actions run of `unified-corpus.yml` (static checks only), every Windows leg (the bench's `K32GetProcessMemoryInfo` branch was written but not run, mingw and clang on the runner), the MSVC leg, the frozen EXE, Python 3.12 (the CI pin), BinDiff `--md_index` parity (no pin), Ghidriff parity (not installed here), the L4 to L6 live checks on these images, and the verdicts of the engine on any of this corpus (S3). The corpus numbers describe test builds of open-source code and say nothing about Windows system files or about the accuracy of any engine.
### [K4:kev-kb-adapter] KEV K4 KB adapter and synergy (2026-10-14, Linux container, CPython 3.13.16)
| Check | Command / method | Result |
|---|---|---|
| K4 tests | `QT_QPA_PLATFORM=offscreen python -m pytest tests/test_kev_synergy.py tests/test_kev_kb_integration.py -q`; with the K1a and K1b files, `tests/test_kev_*.py` | 84 passed (16 + 68); 559 passed in about 6 s (the boundary tests pick `kb_adapter` up by themselves) |
| Lint, schemas | `ruff check src/patchtrace/kev` and the two test files | clean; no persisted contract was added, so the schema check is unchanged |
| Red, then green | the tests were written before the module (red was ModuleNotFoundError) | yes |
| Known answer | plan section 5 with the synthetic 2099 catalog, a real `rank` (F005 68, F001 38, F002 5, F003 0, F004 a contested match) and a real `contextual_rank` over synthetic CVE snapshots | items 1 to 8 reproduced: statuses and cell texts, CVE order [10001, 10002, 10004] and kev-first [10001, 10004, 10002], candidates F005 then F001 under both CWE-787 CVEs, "1 day before" and "9 days after" with the KB and its date named, the unverified-orientation sentence and no before/after, the CWE-416 abstention, freshness at 3, 4, 14 and 15 days, a fullwidth ID invalid and never "Not listed", the decoy listed with no KB link |
| Not averaged | `RankingResult` and `ContextualRanking` JSON compared byte for byte with no catalog, with the catalog and with a catalog that lists the other CVE | identical in all three; candidate lists identical; only the CVE order moves |
| Mutation sanity | 41 one-line mutations of `kb_adapter.py` (gap sign and field, singular day, orientation, release-date parsing, KB and CWE patterns and exact-`str` checks, ranking direction, duplicates, unranked ids, abstention rule and order, note rule, echo, limit, order, banner, summary, label, de-duplication, missing release date) | all killed. The first run left 5 survivors that are tests now: a str look-alike as KB id or CWE, a `date` object as release date, the banner taken from the first row instead of the first answered row, the unverified sentence repeated per KB |
Not verified here: plan section 5 item 9 (MSRC and SSVC lanes) and the real KB view model (KB wave merge); Windows (CI).
### [K5:kev-project-context] KEV K5 project row, drift and report block (2026-10-14, Linux container, CPython 3.13.16 and 3.12.3)
| Check | Command / method | Result |
|---|---|---|
| K5 tests | `QT_QPA_PLATFORM=offscreen python -m pytest tests/test_kev_project_context.py tests/test_kev_report.py -q`; with the whole KEV suite and `tests/test_enrichment_kb_kinds.py` | 32 and 58 passed; 653 passed in about 14 s on 3.13.16 (the boundary tests pick `report` up by themselves); the K4, K5, boundary, view-model and kinds files, 243 passed on the CI pin 3.12.3 (shared scratch venv, pydantic 2.13.5) |
| Lint, schemas | `ruff check src/patchtrace/kev` and the KEV tests; `tools/generate_kev_schemas.py --check` | clean; unchanged (K5 adds no persisted contract: `KevContext` is K1a's) |
| Red, then green | the tests were written before the modules (red was ModuleNotFoundError) | yes; the first green run left gaps that became tests (below) |
| Project row | a real sample project (`create_sample`): publish, `load_contexts`, a reader whose `KINDS` lacks `kev-context`, `apply_retention`, `prune_runs`, `make_room`, `store.save(store.load())` | the row round-trips exactly, `extension_version` stays 1, the old reader's views are unchanged, the row survives all three deletions and the v1 project contract still saves; a different loaded catalog (or none) at publication stores the row stale; the same CVEs under the same catalog replace it |
| Drift | the synthetic 2099 catalog recorded, then a catalog a week later | "KEV data changed since recorded: CVE-2099-10002 was not listed on 2099-03-01 and is listed now (added 2099-03-05)." first, then changed ransomware, due date, triage and weakness list, then removals; a reworded description, the same catalog and no catalog give nothing |
| Report | golden of the block for the scenario (local file, fetched host, no stored catalog, one entry, no file name); hostile catalog version and file name, hostile drift text | no `<` or `>`, one heading, six cells per table row whatever the text, every code span closed, no link syntax, every Markdown special of the escape set pinned by a test, a file name is a code span only when inert |
| Mutation sanity | 36 one-line mutations of `project_context.py` and 53 of `report.py` (kind, limits and their boundaries, ordering, slim entries, guard, stale rule, row id, error mapping, drift conditions, escape set, entities, code-span rule, plural, host or file, timeline once, legend, drift length, newline structure) | all killed except `texts <= {...} and texts` in the timeline, which is behaviour-equivalent. The first runs left survivors that are tests now: the 5,000 and 256 boundaries, a model-level validation failure, the sqlite error mapping, the storage error text, each Markdown special, a lone space or pipe in a file name, `1 entry`, a local file without a name, long drift sentences. One survivor showed a redundant early return in `drift_lines`, which was removed |
Not verified here: Windows (CI); a Markdown renderer (no renderer is a dependency, so the escaping is checked structurally and character by character); the report hook in `reports.py` (plan A6, integrator); the row through the GUI (K3).
### [FAB-1:fabric-store] Anchor fabric enrichment store and schemas (2026-10-14, builder worktree on the FAB-0 merge; Linux container, synthetic data only)
- Red first: `tests/test_fabric_store.py` failed at collection (`No module named 'patchtrace.fabric.store'`) and `tests/test_fabric_schemas.py` for the missing `docs/schemas/fabric/`. Green: the eight fabric test files 440 passed on CPython 3.13.16 and on 3.12.3 (shared scratch venv, pydantic 2.13.5): store 52, schemas 57, the FAB-0 files 331 (one hygiene test extended); `ruff check` clean on `src/patchtrace/fabric`, the new tests and `tools/generate_fabric_schemas.py`.
- Gates: a second store reads back what the first published (digest, `find`, `get`, `batches`); every step of a scripted sequence and 25 random sequences of publish and retract (hypothesis) give the reports, digests, `find` pages and `resolve` answers of `MemoryAnchorStore`, and a fresh reader over the stored rows gives the reference digest after each step; the batch digest equals an independent oracle of the domain-id formula and a pinned golden; a moved origin table and a row stored with a moved guard are listed stale with their anchors still read; after a real `swap_orientation()` the old orientation's anchors are skipped and counted, statements stay, and swapping the snapshot back restores everything; rows are untouched by `apply_retention`, `prune_runs` and `make_room`; an old reader (`KINDS` without the kind) sees the same secondary data, keeps the rows, `extension_version` stays 1 and the project saves and loads; every invalid example is rejected for its own message.
- Test strength: 65 single-point mutations (key, guard, project and row checks, read verification, orientation, stale rules, merge limit, row cutting and ordering, row cap boundary and escaping, retract kind filter and read-only, cache signature parts, snapshot cache, error mapping, status fields, the model validators and strictness). First run 59 killed; 6 survivors: 4 test gaps (a refused retract on a read-only store served the mutated view, rows of a project that was never saved, an unusable project id, an unusable artifact pair), each now closed by a test, and 2 equivalent mutants (a duplicated guard and a duplicated key argument), whose redundant code was removed; 65 of 65 killed after.
- Measured at F-01 (20,000 one-witness anchors with facets, CPython 3.13.16, one shared machine, load about 4): `publish` 1.5 s (reference alone 0.7 s), the row 10.2 MiB (535 bytes per anchor), first read of a fresh store (parse, validate, `verify_anchor`, merge) 1.8 s, a read with nothing changed 28 ms, a 500-row `find` page 25 ms, `resolve` 8 ms, `digest` 47 ms, `retract` with its load 2.5 s. Budgets to re-measure on Windows CI.
- Found while building: the plan's guard fields `run_id` and `raw_sha256` were not defined, so they are the fixed `fabric` and empty (a new Ghidriff run does not stale a batch about two images); `EnrichmentStore.publish` commits per row, so a call touching several batches cannot be one transaction (documented, repeat completes); a cached view must be dropped after a refused write because the database signature does not move (mutation survivor, now tested); the project snapshot can be megabytes, so it is parsed once per snapshot hash, not per read.
- Regression subset (storage, retention, kinds, hardening, intelligence storage, unified store, pilot contracts and keys, spec registry, unified import DAG and packaging, KBC contracts): 752 passed. The full suite was not run (the integrator runs it twice). GitHub was not consulted (worker brief rule).
- Not verified here: Windows and CI; the frozen smoke (nothing imports `patchtrace.fabric.store` yet); worker-thread use (the store is owner-thread only, checked by a test); a real producer; the GUI and CLI slices.
### [FAB-4:fabric-pins] Anchor fabric analyst pins (2026-10-14, builder worktree after FAB-1; Linux container, synthetic data only)
- Red first: `tests/fabric_store_support.py` (imported by both fabric store test files) and `tests/test_fabric_pins.py` could not be collected before `fabric/pins.py` existed. Green: the nine fabric test files 509 passed on CPython 3.13.16 and 3.12.3 (pins 54, schemas 72, store 52, the FAB-0 files 331); `ruff check` clean on `src/patchtrace/fabric`, the new tests and the generator. Regression subset (storage, retention, kinds, hardening, intelligence storage, unified store, pilot contracts and keys, spec registry, import DAG and packaging, KBC contracts) 752 passed together with the fabric files (1,261 in one run).
- Gates: pins survive a batch replacement that drops the anchor, the retraction of the batch, a retraction by the `analyst` producer and `apply_retention`, `prune_runs` and `make_room`, with every pin row byte-identical afterwards, and match the anchor again when a batch brings it back; the sequence decides when the clock ties and the row ids fall; a random sequence of 14 pin and unpin steps against a plain model (25 examples), also read back by a fresh store; 8 kinds of unreadable event are counted and never hide the good pins; a pin made before a swap is listed stale, an anchor of the other orientation is refused, and a stale pin is rewritten when pinned again; notes at and over 2 KiB (ASCII, two-byte, lines); an old reader keeps the row, `extension_version` stays 1 and the project saves and loads; the event digest equals an independent hand-built hash and a pinned golden.
- Test strength: 42 single-point mutations of `pins.py` (kind, caps and boundaries, model validators, note cleaning, idempotence and refresh, sequence and ordering, stale rules, unpin, event reading and counting, input checks, time zone, guard fields, pair at pin time, unsaved project, domain). First run 39 killed; the 3 survivors were test gaps (the `via` of an unpin event, and the two unsaved-project branches when rows exist but no snapshot); each is now tested; 42 of 42 killed. After extracting the shared project access from `store.py`, the 65 store mutations were run again and all are killed.
- Measured (CPython 3.13.16, shared machine): 1,000 pins one after another 16.5 s (16.5 ms each, each reading all earlier events), `pins()` over 1,000 events 27 ms, one more pin over 1,000 events 49 ms.
- Found while building: a pin made while the files were compared the other way round names the wrong image side, so the event stores the project's two hashes and the pin is listed stale after a swap; re-pinning a stale pin with the same note must still write an event (mutation survivor, now tested); `Field(max_length)` placed after an `AfterValidator` reports `too_long`, not `string_too_long`.
- Not verified here: Windows and CI; the frozen smoke (nothing imports `patchtrace.fabric.pins`); WB1's button and the GUI; worker-thread use (owner thread only, checked by a test).
### [R1:rules-synth] YRX R1 closed-grammar synthesis (2026-10-14, Linux container 4 vCPU, Python 3.13.16, yara-x 1.21.0 from the wheel, hypothesis 6.169; SYNTHETIC images only, none of it live evidence)
| Check | Method | Result |
|---|---|---|
| Tests | `pytest tests/test_rules_synth.py` (pure and engine) | 333 passed in about 28 s, three consecutive runs identical; also 333 passed on CPython 3.12.3 (the CI interpreter) in a scratch venv with pydantic 2.14.1 in 36 s; the 422 R0 and R2 tests still pass; `ruff check` clean on the two files |
| Hostile values, no engine | a lexical oracle blanks every string literal of a rule (closed alphabet, no line break inside, nothing outside printable ASCII and LF) and compares the rest with the same rule built from benign values; 54 named hostile values (quotes, backslashes, escaped quotes, NUL, LF, CR, tab, DEL, C1 controls, star-slash, slash-star, braces, a whole second rule, keywords, `import "pe"`, `include`, pattern references, truncated escapes, bidi and zero-width marks, line separators, an emoji, lone surrogates) and 200 hypothesis examples, each in every value position at once (label, project id, function names, CVE, KB, CWE, capability, import and DLL names, pin names, text-pattern bytes) | skeleton identical every time |
| Hostile values, real YARA-X | the same values compiled under R2's policy, read back through the engine (meta keys and values, tags, pattern ids, imports), formatted twice; text-pattern bytes scanned inside PE images in all three encodings, with a flipped byte as the control; header lines of any content under `with_header` | 0 errors, 0 warnings, values read back exactly (non-ASCII as `?`), every text a `Formatter` fixed point, exact bytes found and the control not |
| Exhaustive | every byte value alone and all 256 together as a text pattern; every ASCII character in one meta value | the engine decodes each to the bytes that went in |
| Caps | one rule with every value at its longest, every character four characters long in the source (60,171 bytes, 65 meta entries, a 512-byte pattern, four pins, five patterns, eight gates) | compiles clean and is a fixed point; a value past its cap, or a rule past 64 KiB, is a `PT-RULE-LIMIT` (refusal table) |
| Behaviour on images | call pins on a two-call function in a second code section (right slots, swapped, one wrong, same slot, shifted by padding, two copies satisfying one pin each, the 8th and 9th match), named, ordinal and delay-load imports (DLL case, absent, wrong table), the PE, AMD64 and executable-section gates, text patterns in ASCII and UTF-16 | all as designed; the masked bytes alone hit every variant, the pins separate them |
| Timing | best of 5 runs | `render_rule` 0.3 ms for a 2.5 KB rule (features included) and 5.5 ms for the 60 KB rule; `engine.lint` (compile, build, Formatter check) 16 ms and 23 ms; the Formatter alone 10 ms for 60 KB |
| Mutation sanity | 61 one-line mutations of `synth.py` (quote and backslash escaping, controls and DEL raw, non-ASCII passed through, exact quoting made lossy, comment keeping LF, `fullmatch` to `match`, unvalidated lineage or direction, every pin arithmetic term, the match bound, scope, machine and PE gates, duplicate and order handling, advisory order and cap, side, canonical text and encoding checks, alphabet widened, size caps, raw interpolation of project id, label, capability and function names) | 56 of the first 57 killed on the first run; the survivor (function names on by default) was a real test gap and got a test; the four mutations added for the type-versus-cap refinements were killed at once; 61 of 61 killed after. The engine-free skeleton tests alone kill the escaping and interpolation mutations. The module was prototyped against the engine before its tests existed, so this check stands in for red-first |
| Deep runs | the same tests with 5,000 examples per pure property and 1,000 per engine property (5,000 for the header lines), hypothesis seeds 11 and 12 on the code before the last refinements and 21 and 22 on the final code | pure 220 passed in 110 s and 87 s, engine 105 passed in 316 s and 284 s; no failure |
Found while building: YARA-X 1.21.0 has no `pe.delayed_imports`; `pe.imports(dll, ordinal)` is an integer (the bare form warns `non_bool_expr`); `pe.imports` compares function names without regard to case; an unused declared pattern is E022; `allowed_metadata` does not reject unlisted meta keys; the Formatter re-indents continuation lines and aligns `=` per section; an empty text pattern is E024 and one-byte or all-0x00/0x90/0xFF patterns are E018 (slow pattern). The editing tool of this session turns a typed backslash-u escape into the literal character (the same slip as in PIL-K1/K2), so bidirectional and zero-width characters in the tests are built with `chr()`.
Not verified here: Windows (CI; the goldens need LF checkouts), the frozen build, real third-party PEs and real masks (R4), classic YARA (the rules target YARA-X), and the full suite (the integrator runs it).
### [K2:kev-fetch] KEV K2 transport, service and CLI (2026-10-14, Linux container, CPython 3.13.16 and 3.12.3)
| Check | Command / method | Result |
|---|---|---|
| K2 tests | `QT_QPA_PLATFORM=offscreen python -m pytest tests/test_kev_transport.py tests/test_kev_service.py tests/test_kev_cli.py -q` | 247 passed (95, 50, 102) in about 10 s on 3.13.16; with `test_kev_boundaries.py` and `test_cli_registry.py` 324 passed, 1 skipped (pre-existing) on 3.12.3 (shared scratch venv, pydantic 2.13.5, the CI pin) |
| Neighbours | the other `tests/test_kev_*.py`, `test_cli.py`, `test_cli_registry.py`, `test_acceptance_smoke.py`, `test_workflows.py` | 585 passed, 1 skipped; the two smoke tests that start a subprocess need `PYTHONPATH=<tree>/src` (the editable install points at the main checkout, which has no `kev` verb), then 71 passed, 1 skipped |
| Lint | `ruff check src/patchtrace/kev src/patchtrace/cli_commands tests/test_kev_{transport,service,cli}.py` | clean |
| Red, then green | the three test files were written before the modules; red was ImportError at collection | yes |
| RA-3 regression | loopback server, one byte per 0.5 s for 12 s, `plan_deadline=2.0` | returns `PT-KEV-NETWORK` after 2.03 s (six runs), 2.24 s with 12 busy processes on 4 CPUs; with `read1` replaced by `read` the same test fails after about 14 s; a silent server is cut after 1.0 s |
| Real sockets (loopback only, any other address is refused by an autouse guard) | complete and chunked downloads, truncated bodies (Content-Length and chunked), the two fixed headers and no others on the wire, a 302 is surfaced and never followed, an environment proxy is a decoy that is never contacted (with a stock urllib opener as the control that it would have been) | pass |
| Mutation sanity | 68 one-line mutations (the RA-3 revert, deadline, caps, redirect and consent rules, proxies, retries, headers, exit codes, consent wording, escaping, freshness, strict JSON) | 68 killed. The first pass found three redundant lines (a cancel check that `interruptible` already makes, a URL length check implied by the URL grammar, an unreachable `break`), removed, and eight weak assertions, strengthened |
| Leaks | `python -X dev -W error::ResourceWarning` plus unraisable and unhandled-thread warnings as errors | 247 passed |
| Source hygiene | the authoring tool turned typed `\u` escapes into raw bidi, zero-width and fullwidth characters in three test files; replaced by `chr()` and guarded by `test_no_kev_network_file_hides_a_control_or_invisible_character` | clean |
| Live (this sandbox only, 2026-10-14 22:28 UTC) | `patchtrace kev fetch --source cisa-github --consent-hosts raw.githubusercontent.com`, then `status` and `lookup` | installed 2026.10.14, 1,745 entries, 1,787,354 bytes, SHA-256 47b463a1...; CVE-2024-30088 listed with ransomware use Known, CVE-2024-38063 not listed. `--source cisa-site`: `PT-KEV-NETWORK` (host unreachable here) |
Not verified here: Windows and CI (loopback timing, `os.replace`, TLS roots in the frozen build), the canonical `www.cisa.gov` URL and its User-Agent acceptance (K6 on GitHub), behaviour behind a corporate proxy (the transport ignores proxies by design; Import is the route), Narrator or NVDA (no GUI here).
### [K6:kev-live-probe] KEV K6 live probe and workflow (2026-10-14, Linux container, CPython 3.13.16 and 3.12.3)
| Check | Command / method | Result |
|---|---|---|
| K6 tests | `QT_QPA_PLATFORM=offscreen python -m pytest tests/test_live_kev_probe.py -q` | 63 passed in about 3 s on 3.13.16; with `test_workflows.py`, `test_live_harness.py` and `test_live_nvd_probe.py` 105 passed on 3.12.3 (shared scratch venv, the CI pin). RECORDED/MOCKED: a fake opener serves the committed fixtures, hosts and the schema read are stubbed, the CLI runs in this process; this is not live evidence |
| Lint | `ruff check tools/live_kev_probe.py tests/test_live_kev_probe.py` | clean |
| Red, then green | the test file was written after the tool in this slice (the tool is a thin composition of K2 and the NVD probe's pattern); the first run failed one test (a workflow check that read a comment), fixed in the test | yes |
| Workflow | static guards (`tests/test_workflows.py` plus three in the K6 file) and a PyYAML parse | triggers are `workflow_dispatch` and `schedule` only, `permissions: contents: read`, the one input reaches the shell through `env` only, `pip install --only-binary=:all:` |
| Mutation sanity | 37 one-line mutations (every blocked and failed rule, the 72 h limit and its boundary, formatting-only versus semantic schema change, precedence, exit codes, source validation, per-source folders, PYTHONPATH, reason length, and five workflow mutations) | 37 killed after two test additions (the PYTHONPATH the subprocess receives, a reason longer than the table cell). An earlier run was void: the scratch copy lacked `check_live_status.py`, so every test failed at import; rerun with the file present |
| Live (this sandbox only, 2026-10-14 ~22:40 UTC) | `python tools/live_kev_probe.py --sources cisa-github` | PASSED: catalog 2026.10.14, 1,745 entries, no unknown fields, live schema byte-identical to the vendored copy (SHA-256 0d5865c9...) |
| Live (same) | `python tools/live_kev_probe.py` | BLOCKED, exit 0, `LIVE ACCEPTANCE BLOCKED` on stderr: `www.cisa.gov` does not resolve here; the mirror part of the file is `ok`; `tools/check_live_status.py` renders both files |
Not verified here, and the only gate that proves the canonical address: the first `live-kev` run on GitHub (`www.cisa.gov` URL and User-Agent acceptance, content equality between the sources, no unknown fields, schema unchanged). Also not verified: Windows TLS roots, a runner whose address cisa.gov refuses (that reads as BLOCKED, HTTP 403).

### [FAB-5:fabric-cli] Fabric CLI verbs (2026-10-14, worker worktree on `work/a`; Linux container, synthetic data only)
- Red first: `tests/test_fabric_cli.py` failed 38 of 38 before the code existed (the verb was missing, so the exit was 2 with no document, and the adapter file was absent). Green: the same file 38 passed; the eleven fabric test files 579 passed; `ruff check` clean on the two new modules, the new test file and the guard test.
- Smoke in a worktree: `tests/test_acceptance_smoke.py` runs `python -m patchtrace` in a child process, which imports the editable install, and that points at the main checkout. Until the merge, `fabric --help` and the no-Qt help path fail there; with `PYTHONPATH` set to the worktree `src` the file passes 16 of 16.
- Found while building: the FAB plan has two `Status:` lines that disagree about FAB-2 (line 3 says built, line 4 says open; `convert.py` and its tests exist). Line 4 now records FAB-5 as built and leaves FAB-2 as it was written there.
- Not verified here: Windows and CI; the full suite; live, network or Microsoft data (none involved: the projects are built from synthetic PE bytes).
### [FAB-3:adoption] PIL adopts the fabric's origin table and anchor seams (2026-10-14, worker worktree on 510450d; Linux container, synthetic data only)
- Baseline: the 10 `tests/test_pilot_*.py` and 10 `tests/test_fabric_*.py` files, 1,669 passed on CPython 3.13.16 before any change.
- Red first: `tests/test_fabric_adopt.py` failed 8 of its 15 tests against the unchanged source (the copies were not the fabric's objects, the registry was not a fabric registry, the digest had the old table) and the ports inventory test failed; after the source change the only failures were the three regenerate-and-compare tests that pin the pilot schema examples, which is the one golden the card allows to move. The generator was re-run and the diff checked: only `origins_digest` and ids derived from it changed (21 files with the digest, 23 `result_id`, one `relative_dir`, two manifest hashes, two part hashes).
- Green: the same 20 files plus the new one, 1,684 passed on CPython 3.13.16 and 1,684 passed on CPython 3.12.3 (pydantic 2.13.5, hypothesis 6.169.1, pytest 9.1.1). `ruff check` clean on `src/patchtrace/{pilot,fabric}`, the four edited tests, the new test and `tools/generate_pilot_schemas.py`. `tests/test_gui_core_manifest.py` (it names pilot modules) 22 passed.
- Digest evidence: an independent hand-built hash (the oracle of `test_fabric_origins.py`, written separately from `domain_id`) gives `affccb01...` for the 15-row table PIL shipped before (equal to the old committed golden, so the formula did not change), `3370b2c8...bc18` for the shared 19-row table under `pilot-origins` (the new PIL golden) and `a48c53ab...3f10` under `fabric-origins` (the unchanged fabric golden).
- Mutation spot-check: 18 deliberate defects applied one at a time to `pilot/origins.py`, `pilot/ports.py` and `fabric/origins.py` (wrong domain, leaked fabric error, chained cause, wrong slug or code, digest without sources or without the override, a copied tag tuple, table or calculus, a locally redefined registry port, a dropped sink, unsorted or version-less payload, a changed pre-adoption row, an extra row); 17 of 18 failed the focused tests on the first run. The survivor (the `sorted()` of `payload()` is invisible through the digest, because canonical JSON sorts keys) was a test gap; `test_registry_payload_is_the_hashed_table_in_sorted_order_and_hands_out_copies` closes it and the mutation is killed (18 of 18). Each file was restored after its run and compared by hash, and `git status` showed no stray change.
- Not verified here: Windows and CI; the full suite (the integrator runs it); a real PIL publisher (none exists yet); the interplay with A41's `pilot/{store,report,cli,review}.py` (parallel work, not on this base).
### [R3:rules-candidates] R3 (2026-10-14, Linux container, CPython 3.13.16, yara-x 1.21.0; synthetic images, recorded real-tool goldens)
| Check | Method | Result |
|---|---|---|
| Tests | `tests/test_rules_candidates.py` with the R0 and R2 rules tests | 140 pass in 3 s; 562 pass in all four rules files (24 s) |
| Pipeline on goldens | capa-api `term`, `log`, `env` and floss-static `main` through `FlossStrings`/`CapaCapabilities`/`PeImports`, the reference renderer and the REAL engine | each candidate hits its own build and misses the other one; `log` older and any pair without channels give "no feature" with the channel reported `unavailable` |
| Escaping against the engine | hostile bytes (quote, backslash, CR/LF, NUL, 0xFF, comment end, a bidi byte sequence) and 40 hypothesis byte strings: `escape_text` inside quotes, scanned by YARA-X | every one matches exactly its own bytes at the expected offset; one byte short does not match; `wide` Latin-1 text matches UTF-16LE |
| Mutation sanity | 45 one-line mutations of the five source files (boundaries of every gate, separation rules, tick policy, ids, hash checks, stale checks, API resolution, subscope skip) | 36 killed first; the 9 survivors were test gaps (unknown on the older table, 256-byte limit, 6-byte anchor, `imports-unknown` note, per-direction lineage, run in the candidate id, reader hash check, exact-name preference, subscope rules) and got tests; 45 of 45 killed after |
| Lint | `ruff check src/patchtrace/rules tests/test_rules_candidates.py tests/rules_fixtures.py` | clean |
Not verified here: Windows; real binaries, a real Ghidriff pairing and real capa/FLOSS output on them; the interplay with R1's `synth` (a reference renderer stands in); API names come from capa's spelling (R4 pins are exact).
### [R4:rules-bytes] R4 (2026-10-14, Linux container 4 vCPU, CPython 3.13.16, yara-x 1.21.0; iced-x86 1.21.0 only in a scratch `pip install --target` outside the repository; SYNTHETIC images, none of it live evidence)
| Check | Method | Result |
|---|---|---|
| Tests | `tests/test_rules_masks.py` (98), `tests/test_rules_synergy.py` (20) and `tests/test_rules_candidates.py` (140; R4 touched one line) | 247 pass and 11 skip without iced-x86 (the 10 tests that need it and the pin guard) in 4.4 s; with the scratch iced-x86 on `PYTHONPATH` 257 pass and 1 skips (the guard, which passes or fails by itself once `pyproject.toml` declares the pin); all six rules files together 669 pass, 11 skip in 24 s; the pe_overview and intel-tools suites around the new module are unchanged (403 pass, 8 skip) |
| Known answer (plan s5) | five rules from `term` of the accepted `capa-api` pair (exact bytes, masked bytes, import only, masked + import, masked + call-target pin) over eleven builds, scanned by the REAL YARA-X in process and once through the hidden worker child; the golden `tests/fixtures/rules/synergy-matrix.json` is compared with the table parsed from the plan | identical in both paths. Exact bytes hit V1 and V1t only (the rebuild V1r escapes); masked bytes hit all three rebuilds and also the look-alikes LA and BOTH; import only hits the rebuilds, IMP and BOTH; masked + import still hits BOTH; only the call-target pin hits exactly V1, V1r and V1t and no other build |
| Windows of the card | `propose` on the three `capa-api` pairs with the real YARA-X | term older 24 B (20 literal, longest run 15, mask `rip-disp`, pin TerminateProcess), log newer 38 B (30, 14, WriteFile), env newer 35 B (23, 8, GetEnvironmentVariableA): the numbers of the card, from the policy "changed range plus one instruction each side, grown until the checks pass"; each window is found once in its build and not in the other |
| Decoder | the stand-in decoder (tests only) against iced-x86 1.21.0 on 6 fixture images and on hand-checked encodings of every flow kind; the edges (a jump to the first byte of the body stays inside, one to the byte after the last leaves it; a target at exactly 2**32 is not an RVA); the adapter's version and its fallback to the pin when the distribution metadata is missing | equal on all of them; invalid or cut-short bytes are `PT-RULE-DECODE` with both |
| Diff cost | `diff_opcodes` on masked bodies of 12,000 instructions, 6 shapes (distinct, all alike, 2 keys, 4 keys, half and half reversed, 50 scattered edits) | `difflib` alone: 5 shapes took 14 to 32 s (the distinct one 46 ms); with the bound (shared ends cut off, a middle over 1,000,000 equal-instruction pairs not compared) all 6 take 2 to 5 ms; the worst bodies just under the bound took 0.14 to 0.46 s. Hit counting over 8 MiB of x64-like bytes: 11 ms for a pattern with a literal start, 58 ms for one that starts with a wildcard |
| Mutation sanity | 89 one-line mutations of `tables`, `masks`, `window`, the bytes path of `candidates` and the iced adapter (off-by-ones on every cap and boundary, the tiling check, relocation reach, pin conditions, context size, growth order, ranking, budget, diff direction and cache key, hit-count semantics, stale and size checks, coverage) | 87 killed in the final run. The gaps found on the way got tests (body edges, 2**32, version fallback, tail and head overlap, unequal lengths, direction without opcodes, cache key); the 2 survivors are equivalent (the relocation loop bound that `low < high` repeats; `has_immediate`, which iced always sets for a near branch) |
| Lint | `ruff check` on the new and changed files | clean |
Not verified here: Windows (a CRLF checkout of the golden, process and clock behaviour); real compiler output (jump tables, thunks, SEH funclets, hot-patch NOPs: the stand-in decoder knows a subset and answers `PT-RULE-DECODE` for the rest); real `.pdata` (covered by `pe_builder` images, not by the grid); iced-x86 in the CI matrix; the interplay with R1's `synth`.
### [REDACT-2:redaction-coverage] redact_log coverage and linear time (2026-10-14, worker A40 on the CONSENT base d793ac3; Linux container; CPython 3.13.16; synthetic data only)
- Red first (`tests/test_redaction_coverage.py` against the unchanged code): 39 of the 53 non-timing tests failed (every Cookie, SAS, Slack, JWT, argv and generated-secret case and the CLI cases); the 14 that passed are the prose, digest, idempotence and URL-regression guards. Both timing tests failed: the 1 MiB corpus test was killed at its 180 s limit on its first input (`'a' * 1048576`), the hypothesis mixtures test failed at 64 KiB (2.8 s against 2 s). Cause, found by that test: the existing `_URL_AUTH` rule was quadratic (`redact_log('a' * N)`: 10k 0.69 s, 20k 3.3 s, 40k 15 s; hours for 1 MiB), and `redact_log` runs over child logs of up to 2 MiB (`backend.py:606`), so an unlucky or hostile log could stall the analysis worker.
- Green: the new file 57 passed in about 10 s (6.5 s of it the 1 MiB corpus, 36 inputs timed in one child, each about 0.2 s against an 8 s budget); `ruff check` clean on it, `diagnostics.py` and `cli.py`. Existing tests that import `diagnostics` or run `cli.main`: 677 passed, 4 skipped (the skips are existing) over 32 files in one run, and 17 further Qt, CLI and engine files (`test_ui`, `test_ui_engine_setup*`, `test_acceptance_smoke`, `test_nway_*`, the rules and kbc files, ...) pass one process per file. Stacking those 17 into a single process hit `MemoryError` in Qt fixtures; each file passes alone, and the batch did not contain the new file.
- Benign text is unchanged and not slower: output identical to the old function on log-like text, 0.197 s per MiB against 0.218 s (the literal-anchored `://` rule is faster than the old one and pays for the five added passes).
- Exploration beyond the committed 60-example properties (scratch, nothing committed): 30,000 generated secrets per shape, none survived; idempotent on all 30,000 realistic line mixtures. Of 30,000 adversarial fragment mixtures 55 were not idempotent, all inside the old `_ASSIGNMENT` rule (a quoted value directly followed by more text, for example `token=''--token`), none involving the new rules; left as is.
- Mutation check (scratch copy outside the repository): 21 single-point mutants of `diagnostics.py` and `cli.py` (each new rule removed or weakened, the old quadratic rule restored, the CLI left raw on stderr or in JSON); 19 killed. The 2 survivors remove a lookbehind from the JWT or argv rule: the explicit caps already bound the damage (about 5.5 s against 0.19 s on `'eyJ' * N`, 2.7 s against 0.23 s on `'--' * N` per MiB), so they stay as a 12 to 29 times speed-up that is not test-pinned. Reviewing the JWT lookbehind during the mutation work showed that it would miss a token after an escaped delimiter (`%3DeyJ...`); the escape alternative and a `jwt-escaped` case were added, and a mutant without the alternative is killed. The marker guard of the argv rule is pinned both ways (removed, and loosened so that `[redacted]` with text glued to it leaks).
- Limits: a JWT segment longer than its cap (8 KiB, 64 KiB, 8 KiB) or a token that follows base64url text directly is not recognised; the Cookie rule hides the rest of the line, including JSON that follows on the same line; `-p x` and `curl -u user:pass` are not covered. Not verified here: Windows and CPython 3.12 (the tests avoid POSIX-only calls; possessive quantifiers need 3.11 or later and the project requires 3.12), the frozen executable, the full suite.
### [WBQ-S8:codetext-marks] WBQ S8 (2026-10-14, Linux container, 4 vCPU shared with other workers, CPython 3.13.16 and 3.12.3 (throwaway venv, wheels only), hypothesis 6.169.1, pytest 9.1.1; SYNTHETIC text only, none of it live evidence)
| Check | Evidence | Result |
|---|---|---|
| Slice tests | `tests/test_codetext_marks.py` (337), `QT_QPA_PLATFORM=offscreen nice -n 10 python -m pytest ... -q -p no:cacheprovider`; hypothesis `FAST` profile (150 examples) | 3.13.16: 337 passed in 7 s (the three codetext files 642 passed, 1 skipped); 3.12.3: the three codetext files 641 passed, 2 skipped (S7's colorspacious and PySide6 parity tests) |
| Hypothesis sweep | the same file with 1,500 examples (seed 1) and 3,000 examples (seeds 7, 42, 2026, 31337) | 337 passed each; 1 to 2 minutes per seed |
| Lint | `python -m ruff check` on `src/patchtrace/codetext` and the test file | clean |
| SYN-WBQ-1 (the plan's s5) | the real `align_lines` on the reconstructed text: 15 aligned rows, 8 non-equal, 4 replace hunks; `diff_row` per paired row | 1 changed pair (`0x20` -> `0x40`, `constant`, line 8 of 15), 1 address-only (line 1), 4 rename-maybe (lines 4, 5, 7, 8), rows 10 and 11 skipped as "paired by position only" (0.63, 0.75); the two plan sentences for lines 1 and 8 are reproduced word for word |
| Mutation property | every unmasked token of 13 hand-written lines (C and assembly) replaced by 11 spellings (>= 150 clean single-token edits), plus 150 to 3,000 generated lines | each yields exactly one `changed` mark on each side, covering exactly the replaced token; a masked token (auto-name, temporary) yields `address-only` or `rename-maybe`, never `changed` |
| Shift-only controls | C: SYN text with the +0x40 shift and the renumbering and no edit; assembly: a 14-line listing, 3 rows differ; hypothesis over shifted names and image-range numbers | 0 `changed`; only `address-only` (4) and `rename-maybe` (7) in C, 3 `address-only` in assembly |
| Named symbols never masked | `CreateFileW` -> `CreateFileA`, `strcpy` -> `strncpy`, an import call, a decorated name, auto-name <-> name | always `changed`, label `callee` or `data-ref`; the oracle is never asked |
| Alignment optimum | exhaustive search over every order-keeping pairing of lines of up to 6 tokens from a 10-atom alphabet (masked collisions frequent) | the result equals the minimum of (inserted + removed, renames with another spelling, address pairs with another spelling, runs); the bit-parallel common subsequence equals a classic table on lists of up to 40 tokens; swapping the lines keeps the cost |
| Mutation check (scratch, not committed) | 165 textual mutants of the five new modules (`<scratchpad>/S8/mutate.py`), the S8 test file run against a copy of the package | first run: 17 survived (frame register names, cost-weight order, head and tail trimming, cell-cap boundary, label negatives, oracle arity, scan limits and others); after one round of added tests 6 survived (one was an equivalent shortcut); after a second round none. Final run on the final code: 165 of 165 killed |
| Bounds | 256 tokens and 4,096 characters per side; at most 8,192 table cells per pair; a refresh stops at 200 rows or 250,000 cells; LRUs of 4,096 rows | boundary tests (inclusive and exclusive sides); a row that fails the gate builds no table; the worst case measured below |
| Time (best of 7, shared CPU) | 200 typical pairs (the SYN rows) `refresh`: 18 ms (plan budget 60 ms; gate in the test 150 ms, best of 3). One typical `diff_row`: about 150 microseconds, of which the S7 tokenizer is 30. 80 hostile pairs (250 tokens, every 17th respelled, 7,200 cells each): the refresh stops after 35 rows at 177 ms. 200 `diff_row` over four worst-case shapes: 219 ms. `spans` for 400 cold blocks: 5.3 ms (plan 4.5 to 7.9 ms for 121) | within the plan's budgets; the deterministic guarantee is the cell cap, the timing tests only bound everything else |
| Hostile text | hypothesis over arbitrary text and soups of quotes, comment markers, controls, bidi and astral characters, lone surrogates, in both languages; twelve pathological 4,096-character lines; every mark on a token boundary, sorted, in range, on the right side; the summary one printable line (no category Cc, Cf, Cs, Zl, Zp, no space but U+0020) of at most 1,200 characters | holds; 50 invisible or control code points (C0, C1, spaces, bidi, default ignorables, tags, lone surrogate) each written as `<U+XXXX>` |
| Not verified here | Windows and the frozen EXE; the Windows runner's timing; real SPEC-31 instruction text and real Microsoft-built decompiler output (the SYN text follows Ghidra's forms, it is not a real listing); the Qt side (S9: formats, `QTextBlock.text()` equality with the rows, `compose_selections`, F8, labels, accessibility); the full suite (the integrator runs it) | open, see tasks/todo.md [WBQ-S8:codetext-marks] |

### [UE-WIRE:decompile] S3b live check (open)
Automated evidence only: a fake interpreter answers the real `decompile` request of the real runner over synthetic projects. Not verified: a live Ghidra decompile through `patchtrace unified run --python ... --ghidra-dir ...` on a project whose run retained `runs/<run>/unified/gzf/<side>.gzf`, and the CRT-row rate on a real pair.
### [PIL-C1:store-report-cli] Patch-intent localization store, report and CLI (2026-10-14, builder worktree on 9e9595c (work/a); Linux container, CPython 3.13.16, synthetic data only)
- Focused run: `tests/test_pilot_store.py` 51, `tests/test_pilot_report.py` 45, `tests/test_pilot_cli.py` 26 passed (122 new tests, about 17 s); `tests/test_cli_registry.py` and `tests/test_acceptance_smoke.py`, which now see the `pilot` verb (adapter rule, smoke list, `--help` without Qt), 71 passed and 1 skipped (the opt-in nightly freeze of `test_cli_registry`; the live rz-diff check was deselected). `ruff check src/patchtrace/pilot src/patchtrace/cli_commands tests/test_pilot_*.py` clean. The new modules byte-compile on CPython 3.12.3 (no pydantic there, so the tests were not run on it). The full suite was not run: no existing source file changed (new files and appended documentation only).
- Evidence for the gates: round trip and stale detection (guard moved, raw output changed, orientation swapped, each naming the inputs that differ), damaged sidecars (cut manifest, edited manifest, truncated, swapped and missing part, a decompression bomb) skipped without hiding an intact older result, a pointer that disagrees with its manifest, a symlinked directory, six ownership refusals, idempotent re-publish, replacement of other content under one id, a failed pointer row leaves the previous row and no directory behind; retention keeps three per family and leaves reviews, other kinds and unreadable rows alone, writes one verified backup that holds the rows, refuses to delete without one and does not reuse a backup that lacks the rows; orphan sweep; real-process exit codes 0/2/3/4/5; the unified path on the S0 fixture project; the append-only review round trip through the CLI; hostile function names from a real project (markup, a Markdown link, a pipe, a bidi override) inert in the terminal listing, the Markdown report and the table cells.
- Mutation check (throwaway script, one single-point change per run, restore): 27 mutants of the store, review, report, collect and cli. 24 killed; the 3 survivors are equivalent because a second layer enforces the same rule (the id check in `publish` is repeated when the staged manifest is read back; the decompression bound is repeated by the part digest; the row-id prefix filter of `delete_results` is repeated by its SQL `LIKE` clause). Two mutants that first survived (the pair missing from the retention family, the kind clause missing from the delete) led to stronger tests and are killed.
- Scale (this container, CPU time): 3,000 candidates with 2 CVEs (2,100 persisted leads, 3,400 queue rows counted) localize in 0.33 s, `stage` takes 0.29 s (4.2 MB canonical JSON, 264 KB gzip), `read_sidecar` 0.26 s, the Markdown 30 ms (162 KB), the JSON 50 ms. A result over 64 MiB is not stored (a warning) and the JSON export over 32 MiB is refused.
- Found while building: (1) `--action` of `review` collided with the sub-command destination `action` (the verb is now `args.verb`). (2) A stored unified result of the sample project is never current (its raw output is missing, the manifest source version is `1 [raw-missing]`, so its result id is not the plan's): the adapters fall back with a note, which the CLI passes on. (3) `result_id` does not hash the CVE selection, so `--cve` could not safely narrow a run (see the todo block).
- Not verified here: Windows (path lengths, `os.replace` retries against a real indexer, symlink privilege), real Ghidriff/capa/FLOSS/DiE/unified data, the frozen executable, the 250,000-candidate bound and the P-08 memory bound through the store, concurrent writers (one owner thread is assumed, as everywhere in the enrichment store).

### [R5:rules-store] YRX-wire and R5 (2026-10-14, Linux container, CPython 3.13, yara-x 1.21.0; SYNTHETIC images, none of it live evidence)
| Check | Method | Result |
|---|---|---|
| Section 5 grid with the real renderer | `tests/test_rules_synergy.py` builds the five rules with `synth` and compares the grid with the plan's table and, in a new test, with the grid of the reference renderer | equal |
| Tests | `tests/test_rules_store.py` (14), `test_rules_matrix.py` (34), `test_rules_export.py` (20), `test_rules_cli.py` (28), plus `test_rules_candidates.py`, `test_rules_synergy.py`, `test_rules_synth.py`, `test_cli_registry.py`, `test_kev_cli.py`, `test_fabric_cli.py`, `test_acceptance_smoke.py` | pass |
| Known gates | append-only (same row no-op, other content refused), resume after a crash between decision and version, export golden, no bulk flag, accept and export are separate (no `.yar` after accept; one `rule-export` row and no version after export), a file that was not read is never `no match`, header without path or user name, secret strings refused, `rules` imports neither `yara_x`, `iced_x86` nor Qt | pinned by named tests |
| Real child | `rules _rules-worker` answers a probe request file (exit 0, empty stdout) and refuses a bad one (exit 2); `rules test` through the real worker gives the expected grid | pass |
Not verified here: Windows; the frozen executable; a live backend for `rules propose` (the tests use a fixture backend); a real series.

### [WBQ-S6-S9:qt-modules]
| Item | Evidence |
|---|---|
| Tests | `tests/test_ui_pemeta.py` (39), `tests/test_ui_codetext.py` (34), offscreen, `tools/qt_gate.py --repeat 5` over both: 365 passed |
| Budgets measured here (offscreen, Linux, shared CPU) | scroll window refresh 5-10 ms at 6.5k and 65k lines (gate 30 ms); 65k-line install adds about 135 ms per pane over a plain `setPlainText` (gate 450 ms); 100,000 API rows: table swap and 100,000 `data()` calls inside 3x the plan budget |
| Not verified | Windows; NVDA/Narrator; DPI; high contrast; Consolas bold advance; pixel probe; the 20x single-session repeat (5x run) |
### [UE-S4b:ui-unified] Unified panel automated evidence (2026-10-15, Linux offscreen)
- tests/test_ui_unified.py + tests/test_unified_panel_spec.py: 39 passed; `tools/qt_gate.py --repeat 20 tests/test_ui_unified.py`: 700 passed, no abort. Blocked, not run: Windows CI, NVDA/Narrator, DPI scaling.
### [PIL-C2:leads]

| Item | Evidence |
|---|---|
| Tests | `tests/test_pilot_read_model.py` (35), `tests/test_ui_leads.py` (61) offscreen on Linux; `python tools/qt_gate.py --repeat 6 tests/test_ui_leads.py`: 366 passed, no abort |
| Known gates | one test per state L0-L8 and each gate and window banner; banned-string sweep over every producible string (stems `probab`, `likelihood`, `confidence`, `percent`, `vulnerab`, `exploit`, `proven`, `certain`, `verified`, `safe`, `secure`, with the sanctioned phrases removed); no enum slug and no percent sign in any cell; hostile names, notes and tooltips stay text; `a11y_audit` clean in every state; no new top-level window; late results dropped on a project switch; shutdown cancels and waits |
| Not verified here | Windows; real screen readers; a PE-backed project (the resolver finds no row in the synthetic sample, so Go to function is only exercised with an injected resolver); the freeze of the GUI-thread collection on a large project |
### [QA-CLI:stress] CLI and persistence stress (2026-10-15, Linux, root host)

| Item | Evidence |
|---|---|
| Tests | `tests/stress/test_cli_stress_{verbs,paths,concurrency,recovery,perf}.py`: 158 collected, 150 passed, 1 skipped (read-only directory, root), 7 strict xfail; 22.9 s |
| Open bugs (xfail) | QA-CLI-1 (Medium) `--json` parse failure prints no document; QA-CLI-2 (Low) offline `correlate --cve bad` exits 4; QA-CLI-3 (Medium) `cache verify` on a file `--cache-dir` exits 0 `complete` with `_Unsafe`; QA-CLI-4 (Low) `rank` ignores an unusable `--cache-dir` silently |
| Measured, not gated | 10k-pair cold 5-7 s, cache hit 1.5-3 s (objective 500 ms not met), peak RSS 547 MiB (objective 512 MiB); details in `docs/audits/20261015-qa-cli-persistence.md` |
| Not verified | Windows; read-only directory as a non-root user |


### [UE4:code-panes] Unified code view
| Item | Result |
|---|---|
| Tests | `tests/test_unified_pair_text.py`, `tests/test_ui_unified_code.py`, `tests/test_ui_unified.py`, `tests/test_ui_unified_pipeline.py` offscreen on Linux; `python tools/qt_gate.py --repeat 5` over the Unified files |
| Known gates | every code state, hostile text in code, provenance and notes, accessibility audit, tooltip registry, a 100,000 line function (capped with the notice, only hunks inside the cut navigable), a tampered or malformed decompile part is not shown |
| Not verified here | Windows; real screen readers; real decompiled text (no pipeline writes the part yet, the tests store C with the product's part writer) |

### [LBL-02-04:tranche-recipes] libdeflate, stb, c-ares recipes (2026-10-15, Linux, mingw-w64 gcc 13-win32)
- Network-verified: peeled tag commits (ls-remote of tags) for libdeflate v1.15-v1.24 and c-ares cares-1_26_0 to v1.30.0; stb has no tags (five version-bump commits, all ancestors of master); every licence file hashed from the pinned commit.
- Built here: `tier_r fetch` and `build-card --opt O2` for all 13 new cards (libdeflate 5, stb 4, c-ares 4), 0 disagreements after the declared lists were taken from the factory labels; `aa` byte-identical for libdeflate v1.19, stb_image-2.26 and cares-1_28_0. c-ares needed `Recipe.libs` wired into the link line (ws2_32, iphlpapi, advapi32).
- Not verified: the same runs on an Actions runner (R1); the untagged c-ares pins 035c4c37 and a804c04d (CVE-2024-25629 pair) were hashed but no card was built from them; the Windows MSVC leg.

### [LBL-14:ci-summary]
Automated: tests/test_ci_summary.py (counts, 90% warning, error status, determinism, workflow invariants). Not run: the nightly schedule and the determinism step on a real runner (needs main plus Actions).

### [LBL-prereg:tools]
Automated evidence only: `python -m tools.calibration.prereg --qa docs/qa.md` verifies the recorded `C9-PREREG-v1` SHA after the lock; no lock exists yet.

### [LBL-13:channels]
Automated only: `tests/test_calib_channels_*.py` (synthetic pairs). No channel value is claimed on real builds; `rules` is blocked until YARA-X is available.


### [U3-U8:cli-pin]
- Automated: `tests/test_unified_cli.py` and `tests/test_unified_bindiff_pin.py` (hermetic). Blocked on the owner: BinDiff v8 digest verification (needs an independent network path and the issuer key), so G-U3 oracle part is not run.

### [LBL-08:msvc-cl]
- Automated (Linux): argv, banner, host gating, nuisance variants and a build through fake `cl`/`link` pass; the real-compiler test records `blocked` (profile msvc builds only on a Windows host).
- Not verified: any real `cl` build (A/A byte identity, PDB source-path normalisation via `/d1trimfile`, `llvm-strip` on a MSVC image, `llvm-pdbutil` inventory). Needs the windows-2022 advisory job.

### [LBL-07:mutations-ir-opt]
- `tests/test_mutations_ir.py` (27) and `tests/test_mutations_opt.py` (11): hand-computed IR goldens, fake process runner, and one real-tool test per layer that asserts BLOCKED when clang/opt is absent. Real clang/opt 18.1.3 on Linux: `mergefunc`, `always-inline`, `loop-extract`, `hotcoldsplit` change the module; `partial-inliner` returned `unchanged` on the sample (its trigger is narrow), reported as a rejected attempt, not a pass.
- Not verified: the Windows runner (`opt` availability is [unverified] per the LBL plan); agreement rates on real mutants (needs the farm).


### [WB2-G8:whole-program-sources]
Automated only: `pytest tests/test_callgraph_sources.py` (14). No live BinExport/IR acceptance run.


### [WB3-S9:strings-live]
| check | evidence |
|---|---|
| goldens equal what the committed FLOSS 3.1.1 output yields through the run service (no tool needed) | `tests/test_live_strings.py::test_goldens_match_the_committed_floss_output` |
| pinned FLOSS on the synthetic pair equals the goldens (Linux CI; Windows advisory leg) | `tests/test_live_strings.py::test_pinned_floss_reproduces_the_string_goldens`; BLOCKED here: `PATCHTRACE_FLOSS` is not provisioned, the test records `blocked` and prints `LIVE ACCEPTANCE BLOCKED` |
| run orchestration: consent hash recorded, cancel, stale, project switch | `tests/test_ui_strings_run.py` (fake FLOSS, synthetic pairs) |
Goldens are derived from committed tool output, not from a new live capture; they become real-run goldens only when CI passes the live test. Real-binary string counts, Windows onefile start time and AV behaviour stay owner or CI items.

### [STRESS2:stress-deep-2]
- Automated (Linux, synthetic, seeded): tests/stress/test_stress2_{pilot,kev,kbcorrelation,enrichment_store,unified_parts,rules}.py; 78 passed, 5 strict xfail. Scale knob PATCHTRACE_STRESS_SCALE (default 1).
- Defects (product code unchanged): QA-S2-1 pilot universe() echoes caller CVE text into PilotError.message; QA-S2-2 project store connection is bound to its creating thread (lock-serialised writer threads all fail with ProgrammingError); QA-S2-3 NaN in an enrichment body escapes as ValueError, not PT-ENRICH-INPUT; QA-S2-4 unified part_lines does not enforce the 4 MiB line cap on newline-terminated lines; QA-S2-5 rules not_mostly_wildcards(0,0) raises ZeroDivisionError.
- Not exercised: YARA-X lint path (yara_x not installed in the worker venv); unified retention with many published results (needs staged result dirs).

### [D7:buildenv-timeline]
- `tests/test_buildenv_timeline.py` (12): cells, adjacent hops only, not-run is not a difference, tool-version guard, header-only stays unknown, bounds.
- Not verified: offscreen strip test (strip not built; needs the nway/ui_series seam).

### [D9:buildenv-value-gate]
- `tests/test_buildenv_value_gate.py` (12): hand-computed golden counts, control and leakage checks, no-data, determinism, input rejection, CLI.
- Not verified: any real M4 pair; the targets are [inf] proposals.

### [D8:live-buildenv]
- Locally both cases record BLOCKED (no diec here); the job is dispatch-only. Not verified: any live run, including the golden equality and the provisioning step with `--engine diec`.


### [WB1-S7:search-panel]
Automated: `tests/test_ui_search_panel.py` (offscreen, 29 tests, `tools/qt_gate.py --repeat 5` clean). Not verified: real index on a project, Windows, screen readers.


### [WB2-G5G6:calls-panel]
Offscreen: `QT_QPA_PLATFORM=offscreen python tools/qt_gate.py --repeat 5 tests/test_ui_graph_panel.py`. Screen-reader and high-contrast passes are owner gates, not done.


### [WB3-S7b:strings-panel]

Automated: `tests/test_ui_strings_panel.py` (offscreen, qt_gate x5). Owner-only: NVDA and Narrator pass, high-contrast and DPI check of the Strings dock.


### [CAP-6:capabilities-panel]
| Item | Result |
|---|---|
| Tests | `tests/test_ui_capabilities_panel.py` (35) offscreen on Linux; `python tools/qt_gate.py --repeat 5 tests/test_ui_capabilities_panel.py`: 175 passed |
| Not verified | Windows; screen readers; a real capa program; a PE-backed project (all data through injected fakes) |


### [K3:kev-panel]
Automated: `tests/test_ui_kev_panel.py` offscreen, `tools/qt_gate.py --repeat 5` clean. Not verified: NVDA/Narrator, high contrast, live CISA download.


### [FAB-6:related]
| Tests | `tests/test_ui_related_panel.py` (35) offscreen on Linux; `python tools/qt_gate.py --repeat 5 tests/test_ui_related_panel.py`: 175 passed |
| Not verified here | Windows; screen readers; the real project store read from a worker thread (reader is injected) |

### [LBL-20/21:tier-w-fetch-symbols]
Automated: `tests/test_tier_w_fetch.py` (33 passed) and `tests/test_tier_w_symbols.py` (29 passed, 1 xfailed). The xfail is the live Ghidra export, recorded BLOCKED (no Ghidra on the runner). The live llvm-pdbutil parity test ran against the self-made PDB (LLVM 18.1.3). Not evidenced: any real Microsoft download or PDB (O1, owner only).

### [LBL-22:tier-w-labels]
- Synthetic fixtures only: `tests/test_tier_w_labels.py`, `tests/test_tier_w_audit.py`. Not verified: any real symbol map.

### [LBL-24:tier-w-aggregate]
- `tests/test_tier_w_aggregate.py` (suppression at n < 30, no pooling, no names in output). Not verified: owner-run data.

### [T9:extern-c-linkage] C source function locator regression (2026-10-20, Linux container)
| Check | Evidence | Result |
|---|---|---|
| Focused tests | `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_tier_r_csrc.py tests/test_mutations_ops.py` | 29 passed, 23 skipped; skips are compiler-backed mutation acceptance checks because Clang is not installed/on PATH |
| Lint and patch hygiene | `python -m ruff check tools/calibration/tier_r/csrc.py tests/test_tier_r_csrc.py`; `git diff --check` | clean |
| Scope | `find_functions` tests cover definitions before, inside, and after `extern "C" {}` linkage blocks plus standalone `extern "C"` declarations | pass |
| Independent review | reviewed parser boundary handling and tests | approved; tests do not invoke a C/C++ preprocessor |

### Full-suite Linux container run (2026-10-20; CPython 3.12)
| Check | Evidence | Result |
|---|---|---|
| Full suite | `QT_QPA_PLATFORM=offscreen python -m pytest -q` | 15,716 passed, 12 failed, 83 skipped, 4 xfailed in 1,711.93 s |
| Locally reproducible product issues | screenshot renderer and unknown mutation operator failures listed above | both fixed; combined rerun of `tests/test_site_screens.py` and `tests/test_tier_r_eval_cli.py`: 27 passed, 2 skipped |
| Environment-limited failures | isolated `python -I` import checks, local AF_UNIX socket test, and three time-budget tests | `-I` subprocesses cannot see this environment's editable install (`ModuleNotFoundError`); AF_UNIX creation is denied by the container; budget tests failed under full-suite load but the 26 relevant cases passed in isolation |
| Cross-runner confirmation | GitHub Actions run 39456546905 on Windows and Ubuntu | both runners passed the complete pytest suite and Ruff; Windows later failed only at the NSIS installer compile step, tracked under PR #95 |

### [site-screens:files-panel] Site screenshot renderer follows the current panel UI (2026-10-20, Linux offscreen)
| Check | Evidence | Result |
|---|---|---|
| Screenshot generation | `QT_QPA_PLATFORM=offscreen python tools/site/render_screenshots.py --only overview` | rendered current Files dock at 1440x900; synthetic project; no engine probing |
| Site screenshot suite | `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_site_screens.py` | 12 passed |
| Lint and patch hygiene | `python -m ruff check tools/site/render_screenshots.py tests/test_site_screens.py`; `git diff --check` | clean |
| Updated visual asset | `site/assets/screens/overview.png`, `.webp`, `screens.json` | reflects the Files dock in the workspace rather than the removed overview dialog |

### [T9:mutation-cli-usage] Unknown mutation operator validation (2026-10-20, Linux container)
| Check | Evidence | Result |
|---|---|---|
| Regression test | `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_tier_r_eval_cli.py` | 15 passed, 2 skipped; compiler/toolchain acceptance cases remain blocked because Clang/LLVM tools are not installed/on PATH |
| Lint and patch hygiene | `python -m ruff check tools/calibration/tier_r/cli.py tests/test_tier_r_eval_cli.py`; `git diff --check` | clean |
| Behavior | Unknown `mutate --operator` is rejected as a usage error before probing compiler tools; JSON status is `error` and exit code is 2 | pass |
### Windows installer source-path fix (PR #95 follow-up)
- GitHub Actions run 39012939220 failed compiling `installer/PatchTrace.nsi`: NSIS could not open the relative `LICENSE` path from the script's directory.
- Anchored installer input and output paths to `${__FILEDIR__}..` with `REPO_ROOT`; added static regression coverage for the license, bundle, notice, generated uninstaller manifest, and output paths.
- Local verification on Linux: `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_windows_installer_manifest.py` (4 passed); `python -m ruff check tests/test_windows_installer_manifest.py` clean; `git diff --check` clean.
- Not verified yet: compile with pinned NSIS 3.13 and run installer lifecycle on Windows CI.
### SPEC-53 local symbol mode and launcher (2026-10-21, Linux container)
| Check | Evidence | Result |
|---|---|---|
| Staging, PDB identity reader, launcher, backend integration, CLI flag validation | `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_symbols_staging.py tests/test_ptlaunch.py tests/test_backend_symbol_local.py tests/test_nway_series.py` | full suite 15584 passed, 6 failed (pre-existing, rapidfuzz extra not installed), 286 skipped |
| Scope of the evidence | all runs use a FAKE `ghidriff` package and synthetic PDBs/PEs | Not evidence that real Ghidriff 4f5d895 or Ghidra 12.0.4 honours an empty server list; not an air-gap test (GHR-5 open, needs Windows and an OS-level network block) |
### SPEC-DA-01 Diaphora Mode A import (2026-10-21, Linux container)
| Check | Evidence | Result |
|---|---|---|
| Guard, parser, address mapping, provenance, store, bridge, CLI, schemas | `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_diaphora_import.py tests/test_diaphora_cli.py tests/test_diaphora_schemas.py` | full suite 15584 passed, 6 failed (pre-existing, rapidfuzz extra not installed), 286 skipped |
| Scope of the evidence | synthetic result databases only (`tests/diaphora_support.py`), never produced by Diaphora; no real Diaphora, IDA or Hex-Rays run | Not evidence of compatibility with Diaphora 3.4.3 output (EA text encoding, ratio range and `type` strings are assumptions). The live gate and value-over-Ghidriff evaluation are open |

### Continuation integration checkpoint (2026-10-22)
| Check | Evidence | Result |
|---|---|---|
| Missing optional dependency diagnosis | Before installing the declared `search` extra, `tests/test_search_capability.py` and `tests/test_search_synergy.py` had 6 failures; after installing pinned `rapidfuzz==3.14.6`, the same tests passed | 37 passed; failures were dependency-installation failures, not PR #100 regressions |
| Combined PR #100 feature tests | `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_symbols_staging.py tests/test_backend_symbol_local.py tests/test_ptlaunch.py tests/test_ui_symbol_local.py tests/test_diaphora_cli.py tests/test_diaphora_import.py tests/test_diaphora_schemas.py tests/test_mutations_more.py` | 128 passed, 23 skipped; compiler-dependent cases are BLOCKED because Clang is absent in this container |
| Lint | `python -m ruff check src tests tools` | clean on the combined tree before the current mutation investigation |
| Integration source state | Isolated `codex/patchtrace-completion-20261022`: PR #64 integration branch + current `main` + eight PR #100 commits | Not yet run through full Linux/Windows CI |
| Prior Windows regression gate | PR #64 QA run `39559162804`, merge SHA `a815670a48ae05a1ca7b2e8c2850cb880d57f825` | FAILED: 2 mutation tests (`string-literal-shout`, `callee-swap-dispatch`), 17,988 passed, 79 skipped, 6 xfailed. Must reproduce/fix and verify on Windows before release |
| PR #100 standalone gate | Actions at `66e9adc50fb118c04e5e24eacd0c221ca483a130`: QA Windows/Linux and native Windows Ghidriff acceptance | Passed on PR #100 alone; does not validate the combined branch |

### [LBL-WIN-COFF:masked-body] COFF semantic-label false positives (2026-10-22)
| Check | Evidence | Result |
|---|---|---|
| Red regression fixtures | Added `test_masked_body_coff_quoted_rip_string_symbols_are_addresses` and five parameterized `test_masked_body_stops_at_function_boundary` cases; before the code change these produced **5 failures, 1 pass** | Reproduces quoted MSVC `??_C@...` RIP operand drift and missing COFF `.seh_endproc`, `.def`, `.section`, and next-symbol boundaries without requiring Clang |
| Fixed parser + focused suite | `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_mutations_more.py::test_masked_body_coff_quoted_rip_string_symbols_are_addresses tests/test_mutations_more.py::test_masked_body_stops_at_function_boundary tests/test_mutations_more.py` | 36 passed, 23 skipped; all compiler-backed skipped cases are BLOCKED because Clang is absent |
| Lint and patch hygiene | `python -m ruff check tools/calibration/mutations/engine.py tests/test_mutations_more.py`; `git diff --check` | clean |
| Required remaining verification | Current-head Windows QA using its real Clang 20.1.8; specifically recheck `string-literal-shout` and `callee-swap-dispatch` | PENDING; synthetic assembly tests do not replace native compiler evidence |

### Continuation branch verification follow-up (2026-10-22)
| Check | Evidence | Result |
|---|---|---|
| Combined PR #100 and COFF regression suites | `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_diaphora_import.py tests/test_diaphora_schemas.py tests/test_diaphora_cli.py tests/test_symbols_staging.py tests/test_symbols_decoration.py tests/test_backend_symbol_local.py tests/test_ui_symbol_local.py tests/test_ptlaunch.py tests/test_mutations_more.py` | 314 passed, 24 skipped in 63.91 s; compiler-backed mutation cases skipped because Clang is not installed |
| Full-suite attempt | `QT_QPA_PLATFORM=offscreen python -m pytest -q` | Interrupted after nearly 10 minutes at about 1% progress; run remained CPU-bound. A separate `--collect-only` attempt was also interrupted after over 2 minutes without completing discovery. No full-suite result is claimed. |
| Branch publication | GitHub Git Data API created commit `b8e0a6705cfda603e0ee0d0cf831731eda58cf08` from exact local tree `fd7fa581cf1c7f28ba08676991efdb2b36aeaeff`; ref update used expected prior head `fb3645350f8f38d61dc507d7751377696aa1bcc3` | PR #64 head advanced; tree hash matched local `HEAD` exactly. Shell `git push` remains unavailable because no Git credential is exposed. |
| Current-head CI | Actions query `actions/runs?head_sha=f0af3fe2b4bfd6a8413d6d3cec093238d34e9d93` | No workflow runs had been created at query time. Git Data and Contents API commits advanced the PR head, but did not create Actions runs; an owner-side authenticated push or workflow dispatch is still required. |
| Release status | Combined continuation branch | Not release-ready: current-head Windows/Linux CI, frozen Windows smoke, and installer lifecycle remain unverified. |

### [SPEC-53:setup-modes] Symbol mode radios and local PDB folder list (2026-10-22, Linux offscreen)
| Check | Evidence | Result |
|---|---|---|
| Setup behavior and tooltip audit | `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_tooltips.py::test_setup_dialog_all_tabs_and_profiles tests/test_ui_symbol_local.py` | 7 passed in 51.77 s; covers radio exclusivity, legacy online migration, local config persistence, folder deduplication/removal, 16-folder cap, accessible names and Setup tooltip coverage |
| Lint and patch hygiene | `python -m ruff check src tests tools`; `git diff --check` | clean |
| Scope | Qt offscreen tests only | No Windows visual, DPI, screen reader, or real Ghidriff/air-gap evidence; GHR-5 remains open. |

### [SPEC-53:profile-local] Profile symbol-policy narrowing (2026-10-22, Linux)
| Check | Evidence | Result |
|---|---|---|
| Profile validation, digest, GUI, settings matrix, schema regeneration | `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_profiles.py tests/test_ui_profiles.py tests/test_unified_contracts.py::test_generate_schemas_reproduces_committed_files` | 55 passed in 73.46 s; local policy has a new digest, and a named profile cannot enable a mode above Setup |
| Schema | `docs/schemas/profile/AnalysisProfile.json` regenerated | `symbol_policy` enum is `disabled | local | online`; prior enum values and digest inputs remain unchanged |
| Lint and patch hygiene | `python -m ruff check src tests tools`; `git diff --check` | clean |


## 2026-10-30 consolidation review

Baseline PR #123 head `99f8328` passed QA run `41004210486` and native Windows Ghidriff run `41004210319`; these validate the baseline only. The new consolidation selectively ports #67 launch/consent/import safeguards and #102 parser/checksum protections, fixes client product-scope identity and failed decompile refresh preservation, and corrects hidden worker help. See `docs/audits/20261030-consolidation-review.md` for findings and source dispositions.

Local focused checks: 149 parser/GUI tests; 175 unified tests; 155 KB tests; 262 backend/core tests with 3 skips; 53 independent safety-review tests; 7 installer/help tests. These runs overlap and must not be added. `python -m pip check` and `python -m ruff check src tests tools` passed. Full combined `QT_QPA_PLATFORM=offscreen python -m pytest -q` is running. New exact-head Linux/Windows QA, repeated Qt, native Ghidriff and packaging are pending; no completion/native acceptance claim is made.

Consolidation verification follow-up: the first user-site test run was stopped because isolated subprocesses could not import a user-site editable install. A dedicated venv was installed and its isolated import verified. The complete venv suite at the first consolidation snapshot reported **18,258 passed, 136 skipped, 7 xfailed, 4 failed** in 347.91 s. One failure is the executor denying AF_UNIX socket creation (PermissionError); three are synthetic secret-redaction children formerly injected via cwd. Their fixtures now invoke an explicit absolute fake script while retaining production -I/private-cwd arguments and all redaction assertions. A separate real symlinked venv regression exposed base-interpreter selection from Path.resolve; probe and analysis now preserve the selected absolute executable path. The new runtime suite passes **46 tests**. The final combined full suite and remote gates must validate these corrections. No AF_UNIX test has been removed or skipped to hide the host restriction.

Final runtime integration full run at `8bf483c`: **18,265 passed, 135 skipped, 7 xfailed, 2 failed** in 362.09 s. The remaining product-independent AF_UNIX denial is unchanged. The other failure was the old corpus workflow test requiring every action use a mutable version tag; it rejected the verified MSVC full commit pin. The assertion now validates that exact approved commit while retaining existing checks for other actions. The actual workflow structure is also checked with PyYAML installed locally. A final rerun follows this test-only correction.

Full d34efeb snapshot before final Qodo repairs: **18,304 passed, 128 skipped, 7 xfailed, 1 failed** in 371.25 s. Only failure: executor denies AF_UNIX socket creation. Final substantive Qodo findings are repaired and focused-tested (see 20261030-consolidation-review.md); a new combined full suite and exact-head GitHub gates follow. Schema regeneration completed without schema-file changes.

## 2026-11-01 independent backup and Diaphora integrity repairs

Base main `a04f5a299a8d4afef023261e52e08d14678cf1e7`. Issue #121 backup metadata-cache failure reproduced in three tests, including real history deletion after a damaged backup was trusted. Fresh bounded byte hashing now binds reuse and publication to the checked copy; unchanged-byte SQLite checks remain cached. Six regressions cover same-size/restored-mtime edits, verification/publication races, unreadability and mutation of already-read bytes. Root independently ran 41 backup/prune/history/storage/sidecar tests; a second reviewer ran 24 retention/integrity tests. No native Windows claim from Linux results; fresh hashing has linear I/O cost.

Issue #121 Diaphora row deadline failure reproduced in three cases (sliding budget, interleaved count, small-query cancellation). Each row query now retains its original budget across yields, with explicit checks around fetches and deterministic cursor cleanup. Seven regressions preserve independent per-query scope; 65 Diaphora tests and independent two-iterator checks passed. This does not implement a whole-import memory cap.

These two isolated source repairs retain all other issue findings and do not qualify the broad native/unified feature candidates. Combined focused checks and full Ruff passed; exact-head Linux/Windows/full-suite/native CI must be recorded before merge.

## 2026-11-01 isolated report destination repair

Baseline `a04f5a299a8d4afef023261e52e08d14678cf1e7`: the imported 13 destination/export cases fail (including the existing GUI export overwriting a protected destination; new service API absent). The narrow port from `c3868d8335a8f32f676905032dc1a6d0e9f22fd6` retains project-owned path checks, persisted snapshot reads without recovery, and one GUI call change. Independent of new KB investigation, cancellation and adoption features. Source tests and CI evidence will be appended below; neither earlier #148 green jobs nor future integration checks substitute for this exact head.

Focused validation: `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_export_destination_guard.py tests/test_report_export_backup.py tests/test_service_storage_audit.py` passed; whole-tree Ruff passed. An initial command named nonexistent test files and ran no tests; corrected command above is the evidence. Full suite and native CI remain pending until recorded.

PR151 backup publication follow-up: actual fixed-clock/pending-file regressions2failed before repair; reviewed exclusive-stage/non-replacing publication39 tests passed (independent39 plus live-save failure controls). Prior evidence and no-prune-on-failure preserved; exact newhead CI required. See `docs/qa/backup-publication-collision-20261101.md`.


## Issue #120 independent main repair (2026-11-01)

Base: canonical `6579ed83211b7ff2039e3152728ac1cddc3e93d6`. Before implementation, the two defect suites produced **28 failed, 3 passed**: manual 1:1 ambiguity became an affirmative pairing; reference/name/code changes reused manual identity; changed normalized secondary content reused result identity; inconsistent alternative engine/version/anchor input was accepted. The failures include real ProjectService correction, persisted secondary republish, cache and refresh scenarios.

Ported only the reviewed issue #120 changes from `5db4de9`, `25bfc96`, `59e80be`, and `4578c90`. Relevant source contracts already exist on main. The PR #144 matching-policy hook, ladder/facts/pseudocode reconciliation and typed-literal changes were not required or imported. No rz-diff quarantine was imported.

Focused checks on the main port: identity/alternative/budget/source/key suites **126 passed**; related storage, secondary, read-model, in-process pipeline and wire-compute suites **141 passed, 1 real-child node deselected**; unified contracts/import-boundary suites **141 passed**. That real-child node was then run separately and **1 passed**. A new stored-secondary identity round-trip also ran a real Python worker and verified its next run was cached; the complete resource suite with that new case **8 passed**. Full `ruff check src tests tools` passed. `tools/generate_schemas.py` regenerated without any schema drift.

The main-only source retains existing matching semantics outside the repaired identity/ambiguity/alternative rules. Valid upstream fields, Atom.ref values and raw hashes are preserved; malformed historical rows follow the existing logged per-row skip policy. Stored-byte and in-memory canonical identity domains may conservatively miss cache across representations; distinct emitted content must not collide.

All fixtures are authored or synthetic; a Python worker round-trip is not a native matching/accuracy gate. Full pytest on the final published head, independent review and remote/native checks remain pending. No main merge or publication is asserted by this record.

Independent main identity repair: original28 failures reproduced on main; final coordinator125 focused/worker/child checks passed. Refused-source assertion now verifies derived identity and original raw provenance; independent fault controls and original failures retained in `docs/qa/identity-main-repair-20261101.md`. Exact published full/native/Qt gates remain required.

PR156 external-review follow-up: active Budget now reaches refacts identity/flag work; Qt captures validated inputs on owner and resolves new identity hashing in task work before exact-key owner DB lookup/publication. Both defects independently reviewed; main-port79 coordinator checks passed. Original red/independent evidence is retained in `docs/qa/identity-followup-20261101.md`. Existing capture I/O remains owner-side; no full responsiveness/performance claim.

PR #151 post-link admission follow-up (2026-11-02): exact `9c468bc` reproduced real later deletion after failed publication, despite valid SQLite/project/snapshot facts. Final regression file gives 7 failures / 1 pass on that baseline; stage-based admission repair gives 60 related passes (5.68 s), with earlier and foreign files preserved and failed bytes retained outside adoptable publication state. Whole Ruff/diff clean; independent review and integration pending. Evidence, limits and initial probe setup error: [backup-publication-admission-20261102.md](qa/backup-publication-admission-20261102.md).

PR #151 admission review follow-up: independent review blocked `536aebc` because `Path.glob` swallowed pending-stage scan errors. Explicit `os.scandir` now propagates opening/iteration/entry failures to refusal; two author red cases plus three independent error cases are retained. Revised related selection: 63 passed (5.57 s), Ruff/diff clean. Rereview remains required; see the admission QA record and scan evidence archive.

PR #151 cleanup-completion follow-up (2026-11-02): exact `1f284a1` retained all deleted rows in its valid copy but authorized enrichment pruning while that copy remained undiscoverable. Successful backup return now requires owned-stage removal and observed absence; failures keep every live row and preserve final/foreign evidence. Final regressions: 7 failures / 10 passes on baseline; 76 focused passes on `4bfc2c0`, Ruff/diff clean. Independent review pending; no data-loss or native/full claim. See [backup-completion-20261102.md](qa/backup-completion-20261102.md).
## Essential project-safety and offline investigation (2026-10-31)

Candidate branch `codex/essential-project-safety-20261031`, product source through `e2727e6` on main `a04f5a2`. This is separate from branding PR147. Prior main full CI is baseline evidence; no newer source is certified by those runs.

Delivered and reproduced before repair: report export replacing the open project database; export using unsaved state and unbounded project scanning; consented acquisition losing explicit product scope/revision; local pair preview accepting a known ARM64/x86 product for AMD64 files; missing offline KB desktop entry; new-project creation adopting a concurrent creator's project; deferred dialog Close after failures; project adoption closing the original before successful rendering. Tests use synthetic data/fake transports where relevant, never target execution or live-provider evidence.

Focused integrated journey/tooltips/export/helper checks: **58 passed** in11.37s. Worker broad KB+new helper/Qt batch: **940 passed** (overlapping counts). Independent review:35 export/storage,39 KB selection/acquire,22 GUI helper/lifecycle and6 MainWindow entry tests passed on their scoped sources. Whole Ruff/diff hygiene and source desktop self-test PASS; self-test now constructs the offline dialog without import/download/creation. No wire schema/model changes; final generated-schema drift remains checked by the full suite.

Full combined suite and actual frozen Linux candidate are pending on the frozen integrated revision. Historical host failures were not suppressed: copied venv interpreter is retained; ordinary temp directories have ancestor Git markers. A permission-scoped non-Git `/dev/shm` test directory was verified with executable fake-script and unchanged rule-export tests; full candidate testing will use that appropriate environment with loopback permission. `/var/tmp` setup failed read-only and its log is retained. No assertions, thresholds or protections weakened.

Windows native/resource/portable/installer and clean interactive acceptance remain external gates. PR147's earlier Windows QA failed only on SVG CRLF, now repaired with LF attributes; atomic output staging repair is published as `8f4c4a2`. New exact-head checks and Sonar disposition remain pending; no suppression or false-positive claim. Follow current candidate PR for complete result/run URLs and final evidence; do not merge or publish unverified source. Root owns current workspace, copied venv, worker checkouts and build/test logs. No additional cloud VM provisioned.

### Essential candidate full-run follow-up and seam repair

Complete first run at `a394782`: **18,335 passed, 134 skipped, 7 xfailed, 14 failed** in1108.15s. Two real architecture failures were UI line budget/feature import violations. The dialog factory/callbacks now belong to PanelHost and generic transactional adoption to indexed `gui/qt/project_adoption.py`; ui.py is3054lines, below unchanged3077ceiling. The complete host-seam +entry/helper/dialog selection passes51tests, Ruff/diffclean. No testbudget/forbidden-rule changes.

Other12failures were caused by placing offline-installer fixtures under `/dev/shm`, which is deliberately refused as an operating-system directory. All12 exact failing installer/Linux/UI nodes passed unchanged using ordinary `/tmp` (1.76s); logs/nodelist/XML retained. A final full run uses ordinary temp storage and reports any ancestor-Git-marker failure separately; no host guard is bypassed. Linux build/selftest atfirstfrozen source passed and initialized the new dialog without network/import/creation; final frozen build/smoke rerun pending.

PR147 exact8f4c4a2 now has successful Windows/Linux QA, repeatedQt, Windows PEresource/build/frozen/portable/installer lifecycle, Linuxpackage/smokes and all5 nativeGhidriff jobs: QA41182077577/native41182077573. Windows artifact13036931502; these published assets do NOT include the separate essential GUI candidate. Sonar Csecurity finding remains unresolved, not suppressed.

New essential source publication was rejected by automatic approval review: it cited insufficient explicit authorization for external destination djshellshoxxx/patchtrace and the14-failure run. No alternative publication route, force-push, merge or suppression was attempted. Source remains committed locally; concrete final candidate/evidence will be prepared before requesting publication approval. Existing public PR147 is retained unchanged.

### Final essential local verification

Frozen tested product source `024a00bda33e92aca8e6cca4d4e95e6f158a9137`, tree `6e7a02f8321e59868f476d3aed797664f9057c7a`: complete ordinary-temp offscreen run **18,348 passed, 134 skipped, 7 xfailed, 1 failed** in1085.81s. Sole failure is the unchanged rule-export Git-tree guard test because this host places an ancestor `.git` marker over ordinary temporary files. The same unchanged test passed on this final source in scoped non-Git storage. This is not a clean full-suite pass; no guard/assertion/threshold was weakened. The two real GUI architecture failures from the previous run are fixed and independent seam/entry checks pass30tests; full final run contains no other failure. All12 earlier installer-location failures now pass in ordinary temp storage.

Actual final Linux PyInstaller build, dialog-initializing self-test, complete frozen smoke, checksum verification, whole Ruff, dependency check and patch hygiene PASS. Archive `dist/PatchTrace-0.1.0-linux-x86_64.tar.gz`:85,569,222bytes, SHA-256 `a01dd3bae3d13f2b65fabea674405a83c787f331f080946132b4cae86090627d`. Artifact and all source/test evidence are retained locally; `work/essential-final-receipt.json` and `work/essential-final.patch` identify the exact candidate. This documentation-only handoff does not alter tested src/tests/tools/pyproject.

New essential candidate has no published commit/PR: automatic approval review rejected external commit publication to `djshellshoxxx/patchtrace`, citing explicit destination authorization and the then-failing14-test run. Local code failures are resolved; explicit publication approval remains requested before any further GitHub write. No alternate route, force-push, merge or suppression was attempted. Existing PR147 remains at8f4c4a2 with verified native Windows packaging/assets, but unresolved Sonar; its assets are a separate source, not this new offline-workflow build. Global G-U1–G-U8, live-provider/secondary evidence and clean interactive Windows acceptance remain separate unclosed gates. Root retains current workspace/copied venv/committed worktrees/logs and this Linux candidate; no additional cloud instance provisioned.

## [AF-0:wave1] Autonomous finish baseline and wave 1 (2026-11-04)

- Baseline on main `b77d84e` plus the tracker restoration, Linux container, Python 3.13.18, `pytest -q -n 4 --dist loadfile -p no:cacheprovider`: **18,701 passed, 31 skipped, 6 xfailed, 0 failed in 349 s**. Versus the 2026-10-29 baseline (15,688 / 104 / 4 / 3): about 3,000 tests merged since; the three earlier failures (AF_UNIX denied, optional wheels missing in subprocesses) do not occur in this container; fewer skips because the `search,rules` extras are installed. Collection first failed with `ImportError: libEGL.so.1` (container lacked `libegl1`; environment, not code).
- `ruff` on PATH is 0.16.9 and reports 10 I001 findings; the project's `python -m ruff` 0.17.3 is clean. Use `python -m ruff`.
- Wave 1 focused results (worker worktrees, Linux): rz-diff 97 passed / 1 skipped (skip needs `PATCHTRACE_RIZIN_SIMILARITY`, CI-only; native C controls not compiled here: no rizin); exe identity 614 passed / 1 xfailed with the shared-file hunks; GT-01 `tests/test_unified_live_*.py tests/test_backend*.py` 245 passed with the shared-file hunks; #148 focused set 253 passed. All synthetic: no live evidence.

### [AF-0:ported-154-157] Tracker rows carried from PRs #154 and #157 (2026-11-04)

### November 1 corpus safeguards and preregistration identity
Selective comparison of preserved #78/#79/#82/#85 against coordinator source `241f445` confirms missing output persistence, two-sided recipe A/A/noise planner cases and final-run CLI guard. The narrow preregistration identity repair rejects unrecorded/mismatched/ambiguous QA rows before corpus reads, and explicitly keeps rehearsal reports unlocked. Initial regression 18 failed/1 passed; repaired bounded integration 255 passed/1 native-tool skip (68.85 s); full Ruff passes. This is not final-evaluation or numeric-confidence acceptance. Independent review and combined cross-OS checks remain pending. Full source/remaining-work map and evidence: [corpus-safeguards-20261101.md](https://github.com/djshellshoxxx/patchtrace/blob/4aa99f7bd989765000c6ebd659c9565030a48849/docs/qa/corpus-safeguards-20261101.md).
Preregistration review follow-up: fenced/commented/indented example rows could still be accepted at first review; 8 new failures reproduced. Excluded them without changing real record identity or locked data. Final bounded selection/tools/constants checks: 74 passed (0.88 s), full Ruff passed; independent final review pending. Historical red evidence retained in the linked corpus safeguard record.
Final preregistration format follow-up: independent review found raw HTML and list-nested code contexts could still resemble lock records. The supported format now requires column-zero rows and rejects unsupported raw HTML/multiline code with a controlled error. Existing QA prose compatibility and final selection/tools/constants checks pass: 99 passed (1.02 s), full Ruff clean. Review source/results are retained in the corpus safeguard record; no real final look was consumed.
Independent preregistration identity review complete: `cancel_fix` cleared source `42a3d5dee13ac4ff87436a66f787c6b3b5e093ad` with 102 focused checks passing (1.40 s), original false-lock probes replayed, source hashes verified and unchanged lineage/frozen/final-gate boundaries confirmed. This supersedes pending-review notes above; integration/full/cross-OS and remaining GT-05 acceptance remain separate.
External #154 parser follow-up: actual comment-fragment, whole-digest-cell and inline-code/comment boundaries
reproduced; escaped-pipe false cells and optional trailing delimiter were also verified. Original new regression
run:21 failed/61 passed; repaired selection/tools/constants:123 passed. Before-input probes used only synthetic
protocol/QA files and a mocked corpus boundary. No actual corpus, final look, approval authority or frozen
protocol changed. Preserved closed #155 overlap was inspected; its intended cases are covered while its
prefix-comment false-lock regression is refused. [Detailed source/disposition/evidence](https://github.com/djshellshoxxx/patchtrace/blob/f27d23a80ee49573ccca54cdf036427f57eebb2a/docs/qa/prereg-markdown-review-20261101.md).
Root review found an additional escaped-opening backtick false lock on5e008a5, so its earlier approval
is withdrawn pending follow-up. A closed multiline comment reproduced verification and mocked corpus-boundary
access. Source-backed opening-escape handling now preserves literal backslashes inside established code;
new red6 failed/91 passed, repaired selection/tools/constants138 passed (all prior123 included), whole Ruff/diff
clean. No real corpus or final evaluation was read. Independent exact-follow-up review remains required.
### GT05 normalized output persistence (2026-11-01)
Against checkpoint `06b56a6`, actual CLI reports referenced normalized output digests with no retained source document; original regressions failed 3/3. The narrow #78 reconciliation now uses fresh exclusive run directories and atomic no-overwrite publication, and fails a pair without metrics when evidence cannot be retained. Earlier outputs/reports survive later failures. The actual attention provider exposed an already-produced field/schema mismatch; its bounded ranking key and engine kind now validate without changing original output bytes or scoring. Old strict readers reject these additive `/1` fields/kind safely.
Independent review exposed loss of the ranking field in the production output reader; the one-field reconstruction fix and actual-loader regression preserve it. Final focused checks: **164 passed, 2 native-tool skips** in 3.09 s; whole Ruff/diff clean. All inputs are constructed; production attention import/ranking/loader/replay is exercised, but no native accuracy or real corpus/final evaluation is claimed. Final independent review/integration and verified shard-transfer remain pending. Exact source/license adoption, preserved red/green logs, schema limits and remaining requirements: [output retention receipt](https://github.com/djshellshoxxx/patchtrace/blob/99660cc825b366a28e50b18eacad44dbb069ca69/docs/qa/corpus-output-persistence-20261101.md).
Independent review now clears source `ad35469860d402c4dfa86f041be3ce6996323465` (tree `bb7bd51dc64b08cc6fd33d8d7c90f4bf72b47841`): 164 independent passes, 2 native-tool BLOCKED skips in 3.30 s, extra production-reader/failure controls and old-byte/decoder differential all pass. The sole reader finding is closed; exact source hashes match. Evidence-only follow-up preserves the original runs and raw logs. Coordinator integration/cross-OS and verified transfer remain open.
Independent main657 port `522fe1b` plus receipt `5a95772` preserves all reviewed source/schema/test hashes and main's original QA/todo prefixes. Scoped checks plus corpus contract/schema drift pass **188 tests, 2 native-tool BLOCKED skips in 3.90 s**, with actual imports resolved to the new worktree, full Ruff and diff hygiene clean. Independent review transfers unchanged after explicit source/owned-diff equivalence checks. No preregistration branch dependency or remote publication is introduced.
### PR #157 credited replay boundary (2026-11-01)
Independent review reproduced incompatible ordering keys reaching a ranking TypeError, and a valid failed-publication artifact being adopted by the actual loader. New managed runs now finalize explicit successful-report credit and the reader rechecks exact bytes/ownership; preserved failed files are uncredited. Producer scalar validation precedes encoding/scoring on both paths, with unchanged strict limits and in-memory unified compatibility. Legacy unmarked folders remain visibly unverified and can be refused; historical success is not inferred. Initial controls: 11 failed/4 passed; final bounded selection: **237 passed, 2 native-tool BLOCKED skips**, 5 expected legacy warnings in 4.70 s; whole Ruff, pip check and diff clean. No actual corpus/final evaluation was consumed. Independent final review, integration, cross-OS and broader acceptance remain open; see [credited replay receipt](https://github.com/djshellshoxxx/patchtrace/blob/aff72cddc902f31a2cf44dea9c48797edabc1c30/docs/qa/output-credited-replay-20261101.md).
Independent credited-replay review approved source `5c26af904a28dd41aaacb3a60f9826037a85980d` / tree `f57a7dd2c210b773956bf218ad088295a03f93ff`: 119 separate passes, 1 native-tool BLOCKED skip, 11 expected legacy diagnostics in 26.55 s, plus direct strict-scalar/post-link valid-JSON controls and schema/lint checks. The selection includes existing bounded synthetic training-pipeline regressions; no actual corpus/final evaluation or native acceptance is claimed. This supersedes pending review only; integration/cross-OS/transfer and broader safeguards remain open.


## Parser CPU work budgets — #184 follow-up (2026-11-04)

Base #184 `64e8374d`. Its Windows QA failure is `tests/test_pe_version_info.py::test_hostile_structure_is_reported_and_never_raises[zero-length-child]`: 0.6499 s wall clock exceeds 0.25 s, run 41807460657/job 126497937645. A controlled 300 ms pause before processing the unchanged hostile bytes reproduces the failure (1 failed, `/tmp/patchtrace-parser-budget-red.log`); with CPU-time measurement it passes (1 passed, `/tmp/patchtrace-parser-budget-green.log`). This is a synthetic scheduling/fixture-IO control, not live Windows evidence. The unchanged work thresholds (0.25 s per hostile case, 1 s per mutation), parser result assertions, and process termination deadlines remain enforced. The SPEC-03 test-measurement amendment distinguishes work budgets from desktop latency targets.

Linux Codespace, Python 3.14.2, `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_pe_version_info.py tests/test_pe_resources.py tests/test_jobs.py tests/test_ui_related_panel.py tests/test_ui_unified.py tests/test_unified_pipeline.py tests/test_backend_symbol_local.py`: **302 passed, 3 skipped in 69.09 s**. Whole Ruff and diff hygiene passed. No product/schema changes. Full suite and Windows exact-head CI remain unverified on this follow-up. #184 must satisfy its checks/review before integration; this follow-up does not authorize a merge.

## QA isolation consolidation — 2026-11-05

Ported PR #184's four test-isolation/load-completion commits and PR #189's CPU-work budget amendment onto `5d504ff5`, preserving assertions and process wall deadlines. Initial focused run: **301 passed, 3 skipped, 1 failed** because an isolated Python child could not import user-site-only `typing_extensions`; provisioning it in the interpreter site repaired the environment, and the exact failed test then **passed**. Whole-tree Ruff and `pip check` passed. Full `QT_QPA_PLATFORM=offscreen python -m pytest -q` started; its result remains pending. Missing Qt GL/xkb libraries were also provisioned before successful collection. Native/Windows release gates are not established by this Linux run; draft integration requires exact-head CI and review.

Independent QA review found a remaining `/proc` reaping race in the imported #184 child-cleanup poll: `exists()` followed by `read_text()` could fail after successful reaping. The poll now reads one observed state per iteration, treats disappearance as success and still fails a non-zombie process at the unchanged deadline. Related jobs suite: **51 passed, 3 skipped**. Ruff/diff checks passed. The full-suite run began at `0fdae562` before this test-only correction; its eventual result does not establish the final test helper head by itself. Exact-head CI remains required.

Full QA interrupted after first observed failure to diagnose: **776 passed, 1 skipped, 1 failed** in 389.28 seconds; interrupted, NOT COMPLETE. Failure: `tests/test_artifact_bytes.py::test_in_place_edit_with_restored_mtime_is_detected` did not raise `ArtifactBytesError`. Same-size restored-mtime content edit escaped the reader's metadata fingerprint on this Codespace filesystem. This is a confirmed integrity defect; deterministic metadata-collision regression and bounded read-content verification assigned to isolated `repair/verified-bytes-20261105`. No full-suite success or merge readiness claimed.

### Verified byte metadata-collision repair (2026-11-05)

The Codespaces full-suite run exposed `test_in_place_edit_with_restored_mtime_is_detected` returning changed bytes without `artifact_changed`. The old reader relied on size/mtime/ctime; a deterministic equal-metadata reproduction failed against the original implementation. The Windows-only skip is removed: content integrity now uses compact 4 KiB SHA-256 block digests collected during the original full-file verification, rechecks touched blocks from the exact buffers returned, and checks metadata after reading. Untouched blocks are checked when requested; empty reads verify metadata only. Each scalar read touches at most one 4 KiB block, and the index costs 8 MiB/GiB. Short OS reads are reassembled without shifting digest boundaries; a short-read control first failed and now passes.

Validation on Linux: artifact-byte, representation and all `test_pe_*.py` consumers: **558 passed, 1 skipped** (Windows-only WinVerifyTrust); `test_alpha_integration.py`: **22 passed**. After documenting peak buffers and releasing the digest index on close, the combined exact-source selection passed **580 tests, 1 skipped** in 16.82 s. Whole `python -m ruff check src tests tools` and diff checks passed. Fixtures exercise metadata collisions, read-time mutation, scalar I/O bounds, cross-block/tail ranges and short reads; no target binary is executed. Exact-head full-suite and Windows CI remain unverified; these portable tests are not native compatibility or release acceptance evidence.

## Rules/callgraph consolidation — 2026-11-05

Isolated port of eight PR #181 commits (excluding unrelated GUI timeout) reviewed against `5d504ff5`. Cache rescoring follows file/rule identity across reorderings; export names validate before writing; saved malformed grids are reported; regular-file hashing and graph successor budgets remain bounded. Review additionally reproduced a hash-valid grid sidecar accepting duplicate JSON keys (1 failed, 5 passed before fix); `RuleStore` now uses the existing strict JSON decoder. Focused pure rules/callgraph suite: **130 passed**; whole-tree Ruff passed. Published draft PR #191, initial source head `df0f1eb8`. New-head full QA/Windows checks remain pending; no live YARA-X compatibility claim. Initial ordinary pytest startup was blocked by absent Codespace Qt libraries; declared dependencies and required system libraries were provisioned separately.


## KB explicit filename eligibility (2026-11-04)

Base main `5d504ff5`; also reproduced unchanged in #176 (the components module and existing unit tests are identical). An advisory title naming a file downgraded an explicit analyst selection to contextual tier D, leaving COMPONENTS_READY and persisted pair resolution unreachable. Contextual title suggestions could also crowd explicit names out of a capped list. Before repair, 3 regression cases failed / 35 passed (`/tmp/patchtrace-kb-red.log`), including the real CLI/store/Winbindex-fixture path.

SPEC-31-G and the KB integration plan now specify selectable A/B/C/E priority over contextual D. D+E dedup records tier E (analyst origin) and retains both reasons and source references. Title-only hints remain D and cannot select files. IDs stay basename/scope bound; byte verification remains pending and no file-to-CVE proof is inferred.

Linux Codespace, Python 3.14.2: focused component/pair-index/service/CLI tests **76 passed in 5.91 s**; `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_kbc*.py`: **1,057 passed in 43.01 s**, synthetic/offline with sockets denied. Whole Ruff/diff hygiene passed. `PYTHONPATH=src python tools/generate_schemas.py` has no drift; explicit import check resolves this worktree's `components.py`. The first schema command without PYTHONPATH picked up the shared editable checkout; its unrelated generated ExportManifest change was discarded and regeneration repeated against the correct source. An initial test command also named a nonexistent glob and collected nothing; corrected command above is the actual evidence. Independent read-only review found no blockers. Full-suite and exact-head Windows/Linux CI remain pending; no live MSRC/Winbindex/backend claim.

### KB integration checkpoint (2026-11-05)

- Reconciled PR #182's three KB fixture commits and PR #190's explicit-filename correction onto `5d504ff5`; excluded #182's unrelated UI wait port for the QA integration owner. Fixtures remain synthetic; structural and crash-protocol assertions are not native/provider or application-recovery acceptance evidence.
- Reproduced the old source behavior: an analyst filename also named by a title became tier D and could not select a component. The correction retains tier E, both reasons and source references, including after CLI/store reopening.
- Broad non-Qt KB validation: 1113 passed, one environment failure because isolated Python could not import a user-site `typing_extensions`. Installed that dependency into the shared interpreter; the affected test and all changed fixture/component/pair tests then passed with normal Qt plugin loading: 96 passed. Global `python -m ruff check src tests tools` and `git diff --check` passed.
- Initial pytest startup was blocked by missing Qt host libraries; these were provisioned before the 96-test pass. Full-suite and Windows qualification remain coordinator/CI gates. No live compatibility claim is made.

## Superseded GUI inspection failures — 2026-11-05

Isolated audit-116 repairs from PR #176: a failure from an old project inspection no longer overwrites the current Files status/error/log. Export policy now clarifies that included code/evidence may retain original paths. Both original audit regressions failed on `5d504ff5`; added current-key/unkeyed failure controls and existing-current-error preservation. Independent review found no guard defect and prompted these controls and more precise copy. Focused GUI suite: **35 passed** in 60.42 seconds; whole-tree Ruff and diff check passed; full/cross-OS qualification remains pending. No report bytes, native adapters, project ownership, or wire contracts change.

## 2026-11-05 transactional desktop project adoption slice

Source accounting: isolated the generic `gui/qt/project_adoption.py` helper and `MainWindow.set_service` delegation from PR #176 commit37a6fed0 (original offline investigation work from #148). No KB dialog, project factory, acquisition, corpus, workflow, unrelated GUI or audit-disposition changes are included. PR #176 remains only partially accounted for. The module was indexed and UI ownership contract specified before porting. No serialized schema fields changed.

Confirmed failure: the previous service closed before incoming rendering/preferences completed. Four new regression cases failed on the original implementation, one passed (20.76s). The isolated helper keeps the previous service open until adoption succeeds, restores the service and both recent-project preferences on failure, closes the rejected candidate and releases its project lock. Same-service re-adoption preserves ownership; failed rollback rendering retains the old service and logs a diagnostic. The coordinator independently reviewed the helper/delegation and found no blocking defect.

PASSED: `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_gui_project_adoption.py tests/test_gui_host_seam.py tests/test_ui.py` — 59 passed in126.45s; full-tree `python -m ruff check src tests tools` and diff-check passed. A separate rollback-render failure test passed (1 passed,5 deselected). No second full-suite run was started; final integration QA and Windows lifecycle acceptance remain separate gates.

### Secondary artifact preparation controls (2026-11-05)

- Isolated the artifact-preparation repair from PR #176. Six deterministic regression cases failed on main: missing cancellation/deadline enforcement during copies, excessive copy cap, absent remaining-budget accounting, and missing optional copy callback.
- Scheduler preparation now checks cancellation/deadlines between bounded reads, uses the 1 GiB ingestion cap, and passes the remaining engine budget. Probe time stays outside that budget, correcting the source PR's worker-start anchor to match SPEC-28. Sources are unchanged; partial private copies remain owned by their temporary working directory.
- `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_audit120_rzdiff_prep.py tests/test_secondary_scheduler.py tests/test_bindiff_inputs.py tests/test_bindiff_run.py`: **85 passed**. `python -m ruff check src tests tools` and `git diff --check` passed. No persisted models changed, so no schema regeneration was needed.
- These tests use injected clocks/copies and portable fake engines; they provide no live rz-diff/BinDiff compatibility evidence. Native producer quarantine and release gates remain unchanged. Full-suite/Windows CI gates remain pending for the integration.

Review limitation: copy checks are cooperative between reads, not OS-call interruption. The pre-existing `lstat` followed by `open` input-replacement surface remains a follow-up: evaluate nonblocking open plus handle `fstat` validation and a deterministic regular-file-to-FIFO replacement test. This slice does not claim to close that surface.

## 2026-11-05 isolated rz-diff research-controls consolidation

- Integrated only PR #174 producer-control commits c2107f57, 0b5c5087, 5175ccbe, e8cd27d1, d22853d3: original #165 source patch/boundary control (51e5b4b1, 4d66af55), #166 callback size_t repair (edab7d91), #168 red-matrix and partition-oracle repairs (4013cdd5, b304034e). No #163/#164 application, GT-01, normalizer, workflow or tracker-restoration changes are included. Existing historical evidence files retain their original scope/date.
- Confirmed an additional evidence-loss defect: rerunning the native evidence runner in an existing output directory overwrote receipts/logs even when the executable was absent. Five regression cases failed before the correction. Exclusive run reservation and exclusive evidence-file creation now refuse reuse and preserve prior output; other build diagnostic files are allowed.
- PASSED: 33 focused tests, no skips, with PATCHTRACE_RIZIN_SIMILARITY pointing to the exact pinned source downloaded from raw.githubusercontent.com/rizinorg/rizin/c3a90e9226d977f58f4e9c75f78fa6b07afe13c7/librz/arch/similarity.c. Test verifies Git blob8544259e17a692bcb3c1d8858f104745cd0cba4c and byte-identical patch/application. Compiled wrapper-double stock-red/corrected-green checks and compiled partition oracle are synthetic boundary evidence only.
- PASSED: python -m ruff check src tests tools. No schemas changed.
- BLOCKED/NOT RUN: complete pinned-native API/CLI JSON acceptance, independent recovered inventories, distinct-byte/IO-context controls, Windows acceptance and downstream Tier R requalification. No target binaries executed; no quarantine, runtime parser, approved pin, cache acceptance, or automation changes. This is a research-tool checkpoint, not a qualified producer.

Full `QT_QPA_PLATFORM=offscreen python -m pytest -q` for this isolated native slice was NOT COMPLETED: stopped with SIGINT during collection after 87.42s (no tests ran, exit130) at the coordinator's request to avoid contention with the mandated integration suite. No test failure was observed or discarded; the local interruption log is `/tmp/pt-native-full-qa.log`. The 33 focused passing tests remain the completed local check. Hosted PR #195 CI is pending and does not yet qualify the producer.

## E4-RANDOM-20261105 — seeded cache-boundary audit

- Seed `20261105`, Python `random.Random(seed).sample(pool, 3)` over ordered pool: ingestion, persistence, normalization, alignment, offline_bundle, runtime_discovery, evidence, interpretation, providers, reports, diagnostics, nway, representations, pe_overview, acquisition, diaphora, enrichment.cache. Selected offline_bundle, enrichment.cache, pe_overview. Open PRs #191–#199 do not change these implementations.
- Baseline `5d504ff5`: three deterministic failures: duplicate size/input manifest fields returned a hit; a >1 MiB manifest returned successful admission. Fixed strict duplicate/nonfinite UTF-8 preflight while preserving Pydantic JSON validation, plus matching admission cap before filesystem mutation. No public interface or schema changes. Quarantine retains original manifest/payload; failed oversized admission preserves prior committed entry.
- Validation: `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_cache_manifest_boundaries_20261105.py tests/test_enrichment_cache.py tests/test_raw_cache.py tests/test_offline_bundle.py tests/test_pe_overview.py`: 173 passed (expected duplicate-ZIP fixture warning). `python -m ruff check src tests tools`: passed. Full suite is coordinator-owned.
- Bounded static inspection of offline installer and PE export/orchestration found no additional reproduced defect in this wave. Authored bytes and local IO only; no target execution, network data transmission or native compatibility acceptance. Windows release gates remain separate and unverified by this wave.

### [UE-AUD-20261104] Unified engine audit and hardening, SPEC-50 report/2, Diaphora source (2026-11-04, PR #180)
Environment: Linux container, CPython 3.13.18, PySide6 6.12.0 (offscreen), pytest 9.2 with pytest-xdist (local only), ruff 0.17.3. Base `main` `25b2ac8`. Every result below is synthetic or recorded data; none is live gate evidence (G-U1..G-U8 never ran live; the unified live gates depend on PR #174).
- Baseline before any change: all unified and unified-UI tests, 2,319 passed, 1 xfailed.
- Slice audits, each with red/green regression tests and an audit record `docs/audits/20261104-unified-<card>.md`: cor (store, pipeline, compute, CLI), fus (fusion, sources, keys), lad (ladder), irx (IR, extraction), gui (read model, Qt panel), har (gate harness and bench), plus the follow-ups w2b (GUI-10, LAD-6) and the coordinator's fixes (FUS-09, run options, xdist-safe stray-files test).
- Reproduced before its fix through the real CLI and an offscreen MainWindow screenshot: a unified result reported stale right after every run on the sample project (COR-02); `unified status` now says `current` after a run.
- Merged branch, all unified, unified-UI, tooltip, Diaphora and KB/pilot unified tests: 2,612 passed, 1 xfailed (before the report/2 and w2b merges). IR, extract, ladder, keys and wire suites after the IR merge: 1,012 passed. Harness suites after the har merge: 368 passed. Report, export, CLI registry, packaging and schema tests after the report/2 merge: 567 passed, 21 skipped. Pipeline, read model, CLI, panel, store, contracts, Diaphora and report2 suites after the run-options change: 822 passed.
- `python -m ruff check src tests tools`: clean. `python tools/generate_schemas.py`: no drift apart from the additive `ExportManifest` fields of report/2 (regenerated in that slice).
- Deliberate result re-keying (cached results are recomputed once): `manual/3`, `ladder/4` and the new pass-table digest domain, `INGEST_REVISION=2` with the changed `ghidra_script.py` (`script_sha256` moves). Projects without Diaphora sets keep their result ids (tested).
- Not verified here: Windows (CI pending at the time of writing), real Ghidra/BinDiff/Diaphora output, the BinDiff pin, the Windows frozen bench and the largest Tier R pair (G-U5), screen readers and DPI. SonarCloud reported "Security Rating on New Code: C" for head `88d48fc`; the issue list is on sonarcloud.io, which this session cannot reach, so the finding is not identified yet (owner action).

### [UE-AUD-20261104:facts-and-integration] Facts audit and integration merges (2026-11-04, PR #180)
- Facts audit (fct, Opus): 563 focused tests over 28 files before merge. After merging it and applying FCT-10 and the rule-version bumps: IR, extract, wire and EH suites 653 passed; all unified and unified-UI tests 2,590 passed, 1 xfailed; ruff clean; no schema drift.
- SPEC-51 (d2): 742 passed, 5 skipped (new and existing `tests/test_pe_*.py`, tooltips, GUI host seam, docks, CLI features). Microsoft hosts were unreachable (403); the Authenticode ranges and OIDs were corroborated against signify 0.7.1 (MIT; no code copied). D2-4 Windows catalog: fakes only, BLOCKED for real acceptance.
- report/2 wiring (rpt3): report, tooltip and export-destination tests 281 passed; new adapters and dialog tests 28 passed; Qt repeat gate x5 65 passed. `test_ui_seam_budget` failed after that merge (ui.py 3,117 lines over the 3,077 budget) and passes after moving the controls to `ui_export_v2.py`.
- SonarCloud: the duplication condition (7.4%, then 4.8%) cleared after de-duplicating the set-file reader and storing the HTML goldens as `*.html.golden`; "Security Rating on New Code: C" remains unidentified (sonarcloud.io unreachable from the agent session).


## Manual correction member completeness (2026-11-04)

Candidate base: PR #180 at `a7689119fc25be61a4ac1b65619d6968859a136f`. A correction containing both a resolvable and an unresolved member silently lost the latter; a merge/split could become an affirmative tier-M 1:1, and the persisted result could be complete. Reproduction: 14 category/side adapter cases plus one compute/write/read integration case failed before the repair (15 failed, 15 passed; `/tmp/patchtrace-manual-red.log`).

SPEC-31/06 now requires every named member to resolve before any correction atoms, groups or nodes are emitted. The adapter retains independent valid corrections, emits degrading `manual-unresolved:N`, and moves to `manual/4` to invalidate old cached identities. No wire shape changed. Schemas regenerated without drift.

Linux Codespace, Python 3.14.2; pinned project dev/search/rules dependencies installed in `.venv`, missing Qt system libraries installed. `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_unified_fus_manual.py tests/test_unified_sources.py tests/test_unified_fusion.py tests/test_unified_evidence_identity_20261101.py tests/test_unified_wire_compute.py tests/test_unified_pipeline.py`: **179 passed in 12.54 s**. Whole `python -m ruff check src tests tools` passed; `git diff --check` passed. Full offscreen suite is running; its result and exact published SHA will be recorded separately. Synthetic inputs only, no live backend/provider or Windows qualification is claimed.

GitHub code-scanning and branch-protection queries returned HTTP 403; Dependabot alerts endpoint reports disabled (403). Those checks are unavailable, not clear. No merge attempted. Current local Codex config does not select a model or expose usage/account quota, and no usage/billing connector is available. Actual account TPM and dollar usage cannot be verified or the requested $25 cap claimed enforced. One primary worker plus one bounded read-only reconciliation/review worker; no extra paid API scripts, provider calls, scheduled workflows or model switches were started. No rate-limit event observed.


### Manual snapshot follow-up: category defense and member cap

Worker snapshots could turn contradictory added/removed categories into tier-M pairs or declarations on the opposite side. The project `FunctionMatch` validator already rejects those shapes: this repair is defense at the independently parsed snapshot/adapter boundary, not a claim that normal project creation accepts them. Six category/shape regressions failed before the adapter guard; they now produce degrading `manual-unresolved` and no rows/facts. Adapter `manual/5` invalidates the earlier semantics.

A separate production defect is owner snapshot truncation: valid manual groups over 1,024 members were sliced before `manual_digest`, losing members and hiding changes to omitted functions from cache identity. Four tests with real validated FunctionMatch/FunctionRecord models failed before repair. Selected-run oversized manual groups now fail closed with `PT-UNIFIED-LIMIT/manual-members-cap` before hashing/execution; exact-cap groups and unrelated runs remain usable. Prior committed results are not rewritten.

Category follow-up before the cap repair: `QT_QPA_PLATFORM=offscreen PYTHONPATH=src python -m pytest -q tests/test_unified*.py tests/test_ui_unified.py`: **2,515 passed, 32 skipped, 1 xfailed in 400.16 s**; native MSVC-free checks explicitly BLOCKED for missing lld-link. Final cap/category/sources/identity/pipeline/wire selection: **156 passed in 10.52 s**. Whole Ruff/diff passed, schemas regenerated against this worktree with no drift. The earlier full suite continues separately on frozen `31f51e76`; it has recorded a failure and is not a pass for this follow-up.

Actual Windows native Ghidriff workflow [41934879294](https://github.com/djshellshoxxx/patchtrace/actions/runs/41934879294) completed successfully on exact `31f51e76831ff58ff1ba4982a9c34df1b9b39a01`: patchtrace-clean, seeded-store, seeded-store-no-adjacent-pdb, raw-cache-hit, and repro-plain-ghidriff jobs. This is old-head native CI evidence, not evidence for these subsequent source edits and not G-U1–G-U8 or clean-machine release acceptance.


### Reviewed help dependency integrated into the manual-fix candidate

PR #185 is exactly #180 plus help commits `9313d11b`, `4abe7e33`, `81a9fb28`, verified with range-diff and file comparison. Those three documentation commits were merged without rewriting their provenance; #188 is now stacked on #185 so its reviewed diff remains the manual safeguards only. Post-merge help/CLI/unified-CLI/manual/cap selection: **322 passed in 26.15 s**. The two missing help-page coverage cases are covered by this selection. Independent final review of `063e9fe6` found no blockers, confirmed selected-run/exact-cap behavior, and required the project-vs-snapshot distinction now recorded above. No GitHub main merge or owner gate bypass.

### A4-C3-20261105 offline investigation desktop slice

Source accounting: isolated PR #176 (`597a8b106491cd587cedf1273ee5ef6d56d71508`) offline investigation service/dialog, create-only project factory, host adoption callback, menu and tooltip hooks. Includes only the local `import_pair` preview revision, locked stale-revision check and product-architecture guard from that source; remote acquisition and document-scoping changes, calibration/replay/persistence/security work and unrelated palette changes remain excluded. Prerequisites are the reviewed KB fixture/filename and transactional project-adoption branches; both tracker sections were preserved during the local prerequisite merge.

Baseline acceptance: the source's two workflow regression modules fail collection with two missing-module errors on main plus prerequisites (`/tmp/pt-investigation-red.log`). Initial implementation passed all 21 service/Qt cases. Added a KB-start real offline journey and actual MainWindow host regressions for failed rendering/adoption and a changed current project. Tests cover strict import retention, source references, explicit product selection, inspected hashes, stale preview/byte rejection, architecture mismatch, create race, retained partial project, cancellation and late completion. Synthetic fixtures/fake transports are offline evidence only. Product-only and binary-only desktop starts, online wizard acquisition, native Windows accessibility/DPI/frozen delivery and live provider compatibility remain open; existing CLI routes are unchanged.

Integration failure found and corrected: the global tooltip reachability audit did not construct the newly registered dialog; it failed with the dialog control IDs missing. The audit now builds the real parented dialog and enumerates its controls (no exemption added). Subsequent tooltip file: **18 passed in 27.03 s**. Separate host seam: **24 passed in 26.47 s**. Existing acquisition/service regression selection: **47 passed in 14.45 s**, using offline/fake transports. Real host successful-adoption case: **1 passed in 6.94 s**. Whole-tree Ruff and diff checks pass; schema generation against this worktree (`PYTHONPATH=src`) has no drift. Full suite is reserved for coordinator integration.
Final bounded service/dialog selection, including CVE and KB real offline journeys and real host success/failure/changed-selection adoption: **25 passed in 5.88 s**. Together with the separate host seam, tooltip and acquisition/service selections above, 114 distinct tests pass. These are constructed/offline tests; native source and Windows qualification remain unverified.
Independent read-only review of implementation `27c9c948` found no blockers: preview invalidation/generation, locked revision/pair guard, explicit scope/architecture, create-only port, retained late/partial creation, host current-service checks and adoption rollback reviewed. Reviewer independently reran the service/dialog selection: **25 passed in 5.50 s**. Code is ready for coordinator integration; release/live gates above remain open.

## E4-RANDOM2-20261105 — recovery copy preservation

- Reproducible selection: `random.Random(20261106).sample(pool, 3)` over ordered pool ingestion, persistence, normalization, alignment, runtime_discovery, evidence, interpretation, providers, reports, diagnostics, nway, representations, acquisition, diaphora selected nway, ingestion, persistence. Previous selected modules and current source owners excluded.
- Baseline `5d504ff5`: all three negative recovery cases failed deterministically. `nway.series._keep_corrupt_copy` treated an existing hash-prefix backup name as proof of preserved bytes; unrelated content, a directory or a symlink allowed `--replace-corrupt` to discard the only damaged original. Repair verifies a regular non-link recovery file and exact bytes on a bounded handle before reuse; failures retain both paths. Exact-copy reuse leaves its inode/mtime unchanged. No interfaces or schemas changed.
- Validation: 32 tests passed across the new initial three regressions, `test_nway_series_tolerance.py` and `test_nway_series.py`; final new regression file (four cases, including exact-copy reuse) also passes. Whole `python -m ruff check src tests tools` and `git diff --check` passed. No full suite (coordinator-owned).
- One-defect bounded wave; static inspection of ingestion/persistence did not yield another reproduced finding. Authored PE bytes/local file IO only. No native engine/Windows acceptance evidence; release gates remain independent.

- Coordinator pre-publication review found no blocker for the existing-copy repair. Remaining limitation: `_keep_corrupt_copy` still reads the damaged original via `path.read_bytes()` even when normal load rejects its size; this wave bounds only verification of a preexisting recovery copy, not the whole recovery path.

## CI fragment discovery repair (2026-11-05)

GitHub #191 Ubuntu QA job127522978541 completed with18743passes/47skips/7xfails and3failures, all caused by main's step-only `.github/workflows/openai-agents.yml` (missing workflow name/on/jobs/permissions/timeouts). Local unchanged baseline reproduces3failed/48passed/3existingxfails in workflow source checks. Preserve the fragment byte-for-byte under `.github/workflow-examples/openai-agents-step.yml`, with explanatory README, so only executable workflow definitions are discovered. Final focused source validation:49passed/3existingxfails; whole Ruff/diff hygiene pass; original bytes verified against5d504ff5. No new paid runner/trigger or competitor automation is enabled; #167/#170/#171/#186 remain separate review candidates. Whole/cross-OS acceptance remains pending on the resulting integration head.


### Secondary input replacement follow-up (2026-11-05)

Coordinator reviewed source `8244ec7e`: read-only descriptor opening uses nonblocking/no-follow flags where available, then validates handle and fresh path regularity plus admitted device/inode identity before creating a destination. Every opened descriptor closes on refusal or completion. Existing cancellation callback, exclusive destination, bounds and caller hash comparison remain intact; this is not arbitrary filesystem-call interruption.

Deterministic baseline: **3 failed, 1 passed** (another regular file and a symlink to the retained original were accepted; a regular-to-FIFO swap blocked a Python test child until its five-second timeout killed it; directory replacement was already refused). Final implementation: **92 passed** across input/run/preparation/scheduler/C3 integration tests. Expanded input-only controls, including operation without `O_NOFOLLOW` and descriptor closure: **26 passed**. These selections overlap and are not an aggregate count. Whole-repository Ruff and diff checks passed. The receipt commit changes documentation only after the reviewed implementation.

Tests use synthetic files and Python/fake-engine fixtures; no target binary was executed and no native engine compatibility is claimed. FIFO coverage is POSIX-only; symlink cases may skip where creation is unavailable. Native Windows and combined integration/full-suite qualification remain pending. Earlier committed evidence and the coordinator's frozen candidate are unchanged.

## E3-RECOVERY-20261105 — streamed corrupt-series preservation

- Follow-up to E4-RANDOM2 (base `f2b7d178`): reproduced oversized recovery's unbounded `Path.read_bytes()` with a guarded original that rejects that API. The regression failed before implementation.
- Recovery now hashes and copies/compares through one regular non-link source handle using reads <=1 MiB, bounded to its captured length plus an EOF probe. Rewinding does not reopen the source. Full first/second digest agreement plus handle/path identity, size, mtime and ctime checks reject changes; existing copies receive the same chunked regular-file/change checks. No new evidence-size cap; default normal-load cap unchanged. Failure removes only this attempt's incomplete exclusive copy when its identity still matches.
- Validation: `QT_QPA_PLATFORM=offscreen python -m pytest -q tests/test_nway_recovery_copy_20261105.py tests/test_nway_series_tolerance.py tests/test_nway_series.py`: 38 passed in 9.86s. Includes oversized save success, guarded second-pass read failure and same-size mutation for both new/existing copies, collision refusal and exact-copy reuse. Whole Ruff and diff whitespace checks passed. Full suite stays coordinator-owned.
- This closes the full-original-read limitation recorded by E4-RANDOM2. Cooperative change checks are not a filesystem sandbox against arbitrary concurrent writers after the final check. Authored bytes/local IO only; no native Windows or engine acceptance claim.

- Coordinator review requested new-copy receipt and descriptor-failure coverage. Added flush/fsync-time target path/handle verification: an injected replacement of the newly created copy refuses series replacement and retains the foreign path. Injected target `fstat` and `fdopen` setup failures confirm descriptor closure. Final focused result: 41 passed in 7.68s; whole Ruff/diff checks pass. An identity-setup failure can leave an empty exclusive copy when its ownership cannot be re-verified safely; recovery never deletes an unverified path.

## D2-E6-OFFLINE-20261105 — unambiguous producer pin qualification

- Local source review: `tools/check_backend_pin.py` CLI and producer `gate_pin` each used permissive `json.loads`; six deterministic regressions on `5d504ff5` accepted duplicate schema, Ghidra digest and licence-owner-approval fields (each final value valid). This is a qualification ambiguity defect, independent of native runtime compatibility.
- Shared stdlib checker parser now rejects duplicate keys at every level, nonfinite constants/exponent overflow, invalid UTF-8 and lone surrogate text before normal policy validation. Producer uses the same parser; a real build-entry regression verifies refusal before output/cache creation, injected download or runner. Committed pin values, versions, licences and exact input bytes remain unchanged. Runbook's forbidden `tofu` advice corrected against existing approved pin-source contract, without changing the policy.
- Validation: focused `test_backend_pin_strict_20261105.py`, `test_backend_pin.py`, `test_build_backend_bundle.py`: 179 passed, 1 skipped in 14.01s. Whole Ruff and diff whitespace checks passed. `python tools/check_backend_pin.py --release`: exit 0 (`backend pin ok`), proving local pin consistency/policy only. No large payloads downloaded, workflow activation or external provisioning performed.
- Native clean Windows offline acceptance and downloadable full-runtime release qualification remain unverified by this Linux tooling repair; existing release acceptance gates remain open. No Windows compatibility, live engine or full-runtime artifact claim. Full suite remains coordinator-owned.

## E3-PROJECTCREATE failed initial creation rollback (2026-11-05)

Source accounting: PR #176 audit #116 creation rollback intent and four source regressions, isolated onto main `5d504ff5`. The source's recursive cleanup of every newly named directory entry was deliberately replaced: concurrent analyst files are not owned by a creation attempt. No export, UI, KB, model/schema or unrelated source changes are included.

Baseline source regression run: **4 failed in 1.38 s**; invalid second input left an immutable copy and artifact directory. The source tests also demanded deletion of `.patchtrace.lock`, but that persistent kernel-lock inode is intentionally retained to avoid split writer ownership. Acceptance now verifies actual retry, copied-input cleanup and preservation of foreign/prior files and permissions instead of an entirely empty directory.

The optional Python-only ingestion publication ledger records new files/directories and the staged inode before read-only chmod. Exclusive same-directory `os.link` publication refuses overwriting a concurrent destination; an existing destination is verified before reuse and never claimed. Rollback keeps the project lock, closes SQLite, removes only matching recorded files and empty owned directories, and preserves already committed first snapshots. Foreign concurrent paths, replacements/symlinks, reused read-only copies, interruptions and post-publication failures have focused regressions. New artifact publication requires a hardlink-capable project filesystem; unsupported filesystems fail closed before publication. Native Windows/NTFS qualification remains pending; Linux emulated read-only deletion is not native Windows acceptance.

Validation: `QT_QPA_PLATFORM=offscreen PYTHONPATH=src python -m pytest -q tests/test_audit116_create_rollback.py tests/test_service_storage_audit.py tests/test_ingestion_core10.py tests/test_core.py tests/test_audit_core.py tests/test_core_review_regressions_20261029.py` — **76 passed in 6.02 s**. Whole-tree `python -m ruff check src tests tools` and `git diff --check` passed. No full suite was run by this slice; coordinator owns combined QA.

Independent read-only review reproduced a residual lstat→unlink race by injecting an exact owned-basename replacement inside `Path.unlink`: the foreign replacement could be deleted after the final ownership check. The coordinator explicitly scoped this repair to the existing cooperative project-lock model and identity-checked best-effort cleanup; an uncoordinated process racing the final unlink/chmod is not covered, and no atomic conditional deletion or OS-sandbox claim is made. The architecture contract states that limit. Ordinary foreign-path, preexisting/reused/read-only, replaced-before-check, committed-snapshot and held-lock tests remain intact. Quarantine/native-handle hardening and native acceptance remain open follow-ups.
Coordinator final read-only review approved the bounded implementation for draft publication: committed snapshot retention, database/artifact cleanup under the lock, read-only owned cleanup and foreign-before-check preservation. Retry evidence here is backend `ProjectService.create` only. A desktop destination picker may reject the intentionally retained lock-only directory as nonempty; end-to-end wizard retry is unverified and remains an integration follow-up.

## E4-B5-SONAR-20261105 — parity parser CPU and fixture source safety

- Frozen base `a33a4405`: authored MD dump line (`401000` + 100,000 spaces + `X`) deterministically exceeded a 3-second child timeout. Adjacent whitespace quantifiers in `_MD_LINE` explored ambiguous partitions despite the decimal digit cap. The child is killed by `subprocess.run` on timeout; no native tool or target executes.
- Replace the whole-line regex with explicit boundary whitespace scans plus bounded address/value checks. Preserve optional lowercase 0x, 1–16 ASCII hex digits, whitespace or colon/comma/equals separators, signed decimal with 1–30 digits per side, duplicate-last-wins and rejected-line counts. A bounded child asserts rejection CPU <1 second; grammar cases include Unicode whitespace/digits, decimal/address limits and malformed separators.
- Escape literal bidi U+202E in only `test_pe_der.py`, `test_pe_signature.py`, `test_report2_adapters.py`, `test_unified_diaphora_adapter.py`, `test_unified_irx_records.py`. Independent AST comparisons against the base were identical for all five files, preserving every runtime fixture value/assertion; no gate exemption added.
- Validation: selected parity/fixture suite 168 passed in 8.99s; final parser budget/grammar file two tests also passes (169 unique focused cases covered). Whole Ruff and diff whitespace checks passed. Full suite/Sonar rerun remain coordinator-owned. Authored-text timing is not native BinDiff dump-format compatibility evidence.

## Combined swarm qualification and supporting repairs (2026-11-05)

Frozen candidate #205 `a33a4405` integrates prior #191–#199 and new #200–#204 once. First combined full attempt:422passed/1failed after232.80s; source-CLI smoke subprocess imported the shared editable checkout's old CLI lacking export/inspect. Exact smoke passed after candidate source scoping. A source-scoped retry was interrupted at422passed after172.73s because isolated Python still resolved the shared editable checkout. Neither attempt qualifies the candidate. A dedicated system-site test venv installs candidate editable without changing global installation; both ordinary and `-I` module paths resolve `/tmp/pt-swarm2/src`. Fresh whole-suite run is pending there with fail-fast diagnosis and all tests selected.

Follow-up candidate includes reviewed #206 descriptor input ownership, #207 bounded recovery streaming, #209 strict release-pin parsing, #210 ownership-aware creation rollback, #211 linear parity parser/AST-identical hostile fixtures, #212 approved source SHA256/checkout containment. Their isolated focused results and limitations are in source receipts. #208 retains actual missing-header/library diagnostics; no native executable ran and prerequisites were not provisioned in that bounded wave. Local dependency installation is authorized generally; this is not an unavoidable external blocker.

#210 rollback is identity-checked best effort under the cooperative kernel writer lock. Persistent lock retained; previous snapshots and known foreign/reused files preserved in tests. Uncoordinated final-path replacement between last check and unlink/chmod remains a disclosed residual, not an atomic compare/unlink claim. Exclusive artifact publication requires hardlink-capable storage; unsupported filesystems fail closed. Backend retry is covered; lock-only destination GUI retry remains open.

Sonar205 currently fails. Actual parity slowdown and checkout source escape have fixes; independent remaining operator/benchmark/explicit-output review is in `docs/qa/sonar-205-triage-20261105.md`. No quality gate or issue status was bypassed; authorized project review access and fresh exact-head scans remain required.

## Offline investigation import-boundary integration (2026-11-05)

Dedicated candidate #205 full run at a33a4405 stopped1failed/7351passed/13skipped/4existingxfails in782.08s. Failure: the root KB import scan denied PySide6 in new `investigation_qt.py`. Accepted module index/spec identify it as a named Qt adapter alongside panel_qt; PR176 already carries the missing exact-basename whitelist. Port only PySide6 and gui/tooltips allowances for that adapter. The service remains Qt-free and UI/database/network exclusions remain enforced. Seven guard regressions prove UI Qt accepted while service Qt/network/database and UI network/database stay denied. Related checks159passed; independent import/guard selection44passed/90deselected, Ruff/diff clean. No production behavior or wire/schema fields changed; full/exact-head CI still required.

## A4/C3 current project input journey (2026-11-05)

Frozen #205 base `a33a4405`: an actual MainWindow with an open sample project exposed no current-input action; the new baseline journey failed with `KeyError: use_current` (1 failed in 2.95 s). A subsequent real journey exposed the existing rejection of stored hash.bin names. The bounded repair adds an explicit action and frozen, strict-JSON-decoded existing Artifact snapshots, verifies copies off the GUI thread through the shared reader, then uses captured original names solely as manual component/display hints in the existing local inspector. Each live inspection checks SHA/size before pair resolution, and returned pair hashes must still match. Exact advisory scope, same-component confirmation and current preview remain required. No source project connection/second writer lock, database/model/schema additions or remote traffic.

Origin project id/revision, artifact ids/names and hashes are preview-only convenience provenance. Source annotations and CVE linkage are not carried over; stored context remains the existing manually selected hashes/decision. Host snapshots and callbacks check service identity, revision and ordered artifact records; stale work cannot replace the current service, and late created paths remain reported/reopenable. Original-name labels outside the existing .sys/.dll/.exe contract (including derived projects already labelled hash.bin) return PT-KBC-UNSUPPORTED. Distinct artifact ids sharing a stored hash/path support the existing identical outcome when hints canonically agree, and explicitly refuse conflicting hints. Broader filename/derived-label preservation remains an open contract, not a fabricated alias.

Validation uses the worktree PYTHONPATH with `/tmp/pt-followups-venv/bin/python`; explicit import resolves `/tmp/pt-kb-current2/src/patchtrace/kbcorrelation/investigation_service.py`, and no global editable install was changed. Before final identical-label controls, service/dialog/current journey, host seam, tooltip and KB boundary integration: **217 passed in 82.75 s**. Expanded current-journey file: **15 passed in 83.13 s** (shared load); final size-cap and identical controls after the fast pre-encoding character cap: **5 passed, 12 deselected in 7.90 s**. Whole-tree Ruff and diff hygiene pass. The scoped boundary file preserves boundary repair `226ac7e5`'s seven negative controls and adds only investigation_service models/artifact_bytes siblings with five allowed/denied checks. Fixtures are synthetic/offline; native Windows/live/full-suite integration remain coordinator gates.
Independent read-only review approved exact implementation `0b3c58fb` against `a33a4405`, with no blockers: strict snapshots/off-GUI verified I/O, no second source-project lock, limited manual hint authority, explicit confirmation, per-inspection hash/size before pair commit, stale-owner retained creation and exact sibling boundaries reviewed. Independent focused controls: **20 passed, 136 deselected in 15.91 s**, scoped Ruff/diff clean. Native/live/full-suite and unsupported-label gates above remain open.

## Current-project journey in the follow-up candidate (2026-11-05)

Reviewed #214 source0b3c58fb (final receipt head ef70e0bd) merged into follow-up candidate after #206/#207/#209/#210/#211/#212. Integrated current-input/service/dialog/contract/tooltip/adoption/rollback selection:219passed in78.40s; whole Ruff/schema regeneration/diff clean. Worker evidence217earlier integration passes plus17current controls across overlapping selections; independent review20passed/136deselected. These counts overlap and are not added as unique coverage. Snapshot decode strict and bounded, input hashing/IO off GUI, no second project store/lock, observed SHA+size checked before pair commit, manual component confirmation and stale-owner/retained-path behavior preserved. Original .bin/derived-label and conflicting shared-path labels return explicit unsupported status, not fabricated metadata.

Further whole-suite diagnosis after the import-boundary fix reached2096additional passes/10skips before a network-guard harness assertion. Cause was the coordinator's PYTEST_ADDOPTS fail-fast setting propagating to its intentionally failing child pytest; guard itself correctly rejected/recorded network attempts. The outer diagnostic runner now passes fail-fast as arguments with no inherited setting. Remaining-node diagnosis continues from that node; it is a subset continuation, not a fresh complete exact-head full-suite pass. Initial temporary diagnostic runner collection also lacked cwd on sys.path; corrected to match python -m semantics before running tests. No application assertion/gate/consent guard changed.

## Final coordinated checkpoint (2026-11-05)

Reviewed follow-up #213 (including #214) and actual local native-prerequisite receipt #208 integrated into primary review candidate #205. No main merge/release. Runtime source, tests, tools and workflow trees match reviewed/tested follow-up c6691ab1 before documentation-only additions. Whole Ruff/schema no drift; final tracker/import checks recorded in the checkpoint receipt.

Older a60d1dbc remaining-node diagnosis ended143/SIGTERM after88% progress, no pytest summary and cause not established; NOT COMPLETE, no pass inferred from progress. Final overlapping1600-node tail completed1573passed/27skipped/18117deselected in156.89s. Earlier7351pass whole attempt stopped on omitted named-adapter test metadata, fixed with precise negative purity controls; later2096pass segment stopped because inherited diagnostic fail-fast truncated its controlled child pytest, corrected by outer-only arguments. These are diagnostic segments, not a fresh unsplit full exact-head pass and not qualification of newer follow-up production changes. Full final-head/native/Windows/package/scanner gates remain open. All worker edits are committed/published and raw local logs retained.

### LBL-30 recorded-protocol CLI integration — 2026-11-05

Ported the isolated preregistration selection slice from PR #176 (bad8fa4c, 500ab5a9, d8d8be45) onto f33e2a0a; replay/output persistence remains separate. Before repair the acceptance file produced 96 failures/1 pass; after repair 97 passed. Whole-tree Ruff passed; source-bound schema generation produced no drift. Broader training regression and independent review remain pending at this checkpoint. No real locked evaluation, corpus label, numerical threshold or runtime calibration promotion changed.

### LBL-31 credited-output replay consolidation — 2026-11-05

Selectively ported the remaining normalized-output retention, report completion, replay and bounded metadata slice from PR #176 onto LBL-30. Baseline f33e2a0a independently reproduced a foreign `ghidriff` response scored/credited under its `rz-diff` provider owner; the same constructed control is refused after repair. New feature acceptance initially could not collect because retention modules were absent. After porting and generating all corpus/calibration schemas: 239 focused tests passed; a broader contracts/calibration/unified-harness selection passed 234 tests (overlapping selections), with expected explicit warnings for unverified legacy output compatibility. Whole-tree Ruff passed. Independent security review pending. No actual corpus fit, labels, native compatibility or calibration promotion is claimed; atomic publication requires hardlink-capable storage.

### Wave-three reviewed integration — 2026-11-05

#215/#216/#217 reviewed source integrated at dfc212e2: combined276 passed; Ruff and all four schema generators passed with no drift. Independent prereg97 and replay44 controls passed. Frozen f33e2a0a complete suite remains running (log /tmp/pt-205-f33-full.log); one stale SIGKILL double failure reproduced, repair pending in lifecycle slice. Current scanner/Windows/native/release gates remain open; no main merge.

### GUI retry / retained committed acquisition — #219 integration

Reviewed38be184c merged at a84bf6d1. Five real preflight paths now permit absent/empty/sole regular non-symlink lock directories while kernel locking and committed-database refusal remain authoritative. Baseline actual retry/stress double2failures and separate contributor-file deletion1failure were reproduced. Promotion retains committed project, prior annotations, foreign files and persistent lock, closes service, reports retained path. Integrated lifecycle/KB/calibration475 passed39.80s; author228 and independent206 selections overlap, plus independent second-annotation/KeyboardInterrupt probes. Ruff clean; no schema/model/error-code changes. Frozen f33 full suite remains running; final updated-head/native/Windows acceptance open.

### Reviewed normalizer and binary-only desktop — #220/#221

#220 cf9cefff reserved metadata guard:24 baseline red/1pass, independent77pass; rejects forged derived claims while preserving raw inputs/prior committed evidence. Integrated normalizer/unified-source106pass. #2217e7a52eb real binary-only local-pair preview/create/reopen/export: independent207pass and no-preview-write/reversed-orientation probes; product lineage/advisory linkage remain explicitly unverified. Integrated both with prior lifecycle:339pass23.77s. Counts overlap. Worker full-suite collection was stopped/no tests run; root f33 suite is the sole complete-run attempt still active. Updated-head full/Windows/native acceptance remains open.

### Native provisioning / canonical normalizer identity — #222/#223

Verified all14 complete compressed/raw log receipts and exact unfinished status for #222 dbebfee8; actual pinned headers compile, native oracle/link/CLI not yet executed. Source/dependencies/build cache provisioned with supported PCRE2 retry; quarantine unchanged. #223631b5e91 closes equivalent address spelling duplicate bypass with existing parse_address while preserving raw spelling and repeated-function refusal:14 baseline red/1pass, independent95pass. Latest integrated normalizer/binary/KB/lifecycle357passed33.26s; Ruff clean. Complete f33 suite still active; no exact updated-head full pass claimed.

### [MERGE-20261106:branch-consolidation-readiness]

Audited 242 remote branches and 112 open PRs against pinned main/#205/#218/#235. Isolated #235+#242+#243 source tree `ea48a7e087590fccffadb54e4414bd000f16838b` preserves the nine leaf-owned files and all other integration content. Root affected checks: 424 passed; independent overlapping controls: 42 passed; whole Ruff, diff hygiene and KBC schema drift checks pass. #204 was moved to ready-for-review at its unchanged head after fresh baseline/fix validation. Hosted smoke/review and integration Windows/scanner gates remain open. [Plan](plans/branch-merge-plan-20261106.md); [receipt](qa/branch-merge-readiness-20261106.md). No main merge or release acceptance is claimed.

## N-way Windows recovery compatibility (2026-11-06)

On frozen #205, hosted Windows CPython 3.12.10 reported five recovery failures.
Pinned CPython source and a real-file fault probe identify incompatible pathname
versus descriptor `st_ctime` meanings. Recovery now retains independent complete
timestamp baselines while preserving cross-view device/inode/size/mtime checks,
streamed exact bytes and owned-copy cleanup. New controls first produced two
failures/four passes; corrected recovery/tolerance/series selection: **47 passed
in 3.37 s**, whole Ruff/diff clean. Native Windows and exact integration gates
remain pending. Source blobs, invariants and limits are recorded in
`docs/qa/nway-windows-recovery-20261106.md`.

### [KB-ADMISSION-20261106:captured-source-context]

Reproduced #244 review comment 4489325824 against exact `5347ccfd`: source imports after the old snapshot check could enter a saved ContextBundle. Both real-store timing controls failed before repair. SPEC-31-D now specifies admission after one index read and reuse of that index for scope/context; pre-admission drift is stale, and later imports remain available outside the captured context. After repair, both controls pass and the overlapping lifecycle/acquire/service/crash-recovery selection passes **75 tests in 10.56 s**; whole Ruff passes. Prior project bytes, legitimate source imports, verified artifact hashes and owned staging cleanup are checked. [Detailed receipt](qa/kb-source-admission-20261106.md). Independent integration review and existing hosted/native/Windows/full-suite/scanner gates remain open.


## Branch consolidation execution and full-run limits (2026-11-06)

Combined #244 source tree `3e5276d6643d784e459264d6cb213082b812c8d4`: 774 focused tests passed, whole-tree Ruff passed, schemas unchanged. Separate exact #245 full Linux run: **3 failed, 19618 passed, 139 skipped, 6 xfailed, 1 warning in 2537.16s (0:42:17)**. All three failures reproduced on frozen #205; two launcher controls pass in the corrected environment, while local AF_UNIX construction remains unavailable. The original full run remains non-green. See [complete result and controls](qa/pr245-linux-qualification-20261106.md) and [merge plan](plans/branch-merge-plan-20261106.md). Native Windows, current-head hosted checks and parent scanner dispositions remain open for the application candidates. #204's two smoke jobs subsequently passed and the exact reviewed head merged into main at `d02b94bcedb29dae201941f01f2c94d42ebbb297` on 2026-11-06 at 06:27:13 UTC; the source branch was retained.


## Subprocess virtual-environment preservation (2026-11-06 UTC)

On main `d02b94bc`, two subprocess isolation tests resolved the active interpreter
symlink to a base Python without the installed protobuf/YARA-X dependencies.
Both failures reproduced. Retaining `sys.executable`, as the production workers
already do, passed both complete test files: **116 passed in 42.16 seconds**.
No assertion, limit, environment filter or production code changed. Independent
review, whole-tree Ruff, dependency consistency and diff hygiene passed. Full
and hosted cross-platform qualification remain separate; the local AF_UNIX
restriction is unchanged. [Detailed receipt](qa/subprocess-venv-20261106.md).

## [CONTINUATION-20261106:local-product-start-and-qualification]

Unchanged #245 passed Windows QA: **19,671 passed, 90 skipped, 5 xfailed**,
plus standalone, frozen EXE, portable ZIP and installer gates. The downloadable
candidate belongs to #245, not the later product implementation. Linux full QA
and the native Windows Ghidriff workflow subsequently passed; Ubuntu Qt is
still outstanding at the 08:18 UTC checkpoint.

Reviewed product source `570f86b8` (published equivalent `0b7d8581`, identical
tree) adds the stored-product catalogue, explicit selection, source-bound local
pair preview/create, and original-source pending repair. Final affected
selection: **139 passed** including 59 product cases; independent acceptance:
**16 passed**, no findings. Six distinct independent cases are retained in
`test_kb_product_acceptance_20261106.py`; those plus authored cases: **65 passed**.
Earlier 391-test evidence predates the final repair; counts overlap. New pending
product attachments require the new journal reader: legacy repair ignores
`selected_product` and was observed to lose source digests. Public schemas/SQL
version/CLI grammar are unchanged, but internal journal format is extended.

Test-only exact-byte diagnostics preserve full equality while bounding failure
rendering; affected selection **49 passed**, separate real child-pytest controls
passed. The previously failing #235 Windows report identifies two large byte
diff cases taking 42.6% of that failed run; no normal-path speedup is claimed.
The continuation includes actual #246 ancestry and preserves all source refs.
Whole Ruff/schema/diff checks pass. Combined current-source full and hosted
qualification remain separate. [Evidence and limits](qa/continuation-20261106.md).


## [CONTINUATION-QUALIFICATION-20261106:completed-local-results]

Frozen #247 local full result: **1 failed, 20,284 passed, 139 skipped, 6 xfailed, 18 warnings in 3356.58s**. Only AF_UNIX construction was denied; timing/GUI controls passed. Hosted Ubuntu separately passed **20,372 tests**. The original #246 five-failure run remains preserved; one unchanged three-control timing follow-up passed without establishing cause. Both #244/#246 hosted full suites passed.

Fully qualified #245 merged normally into #205 as `6095f702`; #205 is ready. Forward #248 retains the accepted parent, exact reviewed tree and 54-pass evidence. Source branches remain intact. At the 09:20 UTC checkpoint, current-head hosted gates and parent Sonar dispositions remain open; main is `d02b94bc`. Exact raw evidence and five reconciled R8 documents are retained. [Completed qualification and limits](qa/continuation-qualification-20261106.md).


## [SUBPROCESS-ACCEPTED-20261106]

At 09:29:12 UTC, #246 merged normally into main as `dc53b529560453e84cf45e356a40432ff3fc6725`, after all applicable source checks including both Linux smoke legs passed. The merge tree equals the qualified source; its branch remains at `c804e4d9`. Earlier local failures remain in the evidence. Parent application promotion must recheck its merge tree against this new main. [Acceptance and preserved results](qa/continuation-qualification-20261106.md).


## [CONTINUATION-WINDOWS-20261106:product-start-build]

Frozen #247 Windows QA passed **20,331 tests, 94 skipped, 5 xfailed, 19 warnings in 2675.35s**, plus standalone/frozen/portable/installer checks. Artifact `13492805458`, source `37b77130`, contains the stored-product starting route. API/upload digest and tested/source tree identity agree. The 09:43–09:44 snapshot still has Linux packaging/smokes outstanding; original local failures and release/live/manual gates remain preserved. [Windows candidate and evidence](qa/continuation-windows-20261106.md).


## [WINPAIRS-WINDOWS-NATIVE-20261118]

PR #304 at `bb4277ae` failed the hosted Windows publication boundary: **15 failed, 61 passed, 3 skipped**; full Windows QA and packaging were not reached. The original raw failure is retained. Native information-call repair at local `1c49199e` preserves held-handle ownership/no replacement and fixes independently reproduced primary-error masking during cleanup. Twenty portable controls failed against the old implementation; the focused final result is **101 passed, 2 actual-Windows skips**. Whole Ruff and whitespace checks pass. Exact-head hosted acceptance and merge remain open; no native success or precise old Win32 error-87 cause is inferred from portable checks. [Evidence and limits](qa/winpairs-windows-native-20261118.md).


## [CURRENT302-INTEGRATION-20261118]

Fresh REST inspection found eleven new #302 commits at `121ffb0b`; six repairs match earlier #304 patch IDs, while four behavior commits repair additional ZIP/lineage/selection/budget defects. Actual merge parents preserve both that head and #304 `6cc6b6b7`. Independent review verified all forty #304-only paths remain unchanged. A copied-target chronology-cache regression was reproduced and fixed; four stale test-double failures were preserved and repaired through fixture flags only. Disjoint affected selections total **1,650 passed, 2 native Windows skips**, with separate independent controls, whole Ruff and schema checks passing. Final code/tree is local `3693ca3b` / published `34c06d9e`, tree `42327753`. Hosted exact-head acceptance and guarded merge remain pending; no PR closure or accuracy promotion follows from local checks. [Evidence and limits](qa/current302-integration-20261118.md).


## [FOUNDATION-SAVED-SCOPE-20261119]

Independent controls blocked intact #304: scoped native revision conflicts could resurrect 43 positive edges. A narrow provenance-preserving port from #316 restores global admission and finite saved-scope validation. Dedicated regressions changed from **73 failed, 7 passed** to **80 passed**; both independent date variants now pass. Initial broader commands ran zero tests because a later-only path was included; corrected broad, Qt, hosted and independent review were pending at that receipt's checkpoint. Raw failures and limits are preserved in [the repair receipt](qa/foundation-saved-scope-20261119.md). The accepted foundation merge is the continuation's starting main `fdc2696c`; this historical entry is not evidence that later continuation changes passed. No release or native qualification is claimed.


## [CONTINUATION-CONSOLIDATION-20261119]

Starting main: `fdc2696c23bdbfe7668348f25e3b336ce33039f7`. The local branch
`codex/patchtrace-completion-20261119-81e4` contains the reviewed N-way,
installer-receipt, parser, PE-cache and facts-eligibility slices through `69fa6b8b`.
Full combined run `full-batch1` ended 137/SIGKILL without a summary or JUnit
on that source; it remains incomplete. Later diagnostic and focused results are
recorded separately, and aggregate hosted acceptance remains pending. No main merge or release has been
performed by this continuation.

| Slice | Completed evidence | Local integration |
| --- | --- | --- |
| Branch census | 320 heads including main; 309 PR records; 139 retained for semantic review. | Complete disposition records at `46f37373`; no branch closure or deletion inferred. |
| N-way path failure isolation | 11 controls fail on base; 85 affected tests pass in 21.76s. Healthy pairs survive a different pair's unreadable path. | `24064cf6`. |
| Installer receipt recovery | 5 tests pass in 3.07s; exact authored installer size/digest checked without execution. | Recovery `20b54521`, root port `ef9167d2`; broader source workflow scope retained. |
| Parser bounds and SQLite identity | Initial base replay: 29 failed/4 passed. Independent classifier review: 6 failed/22 passed before correction. Corrected selection: 107 passed. Final affected suite: 432 passed/1 Windows skip in 61.86s. | Chain ends `baf95fcd`, integrated locally by `7610aeaa`. |
| SPEC-51 cache/worker integration | Final deduplicated affected suite: 840 passed/2 Windows skips in 60.27s. Independent cache peer: 16 passed in 2.15s, no remaining blocker in reviewed paths. | Source `0bc41f6b`, local integration `6bf57557`. |
| Research facts-eligibility guard | 11 red controls, then 33 focused passes in 3.52s. The caller sweep found one authored fixture missing facts metadata (106 passed/1 failed); explicit metadata correction retained its hit assertion. Final scoped/caller selection: 140 passed in 4.59s. | Source `d87af037`, local merge `69fa6b8b`. |

Cache review corrected invalid digest/proof claims, stale/failed equal-body
renewal and concurrent row-growth admission. Offscreen production lifecycle
controls verify worker parsing, owner-thread storage, no second Files-tab reader,
and stale UI clearing. OS trust still runs independently, and partial UI data
does not invent a resource-limit cause. Parser/cache Ruff passed; cache schema
regeneration produced no changes. These overlapping slice results are not a
combined pass count or native acceptance evidence.

Exact skips are Windows `msdelta.dll`, the real catalog probe and native
WinVerifyTrust. The coordinator's latest existing-main CI observation had Linux
and most Qt legs green, Windows and one Qt leg still running; PR319 at `a56ab13a`
was queued. Broad PR316/318 holds remain unchanged. These earlier-head states do
not qualify the new aggregate.

The census remains frozen at `2026-11-19T10:34:16.394Z`. Later draft PR320
(`188b4962`, broad 928-file/333-commit integration, full suite incomplete) and
documentation PR321 (`976dddfb`, atop PR319) are separately retained observations,
not additions silently folded into those counts or the local source. The later
all-state issues scan found 10 open non-PR issues and read their comments; it
does not resolve those issues. Main remains `fdc2696c` in the coordinator's latest
observation.

Forced strings-export source-substitution/OSError cleanup races, native trust,
release/manual acceptance, separate L1/L2/L3 evidence and unreviewed historical
branches remain explicit. The restored environment's completed reruns replace
interrupted attempts without inventing results for lost handles. Receipt names,
exact scopes and next commands are in [the continuation test record](consolidation/TEST_RESULTS.md);
[remaining work](consolidation/REMAINING_WORK.md) preserves the open gates.


## 2026-11-19 continuation batches 2–3: exact values and typed boundaries

Reviewed local runtime/test source `a4d6dd9becb37b6245332643683a2ef1d2bf3812` adds the BinExport2/rz-diff text repairs (414 affected passes), CSAF redirect error typing (33 passes), and CVE decimal/UTC admission with exact tenths (124 passes). Each slice preserves red controls and positive behavior; source and receipts are indexed under `docs/consolidation/`. Root review caught CVSS underflow, excess-precision rounding and caller-context dependence before accepting the numeric slice. No real case facts or accuracy claims changed.

The full attempt on earlier `69fa6b8b` ended with exit 137/SIGKILL before a pytest summary or JUnit. Its kill cause is unestablished; disk pressure and low available memory were observed separately. This is incomplete, not passed. The earlier sequential diagnostic planned all 855 tracked test files in 54 groups of at most 16 with no file exclusions; it later stopped after nine groups at disk reserve. Phase 4 below records its actual result and the new complete-manifest run. Its immutable source/test/tool fingerprint and per-group commands/results are retained; partitioned coverage must not be described as an unsplit full pass.

Whole-tree configured Ruff, pip check and schema generation passed on that frozen source; no schema drift. Its supplemental scan had 65 findings, classified in `docs/consolidation/STATIC_AUDIT.md`; later source scans are recorded separately, with no suppression or clean-scan claim. The focused archive contains 94 verified payloads (SHA-256 `babf10b732007de68adbf265416139bcaf3bd72d13f35916985080055cd5c9df`). It excludes later partition outcomes and Phase 6 receipts.

The guarded remote checkpoint `bdc929ebd3c6aaa2563c758936beb315a10eeea0` exactly preserves the earlier local `af8772bf` tree. The final candidate still needs its own hosted Linux/Windows/Qt/package/native checks before any main merge. Existing main QA/Qt success belongs only to main `fdc2696c`. No release, tag, deployment, main merge or branch deletion is claimed.


## Reviewed contextual digest rebaseline after CVE exactness repair

The first nine sequential groups on frozen runtime/test source `a4d6dd9b` collected 2,611 cases: 2,602 passed, 8 skipped and one failed golden expectation. The runner then stopped before group10 because shared disk space was below its 128 MiB reserve; 45 groups are not covered by that attempt. The original failure and all nine group receipts are preserved.

The CVE repair adds exactly one eligible plain-data constant, `ROUND_HALF_EVEN = "ROUND_HALF_EVEN"`. The existing constants-digest contract consequently changes only the contextual digest from `6db85ba584aaa95fe6cac6aee9681c2b6ec064cffe52c9c601fd461081f704cb` to `3d16cbd776c3589f98828a46ebaf420299b2f72d84f5d5bcf79b08de220c5963`. Removing only that constant from a copied current namespace reproduces the prior digest exactly; new class/function imports are excluded. Eight fresh processes across four hash seeds and two Decimal contexts produce the same new digest without changing caller state. Signals, WIL and ranking digests are unchanged.

Reviewed correction: change only the contextual golden expectation. Production hashing and all equality, mutation, stale-row and cache-invalidation assertions remain intact. Existing non-golden guards passed8/8; the complete nine-case file now passes9/9 in1.85s in a separate candidate checkout. Contextual stage identities change and prior stored pipeline algorithm maps correctly become stale until recomputed. Runtime source and the ongoing/frozen partition checkout were not modified by this fixture correction.

`docs/consolidation/evidence/algorithm-digest-review-20261119.zip` contains24 verified payloads, including the original nine-group outcomes and independent/corrected digest evidence. SHA-256: `aaf3f22a9f1b09e8423be01a1667be6afa60b436d6434fe741a0bc852d8ed80a` (84,003bytes). This does not qualify the remaining45 groups or an unsplit full suite.


## [CONTINUATION-PHASE4-HISTORY-20261119]

Original runtime `32abf9702538dc1b2027e8ae052949bbc2436c28`, tests/spec `1c2b770d2eef6266c56504b5d081e5d6d750151e`, lifecycle correction `4d7ae4af9aa6d60fee0f70025d774c3f5b468e0b`.

Recovered source `254190a0b36153d28f76782f8d5dae26e9d9a020`, integrated through `520b524b`, preserves bounded attempt-storage diagnostics without replacing original engine errors or prior trusted sets. Generic publication exceptions now say **"Attempt storage unconfirmed"** because a row may already have committed. Definite not-saved wording requires a returned ownership refusal; a result-kept claim requires confirmed publication. Lifecycle resets clear transient details. Malformed-row retention remained open at this historical checkpoint; the accepted Phase 6 repair below addresses the reproduced cause while preserving generic post-write uncertainty.

Baseline: 12 failed/8 passed in 19.07s. Recovered slice: 79 passed in 42.63s. Real SQLite post-write controls: 2 failed in 3.59s. Final affected UI/host selection: 81 passed in 37.33s; whole-tree Ruff and whitespace checks pass. Independent source review found no blocker in the recovered diagnostics, scheduler/producer boundary or persistence ownership/refusal contract. Authored offscreen controls do not qualify native comparators or atomic storage.

[History evidence](consolidation/evidence/history-diagnostic-20261119.zip): 9 verified payloads, 16,801 bytes; SHA-256 `60248a2e1bc603b6dba92451df639d22b7c58cc0d8153262a387242ae4dc5f67`.

The first `a4d6dd9b` partition stopped at disk reserve after 9/54 groups: 2,602 passed, 8 skipped and one contextual-digest pin mismatch. Golden correction `70b82275` follows review of the exact new ROUND constant; 9 digest/cache-identity tests pass in 1.85s. The original failure remains failed. [Algorithm-digest evidence](consolidation/evidence/algorithm-digest-review-20261119.zip) preserves both outcomes.

The final frozen diagnostic reached all **856 original test files through 59 terminal pytest processes** at runtime/test source `520b524b` (documentation head `3cde10ae`) with unchanged Pydantic 2.13.5. Actual pytest summaries total **23,110 passed, 139 skipped, 6 xfailed, 4 failed and 8 teardown errors**: the diagnostic **FAILED**. Both storage-reserve stops and the original group-51 SIGKILL/-9 without a summary/JUnit remain preserved. Final subpartitions completed the remaining file coverage without rewriting those outcomes. This is not an unsplit pass or qualification of the newer 859-file source and Pydantic 2.14.2.

Remote checkpoint `bdc929ebd3c6aaa2563c758936beb315a10eeea0` contains the earlier `af8772bf` tree. Draft PR #322 subsequently published the reviewed candidate as `32cc4b04cf1f5b9e69d1d0e8691db7083c7a45a7`, tree `e00ee281fa43744e892bbcf806e4b07a90c15e13`, exactly matching local `3cde10ae`. Its five hosted workflow runs were queued at the latest observation. Main remains `fdc2696c`; no main merge or release is claimed.

## Reviewed downstream contextual stage identity

Group 12 of the frozen `520b524b` diagnostic completed with 510 passed and two failures in `test_enrichment_hit_golden.py`. Both expected the contextual stage identity derived from the previous algorithm digest. Independent review restored only the prior algorithm map in an isolated process and reproduced the entire original fingerprint exactly. A separate standard-library domain-hash calculation reproduced both old and new stage identities. The other five fingerprint fields, other three stage identities, signal sets and ranking objects are unchanged; actual cold misses and warm hits agree.

The correction changes only `GOLDEN['stages']['contextual']` from `8c34cd25…` to `6e8833bd…`. All existing equality and ranking assertions remain. The combined golden/cache guard selection passed **12 tests in 1.61 seconds**. An initial command named a nonexistent test file and ran zero tests (exit 4); that failed invocation is retained separately. No production code or active frozen-candidate file changed.

[Stage identity review evidence](consolidation/evidence/contextual-stage-key-review-20261119.zip) contains nine verified payloads, including the original group 12 failures, independent proof and corrected test receipts. Archive: 15,870 bytes; SHA-256 `51af1e41cb11765d3191edbdf09c0472b4575a58d6635c4fa01b2e057a161e1e`. The frozen partition diagnostic retains its original result; this focused correction is separate evidence, not an aggregate pass.

## [CONTINUATION-PHASE5-20261119]

Acquisition source `5131bd94` was reviewed and integrated by `d7842532`: 255 affected tests and 55 integrated acquisition/lifecycle/identity tests pass. Conservative manual provenance remains explicit. Test-only follow-ups `f114eb96` and `bc485a66` fix injected OS faults surviving into fixture cleanup and a path-sensitive preview assertion; 85 tests pass under both cleanup policies with one existing optional skip, plus 30 symbol/backend checks. No production assertion or AF_UNIX acceptance was disabled.

At the Phase 5 checkpoint, groups 1–34 stopped at reserve: JUnit 15,971 tests, four failures, four errors and 86 skips. The first continuation later stopped after 35–45; subsequent tail/subpartitions reached every original file while preserving all failures and the group-51 kill. Phase 6 below records the final FAILED diagnostic and separate repairs.

Draft PR #322 is published; its initial queued workflows are a historical observation. Phase 6 below records the later publication, accepted retention/dependency changes, final diagnostic and remaining gates. [Current handoff](consolidation/HANDOFF.md).
## [CONTINUATION-PHASE6-20261119]

At the Phase 6 observation, accepted source/test was `5aebd98f362e7cc5f01a0c96878860b04835cea4`,
tree `1b4fdd985ccea86e436172ee52ad3b5ab51b8877`: 859 tracked test files, after
runtime/dependency integration `5208c758`. Evidence checkpoint `e430309a`
preserves the new archives and exact advisory report. The then-published PR #322
head `2511301f` has tree `f2366be08a4951880692b56ecbbefbe92a3611dd`, equal to
local `7093ee68`; 78 changed files, ahead 3/behind 0 against main `fdc2696c`.
That publication predates the new source. No main merge/release is recorded.

### Retention and dependency verification

Retention `74d5f4bb` / `153f6cea` replaces unsafe eviction inference with bounded,
hash-checked strict JSON/model admission and matching text/project identities.
Indeterminate records preserve originals. Explicit protected IDs are honored;
null-safe sums count NULL-ID bytes against the existing cap. Read-only history
is outside this private eviction helper. Genuine storage errors propagate and
post-write uncertainty remains truthful; publication is not atomic.

Meaningful baseline: 26 failed/6 passed. Root's NULL-ID finding and authored
BLOB/protection/NULL-cap controls failed before corrections. Final: **175 passed
in 18.92s across 10 files**, including 46 new controls, whole-tree Ruff and
whitespace pass. Independent real-SQLite NULL/BLOB replay preserves all originals
with zero eviction. Initial 32 setup failures were an authored fixture algorithm
mistake, not a production reproduction. The two UI post-write controls now
inject a real post-commit prune exception and preserve original assertions.
[Batch 6](consolidation/RECOVERY_BATCH_6.md) records wider concurrency/hostile-DB limits.

Pydantic `b28f6971` / `5208c758` changes the pin to 2.14.2/core 2.50.2. New
controls changed from 8 failed/1 passed to 9 passed. Compatibility completed in
28 bounded batches over 79 files: **2,903 passed, 1 existing strict CODEX-14 xfail**,
no skips/failures/errors. The nine new controls are included, not added again.
All 16 schema generators completed under both versions; 301 schema files and
generated CSAF table stayed byte-identical. No golden or xfail marker changed.
The earlier grouped attempt ended SIGKILL/-9 without summary/JUnit; cause remains
unestablished. [Upgrade report](consolidation/PYDANTIC_SECURITY_UPGRADE_20261119.md).

Root separately verified integrated `5208c758` on actual new versions: **254
passed across four groups**, zero failures/errors/skips, covering retention,
secondary attempts/backups, acquisition/lifecycle and Pydantic/cache/identity.
Configured Ruff and pip check pass. Original shared/frozen environments retained
2.13.5. Overlapping slices are not summed into full-suite coverage.

Both actual 15-package Linux runtime/search/rules graphs completed PyPI and OSV
audits, all four returning zero advisories. Direct API cross-checks also miss
four known upstream old-pin Pydantic findings; the qualified pin clears those
ranges. This is a coverage gap, not a clean-security result. Qt 6.12.0 remains
in seven assessed native advisory ranges; no official 6.12.1 binding wheels were
available at retrieval and 6.11.3 is not a complete fix. [Advisory audit](consolidation/DEPENDENCY_ADVISORY_AUDIT_20261119.md)
preserves exact graphs, primary findings, retrieval failures and a 26-file
manifest. A bounded source scan does not prove unreachability or a final package SBOM.

Fresh supplemental source scan: 64 findings, no normalized additions/removals
against `520b524b`. Separate tools expansion: 70 findings requiring review;
existing source classifications do not cover all 134 combined findings.
[Static record](consolidation/STATIC_AUDIT.md).

### Final frozen diagnostic and separate fixture repair

All 856 original files reached terminal results through 59 processes: 50 original
groups, eight final subpartitions and an isolated dense case. Frozen source/tests
remain `520b524b` (documentation head `3cde10ae`), old Pydantic 2.13.5, fingerprint
`9ecd20b2dd0f83047551f8a9f85e28c34a34236f65d77b74e46483eecf33a2b2`.
All 1,396 collected node IDs in the last four groups match the XML multiset exactly,
with no omissions/duplicates. All seven residual-performance cases pass split 6+1.

Actual pytest summaries: **23,110 passed, 139 skipped, 6 xfailed, 4 failed and
8 teardown errors**. JUnit: 23,259 tests, 4 failures, 8 errors, 145 skips including
xfails. Errors coexist with passing bodies; do not subtract them from pytest
passes. The diagnostic **FAILED**. Both reserve stops and the original group-51
kill without summary/JUnit remain preserved; the dense-case pass does not prove
that kill's cause. Full file coverage is not an unsplit or current-head pass.

Three new errors in subpartition 53-2 came from the verified-backup test's
`os.scandir` mock surviving into pytest cleanup. Root reproduced 3 passes/3
teardown errors on new dependencies, then scoped only mock lifetime at `5aebd98f`:
**41 passed in 2.62s across three files**. Production source and assertions stay
unchanged; original frozen errors remain errors. External AF_UNIX constructor
EPERM before product imports remains an unchanged acceptance block.
[Harness report](consolidation/TEST_HARNESS_FIXES_20261119.md).

Verified archives contain 41 retention/integrated, 82 Pydantic, 27 advisory,
132 complete-diagnostic and six backup-correction payloads plus their manifests.
[Exact archive hashes and results](consolidation/TEST_RESULTS.md) distinguish these
from the original 94-payload focused archive. The complete failed diagnostic is
599,873 bytes, SHA-256 `29a5149bbc2671db26fe260dcc9e94515cd543ac0643f0e74f29f4f0b5720653`.

At published `2511301f`, QA `44522261517`, rz `44522261469`, native PR
`44522261551`, native push `44522248460` and BinDiff `44522261617` were queued.
Scheduling cause is unestablished; earlier heads do not qualify later accepted
source. Actual final-head Linux/Windows/Qt/package/native/live checks, Qt
remediation, manual acceptance and separate L1/L2/L3 evidence remain open.
REST-only readiness and the all-jobs-green/no-blocker expected-head merge gate
remain. Strings-export recovery and build-tool HTTPS redirect triage were still
separate pending work at this checkpoint; their accepted Phase 7 scope follows.

## [CONTINUATION-PHASE7-20261119]

Accepted local source is `8efb7a4501bdcea77f6aca68f92c5459af47a838`, tree
`41bf19c6321f88134959df8122b26930ee4deaf7`, with **866 tracked test files**.
Published Phase 6 draft PR322 is `eb94510bda73935b1b5b99d00acde879d6474d14`, tree
`62665b03d9c2c7431ceaa1d181505d28105ccb93`, equal to local `0ed53876`: 93 changed
files, ahead 4/behind 0. It predates the following local-only source changes.

| Accepted scope | Verification and limits |
| --- | --- |
| Strings `397abd44` / `cf554155` | 74 focused passes and 115 integrated CLI/UI passes. Held-source no-force publication, anchor creation and forced-failure cleanup repaired; successful-force source/parent substitution remains open. Failures can retain partial/revealed stage bytes. [Batch 7](consolidation/RECOVERY_BATCH_7.md). |
| Sampler/JUnit `45828168` / `541bf83c` | 111 passes/3 existing unshare skips. Three successful observations required, partial endpoints retained through failure, XML bodies bounded to 8 MiB plus sentinel before parse. Positive OS-block controls unchanged. [Batch 8](consolidation/RECOVERY_BATCH_8.md). |
| Build-tool HTTPS `7d4aead2` | 289 passes/1 historical wheel skip; later exact wheel test passed. Per-dispatch HTTPS, manual bounded redirects, response closure, Host/credential handling and typed malformed-URL refusal. [Review](consolidation/BUILD_HTTPS_REVIEW_20261119.md). |
| KEV `c84ca5a2` / `8efb7a45` | 386 passes and 77 added semantic cases; mixed paired local measurements support the small printable-ASCII optimization. Digest behavior and strict one-second budget unchanged; no Windows-fix claim. [Report](consolidation/KEV_TEXT_VALIDATION_PERFORMANCE_20261119.md). |

At `8efb7a45`, configured whole-tree Ruff and pip check pass. All 16 schema
generator commands exit 0, leaving 301 schemas plus the generated CSAF table
byte-identical. The supplemental scan remains non-clean: **134 findings, 64 source
plus 70 tools**. All 70 baseline tools findings are classified; a guarded shared
HTTPS S310 is added and swallowed-sampler S110 removed. Independent red/green
reviews cover those changed sites. These checks do not qualify the aggregate.

The new frozen-source diagnostic collected **866 files/23,529 nodes in 210.705s**,
exit 0, and is running through 111 groups. Group 001 recorded **181 passes/70 setup
errors in 30.59s** and group 002 **65 passes/9 setup errors in 35.18s** because
the orchestrator omitted pytest's temporary parent. The parent was created at
13:42:18 UTC; original log/XML/source/runner identity and the correction receipt
remain preserved. No production test/assertion changed. Affected-group replay
is separate and pending. The earlier 856-file diagnostic remains FAILED; neither
it nor overlapping focused checks supply a full Phase 7 result.

Group 021 subsequently records **1 failed, 727 passed, 1 skipped and 4 xfailed**:
the existing ASM 200,000-character tokenization control measured best-of-five
0.156169465s against strict 0.150s. Cause and unchanged-source replay remain
under review; no threshold/assertion change or host-load explanation is claimed.
The primary run continues and retains this failed gate.

The [timestamped CI review](consolidation/CI_QUEUE_REVIEW_20261119.md) covers
13:33:41–13:37:31 UTC. Phase 6 PR322 has six queued runs/23 runner-zero substantive
jobs and no executed steps; cause unproven. PR318's Windows Qt passed, Linux Qt
shard 3/4 was cancelled without proven actor/cause, and Windows QA failed the
unchanged KEV budget at 1.4662241s on older dependencies. PR319's fresh `8d130aef`
head and native results are distinct from retained `a56ab13a` and this aggregate.
Main remains `fdc2696c` at 13:37:30 UTC; no main merge or release is recorded.

Verified strings, HTTPS, tools evidence/dispositions, KEV, final-source gates and
CI archives are linked with exact payload counts, sizes and hashes in
[TEST_RESULTS.md](consolidation/TEST_RESULTS.md). Earlier red receipts, failed
diagnostics and frozen manifests are preserved. Successful forced replacement,
seven native Qt findings, full index provenance, 139 retained semantic-review
branches, native/manual acceptance and separate L1/L2/L3 obligations remain open.

## Diagnostic continuation after reserve stop and environment recovery

The original `8efb7a45` diagnostic stopped at its storage reserve after groups 001–025 at 13:50:15 UTC; it did not reach the remaining 86 groups. Its raw pytest summaries are **4,558 passed, 79 setup errors, 13 skipped, 4 xfailed and one failed ASM timing gate**. Both setup-only groups then completed separately on the unchanged source: **251 passed in 41.52 seconds** and **74 passed in 46.80 seconds**. Selecting those two replay receipts gives 4,637 passed, 13 skipped, 4 xfailed and one failed across the first 200 files; the original errors are retained. This is partial coverage, not a passing aggregate.

A subsequent executor outage removed `/tmp`; all saved logs/XML/manifests and committed source survived. At 13:59:05 UTC the frozen `8efb7a45` worktree and lightweight interpreter were restored, with identical Python, dependency versions, source path/hash and source/test/tool fingerprint `b34db9a597ddc8c3074bea1d017ddf5702b7ed438146b55eec5e9e61a12efdc1`. Only this task's untracked Python bytecode caches were removed to recover 55,900,712 bytes. The separate continuation is running original groups 026–111 without changed assertions or exclusions. Its `continuation-manifest.json` binds the unchanged original and setup-replay manifests; no terminal continuation result is claimed here.

The original collection remains 866 files/23,529 nodes. Coverage reconciliation treats parameter text containing `::` as opaque; that corrects diagnostic bookkeeping for 48 IDs without changing pytest selection. The first 200 files account for 4,655 distinct XML cases, with no extra IDs. Original storage stop, setup errors, ASM timing failure, environment restoration and continuation keep separate identities under `verification/combined-current-20261119/`.


## 2026-11-19 — maximum-completion generations 1–8

Reviewed combined runtime/test checkpoint: `bffcfa99d6a5044024256edbc0457ab20c92cbae`.
Manifest DTD and v3 cache admission, WinPairs URL/HTTP handling, partial held-source
publication recovery, profile drafts, saved queries, paired physical windows,
accuracy cohort/confidence guards, CSV document metadata and ASM failure diagnostics
are integrated. Reports preserve unique-source proof and original failed controls
under `docs/engineering/`; independent controls accompany each recovery.

The repository-required unsplit pytest run is active in a separate clean checkout
at that checkpoint. Its actual terminal result will be recorded in
`docs/engineering/aggregate-qualification-20261119.md`; no full pass is claimed here.
Whole configured Ruff and pip check pass; 16 schema generators completed without
drift. Later CSV reader-example and peer-evidence commits leave src/tests/tools
identical. Historical focused selections overlap and must not be summed.

PR322's earlier Linux rz-diff cancellation was retried successfully; actual
Linux/Windows nonmocked fixture receipts and digest-verified artifact records
are retained. This does not qualify the new source. The original ASM 156.169465ms
failure remains recorded; production lexer and strict 150ms budget are unchanged.

Linux forced-source replacement, native Qt disposition, native Windows/trust/
clean-machine/manual gates, acquisition provenance and separate L1/L2/L3 empirical
accuracy remain open. See `docs/engineering-handoffs/README.md` and the task ledger.

## 2026-11-20 UTC — generations 9–14 qualification checkpoint

This supersedes the earlier running-state statements for the maximum-completion
candidate, while retaining their historical evidence. The required unsplit run at
`bffcfa99d6a5044024256edbc0457ab20c92cbae` ended **SIGKILL after 1,729.332 seconds**.
There is no terminal failure traceback, summary or JUnit file. Its log retains
19,877 progress markers including two failures. Cause is unestablished; no OOM
or host-load explanation is claimed. Qualification remains incomplete.

The same-source unreported remainder is separately complete: **3,849 passed and
32 existing native-toolchain skips** across 14 fresh processes and 3,881 distinct
reconciled nodes. This includes 3,879 unreported nodes and two overlaps. It does
not convert the original unsplit run into a pass. The 32 blocked cases and exact
missing LLVM/tool-install capabilities are preserved without assertion, policy,
dependency or skip changes. AF_UNIX construction independently returns EPERM
before the project's guard, including an unguarded control.

The separately reproduced GUI measurement defect is repaired: only the selected
model instance's data calls count. All original limits and product code are
unchanged. Its 186-case affected run and independent 41-case replay pass; those
counts overlap. The original aggregate table failure remains unattributed.

The acquisition follow-up now retains immutable original proposal/window and
normalized delivery metadata, approved requests, and inspected receipts. Consent
binds source claims; owner-checked sidecar/row persistence and journal recovery
preserve them. Root independent review passed four new controls plus 27 author
cases. Original two red controls, the first architecture failure and the peer
test's incorrect exit-code expectation remain archived. The later 1-failed/
205-passed whitelist outcome is separately documented from tool output; its raw
receipt is unavailable. Complete raw index retention, live providers and native
qualification are still separate.

Combined follow-up source `97ca0adfad5ea4e6cae0648a55529b9165a40b21` passes
**1,737 affected tests with one native Windows skip in 98.56 seconds**. Ruff,
schema drift and whitespace checks pass. This is not a full current-source suite.

Initial draft PR324's exact remote head is `3862cb5d`; its actual merge checkout
`deab5a05` has the same complete tree. At the retained 00:53–00:54 UTC snapshot,
both five-scenario native Ghidriff workflows passed, two Linux Qt shards passed,
and full Linux/Windows QA plus remaining Qt legs were running. The digest-verified
native clean fixture receipt records backend exit zero in 93.953 seconds. These
receipts apply to that initial source, not the later acquisition follow-up.

The new stacked follow-up keeps those original CI runs intact. See the current
[handoff](engineering-handoffs/generation-9-through-14-20261120.md),
[aggregate report](engineering/aggregate-qualification-20261119.md),
[task ledger](engineering/task-ledger.json) and
[release assessment](engineering/release-readiness-20261119.md). The hourly
successor is actually enabled. Main, release, Windows/manual, Qt disposition,
Linux forced-publication and separate empirical-accuracy gates remain open.

### Later hosted Linux receipt for the initial candidate

At the 01:03:45 UTC refresh, PR324's Linux QA job had completed successfully:
**23,699 passed, 51 skipped and six xfailed in 2,269.52 seconds**, with 23,756
JUnit cases and no failures/errors. Its actual checkout and source identities
remain the initial candidate documented above. Both locally marker-mapped tests
passed; all 32 exact locally skipped native-fixture cases also passed on that
hosted source. Original local results and capability limitations are retained.
The native pair-publication selection reports 108 passes/two native Windows
skips. Linux Qt shard 4/4 adds 9,660 repeated passes. Windows QA/Qt and Linux Qt
1/4 were still running; no completed failing job was observed. The refresh archive
and node reconciliation are linked by the aggregate report. These gates do not
qualify the later acquisition source in PR325.


## 2026-11-20 generation-16 offline index size and rejected-row integrity

Contract-first draft successor to PR326 at initial parent `bddc09b4`.
A standard-library reproduction of the original index method accepted
25 bytes when a stale `stat` reported four against a synthetic cap of 16;
its cached rejected-row count persisted after deleting that record. The
isolated corrected algorithm rejects the over-limit stream and resets
missing-source gaps to zero. The actual production wiring method was edited;
regressions were added to
`tests/test_kbc_winbindex_read_budget_20261120.py`, but **no actual
repository pytest, whole-tree Ruff or independent review has run in this
restricted local environment**. No existing tests/limits were weakened.
Source and donor identities, pending exact-head CI, unresolved original
aggregate SIGKILL and source-race limitations are in
[the generation-16 handoff](engineering-handoffs/generation-16-20261120.md).

### 2026-11-20 generation22 — Winbindex BASE structural loss (draft, unqualified)

Original BASE missing/nonobject metadata was accepted as an undated row. Contract/test/code changes on isolated `codex/patchtrace-base-body-gap-20261120-g22` add one unreadable-body gap instead. Eight **algorithm-mirror** controls passed in 0.05 s; nine authored repo-source pytest cases, full offscreen pytest, Ruff, schema/dependency, source-pinned hosted QA/Qt/native/package and external independent review are **not complete**. PR331's earlier four Linux and four Windows QA assertion failures are real and preserved; PR332 contains a later expectation correction whose source-specific outcome must be checked. Original local unsplit `bffcfa99` SIGKILL remains unexplained and not a pass. No target binary execution or accuracy claim.

## Generation 23: manual Winbindex import source admission (2026-11-20)

Distinct new isolated source: `codex/patchtrace-offline-import-regular-source-20261120-g23`, parent PR333 exact head `543b0a6f1dd2e2ce2b53a7790b7e32ed77dcbd8f`. A standalone POSIX subprocess executing the original `open(FIFO, 'rb')` sequence remained blocked for 0.3 seconds until deliberately terminated; the nonblocking-open/fstat primitive returned a nonregular descriptor without waiting. This demonstrates an importer liveness flaw and a scoped primitive, **not** checked-out PatchTrace execution. SPEC-31-D, three authored source regression tests, and a narrow source patch retain original acceptance thresholds. Local full pytest and Ruff **not run**: github.com DNS unavailable and Ruff absent. Exact-source hosted Linux/Windows QA, Qt, Ghidriff native, packages and independent review **pending**. Original `bffcfa99` interrupted suite and inherited PR330/331 four-hosted-failure evidence remain unchanged; no tests marked passing without receipts. No releases, main merges or target execution.


### Generation 34 — current-parent Strings CSV guard (2026-11-20)

Parent: PR342 `5f34fb57`; spec `c88588d`; tests `bc2cc75`; source
`95072a3`. Ten local **source-equivalent** Python stdlib CSV controls passed;
repository-source regression tests, full offscreen pytest and whole-tree Ruff
were not run due GitHub and pip index DNS failure in this environment.
Parent's old Windows QA/Qt jobs were cancelled on new publication, not
successful; current parent head requires fresh CI and this later source has
no hosted acceptance. Fresh independent review is pending. Prior source,
logs and unresolved forced-export/native/accuracy gates remain intact.


### 2026-11-20 generation 35 — Strings CSV fixture literal-escape review

A fresh reviewer found generation34's ten-case test parameter table encoded intended `\\n`, `\\t` and `\\ufeff` control/BOM values with **doubled source backslashes**. The resulting Python values are literal backslash-letter text; five expectations contradict the production helper. A Python 3.13.5 stdlib algorithm replay failed five of ten original cases. New isolated g35 source uses actual Python escaped control characters, includes CR/vertical-tab and literal-backslash negative controls, and passed thirteen source-equivalent CSV writer/reader checks. Real `tests/test_strings_export.py`, full offscreen pytest, Ruff and desktop/Qt/native jobs were not run; they remain mandatory. Details: `docs/engineering/evidence/generation35/csv-fixture-controls.json`, handoff generation35. No previous failure changed status.


### 2026-11-20 — generation 36 CSV cross-column tests

On the isolated g36 successor, two authored `test_csv_formula_guard_covers_aggregated_source_columns` cases exercise source-derived cues, reasons, functions and lineage groups through CSV reader round-trip and unchanged JSON controls. Source-equivalent Python 3.13.5 local checks passed 2/2, but actual checked-out-source pytest/full offscreen pytest, whole-tree Ruff and external independent reviewer signoff are **not run**; Github DNS and Ruff availability are limiting in this execution environment. Parent PR342 Linux full QA passed 23,900/52 skips/six xfails with Ruff pass and 5 native Windows Ghidriff scenarios succeeded. Original raw-cache failure and local SIGKILL remain unresolved; predecessor successes are not a g36 acceptance result. [Detailed review](engineering/generation36-csv-crosscolumn-review-20261120.md).


### PR342 native Windows Qt five-repeat result (2026-11-20)

Latest completed [QA workflow 44781838172](https://github.com/djshellshoxxx/PatchTrace/actions/runs/44781838172) failed because the Windows native Qt five-repeat shard [job 136446431330](https://github.com/djshellshoxxx/PatchTrace/actions/runs/44781838172/job/136446431330) recorded two `test_real_offline_dialog_journey_creates_and_opens_only_new_project` timeouts (CVE and KB variants), **10,423 passes**, elapsed 3,123.06 seconds. `settled()` waited its original 10,000 ms for `_pending` to clear; no original worker-state evidence exists. Linux/Windows QA and four Linux Qt shards in the same run were successful, but overall workflow **failed**. This is distinct from the older unqualified full local SIGKILL and native raw-cache Java probe failure. Generation38 isolated test-only diagnostics preserve the timeout and add safely bounded operation/worker state. No source-specific native g38 rerun or accepted root cause yet. See [generation38](engineering-handoffs/generation-38-20261120.md).


### 2026-11-20 generation 40 — source-plan malformed lead shape

Isolated spec/test/code repair on g39. Reproduction of the original standalone
lead-normalization algorithm: None/int caused AttributeError; bytes and an
object with a custom `strip` could supply non-plain text; a str subclass could
override `strip`. The revised exact-str guard produced five typed refusals,
and accepted one ordinary padded-text control in bounded Python 3.13.5
source-equivalent checks. The six authored repository regression cases and
whole-tree Ruff/full offscreen suite were not run in this inaccessible
checkout; no independent review was recorded. Native Windows Qt PR343 run
44810716926 was active. Preserve its actual results, do not credit predecessor
checks or close original blocker receipts.


### Sibling PR345/PR346 reconciliation (2026-11-20)

- Read current draft PR345 and PR346 heads before selecting recovery. Existing hosted QA/native runs on both were queued (PR345 44840721370/44840721268; PR346 44841261805/44841261831); no duplicate dispatch.
- Contract-first and exact donor-blob selective recovery: candidate request validation before snapshot IO/service; branch-inventory bounded large TSV replay. Added PR346-owned tests and two distinct Qt diagnostic tests, plus two CSV form-feed controls, retaining PR345's Linux forced-export refusal.
- Actual combined-source whole-tree Ruff, full offscreen pytest, Windows package/native/Qt and independent post-integration review are **pending**. Historical SIGKILL attempts lacked final summaries and remain failures/incomplete; no cause attribution.
- Keep the original 5cc Java-unverified result, PR342 Windows Qt strict failures, ASM strict timing failure and all native/manual, provenance and L1/L2/L3 acceptance gates in separate rows/receipts.


## 2026-11-20 — isolated branch snapshot exact-tip validation and PR345 Windows packaging failure

Isolated branch `codex/patchtrace-inventory-tip-oid-20261120` requires canonical lowercase 40/64-hex commit IDs in retained TSV tips and refuses different resolved commit identities. Seven repository regressions authored; only offline synthetic Git controls ran (six early rejects, one direct SHA success, one tag peeling reject). No complete source checkout pytest/Ruff/independent review or successor CI has passed.

PR345 Windows QA [run 44840721370](https://github.com/djshellshoxxx/PatchTrace/actions/runs/44840721370), job `136648122555`, **failed** during NSIS v3.13 Chocolatey install: `community.chocolatey.org/api/v2` returned HTTP 503. The same job logged 23,847 pytest passes, 181 skips, 5 xfails; that successful test stage does not change the job's failed conclusion. This establishes a dependency-feed failure, not a product-code cause, and should not prompt blanket retries or gate changes without evidence.


## CODEX-14 Linux frozen CLI smoke — isolated successor, 2026-11-21

The extracted, checksum-verified Linux onedir archive now has a workflow
candidate that calls the **complete** `tools/frozen_smoke.py` harness on both
Ubuntu 22.04 and 24.04, retaining prior offscreen and xcb self-tests. The host
fixture tool comes from the exact checked-out Actions source, with the checkout
done before artifact download so cleaning cannot erase the archive. The
existing static CODEX-14 strict xfail was replaced by a positive source
contract plus a Qt-mode preservation test. Thirteen author-side checks
inspecting the connector-fetched source passed, but local repository pytest,
whole-tree Ruff, frozen execution, hosted full/Qt/native/package and
independent review are **not** yet verified. Prior local scratch paths are
absent and shell DNS cannot resolve GitHub. Source, test and contract:
`docs/engineering/codex14-linux-frozen-cli-smoke-20261121.md`.
Do not clear CODEX-1/5/6, Windows/manual/trust or L1/L2/L3 gates.

CODEX-14 author-only negative controls: all seven in-memory workflow mutations
were refused by a source-bound static contract; see
`docs/engineering/evidence/codex14-linux-smoke-static-review-20261121.json`.
The existing `tools/frozen_smoke.py` runtime is unchanged (docstring clarified).
No Linux frozen execution or independent peer pass has been recorded.

## 2026-11-21 — isolated CODEX-6 archive-cache repair; source-specific qualification pending

The Tier R shard workflow formerly cached extracted rizin/Ghidra directories
and allowed a hit to bypass archive digest verification. On branch
`codex/patchtrace-corpus-archive-integrity-20261121` the norm is to cache
only original pinned archives and verify SHA-256 before a clean extraction
on every hit and miss. The retained final author receipt records 14 negative
JS mutations and 14 connector-fetched structural checks. The earlier ten-case
label was a summary error; the original Git version remains retained. Four synthetic shell
archive/digest controls passed (rizin/Ghidra valid/corrupt); no actual native
archive, engine, target binary or full repository source was executed.
The retained CODEX-6 strict xfail becomes a positive source regression only
on this successor. Missing checks: source-bound pytest/Ruff/pip check,
independent review, rizin-only and Ghidriff-enabled hosted Tier R (including
cache-hit behavior), complete QA/Qt/native/package and merge guard.
The original PR #345 Windows Chocolatey NSIS 503 remains historical;
its single failed-job retry is now successful on that ancestor, not this
source. Parent PR #348 Windows full pytest still in progress on inspection.
Other CODEX-1/5, CODEX-14, manual/raw-provenance/accuracy gates remain open.
See `docs/engineering/codex6-corpus-cache-archive-20261121.md`.

## Cycle3 combined source qualification — 21 November 2026 UTC

On clean source e5a531668ef523cd6faa26d5fec59aa552749134 (tree e622ff8f5624ce73bac63c0976af01c614ce05bb), the14-file normal-conftest offscreen selection completed458 passed/11 skipped/2 xfailed. All11 skips were missing declared site-build Pillow/segno dependencies. Installed pinned requirements and replayed exactly those11 identities:11 passed, zero skips/failures.469 distinct affected cases now pass; CODEX-1/5 remain expected failures. WholeRuff, pip check and exact source binding pass. Source-specific full hosted and both actual frozen Linux jobs are pending. [Current qualification](engineering/cycle3-consolidation-20261121-95fe.md).

Preserved original cache test1 failure/29 passes/2 xfail and2Ruff I001, Linux unused-import F401, Pages missing-condition red control, reviewer initial control failure, PR345NSISHTTP503 and historical SIGKILLs. None was overwritten or inferred successful. CODEX-6/14 and Pages changes received independent source reviews; a P3 report-count inconsistency was corrected against the final14/14 author receipt. Application src tree is unchanged from hosted-qualified PR #348; this does not transfer hosted qualification to the changed workflows.

## Parallel 837fe — storage interruptions and Search help (2026-11-21 UTC)

Final reviewed code `b880c317` passes **450 affected tests**, Ruff, dependency, whitespace and source-binding checks. Fresh independent reviews closed Search S-H1 and service SVC-R1/R2; backup cleanup also passed independent controls. Original failures remain in the evidence archive. The earlier-source full local run `b51b1761` ended SIGKILL after 1,417.602 s at 83%, without a terminal summary/JUnit. Its one failed AF_UNIX case is reproduced by isolated stdlib Python and on final source; the execution environment denies socket creation. The kill cause remains unestablished. No limits, skips or assertions changed. Exact-final-source hosted Windows/Linux, Qt/native/package gates remain pending. See [reviewed report](engineering/cycle837fe-recovery-and-search-20261121.md).

## Combined PR349 qualification — 837FE, 2026-11-21 UTC

Clean combined source `2a67980cfeb88ad72bf8ad523d2bafc8426e5b7c` passed **1,296 cases with one CODEX-5 expected failure**, zero failures/errors/ordinary skips, and 1,297 distinct identities. Whole-tree Ruff, dependencies and isolated source binding passed. All storage/Search, CODEX-1 and Intel source reviews are complete. Original PR349 Linux full QA failed only its missing Pages spec citation (1 failed/24,066 passed/53 skipped/4 xfailed); the unchanged registry selection passes 108 after registering all 3 new specs. Native Windows FLOSS exit1 remains unresolved; bounded actual probe diagnostics are now retained. Prior full local AF_UNIX failure and unexplained SIGKILL remain unsuccessful evidence. Final combined hosted full/Qt/native/package/frozen checks are required. [Report](engineering/cycle837fe-combined-pr349-20261121.md).
