"""Replay authored installer-manifest fixtures; never invoke the packaging entry point."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time
import xml.etree.ElementTree as ET


ROOT = Path(__file__).resolve().parent
PYTHON = ROOT.parents[1] / "pages-config-hold-venv/bin/python"


def main() -> None:
    replay = ROOT / "original-on-current-source"
    copies = {
        "tests/test_windows_installer_manifest.py": ROOT / "donor/tests/test_windows_installer_manifest.py",
        "tools/package_windows_installer.py": ROOT / "current/tools/package_windows_installer.py",
        "installer/PatchTrace.nsi": ROOT / "current/installer/PatchTrace.nsi",
    }
    for relative, source in copies.items():
        destination = replay / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, destination)
        assert source.read_bytes() == destination.read_bytes()
    groups = {"original-on-donor": ROOT / "donor",
              "original-on-current": replay, "maintained-current": ROOT / "current"}
    (ROOT / "temporary-test-data").mkdir(exist_ok=True)
    bindings = {}
    results = []
    for label, source in groups.items():
        test = source / "tests/test_windows_installer_manifest.py"
        helper = source / "tools/package_windows_installer.py"
        binding_code = '''import hashlib, json, pathlib, runpy, sys
test = pathlib.Path(sys.argv[1]).resolve()
source = test.parents[1]
namespace = runpy.run_path(str(test))
helper = pathlib.Path(namespace["HELPERS"]["write_uninstall_manifest"].__code__.co_filename).resolve()
assert namespace["ROOT"] == source
assert helper == source / "tools/package_windows_installer.py"
assert namespace["HELPERS"]["__name__"] == "<run_path>"
print(json.dumps({"executable": sys.executable, "isolated": sys.flags.isolated,
                  "dont_write_bytecode": sys.dont_write_bytecode, "test_root": str(source),
                  "test_file": str(test), "test_sha256": hashlib.sha256(test.read_bytes()).hexdigest(),
                  "helper_file": str(helper), "helper_sha256": hashlib.sha256(helper.read_bytes()).hexdigest(),
                  "packaging_main_called": False}, indent=2))
'''
        binding = subprocess.check_output([str(PYTHON), "-I", "-B", "-c", binding_code, str(test)],
                                          text=True, cwd=ROOT)
        bindings[label] = json.loads(binding)
        assert bindings[label]["helper_sha256"] == hashlib.sha256(helper.read_bytes()).hexdigest()
        command = [str(PYTHON), "-I", "-B", "-m", "pytest", "-q", "-rA",
                   "--noconftest", "--disable-plugin-autoload", "--import-mode=importlib",
                   "-c", "/dev/null", "--rootdir", str(ROOT),
                   "-o", f"cache_dir={ROOT / 'pytest-cache' / label}",
                   f"--basetemp={ROOT / 'temporary-test-data' / label}",
                   f"--junitxml={ROOT / (label + '.xml')}", str(test)]
        started = time.monotonic()
        process = subprocess.run(command, cwd=ROOT,
                                 env=dict(os.environ, PYTHONDONTWRITEBYTECODE="1", PYTEST_DISABLE_PLUGIN_AUTOLOAD="1"),
                                 capture_output=True, text=True)
        seconds = time.monotonic() - started
        (ROOT / f"{label}.stdout.txt").write_text(process.stdout)
        (ROOT / f"{label}.stderr.txt").write_text(process.stderr)
        cases = []
        for case in ET.parse(ROOT / f"{label}.xml").getroot().iter("testcase"):
            status = "failed" if case.find("failure") is not None else (
                "error" if case.find("error") is not None else (
                    "skipped" if case.find("skipped") is not None else "passed"))
            cases.append({"name": case.get("name"), "status": status})
        record = {"label": label, "command": command, "cwd": str(ROOT), "exit_code": process.returncode,
                  "process_seconds": seconds, "binding": bindings[label], "cases": cases,
                  "counts": {s: sum(c["status"] == s for c in cases) for s in ("passed", "failed", "error", "skipped")}}
        (ROOT / f"{label}.receipt.json").write_text(json.dumps(record, indent=2) + "\n")
        results.append(record)
        print(json.dumps({k: record[k] for k in ("label", "exit_code", "counts", "process_seconds")}))
    (ROOT / "test-source-binding.json").write_text(json.dumps(bindings, indent=2) + "\n")
    summary = {"counts_overlap": True, "results": [{k: result[k] for k in ("label", "exit_code", "counts")} for result in results],
               "scope": "Pure authored temporary-file manifest generation and source assertions only. No NSIS, PowerShell, packaging entry point, installed application or native binary was invoked.",
               "installs": False}
    (ROOT / "test-summary.json").write_text(json.dumps(summary, indent=2) + "\n")
    assert all(record["exit_code"] == 0 for record in results), "Preserve original failures and report them."


if __name__ == "__main__":
    main()
