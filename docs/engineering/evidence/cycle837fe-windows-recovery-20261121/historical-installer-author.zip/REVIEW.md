# Historical Windows installer branch: complete disposition

## Result

**SUPERSEDED.** No missing compatible implementation was found in the complete branch `codex/windows-setup-installer-20261017`. Its installer/data-retention behavior, workflow integration and original tests are already present in the frozen comparison source. The original branch's destructive QA truncation and retired Inno implementation are preserved as history and must not be restored.

| Identity | Exact value |
| --- | --- |
| Freshly verified branch head | `9c5fe67bd10a5d1342440bb8ea6a524cca3ce1f2` |
| Comparison head | `2ae1bbad2ad9cc78c29541872381750e347c670e` |
| Comparison tree | `6001ef506c38930fd590bd827f428b997c3b2797` |
| Exact merge base | `04d57c72eced716b6c163d29f80b6cd5543c6582` |
| Complete unique history | 31 nonmerge commits plus one merge; 32 total |
| Complete net changed-path set | 13 paths |
| Transient path introduced and removed within branch | `installer/PatchTrace.iss` |

The branch belongs to the original **181 unmatched-head** bucket. This report supplies one complete named semantic disposition, without rewriting the original **181/16** census, deleting a ref or claiming that remaining historical review is complete.

## Selection and prior-review boundary

Only one branch was selected for this bounded cycle. Its value is the existing per-user installer contract: explicit uninstall manifests preserve user-created project files, HKCU registration supports removal through Windows Apps, and build/smoke definitions cover portable and installed layouts. This is separate from the previous CI/WIN1 resource and concurrency recovery.

The candidate search, original inventory and authoritative ledger/handoff/semantic reports are retained in `candidate-search.json`, `search-boundary.json` and `prior-inputs/`, with a hash manifest. Previously reviewed core/report audits, offline-bundle behavior, strings publication, Java, license, CI/WIN1, reader/representations, backup and correlation scopes were excluded. Broader candidates remain unreviewed by this cycle; this is not a claim that no further suitable branch exists.

## Complete changed-path accounting

| Path | Disposition |
| --- | --- |
| `.github/workflows/qa-windows.yml` | All four introduced Windows steps remain exactly: clean portable smoke, pinned NSIS3.13 installation, installer build and installer lifecycle smoke. Installer artifact paths/name/condition remain. Canonical Portable.zip alias and hash logic remain, with a later Setup checksum check. Current action commit pins and publication holds supersede old workflow references and behavior. |
| `docs/package-audit.md` | Byte-identical donor text. It retains both the dated Inno-era description and subsequent dated NSIS follow-up, including the original pending-qualification limits. These are historical records, not fresh acceptance evidence. |
| `docs/qa.md` | All five substantive added PR95 path-fix heading/result lines remain. Donor also replaced 744 old lines with literal tool-output truncation text. That destructive change is not a compatible contribution. Full donor, merge-base and current documents are preserved. |
| `docs/release-process.md` | NSIS, user-data retention and installer assets remain documented. Current text removes a duplicate obsolete Inno table row and strengthens verification to the existing offline release verifier and explicit publication holds. |
| `docs/windows.md` | Byte-identical donor file, including one stale Inno build paragraph. The implementation is present; the paragraph is current documentation debt. |
| `installer/PatchTrace.nsi` | Byte-identical: per-user execution, HKCU Apps registration, Start Menu application shortcut, repository-root paths and inclusion of the generated explicit uninstall manifest. |
| `tasks/claude-progress.md` | Byte-identical historical 2026-10-17 handoff, including queued CI, external-runtime/licensing and release limits. |
| `tasks/todo.md` | Every nonblank line added by the donor remains among historical checkpoints. This review does not silently update original pending states. |
| `tests/test_windows_installer_manifest.py` | The entire original file is an exact byte prefix of current tests; all four original functions are AST-identical. Current adds the LF checksum regression. |
| `third_party/notices/nsis-3.13/COPYING` | Only trailing whitespace differs. All notice text is retained; no licensing conclusion or change is inferred. |
| `tools/package_windows_installer.py` | Compiler discovery, streaming SHA-256 and explicit uninstall manifest generation are AST-identical. Main now calls the later LF-only checksum writer. The NSIS3.13 equality check, frozen-app/Qt preflights and compile contract remain. |
| `tools/test_windows_installer.ps1` | Byte-identical lifecycle definition: inside/outside user-data sentinels, HKCU registration, shortcut, notice and Qt/runtime checks. Inspected only. |
| `tools/test_windows_portable.ps1` | Byte-identical sidecar, clean Unicode/spaces extraction, notices/runtime and isolated self-test/CLI definition. Inspected only. |

`workflow-contribution-mapping.json` records actual parsed job/step mappings, not a text-search-only inference. `structural-proof.json` verifies the exact retained steps, artifact fields, added Setup hash check, byte-identical paths, test prefix and helper AST comparisons.

## Original history and failure preservation

`unique-commit-path-accounting.json` accounts for all 32 unique commits and their paths. Commit `77e797c01015778394eba6e50563314a7d0b44a8` is an empty nonmerge commit. The only intermediate path outside the final 13-path delta is `installer/PatchTrace.iss`, introduced by `104bbc905776d5c73bb015dabba900b4479768c1` and explicitly removed by `70ae6eb8ff8718cc8a149e0efb4cfa084b35f894` during the migration to NSIS. Its original source versions are retained under `transient-source/`; neither donor tip nor current source uses it.

The donor QA text preserves its reported historical failure: Windows run39012939220 could not resolve the relative LICENSE path from the installer script directory. The later donor path-anchor fixes and original four-test result are retained without treating that old report as current CI evidence. The destructive QA truncation is also preserved in the original blob and branch patch; it was not applied anywhere.

## Controlled test results and source binding

| Selection | Result | Meaning |
| --- | --- | --- |
| Original unchanged tests on original donor helper and NSIS snapshot | **4 passed** | Original pure manifest contract reproduces on the retained donor source. |
| Same original test bytes on exact2ae helper and NSIS snapshots | **4 passed** | Current source retains every original assertion. |
| Current maintained test module on exact2ae snapshots | **5 passed** | Includes the added LF checksum regression. |

These counts overlap and must not be added as independent coverage. Every selection completed on its first attempt with no failures, errors or skips. Full stdout/stderr, JUnit XML, exact commands, return codes and source hashes are retained in the corresponding receipts.

The existing `pages-config-hold-venv/bin/python` supplied pytest without an installation or editable rebinding. The tested helper files were loaded directly from verified source snapshots with `runpy`; isolated source-binding receipts assert the exact helper filename, test ROOT and SHA-256. The original-on-current directory contains unmodified original test bytes plus exact current helper/NSIS bytes. No wrapper changes test assertions.

Tests only create authored placeholder files in owned temporary directories and generate/read uninstall manifest text. `package_windows_installer.main`, NSIS, PowerShell, compiled applications and native targets were never invoked. The Windows smoke scripts were read and byte-compared only.

The seven recorded packaging/workflow/test/notice paths are also byte-identical between exact2ae and already-promoted main902 (`9023761a4066ac1c50c127ac09d0ba5f56cdc9e4`), as recorded in `primary-main-packaging-byte-binding.json`. This is a source-binding fact; previous hosted qualification remains root-owned and source-specific. The small tests create no new Windows/native acceptance claim.

## Exact stale-documentation findings for root

Line numbers below bind to the preserved exact2ae snapshots. `stale-documentation-findings.json` includes the complete original lines and source hashes.

| Path and line | Nature | Appropriate reconciliation |
| --- | --- | --- |
| `docs/windows.md`, line27 | **Undated current build guidance.** It says Windows CI compiles `installer/PatchTrace.iss` with Inno Setup. | Correct current instructions to NSIS3.13 and `installer/PatchTrace.nsi`, reflecting the existing helper/workflow. |
| `docs/package-audit.md`, line32 | **Explicitly dated historical finding**, under “Per-user Windows installer follow-up (2026-10-17)”; followed by a dated NSIS follow-up. | Preserve both entries and their original pending qualification state. Add a clearly dated clarification rather than rewriting history. |
| `tasks/todo.md`, line1165 | **Explicitly dated historical checkpoint**, under “Windows per-user installer delivery (2026-10-17)”. | Preserve the checked Inno-era item; state current implementation in a later checkpoint. |

Current `docs/release-process.md` already names NSIS3.13 and has removed the duplicate Inno table row. The actual helper specifies `NSIS_VERSION = "3.13"`, checks the compiler's reported version and compiles `installer/PatchTrace.nsi`; the workflow installs that pinned NSIS version. No documentation was edited during this review.

## Portable evidence and remaining limits

All **41** merge-base/donor/current/transient source snapshots are Git-blob/SHA-256 verified. A non-thin pack preserves **135** introduced original Git objects with strict index/pack verification. The pack is incremental relative to the recorded merge base; the complete changed-path snapshots and original tests are independently portable. The ZIP manifest verifies every included payload and CRC; transient pytest caches/test data are excluded from the portable payload.

This is a complete branch disposition within the named scope, not a full product, dependency, licensing, release, installer lifecycle or native compatibility acceptance. Current manual GUI, accessibility, trust/signing, external-runtime/provenance and other open gates remain separate. No application/workflow/ledger/ref/PR/CI mutation, install, full-suite run or native/untrusted-target execution occurred. Root owns any final record or documentation reconciliation.
