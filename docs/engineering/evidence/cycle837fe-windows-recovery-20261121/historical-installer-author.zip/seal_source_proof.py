"""Verify the complete installer branch delta and preserve original Git objects."""
from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import subprocess


ROOT = Path(__file__).resolve().parent
REPO = ROOT.parents[1] / "PatchTrace-codex5-followup"


def git(*args: str) -> bytes:
    return subprocess.check_output(["git", "-C", str(REPO), *args])


def save(name: str, value: object) -> None:
    (ROOT / name).write_text(json.dumps(value, indent=2) + "\n")


def main() -> None:
    identity = json.loads((ROOT / "identity.json").read_text())
    head, current = identity["head"], identity["comparison_head"]
    base = identity["merge_bases"][0]
    assert git("merge-base", "--all", current, head).decode().splitlines() == identity["merge_bases"]
    assert git("rev-list", "--reverse", f"{current}..{head}").decode().splitlines() == identity["unique_commits"]
    assert git("diff", "--name-only", base, head).decode().splitlines() == identity["changed_paths"]
    records = json.loads((ROOT / "snapshot-manifest.json").read_text())
    for path in (ROOT / "transient-source").rglob("*.iss"):
        commit, relative = path.relative_to(ROOT / "transient-source").as_posix().split("/", 1)
        data = path.read_bytes()
        records.append({"path": str(path.relative_to(ROOT)), "source_commit": commit,
                        "git_blob": git("rev-parse", f"{commit}:{relative}").decode().strip(),
                        "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})
    for record in records:
        data = (ROOT / record["path"]).read_bytes()
        assert len(data) == record["bytes"]
        assert hashlib.sha256(data).hexdigest() == record["sha256"]
        assert hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest() == record["git_blob"]
        assert git("cat-file", "blob", record["git_blob"]) == data
    save("snapshot-verification.json", {"verified_blobs": len(records), "files": records})
    comparisons = json.loads((ROOT / "source-comparison.json").read_text())
    same = [row["path"] for row in comparisons if row["byte_identical"]]
    assert set(same) == {"docs/package-audit.md", "docs/windows.md", "installer/PatchTrace.nsi",
                         "tasks/claude-progress.md", "tools/test_windows_installer.ps1", "tools/test_windows_portable.ps1"}
    tests = "tests/test_windows_installer_manifest.py"
    assert (ROOT / "current" / tests).read_bytes().startswith((ROOT / "donor" / tests).read_bytes())
    license_path = "third_party/notices/nsis-3.13/COPYING"
    original_license = (ROOT / "donor" / license_path).read_text().splitlines()
    current_license = (ROOT / "current" / license_path).read_text().splitlines()
    assert [line.rstrip() for line in original_license] == [line.rstrip() for line in current_license]
    methods = {}
    for relative in (tests, "tools/package_windows_installer.py"):
        old = {n.name: n for n in ast.parse((ROOT / "donor" / relative).read_text()).body if isinstance(n, ast.FunctionDef)}
        new = {n.name: n for n in ast.parse((ROOT / "current" / relative).read_text()).body if isinstance(n, ast.FunctionDef)}
        methods[relative] = {name: {"present": name in new, "ast_identical": name in new and ast.dump(node) == ast.dump(new[name])}
                             for name, node in old.items()}
    mapping = json.loads((ROOT / "workflow-contribution-mapping.json").read_text())
    old_steps = {entry["step"].get("name", entry["step"].get("uses")): entry for entry in mapping["donor"]}
    new_steps = {entry["step"].get("name", entry["step"].get("uses")): entry for entry in mapping["current"]}
    retained_names = ["Extract and run portable Windows ZIP outside checkout", "Install pinned NSIS compiler",
                      "Build per-user Windows installer", "Install, launch, and uninstall the setup package"]
    for name in retained_names:
        assert old_steps[name] == new_steps[name]
    old_upload = next(entry["step"] for entry in mapping["donor"] if entry["step"].get("uses", "").startswith("actions/upload-artifact"))
    new_upload = next(entry["step"] for entry in mapping["current"] if entry["step"].get("uses", "").startswith("actions/upload-artifact"))
    assert old_upload["with"] == new_upload["with"] and old_upload["if"] == new_upload["if"]
    release_name = "Verify Windows portable hash and add canonical Portable.zip release asset"
    old_run, new_run = old_steps[release_name]["step"]["run"], new_steps[release_name]["step"]["run"]
    assert new_run.replace("sha256sum -c PatchTrace-Windows-x64-Setup.exe.sha256\n", "") == old_run
    description = "Windows x64 desktop package. Run the per-user Setup.exe installer or extract the portable ZIP before launching PatchTrace.exe."
    assert description in new_steps["Generate release notes"]["step"]["run"]
    save("structural-proof.json", {"byte_identical_paths": same, "functions": methods,
         "original_tests_are_exact_byte_prefix": True, "notice_diff_is_trailing_whitespace_only": True,
         "exact_retained_workflow_steps": retained_names, "artifact_paths_name_and_condition_retained": True,
         "artifact_action_strengthened_to_commit_pin": new_upload["uses"],
         "canonical_portable_logic_retained_with_additional_setup_hash_check": True,
         "installer_release_description_retained": True,
         "current_publication_hold_retained": new_steps[release_name]["job_if"]})
    disposition = {
        ".github/workflows/qa-windows.yml": ("RETAINED_AND_EXTENDED", "Four exact Windows steps, installer assets and canonical portable-release logic remain. Current workflow additionally pins upload action, verifies Setup checksum and honors publication holds. No old action tag or topology should be restored."),
        "docs/package-audit.md": ("BYTE_IDENTICAL_HISTORICAL_TEXT", "Exact donor file retained, including old Inno text followed by the NSIS follow-up and explicitly pending original PR95 Windows qualification. Stale wording is not missing implementation or current acceptance."),
        "docs/qa.md": ("RETAINED_FOLLOWUP_WITH_CORRUPT_TRUNCATION_REJECTED", "All five substantive added PR95 path-fix heading/result lines remain. Donor also replaced 744 old lines with tool-output truncation text; that destructive record change is not a compatible contribution. Complete original donor/base/current blobs are preserved."),
        "docs/release-process.md": ("SUPERSEDED", "Windows NSIS/data-retention/artifact contract remains. Duplicate obsolete Inno table row removed; asset instructions strengthened to the current offline release verifier and explicit publication holds."),
        "docs/windows.md": ("BYTE_IDENTICAL_WITH_LEGACY_WORDING", "Exact donor file retained. It still refers to the removed Inno .iss in one paragraph despite the NSIS instructions and implementation. This is preexisting documentation debt, not an unmerged runtime contribution."),
        "installer/PatchTrace.nsi": ("BYTE_IDENTICAL", "Per-user NSIS script, HKCU Apps registration, current-user shortcut, repository-root paths and generated explicit uninstall manifest all retained."),
        "tasks/claude-progress.md": ("BYTE_IDENTICAL_HISTORICAL_TEXT", "Exact historical branch/queued-CI/native-license/open-gate handoff retained. Its 2026-10-17 state is not a fresh qualification claim."),
        "tasks/todo.md": ("RETAINED_HISTORICAL_CHECKPOINTS", "Every nonblank line added by the donor remains. Original Inno-era and NSIS-era checklists coexist with later checkpoints; no historical pending state is rewritten here."),
        "tests/test_windows_installer_manifest.py": ("RETAINED_AND_EXTENDED", "Original full file is an exact prefix and all four functions are AST-identical. Current adds the LF checksum regression; original tests pass on both donor and exact-current helpers."),
        "third_party/notices/nsis-3.13/COPYING": ("RETAINED_WHITESPACE_NORMALIZED", "Only trailing whitespace differs; all notice text remains."),
        "tools/package_windows_installer.py": ("SUPERSEDED", "Compiler discovery, streaming hash and explicit manifest helper are AST-identical. Main uses the newer byte-written LF checksum helper; pinned NSIS 3.13, preflights, data-preserving manifest and compile contract remain."),
        "tools/test_windows_installer.ps1": ("BYTE_IDENTICAL", "Original Windows lifecycle definition retained, including inside/outside user-data sentinels, HKCU registration, notices, runtime files and shortcut checks. Inspected only, not executed."),
        "tools/test_windows_portable.ps1": ("BYTE_IDENTICAL", "Original sidecar, clean Unicode/spaces extraction, runtime/notices checks and isolated self-test/CLI definition retained. Inspected only, not executed."),
    }
    assert set(disposition) == set(identity["changed_paths"])
    save("classification.json", {"schema": "patchtrace/historical-next-review/1", **identity,
        "classification": "SUPERSEDED", "whole_branch_scope": True,
        "original_census_bucket": "unmatched-patches-review-required (original 181)",
        "paths": [{"path": path, "classification": disposition[path][0], "reason": disposition[path][1]}
                  for path in identity["changed_paths"]],
        "unique_history": {"nonmerge_commits": 31, "merge_commits": 1,
                           "empty_nonmerge_commit": "77e797c01015778394eba6e50563314a7d0b44a8",
                           "transient_path": "installer/PatchTrace.iss",
                           "transient_disposition": "Explicitly removed by donor commit70ae6eb8 when migrating to NSIS; absent at both donor tip and current. Preserved as original history, not a recovery candidate."},
        "missing_compatible_contributions": [], "native_acceptance_claimed": False,
        "original_census_rewritten": False, "delete_authorized": False,
        "source_ref_ledger_ci_or_pr_mutations": False})
    objects = git("rev-list", "--objects", "--no-object-names", head, f"^{base}").decode().splitlines()
    object_dir = ROOT / "preserved-git-objects"
    object_dir.mkdir(exist_ok=True)
    object_list = "\n".join(sorted(set(objects))) + "\n"
    (object_dir / "objects.txt").write_text(object_list)
    packed = subprocess.run(["git", "-C", str(REPO), "pack-objects", "--stdout"], input=object_list.encode(),
                            capture_output=True, check=True)
    pack = object_dir / "installer-original-introduced.pack"
    index = pack.with_suffix(".idx")
    pack.write_bytes(packed.stdout)
    indexed = subprocess.run(["git", "-C", str(REPO), "index-pack", "--strict", "-o", str(index), str(pack)],
                             capture_output=True, text=True, check=True)
    verified = subprocess.run(["git", "-C", str(REPO), "verify-pack", "-v", str(index)],
                              capture_output=True, text=True, check=True)
    (object_dir / "index-pack.stdout.txt").write_text(indexed.stdout)
    (object_dir / "index-pack.stderr.txt").write_text(indexed.stderr)
    (object_dir / "verify-pack.stdout.txt").write_text(verified.stdout)
    save("preserved-git-objects/receipt.json", {"introduced_objects": len(set(objects)),
         "pack_sha256": hashlib.sha256(packed.stdout).hexdigest(), "pack_bytes": len(packed.stdout),
         "strict_index_exit_code": indexed.returncode, "verify_pack_exit_code": verified.returncode,
         "thin": False, "limits": "Original introduced objects only. Parent history outside the branch's exact merge base is not bundled; source snapshots independently preserve the complete changed paths."})
    (ROOT / "donor-to-current.patch").write_bytes(git("diff", "--binary", head, current, "--", *identity["changed_paths"]))
    print(json.dumps({"disposition": "SUPERSEDED", "complete_paths": len(disposition),
                      "source_blobs_verified": len(records), "introduced_git_objects": len(set(objects)),
                      "comparison_tree": identity["comparison_tree"]}))


if __name__ == "__main__":
    main()
