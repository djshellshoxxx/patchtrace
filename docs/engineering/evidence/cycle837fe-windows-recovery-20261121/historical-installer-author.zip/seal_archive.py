"""Create and verify the portable review payload in this evidence directory only."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parent
ARCHIVE = "historical-next-bounded-review.zip"
MANIFEST = "evidence-manifest.json"
RECEIPT = "archive-receipt.json"
EXCLUDED_DIRS = {"pytest-cache", "temporary-test-data", "__pycache__"}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    files = []
    for path in sorted(ROOT.rglob("*")):
        relative = path.relative_to(ROOT)
        if any(part in EXCLUDED_DIRS for part in relative.parts):
            continue
        if relative.as_posix() in {ARCHIVE, MANIFEST, RECEIPT}:
            continue
        if path.is_file():
            assert not path.is_symlink(), path
            data = path.read_bytes()
            files.append({"path": relative.as_posix(), "bytes": len(data), "sha256": digest(data)})
    manifest = {"schema": "patchtrace/evidence-manifest/1", "scope": "historical-next-bounded-review",
                "comparison_head": "2ae1bbad2ad9cc78c29541872381750e347c670e",
                "comparison_tree": "6001ef506c38930fd590bd827f428b997c3b2797",
                "excluded_transient_directories": sorted(EXCLUDED_DIRS), "files": files}
    manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode()
    (ROOT / MANIFEST).write_bytes(manifest_bytes)
    with zipfile.ZipFile(ROOT / ARCHIVE, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for entry in files:
            archive.write(ROOT / entry["path"], entry["path"])
        archive.write(ROOT / MANIFEST, MANIFEST)
    with zipfile.ZipFile(ROOT / ARCHIVE) as archive:
        assert archive.testzip() is None
        expected = {entry["path"] for entry in files} | {MANIFEST}
        assert len(archive.namelist()) == len(expected)
        assert set(archive.namelist()) == expected
        assert archive.read(MANIFEST) == manifest_bytes
        for entry in files:
            data = archive.read(entry["path"])
            assert len(data) == entry["bytes"] and digest(data) == entry["sha256"], entry["path"]
    archive_bytes = (ROOT / ARCHIVE).read_bytes()
    receipt = {"archive_file": ARCHIVE, "archive_sha256": digest(archive_bytes),
               "archive_bytes": len(archive_bytes), "manifest_file": MANIFEST,
               "manifest_sha256": digest(manifest_bytes), "payload_file_count": len(files),
               "zip_member_count": len(files) + 1, "archive_crc_verified": True,
               "all_manifest_members_verified": True, "receipt_external_to_archive": True}
    (ROOT / RECEIPT).write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
