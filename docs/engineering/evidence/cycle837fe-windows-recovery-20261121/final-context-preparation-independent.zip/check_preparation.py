"""Read-only preparation audit; no source tests or actual publication planning."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

BASE = Path('/workspace/scratch/837fe19aae3a')
OUT = BASE / 'evidence/windows-recovery-records-independent/final-context-preparation'
REPO = BASE / 'PatchTrace-windows-recovery-followup'
SOURCE = 'f596471b8909ec8e28e0624041d60f03d520591d'
REMOTE = '4202e5e79e2aea6366c75261d74544ea48368ca5'
TREE = 'dffeed541749850ef54a130cec0fa56c0fd2f01c'
EVIDENCE = 'docs/engineering/evidence/cycle837fe-windows-recovery-20261121/'
OUT.mkdir(parents=True, exist_ok=True)
checks = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def verify(name, value):
    checks.append({'name': name, 'passed': bool(value)})
    assert value, name

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args]).decode().strip()

bindings = [
 ('windows-recovery-records-context.json', 'context-reviewed.json', '5db4348539da9fe9edefad59fde050b8b26bfcca6ece7c2155c6a69ee2897cac'),
 ('assemble_windows_recovery_records.py', 'helper-reviewed.py', '7f8026469f7b5251236fef89384ce4eb70b722c20ee3988e77e229109a926260'),
 ('prepare_windows_record_publication.py', 'planner-reviewed.py', '075354bd5516bf8e5750ddb72ea99907ad9b8fe72be6ab40326c25131561bac8'),
 ('evidence/windows-recovery-record-preparation/report-template.md', 'report-reviewed.md', '22705192d4895811d55b2e3417bcbeeaef8e21ce34aaef966ae4ad6cdadaf8cb'),
]
for original, target, expected in bindings:
    data = (BASE / original).read_bytes()
    verify(f'input hash {original}', sha(data) == expected)
    (OUT / target).write_bytes(data)
context = json.loads((OUT / 'context-reviewed.json').read_text())
report = (OUT / 'report-reviewed.md').read_text()
prior_path = BASE / 'evidence/windows-recovery-records-independent/combined-source-preparation/context-reviewed.json'
prior = json.loads(prior_path.read_text())
(OUT / 'prior-context-reviewed.json').write_bytes(prior_path.read_bytes())
verify('record worktree clean exact source', git('rev-parse', 'HEAD') == SOURCE and git('rev-parse', 'HEAD^{tree}') == TREE and not git('status', '--porcelain=v1'))
verify('assembly remains blocked and not release ready', context['apply_authorized_now'] is False and context['release_ready'] is False and context['main_merge_eligible'] is False and context['blockers'] == ['Actual PR351 merge and complete hosted qualification receipt pending'])
verify('context exact corrected source', context['frozen_local_source'] == SOURCE and context['frozen_local_tree'] == TREE)
inputs = context['static_evidence_inputs']
verify('exact static input count and bytes', len(inputs) == 57 and sum(e['bytes'] for e in inputs) == 24512032)
destinations = {e['destination']: e for e in inputs}
verify('unique destinations and confined relative paths', len(destinations) == len(inputs) and all(not Path(p).is_absolute() and '..' not in Path(p).parts for p in destinations))
for entry in inputs:
    data = (BASE / entry['source']).read_bytes()
    verify(f'evidence input {entry["destination"]}', len(data) == entry['bytes'] and sha(data) == entry['sha256'])
verify('all 42 previous inputs retained exactly', len(prior['static_evidence_inputs']) == 42 and all(destinations.get(e['destination']) == e for e in prior['static_evidence_inputs']))
for name in ('original_task_count', 'original_notes_count', 'preserve_existing_tasks_ids_order_and_prior_fields',
             'original_census', 'promote_after_verified_actual_merge', 'reviewed_legacy_reconciliation',
             'reviewed_document_replacements', 'independent_windows_review', 'historical_dispositions',
             'prior_windows_only_preparation'):
    verify(f'previous reviewed accounting unchanged: {name}', context[name] == prior[name])
ledger = json.loads(git('show', SOURCE + ':docs/engineering/task-ledger.json'))
verify('baseline ledger has 104 tasks and 46 notes', len(ledger['tasks']) == 104 and len(ledger['notes']) == 46)
drafts = context['additional_tasks']
verify('eight ordered unique noncolliding drafts', len(drafts) == 8 and [t['id'] for t in drafts] == context['proposed_new_task_ids'] and len({t['id'] for t in drafts}) == 8 and not ({t['id'] for t in drafts} & {t['id'] for t in ledger['tasks']}))
required = {'id','status','description','source_branch','source_commit','target_integration_branch','assigned_worker','files_owned','implementation_status','test_results','audit_findings','dependencies','blockers','merge_status','evidence_links','next_action'}
for draft in drafts:
    verify(f'complete task fields {draft["id"]}', required <= set(draft))
    verify(f'task enum {draft["id"]}', draft['status'] in {'PLANNED','IN_PROGRESS','TESTING','COMPLETE','MERGED','BLOCKED','CANCELLED'})
    for link in draft['evidence_links']:
        verify(f'task evidence resolves {draft["id"]}/{link}', link.startswith(EVIDENCE) and link[len(EVIDENCE):] in destinations)
verify('promotion task still explicitly pending', drafts[0]['merge_status'] == 'PENDING' and drafts[0]['status'] == 'TESTING' and bool(drafts[0]['blockers']))
native = next(t for t in drafts if t['id'] == '837fe-live-ghidra-original-archive-recovery')
needed = {'live-ghidra-archive-author.zip','live-ghidra-pin-repair.zip','live-ghidra-original-pin-finding.json',
          'live-ghidra-independent.zip','live-ghidra-independent-review.json','live-ghidra-corrected-source-review.json',
          'combined-source-qualification.zip','combined-source-qualification.json','native-source.bundle'}
verify('original gap closed by all corrected and original links', needed <= {p[len(EVIDENCE):] for p in native['evidence_links']} and native['source_commit'] == SOURCE and native['status'] == 'TESTING')
verify('original 181/16 census not rewritten', context['original_census'] == {'unmatched':181, 'patch_equivalent':16, 'rewrite':False})
verify('exact three future placeholders only', re.findall(r'<[A-Z][A-Z0-9_]+>', report) == ['<ACTUAL_PR351_MERGE>','<PR351_QUALIFICATION_SUMMARY>','<POST_PR351_PAGES_STATUS>'])
links = re.findall(r'\]\((evidence/cycle837fe-windows-recovery-20261121/[^)]+)\)', report)
unresolved = sorted({p.split('/',2)[-1] for p in links if p.split('/',2)[-1] not in destinations})
verify('only expected future report evidence unresolved', unresolved == ['manifest.json','pr351-final-qualification.json','pr351-merge-proof.json','pr351-qualification-evidence.zip','prior-ledger-d667.json'])
verify('publication and source claims scoped', all(s in report for s in (SOURCE, REMOTE, TREE, 'not completed native or final-record-source qualification', 'Counts overlap component suites.', 'Release readiness is false.', 'adds eight scoped tasks', 'exactly seven fields in three legacy rows')))

mapping_path = BASE / 'evidence/native-archive-corrected-git-object-verification.json'
mapping = json.loads(mapping_path.read_text())
(OUT / 'native-code-git-verification.json').write_bytes(mapping_path.read_bytes())
for item in mapping['mapping']:
    for kind in ('local', 'remote'):
        commit, parent = item[kind + '_commit'], item[kind + '_parent']
        verify(f'actual {kind} commit type {commit}', git('cat-file', '-t', commit) == 'commit')
        verify(f'actual {kind} ordered parent {commit}', git('show','-s','--format=%P',commit) == parent)
        verify(f'actual {kind} complete tree {commit}', git('rev-parse',commit+'^{tree}') == item['tree'])
verify('planner native code mapping exact', mapping['remote_head'] == REMOTE and mapping['mapping'][-1]['local_commit'] == SOURCE)
publication = json.loads((BASE / destinations['code-branch-publication.json']['source']).read_text())
(OUT / 'code-branch-publication.json').write_text(json.dumps(publication,indent=2)+'\n')
run = publication['runs']['workflow_runs'][0]
verify('retained publication observation exact source', publication['branch']['object']['sha'] == REMOTE and publication['local_source'] == SOURCE and publication['tree'] == TREE)
verify('native queue receipt not completed qualification', publication['runs']['total_count'] == 1 and run['id'] == 44901791862 and run['head_sha'] == REMOTE and run['event'] == 'push' and run['status'] == 'queued' and run['conclusion'] is None and run['path'] == '.github/workflows/live-backend.yml')
verify('code publication distinct from records or PR', context['planned_publication']['code_ref_published'] is True and context['planned_publication']['ref_moved'] is True and context['planned_publication']['records_published'] is False and context['planned_publication']['pr_number'] is None and publication['records_applied'] is False and publication['pr_created'] is False)
verify('future guarded update starts at published code', context['planned_publication']['expected_previous_branch_head'] == REMOTE)
qualification_path = BASE / destinations['combined-source-qualification.json']['source']
qualification = json.loads(qualification_path.read_text())
verify('root current qualification exact source and counts', qualification['source'] == SOURCE and qualification['tree'] == TREE and qualification['counts'] == {'cases':478,'passed':449,'skipped':27,'xfailed':2,'failed':0,'errors':0} and len(qualification['selectors']) == 14)
verify('context root qualification exact retained object', context['current_recovery_qualification']['exact_combined_selection'] == qualification)
archive_proofs = []
for dest in ('combined-source-qualification.zip','combined-source-preparation-independent.zip'):
    path = BASE / destinations[dest]['source']
    with zipfile.ZipFile(path) as archive:
        verify(f'CRC {dest}', archive.testzip() is None)
        manifest_name = next(n for n in archive.namelist() if n.lower() == 'manifest.json')
        manifest = json.loads(archive.read(manifest_name))
        entries = manifest.get('files', manifest.get('payloads'))
        verify(f'exact member set {dest}', set(archive.namelist()) == {e['path'] for e in entries} | {manifest_name})
        for entry in entries:
            data = archive.read(entry['path'])
            verify(f'archive member {dest}/{entry["path"]}', sha(data) == entry['sha256'] and len(data) == entry['bytes'] and data == (path.parent / entry['path']).read_bytes())
        archive_proofs.append({'path':str(path),'sha256':sha(path.read_bytes()),'bytes':path.stat().st_size,'members':len(archive.namelist())})
        if dest == 'combined-source-qualification.zip':
            cases = ET.fromstring(archive.read('focused.xml')).findall('.//testcase')
            ids = [(c.attrib['classname'],c.attrib['name']) for c in cases]
            counts = {'passed':0,'skipped':0,'xfailed':0,'failed':0,'errors':0}
            for case in cases:
                f,e,s=case.find('failure'),case.find('error'),case.find('skipped')
                key='failed' if f is not None else 'errors' if e is not None else ('xfailed' if s.attrib.get('type')=='pytest.xfail' else 'skipped') if s is not None else 'passed'
                counts[key]+=1
            verify('root XML counts and distinct identities', len(ids)==len(set(ids))==478 and counts=={'passed':449,'skipped':27,'xfailed':2,'failed':0,'errors':0})
            verify('root qualification not claiming full native', qualification['component_counts_additive'] is False)

verify('reviewed helper unchanged from sealed rebind review', (OUT / 'helper-reviewed.py').read_bytes() == (BASE / 'evidence/windows-recovery-records-independent/combined-source-preparation/helper-reviewed.py').read_bytes())
verify('no current record evidence directory applied', not (REPO / EVIDENCE).exists())
verify('no final publication plan executed', not (BASE / 'windows-recovery-final-publication-plan.json').exists())
verify('clean source retained after read-only audit', git('rev-parse','HEAD')==SOURCE and not git('status','--porcelain=v1'))
result={'source':SOURCE,'tree':TREE,'remote_code':REMOTE,'checks':checks,'input_bindings':bindings,
        'static_input_count':len(inputs),'static_input_bytes':sum(e['bytes'] for e in inputs),'drafts':len(drafts),
        'prospective_task_count':112,'original_tasks':104,'original_notes':46,'original_census':context['original_census'],
        'previous_inputs_exact':42,'added_inputs':15,'prior_gap_closed':True,'unresolved_report_links':unresolved,
        'archive_proofs':archive_proofs,'mapping':mapping,'publication_observation':{'observed_utc':publication['observed_utc'],'run_id':run['id'],'status':run['status'],'scope':'Retained observation only; no fresh remote check'},
        'actual_PR351_promotion_verified':False,'assembly_authorized':False,'product_tests_run':0,
        'source_ref_PR_CI_mutations':False,'preparation_verdict':'CLEAR; final promotion and assembled records remain outstanding'}
(OUT / 'context-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'inputs':len(inputs),'bytes':sum(e['bytes'] for e in inputs),'drafts':len(drafts),'status':result['preparation_verdict']}))
