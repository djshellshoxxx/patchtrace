"""Seal the bounded context/report/planner preparation review."""
from pathlib import Path
import datetime
import hashlib
import json
import shutil
import zipfile

BASE=Path('/workspace/scratch/837fe19aae3a')
OUT=BASE/'evidence/windows-recovery-records-independent/final-context-preparation'
context=json.loads((OUT/'context-checks.json').read_text())
planner=json.loads((OUT/'planner-controls.json').read_text())
sha=lambda data:hashlib.sha256(data).hexdigest()
review={
 'schema':'patchtrace/windows-recovery-final-context-preparation-review/1',
 'reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'verdict':'CLEAR FOR PREPARATION; actual PR351 promotion and final assembled records remain outstanding',
 'source':context['source'],'tree':context['tree'],'remote_code':context['remote_code'],
 'input_bindings':context['input_bindings'],
 'context_checks':len(context['checks']),
 'static_inputs':{'count':57,'bytes':24512032,'all_hashes_and_sizes_verified':True,'previous_inputs_preserved_exactly':42,'added':15},
 'closed_prior_finding':'Corrective f596 archive/candidate/proof, original pin finding, independent review and root combined qualification are all retained and linked without replacing88 evidence.',
 'ledger_preparation':{'existing_tasks':104,'notes':46,'additional_drafts':8,'prospective_tasks':112,'prior_census':[181,16],
                       'existing_promotion_scope':'Two C5/Pages rows plus the current C5 follow-up object, only after actual qualified PR351 merge.',
                       'legacy_reconciliation':'Seven fields in three rows, normalized MERGED/BLOCKED/TESTING, prior rows retained.',
                       'prior_task_history_and_document_guards':'Unchanged reviewed helper 7f802; no records applied.'},
 'root_combined_qualification':{'source':context['source'],'tree':context['tree'],'counts':{'passed':449,'skipped_no_pwsh':27,'strict_C5_xfailed':2,'cases':478},'selectors':14,'distinct_xml_cases_verified':True,'new_tests_run_by_this_review':0,'native_or_full_suite_claim':False},
 'git_provenance':{'local_and_remote_native_commit_objects_verified':True,'ordered_parent_chain_verified':True,'complete_trees_equal':True,'publication_receipt':'Retained code branch and native push run44901791862 queued observation; no fresh remote query or qualification claim.'},
 'planner':{'sha256':planner['planner_sha256'],'detached_controls':len(planner['controls']),'accepted':planner['accepted'],'refused':planner['refused'],
            'local_parents':['f596471b8909ec8e28e0624041d60f03d520591d','actual PR351 merge'],
            'remote_parents':['4202e5e79e2aea6366c75261d74544ea48368ca5','same actual PR351 merge'],
            'scope':'One explicit first-parent records delta; approved docs/evidence only; no deletions or non-file modes; both holds separately in subject and body.',
            'actual_execution':False,'actual_output_created':False,'ref_movement_authorized_by_plan':False},
 'report':{'future_placeholders':['ACTUAL_PR351_MERGE','PR351_QUALIFICATION_SUMMARY','POST_PR351_PAGES_STATUS'],
           'unresolved_generated_or_future_links':context['unresolved_report_links'],
           'count_and_source_scoping':'1c Windows,88 original native,f596 correction and root combined results remain separately identified with overlap limits.',
           'nonblocking_precision_note':'Initial reviewed report uses 12:00:58 UTC for queued discovery; linked publication receipt observed_utc is 12:01:47 UTC. Prefer retained receipt time unless earlier observation is separately retained.'},
 'still_required':['Actual PR351 qualification and fetched main-merge proof','Final context application and full104-task/46-note/history preservation audit','Final records commit and exact local/remote complete tree/ordered-parent checks','Exact final-source hosted/full/native qualification; observed cold/warm cache modes'],
 'execution':{'product_tests':0,'native_or_target_execution':False,'actual_planner_execution':False,'records_applied':False,'source_helper_context_ref_PR_CI_mutations':False},
}
(OUT/'review.json').write_text(json.dumps(review,indent=2)+'\n')
(OUT/'REVIEW.md').write_text('''# Final context preparation review

**Clear for preparation.** Actual PR351 promotion and the final assembled-record audit remain outstanding. No records were applied and the actual publication planner was not executed.

Reviewed context binds local `f596471b8909ec8e28e0624041d60f03d520591d`, tree `dffeed541749850ef54a130cec0fa56c0fd2f01c`, to equivalent published code `4202e5e79e2aea6366c75261d74544ea48368ca5`. The local and remote native commit objects, ordered parents and complete trees were checked directly. The retained publication receipt observes the code branch and one queued native push run; it does not establish completed qualification or final-record publication.

All **57 static inputs / 24,512,032 bytes** match their hashes and sizes. All 42 prior inputs remain exact. The earlier preparation gap is closed: original 88 evidence, f596 corrective author and independent evidence, the original pin finding, and the root combined 449-pass qualification are included and linked. Root XML independently yields **449 passed / 27 explicit no-PowerShell skips / 2 strict CODEX-5 expected failures**, 478 distinct cases across 14 selectors. No source tests were repeated by this review.

The preparation retains 104 baseline task IDs, 46 notes and the 181/16 historical snapshot. Eight unique complete drafts produce a prospective 112 tasks; two existing C5/Pages task promotions and the C5 follow-up object remain separate from those additions and the seven fields in three legacy rows. The previously reviewed document replacements, task/history guards and helper 7f802 bytes remain unchanged. Context still disables application, release readiness and main-merge eligibility pending actual PR351 evidence.

Planner `075354bd5516bf8e5750ddb72ea99907ad9b8fe72be6ab40326c25131561bac8` passed **31 detached in-memory controls: three valid fixtures accepted and 28 refused**. Its exact AST was exercised with all Git and file IO replaced by in-memory doubles. It maps final local parents `[f596,actual351]` to `[4202,actual351]`, emits only one first-parent records delta, confines changed paths, refuses deletions/non-file modes and requires both publication holds in subject and body. No actual final commit, plan, Git object or remote action was created.

The report keeps three explicit promotion/qualification/Pages placeholders and source-specific counts with overlap limits. One nonblocking precision note was sent: the initial report's 12:00:58 UTC queued-discovery time differs from the linked receipt's 12:01:47 UTC observation; use the retained receipt time unless the earlier observation is also preserved.

Final actual-promotion/context/application, complete task/history preservation, final commit/tree/parent mapping and exact-source hosted/native qualification still require their later reviews. Original code reviews and failures remain immutable.
''')
for p in [BASE/'evidence/combined-f596-qualification/combined-f596-qualification.zip',BASE/'evidence/windows-recovery-records-independent/combined-source-preparation/combined-source-preparation-independent.zip']:
    shutil.copy2(p,OUT/p.name)
archive=OUT/'final-context-preparation-independent.zip'
excluded={'MANIFEST.json','archive-receipt.json',archive.name}
files=[p for p in OUT.rglob('*') if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts]
manifest={'schema':'patchtrace/independent-preparation-manifest/1','source':context['source'],
          'files':[{'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(files)]}
mp=OUT/'MANIFEST.json';mp.write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in sorted(files)+[mp]:z.write(p,str(p.relative_to(OUT)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist())==len(files)+1
    assert all(z.read(str(p.relative_to(OUT)))==p.read_bytes() for p in files+[mp])
receipt={'path':str(archive),'bytes':archive.stat().st_size,'members':len(files)+1,'sha256':sha(archive.read_bytes()),'manifest_sha256':sha(mp.read_bytes()),'review_sha256':sha((OUT/'review.json').read_bytes()),'CRC_and_all_member_bytes_verified':True}
(OUT/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
