"""Detached in-memory controls for the exact planner; never execute it on a checkout."""
from pathlib import Path
import ast
import copy
import hashlib
import json
from types import SimpleNamespace

OUT = Path('/workspace/scratch/837fe19aae3a/evidence/windows-recovery-records-independent/final-context-preparation')
source = (OUT / 'planner-reviewed.py').read_text()
assert hashlib.sha256(source.encode()).hexdigest() == '075354bd5516bf8e5750ddb72ea99907ad9b8fe72be6ab40326c25131561bac8'
parsed = ast.parse(source)
detached = ast.Module(body=[node for node in parsed.body if not isinstance(node, (ast.Import, ast.ImportFrom))], type_ignores=[])
code = compile(detached, '<exact planner with IO replaced by in-memory doubles>', 'exec')
LOCAL = 'f596471b8909ec8e28e0624041d60f03d520591d'
REMOTE = '4202e5e79e2aea6366c75261d74544ea48368ca5'
CODE_TREE = 'dffeed541749850ef54a130cec0fa56c0fd2f01c'
PRIOR_TREE = '6001ef506c38930fd590bd827f428b997c3b2797'
FINAL, MERGE = 'a' * 40, 'b' * 40
EVIDENCE = 'docs/engineering/evidence/cycle837fe-windows-recovery-20261121/'
controls = []

def run_case(name, changes=None, accepted=True):
    case = {
        'dirty': '', 'head': FINAL, 'parents': [LOCAL, MERGE],
        'merge_tree': PRIOR_TREE, 'local_tree': CODE_TREE, 'remote_tree': CODE_TREE,
        'message': 'Records [no release] [no deploy]\n\nReviewed records [no release] [no deploy]',
        'promotion': {'merged': True, 'all_applicable_automated_jobs_passed': True, 'opt_outs_verified': True, 'merge_commit': MERGE},
        'entries': [('docs/engineering/task-ledger.json', '100644', 'c' * 40)],
        'plan_exists': False,
    }
    case.update(copy.deepcopy(changes or {}))
    reads, writes, calls, prints = [], [], [], []

    class MemoryPath:
        def __init__(self, text): self.text = str(text)
        def __truediv__(self, value): return MemoryPath(self.text.rstrip('/') + '/' + str(value))
        def __str__(self): return self.text
        def read_text(self):
            assert self.text.endswith('/' + EVIDENCE + 'promotion-and-recovery-context.json')
            reads.append(self.text)
            return json.dumps({'verified_pr351_promotion': case['promotion']})
        def exists(self):
            assert self.text.endswith('/windows-recovery-final-publication-plan.json')
            return case['plan_exists']
        def write_text(self, data):
            assert self.text.endswith('/windows-recovery-final-publication-plan.json')
            writes.append((self.text, json.loads(data)))

    def check_output(argv, **kwargs):
        calls.append(list(argv))
        assert argv[0] == 'git'
        args = argv[1:]
        if args == ['status', '--porcelain=v1']: result = case['dirty']
        elif args == ['rev-parse', 'HEAD']: result = case['head']
        elif args == ['show', '-s', '--format=%P', case['head']]: result = ' '.join(case['parents'])
        elif args == ['rev-parse', MERGE + '^{tree}']: result = case['merge_tree']
        elif args == ['rev-parse', LOCAL + '^{tree}']: result = case['local_tree']
        elif args == ['rev-parse', REMOTE + '^{tree}']: result = case['remote_tree']
        elif args == ['show', '-s', '--format=%B', case['head']]: result = case['message']
        elif args == ['rev-parse', 'HEAD^{tree}']: result = 'd' * 40
        elif args == ['show', '-s', '--format=%an <%ae>', case['head']]: result = 'Authored fixture <fixture@example.invalid>'
        elif args == ['show', '-s', '--format=%aI', case['head']]: result = '2026-11-21T00:00:00+00:00'
        elif len(args) == 3 and args[:2] == ['cat-file', '-s']: result = '123'
        elif args == ['diff-tree', '-r', '--no-commit-id', '--no-renames', '--raw', '-z', LOCAL, case['head']]:
            return b''.join((f':100644 {mode} {"e" * 40} {blob} M\0{path}\0').encode() for path, mode, blob in case['entries'])
        else: raise RuntimeError(('Unexpected detached IO command', args))
        assert kwargs.get('text') is True
        return result

    namespace = {'Path': MemoryPath, 'json': json, 'subprocess': SimpleNamespace(check_output=check_output), 'print': lambda value: prints.append(value)}
    error = None
    try:
        exec(code, namespace)
    except AssertionError as caught:
        error = str(caught)
    observed = error is None
    assert observed == accepted, (name, observed, error)
    if accepted:
        assert len(writes) == 1 and len(reads) == 1
        plan = writes[0][1]
        assert plan['local_parents'] == [LOCAL, MERGE] and plan['remote_parents'] == [REMOTE, MERGE]
        assert plan['ref_movement_authorized_by_plan'] is False and plan['hosted_qualification_claimed'] is False
        assert len([c for c in calls if c[1] == 'diff-tree']) == 1
        assert not any('rev-list' in c for c in calls)
        assert len(plan['entries']) == len(case['entries'])
    else:
        assert not writes
    controls.append({'name':name,'outcome':'accepted authored fixture' if observed else 'refused authored fixture',
                     'reason':error,'mock_git_calls':calls,'actual_git_calls':0,'actual_file_writes':0,
                     'synthetic_plan':writes[0][1] if writes else None})

run_case('valid single ledger delta')
run_case('valid evidence blob', {'entries':[(EVIDENCE+'receipt.json','100644','c'*40)]})
run_case('valid regular executable file mode', {'entries':[('docs/qa.md','100755','c'*40)]})
run_case('dirty checkout', {'dirty':' M docs/qa.md'}, False)
run_case('no final records commit', {'head':LOCAL}, False)
for key in ('merged','all_applicable_automated_jobs_passed','opt_outs_verified'):
    promotion={'merged':True,'all_applicable_automated_jobs_passed':True,'opt_outs_verified':True,'merge_commit':MERGE}
    promotion[key]=False
    run_case('promotion '+key+' false', {'promotion':promotion}, False)
for name, parents in [('wrong first parent',['1'*40,MERGE]),('reversed parents',[MERGE,LOCAL]),('missing merge parent',[LOCAL]),('extra parent',[LOCAL,MERGE,'f'*40])]:
    run_case(name, {'parents':parents}, False)
for key in ('merge_tree','local_tree','remote_tree'):
    run_case(key+' mismatch', {key:'f'*40}, False)
for name, message in [('holds only in subject','Records [no release] [no deploy]\n\nNo holds here'),('holds only in body','Records\n\n[no release] [no deploy]'),('missing deployment hold','Records [no release]\n\n[no release]')]:
    run_case(name, {'message':message}, False)
for path in ('src/patchtrace/backend.py','tests/test_release_gate.py','tools/release_gate.py','.github/workflows/qa-windows.yml','docs/specs/REGISTRY.md','docs/unrelated.md',EVIDENCE.rstrip('/')+'-sibling/data.json'):
    run_case('forbidden delta '+path, {'entries':[(path,'100644','c'*40)]}, False)
for name, mode, blob in [('deletion','000000','0'*40),('symlink','120000','c'*40),('submodule','160000','c'*40),('zero object','100644','0'*40)]:
    run_case(name, {'entries':[('docs/qa.md',mode,blob)]}, False)
run_case('empty delta', {'entries':[]}, False)
run_case('preexisting immutable plan', {'plan_exists':True}, False)
result={'planner_sha256':hashlib.sha256(source.encode()).hexdigest(),'controls':controls,
        'accepted':sum(c['outcome'].startswith('accepted') for c in controls),
        'refused':sum(c['outcome'].startswith('refused') for c in controls),
        'actual_planner_execution':False,'actual_git_operations':0,'actual_plan_created':False,
        'scope':'Exact planner AST, all Git/path IO replaced by bounded in-memory authored controls; actual final commit does not exist yet.',
        'verdict':'CLEAR FOR PREPARATION; actual promotion, final commit, complete tree and remote equivalent still require final audit'}
(OUT/'planner-controls.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ('planner_sha256','accepted','refused','actual_planner_execution','verdict')}))
