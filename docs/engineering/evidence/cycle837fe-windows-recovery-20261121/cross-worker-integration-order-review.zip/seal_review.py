"""Seal the bounded metadata-only integration-order review."""
from pathlib import Path
import hashlib
import json
import zipfile

OUT=Path('/workspace/scratch/837fe19aae3a/evidence/cross-worker-integration-order-review')
sha=lambda data:hashlib.sha256(data).hexdigest()
review=json.loads((OUT/'review.json').read_text())
refresh=json.loads((OUT/'final-refresh.json').read_text())
refresh_checks=[]
for item in refresh:
 initial=json.loads((OUT/'snapshots'/f'{item["key"]}.json').read_text())['data']
 current=item['data']
 if item['key'].startswith('pr-'):
  same=all(current[k]==initial[k] for k in ('body','state','draft','merged','comments','review_comments')) and current['head']['sha']==initial['head']['sha'] and current['base']['sha']==initial['base']['sha']
 else:same=current['object']['sha']==initial['object']['sha']
 assert same,item['key']
 refresh_checks.append({'key':item['key'],'observed_utc':item['observed_utc'],'head_base_body_and_holds_stable':same})
review['final_refresh']=refresh_checks
review['checked_as_of_utc']=refresh[0]['observed_utc']
review['verdict']='Metadata/path/ancestry review complete; respect all author and root holds. No independent source qualification or merge authorization.'
review['explicit_holds_by_pr']={
 '352':'Non-draft but explicitly NOT YET VERIFIED: no test/red/Ruff/independent/Linux/Windows claims; requires exact-head whole-checkout and hosted QA plus independent review. Body explicitly leaves Root837FE PR351 and KBC chain untouched.',
 '353':'Non-draft but explicitly NOT VERIFIED: no executed regression/full/Ruff or independent review; exact-head Linux/Windows/Qt/native where applicable and independent review required; keep352 and root351 independent.',
 '354':'Draft: whole-repository pytest/Ruff, exact-head Linux/Windows and independent Windows-aware review outstanding; fresh integration ownership/main reconciliation required. Isolated-source claims are separate.',
 '355':'Draft: exact-head full Linux/Windows/lint, whole-repository validation, independent review and live ownership/main reconciliation outstanding. Seven local-mirror tests are not whole-repository/native acceptance.',
 '356':'Draft stacked on exact354: qualify parent first, then retarget/reconcile to current main and verify exact final head; full hosted/concurrency/transport and independent review required; active integration-owner coordination required.',
}
(OUT/'review.json').write_text(json.dumps(review,indent=2)+'\n')
lines=['# Cross-worker integration ordering review','',
 '**Metadata, path and ancestry review only.** Fresh final snapshots at **2026-11-21 12:25:05 UTC** retain every requested head, body, base and hold. No source qualification, test execution, merge authorization or remote mutation is implied.','',
 '| PR | Exact head | Base | State | Changed paths | Main coordination issue |',
 '|---|---|---|---|---:|---|',
 '| [352](https://github.com/djshellshoxxx/patchtrace/pull/352) | `e3928ab8c8e2deee7bb01b0f857205f68a1abda2` | main `9023761a` | Open; non-draft; explicitly unverified | 5 | Shared QA/TODO records; body relies on `netutil.interruptible` |',
 '| [353](https://github.com/djshellshoxxx/patchtrace/pull/353) | `d0a4bdf439775999340ea760d96a087e032ee6dd` | main `9023761a` | Open; non-draft; explicitly unverified | 5 | Shared QA/TODO records with352 and our work |',
 '| [354](https://github.com/djshellshoxxx/patchtrace/pull/354) | `a41c7a0d594d1fe26c16da395e6f6f9b33b07eca` | main `9023761a` | Open draft | 4 | Parent of356; shared network utility |',
 '| [355](https://github.com/djshellshoxxx/patchtrace/pull/355) | `e2127864cb481026db0157082d688b8a36595e3b` | main `9023761a` | Open draft | 4 | No changed-path overlap; all qualification holds still apply |',
 '| [356](https://github.com/djshellshoxxx/patchtrace/pull/356) | `1d475d926314ae116442bfe2b7cd268ad95ea12c` | exact354 branch `a41c7a0d` | Open draft | 4 incremental | Explicitly requires354 first; then retarget/reconcile and requalify |','',
 '## Ownership and explicit merge holds','',
 'All five are under the same GitHub account, with no assignees, requested reviewers, issue/inline comments or submitted reviews in these snapshots. Account identity does not establish release of an individual worker’s ownership. Each PR body retains qualification and merge holds. Root’s assignment reserves PR351 and the published Windows/native branch through15:00 UTC. No external author was contacted.','']
for number,text in review['explicit_holds_by_pr'].items():lines.append(f'- **PR{number}:** {text}')
lines += ['', '## Ancestry and path accounting','',
 'The complete API commit chains show352–355 separately descended from main902 with5,6,6 and4 commits respectively. PR356 adds four linear commits to354, giving ten commits and six distinct changed paths relative to main902. Its four-file PR list is the incremental stack delta. None of these new commits is already in the ancestry of frozen `d667` or local `f596`. These conclusions use full parent metadata and local owned-source Git objects; no refs were fetched or moved.','',
 'PR352 and353 both change `docs/qa.md` and `tasks/todo.md`. Those are their only changed-path intersections with our `902→d667` and `902→f596` change footprints. None of their paths overlaps the eight-path `d667→f596` increment. PR354 and356 share `src/patchtrace/netutil.py` and `docs/engineering/bug-hunt/findings.json`. No other new-PR pair shares a changed path. The four existing runtime files touched by these branches have identical blobs at main902, d667 and f596.','',
 'PR352 explicitly describes use of `netutil.interruptible`. PR354/356 changes to that utility therefore create an integration-review concern despite352’s separate file paths. This is an interface-coupling inference from the bodies and path inventory, not an implementation-correctness finding.','',
 '## Integration order implications','',
 '1. Preserve the existing qualified-source process and Root837FE ownership. Main remains `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4`; PR351 remains open at `d6679abc6dfddbadce0391c8d18289f7f96338d6`, base902, synthetic `a93005c69fe6091b940d7bc9ad1f5a38542e6e71`. Published next code remains `4202e5e79e2aea6366c75261d74544ea48368ca5`, tree-equal to local f596.','',
 '2. Another main merge before351 would change its tested base/synthetic combination and the preparation helper’s explicit `[902,d667]`/tree6001 promotion guard. Do not label that different combination qualified using the old results. Reconcile ownership, source and actual evidence before any changed integration.','',
 '3. Qualify354 before356, as the author explicitly requests. After354 actually merges, reconcile356 to current main and validate the resulting exact head. Review352 with the changed network utility when the branches are integrated.','',
 '4. Reconcile the shared QA/TODO files from352,353 and our records while preserving every prior result and failure. Changed-path overlap identifies work to review; it does not prove a textual merge conflict.','',
 '5. Any main advance after351 but before the next follow-up merge also changes the integration base. Preserve the frozen checkpoints and reconcile a separate descendant; an ancestry-only merge must not discard another worker’s contribution. PR355 remains independent by changed-path inventory, with all stated gates open.','',
 'The review performed62 metadata/path/ancestry checks and a final eight-object stability refresh. It ran no product tests and made no source, ref, PR, review-comment or CI changes. GitHub mergeability metadata is not a QA result. Original PR bodies, file inventories, complete commit-parent chains, empty review lists and both refresh snapshots are preserved.','']
text='\n'.join(lines)
for old,new in [('with352','with 352'),('of356','of 356'),('requires354','requires 354'),('through15:00','through 15:00'),('show352','show 352'),('with5,6,6 and4','with 5, 6, 6 and 4'),('to354','to 354'),('despite352','despite 352'),('before351','before 351'),('before356','before 356'),('After354','After 354'),('reconcile356','reconcile 356'),('Review352','Review 352'),('from352,353','from 352, 353'),('after351','after 351'),('performed62','performed 62')]:text=text.replace(old,new)
(OUT/'REVIEW.md').write_text(text)
archive=OUT/'cross-worker-integration-order-review.zip'
exclude={'MANIFEST.json','archive-receipt.json',archive.name}
files=[p for p in OUT.rglob('*') if p.is_file() and p.name not in exclude and '__pycache__' not in p.parts]
manifest={'schema':'patchtrace/metadata-review-manifest/1','checked_as_of_utc':review['checked_as_of_utc'],'files':[{'path':str(p.relative_to(OUT)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(files)]}
mp=OUT/'MANIFEST.json';mp.write_text(json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(files)+[mp]:z.write(p,str(p.relative_to(OUT)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None and len(z.namelist())==len(files)+1
 assert all(z.read(str(p.relative_to(OUT)))==p.read_bytes() for p in files+[mp])
receipt={'archive':str(archive),'bytes':archive.stat().st_size,'members':len(files)+1,'sha256':sha(archive.read_bytes()),'manifest_sha256':sha(mp.read_bytes()),'review_sha256':sha((OUT/'review.json').read_bytes()),'CRC_and_member_bytes_verified':True}
(OUT/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
