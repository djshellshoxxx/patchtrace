"""Bounded ownership/path/ancestry review; no source execution or Git mutation."""
from pathlib import Path
import hashlib
import itertools
import json
import subprocess

BASE=Path('/workspace/scratch/837fe19aae3a')
OUT=BASE/'evidence/cross-worker-integration-order-review'
REPO=BASE/'PatchTrace-windows-recovery-followup'
MAIN='9023761a4066ac1c50c127ac09d0ba5f56cdc9e4'
OURS='d6679abc6dfddbadce0391c8d18289f7f96338d6'
NEXT='f596471b8909ec8e28e0624041d60f03d520591d'
PUBLISHED='4202e5e79e2aea6366c75261d74544ea48368ca5'
HEADS={352:'e3928ab8c8e2deee7bb01b0f857205f68a1abda2',353:'d0a4bdf439775999340ea760d96a087e032ee6dd',354:'a41c7a0d594d1fe26c16da395e6f6f9b33b07eca',355:'e2127864cb481026db0157082d688b8a36595e3b',356:'1d475d926314ae116442bfe2b7cd268ad95ea12c'}
checks=[]

def verify(name, value):
 checks.append({'name':name,'passed':bool(value)})
 assert value,name

def snapshot(name):
 return json.loads((OUT/'snapshots'/f'{name}.json').read_text())

def git(*args):
 return subprocess.check_output(['git','-C',str(REPO),*args]).decode().strip()

ours_paths=set(git('diff','--name-only',MAIN,OURS).splitlines())
next_delta=set(git('diff','--name-only',OURS,NEXT).splitlines())
next_paths=set(git('diff','--name-only',MAIN,NEXT).splitlines())
ancestors=set(git('rev-list',OURS,NEXT).splitlines())
verify('both owned sources retain main902',MAIN in ancestors and git('merge-base',MAIN,OURS)==MAIN and git('merge-base',MAIN,NEXT)==MAIN)
verify('owned sources not already in main902',OURS not in set(git('rev-list',MAIN).splitlines()) and NEXT not in set(git('rev-list',MAIN).splitlines()))
verify('main snapshot unchanged',snapshot('main')['data']['object']['sha']==MAIN)
pr351=snapshot('pr-351')['data']
verify('PR351 still frozen and open',pr351['head']['sha']==OURS and pr351['base']['sha']==MAIN and pr351['merged'] is False and pr351['state']=='open')
verify('published next code unchanged',snapshot('our-code-ref')['data']['object']['sha']==PUBLISHED and git('rev-parse',PUBLISHED+'^{tree}')==git('rev-parse',NEXT+'^{tree}'))
rows=[]
for number,head in HEADS.items():
 pr=snapshot(f'pr-{number}')['data'];files=snapshot(f'files-{number}')['data'];commits=snapshot(f'commits-{number}')['data'];reviews=snapshot(f'reviews-{number}')['data']
 expected_base=HEADS[354] if number==356 else MAIN
 verify(f'exact open head and base PR{number}',pr['head']['sha']==head and pr['base']['sha']==expected_base and pr['state']=='open' and pr['merged'] is False)
 verify(f'complete file page PR{number}',len(files)==pr['changed_files'] and len(files)<100 and len({f['filename'] for f in files})==len(files))
 verify(f'complete commit page PR{number}',len(commits)==pr['commits'] and len(commits)<100 and commits[-1]['sha']==head)
 previous=expected_base
 for commit in commits:
  verify(f'linear exact parent PR{number}/{commit["sha"]}',[p['sha'] for p in commit['parents']]==[previous])
  previous=commit['sha']
 verify(f'no new branch commit already in our source ancestry PR{number}',not ({c['sha'] for c in commits}&ancestors))
 verify(f'no submitted review or comment PR{number}',reviews==[] and pr['comments']==0 and pr['review_comments']==0)
 paths={f['filename'] for f in files}
 rows.append({'number':number,'url':pr['html_url'],'title':pr['title'],'head':head,'head_tree':commits[-1]['commit']['tree']['sha'],
              'base_ref':pr['base']['ref'],'base':expected_base,'state':pr['state'],'draft':pr['draft'],
              'head_branch':pr['head']['ref'],'github_author':pr['user']['login'],'assignees':[a['login'] for a in pr['assignees']],
              'requested_reviewers':[a['login'] for a in pr['requested_reviewers']], 'maintainer_can_modify':pr['maintainer_can_modify'],
              'mergeable_metadata':pr['mergeable'],'mergeable_state_metadata':pr['mergeable_state'],'qualification_inferred':False,
              'incremental_commit_count':len(commits),'incremental_path_count':len(paths),'paths':sorted(paths),
              'overlap_our_d667_vs_main902':sorted(paths&ours_paths),'overlap_our_f596_vs_main902':sorted(paths&next_paths),
              'overlap_our_f596_vs_d667':sorted(paths&next_delta),
              'reviews':reviews,'body':pr['body'],'snapshot_utc':snapshot(f'pr-{number}')['observed_utc'],
              'common_ancestor_with_our_sources':MAIN,'ancestry_method':'Complete API parent chain to main902 (via354 for356), plus local owned-source ancestor objects; no remote refs fetched or modified.'})
pairwise=[]
for left,right in itertools.combinations(rows,2):
 common=sorted(set(left['paths'])&set(right['paths']))
 if common:pairwise.append({'prs':[left['number'],right['number']],'shared_changed_paths':common})
verify('only expected pairwise changed-path overlaps',pairwise==[
 {'prs':[352,353],'shared_changed_paths':['docs/qa.md','tasks/todo.md']},
 {'prs':[354,356],'shared_changed_paths':['docs/engineering/bug-hunt/findings.json','src/patchtrace/netutil.py']}])
runtime=[]
for path in sorted({p for row in rows for p in row['paths'] if p.startswith('src/')}):
 blobs={ref:git('rev-parse',ref+':'+path) for ref in (MAIN,OURS,NEXT)}
 verify(f'owned runtime bytes equal existing main for {path}',len(set(blobs.values()))==1)
 runtime.append({'path':path,'blobs':blobs})
full356=sorted(set(next(r for r in rows if r['number']==354)['paths'])|set(next(r for r in rows if r['number']==356)['paths']))
verify('stacked356 complete scope includes parent',len(full356)==6)
verify('source checkout unchanged',git('rev-parse','HEAD')==NEXT and not git('status','--porcelain=v1'))
result={'scope':'Read-only metadata, ownership, path and ancestry review only','checks':checks,'prs':rows,
 'our_sources':{'main_observed':MAIN,'pr351_head':OURS,'pr351_synthetic':pr351['merge_commit_sha'],'local_next':NEXT,'published_next':PUBLISHED,
                'd667_changed_paths_from_main':sorted(ours_paths),'f596_changed_paths_from_main':sorted(next_paths),'f596_only_changes_from_d667':sorted(next_delta)},
 'pairwise_changed_path_overlap':pairwise,'existing_runtime_blob_identity':runtime,'pr356_scope_from_main':{'commits':10,'paths':full356},
 'semantic_coupling_inference':'PR352 body explicitly relies on netutil.interruptible; PR354 and stacked356 change netutil. Integrated network tests/review are needed despite different352 file paths. No implementation correctness inferred.',
 'ownership':{'parent_assignment':'Root837FE retains PR351 and published Windows/native code ownership through15:00UTC; no takeover or external message authorized.',
              'remote_observations':'All five use the same GitHub account; no assignees/requested reviewers or submitted reviews. Bodies contain merge holds, not a worker-lease release.'},
 'ordering_recommendation':['Preserve current PR351/main902 qualification and ownership; do not merge unqualified sibling PRs to advance main during this checkpoint.',
                            'After actual351 promotion, finish promotion-bound records and re-evaluate any newer main before final qualification/merge.',
                            'Qualify354 before356; then retarget/reconcile356 to actual current main and qualify the exact resulting head.',
                            'Treat352 with354/356 as an interface-coupled network integration concern; qualify combined behavior when adopted.',
                            'Reconcile352/353 docs/qa.md and tasks/todo.md with each other and our records, preserving all failures/history; path overlap alone does not prove a textual conflict.',
                            '355 has no changed-path overlap with the other four or our source delta, but its explicit independent-review and full-platform gates remain.'],
 'main_advancement_implications':['Merging another branch before351 changes the tested base/synthetic combination and invalidates the prepared exact[902,d667]/tree6001 promotion assumptions. Fresh integration qualification and reviewed records are then required.',
                                 'Advancing main after351 but before the follow-up changes the actual integration base. Do not reuse prior exact-source success or an ours merge to discard another worker contribution; preserve frozen checkpoints and reconcile a separate descendant under ownership.',
                                 'Existing GitHub mergeable/unstable metadata is not proof of QA success or merge readiness.'],
 'source_qualification':False,'product_tests':0,'source_ref_PR_CI_mutations':False}
(OUT/'review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'prs':[{'number':r['number'],'head':r['head'],'draft':r['draft'],'base':r['base'],'paths':r['incremental_path_count'],'overlap_ours':r['overlap_our_f596_vs_main902']} for r in rows],'pairwise':pairwise,'source_qualification':False}))
