# Independent review of the legacy-ledger helper extension

## Verdict

**CLEAR for preparation only.** The exact scratch helper extension implements the independently reviewed three-row/seven-field reconciliation without widening its permitted ledger changes. This review does not approve final assembled records or actual PR351 promotion.

- Helper SHA256: `3e79cb7b105939c433db86415e136365f08459e40d33e0834f5a587aae85b834`.
- Captured blocked context SHA256: `e4b6c98372367fcfb7a62ce2227bcd5cfb25a4b0bc05e71e99040caaf6bf453b`.
- Source remains `1c70cd5f8053f75c269da673a24a82f221180650`, tree `a39d650ca7fa2b41ece017ea492396722a4142d9`.
- Original ledger SHA256: `9d9ae753a9a7d36ec6e9c2b7778bd98b6c6bff006e4216c0f26e1c5620a287a7`, 104 tasks and 46 notes.

## Exact delta

The original pre-assembly checks, including the fetched actual PR351 merge-object type, full SHA, tree, ordered parents and subject/body publication holds, are AST-identical to reviewed helper d993f794.

The new path requires the original ledger digest, independent CLEAR disposition, exact three whole-row guards and all seven fields exactly once. It rejects fields or task IDs outside the allowlist. Resulting statuses must be `TESTING` for `registered-header-help`, `BLOCKED` for `historical-audit-gates-cycle2`, and `MERGED` for `buildenv-header-help-20261121-95fe`. The full original three row objects are deep-copied into the appended continuation-history checkpoint before replacements. Restoring only the allowed fields must reconstruct each original row exactly; all other tasks retain the existing unchanged-row guard.

The additional new-task check requires IDs in the exact proposed order, complementing existing uniqueness, required-field and status checks. There is no source/workflow/runtime permission added.

## Bounded controls and preservation

**24 source/preservation checks passed.** **20 detached controls ran: 2 accepted and 18 refused.** They execute the actual helper AST blocks in isolated in-memory namespaces, without importing or running the assembly helper as a module. The valid control changes precisely the three intended tasks, preserves all 104 IDs/order and 46 notes, and leaves 101 unrelated tasks identical. The three complete historical row snapshots remain unchanged when a new current nested field is independently mutated, proving separate copies.

Refused controls cover wrong ledger digest, pending review, missing/extra whole-row guards, changed before objects, wrong field-before values, duplicate/missing/unexpected fields, unknown task IDs, all three wrong status values, unrelated legacy nested/top-level changes, unrelated tasks, missing new tasks and reordered new tasks. These are data-integrity controls, not product tests or an actual merge simulation.

A real default invocation of the copied exact helper against the clean owned 1c70 checkout and saved blocked context exited 1 with `Prerequisites incomplete`. It did not use `--apply`. All seven existing record/document hashes, HEAD and clean status remained unchanged, and the future evidence directory was absent. No actual promotion was fabricated or supplied.

The captured latest context contains **35 static inputs totaling 22,190,576 bytes**; every size/SHA256 was verified. The separately retained root normalized proposal has exactly the independently approved before/after values, while original custom-status strings remain available as historical proposal values. No original author archive was rewritten.

## Remaining final review

Root must still supply the real promotion-bound context and assembled records. That review must verify actual Git/REST identity and qualification, the new history snapshots, all existing task IDs/notes/history, final report links, manifest, output scope and actual final DAG. The original d993 preparation findings/receipts and the separate document and normalized-ledger reviews remain sealed, not replaced by this extension.

Only this scratch evidence directory was written. Product tests, native execution, installations, source/helper/context/ledger/ref/PR/CI changes: **none**.
