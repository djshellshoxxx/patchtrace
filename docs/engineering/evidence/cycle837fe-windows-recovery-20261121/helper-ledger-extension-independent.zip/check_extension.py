"""Detached in-memory controls for the records-only legacy reconciliation delta."""
from __future__ import annotations

import ast
from copy import deepcopy
import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/837fe19aae3a')
OUT = ROOT / 'evidence/windows-recovery-records-independent/helper-ledger-extension'
HELPER = ROOT / 'assemble_windows_recovery_records.py'
OLD = ROOT / 'evidence/windows-recovery-records-independent/preparation/helper-d993f794-snapshot.py'
CONTEXT = ROOT / 'windows-recovery-records-context.json'
REPO = ROOT / 'PatchTrace-windows-recovery-followup'
EXPECTED_HELPER = '3e79cb7b105939c433db86415e136365f08459e40d33e0834f5a587aae85b834'
LEDGER_PATH = 'docs/engineering/task-ledger.json'
checks = []
controls = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def verify(name, condition):
    checks.append({'name': name, 'passed': bool(condition)})
    if not condition:
        (OUT / 'failed-checks.json').write_text(json.dumps(checks, indent=2) + '\n')
        raise AssertionError(name)


def check(condition, message):
    if not condition:
        raise ValueError(message)


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args],
                                   env=dict(os.environ, GIT_OPTIONAL_LOCKS='0'))


helper_raw = HELPER.read_bytes(); context_raw = CONTEXT.read_bytes()
verify('exact frozen helper hash', sha(helper_raw) == EXPECTED_HELPER)
(OUT / 'helper-3e79cb7b.py').write_bytes(helper_raw)
(OUT / 'context-observed.json').write_bytes(context_raw)
(OUT / 'helper-delta.patch').write_text(''.join(difflib.unified_diff(OLD.read_text().splitlines(True),
    helper_raw.decode().splitlines(True), fromfile='d993f794', tofile='3e79cb7b')))
tree = ast.parse(helper_raw); compile(tree, str(HELPER), 'exec')
context = json.loads(context_raw)
original_raw = git('show', '1c70cd5f8053f75c269da673a24a82f221180650:' + LEDGER_PATH)
original = json.loads(original_raw)
legacy = context['reviewed_legacy_reconciliation']
recommendation = json.loads((ROOT / 'evidence/windows-recovery-records-independent/legacy-ledger-proposal/normalized-recommendation.json').read_bytes())
verify('normalized recommendation exact before-after fields',
       [(r['task_id'], r['field'], r['before'], r['after']) for r in legacy['changes']] ==
       [(r['task_id'], r['field'], r['before'], r['after']) for r in recommendation['changes']])
verify('root retains original custom status values separately', all('original_proposed_after' in r for r in legacy['changes'] if r['field'] == 'status'))
verify('baseline ledger exact source hash', sha(original_raw) == legacy['baseline_ledger_sha256'] ==
       '9d9ae753a9a7d36ec6e9c2b7778bd98b6c6bff006e4216c0f26e1c5620a287a7')
verify('source104 tasks and46 notes', len(original['tasks']) == 104 and len(original['notes']) == 46)

constants = {}
for n in tree.body:
    if isinstance(n, ast.Assign) and isinstance(n.targets[0], ast.Name) and n.targets[0].id in ['LEGACY_FIELDS', 'LEGACY_STATES', 'FIELDS', 'PROMOTE']:
        constants[n.targets[0].id] = ast.literal_eval(n.value)
verify('exact3-row7-field allowlist', constants['LEGACY_FIELDS'] == {
    'buildenv-header-help-20261121-95fe': {'status', 'result_or_next_action'},
    'historical-audit-gates-cycle2': {'status', 'result_or_next_action'},
    'registered-header-help': {'status', 'result_or_next_action', 'parallel_scope_837fe.qualification'}})
verify('exact normalized enums', constants['LEGACY_STATES'] == {
    'buildenv-header-help-20261121-95fe': 'MERGED', 'historical-audit-gates-cycle2': 'BLOCKED', 'registered-header-help': 'TESTING'})
main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
old_tree = ast.parse(OLD.read_bytes()); old_main = next(n for n in old_tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
# No mutation/ledger construction moved before the original actual-promotion gate.
verify('all original pre-assembly/actual-Git-promotion guards unchanged',
       [ast.dump(n, include_attributes=False) for n in main.body[:41]] ==
       [ast.dump(n, include_attributes=False) for n in old_main.body[:41]])
history_node = main.body[41]
legacy_nodes = main.body[42:53]
preservation_node = main.body[73]
new_ids_node = main.body[56]
verify('extracted actual extension begins at legacy context read',
       isinstance(legacy_nodes[0], ast.Assign) and legacy_nodes[0].targets[0].id == 'legacy')
verify('extracted restoration guard is exact row loop', isinstance(preservation_node, ast.For) and
       ast.get_source_segment(helper_raw.decode(), preservation_node).startswith('for before, after in zip('))


def execute(nodes, namespace):
    exec(compile(ast.Module(body=deepcopy(nodes), type_ignores=[]), '<detached actual helper AST>', 'exec'), namespace)


def namespace(context_override=None):
    return {'context': deepcopy(context_override if context_override is not None else context),
            'original_raw': original_raw, 'original': deepcopy(original), 'ledger': deepcopy(original),
            'created': 'detached-fictional-control-only', 'deepcopy': deepcopy, 'check': check, 'sha': sha,
            'EVIDENCE': Path('docs/engineering/evidence/cycle837fe-windows-recovery-20261121'), **deepcopy(constants)}


valid_context = deepcopy(context)
valid_context['reviewed_legacy_reconciliation']['independent_review_verdict'] = 'CLEAR'
ns = namespace(valid_context)
execute([history_node] + legacy_nodes + [preservation_node], ns)
controls.append({'name': 'valid normalized seven-field update', 'result': 'accepted'})
result = ns['ledger']; changed = [(a['id'], b['status']) for a, b in zip(original['tasks'], result['tasks']) if a != b]
verify('valid exact three changed tasks and required states', dict(changed) == constants['LEGACY_STATES'])
verify('original object and histories untouched', ns['original'] == original and result['continuation_history'][:-1] == original['continuation_history'])
snapshots = result['continuation_history'][-1]['legacy_rows_before_reconciliation']
expected_snapshots = [t for t in original['tasks'] if t['id'] in constants['LEGACY_FIELDS']]
verify('complete three before objects deeply retained', snapshots == expected_snapshots and len(snapshots) == 3 and
       all(a is not b for a, b in zip(snapshots, expected_snapshots)))
verify('104 IDs/order and46notes unchanged', [t['id'] for t in result['tasks']] == [t['id'] for t in original['tasks']] and result['notes'] == original['notes'])
verify('101 other task objects unchanged', sum(a == b for a, b in zip(original['tasks'], result['tasks'])) == 101)
snapshots_before = deepcopy(snapshots)
result['tasks'][59]['parallel_scope_837fe']['completed'] = 'detached mutation'
verify('before snapshot does not alias mutated task', snapshots == snapshots_before)


def negative(name, mutate_context=None, mutate_after=None):
    case = deepcopy(valid_context)
    if mutate_context:
        mutate_context(case['reviewed_legacy_reconciliation'])
    state = namespace(case)
    try:
        execute([history_node] + legacy_nodes, state)
        if mutate_after:
            mutate_after(state)
        execute([preservation_node], state)
    except ValueError as error:
        controls.append({'name': name, 'result': 'refused', 'reason': str(error)})
    else:
        raise AssertionError('Invalid detached control accepted: ' + name)


negative('wrong baseline ledger digest', lambda r: r.update(baseline_ledger_sha256='0' * 64))
negative('independent review still pending', lambda r: r.update(independent_review_verdict='PENDING_SEALED_RECEIPT'))
negative('missing whole-row guard', lambda r: r['before_rows'].pop('registered-header-help'))
negative('additional whole-row guard', lambda r: r['before_rows'].update(unexpected={}))
negative('changed guarded row', lambda r: r['before_rows']['registered-header-help'].update(owner='changed'))
negative('wrong field-before value', lambda r: r['changes'][0].update(before='changed'))
negative('duplicate field replacement', lambda r: r['changes'].append(deepcopy(r['changes'][0])))
negative('missing field replacement', lambda r: r['changes'].pop())
negative('unexpected task ID', lambda r: r['changes'][0].update(task_id='unexpected'))
negative('unexpected field', lambda r: r['changes'][0].update(field='owner'))
negative('wrong registered-header status', lambda r: r['changes'][0].update(after='MERGED'))
negative('wrong historical-audit status', lambda r: r['changes'][3].update(after='COMPLETE'))
negative('wrong Buildenv status', lambda r: r['changes'][5].update(after='TESTING'))
negative('unrelated legacy nested field changed', mutate_after=lambda s: s['ledger']['tasks'][59]['parallel_scope_837fe'].update(completed='changed'))
negative('unrelated legacy top-level field changed', mutate_after=lambda s: s['ledger']['tasks'][71].update(owner='changed'))
negative('unrelated task changed', mutate_after=lambda s: s['ledger']['tasks'][0].update(owner='changed'))
for name, new_ids, expected in [
    ('exact proposed new task order', context['proposed_new_task_ids'], 'accepted'),
    ('missing new task', context['proposed_new_task_ids'][:-1], 'refused'),
    ('reordered new tasks', list(reversed(context['proposed_new_task_ids'])), 'refused'),
]:
    try:
        execute([new_ids_node], {'new_ids': new_ids, 'context': context, 'check': check})
        actual = 'accepted'
    except ValueError:
        actual = 'refused'
    verify('new task identity control ' + name, actual == expected)
    controls.append({'name': name, 'result': actual})

file_paths = [LEDGER_PATH, 'docs/engineering-handoffs/cycle837fe-combined-pr349-20261121.md',
              'docs/qa.md', 'tasks/todo.md', 'docs/release-process.md', 'docs/windows.md', 'docs/package-audit.md']
before_state = {'head': git('rev-parse', 'HEAD').decode().strip(), 'status': git('status', '--porcelain=v1').decode(),
                'files': {p: sha((REPO / p).read_bytes()) for p in file_paths}}
verify('real checkout exact clean1c70', before_state['head'] == '1c70cd5f8053f75c269da673a24a82f221180650' and not before_state['status'])
refusal = subprocess.run(['python', '-I', '-B', str(OUT / 'helper-3e79cb7b.py'), '--repo', str(REPO), '--context', str(OUT / 'context-observed.json')],
                         capture_output=True, text=True, env=dict(os.environ, GIT_OPTIONAL_LOCKS='0'))
(OUT / 'blocked-default-invocation.log').write_text(refusal.stdout + refusal.stderr)
verify('real default invocation refuses incomplete prerequisites', refusal.returncode == 1 and 'Prerequisites incomplete' in refusal.stderr)
after_state = {'head': git('rev-parse', 'HEAD').decode().strip(), 'status': git('status', '--porcelain=v1').decode(),
               'files': {p: sha((REPO / p).read_bytes()) for p in file_paths}}
verify('actual records/source unchanged after default invocation', before_state == after_state)
verify('future evidence directory absent', not (REPO / 'docs/engineering/evidence/cycle837fe-windows-recovery-20261121').exists())
verify('helper source unchanged during review', HELPER.read_bytes() == helper_raw)
report = {'schema': 'patchtrace/records-helper-ledger-extension-independent/1',
          'reviewed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'verdict': 'CLEAR for exact helper extension and normalized proposal; preparation only',
          'blockers': [], 'final_records_clearance': False, 'helper_sha256': sha(helper_raw), 'context_snapshot_sha256': sha(context_raw),
          'source': before_state['head'], 'checks_passed': len(checks), 'checks': checks,
          'detached_controls': controls, 'accepted': sum(c['result'] == 'accepted' for c in controls),
          'refused': sum(c['result'] == 'refused' for c in controls),
          'default_invocation': {'exit': refusal.returncode, 'reason': 'Prerequisites incomplete', 'applied': False},
          'before_after': before_state, 'product_tests_run': 0,
          'limits': ['Detached controls set independent verdict CLEAR only inside private in-memory data; no real context changed.',
                     'Actual PR351 promotion and final assembled records remain unreviewed.',
                     'Full before objects must appear in final authoritative history; this helper now writes them by deepcopy.',
                     'No source/helper/context/ledger/ref/PR/CI/environment mutation.']}
(OUT / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ['verdict', 'helper_sha256', 'context_snapshot_sha256', 'checks_passed', 'accepted', 'refused', 'default_invocation']}, indent=2))
