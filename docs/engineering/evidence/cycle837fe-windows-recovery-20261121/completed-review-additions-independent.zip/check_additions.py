"""Preparation-only immutable input/record-scope checks; no product tests."""
from pathlib import Path
import ast
import datetime
import hashlib
import json
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/837fe19aae3a')
OUT = Path(__file__).parent
PREP = ROOT / 'evidence/windows-recovery-record-preparation'
PR355 = ROOT / 'evidence/pr355-independent-review'
PRIOR = OUT.parent / 'final-context-preparation'
REPO = ROOT / 'PatchTrace-windows-recovery-followup'
CHECKS = []

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_text())

def check(name, ok):
    CHECKS.append({'check': name, 'passed': bool(ok)})
    assert ok, name

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

before_path = PREP / 'context-before-completed-readonly-reviews.json'
context_path = ROOT / 'windows-recovery-records-context.json'
report_path = PREP / 'report-template.md'
before_bytes = before_path.read_bytes()
context_bytes = context_path.read_bytes()
report_bytes = report_path.read_bytes()
before = json.loads(before_bytes)
context = json.loads(context_bytes)
allowed = {'proposed_new_task_ids', 'static_evidence_inputs', 'additional_tasks', 'historical_dispositions'}
check('exact context key set preserved', context.keys() == before.keys())
check('only four append-only context fields changed', {k for k in before if before[k] != context[k]} == allowed)
for key in allowed:
    check('complete old prefix retained: ' + key, context[key][:len(before[key])] == before[key])
check('input/task/disposition cardinalities', len(before['static_evidence_inputs']) == 61 and len(context['static_evidence_inputs']) == 67 and len(before['additional_tasks']) == 9 and len(context['additional_tasks']) == 11 and len(before['historical_dispositions']) == 5 and len(context['historical_dispositions']) == 6)
check('exact static input byte count', sum(x['bytes'] for x in context['static_evidence_inputs']) == 30649939)
check('destinations remain unique', len({x['destination'] for x in context['static_evidence_inputs']}) == 67)
for row in context['static_evidence_inputs']:
    data = (ROOT / row['source']).read_bytes()
    check('exact input bytes/hash: ' + row['destination'], len(data) == row['bytes'] and sha(data) == row['sha256'])
check('original ledger/history/census guards retained', context['original_task_count'] == 104 and context['original_notes_count'] == 46 and context['preserve_existing_tasks_ids_order_and_prior_fields'] is True and context['original_census'] == {'unmatched': 181, 'patch_equivalent': 16, 'rewrite': False})
check('actual promotion remains blocked and unapplied', context['apply_authorized_now'] is False and context['release_ready'] is False and context['main_merge_eligible'] is False and context['blockers'] == ['Actual PR351 merge and complete hosted qualification receipt pending'])
check('actual PR351 task remains pending', context['additional_tasks'][0]['status'] == 'TESTING' and context['additional_tasks'][0]['merge_status'] == 'PENDING' and context['additional_tasks'][0]['test_results'] == 'Pending; scratch placeholder only.')
check('frozen source identity unchanged', context['frozen_local_source'] == 'f596471b8909ec8e28e0624041d60f03d520591d' and context['frozen_local_tree'] == 'dffeed541749850ef54a130cec0fa56c0fd2f01c')
check('reviewed assembly helper unchanged', sha((ROOT / 'assemble_windows_recovery_records.py').read_bytes()) == '7f8026469f7b5251236fef89384ce4eb70b722c20ee3988e77e229109a926260')
check('reviewed publication planner unchanged', sha((ROOT / 'prepare_windows_record_publication.py').read_bytes()) == '075354bd5516bf8e5750ddb72ea99907ad9b8fe72be6ab40326c25131561bac8')

new_tasks = context['additional_tasks'][9:]
check('two new review task identities', [x['id'] for x in new_tasks] == ['837fe-historical-sequential-lock-branch-accounting', '837fe-pr355-independent-source-review'])
check('task IDs and full task rows agree', context['proposed_new_task_ids'] == [x['id'] for x in context['additional_tasks']] and len(set(context['proposed_new_task_ids'])) == 11)
check('review completion does not claim source merge or ownership', all(x['status'] == 'COMPLETE' and x['merge_status'] == 'NOT_APPLICABLE' and x['files_owned'] == [] and x['implementation_status'] == 'COMPLETE for the stated bounded review only' for x in new_tasks))
destinations = {x['destination'] for x in context['static_evidence_inputs']}
for task in new_tasks:
    check('all new task evidence links bound: ' + task['id'], all(x.rsplit('/', 1)[-1] in destinations for x in task['evidence_links']))
sequential = read(ROOT / 'evidence/historical-ghidriff-sequential-lock-independent/review.json')
check('sequential task exact donor identity and bounded disposition', new_tasks[0]['source_commit'] == sequential['donor_head'] and new_tasks[0]['merge_base'] == sequential['merge_base'] and new_tasks[0]['classification'] == 'SUPERSEDED' and new_tasks[0]['original_census_bucket'] == 181)
check('sequential task retains failures and native distinction', all(s in new_tasks[0]['test_results'] for s in ['2pass2stronger-isolation failures', 'missing-helper collection errors', 'Counts overlap', 'no new peer product/native tests']) and 'actual Windows lock acceptance remains separate' in new_tasks[0]['next_action'])
pr_review = read(PR355 / 'review.json')
pr_snapshot = read(PR355 / 'final-pr-snapshot.json')
check('PR355 task exact source/tree and scope', new_tasks[1]['source_commit'] == pr_review['head'] == 'e2127864cb481026db0157082d688b8a36595e3b' and new_tasks[1]['comparison_tree'] == pr_review['tree'] == 'da71960b2edf33f1637c073b0613035843619543')
check('PR355 exact recorded draft/unmerged observation', new_tasks[1]['observed_pr_state'] == {k: pr_snapshot[k] for k in ['number', 'head', 'base', 'draft', 'merged', 'observed_utc']} and pr_snapshot['draft'] is True and pr_snapshot['merged'] is False and pr_snapshot['state'] == 'open')
check('PR355 review does not authorize merge or native acceptance', pr_review['release_ready'] is False and pr_review['full_suite'] is False and pr_review['windows_or_native_fault_acceptance'] is False and 'NOT MERGE AUTHORIZATION' in pr_review['verdict'] and 'this review grants no merge authorization' in new_tasks[1]['next_action'])
check('PR355 author holds remain explicit', all(s in new_tasks[1]['next_action'] for s in ['draft/author/hosted/full/ownership holds', 'current main', 'exact head']) and len(pr_review['open_gates']) == 3 and pr_snapshot['body_unchanged'] is True)
check('PR355 current object identity retained', git('rev-parse', pr_review['head'] + '^{tree}').decode().strip() == pr_review['tree'])
archive = PR355 / 'pr355-independent-review.zip'
receipt = read(PR355 / 'archive-receipt.json')
manifest_bytes = (PR355 / 'manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
check('PR355 archive and manifest binding', len(archive.read_bytes()) == receipt['bytes'] == 200123 and sha(archive.read_bytes()) == receipt['sha256'] == '592351d2c342d713664cb65409dbba57d96a84ae110c46fd2f1512d24ca1725d' and sha(manifest_bytes) == receipt['manifest_sha256'])
with zipfile.ZipFile(archive) as z:
    check('PR355 archive exact member set and CRC', len(z.namelist()) == receipt['members'] == 51 and z.testzip() is None and set(z.namelist()) == {x['path'] for x in manifest['payloads']} | {'manifest.json'})
    for row in manifest['payloads']:
        data = z.read(row['path'])
        check('PR355 sealed payload: ' + row['path'], data == (PR355 / row['path']).read_bytes() and len(data) == row['bytes'] and sha(data) == row['sha256'])
    check('PR355 embedded manifest unchanged', z.read('manifest.json') == manifest_bytes)
for label, expected in [('focused', (82, 0, 0, 0)), ('parent-red', (0, 3, 0, 0))]:
    cases = ET.parse(PR355 / (label + '.xml')).findall('.//testcase')
    fail = sum(c.find('failure') is not None for c in cases)
    error = sum(c.find('error') is not None for c in cases)
    skip = sum(c.find('skipped') is not None for c in cases)
    check('PR355 retained XML count: ' + label, (len(cases) - fail - error - skip, fail, error, skip) == expected)
controls = read(PR355 / 'import-boundary-controls.json')
check('PR355 nine separate synthetic controls retained', controls['count'] == len(controls['controls']) == 9 and all(x['passed'] for x in controls['controls']) and controls['synthetic'] is True and controls['native_fault_acceptance'] is False)
for name in ['focused', 'whole-tree-ruff', 'dependency-check']:
    command = read(PR355 / (name + '.command.json'))
    check('PR355 source-bound retained command: ' + name, command['exit'] == 0 and command['source'] == pr_review['head'] and command['tree'] == pr_review['tree'])
focused_command = read(PR355 / 'focused.command.json')
check('six maintained modules and explicit isolated source binding retained', focused_command['argv'][1] == '-I' and focused_command['argv'][-1].count("'tests/test_") == 6 and 'EXACT_SOURCE_BINDING' in focused_command['argv'][-1])

def literal_assignments(path, name):
    tree = ast.parse(path.read_text())
    return [ast.literal_eval(x.value) for x in tree.body if isinstance(x, ast.Assign) and isinstance(x.targets[0], ast.Name) and x.targets[0].id == name]

expected = (PRIOR / 'report-reviewed.md').read_text()
old_time = 'automatic native push run44901791862 was discovered queued at12:00:58UTC'
new_time = 'the queued discovery of automatic native push run44901791862 was recorded at12:01:47UTC'
check('previous timestamp wording finding is corrected once', expected.count(old_time) == 1 and report_bytes.decode().count(new_time) == 1 and old_time not in report_bytes.decode())
publication = read(PRIOR / 'code-branch-publication.json')
check('corrected timestamp matches original publication receipt', '12:01:47' in json.dumps(publication))
expected = expected.replace(old_time, new_time)
section = literal_assignments(ROOT / 'prepare_windows_coordination_records.py', 'section')[0]
expected = expected.replace('Separately, it adds eight scoped tasks', 'Separately, it adds nine scoped tasks').replace('## Remaining qualification and next actions\n', section + '## Remaining qualification and next actions\n')
append_script = ROOT / 'append_completed_readonly_reviews.py'
row = literal_assignments(append_script, 'row')[0]
paragraphs = literal_assignments(append_script, 'para')
expected = expected.replace('Separately, it adds nine scoped tasks', 'Separately, it adds eleven scoped tasks').replace('\nCI and WIN1 review retained', row + '\nCI and WIN1 review retained').replace('These are complete reviews of the five named branches', paragraphs[0] + 'These are complete reviews of the six named branches').replace('## Remaining qualification and next actions\n', paragraphs[1] + '## Remaining qualification and next actions\n')
check('entire report reconstructed from prior reviewed bytes plus disclosed additions', expected.encode() == report_bytes)
check('eleven draft task and six historical branch wording', expected.count('Separately, it adds eleven scoped tasks') == 1 and expected.count('These are complete reviews of the six named branches') == 1)
check('three actual-promotion placeholders remain exact', re.findall(r'<[A-Z_0-9]+>', expected) == ['<ACTUAL_PR351_MERGE>', '<PR351_QUALIFICATION_SUMMARY>', '<POST_PR351_PAGES_STATUS>'])
check('new report limits preserve native and merge boundaries', 'No new native lock-resolution claim follows.' in expected and 'do not constitute full-suite, native or Windows acceptance' in expected and 'Actual current-main reconciliation, full/platform qualification, author draft/ownership resolution and fresh merge guards remain required' in expected)

ledger_path = 'docs/engineering/task-ledger.json'
ledger_bytes = (REPO / ledger_path).read_bytes()
ledger = json.loads(ledger_bytes)
check('actual 104-task/46-note ledger remains byte-identical to frozen source', len(ledger['tasks']) == 104 and len(ledger['notes']) == 46 and ledger_bytes == git('show', 'f596471b8909ec8e28e0624041d60f03d520591d:' + ledger_path))
check('source checkout remains clean and unapplied', git('status', '--porcelain=v1') == b'' and git('rev-parse', 'HEAD').decode().strip() == context['frozen_local_source'])
check('context/report stable throughout review', context_path.read_bytes() == context_bytes and report_path.read_bytes() == report_bytes)
copies = {
    'context-before.json': before_path, 'context-reviewed.json': context_path,
    'report-reviewed.md': report_path, 'prior-report-reviewed.md': PRIOR / 'report-reviewed.md',
    'append-completed-reviews-reviewed.py': append_script,
    'coordination-preparation-reviewed.py': ROOT / 'prepare_windows_coordination_records.py',
    'pr355-review.json': PR355 / 'review.json', 'pr355-original.zip': archive,
    'sequential-lock-review.json': ROOT / 'evidence/historical-ghidriff-sequential-lock-independent/review.json',
    'code-publication-receipt.json': PRIOR / 'code-branch-publication.json',
}
for name, source in copies.items():
    shutil.copyfile(source, OUT / name)
review = {
    'schema': 'patchtrace/completed-review-additions-independent/1',
    'observed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'verdict': 'CLEAR FOR PREPARATION ONLY; actual PR351-bound assembled-record review remains required',
    'blockers': [], 'source': context['frozen_local_source'], 'tree': context['frozen_local_tree'],
    'context_sha256': sha(context_bytes), 'prior_context_sha256': sha(before_bytes),
    'report_sha256': sha(report_bytes), 'append_script_sha256': sha(append_script.read_bytes()),
    'static_inputs': 67, 'static_input_bytes': 30649939, 'prior_inputs_exactly_preserved': 61,
    'new_evidence_inputs': context['static_evidence_inputs'][61:],
    'draft_tasks': 11, 'prior_draft_tasks_exactly_preserved': 9,
    'existing_ledger_tasks_unchanged': 104, 'existing_ledger_notes_unchanged': 46,
    'historical_dispositions': 6, 'prior_historical_dispositions_exactly_preserved': 5,
    'prior_census': context['original_census'], 'apply_authorized': False,
    'checks': CHECKS, 'check_count': len(CHECKS),
    'new_product_tests_run': 0, 'source_reviews_repeated': False,
    'limitations': [
        'This is a preparation-delta and evidence-binding audit, not a second PR355 source qualification.',
        'All original import failures, isolation-policy failures and intended parent failures remain in immutable source archives.',
        'PR355 draft/author/full/hosted/ownership gates remain; completed review tasks do not authorize its merge.',
        'No actual PR351 promotion has been supplied; three explicit placeholders and the apply=false blocker remain.',
        'Current f596 native cold/warm and Windows acceptance are not inferred from source-fixture or historical receipts.',
        'No source/helper/context/report/ledger/ref/PR/CI changes by this reviewer.'
    ]
}
(OUT / 'review.json').write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps({'verdict': review['verdict'], 'checks': len(CHECKS), 'context_sha256': review['context_sha256'], 'report_sha256': review['report_sha256'], 'review_sha256': sha((OUT / 'review.json').read_bytes())}))
