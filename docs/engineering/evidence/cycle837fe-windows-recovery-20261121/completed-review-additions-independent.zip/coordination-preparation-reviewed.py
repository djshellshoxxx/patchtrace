"""Add the completed, read-only coordination review to an unapplied context."""
from pathlib import Path
import hashlib
import json

root = Path('/workspace/scratch/837fe19aae3a')
path = root / 'windows-recovery-records-context.json'
raw = path.read_bytes()
context = json.loads(raw)
assert context['apply_authorized_now'] is False
task_id = '837fe-cross-worker-integration-order-review'
assert task_id not in context['proposed_new_task_ids']
review_path = root / 'evidence/cross-worker-integration-order-review/review.json'
assert hashlib.sha256(review_path.read_bytes()).hexdigest() == 'd902569de5c296079f4871cf97e783e65f49abe7495e3713ae398e3c8c64e3bb'
before = root / 'evidence/windows-recovery-record-preparation/context-before-coordination-accounting.json'
assert not before.exists()
before.write_bytes(raw)
prefix = 'docs/engineering/evidence/cycle837fe-windows-recovery-20261121/'
context['additional_tasks'].append({
    'id': task_id,
    'status': 'COMPLETE',
    'description': 'Preserve independent metadata, path, ancestry and ownership accounting for concurrent PRs352–356',
    'source_branch': 'main',
    'source_commit': '9023761a4066ac1c50c127ac09d0ba5f56cdc9e4',
    'target_integration_branch': context['target_branch'],
    'assigned_worker': 'codex1 independent read-only review; root837FE record integration',
    'files_owned': [],
    'implementation_status': 'COMPLETE for bounded metadata review; no source qualification',
    'test_results': '62 metadata/path/ancestry checks; final eight-object stability refresh at2026-11-21T12:25:05Z. No product tests.',
    'audit_findings': 'All five author holds retained. PR356 stacks on354. PR352 uses netutil.interruptible, requiring integrated review with354/356. PR352/353 share QA/TODO files with these records. No source, ref, PR or CI mutation.',
    'dependencies': [],
    'blockers': [],
    'merge_status': 'NOT_APPLICABLE',
    'evidence_links': [prefix + 'cross-worker-integration-order-review.zip', prefix + 'cross-worker-integration-order-review.json'],
    'next_action': 'Refresh every author/head/base/hold before later integration; respect active ownership, qualify354 before356, preserve all QA/TODO additions, and requalify any changed integration base. This review authorizes no other PR merge.'
})
context['proposed_new_task_ids'].append(task_id)
context['cross_worker_coordination_snapshot'] = {
    'observed_utc': '2026-11-21T12:25:05Z',
    'main': '9023761a4066ac1c50c127ac09d0ba5f56cdc9e4',
    'head_by_pr': {
        '352': 'e3928ab8c8e2deee7bb01b0f857205f68a1abda2',
        '353': 'd0a4bdf439775999340ea760d96a087e032ee6dd',
        '354': 'a41c7a0d594d1fe26c16da395e6f6f9b33b07eca',
        '355': 'e2127864cb481026db0157082d688b8a36595e3b',
        '356': '1d475d926314ae116442bfe2b7cd268ad95ea12c'},
    'source_qualification': False,
    'all_author_holds_preserved': True,
    'future_refresh_required': True,
    'evidence': prefix + 'cross-worker-integration-order-review.json'}
path.write_text(json.dumps(context, indent=2) + '\n')
report_path = root / 'evidence/windows-recovery-record-preparation/report-template.md'
report = report_path.read_text()
assert report.count('Separately, it adds eight scoped tasks') == 1
report = report.replace('Separately, it adds eight scoped tasks', 'Separately, it adds nine scoped tasks')
section = '''## Concurrent worker integration order

An independent read-only snapshot at **2026-11-21T12:25:05Z**, before the actual PR351 promotion above, retained all author holds on PRs352–356. It verified 62 metadata, changed-path and ancestry checks plus an eight-object stability refresh. This establishes no source qualification and grants no permission to merge those PRs.

| PR | Snapshot head | Qualification and dependency hold |
|---|---|---|
| 352 | `e3928ab8c8e2deee7bb01b0f857205f68a1abda2` | Explicitly unverified; full checkout, hosted QA, lint and independent review remain. Its stated dependency on `netutil.interruptible` requires integrated review with354/356. |
| 353 | `d0a4bdf439775999340ea760d96a087e032ee6dd` | Explicitly unverified; exact-head qualification and independent review remain. Preserve its QA/TODO additions alongside352 and these records. |
| 354 | `a41c7a0d594d1fe26c16da395e6f6f9b33b07eca` | Draft; whole-repository/platform qualification, independent review and ownership reconciliation remain. |
| 355 | `e2127864cb481026db0157082d688b8a36595e3b` | Draft; full QA, lint, independent review and ownership reconciliation remain. |
| 356 | `1d475d926314ae116442bfe2b7cd268ad95ea12c` | Draft stacked on354; qualify354 first, then reconcile to actual main and qualify the resulting exact source. |

These timestamps preserve the observation; they are not a substitute for fresh ownership, head and target checks. Every later main advance requires integration-base reconciliation. The [sealed coordination review](evidence/cycle837fe-windows-recovery-20261121/cross-worker-integration-order-review.zip) and [source identities and holds](evidence/cycle837fe-windows-recovery-20261121/cross-worker-integration-order-review.json) retain the complete snapshots. No other worker's branch, PR or CI run was changed.

'''
needle = '## Remaining qualification and next actions\n'
assert report.count(needle) == 1 and '## Concurrent worker integration order' not in report
report_path.write_text(report.replace(needle, section + needle))
print(json.dumps({'tasks': len(context['additional_tasks']), 'inputs': len(context['static_evidence_inputs']), 'apply': context['apply_authorized_now']}))
