from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).parent
archive = root / 'completed-review-additions-independent.zip'
files = []
for path in sorted(root.iterdir()):
    if path.is_file() and path.name not in {archive.name, 'manifest.json', 'archive-receipt.json'}:
        data = path.read_bytes()
        files.append({'path': path.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
manifest = root / 'manifest.json'
manifest.write_text(json.dumps({'schema': 'patchtrace/independent-preparation-evidence/1', 'files': files}, indent=2) + '\n')
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for row in files:
        z.write(root / row['path'], row['path'])
    z.write(manifest, manifest.name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    assert set(z.namelist()) == {x['path'] for x in files} | {'manifest.json'}
    for row in files:
        b = z.read(row['path'])
        assert len(b) == row['bytes'] and hashlib.sha256(b).hexdigest() == row['sha256']
receipt = {'archive': archive.name, 'bytes': archive.stat().st_size,
           'sha256': hashlib.sha256(archive.read_bytes()).hexdigest(), 'members': len(files) + 1,
           'manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest(),
           'review_sha256': hashlib.sha256((root / 'review.json').read_bytes()).hexdigest(),
           'crc_and_member_hashes_verified': True}
(root / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
