"""Append completed bounded reviews to the still-unapplied Windows record context."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path('/workspace/scratch/837fe19aae3a')
path = root / 'windows-recovery-records-context.json'
raw = path.read_bytes()
c = json.loads(raw)
assert not c['apply_authorized_now'] and len(c['additional_tasks']) == 9
backup = root / 'evidence/windows-recovery-record-preparation/context-before-completed-readonly-reviews.json'
assert not backup.exists()
backup.write_bytes(raw)
prefix = 'docs/engineering/evidence/cycle837fe-windows-recovery-20261121/'
inputs = [
    ('evidence/historical-after-f596-next-review/historical-ghidriff-sequential-lock-review.zip', 'historical-sequential-lock-author.zip', '907abba74b2de63202f138048266b4202a5d96e68549252c70342c737c63dfb1'),
    ('evidence/historical-after-f596-next-review/classification.json', 'historical-sequential-lock-classification.json', None),
    ('evidence/historical-ghidriff-sequential-lock-independent/historical-ghidriff-sequential-lock-independent.zip', 'historical-sequential-lock-independent.zip', '0a92936d693df71c4287fe539ff09bf2f415204937cb14ba746b092e485fb7f3'),
    ('evidence/historical-ghidriff-sequential-lock-independent/review.json', 'historical-sequential-lock-independent-review.json', 'b7566bc9e3398891c11e318635f759afe4709d0de1d5b28035e6de78a0882a04'),
    ('evidence/pr355-independent-review/pr355-independent-review.zip', 'pr355-independent-review.zip', '592351d2c342d713664cb65409dbba57d96a84ae110c46fd2f1512d24ca1725d'),
    ('evidence/pr355-independent-review/review.json', 'pr355-independent-review.json', '10e53d1b3983c8e25a9e7a36f8bf81e52f18a16a9792be03e2ab88b9896d51f7'),
]
for source, destination, expected in inputs:
    p = root / source
    b = p.read_bytes()
    digest = hashlib.sha256(b).hexdigest()
    assert expected is None or digest == expected
    assert not any(x['destination'] == destination for x in c['static_evidence_inputs'])
    if p.suffix == '.zip':
        with zipfile.ZipFile(p) as a:
            assert a.testzip() is None
    c['static_evidence_inputs'].append({'source': source, 'destination': destination,
                                      'bytes': len(b), 'sha256': digest})


def add_task(task_id, description, branch, head, test_results, audit, evidence, next_action, **extra):
    assert task_id not in c['proposed_new_task_ids']
    c['proposed_new_task_ids'].append(task_id)
    c['additional_tasks'].append({
        'id': task_id, 'status': 'COMPLETE', 'description': description,
        'source_branch': branch, 'source_commit': head,
        'target_integration_branch': c['target_branch'],
        'assigned_worker': 'root837FE integration; authors and independent reviewers identified in linked evidence',
        'files_owned': [], 'implementation_status': 'COMPLETE for the stated bounded review only',
        'test_results': test_results, 'audit_findings': audit, 'dependencies': [], 'blockers': [],
        'merge_status': 'NOT_APPLICABLE', 'evidence_links': [prefix + x for x in evidence],
        'next_action': next_action, **extra})


add_task(
    '837fe-historical-sequential-lock-branch-accounting',
    'Complete historical Ghidriff sequential invocation and cache-version branch accounting',
    'chatgpt/ghidriff-sequential-lock-fix-20261017', 'f6b7545bcc7a161440ab7119233c204510571370',
    'All5commits/3paths; donor final4pass; unchanged donor test on current2pass2stronger-isolation failures; maintained4pass; separate cache-selector1pass. Initial and intermediate missing-helper collection errors retained. Counts overlap. Independent230checks; no new peer product/native tests.',
    'SUPERSEDED: sequential argv and adapter /2 remain; mandatory -I -X utf8 is stronger. Dated9-line lock note byte-identical with original uncertainty/native requirement.19snapshots23introducedobjects preserved. No missing compatible contribution.',
    ['historical-sequential-lock-author.zip', 'historical-sequential-lock-classification.json',
     'historical-sequential-lock-independent.zip', 'historical-sequential-lock-independent-review.json'],
    'Keep donor branch, obsolete-test failures and original181/16census. No source port needed; actual Windows lock acceptance remains separate.',
    classification='SUPERSEDED', merge_base='70e33fd77570329ba23afc58a38616270636d37c', original_census_bucket=181)
c['historical_dispositions'].append({
    'branch': 'chatgpt/ghidriff-sequential-lock-fix-20261017',
    'head': 'f6b7545bcc7a161440ab7119233c204510571370',
    'merge_base': '70e33fd77570329ba23afc58a38616270636d37c',
    'classification': 'SUPERSEDED', 'scope': 'All5uniquecommits,3historical/netpaths', 'original_bucket': 181})
add_task(
    '837fe-pr355-independent-source-review',
    'Independently review the existing optional-import startup recovery while retaining its author holds',
    'fix/optional-import-init-exceptions-20261121-0318', 'e2127864cb481026db0157082d688b8a36595e3b',
    'Root independent original main902 regression3failed; exact e212 checkout82passed0skip across6modules, whole-tree Ruff/pip check passed;9separate authored import-boundary controls passed. Overlaps author7; no full/native/Windows execution.',
    'CLEAR for further exact-source hosted qualification; no source blockers. All4commits/4paths inspected. Only executable AST changes are3ImportError-to-Exception handlers; KeyboardInterrupt/SystemExit still propagate. Original source/test/dates and full failures preserved.',
    ['pr355-independent-review.zip', 'pr355-independent-review.json'],
    'Retain draft/author/hosted/full/ownership holds. Reconcile actual current main and exact head before any later integration; this review grants no merge authorization.',
    comparison_tree='da71960b2edf33f1637c073b0613035843619543',
    observed_pr_state={'number': 355, 'head': 'e2127864cb481026db0157082d688b8a36595e3b',
                       'base': '9023761a4066ac1c50c127ac09d0ba5f56cdc9e4', 'draft': True,
                       'merged': False, 'observed_utc': '2026-11-21T12:45:14Z'})
path.write_text(json.dumps(c, indent=2) + '\n')
report_path = root / 'evidence/windows-recovery-record-preparation/report-template.md'
report = report_path.read_text()
assert report.count('Separately, it adds nine scoped tasks') == 1
report = report.replace('Separately, it adds nine scoped tasks', 'Separately, it adds eleven scoped tasks')
needle = '\nCI and WIN1 review retained'
assert report.count(needle) == 1
row = '| `chatgpt/ghidriff-sequential-lock-fix-20261017` — `f6b7545bcc7a161440ab7119233c204510571370` | `70e33fd77570329ba23afc58a38616270636d37c` | SUPERSEDED | All five unique commits and three historical/net paths accounted; sequential invocation and adapter /2 retained with stronger Python isolation |\n'
report = report.replace(needle, row + needle)
needle = 'These are complete reviews of the five named branches'
assert report.count(needle) == 1
para = ('Sequential-lock history retained19 source snapshots and23 introduced Git objects;230 independent checks passed. The final donor fixture passed4 cases; its unchanged replay on current source had2 passes and2 disclosed failures solely from the superseded bundle-only isolation expectation. Maintained current fixtures passed4 cases, and one separate cache-version selector passed; counts overlap. Initial test-only and intermediate-refactor missing-helper collection errors remain preserved. The entire dated nine-line lock note remains byte-identical, including its uncertainty and outstanding native Windows requirement. No new native lock-resolution claim follows. See the [author archive](evidence/cycle837fe-windows-recovery-20261121/historical-sequential-lock-author.zip) and [independent disposition](evidence/cycle837fe-windows-recovery-20261121/historical-sequential-lock-independent-review.json).\n\n')
report = report.replace(needle, para + 'These are complete reviews of the six named branches')
needle = '## Remaining qualification and next actions\n'
assert report.count(needle) == 1
para = ('### Subsequent bounded source review of PR355\n\n'
        'Root independently reviewed all four commits and four paths at `e2127864cb481026db0157082d688b8a36595e3b`, tree `da71960b2edf33f1637c073b0613035843619543`. The unchanged new regressions failed three cases on actual main902 as intended. The exact PR checkout then passed82 cases across optional-import, capability, search and doctor CLI modules, whole-tree Ruff and dependency checks. Nine separate authored controls verified OSError degradation and KeyboardInterrupt/SystemExit propagation. These counts overlap the author’s seven cases and do not constitute full-suite, native or Windows acceptance.\n\n'
        'The review is clear for further hosted qualification. A fresh12:45:14UTC read retained the same open draft, head/base/body and author holds; no PR/ref/source/CI mutation occurred. The three widened exception handlers preserve static import and registry behavior. Actual current-main reconciliation, full/platform qualification, author draft/ownership resolution and fresh merge guards remain required. See the [sealed source review](evidence/cycle837fe-windows-recovery-20261121/pr355-independent-review.zip) and [review result](evidence/cycle837fe-windows-recovery-20261121/pr355-independent-review.json).\n\n')
report_path.write_text(report.replace(needle, para + needle))
print(json.dumps({'tasks': len(c['additional_tasks']), 'inputs': len(c['static_evidence_inputs']),
                  'bytes': sum(x['bytes'] for x in c['static_evidence_inputs']), 'apply': c['apply_authorized_now']}))
