"""Read-only assembled records audit; no Git object/index/source writes."""
from pathlib import Path
import copy, datetime, hashlib, json, re, shutil, stat, subprocess, zipfile

ROOT=Path('/workspace/scratch/837fe19aae3a')
OUT=Path(__file__).parent
REPO=ROOT/'PatchTrace-windows-recovery-followup'
SOURCE='f596471b8909ec8e28e0624041d60f03d520591d'
TREE='dffeed541749850ef54a130cec0fa56c0fd2f01c'
MERGE='3a16290c0fcc4e0c21712fe10474a3ff33fad336'
REMOTE='4202e5e79e2aea6366c75261d74544ea48368ca5'
PRIOR='d6679abc6dfddbadce0391c8d18289f7f96338d6'
LOCAL='2ae1bbad2ad9cc78c29541872381750e347c670e'
PRIOR_TREE='6001ef506c38930fd590bd827f428b997c3b2797'
EV=Path('docs/engineering/evidence/cycle837fe-windows-recovery-20261121')
REPORT=Path('docs/engineering/cycle837fe-windows-recovery-20261121.md')
LEDGER=Path('docs/engineering/task-ledger.json')
PREFIXED=['docs/engineering-handoffs/cycle837fe-combined-pr349-20261121.md','docs/qa.md','tasks/todo.md']
DOCS={'docs/release-process.md':'57d573b9092f7b00ab143adeccdc64478e99895fafbd41f13a597ba187f46e66',
      'docs/windows.md':'aff71e51afb1b74a51fc19be861899b3b096aea6ebbb71e5e1bae2e815a731da',
      'docs/package-audit.md':'1a4f6204dcb2e1e211c30e7fca96d7ce32a51cb1a46bbaacb4c808b2aaa74eb4'}
ALLOWED=set(PREFIXED)|set(DOCS)|{str(REPORT),str(LEDGER)}
FIELDS={'updated_at','integration_branch','local_integration_branch','checkpoint_local_commit','aggregate_source_commit','aggregate_source_tree','remote_publication','current_qualification','current_handoff','continuation','main_merge_eligible','release_ready'}
LEGACY={'buildenv-header-help-20261121-95fe':{'status','result_or_next_action'},'historical-audit-gates-cycle2':{'status','result_or_next_action'},'registered-header-help':{'status','result_or_next_action','parallel_scope_837fe.qualification'}}
PROMOTE={'codex5-per-command-audit-20261121','837fe-pages-configuration-hold'}
CHECKS=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(b,kind='blob'):return hashlib.sha1(f'{kind} {len(b)}\0'.encode()+b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=REPO)
def gt(*a):return git(*a).decode().strip()
def read(p):return json.loads(p.read_text())
def oldbytes(p):return git('show',SOURCE+':'+str(p))
def check(n,v):
 CHECKS.append({'check':n,'passed':bool(v)})
 assert v,n

context_raw=(ROOT/'windows-recovery-records-context.json').read_bytes();c=json.loads(context_raw)
report_raw=(REPO/REPORT).read_bytes();manifest_raw=(REPO/EV/'manifest.json').read_bytes();manifest=json.loads(manifest_raw)
check('exact frozen context/report/manifest hashes',(sha(context_raw),sha(report_raw),sha(manifest_raw))==('e270f9a8ba5e0891b8045156068c9ab3d254f75899bd609d3759f6346be79d3e','d0976daac793cb7512b0b052ef665dc2c723860c8016d2452291101dd8b132ed','f27d58dc196f6f4ff9c52673f52efc06c45fbf92dbdf5507f8fc922723f729f1'))
check('HEAD/tree/MERGE_HEAD/branch',gt('rev-parse','HEAD')==SOURCE and gt('rev-parse','HEAD^{tree}')==TREE and gt('rev-parse','MERGE_HEAD')==MERGE and gt('branch','--show-current')==c['target_branch'])
check('no staged/unmerged entries',git('diff','--cached','--name-only')==b'' and git('ls-files','-u')==b'')
check('actual main equals already incorporated complete tree',all(gt('rev-parse',s+'^{tree}')==PRIOR_TREE for s in [MERGE,LOCAL,PRIOR]))
check('local prior is source ancestor',subprocess.run(['git','merge-base','--is-ancestor',LOCAL,SOURCE],cwd=REPO).returncode==0)
check('remote code complete tree equals local',gt('rev-parse',REMOTE+'^{tree}')==TREE)
promotion_review=read(OUT.parent/'promotion-preparation/review.json')
check('independent actual promotion receipt',promotion_review['merge_commit']==MERGE and promotion_review['tree']==PRIOR_TREE and not promotion_review['blockers'] and promotion_review['check_count']==166)
status=git('status','--porcelain=v1','--untracked-files=all','-z');rows=[r.decode() for r in status.split(b'\0') if r];paths=[r[3:] for r in rows]
check('96 record-only paths with no deletions/renames',len(paths)==len(set(paths))==96 and all(r[:2] in [' M','??'] for r in rows) and all(p in ALLOWED or p.startswith(str(EV)+'/') for p in paths))
check('exact eight document/ledger outputs',{p for p in paths if not p.startswith(str(EV)+'/')}==ALLOWED)
inventory=[]
for p in sorted(paths):
 f=REPO/p;b=f.read_bytes();m=f.lstat().st_mode
 check('regular nonexecuting output '+p,stat.S_ISREG(m) and not f.is_symlink() and not m&0o111)
 inventory.append({'path':p,'bytes':len(b),'sha256':sha(b),'git_blob':oid(b),'mode':'100644'})
check('exact 45,660,375 output bytes',sum(x['bytes'] for x in inventory)==45660375)
applied=read(ROOT/'evidence/windows-recovery-record-preparation/applied-records.json')
check('applied receipt exact scope',applied['applied'] and applied['source']==SOURCE and applied['tree']==TREE and applied['prior_promoted']==MERGE and set(applied['writes'])==set(paths) and applied['bytes']==45660375 and applied['payloads']==87)

def tree_hash(files):
 root={}
 for path,value in files.items():
  node=root;parts=path.split('/')
  for part in parts[:-1]:node=node.setdefault(part,{})
  node[parts[-1]]=value
 def encode(node):
  items=[]
  for name,value in node.items():
   isdir=isinstance(value,dict);mode,child=('40000',encode(value)) if isdir else value
   items.append((name.encode()+(b'/' if isdir else b''),mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(child)))
  return oid(b''.join(v for _,v in sorted(items)),'tree')
 return encode(root)
basefiles={}
for entry in git('ls-tree','-r','-z',SOURCE).split(b'\0'):
 if entry:
  meta,path=entry.split(b'\t',1);mode,kind,objectid=meta.decode().split();basefiles[path.decode()]=(mode,objectid)
check('pure read-only tree reconstruction matches Git',tree_hash(basefiles)==TREE)
candidate=basefiles.copy()
for x in inventory:candidate[x['path']]=(x['mode'],x['git_blob'])
candidate_tree=tree_hash(candidate)
check('all protected tracked object identities preserved',all(candidate[p]==v for p,v in basefiles.items() if p not in ALLOWED))

old_raw=oldbytes(LEDGER);old=json.loads(old_raw);new=read(REPO/LEDGER)
ot={x['id']:x for x in old['tasks']};nt={x['id']:x for x in new['tasks']}
check('prior raw ledger exact to source and prior published head',(REPO/EV/'prior-ledger-d667.json').read_bytes()==old_raw==git('show',PRIOR+':'+str(LEDGER)))
check('104 old IDs/order and 12 exact additions',len(ot)==104 and len(nt)==len(new['tasks'])==116 and [x['id'] for x in new['tasks'][:104]]==[x['id'] for x in old['tasks']] and new['tasks'][104:]==c['additional_tasks'] and [x['id'] for x in new['tasks'][104:]]==c['proposed_new_task_ids'])
changed={k for k in ot if ot[k]!=nt[k]}
check('only five declared original rows changed',changed==PROMOTE|set(LEGACY))
check('99 other complete original task rows unchanged',all(ot[k]==nt[k] for k in set(ot)-changed) and len(set(ot)-changed)==99)
allowed_top=FIELDS|{'tasks','continuation_history','codex5_followup_837fe','pr351_main_promotion_837fe','windows_recovery_837fe'}
check('all unrelated top-level objects unchanged',all(old[k]==new[k] for k in set(old)-allowed_top) and {k for k in set(new)-set(old)}=={'pr351_main_promotion_837fe','windows_recovery_837fe'})
check('all notes and prior continuation histories exact',len(new['notes'])==46 and new['notes']==old['notes'] and len(old['continuation_history'])==6 and len(new['continuation_history'])==7 and new['continuation_history'][:-1]==old['continuation_history'])
h=new['continuation_history'][-1]
check('complete before-field and old C5 deep snapshots',h['previous_current_fields']=={k:old[k] for k in FIELDS if k in old} and h['previous_codex5_followup']==old['codex5_followup_837fe'])
check('all five complete before-row deep snapshots',h['legacy_rows_before_reconciliation']==[x for x in old['tasks'] if x['id'] in LEGACY] and h['updated_tasks_before_promotion']==[x for x in old['tasks'] if x['id'] in PROMOTE])
check('history timestamp/prior link',h['recorded_at']==new['updated_at'] and h['prior_ledger_evidence']==str(EV/'prior-ledger-d667.json'))
previous=read(OUT.parent/'completed-review-additions/context-reviewed.json');legacy=c['reviewed_legacy_reconciliation']
check('unchanged reviewed legacy proposal and before guard',legacy==previous['reviewed_legacy_reconciliation'] and legacy['baseline_ledger_sha256']==sha(old_raw) and legacy['before_rows']=={k:ot[k] for k in LEGACY})
expected_legacy={k:copy.deepcopy(ot[k]) for k in LEGACY};seen=set()
for change in legacy['changes']:
 k,field=change['task_id'],change['field'];check('allowed guarded legacy field '+k+':'+field,k in LEGACY and field in LEGACY[k] and (k,field) not in seen);seen.add((k,field));node=expected_legacy[k];parts=field.split('.')
 for part in parts[:-1]:node=node[part]
 check('legacy prior field '+k+':'+field,node[parts[-1]]==change['before']);node[parts[-1]]=change['after']
check('exactly seven replacements and no other row fields',len(seen)==7 and seen=={(k,f) for k,fields in LEGACY.items() for f in fields} and all(nt[k]==v for k,v in expected_legacy.items()))
check('normalized user enum states',[nt[k]['status'] for k in ['buildenv-header-help-20261121-95fe','historical-audit-gates-cycle2','registered-header-help']]==['MERGED','BLOCKED','TESTING'])
promotion=c['verified_pr351_promotion'];qualified=c['pr351_qualification_summary']
check('actual promotion object exact sealed proof',promotion==read(REPO/EV/'pr351-merge-proof.json') and promotion['merge_commit']==MERGE)
promotion_fields={'status','merge_status','dependencies','blockers','actual_pr351_promotion','test_results','latest_hosted_qualification','historical_prepublication_test_results','next_action','result_or_next_action'}
for k in PROMOTE:
 t=nt[k];check('source promotion and retained test history '+k,t['status']==t['merge_status']=='MERGED' and t['dependencies']==[] and t['actual_pr351_promotion']==promotion and t['test_results']==t['latest_hosted_qualification']==qualified and t['historical_prepublication_test_results']==ot[k]['test_results'])
 restored={a:copy.deepcopy(b) for a,b in t.items() if a not in promotion_fields};restored.update({a:copy.deepcopy(ot[k][a]) for a in promotion_fields if a in ot[k]});check('no unrelated promoted row changes '+k,restored==ot[k])
check('Pages observed behavior remains pending despite source merge',c['post_pr351_pages_accepted'] is False and nt['837fe-pages-configuration-hold']['blockers']==['Automatic held-main Pages skip/upload observation remains pending.'] and nt['codex5-per-command-audit-20261121']['blockers']==[])
gate='New CODEX-5 source still requires final publication, applicable hosted/full qualification, and guarded main merge.'
oc,nc=old['codex5_followup_837fe'],new['codex5_followup_837fe']
check('one fulfilled C5 gate removed and four broader gates exact',oc['open_gates'].count(gate)==1 and nc['open_gates']==[g for g in oc['open_gates'] if g!=gate] and len(nc['open_gates'])==4)
check('historical C5 qualification separate from exact PR351 current result',nc['historical_prepublication_qualification']==oc['qualification'] and nc['qualification']==nc['exact_hosted_qualification']==qualified and nc['actual_main_promotion']==promotion and nc['status']=='MERGED')
c5fields={'status','actual_main_promotion','historical_prepublication_qualification','qualification','exact_hosted_qualification','open_gates','postmerge_pages_status'}
check('all other C5 followup fields exact',all(oc.get(k)==nc.get(k) for k in (set(oc)|set(nc))-c5fields))
check('current source identity and unqualified followup status',new['checkpoint_local_commit']==new['aggregate_source_commit']==SOURCE and new['aggregate_source_tree']==TREE and new['current_qualification']==c['current_recovery_qualification'] and new['main_merge_eligible'] is False and new['release_ready'] is False)
check('continuation and unpublished record boundary',new['continuation']['status']=='TESTING' and new['continuation']['code_commit']==SOURCE and new['continuation']['release_ready'] is False and new['continuation']['main_merge_eligible'] is False and new['remote_publication']==c['planned_publication'] and new['remote_publication']['records_published'] is False and new['remote_publication']['base_commit']==MERGE)
check('new scoped promotion/recovery objects',new['pr351_main_promotion_837fe']==promotion and new['windows_recovery_837fe']['status']=='TESTING' and new['windows_recovery_837fe']['qualification']==c['current_recovery_qualification'] and new['windows_recovery_837fe']['source_commit']==SOURCE and new['windows_recovery_837fe']['release_ready'] is False)
check('181/16 and all six prior scoped dispositions preserved',c['original_census']=={'unmatched':181,'patch_equivalent':16,'rewrite':False} and new['windows_recovery_837fe']['original_census_preserved']=={'unmatched':181,'patch_equivalent':16} and c['historical_dispositions']==previous['historical_dispositions']==new['windows_recovery_837fe']['historical_dispositions'])
check('previous 67 immutable bindings preserved',c['static_evidence_inputs'][:67]==previous['static_evidence_inputs'])
check('eleven prior draft identities plus PR353 only',c['proposed_new_task_ids'][:11]==previous['proposed_new_task_ids'] and len(c['additional_tasks'])==12 and c['additional_tasks'][-1]['id']=='837fe-pr353-independent-csaf-read-bounds-review')
for a,b in zip(previous['additional_tasks'],c['additional_tasks'][:11],strict=True):
 if a['id'] not in {'837fe-pr351-qualified-main-promotion','837fe-live-ghidra-original-archive-recovery'}:check('prior review task preserved '+a['id'],a==b)
native=c['additional_tasks'][7]
check('native prior blockers retained, new final acceptance not claimed',native['historical_pre_native_checkpoint_blockers']==previous['additional_tasks'][7]['blockers'] and native['status']=='TESTING' and native['test_results']['hosted_code_checkpoint']['verdict']['actual_windows_27_case_gate_qualified'] is False)
check('promotion task completed against actual qualification',c['additional_tasks'][0]['status']=='COMPLETE' and c['additional_tasks'][0]['merge_status']=='MERGED' and c['additional_tasks'][0]['test_results']==qualified and c['additional_tasks'][0]['blockers']==[])

for p in PREFIXED:
 b=(REPO/p).read_bytes();prefix=c['prefixes'][p].encode();check('complete historical suffix '+p,b==prefix+oldbytes(p));check('prefix source/limits '+p,all(s in prefix.decode() for s in [MERGE,SOURCE,REMOTE,'final-record-source or Windows27 acceptance','Release readiness is false']))
for edit in c['reviewed_document_replacements']:
 p=edit['path'];b=(REPO/p).read_bytes();check('exact approved document '+p,p in DOCS and sha(b)==DOCS[p] and b==edit['after_text'].encode() and sha(oldbytes(p))==edit['before_sha256'])
check('dated package-audit complete prefix preserved',(REPO/'docs/package-audit.md').read_bytes().startswith(oldbytes('docs/package-audit.md')))
check('report equals context with actual substitutions and no placeholders',report_raw==c['report_markdown'].encode() and not re.search(r'<(?:ACTUAL_|PR351_|POST_PR351_)',report_raw.decode()))
for link in re.findall(r'\]\(([^)]+)\)',report_raw.decode()):
 if not re.match(r'^[a-zA-Z]+:',link) and not link.startswith('#'):check('report link '+link,(REPO/REPORT.parent/link.split('#')[0]).exists())
check('report counts and open acceptance scopes',all(s in report_raw.decode() for s in ['twelve scoped tasks','104 task IDs/order, 46 notes','seven fields in three legacy rows','six named branches','All 27 PowerShell fixtures','final record-bearing source remain pending','does not qualify or approve PR353','Tier R Ghidra import-only provisioning']))
check('manifest scope and exact evidence set',len(manifest['payloads'])==87 and manifest['lists_itself'] is False and manifest['source_commit']==SOURCE and manifest['source_tree']==TREE and manifest['prior_actual_main_merge']==MERGE and {p.name for p in (REPO/EV).iterdir()}=={r['path'] for r in manifest['payloads']}|{'manifest.json'})
for r in manifest['payloads']:
 b=(REPO/EV/r['path']).read_bytes();check('manifest payload '+r['path'],len(b)==r['bytes'] and sha(b)==r['sha256'])
check('84 static bindings and exact three generated payloads',len(c['static_evidence_inputs'])==len({x['destination'] for x in c['static_evidence_inputs']})==84 and {x['path'] for x in manifest['payloads']}-{x['destination'] for x in c['static_evidence_inputs']}=={'prior-ledger-d667.json','promotion-and-recovery-context.json','records-assembly-helper.py'})
for r in c['static_evidence_inputs']:
 b=(ROOT/r['source']).read_bytes();check('exact copied input '+r['destination'],b==(REPO/EV/r['destination']).read_bytes() and len(b)==r['bytes'] and sha(b)==r['sha256'])
 if r['destination'].endswith('.zip'):
  with zipfile.ZipFile(ROOT/r['source']) as z:check('retained ZIP CRC '+r['destination'],z.testzip() is None)
helper=(ROOT/'assemble_windows_recovery_records.py').read_bytes();planner=(ROOT/'prepare_windows_record_publication.py').read_bytes()
check('exact embedded context',(REPO/EV/'promotion-and-recovery-context.json').read_bytes()==context_raw)
check('reviewed helper unchanged and exact embedded bytes',sha(helper)=='7f8026469f7b5251236fef89384ce4eb70b722c20ee3988e77e229109a926260' and helper==(REPO/EV/'records-assembly-helper.py').read_bytes())
check('reviewed first-parent planner unchanged',sha(planner)=='075354bd5516bf8e5750ddb72ea99907ad9b8fe72be6ab40326c25131561bac8')
check('all frozen output bytes unchanged throughout review',(ROOT/'windows-recovery-records-context.json').read_bytes()==context_raw and git('status','--porcelain=v1','--untracked-files=all','-z')==status and all(sha((REPO/r['path']).read_bytes())==r['sha256'] for r in inventory))
(OUT/'assembled-file-inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
for p in ALLOWED:
 dest=OUT/'reviewed-documents'/p;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(REPO/p,dest)
for name,b in {'context-reviewed.json':context_raw,'manifest-reviewed.json':manifest_raw,'prior-ledger.json':old_raw,'helper-reviewed.py':helper,'planner-reviewed.py':planner,'status-reviewed.txt':status.replace(b'\0',b'\n')}.items():(OUT/name).write_bytes(b)
result={'schema':'patchtrace/final-assembled-record-checks/1','reviewed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':SOURCE,'source_tree':TREE,'merge_head':MERGE,'proposed_local_parents':[SOURCE,MERGE],'proposed_remote_parents':[REMOTE,MERGE],'computed_complete_tree_without_git_writes':candidate_tree,'files':96,'file_bytes':45660375,'payloads':87,'static_inputs':84,'ledger_tasks':116,'notes':46,'new_tasks':12,'unchanged_original_tasks':99,'modified_original_tasks':sorted(changed),'context_sha256':sha(context_raw),'report_sha256':sha(report_raw),'manifest_sha256':sha(manifest_raw),'checks':CHECKS,'check_count':len(CHECKS),'blockers':[],'product_tests_run':0,'source_ref_index_mutations':False}
(OUT/'record-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks':len(CHECKS),'computed_tree':candidate_tree,'files':96,'record_checks_sha256':sha((OUT/'record-checks.json').read_bytes())}))
