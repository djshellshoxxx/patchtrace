"""Read-only verification of newly assembled observation evidence; no source execution."""
import hashlib
import io
import json
import re
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/workspace/scratch/837fe19aae3a')
OUT = ROOT / 'evidence/windows-recovery-records-independent/final-assembled'
EV = ROOT / 'PatchTrace-windows-recovery-followup/docs/engineering/evidence/cycle837fe-windows-recovery-20261121'
HEAD = '4202e5e79e2aea6366c75261d74544ea48368ca5'
TREE = 'dffeed541749850ef54a130cec0fa56c0fd2f01c'
RUN = 44901791862
ARCHIVE = 'c3b458661d69e26e203d739c0c82d143cc8a4a29d9e571f099c2cf4bda62a120'
checks = []

def check(label, value):
    assert value, label
    checks.append(label)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def j(data):
    return json.loads(data)

def open_verified(path, digest, count, manifest_name):
    data = path.read_bytes()
    check(path.name + ' exact archive', sha(data) == digest)
    z = zipfile.ZipFile(io.BytesIO(data))
    check(path.name + ' members and CRC', len(z.namelist()) == count and len(set(z.namelist())) == count and z.testzip() is None)
    m = j(z.read(manifest_name))
    check(path.name + ' complete manifest', set(z.namelist()) == {x['path'] for x in m['files']} | {manifest_name})
    for x in m['files']:
        b = z.read(x['path'])
        check(path.name + ':' + x['path'], len(b) == x['bytes'] and sha(b) == x['sha256'])
    return z, m

base, bm = open_verified(EV / 'native-code-two-mode-snapshot.zip', '71657059f356fe7996121b0bd9dbb999c3aaddeba00f9d7fe09cddff3a409623', 17, 'evidence-manifest.json')
delta, dm = open_verified(EV / 'native-code-completion-delta.zip', '5a1dbe04233b04e3b60373ac0953ff077c5885e5e8c107958c22c04d1e4c5a7a', 22, 'completion-delta-evidence-manifest.json')
pr, pm = open_verified(EV / 'pr353-independent-source-review.zip', '5426060e7c21f744d356eb8ebe9b48a26ddd6f682a724c2e87dddfeddcfbe70a', 73, 'evidence-manifest.json')
check('native companion binds prior immutable snapshot', dm['companion_base_archive']['sha256'] == sha((EV/'native-code-two-mode-snapshot.zip').read_bytes()) and dm['companion_base_archive']['manifest_sha256'] == sha(base.read('evidence-manifest.json')))
check('native delta does not duplicate prior payload', not (set(base.namelist()) & set(delta.namelist())))
old = j(base.read('summary.json'))
new = j(delta.read('completed-native-checkpoint.json'))
check('copied two-mode summary exact', (EV/'native-code-two-mode-summary.json').read_bytes() == base.read('summary.json'))
check('copied complete checkpoint exact', (EV/'native-code-completed-checkpoint.json').read_bytes() == delta.read('completed-native-checkpoint.json'))
check('old observation retains unfinished three', old['observed_through'] == '2026-11-21 13:05:43 UTC' and old['verdict']['completed_positive_case_count'] == 2 and not old['verdict']['full_five_case_native_qualification_complete'] and len(old['remaining_three_native_cases_at_snapshot_cut']) == 3 and all(x['conclusion'] is None for x in old['remaining_three_native_cases_at_snapshot_cut']))
check('later observation exact separate source', new['observed_at'] == '2026-11-21 13:13:46 UTC' and new['source']['head_sha'] == HEAD and new['source']['complete_tree_sha'] == TREE and new['source']['run_id'] == RUN)
check('complete checkpoint retains final-source and Windows gates', new['verdict']['all_five_native_contracts_passed'] and not new['verdict']['complete_repository_qualification_claimed'] and not new['verdict']['final_record_bearing_source_qualified'] and not new['verdict']['actual_windows_27_case_gate_qualified'])
run = j(delta.read(f'final-run-{RUN}.json'))
check('actual completed run metadata', run['id'] == RUN and run['head_sha'] == HEAD and run['event'] == 'push' and run['run_attempt'] == 1 and run['status'] == 'completed' and run['conclusion'] == 'success')
jobs = j(delta.read('final-job-records.json'))
check('five complete API jobs', len(jobs) == 1 and jobs[0]['run_id'] == RUN and jobs[0]['total_count'] == 5 and len(jobs[0]['jobs']) == 5)
by_id = {x['id']: x for x in jobs[0]['jobs']}
check('checkpoint job set exact', set(by_id) == {x['job_id'] for x in new['jobs']})
logs = {}
for x in new['jobs']:
    ident = x['job_id']; z = base if x['raw_log'] in base.namelist() else delta
    log = z.read(x['raw_log']).decode(); logs[ident] = log
    api = by_id[ident]
    check(f'{ident} actual success and source', api['head_sha'] == HEAD and api['run_id'] == RUN and api['run_attempt'] == 1 and api['conclusion'] == 'success' and api['status'] == 'completed')
    check(f'{ident} checkout output', bool(re.search(r'^\S+Z\s+' + HEAD + r'\s*$', log, re.M)))
    receipt = j(z.read(f'original-ghidra-archive-cache-{ident}.json'))
    check(f'{ident} archive observation source', receipt['source_head'] == HEAD and receipt['run_id'] == RUN and receipt['checkout_sha'] == HEAD and receipt['archive_sha256'] == ARCHIVE)
    c = receipt['original_archive_cache']; expected = 'miss' if ident == 136839042813 else 'hit'
    check(f'{ident} exact cache mode', c['status'] == expected)
    for field in ['miss_lines', 'hit_lines', 'verification_lines', 'post_save_lines', 'post_save_skip_lines']:
        for line in c.get(field, []):
            check(f'{ident} raw log {field}', line in log)
    check(f'{ident} original exact archive verified', len(c['verification_lines']) == 1 and f'Verified Ghidra archive SHA-256: ghidra-archive/ghidra.zip ({ARCHIVE})' in c['verification_lines'][0])
    step = c['fresh_extraction_step']
    check(f'{ident} real successful archive step', step in api['steps'] and step['status'] == 'completed' and step['conclusion'] == 'success')
    t = datetime.fromisoformat(c['verification_lines'][0].split(' ', 1)[0])
    check(f'{ident} hash inside extraction step', datetime.fromisoformat(step['started_at']) <= t <= datetime.fromisoformat(step['completed_at']))
    check(f'{ident} positive lines source', all(line in log for line in receipt.get('native_positive_lines', [])))
check('exact one cold and four warm', new['original_ghidra_archive_cache']['cold_miss_and_save_count'] == 1 and new['original_ghidra_archive_cache']['warm_restore_count'] == 4)
positives = new['native_outcomes']['positive_known_patch_variants']
check('three positive known-patch contracts', {x['job_id'] for x in positives} == {136839042813,136839043092,136839043125} and all(x['accepted_change_records'] == 1 and 'Known patch accepted: 1 change records' in logs[x['job_id']] for x in positives))
neg = new['native_outcomes']['expected_negative_plain_ghidriff_control']
check('negative remains negative', neg['job_id'] == 136839043120 and not neg['positive_analysis_claimed'] and all(x in logs[neg['job_id']] for x in neg['actual_error_lines']) and any('FileExistsError:' in x for x in neg['actual_error_lines']))
for x in new['artifacts']:
    ident = x['artifact']['id']; z = base if x['receipt'] in base.namelist() else delta
    rec = j(z.read(x['receipt'])); data = z.read(rec['local_original_zip'])
    check(f'artifact {ident} API digest', rec['artifact']['workflow_run']['head_sha'] == HEAD and rec['artifact']['workflow_run']['id'] == RUN and len(data) == rec['local_zip_bytes'] == x['bytes'] and sha(data) == rec['local_zip_sha256'] == x['sha256'] and rec['artifact']['digest'] == 'sha256:' + sha(data))
    az = zipfile.ZipFile(io.BytesIO(data))
    check(f'artifact {ident} CRC and member coverage', az.testzip() is None and set(az.namelist()) == {r['name'] for r in rec['members']})
    for r in rec['members']:
        b = az.read(r['name']); check(f'artifact {ident}:{r["name"]}', len(b) == r['bytes'] and sha(b) == r['sha256'])
raw = j(delta.read('application-raw-cache-result.json'))
check('raw cache remains distinct exact result', raw == new['native_outcomes']['application_raw_cache'] and raw['job_id'] == 136839043113 and raw['source_head'] == HEAD and raw['run_id'] == RUN)
with zipfile.ZipFile(io.BytesIO(delta.read('artifacts/14708740674/original.zip'))) as az:
    first = j(az.read('live-cache-diagnostics/first.json')); second = j(az.read('live-cache-diagnostics/second.json')); result = j(az.read('live-cache-diagnostics/result.json'))
check('actual diagnostics complete and match', first['run']['status'] == second['run']['status'] == 'completed' and result['status'] == 'passed' and first['match_count'] == second['match_count'] == 1)
check('actual diagnostics raw-cache equality', first['raw_sha256'] == second['raw_sha256'] == raw['first_raw_sha256'] == raw['second_raw_sha256'] == '4a6851a1d77afdf1471a77144b4f64f538d572eaa275ff9f71dab4bdfee2ee22')
check('actual second diagnostics cache event', {'stage':'cache','message':'raw output reused from cache'} in second['events'])
check('diagnostics copied accurately', first['run'] == raw['first_run'] and second['run'] == raw['second_run'] and first['java_probes'] == raw['java_probes_first'] and second['java_probes'] == raw['java_probes_second'])

def cases(z, name):
    rows = ET.fromstring(z.read(name)).findall('.//testcase')
    ids = {(x.attrib.get('classname'),x.attrib['name']) for x in rows}
    check(name + ' unique testcase identities', len(ids) == len(rows))
    result = {k:set() for k in ('passed','failed','errors','skipped')}
    for x in rows:
        outcome = 'errors' if x.find('error') is not None else 'failed' if x.find('failure') is not None else 'skipped' if x.find('skipped') is not None else 'passed'
        result[outcome].add((x.attrib.get('classname'),x.attrib['name']))
    return result

pr_review = j(pr.read('review.json'))
check('PR353 copied review exact', (EV/'pr353-independent-review.json').read_bytes() == pr.read('review.json'))
check('PR353 exact scope and holds', pr_review['head'] == 'd0a4bdf439775999340ea760d96a087e032ee6dd' and not pr_review['merge_approved'] and not pr_review['release_ready'] and pr_review['final_author_hold_present'] and not pr_review['hosted_full_native_or_package_qualification_claimed'] and not pr_review['tests']['one_clean_158_case_invocation_claimed'])
before_bad = cases(pr,'author-regressions-before-fix.xml'); before = cases(pr,'author-regressions-before-fix-resumed.xml')
initial = cases(pr,'current-maintained.xml'); retry = cases(pr,'current-setup-errors-resumed.xml')
check('PR353 original setup errors preserved', len(before_bad['errors']) == 2 and sum(map(len,before_bad.values())) == 2)
check('PR353 original regression red two', len(before['failed']) == 2 and sum(map(len,before.values())) == 2)
check('PR353 initial 142 pass and 16 setup errors', len(initial['passed']) == 142 and len(initial['errors']) == 16 and not initial['failed'] and not initial['skipped'])
check('PR353 retry exact failed setup IDs only', retry['passed'] == initial['errors'] and len(retry['passed']) == 16 and not retry['failed'] and not retry['errors'] and not retry['skipped'])
check('PR353 158 distinct eventually passing', len(initial['passed'] | retry['passed']) == 158 and not (initial['passed'] & retry['passed']))

page = j((EV/'main3a-preassembly-jobs-snapshot.json').read_bytes())
check('Pages immutable cut actual main', page['observed']['current_time'] == '2026-11-21 13:22:29 UTC' and page['observed_head'] == '3a16290c0fcc4e0c21712fe10474a3ff33fad336' and page['live_branch_ref']['object']['sha'] == page['observed_head'])
pagejobs = [x for group in page['jobs'] for x in group['jobs'] if x['id'] == 136853186416]
check('Pages queued at exact cut', len(pagejobs) == 1 and pagejobs[0]['status'] == 'queued' and pagejobs[0]['runner_id'] == 0 and pagejobs[0]['steps'] == [] and pagejobs[0]['conclusion'] is None)

validation = ROOT/'evidence/windows-recovery-record-preparation/assembled-validation'
vz, vm = open_verified(validation/'assembled-record-validation.zip','79785eefad9678ae92a1af424be9d1d081ec3c46133fab530a327e5315b7a03f',12,'evidence-manifest.json')
q = j(vz.read('record-qualification.json'))
check('assembled validation exact advertised result', sha(vz.read('record-qualification.json')) == 'bb0b08a5076602ac22f4ce496f2cf873e6487d2669e1014a83473656dfa59b07' and q['context_sha256'] == 'e270f9a8ba5e0891b8045156068c9ab3d254f75899bd609d3759f6346be79d3e' and q['pre_review_manifest_sha256'] == 'f27d58dc196f6f4ff9c52673f52efc06c45fbf92dbdf5507f8fc922723f729f1')
reg = cases(vz,'registry.xml')
check('actual registry 111 pass', len(reg['passed']) == 111 and not reg['failed'] and not reg['errors'] and not reg['skipped'])
check('root four bounded commands passed', len(q['commands']) == 4 and all(x['exit'] == 0 for x in q['commands']) and q['source_code'] == 'f596471b8909ec8e28e0624041d60f03d520591d')
check('root source binding stdout', '/PatchTrace-windows-recovery-followup/src/patchtrace/__init__.py' in vz.read('binding.stdout').decode())
(OUT/'root-assembled-record-validation.zip').write_bytes((validation/'assembled-record-validation.zip').read_bytes())
(OUT/'root-record-qualification.json').write_bytes(vz.read('record-qualification.json'))
result = {'schema':'patchtrace/final-assembled-new-evidence-checks/1','reviewed_utc':datetime.now(timezone.utc).isoformat(),'check_count':len(checks),'checks':checks,'blockers':[],'native_source':HEAD,'native_source_tree':TREE,'native_run':RUN,'native_completed_cases':5,'archive_cache_modes':{'cold_miss_save':1,'warm_restored_checksum_checked':4},'raw_cache_proof_separate':True,'immutable_two_mode_cut_preserved':True,'pr353_results':{'initial_passed':142,'initial_setup_errors':16,'retry_passed':16,'distinct_passed':158,'one_clean_158_invocation_claimed':False},'pages_observation_cut':'2026-11-21 13:22:29 UTC','root_registry_passed':111,'new_product_native_tests_run':0,'mutations_to_source_refs_index':False}
(OUT/'new-evidence-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'checks':len(checks),'sha256':sha((OUT/'new-evidence-checks.json').read_bytes()),'blockers':[]}))
