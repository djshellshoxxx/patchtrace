# Final assembled records — independent review

**Verdict: clear for the bounded records commit and publication preparation. No blocking record or provenance finding.** This is not final-source hosted acceptance or permission to merge an unqualified head.

## Exact reviewed snapshot

The worktree remains on local source `f596471b8909ec8e28e0624041d60f03d520591d`, tree `dffeed541749850ef54a130cec0fa56c0fd2f01c`, with deliberate `MERGE_HEAD` `3a16290c0fcc4e0c21712fe10474a3ff33fad336`. The proposed ordered local parents are the source followed by that actual PR351 merge; the remote equivalent uses `4202e5e79e2aea6366c75261d74544ea48368ca5` followed by the same actual merge. The remote code tree equals the local source tree.

The 96 assembled outputs total **45,660,375 bytes**. They comprise eight records/document paths and an evidence directory containing 87 payloads plus its manifest. A pure in-memory reconstruction from Git's complete source tree and the 96 exact file blobs yields pre-append tree **`11b75e5d8f38876c6c1694d69012b6c7426ea08b`**. The reconstruction first reproduced the known source tree. No index, Git object, ref, source, PR or CI change was made by this review.

The context is `e270f9a8ba5e0891b8045156068c9ab3d254f75899bd609d3759f6346be79d3e`, report `d0976daac793cb7512b0b052ef665dc2c723860c8016d2452291101dd8b132ed`, and frozen pre-review manifest `f27d58dc196f6f4ff9c52673f52efc06c45fbf92dbdf5507f8fc922723f729f1`. All 84 static inputs match their source files and declared sizes/hashes; all 87 manifest payloads and archive CRCs pass. All tracked files outside the approved record/document paths retain their source identities.

## Ledger and history preservation

All **104 original task IDs and ordering**, all **46 original notes**, all prior continuation history and unrelated top-level objects are preserved. There are **12 new tasks**, for **116 total**. Ninety-nine original task objects are unchanged. The five changed original rows are the two C5/Pages promotion rows and the three separately reviewed legacy reconciliations. Every changed row has a complete deep before-snapshot. The legacy reconciliation changes exactly seven permitted fields and uses MERGED, BLOCKED and TESTING as reviewed.

The actual PR351 proof gates both source promotions. Old test results and C5 qualification remain in history. Exactly one fulfilled C5 publication/qualification/merge gate is removed; all four broader gates retain their exact prior text. Current source identity is f596, release readiness and main merge eligibility remain false, and final-source qualification remains pending. The original **181 unmatched / 16 patch-equivalent** historical census is unchanged. Six named historical dispositions retain full branch scope, failures and limited conclusions. PR353/355 bounded reviews preserve author holds and do not integrate their source.

The old handoff, QA and todo bytes are exact suffixes behind the new observation. The three current-document replacements match their previous independent clearance: Windows uses the actual NSIS/uninstall behavior, the release graph includes the current Qt/downloaded-artifact gates and correct names/holds, and the dated package audit remains an exact byte prefix with a current clarification appended.

## Actual promotion and observed native evidence

The separate included promotion review performed 166 checks against the actual fetched Git object, fresh PR/main/merge API reads and sealed qualification. PR351 actually merged at 12:58:35 UTC to `3a16290c0fcc4e0c21712fe10474a3ff33fad336`, tree `6001ef506c38930fd590bd827f428b997c3b2797`, ordered parents 9023761 then d6679abc. Both opt-out markers occur separately in the actual subject and body. The two applicable runs contain 15 successful executed jobs and two intentional skips. Linux full results are 24,295 passed / 53 skipped / 4 expected failures; Windows results are 24,164 passed / 185 skipped / 3 expected failures. Those counts remain scoped to PR351 and are not transferred to f596.

The new native evidence binds branch-push source 4202/tree dff, run 44901791862 attempt 1. All five actual checkout logs and completed job metadata match. The five contracts include three positive known-patch variants, one expected negative plain-ghidriff control and one application raw-cache contract. The tool archive evidence proves **one cold miss/save and four warm restores**, each with the original pinned SHA-256 checked during the successful fresh-extraction step. Its original ZIP cache proof remains separate from application raw-analysis cache reuse. The raw-cache diagnostics independently match the recorded two completed analyses, equal raw hashes and explicit second-run cache event. Four retained small analysis artifacts match API digests, nested member manifests and CRCs.

The earlier 13:05:43 two-mode snapshot still contains three pending cases. The separate 13:13:46 completion delta adds the final five-case result without rewriting that earlier snapshot. Neither source-specific checkpoint claims qualification of the later records head, the 27 Windows PowerShell cases, cross-ref/OS cache reuse or independent analysis determinism. The immutable main Pages snapshot correctly remains queued at its 13:22:29 observation cut; later reported success is separate telemetry, not part of this reviewed frozen snapshot.

PR353's copied result is accurately represented as 142 initial passes with 16 retained setup errors, followed by a separate 16-case retry: 158 distinct cases eventually pass, not one clean 158-case invocation. Original two setup errors, the corrected two intended parent failures and author qualification holds remain available.

## Validation and limits

This final review performed **419 record/preservation checks plus 255 evidence/qualification checks: 674 new mechanical checks**, with no source/product/native test execution. The root's sealed assembled-record validation contains 111 registry passes, whole-tree Ruff, pip check and source binding; its XML and archive were verified, not rerun. Those registry cases overlap prior selections. Previous source reviews and their red evidence remain immutable.

The unchanged assembly helper enforces actual fetched-merge identity/tree/parents/markers, source-chain identities, baseline and whole-row guards, deep snapshots and an exact output allowlist. The unchanged publication planner requires a clean actual final commit, the two ordered parents, both markers and one first-parent record-only delta. It was not executed on this uncommitted snapshot.

Before any main promotion, the later record-bearing head still needs required exact-source hosted full/Qt/platform/native qualification and actual Windows PowerShell execution. Both strict C5 expected failures and broader dependency/hash closure, Tier R producer/coverage/environment limitations, manual/trust/accessibility/provenance/L1-L3 gates and other workers' ownership holds remain open. No release, tag or deployment completion is claimed.

## Permitted proof-only append

Root may append these immutable review JSON/ZIP and external seal receipt, its already sealed validation JSON/ZIP, and an exact copy of the frozen pre-review manifest, then refresh only the outer evidence manifest. All original current docs, ledger/task/history objects, context, report and protected source bytes must remain unchanged. This receipt covers the pre-append tree and manifest; the later outer manifest can bind this receipt without a circular self-hash. The final local and remote commit objects still require a bounded identity/tree/ordered-parent/marker check after creation.

Machine-readable details are in `review.json`, `record-checks.json`, `new-evidence-checks.json` and the 96-file inventory. Full current record/document copies, the old raw ledger, context, helper, planner, promotion review and small validation archive are retained here. Large payloads are immutably bound by the copied outer manifest and exact inventory rather than duplicated again.
