"""Plan only the final records delta onto the verified remote Windows code object.

No Git object creation, ref movement, PR operation, or qualification claim.
"""
from pathlib import Path
import json
import subprocess

ROOT=Path('/workspace/scratch/837fe19aae3a')
REPO=ROOT/'PatchTrace-windows-recovery-followup'
LOCAL_CODE='f596471b8909ec8e28e0624041d60f03d520591d'
REMOTE_CODE='4202e5e79e2aea6366c75261d74544ea48368ca5'
CODE_TREE='dffeed541749850ef54a130cec0fa56c0fd2f01c'
EVIDENCE='docs/engineering/evidence/cycle837fe-windows-recovery-20261121/'
ALLOWED={'docs/engineering/task-ledger.json','docs/engineering-handoffs/cycle837fe-combined-pr349-20261121.md',
         'docs/qa.md','tasks/todo.md','docs/release-process.md','docs/windows.md','docs/package-audit.md',
         'docs/engineering/cycle837fe-windows-recovery-20261121.md'}
def git(*args):
 return subprocess.check_output(['git',*args],cwd=REPO,text=True).strip()
assert not git('status','--porcelain=v1'),'Dirty final records checkout'
head=git('rev-parse','HEAD');assert head!=LOCAL_CODE,'No final records commit yet'
context=json.loads((REPO/EVIDENCE/'promotion-and-recovery-context.json').read_text())
promotion=context['verified_pr351_promotion'];merge=promotion['merge_commit']
assert promotion['merged'] and promotion['all_applicable_automated_jobs_passed'] and promotion['opt_outs_verified']
assert git('show','-s','--format=%P',head).split()==[LOCAL_CODE,merge],'Unexpected final record ancestry'
assert git('rev-parse',merge+'^{tree}')=='6001ef506c38930fd590bd827f428b997c3b2797'
assert git('rev-parse',LOCAL_CODE+'^{tree}')==git('rev-parse',REMOTE_CODE+'^{tree}')==CODE_TREE
message=git('show','-s','--format=%B',head);subject,_,body=message.partition('\n')
assert all(marker in subject and marker in body for marker in ['[no release]','[no deploy]'])
raw=subprocess.check_output(['git','diff-tree','-r','--no-commit-id','--no-renames','--raw','-z',LOCAL_CODE,head],cwd=REPO).split(b'\0')
entries=[];blobs={}
for i in range(0,len(raw)-1,2):
 parts,path=raw[i].decode().split(),raw[i+1].decode();mode,sha=parts[1],parts[3]
 assert path in ALLOWED or path.startswith(EVIDENCE),(path,'not record-only')
 assert mode in ('100644','100755') and sha!='0'*40,'No deletion or non-file allowed'
 entries.append(dict(path=path,mode=mode,type='blob',sha=sha));blobs.setdefault(sha,dict(sha=sha,path=path,bytes=int(git('cat-file','-s',sha))))
assert entries
plan=dict(schema='patchtrace/windows-record-publication-plan/1',repo=str(REPO),local_head=head,
          local_parents=[LOCAL_CODE,merge],remote_parents=[REMOTE_CODE,merge],tree=git('rev-parse','HEAD^{tree}'),
          base_tree=CODE_TREE,message=message,author=git('show','-s','--format=%an <%ae>',head),
          author_date=git('show','-s','--format=%aI',head),entries=entries,blobs=list(blobs.values()),
          diff_scope='Exactly one first-parent records delta; never general rev-list over merge parents',
          ref_movement_authorized_by_plan=False,hosted_qualification_claimed=False)
target=ROOT/'windows-recovery-final-publication-plan.json';assert not target.exists(),'Original plan must remain immutable'
target.write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps(dict(path=str(target),head=head,tree=plan['tree'],files=len(entries),blobs=len(blobs),bytes=sum(x['bytes'] for x in blobs.values()))))
