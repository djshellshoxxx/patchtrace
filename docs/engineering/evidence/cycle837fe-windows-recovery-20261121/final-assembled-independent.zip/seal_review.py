"""Seal this review only; never writes the reviewed worktree or Git objects."""
import hashlib
import json
import shutil
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/workspace/scratch/837fe19aae3a')
OUT = ROOT/'evidence/windows-recovery-records-independent/final-assembled'
REPO = ROOT/'PatchTrace-windows-recovery-followup'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def read(name):
    return json.loads((OUT/name).read_text())

def git(*args):
    return subprocess.check_output(['git','-C',str(REPO),*args])

core = read('record-checks.json')
extra = read('new-evidence-checks.json')
inventory = read('assembled-file-inventory.json')
assert core['check_count'] == 419 and extra['check_count'] == 255
assert not core['blockers'] and not extra['blockers']
assert git('rev-parse','HEAD').decode().strip() == core['source']
assert git('rev-parse','MERGE_HEAD').decode().strip() == core['merge_head']
assert git('status','--porcelain=v1','--untracked-files=all') == (OUT/'status-reviewed.txt').read_bytes()
assert not git('diff','--cached','--name-only') and not git('ls-files','-u')
for row in inventory:
    b = (REPO/row['path']).read_bytes()
    assert len(b) == row['bytes'] and sha(b) == row['sha256'], row['path']
assert sha((ROOT/'windows-recovery-records-context.json').read_bytes()) == core['context_sha256']
promotion = ROOT/'evidence/windows-recovery-records-independent/promotion-preparation'
shutil.copyfile(promotion/'promotion-preparation-independent.zip',OUT/'promotion-preparation-independent.zip')
shutil.copyfile(promotion/'review.json',OUT/'promotion-preparation-review.json')
assert sha((OUT/'promotion-preparation-independent.zip').read_bytes()) == '10692d449ab39d3341e4d30f39ac71e33106408facce1a93dfe9bbe68497dd50'
now = datetime.now(timezone.utc).isoformat()
verdict = {
    'schema':'patchtrace/windows-recovery-final-assembled-independent-review/1',
    'reviewer':'codex1_independent_review',
    'reviewed_at':now,
    'verdict':'CLEAR_FOR_BOUNDED_RECORDS_COMMIT_AND_PUBLICATION_PREPARATION',
    'blockers':[],
    'source':core['source'],
    'source_tree':core['source_tree'],
    'remote_source_equivalent':core['proposed_remote_parents'][0],
    'actual_main_merge':core['merge_head'],
    'proposed_local_ordered_parents':core['proposed_local_parents'],
    'proposed_remote_ordered_parents':core['proposed_remote_parents'],
    'reviewed_pre_append_complete_tree':core['computed_complete_tree_without_git_writes'],
    'tree_method':'Pure in-memory Git blob/tree hashing; base hash independently matches f596 tree. No index/object writes.',
    'snapshot':{k:core[k] for k in ('files','file_bytes','payloads','static_inputs','ledger_tasks','notes','new_tasks','unchanged_original_tasks','modified_original_tasks','context_sha256','report_sha256','manifest_sha256')},
    'checks':{'new_record_preservation':419,'new_observation_archive_and_validation_bindings':255,'new_total':674,'prior_actual_promotion_checks':166,'product_or_native_tests_run_by_this_final_review':0,'root_registry_cases_passed':111},
    'ledger':{
        'original_task_count':104,'original_task_ids_and_order_preserved':True,
        'new_tasks':12,'total_tasks':116,'original_notes_exact':46,
        'unchanged_original_task_objects':99,
        'changed_original_task_objects':core['modified_original_tasks'],
        'changed_rows_all_have_deep_before_snapshots':True,
        'two_existing_C5_Pages_rows_promoted_only_after_actual_PR351_merge':True,
        'legacy_reconciliation_exactly_three_rows_seven_fields':True,
        'legacy_states':{'buildenv-header-help-20261121-95fe':'MERGED','historical-audit-gates-cycle2':'BLOCKED','registered-header-help':'TESTING'},
        'old_test_results_and_C5_qualification_preserved':True,
        'C5_only_fulfilled_merge_gate_removed_four_broader_gates_exact':True,
        'all_previous_histories_retained':True,
        'original_historical_census':{'unmatched':181,'patch_equivalent':16,'unchanged':True}
    },
    'documents':{
        'old_handoff_QA_todo_bytes_are_exact_suffixes':True,
        'three_current_doc_replacements_match_prior_independent_clearance':True,
        'old_package_audit_bytes_are_exact_prefix':True,
        'report_relative_links_resolve':True,
        'current_source_and_old_qualification_scopes_separated':True,
        'historical_failures_and_author_holds_retained':True
    },
    'native_evidence':{
        'source':'4202e5e79e2aea6366c75261d74544ea48368ca5',
        'tree':core['source_tree'],'run_id':44901791862,'event':'push','attempt':1,
        'earlier_two_mode_snapshot_cut':'2026-11-21 13:05:43 UTC',
        'later_five_contract_completion_cut':'2026-11-21 13:13:46 UTC',
        'one_cold_archive_miss_and_save':True,'four_warm_restores_checksum_verified':True,
        'three_positive_known_patch_variants':True,'one_expected_negative_control':True,
        'one_application_raw_cache_contract':True,
        'raw_cache_proof_kept_separate_from_original_tool_archive_cache':True,
        'no_cross_ref_OS_or_independent_determinism_inference':True,
        'final_record_head_qualification_claimed':False,
        'actual_Windows_27_case_suite_claimed':False
    },
    'actual_PR351':{
        'head':'d6679abc6dfddbadce0391c8d18289f7f96338d6',
        'merge':core['merge_head'],'tree':'6001ef506c38930fd590bd827f428b997c3b2797',
        'ordered_parents':['9023761a4066ac1c50c127ac09d0ba5f56cdc9e4','d6679abc6dfddbadce0391c8d18289f7f96338d6'],
        'merged_at':'2026-11-21T12:58:35Z','actual_subject_and_body_each_have_both_markers':True,
        'fetched_actual_Git_object_and_fresh_API_checked':True,
        'executed_jobs_passed':15,'intentional_skips':2,'runs':2,
        'full_Linux':{'passed':24295,'skipped':53,'xfail':4},
        'full_Windows':{'passed':24164,'skipped':185,'xfail':3},
        'these_counts_not_attributed_to_f596_or_later_records':True
    },
    'PR353_bounded_review':{'initial_pass':142,'retained_setup_errors':16,'separate_retry_pass':16,'distinct_passing_cases':158,'one_clean_158_invocation_claimed':False,'author_holds_and_full_qualification_pending':True},
    'main_Pages_observation':{'snapshot':'004','cut':'2026-11-21 13:22:29 UTC','state_at_cut':'queued; runner 0; no steps','later_success_telemetry_is_not_part_of_this_frozen_snapshot':True},
    'helper_planner':{
        'helper_sha256':'7f8026469f7b5251236fef89384ce4eb70b722c20ee3988e77e229109a926260',
        'planner_sha256':'075354bd5516bf8e5750ddb72ea99907ad9b8fe72be6ab40326c25131561bac8',
        'actual_fetched_merge_object_identity_tree_ordered_parents_markers_guarded':True,
        'deep_history_before_snapshots_and_output_allowlist_guarded':True,
        'planner_requires_clean_actual_final_commit_and_single_first_parent_record_delta':True,
        'planner_not_executed_on_uncommitted_review_snapshot':True,
        'original_preparation_guard_finding_and_correction_preserved_in_prior_evidence':True
    },
    'bounded_post_review_append':{
        'permitted':'Immutable reviewer JSON/ZIP and external seal receipt; root validation JSON/ZIP; exact preserved pre-review manifest; outer evidence manifest refresh only.',
        'original_96_output_bytes_must_remain_exact_except_outer_manifest':True,
        'current_docs_ledger_tasks_history_context_report_unchanged':True,
        'source_tests_tools_workflows_specs_dependencies_unchanged':True,
        'no_circular_self_hash_required':True,
        'review_covers_pre_append_tree_and_exact_frozen_manifest':True,
        'final_commit_and_remote_equivalent_require_bounded_actual_object_check':True,
        'actual_final_ordered_parents_and_both_markers_still_required':True
    },
    'open_gates':[
        'Exact later record-bearing head must receive required full Linux/Windows, Qt, package, Windows downloaded-artifact and native qualification before guarded main merge.',
        'Actual Windows execution of the 27 focused PowerShell cases remains required; local unavailable-PowerShell skips are not acceptance.',
        'Both strict CODEX-5 expected failures and broader lock/hash closure remain open.',
        'Historical Tier R fresh producer, coverage/environment/blocked lanes and original downloaded-dev-pin gap are not closed by these records.',
        'Manual, trust, accessibility, raw provenance and separate L1/L2/L3 acceptance remain open.',
        'PR352–356 author ownership and qualification holds remain; bounded reviews do not authorize merging those branches.',
        'Release, tag publication and Pages deployment are not authorized or claimed by this review.'
    ],
    'main_merge_eligible':False,'release_ready':False,
    'review_scope':'Read-only record/source preservation and evidence accounting; no new product, native, CI or remote mutation.',
    'source_index_ref_PR_CI_mutations':False,
    'evidence':['record-checks.json','new-evidence-checks.json','assembled-file-inventory.json','manifest-reviewed.json','context-reviewed.json','promotion-preparation-independent.zip','root-assembled-record-validation.zip']
}
(OUT/'review.json').write_text(json.dumps(verdict,indent=2)+'\n')
report = f'''# Final assembled records — independent review

**Verdict: clear for the bounded records commit and publication preparation. No blocking record or provenance finding.** This is not final-source hosted acceptance or permission to merge an unqualified head.

## Exact reviewed snapshot

The worktree remains on local source `{core['source']}`, tree `{core['source_tree']}`, with deliberate `MERGE_HEAD` `{core['merge_head']}`. The proposed ordered local parents are the source followed by that actual PR351 merge; the remote equivalent uses `4202e5e79e2aea6366c75261d74544ea48368ca5` followed by the same actual merge. The remote code tree equals the local source tree.

The 96 assembled outputs total **45,660,375 bytes**. They comprise eight records/document paths and an evidence directory containing 87 payloads plus its manifest. A pure in-memory reconstruction from Git's complete source tree and the 96 exact file blobs yields pre-append tree **`{core['computed_complete_tree_without_git_writes']}`**. The reconstruction first reproduced the known source tree. No index, Git object, ref, source, PR or CI change was made by this review.

The context is `{core['context_sha256']}`, report `{core['report_sha256']}`, and frozen pre-review manifest `{core['manifest_sha256']}`. All 84 static inputs match their source files and declared sizes/hashes; all 87 manifest payloads and archive CRCs pass. All tracked files outside the approved record/document paths retain their source identities.

## Ledger and history preservation

All **104 original task IDs and ordering**, all **46 original notes**, all prior continuation history and unrelated top-level objects are preserved. There are **12 new tasks**, for **116 total**. Ninety-nine original task objects are unchanged. The five changed original rows are the two C5/Pages promotion rows and the three separately reviewed legacy reconciliations. Every changed row has a complete deep before-snapshot. The legacy reconciliation changes exactly seven permitted fields and uses MERGED, BLOCKED and TESTING as reviewed.

The actual PR351 proof gates both source promotions. Old test results and C5 qualification remain in history. Exactly one fulfilled C5 publication/qualification/merge gate is removed; all four broader gates retain their exact prior text. Current source identity is f596, release readiness and main merge eligibility remain false, and final-source qualification remains pending. The original **181 unmatched / 16 patch-equivalent** historical census is unchanged. Six named historical dispositions retain full branch scope, failures and limited conclusions. PR353/355 bounded reviews preserve author holds and do not integrate their source.

The old handoff, QA and todo bytes are exact suffixes behind the new observation. The three current-document replacements match their previous independent clearance: Windows uses the actual NSIS/uninstall behavior, the release graph includes the current Qt/downloaded-artifact gates and correct names/holds, and the dated package audit remains an exact byte prefix with a current clarification appended.

## Actual promotion and observed native evidence

The separate included promotion review performed 166 checks against the actual fetched Git object, fresh PR/main/merge API reads and sealed qualification. PR351 actually merged at 12:58:35 UTC to `3a16290c0fcc4e0c21712fe10474a3ff33fad336`, tree `6001ef506c38930fd590bd827f428b997c3b2797`, ordered parents 9023761 then d6679abc. Both opt-out markers occur separately in the actual subject and body. The two applicable runs contain 15 successful executed jobs and two intentional skips. Linux full results are 24,295 passed / 53 skipped / 4 expected failures; Windows results are 24,164 passed / 185 skipped / 3 expected failures. Those counts remain scoped to PR351 and are not transferred to f596.

The new native evidence binds branch-push source 4202/tree dff, run 44901791862 attempt 1. All five actual checkout logs and completed job metadata match. The five contracts include three positive known-patch variants, one expected negative plain-ghidriff control and one application raw-cache contract. The tool archive evidence proves **one cold miss/save and four warm restores**, each with the original pinned SHA-256 checked during the successful fresh-extraction step. Its original ZIP cache proof remains separate from application raw-analysis cache reuse. The raw-cache diagnostics independently match the recorded two completed analyses, equal raw hashes and explicit second-run cache event. Four retained small analysis artifacts match API digests, nested member manifests and CRCs.

The earlier 13:05:43 two-mode snapshot still contains three pending cases. The separate 13:13:46 completion delta adds the final five-case result without rewriting that earlier snapshot. Neither source-specific checkpoint claims qualification of the later records head, the 27 Windows PowerShell cases, cross-ref/OS cache reuse or independent analysis determinism. The immutable main Pages snapshot correctly remains queued at its 13:22:29 observation cut; later reported success is separate telemetry, not part of this reviewed frozen snapshot.

PR353's copied result is accurately represented as 142 initial passes with 16 retained setup errors, followed by a separate 16-case retry: 158 distinct cases eventually pass, not one clean 158-case invocation. Original two setup errors, the corrected two intended parent failures and author qualification holds remain available.

## Validation and limits

This final review performed **419 record/preservation checks plus 255 evidence/qualification checks: 674 new mechanical checks**, with no source/product/native test execution. The root's sealed assembled-record validation contains 111 registry passes, whole-tree Ruff, pip check and source binding; its XML and archive were verified, not rerun. Those registry cases overlap prior selections. Previous source reviews and their red evidence remain immutable.

The unchanged assembly helper enforces actual fetched-merge identity/tree/parents/markers, source-chain identities, baseline and whole-row guards, deep snapshots and an exact output allowlist. The unchanged publication planner requires a clean actual final commit, the two ordered parents, both markers and one first-parent record-only delta. It was not executed on this uncommitted snapshot.

Before any main promotion, the later record-bearing head still needs required exact-source hosted full/Qt/platform/native qualification and actual Windows PowerShell execution. Both strict C5 expected failures and broader dependency/hash closure, Tier R producer/coverage/environment limitations, manual/trust/accessibility/provenance/L1-L3 gates and other workers' ownership holds remain open. No release, tag or deployment completion is claimed.

## Permitted proof-only append

Root may append these immutable review JSON/ZIP and external seal receipt, its already sealed validation JSON/ZIP, and an exact copy of the frozen pre-review manifest, then refresh only the outer evidence manifest. All original current docs, ledger/task/history objects, context, report and protected source bytes must remain unchanged. This receipt covers the pre-append tree and manifest; the later outer manifest can bind this receipt without a circular self-hash. The final local and remote commit objects still require a bounded identity/tree/ordered-parent/marker check after creation.

Machine-readable details are in `review.json`, `record-checks.json`, `new-evidence-checks.json` and the 96-file inventory. Full current record/document copies, the old raw ledger, context, helper, planner, promotion review and small validation archive are retained here. Large payloads are immutably bound by the copied outer manifest and exact inventory rather than duplicated again.
'''
(OUT/'REVIEW.md').write_text(report)
archive = OUT/'final-assembled-independent.zip'
manifest = OUT/'evidence-manifest.json'
receipt = OUT/'archive-receipt.json'
assert not archive.exists() and not manifest.exists() and not receipt.exists()
files = sorted(x for x in OUT.rglob('*') if x.is_file())
rows = [{'path':str(x.relative_to(OUT)),'bytes':x.stat().st_size,'sha256':sha(x.read_bytes())} for x in files]
manifest.write_text(json.dumps({'schema':'patchtrace/evidence-manifest/1','reviewed_pre_append_tree':core['computed_complete_tree_without_git_writes'],'files':rows,'lists_itself':False,'archive_and_external_receipt_excluded':True},indent=2)+'\n')
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for x in files + [manifest]: z.write(x,str(x.relative_to(OUT)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None and len(z.namelist()) == len(rows)+1
    for row in rows:
        data = z.read(row['path']); assert len(data) == row['bytes'] and sha(data) == row['sha256']
seal = {'schema':'patchtrace/independent-review-seal/1','sealed_at':now,'archive_file':archive.name,'archive_bytes':archive.stat().st_size,'archive_members':len(rows)+1,'archive_sha256':sha(archive.read_bytes()),'manifest_sha256':sha(manifest.read_bytes()),'review_sha256':sha((OUT/'review.json').read_bytes()),'reviewed_pre_append_tree':core['computed_complete_tree_without_git_writes'],'crc_and_all_member_hashes_verified':True,'source_ref_index_PR_CI_mutations':False}
receipt.write_text(json.dumps(seal,indent=2)+'\n')
print(json.dumps(seal,indent=2))
