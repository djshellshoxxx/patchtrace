# Current and historical qualification consistency

At helper b57535b5, setting the current C5-followup status to MERGED would leave its publication/qualification/merge open-gate entry and nested old PENDING fields in place. The two promoted task objects also retained old PENDING test_results as their current results. These were preparation findings; no outputs were applied.

Helper d993f794 resolves them. It retains both original task test_results under historical_prepublication_test_results and the C5 object's old qualification under historical_prepublication_qualification. Current fields use the exact PR351 qualification summary. It requires exactly one occurrence of the fulfilled publication gate and removes only that entry, preserving all four broader C5/native/trust/acceptance gates. Raw-ledger and deep before snapshots preserve every original value as well.
