# Preliminary guard finding

Observed before records application: the helper validates promotion actual_tree, actual_parents, merged, qualification and opt-out fields as context values but does not read the commit object named by promotion.merge_commit. A report-string membership check does not bind that identifier to the claimed Git ancestry/tree/markers. The present context is blocked and no records were applied.

Requested repair: validate the full lowercase merge SHA, commit object type, actual ordered parents, actual tree, and both opt-out markers in the actual commit subject/body, and require agreement with the retained context. Root acknowledged this gap and is preparing the correction. Fresh REST PR/merge/main evidence and final output review remain required; this is not final records clearance.

## Resolution observed

The actual-object guard was added in helper b57535b5 and remains in reviewed helper d993f7943be29f4292cc025795aec975e1e6cb39acd8e9ff5dabc02971cdc0bc. Fourteen detached fictional controls exercise exact shape, wrong object type/tree/parents/identifier/context claims, and missing subject/body holds: one accepted and thirteen refused. Actual PR351 promotion is still absent and is not claimed by these controls. The corrected snapshot arrived before the first filesystem snapshot; its filename explicitly identifies it as corrected. The original gap remains documented above and in the root acknowledgement.
