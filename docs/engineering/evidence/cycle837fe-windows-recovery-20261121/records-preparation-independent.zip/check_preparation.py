"""Read-only preparation checks; no application of records or actual promotion claim."""
import ast
import copy
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import zipfile

ROOT = Path('/workspace/scratch/837fe19aae3a')
OUT = ROOT / 'evidence/windows-recovery-records-independent/preparation'
REPO = ROOT / 'PatchTrace-windows-recovery-followup'
HELPER = OUT / 'helper-d993f794-snapshot.py'
CONTEXT = OUT / 'blocked-context-latest.snapshot.json'
PRIOR = 'd6679abc6dfddbadce0391c8d18289f7f96338d6'
TREE = '6001ef506c38930fd590bd827f428b997c3b2797'
PARENTS = ['9023761a4066ac1c50c127ac09d0ba5f56cdc9e4', PRIOR]
checks, controls = [], []


def sha(b):
    return hashlib.sha256(b).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '--no-optional-locks', '-C', str(REPO), *args])


def check(name, value):
    checks.append({'name': name, 'passed': bool(value)})
    assert value, name


raw = HELPER.read_bytes()
check('Exact corrected helper', sha(raw) == 'd993f7943be29f4292cc025795aec975e1e6cb39acd8e9ff5dabc02971cdc0bc')
source = raw.decode()
tree = ast.parse(raw)
compile(tree, str(HELPER), 'exec')
context = json.loads(CONTEXT.read_bytes())
check('Exact blocked preparation context', sha(CONTEXT.read_bytes()) == 'a93e0de8ca06d4911d4a408f3b74e72a6aadf4afb32d924ecc4447d10a2c615c'
      and context['apply_authorized_now'] is False and bool(context['blockers']))
check('Frozen source and clean branch for refusal control', git('rev-parse', 'HEAD').decode().strip() == '1c70cd5f8053f75c269da673a24a82f221180650'
      and git('rev-parse', 'HEAD^{tree}').decode().strip() == 'a39d650ca7fa2b41ece017ea492396722a4142d9'
      and not git('status', '--porcelain=v1', '--untracked-files=all').strip())
paths = ['docs/engineering/task-ledger.json', 'docs/engineering-handoffs/cycle837fe-combined-pr349-20261121.md',
         'docs/qa.md', 'tasks/todo.md', 'docs/release-process.md', 'docs/windows.md', 'docs/package-audit.md']
before = {p: sha((REPO / p).read_bytes()) for p in paths}
run = subprocess.run(['python', '-I', '-B', str(HELPER), '--repo', str(REPO), '--context', str(CONTEXT)],
                     capture_output=True, text=True, env=dict(os.environ, GIT_OPTIONAL_LOCKS='0'))
(OUT / 'blocked-context-refusal.log').write_text(run.stdout + run.stderr)
after = {p: sha((REPO / p).read_bytes()) for p in paths}
check('Blocked default invocation refuses with no record writes', run.returncode == 1 and 'Prerequisites incomplete' in run.stderr
      and before == after and not git('status', '--porcelain=v1', '--untracked-files=all').strip()
      and not (REPO / 'docs/engineering/evidence/cycle837fe-windows-recovery-20261121').exists())
for item in context['static_evidence_inputs']:
    path = ROOT / item['source']
    content = path.read_bytes()
    check('Evidence hash/size: ' + item['destination'], sha(content) == item['sha256'] and len(content) == item['bytes'])
    if path.suffix == '.zip':
        with zipfile.ZipFile(path) as z:
            check('Evidence CRC: ' + item['destination'], z.testzip() is None)
check('Unique evidence destinations', len(context['static_evidence_inputs']) == len({i['destination'] for i in context['static_evidence_inputs']}))
for edit in context['reviewed_document_replacements']:
    check('Only allowed current document: ' + edit['path'], edit['path'] in {'docs/release-process.md', 'docs/windows.md', 'docs/package-audit.md'})
    old = (REPO / edit['path']).read_bytes()
    check('Current document hash: ' + edit['path'], sha(old) == edit['before_sha256'])
    if edit['path'] == 'docs/package-audit.md':
        check('Entire dated package audit remains exact prefix', edit['after_text'].encode().startswith(old))
ledger_raw = (REPO / paths[0]).read_bytes()
ledger = json.loads(ledger_raw)
check('104 tasks and46 notes exactly bound to original ledger', len(ledger['tasks']) == 104 and len({t['id'] for t in ledger['tasks']}) == 104
      and len(ledger['notes']) == 46 and ledger_raw == git('show', PRIOR + ':' + paths[0]))
check('Deep before snapshots and original history are explicit', all(token in source for token in [
    'ledger = deepcopy(original)', "'previous_codex5_followup': deepcopy(original['codex5_followup_837fe'])",
    "'updated_tasks_before_promotion': [deepcopy(t) for t in original['tasks'] if t['id'] in PROMOTE]",
    "ledger['notes'] == original['notes']", "ledger['continuation_history'][:-1] == original['continuation_history']",
    "[t['id'] for t in ledger['tasks'][:104]] == ids", "before['id'] in PROMOTE or before == after",
    "EVIDENCE / 'prior-ledger-d667.json': original_raw"]))
check('Current versus historical C5 qualification explicitly separated', all(token in source for token in [
    "task['historical_prepublication_test_results'] = deepcopy(task['test_results'])",
    "test_results=deepcopy(context['pr351_qualification_summary'])",
    "historical_prepublication_qualification=deepcopy(original['codex5_followup_837fe']['qualification'])",
    "qualification=deepcopy(context['pr351_qualification_summary'])",
    "['open_gates'].count(completed_gate) == 1", "if gate != completed_gate"]))
gate = 'New CODEX-5 source still requires final publication, applicable hosted/full qualification, and guarded main merge.'
check('Exactly one fulfilled gate and four broader gates in baseline', ledger['codex5_followup_837fe']['open_gates'].count(gate) == 1
      and len([g for g in ledger['codex5_followup_837fe']['open_gates'] if g != gate]) == 4)
check('No writes without apply and all outputs validated first', source.index('if args.apply:') > source.index('Context changed during preparation')
      and source.count('target.write_bytes(content)') == 1)
check('New recovery remains TESTING and not release/merge eligible', 'main_merge_eligible=False, release_ready=False' in source and "'status': 'TESTING'" in source)

main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
def assignment_to(node, name):
    return isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets)
start = next(i for i, n in enumerate(main.body) if assignment_to(n, 'merge'))
end = next(i for i, n in enumerate(main.body) if assignment_to(n, 'review'))
guard = compile(ast.fix_missing_locations(ast.Module(body=copy.deepcopy(main.body[start:end]), type_ignores=[])), '<detached promotion guard>', 'exec')
message = 'Synthetic subject [no release] [no deploy]\n\nSynthetic body [no release] [no deploy]\n'


def fixture(label, accept=False, **changes):
    values = {'id': 'a' * 40, 'type': b'commit', 'tree': TREE, 'parents': PARENTS,
              'claimed_tree': TREE, 'claimed_parents': PARENTS, 'message': message}
    values.update(changes)
    commit = ('tree ' + values['tree'] + '\n' + ''.join('parent ' + x + '\n' for x in values['parents'])
              + 'author Synthetic <test@example.invalid> 1 +0000\ncommitter Synthetic <test@example.invalid> 1 +0000\n\n' + values['message']).encode()
    calls = []

    def fake_git(*args):
        calls.append(args)
        if args == ('cat-file', '-t', values['id']):
            return values['type'] + b'\n'
        assert args == ('cat-file', 'commit', values['id'])
        return commit

    def guard_check(ok, why):
        if not ok:
            raise RuntimeError(why)

    ns = {'promotion': {'merge_commit': values['id'], 'actual_tree': values['claimed_tree'], 'actual_parents': values['claimed_parents']},
          'PRIOR': PRIOR, 'PRIOR_TREE': TREE, 're': re, 'git': fake_git, 'check': guard_check}
    try:
        exec(guard, ns)
    except RuntimeError as exc:
        actual, error = False, str(exc)
    else:
        actual, error = True, ''
    controls.append({'label': label, 'expected_accept': accept, 'accepted': actual, 'error': error, 'fictional_calls': calls})
    check('Detached guard: ' + label, actual == accept)


fixture('Fictional correctly bound object', True)
fixture('Short SHA', id='a' * 39)
fixture('Uppercase SHA', id='A' * 40)
fixture('Noncommit object', type=b'blob')
fixture('Wrong actual tree', tree='b' * 40)
fixture('Reversed actual parents', parents=list(reversed(PARENTS)))
fixture('Additional actual parent', parents=PARENTS + ['c' * 40])
fixture('Missing actual parent', parents=PARENTS[:1])
fixture('Context tree disagrees', claimed_tree='d' * 40)
fixture('Context parents disagree', claimed_parents=list(reversed(PARENTS)))
fixture('Subject missing release hold', message=message.replace('Synthetic subject [no release]', 'Synthetic subject'))
fixture('Body missing deploy hold', message=message.replace('Synthetic body [no release] [no deploy]', 'Synthetic body [no release]'))
fixture('Holds only in subject', message='Subject [no release] [no deploy]\n\nBody\n')
fixture('Holds only in body', message='Subject\n\nBody [no release] [no deploy]\n')

report = {'scope': 'Preliminary preparation only; actual PR351 merge/final context/assembled records not reviewed',
          'helper_sha256': sha(raw), 'context_sha256': sha(CONTEXT.read_bytes()), 'checks_passed': len(checks), 'checks': checks,
          'guard_controls': controls, 'guard_controls_are_fictional': True, 'blocked_exit': run.returncode,
          'record_hashes_before': before, 'record_hashes_after': after, 'input_count': len(context['static_evidence_inputs']),
          'ledger_sha256': sha(ledger_raw), 'tasks': 104, 'notes': 46, 'prior_history_rows': len(ledger['continuation_history']),
          'original_merge_guard_gap': 'Preserved finding; fixed in inspected helper',
          'historical_current_pending_field_gap': 'Preserved finding; fixed in inspected helper',
          'source_helper_context_ref_PR_CI_ledger_mutations': False, 'records_applied': False,
          'remaining': ['Actual PR351 Git/REST promotion evidence', 'Complete final context and evidence hashes', 'Final assembled record/diff/manifest review']}
(OUT / 'preparation-controls.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ['scope', 'helper_sha256', 'context_sha256', 'checks_passed', 'input_count', 'records_applied']}, indent=2))
