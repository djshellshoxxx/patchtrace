# Windows recovery records: independent preparation audit

**The corrected preparation helper is clear within the inspected scope. This is not final records clearance.** The context remains blocked, actual PR351 promotion is not yet available, and no records were applied.

| Bound input | SHA-256 |
|---|---|
| Corrected helper | d993f7943be29f4292cc025795aec975e1e6cb39acd8e9ff5dabc02971cdc0bc |
| Blocked preparation context | a93e0de8ca06d4911d4a408f3b74e72a6aadf4afb32d924ecc4447d10a2c615c |
| Original authoritative ledger | 9d9ae753a9a7d36ec6e9c2b7778bd98b6c6bff006e4216c0f26e1c5620a287a7 |

## Preservation and scope

The baseline contains 104 unique task IDs, 46 notes and six continuation-history entries. The helper deep-copies it, retains original IDs/order, all notes and prior histories, and leaves the other 102 original task objects unchanged. It saves the original raw ledger and deep before snapshots of the two promoted tasks, all overwritten current fields and the complete C5-followup object. The original 181/16 census remains intact.

The prepared inputs imply 35 possible documentation/task/evidence paths. This is a static scope count, not an assembled-output result; the final context may add evidence. There are no runtime, workflow, test or installer writes. Handoff/QA/todo content remains an exact suffix under new current context. Only release-process, Windows instructions and package-audit are allowed current document replacements, each guarded by the original content hash. The complete dated package audit must remain an exact prefix. These proposed document bytes are still unapplied and require final review with the actual promotion records.

## Findings resolved before application

The initial helper accepted merge tree/parents/marker claims from context without binding the named merge SHA to a fetched Git object. The corrected helper requires a full lowercase SHA naming a commit, reads that object, and checks its actual tree and ordered parents against both the expected identities and context. Both publication markers must appear separately in its actual subject and body. The original finding remains in guard-gap.md.

The earlier current C5 object would have retained a fulfilled publication gate and old PENDING qualification fields after its status became MERGED; the two promoted tasks had the analogous nested test_results issue. The corrected helper preserves these values in named historical fields and full before snapshots, replaces current qualification/results with the PR351 summary, and removes only the exactly matched fulfilled gate. All four wider open gates remain. The original consistency finding is retained separately.

## Independent checks

The parent completed 61 source/input/guard checks; the separate preservation subreview completed 25 static/hash checks. Included in the parent count are 14 detached, explicitly fictional Git-object guard controls: one valid structure accepted and 13 wrong identifiers/types/trees/parent orders/context bindings/subject-body marker forms refused. No fictional object was written into a repository or used as promotion evidence.

A default, read-only invocation of the exact helper snapshot against the saved blocked context returned `Prerequisites incomplete` with exit 1. All seven existing record/document hashes were unchanged; the owned source checkout remained clean and no new evidence directory appeared. All 23 declared static inputs matched their sizes and hashes, and ZIP CRCs passed. No helper `--apply` invocation, source edit, ref action, CI operation, native execution or environment change occurred.

## Still required

Final clearance requires the actual PR351 merge object and fresh PR/main/hosted qualification receipts, the completed final context and task additions, and the concrete assembled tree. That audit must verify every old task/history value, complete output/document diffs, source identities, manifest entries and final ancestry. The present controls do not establish an actual merge, successful hosted qualification, record application or publication readiness.
