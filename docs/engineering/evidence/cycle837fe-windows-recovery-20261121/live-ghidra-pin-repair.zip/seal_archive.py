"""Seal this scratch evidence only; never touch a source checkout or Git ref."""
from __future__ import annotations

import hashlib
import json
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ARCHIVE = ROOT / "live-ghidra-archive-pin-repair.zip"
MANIFEST = ROOT / "MANIFEST.json"
RECEIPT = ROOT / "archive-receipt.json"

if ARCHIVE.exists() or MANIFEST.exists() or RECEIPT.exists():
    raise SystemExit("Existing sealed output must not be overwritten")

payloads = []
for path in sorted(ROOT.rglob("*")):
    relative = path.relative_to(ROOT)
    if relative.parts[0] == "tmp" or "__pycache__" in relative.parts or not path.is_file():
        continue
    if path.is_symlink():
        raise SystemExit(f"Unexpected payload symlink: {relative}")
    data = path.read_bytes()
    payloads.append({"path": relative.as_posix(), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()})

MANIFEST.write_text(json.dumps({
    "schema": "patchtrace/evidence-manifest/1",
    "source_head": "f596471b8909ec8e28e0624041d60f03d520591d",
    "source_tree": "dffeed541749850ef54a130cec0fa56c0fd2f01c",
    "excluded": ["tmp/ reproducible pytest scratch data", "external archive and receipt"],
    "files": payloads,
}, indent=2) + "\n", encoding="utf-8")

with zipfile.ZipFile(ARCHIVE, "x", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as output:
    for item in payloads:
        output.write(ROOT / item["path"], item["path"])
    output.write(MANIFEST, MANIFEST.name)

with zipfile.ZipFile(ARCHIVE) as sealed:
    assert sealed.testzip() is None
    assert len(sealed.namelist()) == len(payloads) + 1
    assert len(set(sealed.namelist())) == len(sealed.namelist())
    for item in payloads:
        data = sealed.read(item["path"])
        assert len(data) == item["bytes"]
        assert hashlib.sha256(data).hexdigest() == item["sha256"]
    assert sealed.read(MANIFEST.name) == MANIFEST.read_bytes()

receipt = {
    "archive_file": ARCHIVE.name,
    "archive_sha256": hashlib.sha256(ARCHIVE.read_bytes()).hexdigest(),
    "archive_bytes": ARCHIVE.stat().st_size,
    "manifest_file": MANIFEST.name,
    "manifest_sha256": hashlib.sha256(MANIFEST.read_bytes()).hexdigest(),
    "payload_file_count": len(payloads),
    "zip_members": len(payloads) + 1,
    "archive_crc_verified": True,
    "all_manifest_members_verified": True,
    "head_sha": "f596471b8909ec8e28e0624041d60f03d520591d",
    "head_tree_sha": "dffeed541749850ef54a130cec0fa56c0fd2f01c",
}
RECEIPT.write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt, indent=2))
