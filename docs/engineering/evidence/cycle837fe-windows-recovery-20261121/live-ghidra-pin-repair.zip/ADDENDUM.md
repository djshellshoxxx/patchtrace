# Ghidra pin validation repair — exact child of preserved88

## Frozen identity

Commit `f596471b8909ec8e28e0624041d60f03d520591d`, tree `dffeed541749850ef54a130cec0fa56c0fd2f01c`, direct parent `88df8cfbe51f91a6bc08c6863cd5d63f86500ca0`.
The clean worktree remains `/workspace/scratch/837fe19aae3a/repair-live-ghidra-archive`
on `codex/patchtrace-live-ghidra-archive-20261121-837fe`. Both publication opt-out
markers are present. No amend, reset, history removal or remote mutation occurred.
Root owns integration and future hosted qualification. Source is frozen pending
independent review.

## Narrow defect and correction

Independent review identified GHA-PIN-TERMINAL-LF: the old .NET end-of-line anchor
could accept 64 lowercase hexadecimal characters followed by LF, permitting the
download before the later full digest comparison rejected the value. The actual
committed pin was valid, and extraction remained protected by that comparison.
The original receipt is retained as `prior/review-v1.json`.

The spec now explicitly requires the entire value to be exactly 64 lowercase
hexadecimal characters with no trailing LF or whitespace. That contract was
clarified before the workflow change. The existing registry row reflects strict
entire-value validation. The workflow's only byte change replaces the old anchors
with `\A[0-9a-f]{64}\z`. The source assertion uses the same absolute guard. The
added `terminal-lf` PowerShell parameter checks nonzero exit with no download log,
no runtime extraction and no GITHUB_ENV export. All other native/workflow bytes
are identical to88, as proved in `repair-preservation-proof.json`.

Only the same four owned paths changed: live workflow, existing Windows acceptance
spec, its registry row and `tests/test_live_ghidra_archive.py`. No ledger, QA,
handoff, runtime, pin identity, native assertion, trigger, permission, dependency
or limit changed. No root record/helper or other worktree was edited.

## Red/green and environment

- New source regression against the unchanged88 workflow: **1 failed, 3 passed,
  10 skipped**. The failure names the missing absolute-anchor guard.
- Same seven-module candidate selection, with one additional terminal-LF case:
  **260 passed, 10 skipped, 2 unchanged strict CODEX-5 xfails**; 272 distinct cases,
  1.87 seconds pytest time. These counts overlap the original88 selection.
- Whole `src tests tools` Ruff: passed. Pip check: passed. Whitespace check: passed.
- Current `patchtrace` and `patchtrace.backend` source paths were explicitly
  verified by the retained bootstrap. The frozen Pages environment was reused
  without rebinding or installation; its old editable metadata is disclosed in
  stdout. The bootstrap explicitly selects this worktree's source.

PowerShell is unavailable here. All ten exact-step fixtures, including the new
terminal-LF case, are explicit skips, not runtime passes. Windows QA requires
PowerShell. No PowerShell/native/target execution, archive/dependency download,
full pytest, dispatch or rerun was performed. Original cold/warm/native gates and
both CODEX-5 expected failures remain open.

All stdout, stderr, JUnit and command receipts are retained. Validation truthfully
records parent HEAD with uncommitted candidate source. Those four tested files
were subsequently matched byte-for-byte to the frozen commit. No source edit
occurred after validation.

### Exact final command

CWD: `/workspace/scratch/837fe19aae3a/repair-live-ghidra-archive`. Environment additions: `QT_QPA_PLATFORM=offscreen` and
`PYTHONDONTWRITEBYTECODE=1`.

```sh
/workspace/scratch/837fe19aae3a/pages-config-hold-venv/bin/python -I -B /workspace/scratch/837fe19aae3a/evidence/live-ghidra-archive-pin-repair/run_pytest.py /workspace/scratch/837fe19aae3a/repair-live-ghidra-archive -q --disable-plugin-autoload --import-mode=importlib -p no:cacheprovider --basetemp /workspace/scratch/837fe19aae3a/evidence/live-ghidra-archive-pin-repair/tmp/green --junitxml=/workspace/scratch/837fe19aae3a/evidence/live-ghidra-archive-pin-repair/green-focused.xml tests/test_live_ghidra_archive.py tests/test_corpus_cache_archive_integrity_20261121.py tests/test_corpus_archive_cache_hit_shell_20261121.py tests/test_live_cache_diagnostics.py tests/test_codex_pkg_workflows.py tests/test_codex5_command_audit_20261121.py tests/test_spec_registry.py
```

Ruff uses the same Python with `-I -B -m ruff check --no-cache src tests tools`.
Pip uses `-I -B -m pip check`. Exact argv, timing and results are in the receipts.

## Preserved history and portable evidence

The entire original sealed88 ZIP is copied unchanged into `prior/`, with its
original manifest/receipt. Its SHA-256 remains
`c096caf608c442a51de958701acff3346709349bc024b96e79ffadcd2fc91bd9`.
The source finding is retained. `repair.patch` supplies this child alone, while
that original archive supplies the original88 patch and prior red/green history.
No earlier result was overwritten or relabeled as passing.

The new archive manifest binds all repair source snapshots, exact outputs,
receipts, finding and original sealed archive. Reproducible `tmp/` fixture files
are excluded; failure stdout is retained. The external receipt supplies final
ZIP/manifest hashes, member count and verified CRC/member hashes.
