"""Read-only PR351 evidence checks. Writes only this review's scratch evidence."""

from datetime import datetime, timezone
import fnmatch
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

import yaml


OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
REPO = ROOT / 'repair-live-ghidra-archive'
EVIDENCE = ROOT / 'evidence'
HOSTED = EVIDENCE / 'final-d667-qualification'
HEAD = 'd6679abc6dfddbadce0391c8d18289f7f96338d6'
TREE = '6001ef506c38930fd590bd827f428b997c3b2797'
BASE = '9023761a4066ac1c50c127ac09d0ba5f56cdc9e4'
MERGE = 'a93005c69fe6091b940d7bc9ad1f5a38542e6e71'
LOCAL = '2ae1bbad2ad9cc78c29541872381750e347c670e'
CODE = '0cdd5bf37130206c2ddec399450be6338ae8e4fd'
DONOR = '36b58a7d857690a8bf0093bcee1edd5036189b30'
CHECKS = []
INPUTS = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def check(name, condition, evidence=None):
    CHECKS.append({'check': name, 'passed': bool(condition), 'evidence': evidence})


def preserve(path):
    data = path.read_bytes()
    rel = path.relative_to(EVIDENCE)
    target = OUT / 'inputs' / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    INPUTS.append({'path': rel.as_posix(), 'sha256': sha(data), 'bytes': len(data)})
    return data


def load(path):
    return json.loads(preserve(path))


def archive_review(receipt_rel, manifest_name):
    receipt = load(EVIDENCE / receipt_rel)
    path = Path(receipt['archive'])
    data = preserve(path)
    check(f'{receipt_rel}: archive digest', sha(data) == receipt['sha256'])
    check(f'{receipt_rel}: archive size', len(data) == receipt['bytes'])
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        check(f'{receipt_rel}: CRC', archive.testzip() is None)
        check(f'{receipt_rel}: member count', len(archive.namelist()) == receipt['members'])
        manifest = archive.read(manifest_name)
        if 'manifest_sha256' in receipt:
            check(f'{receipt_rel}: manifest digest', sha(manifest) == receipt['manifest_sha256'])
        if manifest_name.endswith('.sha256'):
            members = [{'path': line.split('  ', 1)[1], 'sha256': line.split('  ', 1)[0]}
                       for line in manifest.decode().splitlines() if line]
        else:
            parsed = json.loads(manifest)
            members = parsed.get('files', parsed.get('members'))
        expected = {entry['path'] for entry in members} | {manifest_name}
        check(f'{receipt_rel}: manifest inventory', set(archive.namelist()) == expected)
        for entry in members:
            payload = archive.read(entry['path'])
            check(f'{receipt_rel}: member {entry["path"]}', sha(payload) == entry['sha256']
                  and ('bytes' not in entry or len(payload) == entry['bytes']))
    return receipt


def main():
    object_proofs = []
    for label, commit in [('head', HEAD), ('synthetic_merge', MERGE), ('base', BASE)]:
        raw = git('cat-file', 'commit', commit)
        check(f'{label}: raw Git object identity',
              hashlib.sha1(f'commit {len(raw)}\0'.encode() + raw).hexdigest() == commit)
        path = OUT / 'git-objects' / f'{commit}.txt'
        path.parent.mkdir(exist_ok=True)
        path.write_bytes(raw)
        tree = git('rev-parse', f'{commit}^{{tree}}').decode().strip()
        parents = git('show', '-s', '--format=%P', commit).decode().split()
        object_proofs.append({'label': label, 'commit': commit, 'tree': tree, 'parents': parents,
                              'raw_sha256': sha(raw)})
        if label != 'base':
            check(f'{label}: exact tree', tree == TREE)
        if label == 'synthetic_merge':
            check('synthetic merge ordered parents', parents == [BASE, HEAD])
        if label == 'head':
            check('published head ordered parents', parents == [
                '06b5ed67c78aac30972e657b4a7ae5a17de739b8', BASE, DONOR])
            check('published head carries both holds', all(x.encode() in raw for x in ['[no release]', '[no deploy]']))
    check('local reviewed final tree equals published tree',
          git('rev-parse', f'{LOCAL}^{{tree}}').decode().strip() == TREE)
    check('runtime tree unchanged from qualified primary main',
          git('rev-parse', f'{HEAD}:src') == git('rev-parse', f'{BASE}:src'))
    check('reviewed code/workflows/tests untouched by final record commit',
          not git('diff', '--name-only', CODE, HEAD, '--', 'src', 'tools', 'tests', '.github'))

    archives = [archive_review(*item) for item in [
        ('codex5-command-audit-independent/final-archive.json', 'MANIFEST.sha256'),
        ('codex5-final-records-independent/pages/archive.json', 'manifest.json'),
        ('codex5-final-records-independent/archive-receipt.json', 'MANIFEST.json'),
        ('codex5-final-publication-independent/archive-receipt.json', 'MANIFEST.json'),
    ]]
    c5 = load(EVIDENCE / 'codex5-command-audit-independent/verdict.json')
    pages = load(EVIDENCE / 'codex5-final-records-independent/pages/review.json')
    records = load(EVIDENCE / 'codex5-final-records-independent/review.json')
    publication = load(EVIDENCE / 'codex5-final-publication-independent/remote-review.json')
    local_review = load(EVIDENCE / 'codex5-final-publication-independent/local-review.json')
    check('independent C5 review no remaining bounded blocker', c5['verdict'].startswith('no-remaining-blocker'))
    for entry in c5['source_blobs'] + pages['file_identities']:
        actual = git('show', f"{HEAD}:{entry['path']}")
        check(f"independent reviewed bytes preserved: {entry['path']}", sha(actual) == entry['sha256'])
    check('independent Pages source review clear', pages['verdict'].startswith('No blocker'))
    check('independent record review clear', not records['blockers'] and records['checks_passed'] == 141)
    check('independent final local record review clear', not local_review['blockers'] and local_review['tree'] == TREE)
    check('independent published object review clear', not publication['blockers']
          and publication['remote_commit'] == HEAD and publication['tree'] == TREE)

    ledger = json.loads(git('show', f'{HEAD}:docs/engineering/task-ledger.json'))
    tasks = {t['id']: t for t in ledger['tasks']}
    check('global release readiness remains false', ledger['release_ready'] is False)
    check('static prepublication main eligibility remains false', ledger['main_merge_eligible'] is False)
    check('broad CODEX5 assessment remains blocked', tasks['837fe-codex5-bounded-assessment']['status'] == 'BLOCKED')
    check('referenced-lock closure remains blocked', tasks['codex5-per-command-audit-gap-20261121-95fe']['status'] == 'BLOCKED')
    c6 = [tasks[x] for x in ['codex6-corpus-cache-archive-20261121', 'codex6-cache-hit-fixture-20261121']]
    for task in c6:
        check(f"{task['id']}: partial native scope retained", task['status'] == 'MERGED'
              and 'Ghidra archive cache remains unverified' in task['acceptance_status']
              and task['blockers'] and '5/11' in task['result_or_next_action'])
    gates = ledger['codex5_followup_837fe']['open_gates']
    for label, text in [('C5', 'Broad CODEX-5'), ('Ghidra archive', 'Ghidra original-archive'),
                        ('Tier R', 'Tier R'), ('manual/accessibility/L1-L3', 'Manual, trust, accessibility, full raw provenance, and separate L1/L2/L3')]:
        check(f'open gate retained: {label}', any(text in gate for gate in gates))
    check('broad native acceptance remains blocked', tasks['native-release-acceptance']['status'] == 'blocked')
    prior = ledger['codex5_followup_837fe']['qualification']['prior_full_attempt']
    check('original unexplained local full failure preserved', prior['exit_code'] == -9
          and prior['wrapper_exit_code'] == 247 and prior['seconds'] == 498.536
          and prior['cause'] == 'unknown' and prior['second_local_full_attempt'] is False)

    workflows = []
    changes = {event: git('diff', '--name-only', old, HEAD).decode().splitlines()
               for event, old in [('pull_request', BASE), ('push', DONOR)]}
    paths = git('ls-tree', '-r', '--name-only', HEAD, '.github/workflows').decode().splitlines()
    check('workflow count remains 21', len(paths) == 21)
    for path in paths:
        data = git('show', f'{HEAD}:{path}')
        target = OUT / 'source' / HEAD / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        workflow = yaml.load(data, Loader=yaml.BaseLoader)
        row = {'path': path, 'sha256': sha(data), 'name': workflow.get('name'),
               'triggers': workflow['on'], 'events': {}}
        for event, branch in [('pull_request', 'main'), ('push', 'codex/patchtrace-codex5-per-command-audit-20261121')]:
            on = workflow['on']
            if event not in on:
                row['events'][event] = {'applicable': False, 'reason': 'no matching event trigger'}
                continue
            config = on[event] or {}
            patterns = config.get('paths')
            branches = config.get('branches')
            assert not config.get('paths-ignore') and not config.get('branches-ignore')
            assert not patterns or all(not x.startswith('!') for x in patterns)
            matches = [changed for changed in changes[event]
                       if any(fnmatch.fnmatchcase(changed, pattern) for pattern in patterns)] if patterns else None
            branch_ok = (not branches or any(fnmatch.fnmatchcase(branch, p) for p in branches))
            branch_ok = branch_ok and not (config.get('tags') and not branches)
            row['events'][event] = {'applicable': bool(branch_ok and (matches is None or matches)),
                                    'branch_matches': bool(branch_ok), 'matched_paths': matches}
        workflows.append(row)
    applicable = {(w['path'], event) for w in workflows for event, v in w['events'].items() if v['applicable']}
    check('bounded actual-event workflow applicability', applicable == {
        ('.github/workflows/qa-windows.yml', 'pull_request'),
        ('.github/workflows/live-backend.yml', 'push')})
    discovery = load(HOSTED / 'run-discovery-20261121T1012Z.json')
    runs = discovery['result']['workflow_runs']
    check('retained run discovery matches bounded applicability', discovery['result']['total_count'] == 2
          and {(r['path'], r['event']) for r in runs} == applicable
          and all(r['head_sha'] == HEAD and r['run_attempt'] == 1 for r in runs))

    junit = []
    for platform, artifact, expected in [('linux', 14704492014, (24295, 53, 4)),
                                         ('windows', 14705395915, (24164, 185, 3))]:
        receipt = load(HOSTED / f'qa-artifact-{platform}-{artifact}.json')
        data = preserve(HOSTED / receipt['local_original_zip'])
        check(f'{platform}: artifact source identity', receipt['source_head'] == HEAD
              and receipt['run_id'] == 44892118810 and receipt['artifact']['workflow_run']['head_sha'] == HEAD)
        check(f'{platform}: original artifact digest', sha(data) == receipt['local_zip_sha256']
              == receipt['artifact']['digest'].removeprefix('sha256:'))
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            check(f'{platform}: original artifact CRC', archive.testzip() is None)
            for member in receipt['members']:
                payload = archive.read(member['name'])
                check(f'{platform}: artifact member {member["name"]}', sha(payload) == member['sha256']
                      and len(payload) == member['bytes'])
            xml = ET.fromstring(archive.read('qa-results.xml'))
        cases = list(xml.iter('testcase'))
        xfails = [{'classname': c.get('classname'), 'name': c.get('name'), 'reason': c.find('skipped').get('message')}
                  for c in cases if c.find('skipped') is not None and c.find('skipped').get('type') == 'pytest.xfail']
        normal_skip = sum(c.find('skipped') is not None and c.find('skipped').get('type') != 'pytest.xfail' for c in cases)
        failures = sum(c.find('failure') is not None for c in cases)
        errors = sum(c.find('error') is not None for c in cases)
        passed = len(cases) - normal_skip - len(xfails) - failures - errors
        check(f'{platform}: exact JUnit outcomes', len(cases) == 24352 and failures == errors == 0
              and (passed, normal_skip, len(xfails)) == expected)
        check(f'{platform}: both CODEX5 expected failures remain',
              {'test_pip_downloads_require_hashes', 'test_all_explicit_workflow_pip_installs_are_protected'}
              <= {c['name'] for c in xfails})
        junit.append({'platform': platform, 'cases': len(cases), 'passed': passed, 'skipped': normal_skip,
                      'xfailed': len(xfails), 'failures': failures, 'errors': errors, 'expected_failures': xfails})

    snapshot_file = max(HOSTED.glob('jobs-snapshot-*.json'), key=lambda p: int(p.stem.rsplit('-', 1)[1]))
    snapshot = load(snapshot_file)
    checkout_proofs = []
    for observation in snapshot['observations']:
        for job in observation['jobs']:
            if job['status'] != 'completed' or job['conclusion'] != 'success':
                continue
            raw_file = HOSTED / f'raw-job-{job["id"]}.json'
            if not raw_file.exists():
                continue  # Newly completed jobs belong to the later sealed-evidence audit.
            raw = json.loads(raw_file.read_text())
            log_path = HOSTED / 'logs' / f'{job["id"]}.log'
            log = log_path.read_text()
            checkouts = re.findall(r'log -1 --format=%H\r?\n[^\n]*? ([a-f0-9]{40})\r?\n', log)
            expected = MERGE if observation['run_id'] == 44892118810 else HEAD
            check(f'job {job["id"]}: checkout identity', checkouts == [expected]
                  and raw['head_sha'] == HEAD and raw['expected_checkout'] == expected)
            checkout_proofs.append({'job_id': job['id'], 'run_id': observation['run_id'],
                                    'checkout': expected, 'log_sha256': sha(log_path.read_bytes()),
                                    'raw_record_sha256': sha(raw_file.read_bytes())})

    check('source worktree remains clean', git('status', '--porcelain=v1') == b'')
    result = {
        'schema': 'patchtrace/pr351-premerge-consistency/1',
        'observed_at_utc': datetime.now(timezone.utc).isoformat(),
        'phase': 'preseal_source_reviews_and_completed_receipts',
        'source': {'head': HEAD, 'tree': TREE, 'base': BASE, 'synthetic_merge': MERGE},
        'verdict': 'PENDING_HOSTED_SEAL' if all(c['passed'] for c in CHECKS) else 'BLOCKED_FINDING',
        'checks': CHECKS, 'mechanical_checks': len(CHECKS),
        'blockers': [c for c in CHECKS if not c['passed']],
        'git_object_proofs': object_proofs, 'preserved_independent_archives': archives,
        'workflow_applicability': workflows,
        'applicability_scope': 'Actual PR delta versus 902 and branch-push delta versus preserved donor36b; positive path/branch filters only; no schedule/manual invocation inferred.',
        'junit': junit, 'checkout_proofs': checkout_proofs,
        'open_gates': gates, 'release_ready': False,
        'pending': 'Await watcher final run/job outcomes, both Ubuntu frozen smokes, actual release skip and sealed archive.',
        'independence_boundary': 'Evidence consistency audit; author-owned C5/Pages implementation relies on preserved C1 source review. No independent self-clearance of authored code.',
        'source_tests_executed': 0, 'remote_mutations': False, 'source_mutations': False,
        'inputs': INPUTS,
    }
    (OUT / 'preseal-review.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'verdict': result['verdict'], 'checks': len(CHECKS), 'blockers': result['blockers'],
                      'completed_checkout_logs': len(checkout_proofs), 'junit': junit}, indent=2))


if __name__ == '__main__':
    main()
