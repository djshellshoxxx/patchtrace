# PR351 final independent premerge evidence review

**CLEAR FOR GUARDED PREMERGE — no blocking evidence inconsistency found.** This conclusion is bound to the sealed PR351 source-specific qualification archive below. Root owns the fresh expected-head merge guard and subsequent actual-main verification; this review does not itself merge or publish anything.

## Exact identity and seal

| Identity | Verified value |
| --- | --- |
| PR head | `d6679abc6dfddbadce0391c8d18289f7f96338d6` |
| Complete tree | `6001ef506c38930fd590bd827f428b997c3b2797` |
| Expected main/base | `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4` |
| Tested synthetic merge | `a93005c69fe6091b940d7bc9ad1f5a38542e6e71` |
| Synthetic ordered parents | `[9023761a4066ac1c50c127ac09d0ba5f56cdc9e4, d6679abc6dfddbadce0391c8d18289f7f96338d6]` |
| Qualification ZIP | `final-d667-evidence.zip`, 2,811,379 bytes, 104 members |
| Qualification ZIP SHA-256 | `a4829fc624a1b9b84313801b41b85782d40fd897290195ace45448918c9dbfb6` |
| Qualification manifest SHA-256 | `95ceaddf821eb906b7e1095de1032c300dd943b6f8c288b2bf2b438b2afadfcc` |
| Final summary SHA-256 | `a82d4a8afac234213eccbb76b8e957020ad5d45fe0bbf65a8c5042b74ad0f788` |

The archive's CRCs, all 103 payload sizes and hashes, exact member inventory, manifest and external final summary were independently verified. Actual Git object identities, ordered ancestry, complete-tree equality to reviewed local `2ae1bbad`, source-preserving final records and all four retained C1 review archives were checked in the preserved preseal phase. Published d667 carries both publication holds.

## Actual final jobs

| Owned run | Event and checkout | Final result |
| --- | --- | --- |
| QA `44892118810`, attempt 1 | `pull_request`; checkout `a93005c6` | Ten executed jobs succeeded: both full suites, all five Qt gates, Linux packaging and both Ubuntu frozen smoke jobs. |
| Native Ghidriff `44892116389`, attempt 1 | `push`; checkout `d6679abc` | All five authored-fixture jobs succeeded, with positive, expected-negative and raw-cache meanings kept separate. |

Exactly **17 jobs** are accounted for: **15 completed successes** and the actual intentional skips `release-gate` **136810020819** and `release` **136850824693**. Every executed job has a source-matching checkout log. The previously audited thirteen logs remained unchanged.

Ubuntu 22.04 job **136843246854** and Ubuntu 24.04 job **136843246894** each have 64 actual PASS lines and zero failures. Both accept Linux artifact **14707060565** with digest `sha256:5ee4bf5f11d1fb51980f4df3c567e4b8fa4fdf88b6d7015542dcfb90d1db2de1`, verify the tar checksum, and complete both offscreen and XCB self-tests. The fresh root guard also records successful Snyk status, no review/thread/ruleset entries and unchanged main/head/synthetic identities.

Linux full QA remains **24,295 passed / 53 skipped / 4 xfailed**; Windows remains **24,164 passed / 185 skipped / 3 xfailed**. Each JUnit contains 24,352 cases and zero failures/errors. Full-suite, Qt repetition, boundary-fixture and frozen-check counts overlap and are not added.

## Limits preserved

Both strict CODEX-5 expected failures remain on both platforms. Linux retains missing `llvm-pdbutil`; both platforms retain missing `--ghidra-dir`. These are seven platform-specific expected-failure records, not passes.

C6 implementation/fixture rows are MERGED, while Ghidra original-archive cache acceptance remains unverified. Tier R's 5/11 completion and native limits remain open. Manual trust/accessibility, full provenance and separate L1/L2/L3 acceptance remain open. Global release readiness remains false. Native Ghidriff records establish three known-patch positives, one expected cached-PDB negative and one within-run raw-cache reuse check; they do not establish Ghidra ZIP cold-save/warm-hit acceptance or transfer acceptance to untriggered native lanes.

Pages has no PR trigger. Actual held configure-skip, successful artifact upload and deploy-skip require the later main push. That observation remains pending. Actual main merge parents/tree and both `[no release]` / `[no deploy]` markers also require post-merge verification.

Earlier timestamped pending observations, the initial primary Pages failure and the unexplained original C5 local SIGKILL remain preserved historical evidence. The final sealed qualification governs completed current-source CI; it does not rewrite those earlier observations.

## Review receipts and independence

- `preseal-review.json`: 348 mechanical checks, zero findings.
- `completed-receipts-review.json`: 66 mechanical checks, zero findings.
- `final-root-guard-delta.json`: 15 mechanical checks, zero findings.
- `final-review.json`: 184 final seal/delta checks, zero findings.

These are read-only evidence-verification counts, not product tests. No suite, native tool, target, install, dispatch or source/ref/PR mutation was performed for this audit. C5 and Pages implementation clearance is attributed to the preserved C1 reviews; this evidence audit does not independently clear the auditor's own source work.

An initial reviewer script expected the preceding archive receipt's integrity-field names and stopped with a `KeyError`. The script, failure output and exact schema adaptation are retained. The corrected verifier uses the actual sealed schema while independently checking ZIP CRCs and every member digest; no qualification evidence or product source was changed.
