"""Verify already-completed hosted receipts without executing product code."""

import io
import json
from pathlib import Path
import sys
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parent))
from audit_static import CHECKS, EVIDENCE, HEAD, HOSTED, INPUTS, OUT, check, load, preserve, sha


def main():
    refs = load(EVIDENCE / 'codex5-final-publication-independent/remote-fresh-reads.json')
    by_label = {entry['label']: entry['response'] for entry in refs['reads']}
    check('retained prepublication main ref establishes PR comparison base',
          by_label['main_ref']['object']['sha'] == '9023761a4066ac1c50c127ac09d0ba5f56cdc9e4')
    check('retained prepublication donor ref establishes push comparison base',
          by_label['donor_ref']['object']['sha'] == '36b58a7d857690a8bf0093bcee1edd5036189b30')
    native = load(HOSTED / 'native-summary.json')
    artifacts = load(HOSTED / 'downloaded-native-artifact-records.json')
    for receipt in artifacts:
        metadata = receipt['artifact']
        check(f'native artifact {metadata["id"]}: run and head',
              metadata['workflow_run']['id'] == 44892116389 and metadata['workflow_run']['head_sha'] == HEAD)
        data = preserve(HOSTED / receipt['local_original_zip'])
        check(f'native artifact {metadata["id"]}: digest', sha(data) == receipt['local_zip_sha256']
              == metadata['digest'].removeprefix('sha256:'))
        with zipfile.ZipFile(io.BytesIO(data)) as archive:
            check(f'native artifact {metadata["id"]}: CRC', archive.testzip() is None)
            for member in receipt['members']:
                payload = archive.read(member['name'])
                check(f'native artifact {metadata["id"]}: member {member["name"]}',
                      sha(payload) == member['sha256'] and len(payload) == member['bytes'])
            execution = [name for name in archive.namelist() if name.endswith('/backend-execution.json')]
            for name in execution:
                record = json.loads(archive.read(name))
                check(f'native artifact {metadata["id"]}: engine exited successfully',
                      record['returncode'] == 0 and record['stop_reason'] == 'exited')
    for job_id in [136810012270, 136810012295, 136810012407]:
        log = (HOSTED / 'logs' / f'{job_id}.log').read_text()
        check(f'native positive {job_id}: one known change accepted',
              log.count('Known patch accepted: 1 change records') == 1)
    negative = (HOSTED / 'logs/136810012309.log').read_text()
    check('plain Ghidriff is an expected negative, not a fourth positive',
          'FileExistsError: Symbols are disabled, but the symbol is already downloaded' in negative
          and native['actual_outcomes']['expected_negative_cached_pdb_control']['passed_as_negative_control'] is True)
    first = load(HOSTED / 'artifacts/14702623076/live-cache-diagnostics/first.json')
    second = load(HOSTED / 'artifacts/14702623076/live-cache-diagnostics/second.json')
    result = load(HOSTED / 'artifacts/14702623076/live-cache-diagnostics/result.json')
    check('within-run raw-cache result passed', result['status'] == 'passed'
          and first['run']['status'] == second['run']['status'] == 'completed')
    check('within-run raw-cache bytes and fixture match count equal',
          first['raw_sha256'] == second['raw_sha256'] and first['match_count'] == second['match_count'] == 1)
    check('second phase records actual raw-cache reuse',
          any(event['message'] == 'raw output reused from cache' for event in second['events']))
    for key in ['older_sha256', 'newer_sha256']:
        check(f'raw-cache phase inputs equal: {key}', first['run']['settings'][key] == second['run']['settings'][key])

    windows = load(HOSTED / 'windows-full-and-platform-completion.json')
    linux = load(HOSTED / 'linux-full-completion.json')
    package = load(HOSTED / 'linux-package-completion.json')
    qt = load(HOSTED / 'five-qt-completion.json')
    for label, receipt in [('windows', windows), ('linux', linux)]:
        log = (HOSTED / receipt['raw_log']).read_text()
        check(f'{label}: exact full summary occurs in retained log', receipt['full_pytest']['summary_line'] in log)
        check(f'{label}: success and source binding', receipt['head_sha'] == HEAD and receipt['conclusion'] == 'success')
    winlog = (HOSTED / windows['raw_log']).read_text()
    check('Windows frozen CLI has 64 retained PASS records', windows['frozen_cli']['passed'] == 64
          and windows['frozen_cli']['failed'] == 0 and len(windows['frozen_cli']['receipt_lines']) == 64
          and all(line in winlog for line in windows['frozen_cli']['receipt_lines']))
    check('Windows portable acceptance log retained', windows['portable_smoke_receipt'] in winlog)
    check('Windows installer/install/uninstall acceptance log retained', windows['installer_smoke_receipt'] in winlog)
    check('Windows installer build digest retained in log', windows['installer_build_sha256'] in winlog)
    for gate in qt['qt']:
        log = (HOSTED / gate['raw_log']).read_text()
        check(f'Qt {gate["job_id"]}: exact success summary', gate['conclusion'] == 'success' and gate['summary_line'] in log)
    check('all five Qt gate records present', len(qt['qt']) == 5)
    package_log = (HOSTED / package['raw_log']).read_text()
    check('Linux package source and job succeeded', package['head_sha'] == HEAD and package['conclusion'] == 'success')
    product = package['product_artifact']
    check('Linux package artifact digest is retained in upload log', product['digest'].removeprefix('sha256:') in package_log
          and product['workflow_run']['head_sha'] == HEAD and product['workflow_run']['id'] == 44892118810)
    output = {
        'schema': 'patchtrace/pr351-completed-evidence-review/1', 'head': HEAD,
        'verdict': 'CLEAR_COMPLETED_RECEIPTS_ONLY' if all(c['passed'] for c in CHECKS) else 'BLOCKED_FINDING',
        'checks': CHECKS, 'mechanical_checks': len(CHECKS), 'blockers': [c for c in CHECKS if not c['passed']],
        'inputs': INPUTS, 'native_outcomes': native['actual_outcomes'],
        'limits': ['The two required Ubuntu frozen smokes and final release skip remain pending.',
                   'Raw-cache reuse does not establish original Ghidra archive cold-save/warm-hit acceptance.',
                   'No local product, package, native or target execution; no source/ref/PR/CI mutations.',
                   'No qualification transfer to other native lanes, future sources or global release readiness.'],
    }
    (OUT / 'completed-receipts-review.json').write_text(json.dumps(output, indent=2) + '\n')
    print(json.dumps({'verdict': output['verdict'], 'mechanical_checks': len(CHECKS), 'blockers': output['blockers']}))


if __name__ == '__main__':
    main()
