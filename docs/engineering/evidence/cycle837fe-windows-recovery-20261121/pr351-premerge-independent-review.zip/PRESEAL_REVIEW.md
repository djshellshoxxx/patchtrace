# PR351 independent premerge evidence snapshot

**Result: PENDING — no blocker found in the completed evidence, but premerge qualification is not yet sealed.** The two required Ubuntu frozen smoke jobs remain queued in the retained observation. The final release-job skip has not yet been instantiated and observed. Root must await the watcher's complete final job inventory and verified qualification archive before treating this audit as a final premerge clearance.

## Source and independent reviews

The local Git objects independently verify published head `d6679abc6dfddbadce0391c8d18289f7f96338d6`, complete tree `6001ef506c38930fd590bd827f428b997c3b2797`, base `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4`, and synthetic merge `a93005c69fe6091b940d7bc9ad1f5a38542e6e71`. The synthetic merge has ordered parents `[9023761a, d6679abc]` and the same complete tree as the head. Published d667 carries both `[no release]` and `[no deploy]` markers. An eventual actual main merge still needs its own expected-head, parent/tree and marker checks.

The complete final tree equals independently reviewed local `2ae1bbad`. Runtime `src/` remains byte-identical to qualified primary main902. Runtime, tools, tests and workflow bytes match the reviewed combined implementation at `0cdd5bf3`. The preserved C1 C5, Pages, records and final-publication archives pass their archive digests, CRCs and complete manifests. Their declared reviewed implementation blobs match d667.

This is an independent **evidence consistency** audit. C5 and Pages source clearance comes from the preserved C1 reviews; this audit does not independently clear the auditor's own authored implementation.

## Applicable runs and current outcomes

All 21 current workflow triggers were inspected against the exact PR delta and the preserved prepublication donor-to-head push delta. The bounded positive path/branch filters account for the two observed automatic attempt-1 runs: QA `44892118810` on the PR synthetic merge and native Ghidriff `44892116389` on d667. The latter matches the push change to `src/patchtrace/intelligence/tools/process.py`. Pages has no PR trigger and requires a later main push for actual held configure/upload/deploy behavior.

Thirteen completed executed jobs have independently checked checkout-log identities: both full QA jobs, all five Qt jobs, Linux packaging and all five Ghidriff jobs. The existing release-gate job `136810020819` is intentionally skipped. Still pending are Ubuntu 22.04 frozen smoke `136843246854`, Ubuntu 24.04 frozen smoke `136843246894`, and the final release-job skip/ID. The watcher's last successful poll communicated for this snapshot was 12:34:27 UTC; root separately reported unchanged queued smoke jobs at 12:39:54 UTC. These are time-bounded observations.

| Completed scope | Independently reconciled evidence |
| --- | --- |
| Linux full QA | 24,295 passed, 53 skipped, 4 xfailed; 24,352 JUnit cases; zero failures/errors |
| Windows full QA | 24,164 passed, 185 skipped, 3 xfailed; 24,352 JUnit cases; zero failures/errors |
| Qt | All five success summaries occur in the retained logs; repetitions are not added to full-suite counts |
| Windows distribution | All 64 frozen CLI PASS records, portable acceptance, installer build digest and install/launch/uninstall acceptance match retained logs |
| Linux packaging | Successful job, exact source identity and uploaded artifact digest match the retained log |
| Native Ghidriff | Three known-patch positive jobs each accept one change; one expected cached-PDB negative control; one within-run raw-cache reuse check |

The two QA artifact ZIPs and four native artifact ZIPs pass independent digest, member-hash and CRC checks. Native raw-cache phases retain equal inputs and raw bytes, one match each, successful completion and an explicit second-phase cache reuse event. That evidence does not establish original Ghidra archive cache cold-save/warm-hit acceptance, cross-run determinism or general analysis accuracy. The three positive backend records retain `jvm: unverified`; the separate cache diagnostic's Java probe is distinct.

## Preserved gates and failure history

Both CODEX-5 strict expected failures remain in each platform's actual JUnit. Linux additionally retains the missing `llvm-pdbutil` expected failure; both platforms retain the missing `--ghidra-dir` expected failure. The broader C5 hash/lock closures remain blocked.

C6 source/fixture rows are MERGED, but their native acceptance remains explicitly partial: rizin archive-hit evidence is retained and Ghidra archive-cache acceptance is unverified. Tier R remains 5/11 completed pairs, with its documented remaining limits. Manual trust/accessibility, full provenance and separate L1/L2/L3 gates remain open. Global `release_ready` is false. Static prepublication fields remain truthful historical checkpoints rather than assertions that live final qualification is complete.

The original modified-tree C5 full attempt is preserved as SIGKILL `-9`, wrapper `247`, 498.536 seconds, unknown cause, no aggregate summary and no second local full attempt.

## Audit receipts and next action

`preseal-review.json` records 348 read-only mechanical checks with zero findings. `completed-receipts-review.json` records 66 additional read-only evidence checks with zero findings. These are mechanical verification counts, not new product test cases and not additive qualification totals. No product suite, native tool, target, install, workflow dispatch or source/ref/PR mutation was performed.

When the watcher seals, review only the newly completed smoke/release outcomes, fresh final source/run identity and the archive/manifest consistency; bind that final conclusion to the sealed archive. Preserve this pending snapshot unchanged.
