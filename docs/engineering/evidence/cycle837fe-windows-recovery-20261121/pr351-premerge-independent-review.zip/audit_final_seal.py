"""Verify only the final PR351 qualification delta after the watcher seals it."""

from datetime import datetime, timezone
import io
import json
from pathlib import Path
import re
import sys
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parent))
from audit_static import BASE, CHECKS, HEAD, HOSTED, INPUTS, MERGE, OUT, TREE, check, load, preserve, sha


def main():
    required = ['final-qualification.json', 'evidence-manifest.json', 'archive-receipt.json', 'final-d667-evidence.zip']
    absent = [name for name in required if not (HOSTED / name).is_file()]
    if absent:
        print(json.dumps({'verdict': 'PENDING_WATCHER_SEAL', 'absent': absent}))
        raise SystemExit(2)
    receipt = load(HOSTED / 'archive-receipt.json')
    final = load(HOSTED / 'final-qualification.json')
    manifest = load(HOSTED / 'evidence-manifest.json')
    archive_bytes = preserve(HOSTED / receipt['archive_file'])
    check('sealed archive filename', receipt['archive_file'] == 'final-d667-evidence.zip')
    check('sealed archive digest', sha(archive_bytes) == receipt['archive_sha256'])
    check('sealed archive length', len(archive_bytes) == receipt['archive_bytes'])
    manifest_bytes = (HOSTED / receipt['manifest_file']).read_bytes()
    check('sealed manifest digest', sha(manifest_bytes) == receipt['manifest_sha256'])
    with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
        check('sealed archive CRC', archive.testzip() is None)
        check('sealed complete member inventory', set(archive.namelist()) ==
              {entry['path'] for entry in manifest['files']} | {receipt['manifest_file']})
        check('sealed member count and no duplicate names',
              len(archive.namelist()) == len(manifest['files']) + 1 == len(set(archive.namelist())))
        check('external and archived manifests identical', archive.read(receipt['manifest_file']) == manifest_bytes)
        check('external and archived final qualification identical',
              archive.read('final-qualification.json') == (HOSTED / 'final-qualification.json').read_bytes())
        for entry in manifest['files']:
            data = archive.read(entry['path'])
            check(f"sealed member digest: {entry['path']}", sha(data) == entry['sha256'] and len(data) == entry['bytes'])
    check('manifest payload count agrees with receipt', len(manifest['files']) == receipt['payload_file_count'])
    check('watcher receipt declares completed integrity verification', receipt['zip_crc_verified'] is True
          and receipt['every_manifest_member_size_and_sha256_verified'] is True)
    check('watcher receipt source and final-summary bindings', receipt['source_head'] == HEAD
          and receipt['source_tree'] == TREE and receipt['archive_member_count'] == len(manifest['files']) + 1
          and receipt['final_summary_sha256'] == sha((HOSTED / 'final-qualification.json').read_bytes()))
    source = final['source']
    check('final source identity', source['pull_request'] == 351 and source['head_sha'] == HEAD
          and source['head_tree_sha'] == TREE and source['base_sha'] == BASE
          and source['synthetic_merge_sha'] == MERGE and source['synthetic_merge_tree_sha'] == TREE
          and source['synthetic_merge_parents'] == [BASE, HEAD])
    for key in ['source_consistent', 'all_owned_runs_completed_successfully',
                'all_required_qa_jobs_successful', 'all_applicable_ci_jobs_successful']:
        check(f'final verdict flag: {key}', final['verdict'][key] is True)
    check('qualification remains limited by documented open gates',
          final['verdict']['qualification_status'] == 'qualified_with_documented_open_gates'
          and final['verdict']['native_coverage_limits_remaining'] is True
          and final['verdict']['expected_failures_remaining'] is True)

    expected_qa = {136810019664, 136810019884, 136810019804, 136810019927, 136810019864,
                   136810019928, 136810019907, 136831550032, 136843246854, 136843246894}
    expected_native = {136810012270, 136810012295, 136810012309, 136810012336, 136810012407}
    expected_skips = {136810020819: 'release-gate', 136850824693: 'release'}
    check('required QA inventory is exactly the ten executed gates', set(final['qa']['required_job_ids']) == expected_qa)
    runs = final['runs']
    check('final applicable run IDs are unchanged', {run['id'] for run in runs} == {44892118810, 44892116389})
    jobs = []
    old_proofs = {entry['job_id']: entry for entry in json.loads((OUT / 'preseal-review.json').read_text())['checkout_proofs']}
    for run in runs:
        check(f"run {run['id']}: exact source successful attempt1", run['head_sha'] == HEAD
              and run['status'] == 'completed' and run['conclusion'] == 'success' and run['run_attempt'] == 1)
        expected_event = 'pull_request' if run['id'] == 44892118810 else 'push'
        check(f"run {run['id']}: event", run['event'] == expected_event)
        expected_jobs = expected_qa | set(expected_skips) if run['id'] == 44892118810 else expected_native
        check(f"run {run['id']}: complete exact job inventory", {job['id'] for job in run['jobs']} == expected_jobs)
        for job in run['jobs']:
            jobs.append(job)
            if job['id'] in expected_skips:
                check(f"job {job['id']}: actual intentional release skip", job['name'] == expected_skips[job['id']]
                      and job['status'] == 'completed' and job['conclusion'] == 'skipped')
                continue
            check(f"job {job['id']}: completed success", job['status'] == 'completed' and job['conclusion'] == 'success')
            log_path = HOSTED / job['log_file']
            raw = log_path.read_bytes()
            log = log_path.read_text()
            found = re.findall(r'log -1 --format=%H\r?\n[^\n]*? ([a-f0-9]{40})\r?\n', log)
            expected_checkout = MERGE if run['id'] == 44892118810 else HEAD
            check(f"job {job['id']}: logged checkout", found == [expected_checkout] and job['checkout_sha'] == expected_checkout)
            if job['id'] in old_proofs:
                check(f"job {job['id']}: previously audited log unchanged", sha(raw) == old_proofs[job['id']]['log_sha256'])
    check('final owned job counts are 15 successes and two skips', len(jobs) == 17
          and sum(job['conclusion'] == 'success' for job in jobs) == 15
          and sum(job['conclusion'] == 'skipped' for job in jobs) == 2)

    package = json.loads((HOSTED / 'linux-package-completion.json').read_text())['product_artifact']
    smokes = []
    for job_id, os_name in [(136843246854, 'ubuntu-22.04'), (136843246894, 'ubuntu-24.04')]:
        smoke = load(HOSTED / f'linux-smoke-{job_id}.json')
        log = (HOSTED / smoke['raw_log']).read_text()
        check(f'{os_name}: exact source and 64/0 acceptance', smoke['head_sha'] == HEAD
              and smoke['synthetic_merge_sha'] == MERGE and smoke['conclusion'] == 'success'
              and smoke['passed'] == 64 and smoke['failed'] == 0)
        pass_lines = [line for line in log.splitlines() if 'Z ' in line and line.split('Z ', 1)[1].startswith('PASS ')]
        check(f'{os_name}: 64 actual PASS log lines', len(pass_lines) == 64)
        check(f'{os_name}: accepted exact packaged artifact', smoke['downloaded_product_id'] == package['id']
              and smoke['downloaded_artifact_digest'] == package['digest']
              and smoke['download_digest_matches_metadata'] is True and smoke['tar_checksum_ok'] is True)
        check(f'{os_name}: offscreen and XCB self-tests succeeded',
              len(smoke['self_test_steps']) == 2 and all(step['conclusion'] == 'success' for step in smoke['self_test_steps'])
              and any('offscreen' in step['name'] for step in smoke['self_test_steps'])
              and any('xcb' in step['name'] for step in smoke['self_test_steps']))
        smokes.append(smoke)
    guards = json.loads((OUT / 'final-root-guard-delta.json').read_text())
    preseal = json.loads((OUT / 'preseal-review.json').read_text())
    completed = json.loads((OUT / 'completed-receipts-review.json').read_text())
    check('retained source/review/completed-result/guard audits remain clear',
          not preseal['blockers'] and not completed['blockers'] and not guards['blockers'])
    result = {
        'schema': 'patchtrace/pr351-final-premerge-evidence-audit/1',
        'reviewed_at_utc': datetime.now(timezone.utc).isoformat(),
        'source': source, 'qualification_archive': receipt,
        'verdict': 'CLEAR_FOR_GUARDED_PREMERGE' if all(entry['passed'] for entry in CHECKS) else 'BLOCKED_FINDING',
        'mechanical_checks': len(CHECKS), 'checks': CHECKS,
        'blockers': [entry for entry in CHECKS if not entry['passed']],
        'owned_runs': 2, 'successful_executed_jobs': 15, 'intentional_skips': expected_skips,
        'linux_frozen_smokes': smokes, 'release_ready': False,
        'remaining_gates': preseal['open_gates'][:4],
        'premerge_conditions': ['Root refreshes expected main/head and uses its guarded merge.',
                               'Actual main merge parents/tree and both opt-out markers require post-merge verification.',
                               'Held Pages configure/upload/deploy behavior requires the subsequent actual main run.'],
        'independence_scope': preseal['independence_boundary'],
        'source_tests_executed': 0, 'source_or_ref_or_remote_mutations': False,
        'inputs': INPUTS,
    }
    (OUT / 'final-review.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'verdict': result['verdict'], 'checks': len(CHECKS), 'blockers': result['blockers'],
                      'qualification_archive_sha256': receipt['archive_sha256'],
                      'qualification_manifest_sha256': receipt['manifest_sha256']}, indent=2))


if __name__ == '__main__':
    main()
