# Independent complete historical packaging review

**CLEAR for the bounded classifications: CI remains PORT(partial); WIN-1 is SUPERSEDED.** All compatible scope is accounted for, including the known CI contribution that remains open. This report adds current recovery references without changing the original historical report or its test outcomes.

## Exact historical scope

The historical comparison is commit `0cdd5bf37130206c2ddec399450be6338ae8e4fd`, tree `6d532dd606a1fdf987245a03271970758a03fe57`.

| Branch | Exact head | Complete unique delta | Disposition |
|---|---|---|---|
| claude/awesome-ramanujan-o3pxx3-ci | 0bf1f8309e8425ba34199657009d3055215336f1 | One commit, 11 paths | PORT(partial) |
| claude/awesome-ramanujan-o3pxx3-win1 | 7ac57759f3b9b332eaafb48c82f366566892f1b1 | One commit, 13 paths | SUPERSEDED |

Both have parent and merge base `99f8328ce89d02f200cf9fbc5852d9801761af28`. There are no hidden branch merge resolutions. The full path sets, original patches, donor-to-current diffs, 65 available base/donor/current snapshots and every changed Python symbol were checked against immutable Git objects. The review completed **314 checks**, with no test reruns or source/ref/PR/CI/ledger/environment mutations.

Both exact heads are in the **original 181 unmatched-head bucket**, not the 16 patch-equivalent bucket. Their original inventory rows record one unmatched commit each and no deletion authorization. Read-only `git cherry` agrees. The original 181/16 snapshot remains unchanged; these named dispositions do not establish a new global remaining count or authorize branch deletion.

## Complete CI path accounting

| Changed path | Independent disposition and evidence |
|---|---|
| .github/workflows/qa-windows.yml | Partial. The original comparison retains dual-OS QA, Windows build/portable/installer checks, release checks for both sidecars, immutable release Action and tag-derived name. Concurrency, empty upload refusal and post-download validation were absent at that checkpoint. The later narrow recoveries are recorded below. |
| docs/release-process.md | Partial and awaiting a current pipeline amendment. Its older matrix/build paragraph omits the Qt/fresh-download gate and describes a stale release name. The donor's split-job prose is not the maintained architecture. |
| docs/specs/windows-acceptance-and-milestone-builds.md | Tag-derived naming retained; donor split-job/download topology was absent at the historical checkpoint. Current recovery amendments govern the adapted topology separately. |
| docs/specs/windows-release-signing-policy.md | Superseded. Maintained policy has a newer explicit full release-Action commit and tag-aware observation; dated observations and continuation boundaries remain visible. |
| pyproject.toml | Open dependency policy. The donor's October exact setuptools/dev versions were not adopted; current bounded ranges retain the subsequently declared PyYAML dependency. No transitive/hash/platform closure follows from those old pins. |
| tests/test_codex_pkg_packaging.py | Original exact-build/dev-pin test remains unported and its failure is preserved. Other maintained packaging assertions remain. |
| tests/test_milestone_notes.py | Superseded. The original Setup size/digest regression remains, strengthened by an exact expected SHA-256 assertion. |
| tests/test_release_gate.py | Partial. The immutable release-Action assertion is retained. Old split-job expectations differ from the maintained matrix/Qt/hold graph. The original six failures and three passes in this file remain historical results. |
| tests/test_windows_installer_manifest.py | Entire file byte-identical, including LF-only checksum regression. |
| tools/milestone_notes.py | Entire file byte-identical; Setup.exe is included in asset size/digest evidence. |
| tools/package_windows_installer.py | Entire file byte-identical; LF-only checksum helper and its invocation remain. |

The CI changed-symbol account independently reproduces 4 AST-identical symbols out of 10 changed top-level Python symbols, plus three wholly identical files. Source equality and the explained exceptions—not the structural counts alone—support the disposition.

Pip caching, explicit shallow checkout, image-only path exclusions and splitting matrix jobs are alternative CI policy, not automatically missing behavior. The maintained matrix covers both platforms and currently includes image changes. Copying the old workflow would remove later direct Action pins, Qt dependencies, publication holds and acceptance controls. No wholesale replacement is justified.

## Complete WIN-1 path accounting

| Changed path | Independent disposition and evidence |
|---|---|
| .gitattributes | The broader resource LF rule is narrowed to the exact SVG introduced by this branch; that file retains explicit LF handling. |
| docs/modules.md | Dedicated Application mark and Windows executable identity rows retain the original modules, tests and CI-only native-readback boundary. |
| docs/specs/windows-release-signing-policy.md | Continuation and acceptance amendments preserve metadata/icon/unsigned identity and deferred manifest work. Old dated observations are not substituted for current qualification. |
| pyproject.toml | The SVG package-data declaration is structurally identical. Other dependency changes are outside the donor hunk. |
| src/patchtrace/__main__.py | Window icon assignment and missing-icon self-test failure remain. The only behavioral ordering difference moves the optional-dependency summary after the icon check. |
| src/patchtrace/app_icon.py | Entire file byte-identical. |
| src/patchtrace/resources/patchtrace-mark.svg | Entire blob byte-identical and equal to the maintained owner site mark. |
| tests/test_windows_build_resources.py | Seventeen of nineteen original changed top-level symbols are AST-identical. The other two use the stronger checker API and real icon evidence in maintained replacements; their original API failures remain disclosed. |
| tools/build_windows.py | `pyinstaller_command` is AST-identical. Main retains icon/version generation and readback, validates metadata earlier, checks the packaged mark and supplies the numeric version quad. |
| tools/check_windows_exe.py | Label, commit, unsigned publisher and icon checks remain. Current code additionally rejects incomplete/contradictory version evidence, wrong fixed file/product quads and invalid icon payloads. Its required numeric-quad argument is an explicit internal API supersession. |
| tools/pyinstaller_hooks/hook-patchtrace.app_icon.py | Entire hook byte-identical; packaged mark and QtSvg inclusion retained. |
| tools/windows_icon.py | ICO render/packing functions are AST-identical. Output staging uses exclusive adjacent temporary files with cleanup, preserving successful output semantics. |
| tools/windows_version_info.py | Version data, label/run rules and rendering remain. Current validation requires the full lowercase commit, rejects trailing controls and stages output exclusively with cleanup. |

The WIN-1 changed-symbol account reproduces 30 AST-identical symbols out of 43, with three entirely identical files. No original symbol is missing. All 13 WIN-1 paths also remain byte-identical between historical comparison 0cdd and the current narrow recovery source 1c70; the current workflow work does not alter this implementation.

## Retained test provenance and failures

| Retained run on original 0cdd source | Exact outcome | Interpretation |
|---|---:|---|
| Maintained five-module selection | 198 passed | Existing packaging/release/notes/installer/resource contracts |
| Unchanged CI donor changed-test selection | 5 passed, 7 failed | Exact dev-pin policy; old release graph; three absent legacy job names; absent downloaded-byte gate; absent conditional concurrency |
| Complete unchanged WIN-1 donor test file | 33 passed, 2 failed | Both call the old three-argument `problems` API; current API requires `quad` and stronger evidence |
| Initial replay-wrapper attempt | 1 collection error, exit 4 | Wrapper assumed every module declared ROOT; milestone notes does not |
| Intermediate combined donor replay | 38 passed, 9 failed | Same 47 cases subsequently split by branch; overlapping, never additive |

All raw JUnit outcomes, original donor hashes and wrapper bindings were verified. Final wrappers compile the original unchanged donor bytes with their actual preserved filenames while binding `__file__` to the corresponding current test path for original ROOT/tool-loading logic. The sole initial functional wrapper correction makes its ROOT assertion conditional on the module declaring ROOT. A later presentation-only correction changes the compile filename to the original donor path for accurate tracebacks. Neither alters historical test assertions or converts failures to xfail.

The tests were source-bound to the clean original Pages checkout and dedicated environment. Prior ledger/review snapshots were captured while root's records were being staged; that recorded dirty status is preserved and is not mistaken for the clean executable-source checkout. The test runs use inert authored data and offscreen Qt/resource serialization. They do not establish Windows packaging, signing, trust, installer or target-execution acceptance. This independent audit ran **zero tests**.

## Separate current recovery addendum

The original report remains an observation of 0cdd. Later reviewed source now recovers selected behavior:

| Follow-up | Exact commit | Bounded recovery |
|---|---|---|
| Concurrency / required upload | c4eb63c55a35a1c2a927f4aeb4d42c8b96ff45ff | PR-only cancellation, unique non-PR run groups, refusal of an entirely empty Windows upload |
| Downloaded Windows artifact validation | 1c70cd5f8053f75c269da673a24a82f221180650 | Same-run named download, four regular members, both filename-bound sidecars/digests, then unchanged portable and installer smokes |

The second recovery adapts the donor proposal. It keeps full `frozen_smoke.py` execution on the builder and does not repeat the donor's host-Python/full-CLI invocation after download. It adds no application/dev install to the fresh validation job and retains the current matrix, Qt and release-hold topology. The sealed independent source reviews are linked by exact hashes in review.json. Their local passing selections are not added to historical test counts or turned into hosted acceptance.

**CI remains PORT(partial).** Old exact build/dev pin policy is still open, broader CODEX-5 remains open, and no wholesale donor adoption is claimed. The release-process pipeline correction is planned for root's next records commit and is not applied by this review. Exact-source hosted Windows qualification remains separate.

## Portable preservation

The original author archive is retained byte-for-byte: 138 members, 1,972,909 bytes, SHA-256 `b8bd30fc05950a052f46e867866aab8b16e9970af1942384a90e37c98677e2f8`. All 137 manifest payloads, CRCs, sizes, hashes and disk bytes were checked. Manifest SHA-256: `f6edbad901d9cf23c0bf1b887cc473fb0d73ec119841aec7d964d2eb746d9c7f`.

The nonthin pack verifies all 41 objects introduced by the two commits relative to their common base. Pack SHA-256: `10bb20b56767afffd148ce3dba9517ebcb5fefd5e801d1dab94277bb752a50c5`. Earlier parent ancestry remains a prerequisite; complete changed-source snapshots and original commits are retained. No history or original outcome was overwritten.
