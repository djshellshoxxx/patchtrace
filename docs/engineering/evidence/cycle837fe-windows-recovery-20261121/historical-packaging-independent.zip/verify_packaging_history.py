"""Read-only full-branch accounting and retained-result verification; no test execution."""
import ast
import collections
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import tomllib
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/837fe19aae3a')
REPO = ROOT / 'PatchTrace-codex5-followup'
E = ROOT / 'evidence/historical-packaging-next-review'
OUT = ROOT / 'evidence/historical-packaging-independent'
CURRENT = '0cdd5bf37130206c2ddec399450be6338ae8e4fd'
TREE = '6d532dd606a1fdf987245a03271970758a03fe57'
BASE = '99f8328ce89d02f200cf9fbc5852d9801761af28'
HEADS = {'ci': '0bf1f8309e8425ba34199657009d3055215336f1', 'win1': '7ac57759f3b9b332eaafb48c82f366566892f1b1'}
C4 = 'c4eb63c55a35a1c2a927f4aeb4d42c8b96ff45ff'
W1 = '1c70cd5f8053f75c269da673a24a82f221180650'
checks = []


def read(name):
    return json.loads((E / name).read_text())


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def blob(ref, path):
    return git('show', ref + ':' + path)


def check(name, condition, **details):
    checks.append({'name': name, 'passed': bool(condition), **details})
    if not condition:
        (OUT / 'verification-failure.json').write_text(json.dumps(checks, indent=2) + '\n')
        raise AssertionError(name)


def symbols(raw):
    return {node.name: ast.dump(node, include_attributes=False) for node in ast.parse(raw).body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}


def exists(ref, path):
    return subprocess.run(['git', '-C', str(REPO), 'cat-file', '-e', ref + ':' + path],
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0


classification = read('classification.json')
check('Exact original comparison source', classification['comparison_head'] == CURRENT and classification['comparison_tree'] == TREE
      and git('rev-parse', CURRENT + '^{tree}').decode().strip() == TREE)
inventory = read('prior-inputs/docs/engineering/branch-recovery-20261120-2bad.json')
check('Original181/16 census preserved', inventory['counts']['classifications']['unmatched-patches-review-required'] == 181
      and inventory['counts']['classifications']['patch-equivalent-semantics-unreviewed'] == 16
      and not classification['original_census_rewritten'])
all_paths, branch_rows, symbol_results = set(), [], {}
expected_snapshots = set()
for kind, head in HEADS.items():
    paths = git('diff', '--name-only', BASE, head).decode().splitlines()
    original = next(r for r in inventory['branches'] if r['head'] == head)
    claimed = next(r for r in classification['records'] if r['head'] == head)
    changed = read(kind + '/changed-paths.json')
    check(kind + ': exact complete branch scope', len(paths) == (11 if kind == 'ci' else 13)
          and set(paths) == {r['path'] for r in claimed['paths']} == set(changed['changed_paths']))
    check(kind + ': one unique commit, original parent and merge base',
          git('rev-list', CURRENT + '..' + head).decode().splitlines() == [head]
          and git('show', '-s', '--format=%P', head).decode().strip() == BASE
          and git('merge-base', CURRENT, head).decode().strip() == BASE)
    check(kind + ': original unmatched bucket, no deletion authority', original['classification'] == 'unmatched-patches-review-required'
          and original['unmatched_nonmerge_commits'] == [head] and original['equivalent_nonmerge_commits'] == []
          and not original['delete_authorized'] and git('cherry', CURRENT, head).decode().splitlines() == ['+ ' + head])
    check(kind + ': branch patch exact', (E / kind / 'branch.patch').read_bytes() == git('diff', '--binary', BASE, head))
    check(kind + ': donor-current delta exact', (E / kind / 'donor-to-current.patch').read_bytes() == git('diff', head, CURRENT, '--', *paths))
    compared = read(kind + '/source-comparison.json')
    computed_symbols, equal_symbols, missing = 0, 0, []
    for row in compared:
        path = row['path']
        old, now = blob(head, path), blob(CURRENT, path)
        check(kind + ': source comparison ' + path,
              row['donor_blob'] == git('rev-parse', head + ':' + path).decode().strip()
              and row['current_blob'] == git('rev-parse', CURRENT + ':' + path).decode().strip()
              and row['donor_sha256'] == sha(old) and row['current_sha256'] == sha(now)
              and row['byte_identical'] == (old == now))
        if path.endswith('.py'):
            before = symbols(blob(BASE, path)) if exists(BASE, path) else {}
            donor, current = symbols(old), symbols(now)
            changes = [{'name': name, 'present': name in current, 'ast_identical': value == current.get(name)}
                       for name, value in donor.items() if before.get(name) != value]
            check(kind + ': complete changed-symbol accounting ' + path, changes == row['changed_symbols'])
            computed_symbols += len(changes)
            equal_symbols += sum(r['ast_identical'] for r in changes)
            missing.extend(r['name'] for r in changes if not r['present'])
        for label, ref in [('merge-base', BASE), ('donor', head), ('current', CURRENT)]:
            if exists(ref, path):
                expected_snapshots.add((kind, label, path))
        all_paths.add(path)
    expected = (10, 4) if kind == 'ci' else (43, 30)
    check(kind + ': original structural count reproducible', (computed_symbols, equal_symbols) == expected
          and missing == claimed['source_comparison']['missing_symbol_names'] if kind == 'ci' else
          (computed_symbols, equal_symbols) == expected and not missing)
    symbol_results[kind] = {'changed': computed_symbols, 'AST_identical': equal_symbols, 'missing_names': missing}
    branch_rows.append({'branch': claimed['branch'], 'head': head, 'tree': changed['tree'], 'merge_base': BASE,
                        'paths': paths, 'original_bucket': original['classification'],
                        'disposition': 'PORT(partial)' if kind == 'ci' else 'SUPERSEDED'})
check('All24 path rows and22 distinct names accounted', sum(len(r['paths']) for r in branch_rows) == 24 and len(all_paths) == 22)

binding = read('source-binding-and-preservation.json')
check('All65 available base/donor/current snapshots retained', len(binding['files']) == binding['preserved_files_blob_verified'] == 65
      and {(r['branch'], r['category'], r['path']) for r in binding['files']} == expected_snapshots)
for row in binding['files']:
    ref = {'merge-base': BASE, 'donor': HEADS[row['branch']], 'current': CURRENT}[row['category']]
    raw = (E / row['branch'] / row['category'] / row['path']).read_bytes()
    check('Snapshot ' + '/'.join([row['branch'], row['category'], row['path']]),
          raw == blob(ref, row['path']) and sha(raw) == row['sha256']
          and row['git_blob'] == git('rev-parse', ref + ':' + row['path']).decode().strip())
check('Recorded test import binding is clean original source', binding['current_head'] == CURRENT and binding['current_tree'] == TREE
      and binding['clean_after'] and binding['module'] == str(ROOT / 'repair-pages-config-hold/src/patchtrace/__init__.py')
      and binding['direct_url'] == {'dir_info': {'editable': True}, 'url': (ROOT / 'repair-pages-config-hold').as_uri()})
for row in read('prior-input-manifest.json')['inputs']:
    raw = (E / row['path']).read_bytes()
    check('Preserved prior input ' + row['path'], len(raw) == row['bytes'] and sha(raw) == row['sha256'])

for path in ['src/patchtrace/app_icon.py', 'src/patchtrace/resources/patchtrace-mark.svg', 'tools/pyinstaller_hooks/hook-patchtrace.app_icon.py']:
    check('WIN1 exact retained implementation ' + path, blob(HEADS['win1'], path) == blob(CURRENT, path))
check('WIN1 SVG remains owner site mark', blob(CURRENT, 'src/patchtrace/resources/patchtrace-mark.svg') == blob(CURRENT, 'site/assets/cdl-mark.svg'))
check('WIN1 package-data hunk retained', tomllib.loads(blob(HEADS['win1'], 'pyproject.toml').decode())['tool']['setuptools']['package-data']
      == tomllib.loads(blob(CURRENT, 'pyproject.toml').decode())['tool']['setuptools']['package-data'])
check('WIN1 actual SVG keeps explicit LF rule', b'src/patchtrace/resources/patchtrace-mark.svg text eol=lf' in blob(CURRENT, '.gitattributes'))
for path in ['tools/package_windows_installer.py', 'tools/milestone_notes.py', 'tests/test_windows_installer_manifest.py']:
    check('CI exact retained implementation ' + path, blob(HEADS['ci'], path) == blob(CURRENT, path))
current_checker = ast.parse(blob(CURRENT, 'tools/check_windows_exe.py'))
checker = next(n for n in current_checker.body if isinstance(n, ast.FunctionDef) and n.name == 'problems')
check('WIN1 current API explicitly requires numeric quad', [a.arg for a in checker.args.args] == ['found', 'label', 'commit', 'quad'] and not checker.args.defaults)
check('WIN1 stricter resource evidence is explicit', all(token in blob(CURRENT, 'tools/check_windows_exe.py').decode()
      for token in ['version_shape_valid', 'invalid_icon_groups', "('file_version', 'product_version')", 'PT-REL-PUBLISHER', 'PT-REL-COMMIT']))

outcomes = {}
expected_runs = {'maintained': (198, 0, 0, 0), 'donor-ci': (5, 7, 0, 0), 'donor-win1': (33, 2, 0, 0),
                 'donor-replay': (38, 9, 0, 0), 'donor-replay-initial-wrapper-error': (0, 0, 1, 0)}
for label, wanted in expected_runs.items():
    xml = ET.parse(E / (label + '.xml'))
    cases = xml.findall('.//testcase')
    failures, errors, skips = xml.findall('.//failure'), xml.findall('.//error'), xml.findall('.//skipped')
    actual = (len(cases) - len(failures) - len(errors) - len(skips), len(failures), len(errors), len(skips))
    check('Retained exact JUnit outcome ' + label, actual == wanted)
    receipt = read(label + '-receipt.json')
    check('Retained exact source/exit binding ' + label,
          receipt.get('current_head', receipt.get('source_head')) == CURRENT
          and receipt.get('current_tree', receipt.get('source_tree')) == TREE
          and receipt['source_clean_after'] and receipt['exit_code'] == (0 if label == 'maintained' else 4 if 'initial' in label else 1)
          and '--noconftest' in receipt['argv'] and '--disable-plugin-autoload' in receipt['argv'])
    outcomes[label] = {'passed': actual[0], 'failed': actual[1], 'errors': actual[2], 'skipped': actual[3],
                       'failures': [{'name': c.get('name'), 'message': c.find('failure').get('message')} for c in cases if c.find('failure') is not None]}
check('Both WIN1 failures preserve original API cause', all("missing 1 required positional argument: 'quad'" in r['message'] for r in outcomes['donor-win1']['failures']))
check('Original wrapper error remains ROOT NameError', "NameError: name 'ROOT' is not defined" in (E / 'donor-replay-initial-wrapper-error.stdout.txt').read_text())
for path in sorted((E / 'donor-replay').glob('*.py')):
    text = path.read_text()
    kind = 'win1' if path.name.startswith('test_win1_') else 'ci'
    filename = 'test_' + path.name.split('_', 2)[2]
    donor_path = E / kind / 'donor/tests' / filename
    check('Replay compiles unchanged original bytes ' + path.name,
          str(donor_path) in text and "exec(compile(_ReplayPath(_REPLAY_SOURCE).read_bytes(), _REPLAY_SOURCE, 'exec'), globals())" in text
          and "__file__ = '" + str(ROOT / 'repair-pages-config-hold/tests' / filename) + "'" in text
          and "assert 'ROOT' not in globals() or ROOT ==" in text
          and donor_path.read_bytes() == blob(HEADS[kind], 'tests/' + filename))
    middle = (E / 'initial-wrappers' / (path.name + '.virtual-filename')).read_text()
    initial = (E / 'initial-wrappers' / path.name).read_text()
    check('Only wrapper guard and traceback filename corrections ' + path.name,
          initial.replace('assert ROOT ==', "assert 'ROOT' not in globals() or ROOT ==") == middle
          and middle.replace(".read_bytes(), __file__, 'exec')", ".read_bytes(), _REPLAY_SOURCE, 'exec')") == text)

archive_receipt = read('archive-receipt.json')
archive = E / archive_receipt['archive_file']
check('Exact historical archive digest and size', len(archive.read_bytes()) == 1972909 and sha(archive.read_bytes()) == 'b8bd30fc05950a052f46e867866aab8b16e9970af1942384a90e37c98677e2f8')
check('Exact historical manifest digest', sha((E / 'evidence-manifest.json').read_bytes()) == 'f6edbad901d9cf23c0bf1b887cc473fb0d73ec119841aec7d964d2eb746d9c7f')
manifest = read('evidence-manifest.json')
with zipfile.ZipFile(archive) as z:
    check('Full138-member archive and CRC verified', len(z.namelist()) == 138 and z.testzip() is None
          and set(z.namelist()) == {r['path'] for r in manifest['files']} | {'evidence-manifest.json'})
    for row in manifest['files']:
        raw = z.read(row['path'])
        check('Archive member ' + row['path'], raw == (E / row['path']).read_bytes() and len(raw) == row['bytes'] and sha(raw) == row['sha256'])
pack = E / 'donor-original-history.pack'
check('Exact original nonthin41-object pack', len(pack.read_bytes()) == 214113 and sha(pack.read_bytes()) == '10bb20b56767afffd148ce3dba9517ebcb5fefd5e801d1dab94277bb752a50c5')
verified = subprocess.run(['git', 'verify-pack', '-v', str(pack.with_suffix('.idx'))], capture_output=True)
(OUT / 'verify-pack.log').write_bytes(verified.stdout + verified.stderr)
packed = {line.split()[0] for line in verified.stdout.decode().splitlines() if len(line.split()[0]) == 40}
introduced = {line.split()[0] for line in git('rev-list', '--objects', *HEADS.values(), '--not', BASE).decode().splitlines()}
check('Every introduced Git object verified', verified.returncode == 0 and len(packed) == 41 and packed == introduced)

check('Current narrow recoveries have exact ancestry', git('show', '-s', '--format=%P', C4).decode().strip() == '2ae1bbad2ad9cc78c29541872381750e347c670e'
      and git('show', '-s', '--format=%P', W1).decode().strip() == C4)
check('Original dev-pin policy still open', blob(CURRENT, 'pyproject.toml') == blob(W1, 'pyproject.toml') and blob(W1, 'pyproject.toml') != blob(HEADS['ci'], 'pyproject.toml'))
check('WIN1 full13-path source unchanged through narrow recoveries', all(blob(CURRENT, p) == blob(W1, p) for p in branch_rows[1]['paths']))
check('Release-process prose correction is still future work', blob(CURRENT, 'docs/release-process.md') == blob(W1, 'docs/release-process.md'))
new_workflow = blob(W1, '.github/workflows/qa-windows.yml').decode()
new_job = new_workflow.split('  windows-validate:\n', 1)[1].split('  # Repeats the GUI', 1)[0]
check('Narrow recovery does not reproduce old topology or full host-Python smoke invocation',
      '  qa-windows:' not in new_workflow and '  windows-package:' not in new_workflow
      and 'tools/frozen_smoke.py' not in new_job and 'pip install' not in new_job
      and 'tools/frozen_smoke.py dist/PatchTrace/PatchTrace.exe' in new_workflow)
check('Recovered conditional cancellation and empty-upload control present',
      "cancel-in-progress: ${{ github.event_name == 'pull_request' }}" in new_workflow
      and "github.event_name == 'pull_request' && github.ref || github.run_id" in new_workflow
      and 'if-no-files-found: error' in new_workflow)
references = []
for dirname, digest in [('ci-publication-concurrency-independent', '7485d3def53a45b7302d15072056f2858f772b618e8ad0e08c156ebcbdd55f49'),
                        ('windows-artifact-validation-independent', '0e43697fe785346ed5f607cf6a0a2bd8729467f8aea9979becfa3a17fbed578a')]:
    raw = (ROOT / 'evidence' / dirname / 'review.json').read_bytes()
    check('Sealed narrow independent review unchanged ' + dirname, sha(raw) == digest)
    references.append({'path': 'evidence/' + dirname + '/review.json', 'sha256': digest})

report = {'schema': 'patchtrace/historical-packaging-independent/1', 'reviewed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'comparison_head': CURRENT, 'comparison_tree': TREE, 'verdict': 'CLEAR: CI PORT(partial), WIN1 SUPERSEDED',
          'blockers': [], 'branches': branch_rows, 'checks_passed': len(checks), 'checks': checks,
          'symbol_proof': symbol_results, 'retained_test_outcomes': outcomes, 'reviewer_tests_executed': 0,
          'original_census': {'unmatched': 181, 'patch_equivalent': 16, 'rewritten': False, 'both_reviewed_heads_from': 'unmatched-patches-review-required'},
          'current_recovery_references': references,
          'current_recovery_limits': ['c4 recovers conditional concurrency and empty upload refusal.',
              '1c adapts same-run downloaded portable/installer verification; full frozen CLI remains builder-side, without donor host-Python/dev installation or split-job topology.',
              'Exact development/build pin policy remains open; no broad dependency/CODEX-5 closure.',
              'docs/release-process.md correction is planned, not applied or accepted by this report.',
              'No new hosted/native qualification claim; original historical report and outcomes remain unchanged.'],
          'author_archive': archive_receipt, 'mutations': 'Only own scratch evidence. No source/ref/PR/CI/ledger/environment changes.'}
(OUT / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ['verdict', 'checks_passed', 'blockers', 'reviewer_tests_executed']}, indent=2))
