# Independent QA concurrency and empty-upload review

**CLEAR for exact commit `c4eb63c55a35a1c2a927f4aeb4d42c8b96ff45ff`; no blockers.**

| Identity | Value |
|---|---|
| Candidate tree | `561befcde425c5de07e113128dc79c21b7616772` |
| Exact parent | `2ae1bbad2ad9cc78c29541872381750e347c670e` |
| Parent tree | `6001ef506c38930fd590bd827f428b997c3b2797` |
| Original concurrency donor | `0bf1f8309e8425ba34199657009d3055215336f1` |

The frozen worktree remained clean before and after independent review. Both `[no release] [no deploy]` markers are present. Only the four authorized paths change: the QA workflow, the Windows acceptance specification, its existing registry row and `tests/test_release_gate.py`.

## Source and behavior

Exact byte neutralization independently proves that the workflow changes only its two concurrency fields and the required Windows upload's `if-no-files-found` input. A separate parsed-YAML comparison confirms every other field and job definition is identical to the parent: triggers, permissions, job graph, commands, action pins, publication holds, QA/Qt/native checks, upload conditions, paths and other upload settings. Every other repository path is unchanged by the commit.

The recovered concurrency expressions exactly match the donor. For pull requests, the suffix is the nonempty PR ref and cancellation is enabled: newer runs of the same PR share a group; different PR refs do not. Push and manual runs use their repository-unique run ID and disable running cancellation. Those non-PR runs can proceed independently; this is not a serialization queue. A rerun retains its run ID, so it retains the same group while cancellation remains disabled. The expression reasoning follows GitHub's documented contexts and boolean operators; the maintained fixture deliberately models only this declared shape and does not claim to execute GitHub's expression engine.

The upload setting is valid at the exact pinned `actions/upload-artifact@ea165f8d65b6e75b540449e92b4886f43607fa02`. Independent fresh reads of its action metadata and implementation confirm the previous default is `warn`, while `error` calls `core.setFailed` when the resolved file list has length zero. The existing successful-Windows condition and all four ZIP/Setup/checksum paths are exact. **A nonempty but incomplete artifact can still pass this control.** The specification explicitly keeps member completeness and downloaded-artifact smoke validation separate.

The specification adds one bounded section without altering prior text. The registry retains its existing draft status and limits its claim to source regressions with hosted acceptance separate. The retained red-stage evidence records the contract and new tests before the workflow change; the baseline workflow remained unchanged for those failures. The original donor concurrency regression is AST-identical, and **all74 pre-existing test/helper function ASTs remain unchanged**. Only three tests and one bounded helper are added.

## Independent verification

| Verification | Result |
|---|---|
| Maintained eight-module selection on clean exact candidate | **368 passed / 2 strict CODEX-5 xfailed**,370 cases, zero failures/errors/ordinary skips |
| Process duration | **2.131 seconds** |
| Source/evidence/control checks | **101 passed** |
| In-memory workflow controls | **19 expected outcomes**: two valid configurations and17 rejection controls |
| Unchanged parent workflow | All **eight intended red cases** independently reproduced |
| Original function preservation | **74 AST-identical functions** |
| Author evidence | **46 members /45 payloads**, all hashes, sizes and CRCs verified |

The independent command used the existing Pages interpreter with `-I -B` and explicit candidate `src`, repository and tests paths. It asserted the actual imported `patchtrace` and C5 audit paths. The environment's earlier editable metadata was recorded honestly and was neither modified nor treated as the candidate source binding. Pytest caching was disabled and temporary artifacts stayed in the reviewer-owned evidence directory.

The maintained selection includes release-gate, packaging contracts, milestone notes, installer-manifest, workflow contracts, the bounded C5 scanner, registry and site-workflow modules. It is not a full-suite, native engine, Windows build/installer, target execution or live scheduling/upload run. The two expected failures remain the original broad C5 gate and bounded scanner gate, with `pytest.xfail` typing preserved. Author and independent counts overlap and must not be added.

The19 workflow controls cover the valid frozen source, harmless following-job comments, the old parent, unconditional/disabled cancellation, wrong event/grouping, missing/warn/ignore/comment-only upload input, upload condition changes, missing/extra/broadened paths, artifact rename and action-pin change. They operate on in-memory text passed to the maintained regressions; no checked-in workflow was edited. Additional same-run-ID fixtures confirm rerun grouping without cancellation. This is bounded contract validation, not hosted behavior.

The author archive preserves the intended eight red cases, the intermediate **one failed /367 passed /two strict expected failures**, and the final green result. The intermediate error was confined to the new assertion consuming an existing comment outside the path literal. The final regex correctly stops at the indentation boundary and still requires the exact four paths. No workflow workaround was used. The entire validated precommit diff equals the frozen commit diff byte-for-byte; the recorded whole-tree Ruff result therefore remains tied to the reviewed bytes.

## Historical accounting

The retained historical archive is byte-identical, SHA256 `b8bd30fc05950a052f46e867866aab8b16e9970af1942384a90e37c98677e2f8`. Its complete CI11-path and WIN1 thirteen-path inventories agree with actual branch deltas and single unique commits from the stated merge base. Original histories and failed donor replays remain preserved.

The CI donor is **PORT(partial)** for the two selected controls; the historical pre-recovery label remains `PARTIALLY_INTEGRATED_WITH_RECOVERY_CANDIDATES`. It is not globally superseded or exhausted. The uploaded-Windows-artifact download/smoke gate and historical exact build/dev pin policy remain open, together with broad CODEX5/transitive hash closure. WIN1 donor `7ac57759f3b9b332eaafb48c82f366566892f1b1` retains its **SUPERSEDED** classification. This review does not transfer native acceptance from obsolete donor tests. The original **181 unmatched /16 patch-equivalent** census is unchanged.

## Remaining qualification

This signoff covers the exact source and its bounded historical disposition. Hosted scheduling and upload behavior require separate exact-source qualification. It does not extend or reset PR351's running qualification, perform publication, or claim release readiness. The existing native, signing, trust, manual/accessibility and other acceptance gates remain separate.

No source, index, ref, PR or CI state was mutated by this reviewer. No full pytest or native/target execution occurred.

## Primary references and receipts

- Candidate: `source/` snapshots and exact identities in `review.json`.
- Independent execution: `maintained-receipt.json`, `binding.json`, JUnit and stdout/stderr.
- Controls: `controls.json`; scripts retain the full reproducible checks.
- Original red/intermediate/final/history evidence: byte-identical `author-evidence.zip`.
- [Pinned upload input](https://github.com/actions/upload-artifact/blob/ea165f8d65b6e75b540449e92b4886f43607fa02/action.yml).
- [Pinned empty-file implementation](https://github.com/actions/upload-artifact/blob/ea165f8d65b6e75b540449e92b4886f43607fa02/src/upload/upload-artifact.ts).
- [GitHub contexts](https://docs.github.com/en/actions/reference/workflows-and-actions/contexts), [concurrency syntax](https://docs.github.com/en/actions/reference/workflows-and-actions/workflow-syntax#concurrency), and [expression operators](https://docs.github.com/en/actions/reference/workflows-and-actions/expressions).
