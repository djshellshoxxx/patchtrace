# PR351 d667 hosted qualification

Final observation: 2026-11-21 12:53:36 UTC. Qualification: **qualified with documented open gates**.

Head `d6679abc6dfddbadce0391c8d18289f7f96338d6`; complete tree `6001ef506c38930fd590bd827f428b997c3b2797`. Base/main `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4`. Synthetic checkout `a93005c69fe6091b940d7bc9ad1f5a38542e6e71` has parents [base, head] and the same complete tree.

## Actual applicable results

- QA 44892118810 (pull_request): completed success, attempt 1; all ten required executed jobs passed. Both release jobs were intentionally skipped, including actual release job 136850824693.
- Native Ghidriff 44892116389 (push): completed success, attempt 1; five cases passed their actual contracts.
- Total: 17 jobs, 15 executed successes and two intentional skips; zero failed jobs. All 15 completed checkout logs were retained and verified against the expected source.
- Only these two automatic runs were observed for this head. Runtime and other native workflow blob equivalence is recorded; older native acceptance is not transferred.

## QA and platform receipts

- Linux full: 24,295 passed / 53 skipped / 4 xfailed / 21 warnings. Windows full: 24,164 passed / 185 skipped / 3 xfailed / 22 warnings.
- Both full JUnit reports contain 24,352 cases with zero failures and zero errors. Skipped counts including expected failures are 57 Linux and 188 Windows.
- Separate boundary controls: 108 passed / 2 skipped Linux; 107 passed / 3 skipped Windows.
- Qt gates separately: Ubuntu shards 13,320 / 10,860 / 9,840 / 8,460 passed; Windows 10,620 passed.
- Windows standalone build, 64/0 frozen CLI checks, clean portable extraction/runtime smoke, installer build, installation/self-test and non-destructive uninstall all passed.
- Linux package passed. Ubuntu 22.04 and 24.04 each passed 64/0 frozen CLI checks; actual product archive digest and tar checksum were verified, both offscreen/XCB self-tests succeeded, and neither emitted unresolved-library warnings.

## Native scope and open gates

- Ghidriff has three positive known-patch variants with one accepted change each, one required cached-PDB negative control, and one application raw-cache test. The negative control is not a fourth successful analysis.
- Raw-cache first/second output SHA256 is 696f0d4e26c7c59dc171586bed4b1c17f24309cc7c5bdf069da12cb36e993cdc. This establishes within-run reuse, not independent-run determinism.
- Seven platform-specific expected failures remain: the repository-wide hashed-wheel audit and legacy CODEX-5 test on both platforms, Tier W live Ghidra export without --ghidra-dir on both platforms, and missing llvm-pdbutil on Linux. Exact JUnit IDs and messages are in the final JSON.
- Synthetic native acceptance does not close these live Tier W blocks. Earlier Tier R coverage limits remain preserved separately.
- Pages has no PR trigger. Configure skip, successful Pages artifact upload and deployment hold require observation of the later actual main push. No dispatch or enablement was performed.
- The separate 4202 code checkpoint and its native original-ZIP cache work are outside this source.

## Evidence and integrity

- final-qualification.json is the definitive completed receipt. Earlier snapshots, including native-summary.json, remain timestamped historical observations.
- Six small original artifact ZIPs (four native, two QA) have verified API lengths/digests and ZIP CRCs. Product artifact IDs, URLs, metadata and hosted digest receipts are retained; large product binaries are excluded.
- final-d667-evidence.zip contains the complete evidence payload and evidence-manifest.json. archive-receipt.json is external to avoid a self-referential hash.
- Prior full failures and superseded cancellations are indexed, and the primary ae69 and main902 archives remain unchanged. The actual main902 Pages HTTP 404 is kept separate from premerge qualification.
- No source/ref write, workflow dispatch/retry/cancel, local native-engine execution or analyzed-target execution occurred in this observation.
