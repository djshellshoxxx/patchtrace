# Independent source review — PR355

**CLEAR for further exact-source hosted qualification; not merge authorization.** No blocking finding was identified. The author's draft, full-suite, hosted-platform and ownership holds remain in force.

Head `e2127864cb481026db0157082d688b8a36595e3b`, complete tree `da71960b2edf33f1637c073b0613035843619543`, base/merge-base `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4`. All four unique linear commits and all four changed paths were reviewed and snapshotted. Final metadata at2026-11-21T12:45:14Z retained the same head/base, open draft, body and holds.

The existing optional-import contract requires graceful unavailable capabilities when an optional package fails. AST comparison proves that the only executable change is widening the three import handlers from `ImportError` to `Exception`. Static imports, registry, API, error detail, remediation text and packaging hook remain. `KeyboardInterrupt` and `SystemExit` propagate. No dependency, schema, runtime-engine or network behavior changes.

| Exact-source verification | Observed outcome |
|---|---|
| Original main902 checkout with unchanged new regression bytes | 3 intended failures; no errors/skips; each is the uncaught RuntimeError from a controlled optional importer |
| Reviewed e212 checkout: recovery, optional capabilities, search capability/fuzzy/synergy, doctor CLI | 82 passed; no failures/errors/skips; six modules; 6.01 pytest seconds |
| Separate independent import-boundary controls | 9 passed: three OSError cases become unavailable with actionable error and unchanged unrelated capabilities; six KeyboardInterrupt/SystemExit cases propagate the original exception by identity |
| Whole-tree Ruff | Passed `python -m ruff check src tests tools` |
| Dependency environment | `python -m pip check` passed |
| Checkout binding | Both heads, imported source paths and clean-before/after states verified |

The 82 cases overlap the author's seven; they are not additive coverage. Nine independent controls are separate from pytest. The complete parent failure logs and JUnit are retained. One initial read-only Git-log call mistyped the base SHA and exited128; correction used the actual fetched base, with no source mutation.

The unchanged frozen environment was not rebound. An explicit `-I` bootstrap selected each complete checkout's source. Existing doctor subprocess tests explicitly select their own checked-out SRC through PYTHONPATH. Runtime versions and exact commands are included.

These are Linux checkout tests and authored import faults, not actual failed-extension ABI or Windows/frozen/native acceptance. No local full suite, hosted rerun, workflow dispatch, source/ref/PR/CI mutation or merge occurred. Full exact-head Linux/Windows qualification and applicable workflows, current-main integration, author draft/ownership reconciliation and fresh guarded merge checks remain. Release readiness stays false.
