"""Read-only source-bound PR355 regression and integration review."""
from pathlib import Path
import ast
import hashlib
import json
import os
import subprocess
import time

ROOT = Path('/workspace/scratch/837fe19aae3a')
OUT = Path(__file__).resolve().parent
REPO = ROOT / 'review-pr355-optional-imports'
BASE = ROOT / 'review-pr355-main-baseline'
PYTHON = ROOT / 'windows-recovery-followup-venv/bin/python'
EXPECTED = 'e2127864cb481026db0157082d688b8a36595e3b'
BASE_HEAD = '9023761a4066ac1c50c127ac09d0ba5f56cdc9e4'


def git(repo, *args):
    return subprocess.check_output(['git', *args], cwd=repo).decode().strip()


def run(name, argv, cwd):
    env = dict(os.environ, QT_QPA_PLATFORM='offscreen', PYTHONDONTWRITEBYTECODE='1')
    start = time.monotonic()
    result = subprocess.run(argv, cwd=cwd, env=env, capture_output=True)
    (OUT / (name + '.stdout')).write_bytes(result.stdout)
    (OUT / (name + '.stderr')).write_bytes(result.stderr)
    record = {'argv': [str(x) for x in argv], 'cwd': str(cwd), 'exit': result.returncode,
              'seconds': time.monotonic() - start, 'source': git(cwd, 'rev-parse', 'HEAD'),
              'tree': git(cwd, 'rev-parse', 'HEAD^{tree}')}
    (OUT / (name + '.command.json')).write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'name': name, **record}), flush=True)
    return result.returncode


def selection(repo, expected, paths, name):
    temp = OUT / 'tmp' / name
    temp.parent.mkdir(exist_ok=True)
    bootstrap = ('import sys,pathlib; r=pathlib.Path(' + repr(str(repo)) + '); '
                 'sys.path[:0]=[str(r/"src"),str(r/"tests"),str(r)]; '
                 'import patchtrace; from patchtrace import optional_deps; '
                 'assert pathlib.Path(patchtrace.__file__).resolve().is_relative_to(r/"src"); '
                 'assert pathlib.Path(optional_deps.__file__).resolve()==r/"src/patchtrace/optional_deps.py"; '
                 'print("EXACT_SOURCE_BINDING",patchtrace.__file__,optional_deps.__file__); '
                 'import pytest; raise SystemExit(pytest.main(' + repr(paths + [
                     '-q', '--basetemp=' + str(temp), '--junitxml=' + str(OUT / (name + '.xml'))]) + '))')
    assert git(repo, 'rev-parse', 'HEAD') == expected
    return run(name, [str(PYTHON), '-I', '-c', bootstrap], repo)


assert git(REPO, 'rev-parse', 'HEAD') == EXPECTED
assert git(BASE, 'rev-parse', 'HEAD') == BASE_HEAD
assert not git(REPO, 'status', '--porcelain=v1') and not git(BASE, 'status', '--porcelain=v1')
base_source = (BASE / 'src/patchtrace/optional_deps.py').read_bytes()
fixed_source = (REPO / 'src/patchtrace/optional_deps.py').read_bytes()
base_ast = ast.parse(base_source)
changed = 0
for node in ast.walk(base_ast):
    if isinstance(node, ast.ExceptHandler) and isinstance(node.type, ast.Name) and node.type.id == 'ImportError':
        node.type.id = 'Exception'
        changed += 1
assert changed == 3 and ast.dump(base_ast) == ast.dump(ast.parse(fixed_source))
assert git(REPO, 'rev-parse', 'HEAD:src/patchtrace/optional_deps.py') == 'b99ebfb1f24bf86123dd244204d80601d8bcb628'
red_test = OUT / 'source' / EXPECTED / 'tests/test_optional_import_recovery.py'
assert red_test.read_bytes() == (REPO / 'tests/test_optional_import_recovery.py').read_bytes()
assert selection(BASE, BASE_HEAD, [str(red_test)], 'parent-red') == 1
paths = ['tests/test_optional_import_recovery.py', 'tests/test_optional_deps.py',
         'tests/test_search_capability.py', 'tests/test_search_fuzzy.py',
         'tests/test_search_synergy.py', 'tests/test_doctor_cli.py']
assert selection(REPO, EXPECTED, paths, 'focused') == 0
assert run('whole-tree-ruff', [str(PYTHON), '-m', 'ruff', 'check', 'src', 'tests', 'tools'], REPO) == 0
assert run('dependency-check', [str(PYTHON), '-m', 'pip', 'check'], REPO) == 0
assert not git(REPO, 'status', '--porcelain=v1') and not git(BASE, 'status', '--porcelain=v1')
record = {'head': EXPECTED, 'base': BASE_HEAD, 'three_handler_change_only_ast': True,
          'base_module_sha256': hashlib.sha256(base_source).hexdigest(),
          'fixed_module_sha256': hashlib.sha256(fixed_source).hexdigest(),
          'clean_before_and_after': True, 'frozen_environment_rebound': False,
          'source_binding': 'Explicit -I bootstrap imports the exact checked-out src; test child processes use their own checked-out SRC through existing PYTHONPATH setup.',
          'full_suite': False, 'native_extension_fault_execution': False}
(OUT / 'local-validation.json').write_text(json.dumps(record, indent=2) + '\n')
