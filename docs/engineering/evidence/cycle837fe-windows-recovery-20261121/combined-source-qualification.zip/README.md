# Exact combined source qualification

f596471b8909ec8e28e0624041d60f03d520591d, tree dffeed541749850ef54a130cec0fa56c0fd2f01c.

449 passed,27 explicit no-pwsh skips,2 strict CODEX-5 xfailed;478 distinct cases in14 modules. Counts overlap component receipts. Whole Ruff,pip check and isolated editable binding passed. Clean before/after. No full-suite,hosted or native acceptance claimed.

Native-source bundle retains original88 and correctivef596, requiring local1c70; earlier local-recovery-source.bundle retainsc4/1c and requires2ae. The JSON and original stdout/XML contain exact commands,identities and limits.
