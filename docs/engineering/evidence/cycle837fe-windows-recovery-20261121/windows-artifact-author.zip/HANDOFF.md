# Downloaded Windows artifact validation recovery

Exact local source `1c70cd5f8053f75c269da673a24a82f221180650`, complete tree `a39d650ca7fa2b41ece017ea492396722a4142d9`, parent `c4eb63c55a35a1c2a927f4aeb4d42c8b96ff45ff`. Clean worktree `repair-windows-artifact-validation`; source frozen for independent review. Neither PR351 nor the concurrency parent was edited. No remote publication, CI dispatch, release or deployment occurred.

## Recovered behavior

Historical CI donor `claude/awesome-ramanujan-o3pxx3-ci` at `0bf1f8309e8425ba34199657009d3055215336f1` proposed a separate Windows artifact validation job. Adapt it to the maintained workflow: fresh Windows runner, same-run named artifact download after pinned checkout, all four regular ZIP/Setup/sidecar files required, exact single-record SHA-256 filename binding and both byte hashes checked before execution. Reuse the unchanged portable and installer PowerShell smoke scripts. The new job installs no application/Python/dev dependency or NSIS compiler and rebuilds nothing. Release adds this dependency with every previous dependency and the original condition/holds retained.

Only the new job and its release dependency change the workflow relative to c4eb. Removing those restores the parent's bytes exactly. All existing job fields and three smoke scripts remain unchanged. Six paths change, including the spec-first amendment, existing registry row, regressions and current-source census. Census:21 workflows/203 actual run scalars/42 explicit pip installs/41 unprotected installs. Historical200-step receipts remain historical observations.

## Executed validation

First regression attempt: one syntax/collection error in the new test file, exit4; original source/log/XML/receipt retained, not a product assertion. After correcting that typo, all five intended regressions failed against the unchanged c4eb workflow.

Initial focused selection:340 passed/17 absent-PowerShell skips/2 strict CODEX-5 xfails, overlapping final selection. Final10 affected/contract modules: **415 passed/17 explicit absent-PowerShell skips/2 strict CODEX-5 xfails**,434 cases,0 failures/errors. Tested staged tree equals frozen commit. Whole-tree Ruff passes, including after commit; dedicated `-I` module/editable-source binding and pip check pass.

No PowerShell interpreter exists here. Seventeen fixture cases are not executed locally. Windows QA requires PowerShell and must run the exact verification step against inert authored bytes; those fixture artifacts are never extracted or executed. No local full suite, actual Windows installer/package, target binary or native engine was executed for this source. Exact-source hosted full/Qt/platform and downloaded Windows acceptance remain required after review/publication.

## Evidence and limits

Source invariants, hashes, binary patch, six changed-file snapshots, three unchanged scripts and a two-commit Git bundle preserve provenance. The bundle requires local2ae, whose full tree equals published d667. The source snapshots remain independently inspectable. Historical donor evidence remains in the predecessor's sealed packaging archive. This recovery does not classify the entire donor as merged or close broad build/dev dependency pinning.

A fresh hosted runner includes standard image software. This does not prove a pristine Windows11 profile, manual GUI/accessibility acceptance, signing/trust, upgrades, full offline backend packaging, broad CODEX-5 closure, hostile-writer confinement or publisher authenticity. Preserve separate native/provenance and L1/L2/L3 gates.
