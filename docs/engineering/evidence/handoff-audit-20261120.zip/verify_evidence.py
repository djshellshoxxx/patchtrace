"""Read-only independent verification of the generation 14 evidence checkpoint."""
from __future__ import annotations

import collections
import hashlib
import json
import re
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/workspace/scratch/4c8dc848d760/PatchTrace/docs/engineering/evidence')
OUT = Path('/workspace/scratch/4c8dc848d760/validation/handoff-audit')
STEMS = (
    'aggregate-qualification-20261120', 'aggregate-remainder-20261120',
    'followup-combined-20261120', 'gui-counter-root-review-20261120',
    'acquisition-provenance-peer-review-20261120', 'pr324-ci-review-20261120',
    'pr324-native-patchtrace-clean', 'native-fixture-qualification-20261120',
    'qa-diagnosis-20261120',
)
issues = []
archives = {}
contents = {}

def check(condition, message):
    if not condition:
        issues.append(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def verify_entries(data, entries, label):
    for name, details in entries.items():
        check(name in data, f'{label}: missing archive member {name}')
        if name not in data:
            continue
        if 'bytes' in details:
            check(len(data[name]) == details['bytes'], f'{label}: size mismatch {name}')
        if 'sha256' in details:
            check(sha(data[name]) == details['sha256'], f'{label}: hash mismatch {name}')

def xml_cases(raw):
    node = ET.fromstring(raw)
    cases = list(node.iter('testcase'))
    counts = collections.Counter()
    result = []
    for case in cases:
        if case.find('failure') is not None:
            outcome = 'failed'
        elif case.find('error') is not None:
            outcome = 'error'
        elif case.find('skipped') is not None:
            outcome = 'xfail' if case.find('skipped').get('type') == 'pytest.xfail' else 'skipped'
        else:
            outcome = 'passed'
        counts[outcome] += 1
        result.append((case.get('classname'), case.get('name'), outcome))
    return {'cases': len(cases), **dict(counts)}, result

for stem in STEMS:
    path = ROOT / (stem + '.zip')
    payload = path.read_bytes()
    with zipfile.ZipFile(path) as archive:
        check(archive.testzip() is None, f'{stem}: ZIP CRC error')
        names = archive.namelist()
        check(len(names) == len(set(names)), f'{stem}: duplicate ZIP member names')
        data = {name: archive.read(name) for name in names}
    contents[stem] = data
    manifest_file = path.with_suffix('.json')
    manifest = json.loads(manifest_file.read_bytes()) if manifest_file.exists() else {}
    expected = manifest.get('archive_sha256') or manifest.get('archive', {}).get('sha256')
    expected = expected or (manifest.get('github_digest', '').removeprefix('sha256:') or None)
    if expected is not None:
        check(sha(payload) == expected, f'{stem}: whole archive hash mismatch')
    entries = manifest.get('files') or manifest.get('entries')
    if entries:
        verify_entries(data, entries, stem)
        check(set(data) == set(entries), f'{stem}: unlisted or absent manifest members')
    if 'checksums.json' in data:
        checksums = json.loads(data['checksums.json'])
        checksums = checksums.get('files', checksums)
        verify_entries(data, checksums, stem)
        check(set(data) == set(checksums) | {'checksums.json'}, f'{stem}: unlisted checksum members')
    xml = {name: xml_cases(raw)[0] for name, raw in data.items() if name.endswith('.xml')}
    archives[stem] = {'bytes': len(payload), 'sha256': sha(payload), 'members': len(data),
                      'crc_valid': True, 'xml': xml}

# Independent collection/progress recount of the original interrupted attempt.
original = contents['aggregate-qualification-20261120']
receipt = json.loads(original['aggregate-1/receipt.json'])
nodes = [line for line in original['collection-bffcfa99.txt'].decode().splitlines()
         if line.startswith('tests/') and '::' in line]
markers = ''.join(match.group(1) for line in original['aggregate-1/pytest.log'].decode().splitlines()
                  if (match := re.fullmatch(r'([.sFxXE]+)\s*(?:\[\s*\d+%\])?\s*', line)))
progress = dict(collections.Counter(markers))
check(len(nodes) == 23756 and len(set(nodes)) == 23756, 'Original collection count/uniqueness differs')
check(len(markers) == 19877, 'Original progress length differs')
check(progress == {'.': 19776, 's': 93, 'x': 6, 'F': 2}, 'Original progress counts differ')
check(receipt['exit_code'] == -9 and receipt['elapsed_seconds'] == 1729.332, 'Original termination receipt differs')
check(not any(n.endswith('.xml') for n in original), 'Original killed suite unexpectedly has JUnit')

# Reconcile every distinct remainder XML case to its exact collected node ID.
remainder = contents['aggregate-remainder-20261120']
selected = json.loads(remainder['selected-nodeids.json'])
check(selected == nodes[19875:], 'Remainder differs from complete original boundary-module suffix')
check(len(selected) == len(set(selected)) == 3881, 'Remainder selection count/uniqueness differs')

def junit_key(nodeid):
    base, separator, suffix = nodeid.partition('[')
    parts = base.split('::')
    module = parts[0][:-3].replace('/', '.')
    return '.'.join([module, *parts[1:-1]]), parts[-1] + (separator + suffix if separator else '')

expected_keys = {junit_key(node): node for node in selected}
check(len(expected_keys) == 3881, 'Remainder expected XML keys collide')
observed = []
node_outcomes = {}
counts = collections.Counter()
skip_reasons = collections.Counter()
for name, raw in remainder.items():
    if re.fullmatch(r'batch-\d\d.xml', name):
        _, cases = xml_cases(raw)
        for classname, testname, outcome in cases:
            key = classname, testname
            check(key in expected_keys, f'Unexpected remainder JUnit testcase {key}')
            if key in expected_keys:
                observed.append(expected_keys[key])
                node_outcomes[expected_keys[key]] = outcome
            counts[outcome] += 1
        for skipped in ET.fromstring(raw).iter('skipped'):
            skip_reasons[skipped.get('message')] += 1
check(len(observed) == len(set(observed)) == 3881, 'Remainder XML count/uniqueness differs')
check(set(observed) == set(selected), 'Remainder XML node set differs')
check(dict(counts) == {'passed': 3849, 'skipped': 32}, 'Remainder XML results differ')
recorded = [r for name, raw in remainder.items() if name.endswith('-node-results.json')
            for r in json.loads(raw)]
check(len(recorded) == 3881, 'Remainder reconciled records count differs')
check(all(node_outcomes.get(r['nodeid']) == r['outcome'] for r in recorded), 'Remainder node-result outcome differs from raw XML')
internal = json.loads(remainder['manifest.json'])
check(sha(remainder['run_remainder.py']) == internal['runner_sha256'], 'Remainder runner hash mismatch')
check(all(b['exit_code'] == 0 for b in internal['batches']), 'Remainder process exit was not zero')
check(internal['source_head'] == internal['final_source_head'] == 'bffcfa99d6a5044024256edbc0457ab20c92cbae', 'Remainder source changed')
check(internal['source_tree'] == internal['final_source_tree'] == 'e79fe1eb6cc438384f0cc347d8f87f0a4ac3f7db', 'Remainder tree changed')
check(internal['initial_worktree_status'] == internal['final_worktree_status'] == '', 'Remainder tracked checkout status was not clean')

# Expected XML outcomes of the separate reviewed scopes and preserved red attempts.
expected_xml = {
    ('followup-combined-20261120', 'results.xml'): {'cases': 1738, 'passed': 1737, 'skipped': 1},
    ('gui-counter-root-review-20261120', 'results.xml'): {'cases': 41, 'passed': 41},
    ('acquisition-provenance-peer-review-20261120', 'acquisition-root-review/results.xml'): {'cases': 31, 'passed': 29, 'failed': 2},
    ('acquisition-provenance-peer-review-20261120', 'acquisition-root-review-corrected/results.xml'): {'cases': 31, 'passed': 31},
    ('qa-diagnosis-20261120', 'qa-diagnosis-20261120/gui-counter-final.xml'): {'cases': 186, 'passed': 186},
    ('qa-diagnosis-20261120', 'qa-diagnosis-20261120/gui-counter-red-clean.xml'): {'cases': 1, 'failed': 1},
    ('qa-diagnosis-20261120', 'qa-diagnosis-20261120/unix-focused.xml'): {'cases': 1, 'failed': 1},
}
for (stem, name), expected in expected_xml.items():
    check(archives[stem]['xml'][name] == expected, f'{stem}/{name}: advertised totals differ')
qa = contents['qa-diagnosis-20261120']
check(b'Fatal Python error: Segmentation fault' in qa['qa-diagnosis-20261120/gui-counter-red.log'], 'Original regression segmentation fault not retained')
check(qa['qa-diagnosis-20261120/aggregate-termination-receipt.json'] == original['aggregate-1/receipt.json'], 'Cross-archive original termination receipt changed')
check(qa['qa-diagnosis-20261120/aggregate-progress-snapshot.log'] == original['aggregate-1/pytest.log'], 'Cross-archive original aggregate log changed')
native = contents['native-fixture-qualification-20261120']
native_nodes = json.loads(native['selected-nodeids.json'])
check(set(native_nodes) == {n for n, outcome in node_outcomes.items() if outcome == 'skipped'}, 'Native replay selection differs from all 32 original remainder skips')

# Native artifact receipt is internally and externally digest-bound.
native_clean = contents['pr324-native-patchtrace-clean']
backend = json.loads(next(raw for name, raw in native_clean.items() if name.endswith('/backend-execution.json')))
check(backend['returncode'] == 0 and backend['elapsed_seconds'] == 93.953, 'Native clean backend receipt differs')
for stem, job, expected_text in [('pr324-ci-review-20261120', 'job-135982353737.log', '10680 passed'), ('pr324-ci-review-20261120', 'job-135982353762.log', '8640 passed')]:
    check(expected_text.encode() in contents[stem][job], f'{job}: repeated-pass summary missing')

result = {'schema': 'patchtrace-independent-evidence-validation/1',
          'recorded_at': datetime.now(timezone.utc).isoformat(),
          'scope': 'Read-only archive/hash/JUnit verification; no tests or project code executed.',
          'archive_count': len(archives), 'archives': archives,
          'original_collection_nodes': len(nodes), 'original_progress_markers': len(markers),
          'original_progress_counts': progress, 'original_exit_code': receipt['exit_code'],
          'remainder': {'selected_nodes': len(selected), 'previously_unreported': len(nodes)-len(markers),
                        'overlap_nodes': len(markers)-19875, 'xml_counts': dict(counts),
                        'missing_or_duplicate_ids': len(observed)-len(set(observed)),
                        'skip_reasons': dict(skip_reasons)},
          'issues': issues, 'disposition': 'verified' if not issues else 'discrepancies'}
OUT.mkdir(parents=True, exist_ok=True)
(OUT/'evidence-validation.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({k: v for k, v in result.items() if k not in ('archives','remainder')}, indent=2))
