# PR352 independent review — blocked as-is

The authored stalled-operation repair is reproduced and its maintained tests pass. The exact PR head still publishes a completed response after its total wall deadline in the completion window between polling checks. It also inherits the late-cleanup accounting defect addressed by PR356. No product source, author hold, PR, CI, shared ref, current integration record or environment binding was changed during this review.

## Exact source and complete scope

| Item | Identity |
| --- | --- |
| PR352 head | `e3928ab8c8e2deee7bb01b0f857205f68a1abda2` |
| Head tree | `ee0a8bdf70b497c0b2d0e5ed5eeca9b9e9f648e1` |
| Base and merge base | `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4` |
| Author tests before implementation | `a1efd07a7f4be7c9cc4689335d059c54a20c1325` |
| Detached checkout | `/workspace/scratch/837fe19aae3a/review-pr352-enrichment-deadline-837fe` |
| Existing interpreter | `/workspace/scratch/837fe19aae3a/pages-config-hold-venv/bin/python` — Python 3.12.14 |

All five linear commits were accounted for, with original commit objects checked against their Git identities: specification `5413e4dd`, tests `a1efd07a`, implementation `fe73b2ef`, QA `df63006f`, and task record `e3928ab8`. `source-history.json` contains exact messages, parents, trees and per-commit paths; `original-history/` preserves the raw commit objects. All five net and historical changed paths are preserved at every commit in `original-source/`.

| Changed path | Complete semantic accounting |
| --- | --- |
| `docs/specs/enrichment-hardening-backlog.md` | Inserts only H9b before H10; every original byte is preserved. Requires a wall deadline across the complete attempt and owned cleanup. The existing spec path is already registered; no new spec path is introduced. |
| `src/patchtrace/enrichment/intelligence.py` | Adds `_AttemptLimit` and changes only `_fetch_one`; 23 existing definitions remain AST-identical. Wraps `_attempt` in `interruptible`, maps deadline/cancellation/cap failures, and leaves inner opener/read supervision unchanged. |
| `tests/test_enrichment_intelligence.py` | Adds the two parameterized connect/read deadline cases. All 36 original top-level definitions are AST-identical. |
| `docs/qa.md` | Prepends six lines documenting unverified implementation; the entire original file is retained as an exact suffix. |
| `tasks/todo.md` | Prepends seven lines documenting implementation and qualification gates; the entire original file is retained as an exact suffix. |

`semantic-path-accounting.json` provides blob hashes and the mechanical comparison. No workflow, dependency, netutil implementation, provider implementation, or other runtime file changes on PR352. The detached checkout was clean before and after all checks.

Actual main `3a16290c0fcc4e0c21712fe10474a3ff33fad336`, tree `6001ef506c38930fd590bd827f428b997c3b2797`, is recorded separately. The relevant enrichment/netutil/cancellation/pacing source and tests are byte-identical between base902 and that main. PR352 still has merge base902. This comparison does not qualify a new combined main tree.

## Finding 1 — completed attempt can publish after its wall deadline

**P2, confirmed; blocks the H9b claim.** At `src/patchtrace/enrichment/intelligence.py` lines 360–361, `_fetch_one` immediately returns the result of `interruptible`. The helper tests cancellation/deadline before starting and on polling timeouts. When its worker signals completion first, it returns the outcome without checking the stop condition again.

The preserved deterministic controls advance the wall clock across the deadline during EOF or response close, while keeping the separately injected logical clock unchanged. Both return a successful result instead of a recoverable `PT-ENRICH-NETWORK` error. A companion finishing before the deadline succeeds. The ordinary blocked-open/read cases and blocked-close positive control also pass: this finding concerns publishing an outcome in the completion window between checks, not loss of the authored stalled-operation fix. The default poll interval is 100 ms; no claim of an indefinitely stalled caller is made for this finding.

The narrow repair location is the immediate return in `_fetch_one`: retain the completed value, check explicit caller cancellation first so `PT-ENRICH-CANCEL` keeps its existing precedence, then validate the same wall and injected logical deadlines before publishing. Expiry should yield the existing recoverable `PT-ENRICH-NETWORK`/`total timeout exceeded` classification without remote text. Preserve the response's owned cleanup and all existing success, retry, byte-limit and consent behavior.

Exact controls: `test_review_attempt_boundaries.py::test_completed_attempt_past_wall_deadline_is_not_published[eof]` and `[close]`. Raw failures: `current-independent-boundaries.stdout.txt` and its JUnit XML. Both failures remain when the exact PR356 helper component is substituted in memory; no source checkout is edited by that comparison.

## Finding 2 — inherited late cleanup is no longer counted

**P2, confirmed inherited dependency limitation.** PR352 leaves `netutil.py` at base blob `9fff565fd59d3d3d23a7a9f4e0a894bd742f8432`. Its inner opener still calls `interruptible(..., cleanup=lambda r: r.close())`. On explicit cancellation, a late opener's blocked close is counted as zero because the helper decrements `_abandoned` before running cleanup. This is preexisting helper behavior, not a newly introduced accounting regression in PR352.

The end-to-end synthetic enrichment control observes one still-running close and `abandoned_count() == 0`, where one reserved slot is required. The original PR356 regression independently observes four blocked cleanup callbacks counted as zero. The exact PR356 helper fixes both retained controls. That repair needs appropriate ancestry and source-specific integration qualification; the passing component test does not authorize merging either draft.

## PR354 / PR356 dependency comparison

| Component | Exact source | Relationship |
| --- | --- | --- |
| PR352/base helper | blob `9fff565fd59d3d3d23a7a9f4e0a894bd742f8432` | Unchanged by PR352. Neither stalled-read deadlines nor late-cleanup slot retention are repaired here. |
| PR354 | head `a41c7a0d594d1fe26c16da395e6f6f9b33b07eca`, blob `2898798fe08eee87653db4b404f33bd24a069bd0` | Six commits and four paths above902. Adds bounded read supervision, post-read validation and shortening of known CPython HTTP socket timeouts. Does not fix the cleanup slot lifetime. |
| PR356 | head `1d475d926314ae116442bfe2b7cd268ad95ea12c`, blob `60b7e113607d88c26fe7cbcb772969c5af4619e4` | Four commits and four paths stacked on354. Keeps abandoned slots through cleanup and releases them in `finally`. Both helper changes are present in this exact component. |

The complete dependency commit/path inventories and raw commits are in `dependency-source-history.json` and `dependency-history/`. All changed head files, original tests and the authors' bug-hunt records are preserved in `dependency-source/`. This is a review of the helper dependency needed by PR352, not full independent qualification of all of PR354/356. The author's sixth PR354 test uses a real localhost HTTP server; it is preserved but was not executed in this bounded synthetic review. Its socket/Windows claims therefore remain author evidence and future qualification work.

## Executed evidence — overlapping selections stay separate

| Invocation | Actual outcome |
| --- | --- |
| Exact authored tests-before-fix commit, both new cases | **2 failed**, both intended elapsed-time assertions: about 1.5 s versus the 0.9 s bound; no setup errors |
| Exact PR352: enrichment intelligence, NVD pacing, cancellation latency, spec registry | **168 passed** in one clean invocation, including both new author cases |
| Exact PR352: seven independent attempt controls | **4 passed, 3 failed**: the two completion cases and inherited late-opener cleanup accounting |
| Seven original synthetic PR354/356 helper cases on base/PR352 helper | **3 passed, 4 failed**: three deadline cases and the retained cleanup count case |
| Same seven cases on exact PR354 helper | **6 passed, 1 failed**: cleanup count remains wrong |
| Same seven cases on exact PR356 helper | **7 passed** |
| Seven independent attempt controls on PR352 enrichment plus exact PR356 helper component | **5 passed, 2 failed**: cleanup is fixed, both completed-attempt deadline cases remain |
| Whole-repository Ruff over `src tests tools`, no cache | **Passed** |
| Existing environment `pip check` | **Passed** |

`junit-outcome-index.json` indexes every outcome. Commands, timings, stdout/stderr and JUnit files are preserved per invocation; no failed result was removed or rewritten. Every Python run used `-I -B`, explicit reviewed-source imports, no pytest autoload/conftest/cache, and an external scratch temporary root. Binding receipts assert the exact enrichment and netutil file paths and SHA-256 digests. The existing environment's editable metadata remains bound to the original Pages checkout; explicit source insertion is recorded, and no install or editable rebinding occurred.

Component comparisons load the identified netutil file directly in a fresh interpreter and record that they are not qualification of a combined Git tree. Counts are intentionally not added across overlapping runs. No full suite, native target, package, external HTTP call or localhost server was executed.

## Exact holds and ownership interpretation

Fresh final GETs retain the assigned heads, open state and author bodies. The merged discussion listings for PR352,353,354,356 are all empty. `author-holds-and-ownership.json` preserves complete bodies and captured timestamps.

- **PR352:** “Qualification status — NOT YET VERIFIED”; requires exact-head focused/full pytest, Ruff, dependency checks, applicable hosted matrices, independent review and a guarded merge. It says Root837FE PR351 and the KBC chain are intentionally untouched. No separate active-author lease is stated in the captured body.
- **PR353:** “Current qualification — NOT VERIFIED”; requires current-head qualification/review/no blockers and says to keep PR352 and Root837FE PR351 independent. No separate active-author lease is stated. Its previously sealed independent evidence is left unchanged.
- **PR354:** explicitly “Remaining gates — keep as draft” and “No release, no deployment, no merge until qualified,” including fresh integration ownership/main reconciliation.
- **PR356:** explicitly stacked on354; requires qualifying parent354 first, then retargeting/reconciling to main and checking the final head, plus coordination with the active integration owner.

Missing qualification is not recorded as a permanent ownership prohibition. Conversely, this review does not remove a hold, change draft status, authorize integration, or establish release readiness. The root owner separately controls layering and the later guarded integration process.

## Preservation and handoff

`pr352-and-netutil-dependencies.bundle` preserves the five PR352 commits and the complete PR354/356 chain, with prerequisite902 documented in its verified receipt. `author-tests-before-fix-source.tar` preserves the original red source; `reviewed-head-focused-source.tar` preserves the exact runtime, selected maintained tests, specifications and pytest configuration needed by this review. All tar payload identities and source blobs are checked in the archive preparation receipts. Expanded snapshots/private object cache are working material; portable copies are included in the final evidence archive.

No implementation is begun here. A later repair should retain all donor histories, fix the completed-attempt publication check, retain the reviewed cleanup accounting correction with its actual layering, and repeat focused source-specific checks plus independent and applicable hosted qualification. The current root Windows/native candidate and its records remain untouched.
