"""Stdlib-only helper that makes a blocking network call observe cancellation promptly (H9)."""
from __future__ import annotations

import http.client
import threading
from collections.abc import Callable
from functools import partial

MAX_ABANDONED = 4
_lock = threading.Lock()
_abandoned = 0


class Cancelled(Exception):
    """Raised when the cancel event fired while a blocking call was in flight."""


class DeadlineExceeded(Exception):
    """Raised when the request deadline passed before the body was complete."""


class CapExceeded(Exception):
    """Raised when the body is larger than the caller's byte cap."""


class TooManyAbandoned(OSError):
    """Previous cancelled calls have not yet released their sockets."""


def abandoned_count() -> int:
    with _lock:
        return _abandoned


def interruptible[T](call: Callable[[], T], cancel: threading.Event | None, *, poll: float = 0.1,
                     cleanup: Callable[[T], None] | None = None) -> T:
    """Run ``call`` and return its result, or raise `Cancelled` within ~``poll`` s of ``cancel.set()``.

    The call runs on a daemon thread. After abandonment the thread closes whatever it eventually
    returns through ``cleanup`` and publishes nothing else. At most MAX_ABANDONED abandoned threads
    may be alive at once; further calls fail with `TooManyAbandoned` instead of leaking more.
    """
    global _abandoned
    if cancel is None:
        return call()
    if cancel.is_set():
        raise Cancelled()
    with _lock:
        if _abandoned >= MAX_ABANDONED:
            raise TooManyAbandoned('previous requests still closing')
    done = threading.Event()
    state: dict = {'abandoned': False}

    def worker() -> None:
        global _abandoned
        try:
            outcome = (call(), None)
        except BaseException as exc:  # noqa: BLE001 - re-raised on the caller thread
            outcome = (None, exc)
        with _lock:
            late = state['abandoned']
            if late:
                _abandoned -= 1
            else:
                state['outcome'] = outcome
        if late and outcome[1] is None and cleanup is not None:
            try:
                cleanup(outcome[0])
            except Exception:  # noqa: BLE001 - best effort close
                pass
        done.set()

    threading.Thread(target=worker, daemon=True, name='patchtrace-net').start()
    while not done.wait(poll):
        if cancel.is_set():
            with _lock:
                if 'outcome' not in state:
                    state['abandoned'] = True
                    _abandoned += 1
                    raise Cancelled()
            break
    value, error = state['outcome']
    if error is not None:
        raise error
    return value


def _shorten_http_socket_timeout(response, remaining: float) -> None:
    """Bound CPython's blocking HTTP read so response.close() need not await a stalled reader.

    Never lengthen an existing per-operation timeout. Unknown response transports still use
    the interruptible deadline watcher below, without assuming private socket attributes.
    """
    if not isinstance(response, http.client.HTTPResponse):
        return
    raw = getattr(getattr(response.fp, 'raw', None), '_sock', None)
    if raw is None:
        return
    current = raw.gettimeout()
    timeout = max(0.001, remaining)
    if current is None or current > timeout:
        raw.settimeout(timeout)


def read_bounded(response, cap: int, *, deadline: float, clock: Callable[[], float],
                 cancel: threading.Event | None, chunk: int = 65536) -> bytes:
    """Read a whole body of at most ``cap`` bytes, honouring ``deadline`` and ``cancel`` on every read.

    ``read1`` returns whatever is available, so a server dripping one byte at a time cannot hold a
    single read open until a full chunk arrives; the deadline is re-checked after each small read.
    Raises `Cancelled`, `DeadlineExceeded` or `CapExceeded`; socket errors propagate to the caller.
    """
    class _ReadStop:
        def is_set(self) -> bool:
            return (cancel is not None and cancel.is_set()) or clock() >= deadline

    read = getattr(response, 'read1', response.read)
    stop = _ReadStop()
    data = bytearray()
    while True:
        if cancel is not None and cancel.is_set():
            raise Cancelled()
        remaining = deadline - clock()
        if remaining <= 0:
            raise DeadlineExceeded()
        _shorten_http_socket_timeout(response, remaining)
        try:
            piece = interruptible(partial(read, min(chunk, cap + 1 - len(data))), stop)
        except Cancelled:
            if cancel is not None and cancel.is_set():
                raise
            raise DeadlineExceeded() from None
        except TimeoutError:
            if clock() >= deadline:
                raise DeadlineExceeded() from None
            raise
        if cancel is not None and cancel.is_set():
            raise Cancelled()
        if clock() >= deadline:
            raise DeadlineExceeded()
        if not piece:
            return bytes(data)
        data.extend(piece)
        if len(data) > cap:
            raise CapExceeded()
