"""Bind an exact netutil component blob for dependency comparison, never a qualified combined tree."""
from __future__ import annotations

import hashlib
import importlib.metadata
import importlib.util
import json
import os
import sys
from pathlib import Path

source_arg, component_arg, label, output_arg, *selectors = sys.argv[1:]
source, component, output = map(lambda s: Path(s).resolve(), (source_arg, component_arg, output_arg))
assert (output / "tmp").is_dir()
os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
os.environ["QT_QPA_PLATFORM"] = "offscreen"
sys.path[:0] = [str(source / "src"), str(source), str(source / "tests")]
os.chdir(source)
import patchtrace  # noqa: E402

spec = importlib.util.spec_from_file_location("patchtrace.netutil", component)
module = importlib.util.module_from_spec(spec)
sys.modules["patchtrace.netutil"] = module
spec.loader.exec_module(module)
patchtrace.netutil = module
from patchtrace.enrichment import intelligence  # noqa: E402

assert Path(module.__file__).resolve() == component
assert Path(intelligence.__file__).resolve() == source / "src/patchtrace/enrichment/intelligence.py"
assert intelligence.interruptible is module.interruptible
assert module.abandoned_count() == 0
metadata = {
    "enrichment_source": str(source), "component_file": str(component),
    "component_sha256": hashlib.sha256(component.read_bytes()).hexdigest(),
    "enrichment_sha256": hashlib.sha256(Path(intelligence.__file__).read_bytes()).hexdigest(),
    "python": sys.executable, "python_version": sys.version,
    "editable_direct_url": importlib.metadata.distribution("patchtrace").read_text("direct_url.json"),
    "environment_rebound": False, "qualification_of_combined_source_claimed": False,
    "selectors": selectors,
}
(output / (label + "-binding.json")).write_text(json.dumps(metadata, indent=2) + "\n")
print(json.dumps(metadata, indent=2), flush=True)
import pytest  # noqa: E402

raise SystemExit(pytest.main(["-q", "--noconftest", "-p", "no:cacheprovider", "-o", "addopts=",
                             "--basetemp=" + str(output / "tmp" / label),
                             "--junitxml=" + str(output / (label + ".xml")), *selectors]))
