"""Independent review runner: explicit immutable-source binding, no environment rebinding."""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
import os
import sys
from pathlib import Path

source, label, output, *selectors = sys.argv[1:]
source = Path(source).resolve()
output = Path(output).resolve()
assert (output / "tmp").is_dir()
os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
os.environ["QT_QPA_PLATFORM"] = "offscreen"
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
sys.path[:0] = [str(source / "src"), str(source), str(source / "tests")]
os.chdir(source)
from patchtrace import netutil  # noqa: E402
from patchtrace.enrichment import intelligence  # noqa: E402

binding = []
for module, relative in ((netutil, "src/patchtrace/netutil.py"),
                         (intelligence, "src/patchtrace/enrichment/intelligence.py")):
    path = Path(module.__file__).resolve()
    assert path == source / relative, (path, source / relative)
    binding.append({"module": module.__name__, "file": str(path),
                    "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
assert netutil.abandoned_count() == 0
dist = importlib.metadata.distribution("patchtrace")
metadata = {"source": str(source), "python": sys.executable, "python_version": sys.version,
            "bindings": binding, "editable_direct_url": dist.read_text("direct_url.json"),
            "environment_rebound": False, "selectors": selectors}
(output / (label + "-binding.json")).write_text(json.dumps(metadata, indent=2) + "\n")
print(json.dumps(metadata, indent=2), flush=True)
import pytest  # noqa: E402

raise SystemExit(pytest.main(["-q", "--noconftest", "-p", "no:cacheprovider",
                             "-o", "addopts=", "--basetemp=" + str(output / "tmp" / label),
                             "--junitxml=" + str(output / (label + ".xml")), *selectors]))
