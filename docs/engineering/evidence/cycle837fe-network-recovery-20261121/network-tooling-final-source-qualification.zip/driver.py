"""Qualify the frozen, privately integrated network recovery source only."""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from datetime import datetime, timezone
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/837fe19aae3a')
REPO = ROOT / 'PatchTrace-network-recovery-followup'
PYTHON = ROOT / 'pilot-tooling-source-validation-venv/bin/python'
OUT = ROOT / 'evidence/network-tooling-final-source-qualification'
HEAD = '9610919d29010d53cf00af3b7c38207ffd84f945'
TREE = '3d5e2965ef26235610a08fd8378cac078c6bd9a0'
BASE = 'd60ac40daf767fe6a93ae152feb21235f6e75e0b'


def write_json(path: Path, value) -> None:
    path.write_text(json.dumps(value, indent=2) + '\n')


def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=REPO).decode().strip()


def check_source() -> dict:
    result = {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
              'status': git('status', '--porcelain=v1')}
    assert result == {'head': HEAD, 'tree': TREE, 'status': ''}, result
    return result


OUT.mkdir(exist_ok=False)
(OUT / 'tmp').mkdir()
write_json(OUT / 'source-before.json', check_source())
selectors = [
    'tests/test_netutil_read_deadline.py',
    'tests/test_netutil_abandoned_cleanup.py',
    'tests/test_cancel_latency.py',
    'tests/test_providers_transport.py',
    'tests/test_kev_transport.py',
    'tests/test_intel_transport.py',
    'tests/test_csaf_redirect_integrity.py',
    'tests/test_enrichment_intelligence.py',
    'tests/test_optional_import_recovery.py',
    'tests/test_optional_deps.py',
    'tests/test_search_capability.py',
    'tests/test_search_fuzzy.py',
    'tests/test_search_synergy.py',
    'tests/test_doctor_cli.py',
    'tests/test_intel_offline_cache.py',
    'tests/test_intel_discovery.py',
    'tests/test_spec_registry.py',
]
selectors += ['tests/test_pilot_eval_metrics.py', 'tests/test_pilot_eval_gate.py',
    'tests/test_pilot_dependency_lock.py', 'tests/test_codex5_command_audit_20261121.py',
    'tests/test_codex_pkg_workflows.py', 'tests/test_site_dependency_lock.py',
    'tests/test_pilot_properties.py::test_localization_is_idempotent_and_ignores_the_clock',
    'tests/test_sigstore_dependency_lock.py', 'tests/test_verify_backend_pins.py']
assert len(set(selectors)) == len(selectors) == 26
bootstrap = '''import sys,json,hashlib,importlib,importlib.metadata
from pathlib import Path
checkout=Path(sys.argv[1]).resolve(); receipt=Path(sys.argv[2]); args=sys.argv[3:]
sys.path[:0]=[str(checkout/'src'),str(checkout/'tests'),str(checkout)]
modules={}
for name,relative in [
 ('patchtrace','src/patchtrace/__init__.py'),
 ('patchtrace.netutil','src/patchtrace/netutil.py'),
 ('patchtrace.enrichment.intelligence','src/patchtrace/enrichment/intelligence.py'),
 ('patchtrace.intelligence.csaf.transport','src/patchtrace/intelligence/csaf/transport.py'),
 ('patchtrace.optional_deps','src/patchtrace/optional_deps.py'),
 ('patchtrace.pilot.contracts','src/patchtrace/pilot/contracts.py'),
 ('tools.ci_pip_install_audit','tools/ci_pip_install_audit.py')]:
 module=importlib.import_module(name); path=Path(module.__file__).resolve()
 assert path==checkout/relative,(name,path)
 modules[name]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
toolsite=Path('/workspace/scratch/837fe19aae3a/pilot-tooling-source-validation-venv/lib/python3.12/site-packages')
expected={'pytest':'9.2.0','hypothesis':'6.170.17','sortedcontainers':'2.4.0','iniconfig':'2.3.1','packaging':'26.3','pluggy':'1.7.0','pygments':'2.21.0'}
tooling={}
for name,version in expected.items():
 d=importlib.metadata.distribution(name); location=Path(d.locate_file('')).resolve()
 assert d.version==version and location==toolsite,(name,d.version,location)
 mod=importlib.import_module(name); actual=Path(mod.__file__).resolve(); assert actual.is_relative_to(toolsite),(name,actual)
 tooling[name]={'version':d.version,'location':str(location),'module':str(actual)}
receipt.write_text(json.dumps({'tooling':tooling,'python':sys.executable,'version':sys.version,'checkout':str(checkout),
 'modules':modules,'versions':{name:importlib.metadata.version(name) for name in ('pytest','ruff','pydantic','PySide6')},
 'source_binding':'Explicit isolated bootstrap; existing editable installation unchanged'},indent=2)+'\\n')
import pytest
result=pytest.main(args)
for name,expected in modules.items():
 module=importlib.import_module(name)
 assert str(Path(module.__file__).resolve())==expected['path'],name
 assert hashlib.sha256(Path(expected['path']).read_bytes()).hexdigest()==expected['sha256'],name
raise SystemExit(result)
'''
(OUT / 'pytest-bootstrap.py').write_text(bootstrap)
env = dict(os.environ, QT_QPA_PLATFORM='offscreen')
executions = []


def run(label: str, argv: list[str], limit: int) -> dict:
    started = datetime.now(timezone.utc).isoformat()
    start = time.monotonic()
    with (OUT / f'{label}.stdout.txt').open('wb') as stdout, (OUT / f'{label}.stderr.txt').open('wb') as stderr:
        try:
            proc = subprocess.run(argv, cwd=REPO, env=env, stdout=stdout, stderr=stderr, timeout=limit)
        except subprocess.TimeoutExpired:
            write_json(OUT / f'{label}.timeout.json', {'argv': argv, 'limit_seconds': limit, 'source': HEAD, 'started_at': started})
            raise
    result = {'label': label, 'source': HEAD, 'tree': TREE, 'argv': argv, 'cwd': str(REPO),
              'started_at': started, 'seconds': time.monotonic() - start, 'exit_code': proc.returncode,
              'source_after': check_source()}
    executions.append(result)
    write_json(OUT / 'executions.json', executions)
    print(json.dumps({key: result[key] for key in ['label', 'source', 'seconds', 'exit_code']}), flush=True)
    return result


argv = [str(PYTHON), '-I', '-B', str(OUT / 'pytest-bootstrap.py'), str(REPO), str(OUT / 'source-binding.json'),
        '-q', *selectors, '-p', 'no:cacheprovider', '--rootdir=' + str(REPO),
        '--basetemp=' + str(OUT / 'tmp/maintained'), '--junitxml=' + str(OUT / 'maintained.xml')]
maintained = run('maintained', argv, 180)
cases = ET.parse(OUT / 'maintained.xml').getroot().findall('.//testcase')
counts = {'cases': len(cases), 'passed': sum(not any(x.tag in {'failure', 'error', 'skipped'} for x in c) for c in cases),
          'failed': sum(c.find('failure') is not None for c in cases),
          'errors': sum(c.find('error') is not None for c in cases),
          'skipped': sum(c.find('skipped') is not None and c.find('skipped').attrib.get('type') != 'pytest.xfail' for c in cases),
          'xfailed': sum(c.find('skipped') is not None and c.find('skipped').attrib.get('type') == 'pytest.xfail' for c in cases)}
assert len({(c.attrib.get('classname'),c.attrib.get('name')) for c in cases}) == len(cases)
expected_failures = [c.attrib.get('classname','')+'::'+c.attrib.get('name','') for c in cases if c.find('skipped') is not None and c.find('skipped').attrib.get('type') == 'pytest.xfail']
assert sorted(expected_failures) == sorted(['tests.test_codex5_command_audit_20261121::test_all_explicit_workflow_pip_installs_are_protected','tests.test_codex_pkg_workflows::test_pip_downloads_require_hashes']), expected_failures
maintained['junit'] = counts
write_json(OUT / 'executions.json', executions)
print(json.dumps({'junit': counts}), flush=True)
assert maintained['exit_code'] == 0 and not any(counts[k] for k in ['failed', 'errors', 'skipped']), counts
checks = [
    run('whole-ruff', [str(PYTHON), '-I', '-B', '-m', 'ruff', 'check', '--no-cache', 'src', 'tests', 'tools'], 120),
    run('pip-check', [str(PYTHON), '-I', '-B', '-m', 'pip', 'check'], 120),
]
assert all(r['exit_code'] == 0 for r in checks), checks
write_json(OUT / 'qualification.json', {
    'schema': 'patchtrace/network-tooling-combined-local-qualification/1',
    'observed_at': datetime.now(timezone.utc).isoformat(), 'source': HEAD, 'tree': TREE, 'base': BASE,
    'selectors': selectors, 'maintained': maintained, 'tooling': checks, 'expected_failures': expected_failures,
    'source_before_and_after_exact_and_clean': True, 'environment_rebound_or_installed': False,
    'scope': 'Maintained source tests using authored loopback, fake transport, local files and registry fixtures only',
    'full_suite_run': False, 'native_or_windows_claim': False, 'separate_source_counts_not_aggregated': True,
    'remaining_gates': ['Independent combined-source review', 'Final records and actual-main ancestry reconciliation',
                        'Exact final-source hosted full Linux and Windows QA and all applicable platform/native jobs',
                        'Fresh current-head/main/ownership/approval guards before expected-head REST merge'],
})
write_json(OUT / 'source-after.json', check_source())
(OUT / 'driver.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'complete': True, 'source': HEAD, 'tree': TREE, 'junit': counts}), flush=True)
