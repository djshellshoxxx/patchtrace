import sys,json,hashlib,importlib,importlib.metadata
from pathlib import Path
checkout=Path(sys.argv[1]).resolve(); receipt=Path(sys.argv[2]); args=sys.argv[3:]
sys.path[:0]=[str(checkout/'src'),str(checkout/'tests'),str(checkout)]
modules={}
for name,relative in [
 ('patchtrace','src/patchtrace/__init__.py'),
 ('patchtrace.netutil','src/patchtrace/netutil.py'),
 ('patchtrace.enrichment.intelligence','src/patchtrace/enrichment/intelligence.py'),
 ('patchtrace.intelligence.csaf.transport','src/patchtrace/intelligence/csaf/transport.py'),
 ('patchtrace.optional_deps','src/patchtrace/optional_deps.py'),
 ('patchtrace.pilot.contracts','src/patchtrace/pilot/contracts.py'),
 ('tools.ci_pip_install_audit','tools/ci_pip_install_audit.py')]:
 module=importlib.import_module(name); path=Path(module.__file__).resolve()
 assert path==checkout/relative,(name,path)
 modules[name]={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
toolsite=Path('/workspace/scratch/837fe19aae3a/pilot-tooling-source-validation-venv/lib/python3.12/site-packages')
expected={'pytest':'9.2.0','hypothesis':'6.170.17','sortedcontainers':'2.4.0','iniconfig':'2.3.1','packaging':'26.3','pluggy':'1.7.0','pygments':'2.21.0'}
tooling={}
for name,version in expected.items():
 d=importlib.metadata.distribution(name); location=Path(d.locate_file('')).resolve()
 assert d.version==version and location==toolsite,(name,d.version,location)
 mod=importlib.import_module(name); actual=Path(mod.__file__).resolve(); assert actual.is_relative_to(toolsite),(name,actual)
 tooling[name]={'version':d.version,'location':str(location),'module':str(actual)}
receipt.write_text(json.dumps({'tooling':tooling,'python':sys.executable,'version':sys.version,'checkout':str(checkout),
 'modules':modules,'versions':{name:importlib.metadata.version(name) for name in ('pytest','ruff','pydantic','PySide6')},
 'source_binding':'Explicit isolated bootstrap; existing editable installation unchanged'},indent=2)+'\n')
import pytest
result=pytest.main(args)
for name,expected in modules.items():
 module=importlib.import_module(name)
 assert str(Path(module.__file__).resolve())==expected['path'],name
 assert hashlib.sha256(Path(expected['path']).read_bytes()).hexdigest()==expected['sha256'],name
raise SystemExit(result)
