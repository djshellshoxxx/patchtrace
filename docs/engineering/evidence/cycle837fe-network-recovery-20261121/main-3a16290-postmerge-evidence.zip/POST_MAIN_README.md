# Main3a completed post-merge qualification

This is the completed source-specific record for PR351 main merge 3a16290c0fcc4e0c21712fe10474a3ff33fad336, tree 6001ef506c38930fd590bd827f428b997c3b2797. Final observation: 2026-11-21 14:47:56 UTC.

QA run 44906524287 and Pages run 44906524308 completed successfully on attempt 1. The 14 actual jobs comprise 12 successful executed jobs with verified main3a checkout logs and two intentional publication skips. All 10 required QA jobs passed.

Linux full: 24,295 passed / 53 skipped / 4 expected failures. Windows full: 24,164 passed / 185 skipped / 3 expected failures. Both JUnit reports have 24,352 cases and zero failures/errors. Boundary controls are separate. Ubuntu Qt shards: 13,320 / 10,860 / 9,840 / 8,460; Windows Qt: 10,620. Warnings remain in the detailed receipts.

Windows build, 64/0 frozen CLI assertions, portable checksum/extraction/runtime and installer install/launch/non-destructive uninstall passed. Linux packaging and both Ubuntu 22.04/24.04 frozen smokes passed 64/0 each, with actual downloaded artifact digest, tar checksum and offscreen/XCB checks. Large product binaries remain at their recorded GitHub artifact IDs/URLs; metadata and hosted checksums are included.

The release gate truthfully reported publish=true for five counted merges. Actual release job 136880181515 was skipped after successful dependencies. Both markers are verified in the actual merge subject and body. The fresh 59-release identity list matches the prior sealed main902 baseline; no release is visible with a publication time at or after this merge.

The repaired Pages run passed 248 site tests with one skip, built the site, skipped configure-pages, uploaded the artifact, and skipped deploy. The unchanged earlier completion archive is embedded as pages-completion-main-3a.zip (SHA256 1b9cec5fed0b85fe85caf95181f14b4a1a09c7f75fb0e25c5e6685059a6031c9). It contains the original site artifact ZIP and all bounded Pages raw evidence. Large Pages payloads are not duplicated at the parent archive level.

The original 13:22 pending jobs-snapshot-004.json is retained unchanged. Earlier bounded receipts and README describe their own observation cuts; post-main-qualification.json is the definitive completion record. The prior main902 Pages404 remains separately identified and is not rewritten.

Seven actual platform expected-failure records remain open: two CODEX5 cases on both platforms, missing live Ghidra directory on both platforms, and missing llvm-pdbutil on Linux. This record does not qualify later PR357 or transfer native results between sources.

The archive manifest hashes every parent-level payload; its external receipt records the final ZIP and manifest hashes. The nested Pages ZIP is also CRC/member-hash verified. No CI, source, ref, release or Pages setting mutation occurred.
