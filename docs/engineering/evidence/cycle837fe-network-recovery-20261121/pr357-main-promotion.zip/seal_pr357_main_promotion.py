from pathlib import Path
import datetime, hashlib, json, shutil, zipfile

root = Path(__file__).resolve().parent
out = root / 'evidence/pr357-main-promotion'
sha = lambda b: hashlib.sha256(b).hexdigest()
read = lambda n: json.loads((out / n).read_text())
guard, actual, proof = read('premerge-guard.json'), read('postmerge-api.json'), read('actual-main-proof.json')
expected = 'ea16019601486c831941f9bc1a7ba5862a170317'
assert actual['pr']['merged'] and actual['pr']['merge_commit_sha'] == expected
assert actual['main']['object']['sha'] == expected
assert actual['commit']['tree']['sha'] == proof['tree'] == '4a07cd88ded407bef30a8aeb81961e4041822dc2'
assert [p['sha'] for p in actual['commit']['parents']] == proof['ordered_parents']
assert guard['pr']['head']['sha'] == proof['source_head'] and guard['main']['object']['sha'] == proof['previous_main']
assert proof['complete_source_diff_empty'] and proof['subject_markers_verified'] and proof['body_markers_verified']
body = read('body-update-verification.json')
assert body['prior_body_exact_suffix_preserved'] and body['actual_merge'] == expected
assert len(guard['checks']['check_runs']) == 18
assert sum(c['conclusion'] == 'success' for c in guard['checks']['check_runs']) == 16
assert sum(c['conclusion'] == 'skipped' for c in guard['checks']['check_runs']) == 2
shutil.copyfile(__file__, out / Path(__file__).name)
files = [{'path': p.relative_to(out).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())} for p in sorted(out.rglob('*')) if p.is_file() and p.name not in {'manifest.json', 'archive-receipt.json', 'pr357-main-promotion.zip'}]
manifest = {'schema': 'patchtrace/pr357-main-promotion-manifest/1', 'actual_main': expected, 'tree': proof['tree'], 'source_head': proof['source_head'], 'source_qualification_is_separate': True, 'files': files}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
archive = out / 'pr357-main-promotion.zip'
assert not archive.exists()
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for row in files: z.write(out / row['path'], row['path'])
    z.write(out / 'manifest.json', 'manifest.json')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in files: assert len(z.read(row['path'])) == row['bytes'] and sha(z.read(row['path'])) == row['sha256']
receipt = {'sealed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'archive': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes()), 'member_count': len(files) + 1, 'manifest_sha256': sha((out / 'manifest.json').read_bytes()), 'actual_main_proof_sha256': sha((out / 'actual-main-proof.json').read_bytes()), 'all_payload_hashes_and_crc_verified': True, 'main_postmerge_qualification_pending': True}
(out / 'archive-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
