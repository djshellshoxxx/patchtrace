# ea160 completed native-only checkpoint

This immutable checkpoint records the completed native phase of actual main `ea16019601486c831941f9bc1a7ba5862a170317` (tree `4a07cd88ded407bef30a8aeb81961e4041822dc2`), after PR357 merged at 2026-11-21T15:32:22Z. It does not close main QA or publication gates.

## Completed native evidence

Automatic push run 44919714141, attempt1, completed successfully. All five actual checkout logs identify the exact main commit: three positive known-patch analyses, one expected cached-PDB negative control, and one application raw-analysis cache case. Four original report artifact ZIPs are retained, with API size/digest and ZIP CRC validation. No local engine or analyzed target was executed.

The original Ghidra ZIP cache had five actual misses, one successful post-save, and four reservation declines. All five pinned SHA-256 checks and fresh extraction steps succeeded. This source has no observed warm restore. The application raw-cache result is separate: it reports equal within-case raw hashes, one match per phase, and explicit reuse; its small diagnostic artifact does not contain the raw output bytes for independent recomputation.

## Explicit partial observation

At 2026-11-21 15:54:33 UTC, QA run 44919714193 had seven full/Qt jobs in progress and one successful release-gate job. The gate computed publish=true with six counted merges. The actual release job was not present yet. Full/JUnit/Qt, Windows27/build/frozen/producer/consumer, Linux package and both frozen smoke results remain pending in this checkpoint. Both merge markers are verified in the actual subject and body, but they do not replace observation of the eventual release job.

The exact-head run inventory at this cut contains QA and native only; no Pages run is observed. No deploy skip or prior-source Pages acceptance is claimed for ea160.

## Sources and integrity

`initial-source-and-runs.json` preserves the independent API guard; `root-actual-main-promotion-proof.json` preserves the root Git/API proof. `jobs-snapshot-001.json` and `jobs-snapshot-002.json` retain their original observations. `native-summary.json`, the five raw job JSON/log/cache receipts, pinned workflow sources, and four original artifact ZIPs provide the portable evidence. `evidence-manifest.json` hashes every payload; `archive-receipt.json` separately hashes the ZIP, manifest and summary. Later complete-main evidence should embed this exact checkpoint without rewriting it.
