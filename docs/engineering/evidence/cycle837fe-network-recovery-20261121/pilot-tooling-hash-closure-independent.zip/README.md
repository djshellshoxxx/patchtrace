# Independent review: first pilot tooling hash closure

## Verdict and exact source

**CLEAR for this bounded first installer and reviewed source integration. No blocker was found.**

The reviewed clean head is `f08632ab81e6ab24fcc34fc994dd2dda2556d267`, complete tree `cb959c1bc0189697241ec2a89c9ec22efabceded`, based on `96baaee20f390a3f2a5629de3764d32323bb80e5`. The review author changed only this scratch evidence directory and five new review environments. Source, existing environments, root's integration checkout, PR357, refs, PR metadata and CI were not changed.

The actual Git objects preserve the four ordered commits: specification `cd11919b`, tests `1177902b`, implementation `1dcb9729`, and quote correction `f08632ab`. All subjects and bodies retain both opt-outs. The source bundle verifies against its exact 96 prerequisite. Exactly seven paths change; **4,826 other tracked entries preserve their modes and blob identities**. No application runtime, dependencies, preregistration, pilot metric/gate implementation, report implementation, other workflow, QA/TODO or historical ledger bytes change.

## Actual seven-wheel closure

The accepted new baseline is successful main3a Linux QA run 44906524287 / job 136853186420, with pytest 9.2.0, Hypothesis 6.170.17, iniconfig 2.3.1, packaging 26.3, pluggy 1.7.0, Pygments 2.21.0 and sortedcontainers 2.4.0. The prior independently reviewed baseline and available-history observation are retained in the preflight ZIP. This is a new pilot tooling baseline. It does not assert a successful historical pilot run.

The reviewer verified all seven retained wheel byte lengths and SHA-256 digests against the accepted artifact metadata, fresh version-specific registry JSON, embedded wheel Name/Version/Requires-Python/Requires-Dist, compatible filename and WHEEL tags, and the exact final lock. All ZIP CRCs and unique embedded metadata were checked. The five active dependency edges close over the seven selected versions on Linux x86_64 / CPython 3.12 without extras. The five shared pytest packages match the existing reviewed Pages lock.

There are **298 independent mechanical checks**: 237 archive/wheel/metadata checks and 61 source/history/census checks. These are inspection checks, separate from pytest and installer probes.

## Fresh normal-resolver checks

Five newly created `--without-pip` environments started with no installed distributions. Existing pip 25.0.1 drove each target using `--python`; CPython 3.12.14 and the pip bootstrap are disclosed, not artifact-locked. Inherited PIP variables were removed and `PIP_CONFIG_FILE=/dev/null` disabled configuration. The exact independently verified local wheelhouse supplied all seven wheels with `--require-hashes --only-binary=:all:` and normal dependency resolution. `--no-index` limited the replay to retained bytes; it did not disable dependency resolution. There was no `--no-deps`, hash bypass, new download or existing-environment installation.

| Fresh case | Observed result |
|---|---|
| Exact final lock | Exit 0; all seven exact versions installed in the new environment; every pip-report digest matches; pip check passed |
| Present exact sortedcontainers pin, missing hash | Refused for the missing required hash; actual accepted wheel available |
| Omitted sortedcontainers entry | Normal resolver discovered the transitive requirement and refused the absent exact pin in hash mode |
| Wrong sortedcontainers hash | Refused with the intended expected/actual digest mismatch |
| Wrong Hypothesis hash | Refused with the intended expected/actual digest mismatch |

All four negative environments remained empty. They are expected refusal controls, not product-test failures. Full commands, effective pip configuration, raw outputs, mutated lock copies and before/after distribution states are retained.

## Exact source tests and retained failures

The focused independent replay ran from the fresh seven-package environment using `-I -B` and explicit final-source paths. All seven tooling metadata locations and actual import origins were checked before/after. Trusted application dependencies were appended after the fresh tool site-packages in `sys.path`; the existing dependency environment was not modified or rebound, and its Hypothesis version could not satisfy the selected-tooling check.

**259 tests passed and two existing strict CODEX-5 cases xfailed, across 261 distinct cases**, with zero failed cases, errors, ordinary skips or output warnings. This includes the unchanged 19 pilot metrics/gate cases, four original workflow tests, the new lock contract, scanner/typed failure controls, registry and one unchanged Hypothesis property. The unchanged report writer emitted its exact preregistration identity, empty arms and `not-evaluated` status. This is unit/report evidence, not a locked-data pilot evaluation.

The author history is preserved without aggregation: test stage 1177902b collected four cases and failed three real assertions with one pass against the unchanged parent workflow and absent lock. Initial 1dcb retained 233 passes/four YAML failures/one xfail in the affected selection, plus a separate 19-case pilot pass. In that initial source, the typed broad C5 gate correctly failed for malformed YAML. Final f086 adds enclosing YAML quotes only; it changes neither installer arguments, lock bytes nor the original new assertions. Final author affected results were 236 passes/two strict xfails, plus the separate 19 pilot passes. Actual final Ruff and pip receipts were verified; these were not rerun or combined into the independent test total.

## Workflow and remaining limits

Only the first run scalar changes. Entire workflow text and parsed mappings become exactly the parent after reversing that scalar. Manual-only/advisory/read-only scope, Ubuntu/Python 3.12, 30-minute budget, Action pins, ordering, preregistration hash, evaluation selectors, report command and aggregate artifact upload are preserved. The second `python -m pip install -e .` remains unchanged and unprotected.

Actual source scanning preserves 21 workflows, 203 run scalars, 38 installing jobs and 42 explicit install commands. Source 96 remains historically **1 protected/41 unprotected**; final f086 is **2 protected/40 unprotected**, with only pilot's first command added. Both broad strict-xfail function ASTs are unchanged, including the typed missing-boundary exception. Parser/discovery errors remain hard failures. The older ae69 census and 181/16 historical branch snapshot remain unchanged.

The separate editable application/build closure, other 40 installers, broader C5 gates, full final integrated-source hosted qualification, applicable Windows/native/package acceptance, hosted index access, actual pilot evaluation and release readiness remain open. Root retains publication and integration authority. No hosted run, native engine or external target was executed for this review.

## Portable evidence

`review.json` gives the machine-readable verdict. `artifact-proof.json`, `source-proof.json`, both check lists, full Git inventories, `actual-workflow-census.json`, retained-source history and raw source-test XML provide the proof. `install-proof.json` links all five fresh resolver receipts. Both immutable author and prior-preflight ZIPs are included under `inputs/`, preserving original failures, source bundle, accepted baseline and actual seven wheels. Disposable environments/caches are excluded. The duplicate review wheelhouse is excluded because those exact bytes remain in the nested author archive. `manifest.json` covers every payload; the outer archive receipt is kept outside the ZIP to avoid circular hashes.
