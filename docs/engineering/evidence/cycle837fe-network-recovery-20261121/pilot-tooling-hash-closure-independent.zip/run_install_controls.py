"""Fresh final-lock resolver checks against independently verified retained wheels."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import datetime,hashlib,json,os,subprocess,time
O=Path(__file__).resolve().parent;R=O.parents[1];P=R/'repair-pilot-tooling-hash-closure'
H='f08632ab81e6ab24fcc34fc994dd2dda2556d267';T='cb959c1bc0189697241ec2a89c9ec22efabceded'
HOST=R/'pages-config-hold-venv/bin/python';W=O/'verified-wheelhouse'
proof=json.loads((O/'artifact-proof.json').read_text());V=proof['versions'];raw=(P/'tools/calibration/pilot/requirements-ci.lock').read_text()
assert proof['source']==H and proof['all_passed'] and hashlib.sha256(raw.encode()).hexdigest()==proof['lock_sha256']
env={k:v for k,v in os.environ.items() if not k.startswith('PIP_') and k not in {'PYTHONPATH','PYTHONHOME','VIRTUAL_ENV'}}
env.update(PIP_CONFIG_FILE=os.devnull,PIP_DISABLE_PIP_VERSION_CHECK='1',PIP_NO_INPUT='1')
assert 'PIP_NO_DEPS' not in env
digest={x['name']:x['sha256'] for x in proof['artifacts']}
cases={'positive':raw,
       'present-transitive-pin-missing-hash':raw.replace('sortedcontainers==2.4.0 --hash=sha256:'+digest['sortedcontainers'],'sortedcontainers==2.4.0'),
       'omitted-transitive-entry':'\n'.join(s for s in raw.splitlines() if not s.startswith('sortedcontainers=='))+'\n',
       'wrong-transitive-hash':raw.replace(digest['sortedcontainers'],'0'*64),
       'wrong-top-level-hash':raw.replace(digest['hypothesis'],'0'*64)}
assert len(set(cases.values()))==5
for x in proof['artifacts']:
 data=(W/x['filename']).read_bytes();assert hashlib.sha256(data).hexdigest()==x['sha256'] and len(data)==x['bytes']

def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def run(d,label,args):
 start=time.monotonic();began=datetime.datetime.now(datetime.timezone.utc).isoformat()
 with (d/(label+'.stdout.txt')).open('wb') as out,(d/(label+'.stderr.txt')).open('wb') as err:
  try:result=subprocess.run(list(map(str,args)),cwd=d,env=env,stdout=out,stderr=err,timeout=120)
  except subprocess.TimeoutExpired:
   save(d/(label+'.timeout.json'),{'argv':list(map(str,args)),'seconds':120});raise
 record={'argv':list(map(str,args)),'cwd':str(d),'started_at':began,'seconds':time.monotonic()-start,'exit_code':result.returncode}
 save(d/(label+'.command.json'),record);return record
def distributions(python):
 code='import importlib.metadata,json;print(json.dumps({d.metadata["Name"].lower():{"version":d.version,"location":str(d.locate_file(""))} for d in importlib.metadata.distributions()},sort_keys=True))'
 return json.loads(subprocess.check_output([str(python),'-I','-B','-c',code],env=env))
def execute(item):
 name,text=item;d=O/'install-controls'/name;d.mkdir(parents=True,exist_ok=False)
 target=O/'_environments'/name;assert not target.exists();lock=d/'requirements.lock';lock.write_text(text)
 created=run(d,'create-env',[HOST,'-I','-B','-m','venv','--without-pip',target]);assert created['exit_code']==0
 py=target/'bin/python';before=distributions(py);assert before=={},before
 assert 'include-system-site-packages = false' in (target/'pyvenv.cfg').read_text()
 config=run(d,'pip-config',[HOST,'-I','-B','-m','pip','--python',py,'config','debug']);assert config['exit_code']==0
 args=[HOST,'-I','-B','-m','pip','--python',py,'install','--no-index','--find-links',W,'--no-cache-dir','--require-hashes','--only-binary=:all:','--report',d/'pip-report.json','-r',lock]
 assert '--no-deps' not in args
 installed=run(d,'install',args);after=distributions(py);error=(d/'install.stderr.txt').read_text();output=(d/'install.stdout.txt').read_text()
 record={'case':name,'source':H,'tree':T,'environment':str(target),'before':before,'after':after,'lock_sha256':hashlib.sha256(lock.read_bytes()).hexdigest(),'create':created,'install':installed,'pip_config':config,'all7wheels_available':len(list(W.glob('*.whl')))==7,'dependency_resolution_enabled':True,'network_index_disabled_for_verified_local_wheel_replay':True,'PIP_environment_removed':True,'PIP_CONFIG_FILE':os.devnull}
 save(d/'receipt.json',record)
 if name=='positive':
  assert installed['exit_code']==0 and {k:v['version'] for k,v in after.items()}==V,record
  site=target/'lib/python3.12/site-packages';assert all(Path(x['location']).resolve()==site for x in after.values())
  check=run(d,'pip-check',[HOST,'-I','-B','-m','pip','--python',py,'check']);assert check['exit_code']==0;record['pip_check']=check
  report=json.loads((d/'pip-report.json').read_text());assert len(report['install'])==7
  for item in report['install']:
   name_=item['metadata']['name'].lower();assert item['metadata']['version']==V[name_] and item['download_info']['archive_info']['hashes']['sha256']==digest[name_]
  record['outcome']='Exact7 installed with normal resolver; pip check and all7 report digests verified'
 else:
  assert installed['exit_code']!=0 and after=={},record
  assert 'No matching distribution found' not in error and 'Could not find a version' not in error
  if name=='present-transitive-pin-missing-hash':
   assert 'Hashes are required in --require-hashes mode' in error and 'sortedcontainers==2.4.0' in error and digest['sortedcontainers'] in error,error
   record['outcome']='Present exact transitive pin without hash refused; accepted wheel still available'
  elif name=='omitted-transitive-entry':
   assert '--require-hashes mode' in error and 'versions pinned with ==' in error and 'sortedcontainers' in error,error
   record['outcome']='Normal resolver discovers transitive requirement and refuses missing exact pin/hash'
  else:
   package='hypothesis' if name=='wrong-top-level-hash' else 'sortedcontainers'
   assert 'THESE PACKAGES DO NOT MATCH THE HASHES' in error and package in error and '0'*64 in error and digest[package] in error,error
   record['outcome']='Deliberate '+package+' digest mismatch refused'
 save(d/'receipt.json',record);return record

assert subprocess.check_output(['git','-C',str(P),'rev-parse','HEAD']).decode().strip()==H
assert not subprocess.check_output(['git','-C',str(P),'status','--porcelain=v1']).strip()
with ThreadPoolExecutor(max_workers=5) as pool:
 futures=[(name,pool.submit(execute,(name,text))) for name,text in cases.items()];records=[];errors=[]
 for name,future in futures:
  try:records.append(future.result())
  except BaseException as exc:errors.append({'case':name,'error':repr(exc)})
save(O/'install-control-errors.json',errors)
save(O/'install-proof.json',{'source':H,'tree':T,'records':records,'errors':errors,'fresh_environments':5,'successful_installs':sum(x['case']=='positive' and x['install']['exit_code']==0 for x in records),'expected_refusals':sum(x['case']!='positive' and x['install']['exit_code']!=0 for x in records),'actual_wheel_downloads':False,'existing_environment_rebound_or_mutated':False})
assert not errors and len(records)==5,errors
assert not subprocess.check_output(['git','-C',str(P),'status','--porcelain=v1']).strip()
print(json.dumps({'source':H,'successful_fresh_installs':1,'intended_fresh_refusals':4,'installed_versions':V,'errors':errors},indent=2))
