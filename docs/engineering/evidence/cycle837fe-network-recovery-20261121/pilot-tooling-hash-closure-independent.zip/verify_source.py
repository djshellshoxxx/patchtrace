"""Read-only exact-object, workflow, gate, census and retained-history proof."""
from __future__ import annotations

import ast
import copy
from dataclasses import asdict
from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
REPO = ROOT / "repair-pilot-tooling-hash-closure"
AUTHOR = ROOT / "evidence/pilot-tooling-hash-closure-repair"
BASE = "96baaee20f390a3f2a5629de3764d32323bb80e5"
HEAD = "f08632ab81e6ab24fcc34fc994dd2dda2556d267"
TREE = "cb959c1bc0189697241ec2a89c9ec22efabceded"
STAGES = [
    ("cd11919b47df46b2b9826da1daf0d1fa4e39af5b", "69960ef2811df6edd21f6c719cb62a1c5c585725"),
    ("1177902b2204314c201900a8def6b7ca69a83515", "eb6670fb6a568d91193e8969a3f72a605cfc653c"),
    ("1dcb9729e00ba1197861f801b83e7d414d38950b", "9aef9c69c4ba34f04c55db7ca45427113cb2c68e"),
    (HEAD, TREE),
]
WORKFLOW = ".github/workflows/pilot-eval.yml"
LOCK = "tools/calibration/pilot/requirements-ci.lock"
NEW_TEST = "tests/test_pilot_dependency_lock.py"
CENSUS_TEST = "tests/test_codex5_command_audit_20261121.py"
SPEC = "docs/specs/pilot-evaluation-tooling-hashes.md"
ALLOWED = {WORKFLOW, LOCK, NEW_TEST, CENSUS_TEST, SPEC, "docs/modules.md", "docs/specs/REGISTRY.md"}
STAGE_PATHS = [
    {SPEC, "docs/modules.md", "docs/specs/REGISTRY.md"}, {NEW_TEST}, {WORKFLOW, LOCK, CENSUS_TEST}, {WORKFLOW},
]
checks = []


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")


def check(label, condition):
    checks.append({"check": label, "passed": bool(condition)})
    save("source-checks.json", checks)
    assert condition, label


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(["git", "-C", str(REPO), *args])


def blob(rev, path):
    return git("show", f"{rev}:{path}")


def inventory(rev):
    raw = git("ls-tree", "-r", "-z", rev)
    result = {}
    for item in raw.split(b"\0"):
        if not item:
            continue
        metadata, path = item.split(b"\t", 1)
        mode, kind, identity = metadata.decode().split()
        result[path.decode()] = {"mode": mode, "kind": kind, "oid": identity}
    save(f"inventory-{rev[:8]}.json", result)
    return result


check("exact final clean source", git("rev-parse", "HEAD").decode().strip() == HEAD
      and git("rev-parse", "HEAD^{tree}").decode().strip() == TREE
      and not git("status", "--porcelain=v1").strip())
before = inventory(BASE)
after = inventory(HEAD)
changed = {path for path in before.keys() | after.keys() if before.get(path) != after.get(path)}
check("complete exact seven-path union", changed == ALLOWED)
unchanged = {path for path in before.keys() & after.keys() if before[path] == after[path]}
check("all other entries preserved including modes", len(unchanged) == len(before) - 4 and not before.keys() - after.keys())
check("no runtime or application dependency declaration changes", not any(path.startswith("src/") for path in changed)
      and before["pyproject.toml"] == after["pyproject.toml"])
check("exact four retained commits", git("rev-list", "--reverse", f"{BASE}..{HEAD}").decode().split() == [x[0] for x in STAGES])
history = []
previous = BASE
for (commit, tree), expected_paths in zip(STAGES, STAGE_PATHS, strict=True):
    raw = git("cat-file", "commit", commit)
    headers, message = raw.split(b"\n\n", 1)
    fields = headers.decode().splitlines()
    parents = [line[7:] for line in fields if line.startswith("parent ")]
    actual_tree = next(line[5:] for line in fields if line.startswith("tree "))
    subject, _, body = message.decode().partition("\n")
    paths = set(git("diff", "--name-only", previous, commit).decode().splitlines())
    check("stage identity and ordered parent " + commit[:8], parents == [previous] and actual_tree == tree)
    check("spec/test/implementation/quote stage scope " + commit[:8], paths == expected_paths)
    check("both opt-outs in subject and body " + commit[:8], all(token in subject and token in body for token in ("[no release]", "[no deploy]")))
    check("exact raw Git commit identity " + commit[:8], hashlib.sha1(b"commit " + str(len(raw)).encode() + b"\0" + raw).hexdigest() == commit)
    (OUT / ("commit-" + commit[:8] + ".txt")).write_bytes(raw)
    history.append({"commit": commit, "tree": tree, "parents": parents, "subject": subject, "body": body, "paths": sorted(paths)})
    previous = commit

old = blob(BASE, WORKFLOW).decode()
new = blob(HEAD, WORKFLOW).decode()
old_command = "python -m pip install --only-binary :all: pytest hypothesis"
new_command = "python -m pip install --require-hashes --only-binary=:all: -r tools/calibration/pilot/requirements-ci.lock"
check("sole workflow text change is first installer", old.count(old_command) == new.count(new_command) == 1 and new.replace(new_command, old_command) == old)
initial = blob(STAGES[2][0], WORKFLOW).decode()
check("corrective child changes only enclosing YAML quotes", initial.count("- run: " + new_command) == 1
      and initial.replace("- run: " + new_command, "- run: '" + new_command + "'") == new)
check("installer-qualified lock unchanged through quote correction", blob(STAGES[2][0], LOCK) == blob(HEAD, LOCK))
check("new assertions remain exact original test-stage bytes", blob(STAGES[1][0], NEW_TEST) == blob(HEAD, NEW_TEST))
check("parent-red source preserves original workflow", blob(STAGES[1][0], WORKFLOW) == blob(BASE, WORKFLOW))
check("parent-red source truly has no lock", LOCK not in inventory(STAGES[1][0]))

sys.path[:0] = [str(REPO / "src"), str(REPO / "tests"), str(REPO)]
import yaml
from tools import ci_pip_install_audit as audit

check("actual audit module binding", Path(audit.__file__).resolve() == REPO / "tools/ci_pip_install_audit.py")
check("entire parser unchanged", blob(BASE, "tools/ci_pip_install_audit.py") == blob(HEAD, "tools/ci_pip_install_audit.py"))
parsed_old = yaml.safe_load(old)
parsed_new = yaml.safe_load(new)
restored = copy.deepcopy(parsed_new)
restored["jobs"]["evaluate"]["steps"][2]["run"] = old_command
check("entire decoded workflow identical except first scalar", restored == parsed_old)
runs = list(audit.run_scalars(new))
installs = audit.pip_installs(new)
check("five run scalars and only two installers", len(runs) == 5 and len(installs) == 2)
check("first installer has exact enabled-resolver hash arguments", installs[0].arguments == ("--require-hashes", "--only-binary=:all:", "-r", LOCK) and installs[0].has_boundary)
check("separate editable install remains unprotected", runs[1] == "python -m pip install -e ." and installs[1].arguments == ("-e", ".") and not installs[1].has_boundary)
check("manual/read-only/advisory scope retained", parsed_new.get("on", parsed_new.get(True)) == {"workflow_dispatch": None}
      and parsed_new["permissions"] == {"contents": "read"}
      and parsed_new["jobs"]["evaluate"]["runs-on"] == "ubuntu-latest"
      and parsed_new["jobs"]["evaluate"]["timeout-minutes"] == 30)
try:
    audit.pip_installs(initial)
except audit.WorkflowAuditError as exc:
    initial_error = {"class": type(exc).__name__, "message": str(exc)}
else:
    initial_error = None
check("initial retained YAML defect is a hard parser failure", initial_error == {"class": "WorkflowAuditError", "message": "invalid workflow YAML"})

def stripped_census(text):
    tree = ast.parse(text)
    tree.body = [node for node in tree.body if not isinstance(node, ast.FunctionDef)
                 or node.name != "test_actual_workflow_scan_matches_reviewed_source_census"]
    return ast.dump(tree, include_attributes=False)

check("only preexisting changed test function is positive census", stripped_census(blob(BASE, CENSUS_TEST)) == stripped_census(blob(HEAD, CENSUS_TEST)))
strict_gates = []
for path, name in [(CENSUS_TEST, "test_all_explicit_workflow_pip_installs_are_protected"),
                   ("tests/test_codex_pkg_workflows.py", "test_pip_downloads_require_hashes")]:
    old_ast = ast.parse(blob(BASE, path))
    new_ast = ast.parse(blob(HEAD, path))
    old_fn = next(n for n in old_ast.body if isinstance(n, ast.FunctionDef) and n.name == name)
    new_fn = next(n for n in new_ast.body if isinstance(n, ast.FunctionDef) and n.name == name)
    check("strict gate entire AST unchanged " + name, ast.dump(old_fn, include_attributes=False) == ast.dump(new_fn, include_attributes=False))
    marks = [node for node in new_fn.decorator_list if isinstance(node, ast.Call)
             and isinstance(node.func, ast.Attribute) and node.func.attr == "xfail"]
    check("strict expected failure retained " + name, len(marks) == 1 and any(k.arg == "strict" and isinstance(k.value, ast.Constant) and k.value.value is True for k in marks[0].keywords))
    if path == CENSUS_TEST:
        check("typed missing-boundary exception remains the sole xfail type", any(k.arg == "raises" and isinstance(k.value, ast.Name) and k.value.id == "UnprotectedPipInstalls" for k in marks[0].keywords))
    strict_gates.append({"path": path, "name": name, "decorators": [ast.unparse(n) for n in new_fn.decorator_list], "ast_sha256": sha(ast.dump(new_fn, include_attributes=False).encode())})


def census(rev, inv):
    workflow_paths = sorted(path for path in inv if path.startswith(".github/workflows/") and path.endswith((".yml", ".yaml")))
    result = {"workflows": len(workflow_paths), "run_scalars": 0, "installing_jobs": 0, "commands": 0, "protected": 0, "unprotected": 0}
    rows = []
    for path in workflow_paths:
        source = blob(rev, path).decode()
        parsed = yaml.safe_load(source)
        commands = audit.pip_installs(source)
        count = len(list(audit.run_scalars(source)))
        result["run_scalars"] += count
        result["commands"] += len(commands)
        result["protected"] += sum(item.has_boundary for item in commands)
        result["unprotected"] += sum(not item.has_boundary for item in commands)
        for job_name, job in parsed["jobs"].items():
            if audit.pip_installs(yaml.safe_dump({"jobs": {job_name: job}})):
                result["installing_jobs"] += 1
        rows.append({"path": path, "runs": count, "commands": [{**asdict(item), "protected": item.has_boundary} for item in commands]})
    return {"source": rev, "counts": result, "rows": rows}


before_census = census(BASE, before)
after_census = census(HEAD, after)
check("exact historical source96 census", before_census["counts"] == {"workflows": 21, "run_scalars": 203, "installing_jobs": 38, "commands": 42, "protected": 1, "unprotected": 41})
check("exact final actual-workflow census", after_census["counts"] == {"workflows": 21, "run_scalars": 203, "installing_jobs": 38, "commands": 42, "protected": 2, "unprotected": 40})
check("all other workflow census rows unchanged", [r for r in before_census["rows"] if r["path"] != WORKFLOW] == [r for r in after_census["rows"] if r["path"] != WORKFLOW])
save("actual-workflow-census.json", {"before": before_census, "after": after_census})


def xml_summary(path):
    cases = list(ET.parse(path).iter("testcase"))
    counts = {"cases": len(cases), "passed": 0, "failed": 0, "errors": 0, "skipped": 0, "xfailed": 0}
    exceptional = []
    for case in cases:
        if case.find("failure") is not None:
            state, detail = "failed", case.find("failure")
        elif case.find("error") is not None:
            state, detail = "errors", case.find("error")
        elif (detail := case.find("skipped")) is not None:
            state = "xfailed" if detail.get("type") == "pytest.xfail" else "skipped"
        else:
            state, detail = "passed", None
        counts[state] += 1
        if state != "passed":
            exceptional.append({"id": case.get("classname", "") + "::" + case.get("name", ""), "state": state,
                                "message": detail.get("message", ""), "text": detail.text or ""})
    return {"path": str(path), "sha256": sha(path.read_bytes()), "counts": counts, "exceptional": exceptional}


receipts = {
    "parent_red": xml_summary(AUTHOR / "parent-red/result.xml"),
    "initial_pilot": xml_summary(AUTHOR / "source-qualification/pilot-workflow-tests.xml"),
    "initial_affected": xml_summary(AUTHOR / "source-qualification/affected-source-and-property.xml"),
    "final_pilot": xml_summary(AUTHOR / "corrected-source-qualification/pilot-workflow-tests.xml"),
    "final_affected": xml_summary(AUTHOR / "corrected-source-qualification/affected-source-and-property.xml"),
}
expected_counts = {
    "parent_red": (4, 1, 3, 0, 0, 0), "initial_pilot": (19, 19, 0, 0, 0, 0),
    "initial_affected": (238, 233, 4, 0, 0, 1), "final_pilot": (19, 19, 0, 0, 0, 0),
    "final_affected": (238, 236, 0, 0, 0, 2),
}
for name, expected in expected_counts.items():
    check("retained exact XML counts " + name, tuple(receipts[name]["counts"].values()) == expected)
parent_failures = receipts["parent_red"]["exceptional"]
check("parent-red consists of intended collected assertions", len(parent_failures) == 3 and all("AssertionError" in row["text"] for row in parent_failures)
      and sum("Reviewed tooling lock is missing" in row["text"] for row in parent_failures) == 2
      and any("--require-hashes" in row["text"] for row in parent_failures))
initial_failures = [row for row in receipts["initial_affected"]["exceptional"] if row["state"] == "failed"]
check("initial four failures all preserve actual YAML error", len(initial_failures) == 4 and all("WorkflowAuditError" in row["text"] and "invalid workflow YAML" in row["text"] for row in initial_failures))
check("initial typed broad gate remains hard failure", any(row["id"].endswith("::test_all_explicit_workflow_pip_installs_are_protected") for row in initial_failures))
final_xfails = [row["id"] for row in receipts["final_affected"]["exceptional"]]
check("final author expected failures are exactly broad C5", set(final_xfails) == {
    "tests.test_codex5_command_audit_20261121::test_all_explicit_workflow_pip_installs_are_protected",
    "tests.test_codex_pkg_workflows::test_pip_downloads_require_hashes",
})
save("retained-source-test-history.json", receipts)
author_qual = json.loads((AUTHOR / "source-qualification.json").read_text())
check("final author qualification identity exact", author_qual["source"] == HEAD and author_qual["tree"] == TREE and author_qual["source_clean_before_and_after"])
check("author actual Ruff and pip receipts pass", all(c["exit_code"] == 0 for c in author_qual["commands"] if c["label"] in {"whole-ruff", "pip-check"})
      and "All checks passed" in (AUTHOR / "corrected-source-qualification/whole-ruff.stdout.log").read_text()
      and "No broken requirements found" in (AUTHOR / "corrected-source-qualification/pip-check.stdout.log").read_text())

preflight = json.loads((ROOT / "evidence/c5-pilot-independent-preflight/preflight-proof.json").read_text())
artifacts = json.loads((OUT / "artifact-proof.json").read_text())
check("seven final versions equal prior independently reviewed actual main3a baseline", artifacts["versions"] == preflight["accepted_version_baseline"]["versions"]
      and preflight["accepted_version_baseline"]["source"] == "3a16290c0fcc4e0c21712fe10474a3ff33fad336"
      and preflight["accepted_version_baseline"]["run"] == 44906524287 and preflight["accepted_version_baseline"]["job"] == 136853186420)
check("new lock-only contract is registered exactly once", blob(HEAD, "docs/specs/REGISTRY.md").decode().count("`docs/specs/pilot-evaluation-tooling-hashes.md`") == 1)
check("historical CI audit contract and records untouched", all(before[path] == after[path] for path in before
      if path in {"docs/specs/ci-pip-command-audit.md", "docs/audits/codex-workflows-1.md", "docs/qa.md", "tasks/todo.md"}
      or "findings" in path and path.endswith(".json")))
bundle = AUTHOR / "pilot-tooling-source.bundle"
header = bundle.read_bytes().split(b"\n\n", 1)[0].decode()
prerequisites = [line[1:].split()[0] for line in header.splitlines() if line.startswith("-")]
check("source bundle exact base prerequisite", prerequisites == [BASE])
bundle_run = subprocess.run(["git", "-C", str(REPO), "bundle", "verify", str(bundle)], text=True, capture_output=True)
(OUT / "bundle-verify.stdout.txt").write_text(bundle_run.stdout)
(OUT / "bundle-verify.stderr.txt").write_text(bundle_run.stderr)
check("portable source bundle verifies against retained base", bundle_run.returncode == 0)
check("all source worktree files remain frozen and clean", git("rev-parse", "HEAD").decode().strip() == HEAD
      and git("rev-parse", "HEAD^{tree}").decode().strip() == TREE and not git("status", "--porcelain=v1").strip())
proof = {
    "source": HEAD, "tree": TREE, "base": BASE, "observed_at": datetime.now(UTC).isoformat(),
    "checks": len(checks), "all_passed": True, "changed_paths": sorted(changed),
    "unchanged_tracked_entries": len(unchanged), "before_entries": len(before), "after_entries": len(after),
    "history": history, "strict_gates": strict_gates, "initial_yaml_error": initial_error,
    "before_census": before_census["counts"], "after_census": after_census["counts"],
    "source_bundle": {"sha256": sha(bundle.read_bytes()), "header": header, "verified": True},
    "accepted_version_baseline": preflight["accepted_version_baseline"],
    "prior_preflight_review_sha256": sha((ROOT / "evidence/c5-pilot-independent-preflight/review.json").read_bytes()),
    "new_downloads": False, "source_or_ref_mutations": False,
}
save("source-proof.json", proof)
print(json.dumps({"checks": len(checks), "unchanged_entries": len(unchanged), "paths": len(changed), "all_passed": True}))
