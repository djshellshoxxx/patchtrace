"""Independently inspect retained bytes before any isolated package install."""
from pathlib import Path
from email.parser import BytesParser
import hashlib,json,re,shutil,subprocess,sys,zipfile
from packaging.markers import default_environment
from packaging.requirements import Requirement
from packaging.specifiers import SpecifierSet
from packaging.tags import sys_tags,parse_tag
from packaging.utils import canonicalize_name,parse_wheel_filename
from packaging.version import Version
O=Path(__file__).resolve().parent;R=O.parents[1];A=R/'evidence/pilot-tooling-hash-closure-repair';P=R/'repair-pilot-tooling-hash-closure'
H='f08632ab81e6ab24fcc34fc994dd2dda2556d267';T='cb959c1bc0189697241ec2a89c9ec22efabceded'
checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def check(n,c):
 checks.append({'check':n,'passed':bool(c)});(O/'wheel-checks.json').write_text(json.dumps(checks,indent=2)+'\n');assert c,n
def git(*a):return subprocess.check_output(['git','-C',str(P),*a])
check('frozen exact clean source',git('rev-parse','HEAD').decode().strip()==H and git('rev-parse','HEAD^{tree}').decode().strip()==T and not git('status','--porcelain=v1').strip())
archive=A/'pilot-tooling-hash-closure-repair.zip'
check('exact author archive',archive.stat().st_size==4554783 and sha(archive.read_bytes())=='a3ec5c23c4139ee8ba809c5fc070d48b8caa8beac44e7db545f794212ae64cd3')
with zipfile.ZipFile(archive) as z:
 raw=z.read('manifest.json');manifest=json.loads(raw)
 check('author archive members manifest CRC',len(z.namelist())==len(set(z.namelist()))==161 and z.testzip() is None and sha(raw)=='c53b308c6525d936cc6a1b74d278322d366102136abf6dbddebb38af06bf3cf4' and set(z.namelist())=={x['path'] for x in manifest['files']}|{'manifest.json'})
 for row in manifest['files']:
  b=z.read(row['path']);check('author sealed member '+row['path'],len(b)==row['bytes'] and sha(b)==row['sha256'] and b==(A/row['path']).read_bytes())
selected=json.loads((R/'evidence/c5-pilot-version-closure-assessment/candidate-artifacts.json').read_text())
versions={x['name']:x['version'] for x in selected};author=json.loads((A/'wheel-verification.json').read_text())
lock=P/'tools/calibration/pilot/requirements-ci.lock';raw_lock=lock.read_bytes()
check('lock exactly frozen Git bytes',raw_lock==git('show',H+':tools/calibration/pilot/requirements-ci.lock'))
pattern=re.compile(r'([a-z][a-z0-9-]*)==([0-9.]+) --hash=sha256:([0-9a-f]{64})')
entries={}
for line in raw_lock.decode().splitlines():
 if not line.strip() or line.startswith('#'):continue
 m=pattern.fullmatch(line);check('exact lock grammar '+line.split()[0],m is not None)
 name,version,digest=m.groups();check('unique lock entry '+name,name not in entries);entries[name]=(version,digest)
check('exact accepted7 versions',len(entries)==7 and {k:v[0] for k,v in entries.items()}==versions and versions['hypothesis']=='6.170.17')
check('review CPython3.12 Linuxx86_64',sys.version_info[:2]==(3,12) and sys.platform=='linux' and default_environment()['platform_machine']=='x86_64')
env=default_environment();env['extra']='';tags=set(sys_tags());verified=[];active=[];inactive=[]
wh=O/'verified-wheelhouse';wh.mkdir(exist_ok=True)
for accepted in selected:
 name=accepted['name'];filename=accepted['filename'];data=(A/'wheelhouse'/filename).read_bytes()
 metadata_bytes=(A/'metadata'/f"{name}-{accepted['version']}.json").read_bytes();registry=json.loads(metadata_bytes)
 url=next(x for x in registry['urls'] if x['filename']==filename)
 check('actual wheel accepted identity/hash/length '+name,len(data)==accepted['size']==url['size'] and sha(data)==accepted['sha256']==url['digests']['sha256']==entries[name][1] and url['url']==accepted['url'] and url['packagetype']=='bdist_wheel' and not url['yanked'])
 with zipfile.ZipFile(A/'wheelhouse'/filename) as z:
  meta_names=[x for x in z.namelist() if x.endswith('.dist-info/METADATA')];info_names=[x for x in z.namelist() if x.endswith('.dist-info/WHEEL')]
  check('wheel CRC and unique embedded metadata '+name,z.testzip() is None and len(meta_names)==len(info_names)==1)
  meta_bytes=z.read(meta_names[0]);info_bytes=z.read(info_names[0]);meta=BytesParser().parsebytes(meta_bytes);info=BytesParser().parsebytes(info_bytes)
 wheel_name,wheel_version,build,wheel_tags=parse_wheel_filename(filename)
 check('embedded distribution identity '+name,canonicalize_name(meta['Name'])==canonicalize_name(registry['info']['name'])==wheel_name==name and meta['Version']==registry['info']['version']==accepted['version']==str(wheel_version))
 embedded_tags={tag for s in info.get_all('Tag',[]) for tag in parse_tag(s)}
 check('compatible exact wheel tags '+name,embedded_tags==wheel_tags and bool(tags&wheel_tags))
 py=meta.get('Requires-Python') or ''
 check('embedded Python constraint '+name,SpecifierSet(py)==SpecifierSet(registry['info'].get('requires_python') or '') and Version(env['python_full_version']) in SpecifierSet(py))
 reqs=meta.get_all('Requires-Dist',[])
 norm=lambda rows:sorted(str(Requirement(x)) for x in rows)
 check('all embedded dependency declarations agree '+name,norm(reqs)==norm(registry['info'].get('requires_dist') or [])==norm(accepted.get('requires_dist') or []))
 for text in reqs:
  req=Requirement(text)
  if req.marker is not None and not req.marker.evaluate(env):inactive.append({'from':name,'requirement':text});continue
  dep=canonicalize_name(req.name)
  check('active complete dependency '+name+' -> '+text,dep in versions and not req.extras and req.url is None and Version(versions[dep]) in req.specifier)
  active.append({'from':name,'to':dep,'requirement':text,'version':versions[dep]})
 ar=next(x for x in author['artifacts'] if x['name']==name)
 check('author artifact receipt independently reproduced '+name,ar['sha256']==sha(data) and ar['metadata_sha256']==sha(meta_bytes) and ar['wheel_info_sha256']==sha(info_bytes) and ar['pypi_json_sha256']==sha(metadata_bytes))
 (wh/filename).write_bytes(data)
 verified.append({'name':name,'version':accepted['version'],'filename':filename,'bytes':len(data),'sha256':sha(data),'metadata_sha256':sha(meta_bytes),'registry_sha256':sha(metadata_bytes),'source_url':url['url'],'requires_python':py,'requires_dist':reqs,'tags':sorted(map(str,wheel_tags))})
check('exact five active edges',len(active)==5 and {(x['from'],x['to']) for x in active}=={('pytest','iniconfig'),('pytest','packaging'),('pytest','pluggy'),('pytest','pygments'),('hypothesis','sortedcontainers')})
check('actual complete copied wheelset',len(list(wh.glob('*.whl')))==7)
check('unchanged source after artifact verification',not git('status','--porcelain=v1').strip())
result={'source':H,'tree':T,'checks':len(checks),'all_passed':True,'versions':versions,'artifacts':verified,'active_edges':active,'inactive_requirements':inactive,'target_environment':env,'lock_sha256':sha(raw_lock),'actual_wheel_bytes_verified':True,'new_downloads':False,'packages_executed_by_artifact_verification':False}
(O/'artifact-proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'checks':len(checks),'artifacts':len(verified),'active_edges':len(active),'all_passed':True}))
