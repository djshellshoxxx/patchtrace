"""Seal completed read-only review; exclude disposable environments and caches."""
from __future__ import annotations

from datetime import UTC, datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
REPO = ROOT / "repair-pilot-tooling-hash-closure"
HEAD = "f08632ab81e6ab24fcc34fc994dd2dda2556d267"
TREE = "cb959c1bc0189697241ec2a89c9ec22efabceded"
ARCHIVE = "pilot-tooling-hash-closure-independent.zip"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def load(name):
    return json.loads((OUT / name).read_text())


def save(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")


def git(*args):
    return subprocess.check_output(["git", "-C", str(REPO), *args]).decode().strip()


assert git("rev-parse", "HEAD") == HEAD and git("rev-parse", "HEAD^{tree}") == TREE
assert not git("status", "--porcelain=v1")
source = load("source-proof.json")
artifacts = load("artifact-proof.json")
installs = load("install-proof.json")
tests = load("source-tests.json")
report = load("unchanged-report-writer.json")
assert source["all_passed"] and artifacts["all_passed"] and not installs["errors"]
assert source["checks"] == 61 and artifacts["checks"] == 237
assert tests["exit_code"] == 0 and tests["distinct_ids"] == 261
assert installs["successful_installs"] == 1 and installs["expected_refusals"] == 4
assert report["report"]["gate"]["status"] == "not-evaluated"

inputs = OUT / "inputs"
inputs.mkdir(exist_ok=True)
retained = []
for original, destination, expected in [
    (ROOT / "evidence/pilot-tooling-hash-closure-repair/pilot-tooling-hash-closure-repair.zip",
     "author-pilot-tooling-hash-closure-repair.zip", "a3ec5c23c4139ee8ba809c5fc070d48b8caa8beac44e7db545f794212ae64cd3"),
    (ROOT / "evidence/c5-pilot-independent-preflight/c5-pilot-independent-preflight.zip",
     "c5-pilot-independent-preflight.zip", "82252252c0101277252acee3248dd892e7c5dde943fadddc3e5426bfe29de8c5"),
]:
    content = original.read_bytes()
    assert sha(content) == expected
    target = inputs / destination
    shutil.copyfile(original, target)
    assert target.read_bytes() == content
    retained.append({"path": "inputs/" + destination, "original": str(original), "bytes": len(content), "sha256": expected})

review = {
    "schema": "patchtrace/pilot-tooling-hash-closure-independent/1",
    "reviewer": "/root/codex1_independent_review",
    "observed_at": datetime.now(UTC).isoformat(),
    "verdict": "CLEAR for the bounded first pilot-tooling installer and reviewed source integration",
    "blockers": [],
    "source": HEAD,
    "tree": TREE,
    "base": source["base"],
    "worktree": str(REPO),
    "clean_before_and_after": True,
    "scope": "First Linux CPython 3.12 pilot tooling install only; no application/runtime/evaluation change",
    "source_history": source["history"],
    "changed_paths": source["changed_paths"],
    "unchanged_tracked_entries": source["unchanged_tracked_entries"],
    "mechanical_checks": {"archive_wheel_metadata": 237, "source_history_census": 61, "total": 298, "all_passed": True},
    "accepted_version_baseline": source["accepted_version_baseline"],
    "actual_wheels": artifacts["artifacts"],
    "active_dependency_edges": artifacts["active_edges"],
    "wheel_target": "Linux x86_64 CPython 3.12, no extras",
    "fresh_resolver_checks": {
        "environments": 5, "started_with_no_distributions": True,
        "positive_installs": 1, "exact_installed_versions": artifacts["versions"],
        "positive_pip_check_passed": True,
        "expected_refusals": ["present sortedcontainers==2.4.0 entry with its hash removed",
                              "omitted sortedcontainers entry with the actual wheel still available",
                              "wrong sortedcontainers hash", "wrong Hypothesis hash"],
        "negative_environments_remained_empty": True,
        "all_seven_verified_wheels_available_in_every_case": True,
        "normal_resolver_enabled": True, "require_hashes_enabled": True,
        "dependency_or_hash_bypass_used": False,
        "PIP_environment_cleared_and_config_disabled": True,
        "local_wheelhouse_no_index": True,
        "new_downloads": False,
        "bootstrap_pip_version": "25.0.1", "interpreter": "CPython 3.12.14",
        "bootstrap_and_runner_are_not_artifact_locked": True,
    },
    "independent_source_tests": {
        "counts": tests["counts"], "distinct_cases": tests["distinct_ids"], "seconds": tests["seconds"],
        "seven_tooling_distributions_and_imports_bound_to_fresh_environment": True,
        "application_dependencies": "Existing trusted application packages appended to sys.path only; no editable install or .pth rebind performed",
        "unchanged_report_writer": "not-evaluated; exact preregistration hash, empty arms and placeholder corpus/tool identities preserved",
        "ordinary_warnings_in_output": 0,
    },
    "prior_author_test_history_retained_separately": {
        "1177902b_parent_test_stage": {"passed": 1, "failed": 3, "errors": 0, "skips": 0, "collected": 4},
        "1dcb9729_initial_affected": {"passed": 233, "failed": 4, "xfailed": 1, "errors": 0, "cases": 238},
        "1dcb9729_pilot_selection": {"passed": 19},
        "f08632ab_final_affected": {"passed": 236, "xfailed": 2, "errors": 0, "failed": 0, "cases": 238},
        "f08632ab_pilot_selection": {"passed": 19},
        "typed_gate_treated_initial_parser_defect_as_hard_failure": True,
        "initial_failures_not_transferred_or_aggregated_into_final_success": True,
        "new_test_bytes_identical_to_original_test_stage": True,
        "author_final_whole_tree_ruff_and_pip_receipts_verified": True,
    },
    "census": {"before_96": source["before_census"], "after_f086": source["after_census"]},
    "strict_C5_gate_asts_unchanged": source["strict_gates"],
    "historical_scope": {
        "available_actions_history_at_preflight": "36 manual runs, including 24 successes; zero available pilot-evaluation runs. No claim about deleted/inaccessible history.",
        "new_explicit_baseline_not_a_historical_pilot_success": True,
        "older_ae69_200_run_census_untouched": True,
        "historical_181_unmatched_and_16_patch_equivalent_census_unchanged": True,
    },
    "remaining_gates": [
        "Separate editable application installation and its build/runtime dependency closure",
        "40 still-unprotected explicit workflow installers and both broad strict CODEX-5 gates",
        "Full final integrated-source hosted Linux/Windows qualification and applicable native/package/platform acceptance",
        "Actual locked-data pilot evaluation; report writer remains not-evaluated",
        "Interpreter, pip bootstrap, runner reproducibility and hosted index availability",
        "Release readiness and root-controlled publication/merge decisions",
    ],
    "mutations": {"candidate_source": False, "existing_environments": False, "root_network_worktree": False,
                  "PR357": False, "refs_PRs_CI": False, "new_review_environments_only": True},
    "reviewer_unexpected_errors_or_failures": [],
    "portable_retention": retained,
    "portable_archive": ARCHIVE,
    "archive_exclusions": {
        "_environments": "Disposable five environments; exact command, configuration and installation-state receipts included",
        "tmp": "Disposable pytest/Hypothesis cache and fixture directories; raw outputs/XML and source bindings included",
        "verified-wheelhouse": "Exact same seven wheels are retained once in inputs/author-pilot-tooling-hash-closure-repair.zip under wheelhouse/",
        "outer_archive_and_receipt": "Avoid circular self-hashing; manifest covers every payload, receipt identifies final ZIP",
    },
}
save("review.json", review)

readme = f"""# Independent review: first pilot tooling hash closure

## Verdict and exact source

**CLEAR for this bounded first installer and reviewed source integration. No blocker was found.**

The reviewed clean head is `{HEAD}`, complete tree `{TREE}`, based on `96baaee20f390a3f2a5629de3764d32323bb80e5`. The review author changed only this scratch evidence directory and five new review environments. Source, existing environments, root's integration checkout, PR357, refs, PR metadata and CI were not changed.

The actual Git objects preserve the four ordered commits: specification `cd11919b`, tests `1177902b`, implementation `1dcb9729`, and quote correction `f08632ab`. All subjects and bodies retain both opt-outs. The source bundle verifies against its exact 96 prerequisite. Exactly seven paths change; **4,826 other tracked entries preserve their modes and blob identities**. No application runtime, dependencies, preregistration, pilot metric/gate implementation, report implementation, other workflow, QA/TODO or historical ledger bytes change.

## Actual seven-wheel closure

The accepted new baseline is successful main3a Linux QA run 44906524287 / job 136853186420, with pytest 9.2.0, Hypothesis 6.170.17, iniconfig 2.3.1, packaging 26.3, pluggy 1.7.0, Pygments 2.21.0 and sortedcontainers 2.4.0. The prior independently reviewed baseline and available-history observation are retained in the preflight ZIP. This is a new pilot tooling baseline. It does not assert a successful historical pilot run.

The reviewer verified all seven retained wheel byte lengths and SHA-256 digests against the accepted artifact metadata, fresh version-specific registry JSON, embedded wheel Name/Version/Requires-Python/Requires-Dist, compatible filename and WHEEL tags, and the exact final lock. All ZIP CRCs and unique embedded metadata were checked. The five active dependency edges close over the seven selected versions on Linux x86_64 / CPython 3.12 without extras. The five shared pytest packages match the existing reviewed Pages lock.

There are **298 independent mechanical checks**: 237 archive/wheel/metadata checks and 61 source/history/census checks. These are inspection checks, separate from pytest and installer probes.

## Fresh normal-resolver checks

Five newly created `--without-pip` environments started with no installed distributions. Existing pip 25.0.1 drove each target using `--python`; CPython 3.12.14 and the pip bootstrap are disclosed, not artifact-locked. Inherited PIP variables were removed and `PIP_CONFIG_FILE=/dev/null` disabled configuration. The exact independently verified local wheelhouse supplied all seven wheels with `--require-hashes --only-binary=:all:` and normal dependency resolution. `--no-index` limited the replay to retained bytes; it did not disable dependency resolution. There was no `--no-deps`, hash bypass, new download or existing-environment installation.

| Fresh case | Observed result |
|---|---|
| Exact final lock | Exit 0; all seven exact versions installed in the new environment; every pip-report digest matches; pip check passed |
| Present exact sortedcontainers pin, missing hash | Refused for the missing required hash; actual accepted wheel available |
| Omitted sortedcontainers entry | Normal resolver discovered the transitive requirement and refused the absent exact pin in hash mode |
| Wrong sortedcontainers hash | Refused with the intended expected/actual digest mismatch |
| Wrong Hypothesis hash | Refused with the intended expected/actual digest mismatch |

All four negative environments remained empty. They are expected refusal controls, not product-test failures. Full commands, effective pip configuration, raw outputs, mutated lock copies and before/after distribution states are retained.

## Exact source tests and retained failures

The focused independent replay ran from the fresh seven-package environment using `-I -B` and explicit final-source paths. All seven tooling metadata locations and actual import origins were checked before/after. Trusted application dependencies were appended after the fresh tool site-packages in `sys.path`; the existing dependency environment was not modified or rebound, and its Hypothesis version could not satisfy the selected-tooling check.

**259 tests passed and two existing strict CODEX-5 cases xfailed, across 261 distinct cases**, with zero failed cases, errors, ordinary skips or output warnings. This includes the unchanged 19 pilot metrics/gate cases, four original workflow tests, the new lock contract, scanner/typed failure controls, registry and one unchanged Hypothesis property. The unchanged report writer emitted its exact preregistration identity, empty arms and `not-evaluated` status. This is unit/report evidence, not a locked-data pilot evaluation.

The author history is preserved without aggregation: test stage 1177902b collected four cases and failed three real assertions with one pass against the unchanged parent workflow and absent lock. Initial 1dcb retained 233 passes/four YAML failures/one xfail in the affected selection, plus a separate 19-case pilot pass. In that initial source, the typed broad C5 gate correctly failed for malformed YAML. Final f086 adds enclosing YAML quotes only; it changes neither installer arguments, lock bytes nor the original new assertions. Final author affected results were 236 passes/two strict xfails, plus the separate 19 pilot passes. Actual final Ruff and pip receipts were verified; these were not rerun or combined into the independent test total.

## Workflow and remaining limits

Only the first run scalar changes. Entire workflow text and parsed mappings become exactly the parent after reversing that scalar. Manual-only/advisory/read-only scope, Ubuntu/Python 3.12, 30-minute budget, Action pins, ordering, preregistration hash, evaluation selectors, report command and aggregate artifact upload are preserved. The second `python -m pip install -e .` remains unchanged and unprotected.

Actual source scanning preserves 21 workflows, 203 run scalars, 38 installing jobs and 42 explicit install commands. Source 96 remains historically **1 protected/41 unprotected**; final f086 is **2 protected/40 unprotected**, with only pilot's first command added. Both broad strict-xfail function ASTs are unchanged, including the typed missing-boundary exception. Parser/discovery errors remain hard failures. The older ae69 census and 181/16 historical branch snapshot remain unchanged.

The separate editable application/build closure, other 40 installers, broader C5 gates, full final integrated-source hosted qualification, applicable Windows/native/package acceptance, hosted index access, actual pilot evaluation and release readiness remain open. Root retains publication and integration authority. No hosted run, native engine or external target was executed for this review.

## Portable evidence

`review.json` gives the machine-readable verdict. `artifact-proof.json`, `source-proof.json`, both check lists, full Git inventories, `actual-workflow-census.json`, retained-source history and raw source-test XML provide the proof. `install-proof.json` links all five fresh resolver receipts. Both immutable author and prior-preflight ZIPs are included under `inputs/`, preserving original failures, source bundle, accepted baseline and actual seven wheels. Disposable environments/caches are excluded. The duplicate review wheelhouse is excluded because those exact bytes remain in the nested author archive. `manifest.json` covers every payload; the outer archive receipt is kept outside the ZIP to avoid circular hashes.
"""
(OUT / "README.md").write_text(readme)
excluded_top = {"_environments", "tmp", "verified-wheelhouse"}
excluded_files = {"manifest.json", "archive-receipt.json", ARCHIVE}
files = [path for path in sorted(OUT.rglob("*")) if path.is_file()
         and path.relative_to(OUT).parts[0] not in excluded_top
         and path.relative_to(OUT).as_posix() not in excluded_files]
manifest = {
    "schema": "patchtrace/independent-review-manifest/1",
    "source": HEAD,
    "tree": TREE,
    "files": [{"path": path.relative_to(OUT).as_posix(), "bytes": path.stat().st_size,
               "sha256": sha(path.read_bytes())} for path in files],
}
save("manifest.json", manifest)
with zipfile.ZipFile(OUT / ARCHIVE, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    for path in [*files, OUT / "manifest.json"]:
        info = zipfile.ZipInfo(path.relative_to(OUT).as_posix(), date_time=(2026, 11, 21, 0, 0, 0))
        info.compress_type = zipfile.ZIP_DEFLATED
        info.external_attr = 0o100644 << 16
        archive.writestr(info, path.read_bytes())
with zipfile.ZipFile(OUT / ARCHIVE) as archive:
    assert archive.testzip() is None
    assert len(archive.namelist()) == len(set(archive.namelist())) == len(files) + 1
    assert set(archive.namelist()) == {row["path"] for row in manifest["files"]} | {"manifest.json"}
    for row in manifest["files"]:
        data = archive.read(row["path"])
        assert len(data) == row["bytes"] and sha(data) == row["sha256"]
assert git("rev-parse", "HEAD") == HEAD and git("rev-parse", "HEAD^{tree}") == TREE
assert not git("status", "--porcelain=v1")
receipt = {
    "source": HEAD, "tree": TREE, "archive": str(OUT / ARCHIVE),
    "bytes": (OUT / ARCHIVE).stat().st_size, "members": len(files) + 1,
    "sha256": sha((OUT / ARCHIVE).read_bytes()),
    "manifest_sha256": sha((OUT / "manifest.json").read_bytes()),
    "review_sha256": sha((OUT / "review.json").read_bytes()),
    "CRC_and_every_member_verified": True, "source_still_clean": True,
}
save("archive-receipt.json", receipt)
print(json.dumps(receipt, indent=2))
