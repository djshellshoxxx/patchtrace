"""Source-bound independent tests with freshly installed accepted tool wheels."""
from __future__ import annotations

import hashlib
import importlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
REPO = ROOT / "repair-pilot-tooling-hash-closure"
SITE = OUT / "_environments/positive/lib/python3.12/site-packages"
APP_DEPS = Path("/workspace/scratch/patchtrace-95fe-c3/venv/lib/python3.12/site-packages")
HEAD = "f08632ab81e6ab24fcc34fc994dd2dda2556d267"
TREE = "cb959c1bc0189697241ec2a89c9ec22efabceded"
VERSIONS = {
    "pytest": "9.2.0", "hypothesis": "6.170.17", "sortedcontainers": "2.4.0",
    "iniconfig": "2.3.1", "packaging": "26.3", "pluggy": "1.7.0", "pygments": "2.21.0",
}


def git(*args):
    return subprocess.check_output(["git", "-C", str(REPO), *args]).decode().strip()


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + "\n")


assert sys.flags.isolated and sys.dont_write_bytecode
assert Path(sys.prefix) == OUT / "_environments/positive"
assert git("rev-parse", "HEAD") == HEAD and git("rev-parse", "HEAD^{tree}") == TREE
assert not git("status", "--porcelain=v1")
sys.path[:0] = [str(REPO / "src"), str(REPO / "tests"), str(REPO)]
# Reuse application dependencies only; do not change or process its .pth files.
sys.path.append(str(APP_DEPS))
os.environ["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
os.environ["HYPOTHESIS_STORAGE_DIRECTORY"] = str(OUT / "tmp/hypothesis")
os.environ["XDG_CACHE_HOME"] = str(OUT / "tmp/cache")
os.environ["PATCHTRACE_LIVE_STATUS_DIR"] = str(OUT / "tmp/live-status")
os.environ["QT_QPA_PLATFORM"] = "offscreen"
bound = {}
for name, version in VERSIONS.items():
    dist = importlib.metadata.distribution(name)
    spec = importlib.util.find_spec(name)
    location = Path(dist.locate_file("")).resolve()
    assert dist.version == version and location == SITE, (name, dist.version, location)
    assert spec is not None and Path(spec.origin).resolve().is_relative_to(SITE)
    bound[name] = {"version": dist.version, "metadata_location": str(location), "origin": spec.origin}

import patchtrace
from patchtrace.pilot import contracts
from tools import ci_pip_install_audit as audit

assert Path(patchtrace.__file__).resolve() == REPO / "src/patchtrace/__init__.py"
assert Path(contracts.__file__).resolve() == REPO / "src/patchtrace/pilot/contracts.py"
assert Path(audit.__file__).resolve() == REPO / "tools/ci_pip_install_audit.py"
write("source-binding.json", {
    "head": HEAD, "tree": TREE, "python": sys.executable, "version": sys.version,
    "isolated": sys.flags.isolated, "bytecode_disabled": sys.dont_write_bytecode,
    "fresh_tooling": bound, "application_dependencies_appended_only": str(APP_DEPS),
    "existing_environment_modified": False, "sys_path": sys.path,
    "source_modules": {
        "patchtrace": patchtrace.__file__, "contracts": contracts.__file__, "audit": audit.__file__,
    },
})
selectors = [
    "tests/test_pilot_eval_metrics.py", "tests/test_pilot_eval_gate.py",
    "tests/test_pilot_eval_workflow.py", "tests/test_pilot_dependency_lock.py",
    "tests/test_codex5_command_audit_20261121.py", "tests/test_codex_pkg_workflows.py",
    "tests/test_site_dependency_lock.py", "tests/test_spec_registry.py",
    "tests/test_pilot_properties.py::test_localization_is_idempotent_and_ignores_the_clock",
]
args = ["-q", *selectors, "-p", "no:cacheprovider", "-p", "_hypothesis_pytestplugin",
        f"--basetemp={OUT / 'tmp/source-tests'}", f"--junitxml={OUT / 'source-tests.xml'}"]
write("source-tests-command.json", {
    "argv": [sys.executable, "-I", "-B", str(Path(__file__).resolve())],
    "pytest_args": args, "cwd": str(REPO), "selectors": selectors,
    "plugin_autoload": False, "explicit_plugin": "_hypothesis_pytestplugin",
})
os.chdir(REPO)
import pytest

start = time.monotonic()
code = pytest.main(args)
elapsed = time.monotonic() - start
cases = list(ET.parse(OUT / "source-tests.xml").iter("testcase"))
counts = {"cases": len(cases), "passed": 0, "failed": 0, "errors": 0, "skipped": 0, "xfailed": 0}
outcomes = []
for case in cases:
    if case.find("failure") is not None:
        status = "failed"
    elif case.find("error") is not None:
        status = "errors"
    elif (skip := case.find("skipped")) is not None:
        status = "xfailed" if skip.get("type") == "pytest.xfail" else "skipped"
    else:
        status = "passed"
    counts[status] += 1
    outcomes.append({"id": case.get("classname", "") + "::" + case.get("name", ""), "status": status})
after = {}
for name, version in VERSIONS.items():
    module = importlib.import_module(name)
    origin = str(Path(module.__file__).resolve())
    assert Path(origin).is_relative_to(SITE), (name, origin)
    assert importlib.metadata.version(name) == version
    after[name] = {"version": version, "origin": origin}
assert after["hypothesis"]["version"] == "6.170.17"
write("source-tests.json", {
    "head": HEAD, "tree": TREE, "exit_code": code, "seconds": elapsed,
    "counts": counts, "outcomes": outcomes, "after_tooling_imports": after,
    "distinct_ids": len({x["id"] for x in outcomes}), "source_clean_after": not git("status", "--porcelain=v1"),
    "full_or_native_or_hosted_run": False,
})
assert code == 0 and counts == {"cases": 261, "passed": 259, "failed": 0, "errors": 0, "skipped": 0, "xfailed": 2}
expected = {
    "tests.test_codex5_command_audit_20261121::test_all_explicit_workflow_pip_installs_are_protected",
    "tests.test_codex_pkg_workflows::test_pip_downloads_require_hashes",
}
assert {x["id"] for x in outcomes if x["status"] == "xfailed"} == expected

workflow = (REPO / ".github/workflows/pilot-eval.yml").read_text()
report_command = list(audit.run_scalars(workflow))[4]
words = shlex.split(report_command)
assert len(words) == 3 and words[:2] == ["python", "-c"]
report_dir = OUT / "report-workdir"
(report_dir / "out").mkdir(parents=True, exist_ok=True)
os.chdir(report_dir)
exec(compile(words[2], "<unchanged workflow report writer>", "exec"), {})
report_bytes = (report_dir / "out/report.json").read_bytes()
report = json.loads(report_bytes)
prereg_sha = hashlib.sha256((REPO / "docs/plans/pilot-preregistration-v1.md").read_bytes()).hexdigest()
write("unchanged-report-writer.json", {
    "head": HEAD, "command": report_command, "decoded_code": words[2],
    "source_file": str(REPO / "tools/calibration/pilot/report.py"),
    "preregistration_sha256": prereg_sha, "report_sha256": hashlib.sha256(report_bytes).hexdigest(),
    "report": report, "evaluated_pilot_data": False,
})
assert report["gate"]["status"] == "not-evaluated" and report["gate"]["conditions"] == {}
assert report["arms"] == {} and report["prereg_sha256"] == prereg_sha
assert git("rev-parse", "HEAD") == HEAD and git("rev-parse", "HEAD^{tree}") == TREE
assert not git("status", "--porcelain=v1")
print(json.dumps({"counts": counts, "report": "not-evaluated", "clean_after": True}))
