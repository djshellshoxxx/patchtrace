"""Final sealed-evidence delta; no network, test, native or source execution."""
import collections, datetime, hashlib, io, json, pathlib, re, stat, zipfile
ROOT=pathlib.Path('/workspace/scratch/837fe19aae3a/evidence/final-d60-qualification')
OUT=pathlib.Path(__file__).parent
HEAD='d60ac40daf767fe6a93ae152feb21235f6e75e0b';TREE='4a07cd88ded407bef30a8aeb81961e4041822dc2';BASE='3a16290c0fcc4e0c21712fe10474a3ff33fad336';MERGE='254d26e58ef03a03e50c78b5f90c6ef7d9bf9e57'
PARENT_SHA='0b70d118ec79e9a88230eb7dd404bc7ebf5080f78c6d2c15614dccdb493a6b08';MANIFEST_SHA='4f165202d278f98be242323bb49cc97e4b7b1816183b7d6ca4cc853259c403bb';QUAL_SHA='a6f59daaa6d1dc3b495705ec26c6f392a2a4a383b846d20f7a4ccc8c397ea5f1'
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=[]
def check(n,c):checks.append({'name':n,'passed':bool(c)})
b=(ROOT/'final-d60-evidence.zip').read_bytes();z=zipfile.ZipFile(io.BytesIO(b))
read=z.read
def obj(n):return json.loads(read(n))
m=obj('evidence-manifest.json');q=obj('final-qualification.json');guard=obj('final-source-and-run-guard.json');receipt=json.loads((ROOT/'archive-receipt.json').read_bytes())
check('Parent ZIP expected bytes and hash',len(b)==3038215 and sha(b)==PARENT_SHA)
check('Manifest and qualification expected hashes',sha(read('evidence-manifest.json'))==MANIFEST_SHA and sha(read('final-qualification.json'))==QUAL_SHA)
check('External manifest and qualification unchanged',read('evidence-manifest.json')==(ROOT/'evidence-manifest.json').read_bytes() and read('final-qualification.json')==(ROOT/'final-qualification.json').read_bytes())
check('Parent ZIP CRC and complete145-member inventory',z.testzip() is None and len(z.namelist())==145 and len(m['files'])==144 and set(z.namelist())=={f['path'] for f in m['files']}|{'evidence-manifest.json'})
for f in m['files']:
 content=read(f['path']);p=pathlib.PurePosixPath(f['path']);safe=not p.is_absolute() and '..' not in p.parts and not stat.S_ISLNK(z.getinfo(f['path']).external_attr>>16)
 check('Parent member '+f['path'],safe and len(content)==f['bytes'] and sha(content)==f['sha256'])
check('External archive receipt agrees',receipt['archive_sha256']==PARENT_SHA and receipt['manifest_sha256']==MANIFEST_SHA and receipt['qualification_sha256']==QUAL_SHA and receipt['archive_bytes']==len(b))
check('Final guard observed15:20:42',guard['observed_at']=='2026-11-21 15:20:42 UTC' and q['observed_at']==guard['observed_at'])
check('Exact final PR/head/base/main',guard['pr']['number']==357 and guard['pr']['head']['sha']==HEAD and guard['pr']['base']['sha']==BASE and guard['main']['object']['sha']==BASE and guard['head']['sha']==HEAD)
check('Exact source complete tree and parents',guard['head']['tree']['sha']==TREE and [p['sha'] for p in guard['head']['parents']]==['4202e5e79e2aea6366c75261d74544ea48368ca5',BASE])
check('Exact synthetic merge/tree/ordered parents',guard['pr']['merge_commit_sha']==MERGE and guard['merge']['sha']==MERGE and guard['merge']['tree']['sha']==TREE and [p['sha'] for p in guard['merge']['parents']]==[BASE,HEAD])
check('Final summary source matches guard',q['source']['head_sha']==HEAD and q['source']['head_tree_sha']==TREE and q['source']['base_sha']==BASE and q['source']['synthetic_merge_sha']==MERGE and q['source']['synthetic_merge_tree_sha']==TREE and q['source']['synthetic_merge_parents']==[BASE,HEAD])
run_ids={44910528283,44910528348};check('Only two actually discovered applicable runs',guard['runs']['total_count']==2 and {r['id'] for r in guard['runs']['workflow_runs']}==run_ids)
for rid in run_ids:
 r=obj(f'final-run-{rid}.json');check(f'{rid}: completed PR success attempt1',r['head_sha']==HEAD and r['event']=='pull_request' and r['status']=='completed' and r['conclusion']=='success' and r['run_attempt']==1)
groups=obj('final-job-records.json')['runs'];jobs={j['id']:j for g in groups for j in g['jobs']}
check('18 actual completed jobs16success2skip',len(jobs)==18 and collections.Counter(j['conclusion'] for j in jobs.values())=={'success':16,'skipped':2} and all(j['status']=='completed' and j['head_sha']==HEAD and j['run_attempt']==1 for j in jobs.values()))
check('Exact PR release skips',{j['id'] for j in jobs.values() if j['conclusion']=='skipped'}=={136865172968,136889308090})
logs={}
for jid,j in jobs.items():
 if j['conclusion']=='skipped':
  check(f'{jid}: no executed runner or steps',not j['steps'] and j['runner_id'] is None);continue
 raw=obj(f'raw-job-{jid}.json');log=read(f'logs/{jid}.log').decode();logs[jid]=log
 check(f'{jid}: exact raw log source/checkout',raw['decoded_log']==log and raw['head_sha']==HEAD and raw['run_id']==j['run_id'] and raw['checkouts']==[MERGE] and raw['expected_checkout']==MERGE and bool(re.search(r'^\S+Z '+MERGE+r'\r?$',log,re.M)))
check('All16 actual checkout logs verified',len(logs)==16)
check('Final summary run/job inventory agrees',{r['id'] for r in q['runs']}==run_ids and {j['id'] for r in q['runs'] for j in r['jobs']}==set(jobs))
check('All11 required QA jobs successful',len(q['qa']['required_job_ids'])==11 and all(jobs[j]['conclusion']=='success' for j in q['qa']['required_job_ids']))
check('Final verdict counts agree',q['verdict']['actual_job_count']==18 and q['verdict']['successful_executed_job_count']==16 and q['verdict']['intentional_skipped_job_count']==2 and q['verdict']['failed_job_count']==0 and q['verdict']['executed_checkout_log_count']==16 and q['verdict']['qualification_status']=='qualified_with_documented_open_gates')

native=obj('independent-reviews/native-audit.json');nb=read('independent-reviews/native-audit.json');qdbytes=read('independent-reviews/qa-delta-review.zip');qz=zipfile.ZipFile(io.BytesIO(qdbytes));qd=json.loads(qz.read('qa-delta-review.json'));qm=json.loads(qz.read('qa-delta-manifest.json'))
check('Original175 native audit exact and passed',sha(nb)=='4c72cac167dd3928501501ee3e3b0dd794df1e602d3f57c043b5de308186d257' and native['check_count']==175 and native['failure_count']==0 and nb==(OUT/'audit.json').read_bytes())
check('Original96 QA audit ZIP exact and passed',sha(qdbytes)=='4012cd0e22af25bf26dc43f36b21470e2bc181adf13a0a467df4a5faeeb63206' and qd['check_count']==96 and qd['failure_count']==0 and qdbytes==(OUT/'qa-delta-review.zip').read_bytes())
check('QA companion CRC/inventory',qz.testzip() is None and set(qz.namelist())=={f['path'] for f in qm['files']}|{'qa-delta-manifest.json'})
for f in qm['files']:check('QA companion member '+f['path'],len(qz.read(f['path']))==f['bytes'] and sha(qz.read(f['path']))==f['sha256'])
for label,audit in [('Native175',native),('QA96',qd)]:
 for path,meta in audit['input_files'].items():check(label+' original input unchanged '+path,path in z.namelist() and len(read(path))==meta['bytes'] and sha(read(path))==meta['sha256'])
check('Native final summary exact previously audited receipt',q['native']==obj('native-summary.json'))
check('Full platform final summaries exact',q['qa']['full_pytest']['Linux']==obj('linux-full-completion.json')['full_pytest'] and q['qa']['full_pytest']['Windows']==obj('windows-producer-completion.json')['full_pytest'])
check('Final Qt/sourceWindows27/producer/consumer/package match audited receipts',q['qa']['qt']==obj('qt-five-completion.json')['jobs'] and q['qa']['windows_powershell_cases']==obj('windows-powershell27-completion.json') and q['qa']['windows_full_build_smoke']==obj('windows-producer-completion.json') and q['qa']['windows_downloaded_artifact_validation']==obj('windows-downloaded-artifact-validation.json') and q['qa']['linux_package']==obj('linux-package-completion.json'))
check('Final JUnit and7xfails match previously parsed evidence',{(r['platform'],r['path']):r for r in q['qa']['junit_reports']}=={(r['platform'],r['path']):r for r in qd['parsed_junit']} and q['open_gates']['actual_expected_failures']==qd['open_expected_failures'] and len(q['open_gates']['actual_expected_failures'])==7)
check('Native limitations/no ancestor transfer preserved',q['open_gates']['native_limits']==q['native']['limitations'] and q['source_applicability']['no_ancestor_result_transfer'] and q['source_applicability']['no_untriggered_native_lane_acceptance_claimed'])

sm=obj('linux-frozen-smoke-completion.json');lp=q['qa']['linux_package']['product_artifact'];new_smokes=[]
check('Both final Ubuntu smoke identities',sm['source_head']==HEAD and sm['source_tree']==TREE and sm['synthetic_merge_sha']==MERGE and q['qa']['linux_frozen_smokes']==sm['jobs'] and {r['job_id'] for r in sm['jobs']}=={136888792650,136888792729})
for r in sm['jobs']:
 jid=r['job_id'];log=logs[jid];steps=jobs[jid]['steps'];counts={x:len(re.findall(r'^\S+Z '+x+r' ',log,re.M)) for x in ['PASS','FAIL']}
 check(f'{jid}: actual64PASS0FAIL',counts=={'PASS':64,'FAIL':0} and r['passed']==64 and r['failed']==0)
 check(f'{jid}: same-run artifact ID/size/actual digest',r['downloaded_product_id']==lp['id']==14712433241 and r['downloaded_artifact_digest']==lp['digest'] and f"(ID: {lp['id']}, Size: {lp['size_in_bytes']}, Expected Digest: {lp['digest']})" in log and 'SHA256 digest of downloaded artifact is '+lp['digest'].removeprefix('sha256:') in log)
 check(f'{jid}: tar checksum and executable extraction',bool(re.search(r'^\S+Z PatchTrace-0.1.0-linux-x86_64.tar.gz: OK\r?$',log,re.M)) and any('tar xzf PatchTrace-0.1.0-linux-x86_64.tar.gz && test -x PatchTrace/PatchTrace' in s['name'] and s['conclusion']=='success' for s in steps))
 check(f'{jid}: offscreen/XCB/fullCLI success',all(any(fragment in s['name'] and s['conclusion']=='success' for s in steps) for fragment in ['QT_QPA_PLATFORM=offscreen PatchTrace/PatchTrace --self-test','QT_QPA_PLATFORM=xcb xvfb-run -a PatchTrace/PatchTrace --self-test','Full frozen Linux CLI smoke (CODEX-14)']))
 check(f'{jid}: individual self-test receipts agree',all(s in steps and s['conclusion']=='success' for s in r['self_test_steps']))
 new_smokes.append({'job_id':jid,'name':r['name'],'PASS':counts['PASS'],'FAIL':counts['FAIL'],'artifact_id':lp['id'],'artifact_digest':lp['digest']})
check('Actual final release136889308090 skip',q['qa']['release']=={'job_id':136889308090,'conclusion':'skipped'} and jobs[136889308090]['name']=='release' and jobs[136889308090]['conclusion']=='skipped')

artifact_rows=q['artifact_validation']['downloaded_original_artifacts'];expected_artifacts={14709594641,14709899284,14710346116,14710376722,14711636807,14712204882}
check('Exactly six original small artifact ZIPs',len(artifact_rows)==6 and {a['artifact']['id'] for a in artifact_rows}==expected_artifacts and {n for n in z.namelist() if n.endswith('/original.zip')}=={a['local_original_zip'] for a in artifact_rows})
for a in artifact_rows:
 ab=read(a['local_original_zip']);ar=a['artifact'];az=zipfile.ZipFile(io.BytesIO(ab))
 check(str(ar['id'])+': final artifact byte/digest/API/source representation',len(ab)==a['local_bytes']==ar['size_in_bytes'] and sha(ab)==a['local_sha256'] and ar['digest']=='sha256:'+sha(ab) and ar['workflow_run']['head_sha']==HEAD and ar['workflow_run']['id'] in run_ids and az.testzip() is None)
check('Large product bytes explicitly excluded',q['artifact_validation']['no_large_product_binaries_downloaded_locally'] is True)
check('Final source-specific qualification does not preclaim postmerge holds','Pending an actual guarded main merge' in q['open_gates']['post_merge_publication_holds'])
check('Parent archive remains unchanged',sha((ROOT/'final-d60-evidence.zip').read_bytes())==PARENT_SHA)
failures=[x for x in checks if not x['passed']]
report={'schema':'patchtrace/final-completion-delta-independent-review/1','completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'clear_qualified_with_documented_open_gates' if not failures else 'inconsistency_found','source':q['source'],'parent_archive':{'file':str(ROOT/'final-d60-evidence.zip'),'bytes':len(b),'sha256':PARENT_SHA,'manifest_sha256':MANIFEST_SHA,'qualification_sha256':QUAL_SHA,'members':145,'payloads':144},'check_count':len(checks),'failure_count':len(failures),'checks':checks,'reused_unchanged_substantive_audits':[{'assertions':175,'sha256':sha(nb)},{'assertions':96,'archive_sha256':sha(qdbytes)}],'actual_counts':{'runs':2,'jobs':18,'executed_success':16,'intentional_PR_release_skips':2,'verified_checkout_logs':16,'small_original_artifact_ZIPs':6},'newly_verified_Ubuntu_smokes':new_smokes,'actual_release_skip_job':136889308090,'open_expected_failure_records':q['open_gates']['actual_expected_failures'],'native_limits':q['open_gates']['native_limits'],'interpretation':'Final exact-source automatic PR qualification evidence is internally consistent and complete within its documented gates. The root must still perform its own fresh guarded merge. No merge or post-main publication result is claimed by this review.','no_network_download_test_native_source_ref_CI_or_parent_evidence_mutations':True}
(OUT/'completion-delta-review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'assertions':len(checks),'failures':failures,'review_sha256':sha((OUT/'completion-delta-review.json').read_bytes()),'smokes':new_smokes},indent=2))
