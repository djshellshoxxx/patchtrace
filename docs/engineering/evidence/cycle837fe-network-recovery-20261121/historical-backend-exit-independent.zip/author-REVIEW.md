# Historical backend-exit diagnostics — complete branch disposition

**SUPERSEDED.** No missing compatible contribution was found in `fix/backend-exit-diagnostics`. The current source preserves the original fixed failure hints, original exit code, bounded redacted analysis log, backend integration, specification and all original regression assertions. It adds a cached-symbol conflict diagnostic and retains stronger interpreter isolation.

This is one complete named branch disposition. The original **181 unmatched / 16 patch-equivalent** census remains historical and unchanged. No remaining-work recount, branch deletion, source change, ledger update, PR action or native acceptance is implied.

## Exact scope and selection

| Item | Exact identity |
| --- | --- |
| Fresh remote donor | `bc00a6912dde57482a301bf64ef6fbc3f324cb92` |
| Donor tree | `ca7b3bf15c27588560eb09c31802b58be5d7c12b` |
| Current comparison | `d60ac40daf767fe6a93ae152feb21235f6e75e0b` |
| Current tree | `4a07cd88ded407bef30a8aeb81961e4041822dc2` |
| Exact merge base | `736332cf63d3c7927f5c17f4aea5150f624bf957` |
| Unique commits | Six nonmerge commits and one merge |
| Net delta | Six paths; 70 insertions and four deletions |
| Historical union across every parent diff | Thirteen paths |

The original census lists this branch, associated with historical PR6, as `retained-for-semantic-review` with six unmatched nonmerge commits. The authoritative d60 ledger and 30 prior review/disposition documents were checked before selection; none identifies this exact branch or head as already reviewed. `audit/runtime` was considered and excluded because its two commits and declared runtime behavior were already covered in the cycle2 historical review. The selection does not reopen the excluded Java, native Ghidra, sequential-lock, Buildenv, CI/WIN1, installer, artifact-byte or representation work, or PR352–357.

The six branch commits add tests (`483d9cac`), specification (`f66000f1`), classifier (`0321b184`), backend call (`05a50869`), QA note (`e593fe9d`) and module registration (`d590d987`). Merge `bc00a691` combines that line with main736. Raw commit objects, both merge-parent diffs, exact blob identities and preserved file contents are recorded in `source-history-and-paths.json`, `original-history/` and `preserved-source/`.

## Complete path accounting

| Path | Contribution and current disposition |
| --- | --- |
| `docs/modules.md` | The diagnostics registration row is retained verbatim. |
| `docs/qa.md` | The introduced classifier paragraph is retained verbatim as historical documentation. Earlier native/Windows claims in surrounding text are preserved without being promoted into this review's acceptance evidence. |
| `docs/specs/architecture.md` | The complete introduced error-taxonomy paragraph is retained verbatim, including fixed messages, original exit code, bounded log retention and generic fallback. |
| `src/patchtrace/backend.py` | The classifier import and nonzero-exit call remain. Current source still writes the redacted bounded log before classification and records the error without publishing a successful project run. The maintained controlled child fixture passes. |
| `src/patchtrace/diagnostics.py` | Every original classifier branch, fixed hint, 2 MiB tail bound, case-folding step, original-code formatting and unknown fallback remains. Removing the one later cached-symbol-conflict branch from a copied current AST yields the exact original function AST. |
| `tests/test_jobs.py` | All three introduced test definitions—eight cases—are AST-identical. The surrounding maintained fake-runtime helper now launches an explicit authored script under isolated Python rather than relying on current-directory package import. |
| `README.md` | Touched only by the incoming main side of the merge; donor-tip bytes equal the merge base. No unique donor contribution remains in this path. |
| `docs/specs/runtime-discovery.md` | Same inherited-main-only, exact-merge-base relationship. |
| `docs/windows.md` | Same inherited-main-only, exact-merge-base relationship. |
| `src/patchtrace/runtime_discovery.py` | Same inherited-main-only, exact-merge-base relationship. |
| `src/patchtrace/ui.py` | Same inherited-main-only, exact-merge-base relationship. |
| `tests/test_runtime_discovery.py` | Same inherited-main-only, exact-merge-base relationship. |
| `tests/test_ui.py` | Same inherited-main-only, exact-merge-base relationship. |

The seven inherited-main-only paths are explicitly accounted for without treating their entire earlier features as new contributions from this branch. The final six-path delta contains the branch's complete unique behavior. `semantic-proofs.json` retains the mechanical comparisons; no older classifier or test fixture should replace the maintained implementation.

## Controlled original/current evidence

| Source and selection | Actual result |
| --- | --- |
| Historical specification/tests-before-code commit `f66000f1e18ada9a8d0aab7489c2cbe148d12d5c`, original eight cases | **8 failed**: seven calls cannot import the not-yet-created classifier; the backend integration retains only its generic error. These are intended source-regression failures, with zero setup errors. |
| Exact donor `bc00a691`, original eight cases | **8 passed** |
| Exact current `d60`, unchanged original donor test module and fixture | **7 passed, 1 failed** |
| Exact current `d60`, maintained eight cases plus two existing fixed-hint credential controls | **10 passed** |

The old-fixture failure is retained in full. Its fake Ghidriff package is placed in the child's working directory. Current `-I` interpreter isolation refuses that implicit import, so the actual saved log reports a missing module and the error correctly gives the missing-installation hint, instead of the fake script's JDK hint. The maintained fixture preserves the original assertion and explicitly runs the same authored fake script while retaining isolation; it passes. This is a superseded fixture assumption, not a missing donor diagnostic.

`validation-receipts.json` contains exact commands, source heads, timing and exit status. `junit-outcome-index.json` indexes every case and failure. All stdout/stderr and original fake-process `analysis.log`/`failure.txt` artifacts are preserved. The original eight cases overlap across runs and are not added into a cumulative acceptance count.

Each invocation used the existing `/workspace/scratch/837fe19aae3a/pages-config-hold-venv/bin/python`, Python 3.12.14, with `-I -B`, explicit selected-source import paths, disabled pytest plugin autoload/conftest/cache and a scratch basetemp. Binding receipts verify `backend`, `diagnostics` and `jobs` file paths and hashes. Editable metadata remains bound to the original Pages checkout; no environment was rebound or installed. All three detached review checkouts remained clean.

Only the small authored fake Python child was executed; its input `.bin` files contain synthetic static text. No Ghidra/Java runtime, native package, real target, remote service, full suite or fresh platform acceptance was exercised. The additional current pure credential controls do not call a provider.

## Preservation and next action

The portable archive retains the original census record, authoritative ledger snapshot, prior-review search boundary, raw commits and per-parent diffs, all historical path versions, focused source snapshots, verified history bundle and every executed result. Archive/manifest hashes and member verification are recorded separately to avoid circular hashing.

The appropriate next action is independent review of this **SUPERSEDED** branch classification and, if accepted, a later scoped root-owned ledger checkpoint. Preserve the branch and original tests. No implementation or recovery branch is needed for this contribution, and no broader release/native gate is closed.
