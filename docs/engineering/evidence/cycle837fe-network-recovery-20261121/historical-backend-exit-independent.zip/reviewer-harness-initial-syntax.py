"""Independent whole-branch disposition verification; no product/native execution."""
import ast
import copy
import difflib
import hashlib
import io
import json
import re
import shutil
import subprocess
import tarfile
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT=Path('/workspace/scratch/837fe19aae3a')
OUT=ROOT/'evidence/historical-backend-exit-independent'
AUTHOR=ROOT/'evidence/historical-after-d60-next-review'
REPO=ROOT/'PatchTrace-windows-recovery-followup'
DONOR='bc00a6912dde57482a301bf64ef6fbc3f324cb92'
BASE='736332cf63d3c7927f5c17f4aea5150f624bf957'
CURRENT='d60ac40daf767fe6a93ae152feb21235f6e75e0b'
BEFORE='f66000f1e18ada9a8d0aab7489c2cbe148d12d5c'
checks=[]

def check(label,value):
    assert value,label
    checks.append(label)

def sha(b):return hashlib.sha256(b).hexdigest()
def oid(kind,b):return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
def textgit(*args):return git(*args).decode().strip()
def blob(rev,p):return git('show',rev+':'+p)
def read(n):return json.loads((AUTHOR/n).read_text())
def equal(a,b):return ast.dump(a,include_attributes=False)==ast.dump(b,include_attributes=False)
def function(data,name):return next(x for x in ast.parse(data).body if isinstance(x,ast.FunctionDef) and x.name==name)
maps={}
def filemap(rev):
    if rev not in maps:
        maps[rev]={}
        for row in git('ls-tree','-r','-z',rev).split(b'\0'):
            if row:
                left,p=row.split(b'\t',1);mode,kind,ident=left.decode().split();maps[rev][p.decode()]=(mode,kind,ident)
    return maps[rev]

OUT.mkdir(exist_ok=True)
archive=AUTHOR/'historical-backend-exit-diagnostics-review.zip'
check('exact author archive',archive.stat().st_size==3502609 and sha(archive.read_bytes())=='bc29de9d8b82fd720773d845e641986fb52a00c34ce168c7adf5f1b8cb5035ff')
z=zipfile.ZipFile(archive)
check('173 unique author members and CRC',len(z.namelist())==len(set(z.namelist()))==173 and z.testzip() is None)
manifest=json.loads(z.read('payload-manifest.json'))
check('exact author manifest digest',sha(z.read('payload-manifest.json'))=='d635be089029e25a6dcede0ddccfbbd27aff07bca48208d44afe083038810841')
check('complete author payload accounting',set(z.namelist())=={x['path'] for x in manifest['files']}|{'payload-manifest.json'})
for row in manifest['files']:
    b=z.read(row['path']);check('archive member '+row['path'],len(b)==row['bytes'] and sha(b)==row['sha256'] and b==(AUTHOR/row['path']).read_bytes())
review=read('review.json');history=read('source-history-and-paths.json')
check('exact donor and current trees',textgit('rev-parse',DONOR+'^{tree}')=='ca7b3bf15c27588560eb09c31802b58be5d7c12b' and textgit('rev-parse',CURRENT+'^{tree}')=='4a07cd88ded407bef30a8aeb81961e4041822dc2')
check('exact merge base',textgit('merge-base',DONOR,CURRENT)==BASE)
commits=textgit('rev-list','--reverse',BASE+'..'+DONOR).splitlines()
check('complete seven unique commit scope',commits==[x['head'] for x in history['all_unique_commits']] and len(commits)==7)
historical=set();nonmerges=[]
for row in history['all_unique_commits']:
    rev=row['head'];raw=git('cat-file','commit',rev);header,message=raw.decode().split('\n\n',1)
    check('exact raw commit '+rev,raw==z.read(f'original-history/{rev}.commit') and oid('commit',raw)==rev)
    parents=[x[7:] for x in header.splitlines() if x.startswith('parent ')]
    check('tree and ordered parents '+rev,parents==row['parents'] and header.splitlines()[0]=='tree '+row['tree'])
    if len(parents)==1:nonmerges.append(rev)
    check('all parents accounted '+rev,parents==[x['parent'] for x in row['parent_diffs']])
    for diff in row['parent_diffs']:
        parent=diff['parent'];paths=textgit('diff','--name-only',parent,rev).splitlines();historical.update(paths)
        check('complete per-parent path diff '+rev+' '+parent,paths==diff['paths'])
        patch=z.read(f'original-history/{rev}-from-{parent}.patch')
        check('exact per-parent patch '+rev+' '+parent,patch==git('diff',parent,rev))
net=textgit('diff','--name-only',BASE,DONOR).splitlines()
check('six net and thirteen historical paths',net==history['net_paths'] and len(net)==6 and len(historical)==13 and historical=={x['path'] for x in history['all_parent_historical_path_union']})
check('six nonmerge commits plus one merge',len(nonmerges)==6 and len(commits)-len(nonmerges)==1)
stats=[line.split('\t') for line in textgit('diff','--numstat',BASE,DONOR).splitlines()]
check('complete net size70insertions4deletions',sum(int(x[0]) for x in stats)==70 and sum(int(x[1]) for x in stats)==4)
for row in history['all_parent_historical_path_union']:
    p=row['path']
    for rev,key in [(BASE,'base_blob'),(DONOR,'donor_blob'),(CURRENT,'current_blob')]:check('historical Git identity '+rev+' '+p,filemap(rev)[p][2]==row[key])
    if p not in net:check('incoming-main-only path exact merge base '+p,blob(BASE,p)==blob(DONOR,p))
preserved=0
for name in z.namelist():
    if name.startswith('preserved-source/'):
        _,rev,p=name.split('/',2);check('preserved historical source '+rev+' '+p,oid('blob',z.read(name))==filemap(rev)[p][2]);preserved+=1
    if name.startswith('prior-inputs/'):
        p=name[len('prior-inputs/'):];check('prior input bound to d60 '+p,z.read(name)==blob(CURRENT,p))
    if name.startswith('current-test-context/'):
        p=name[len('current-test-context/'):];check('current fixture context exact '+p,z.read(name)==blob(CURRENT,p))
snapshot_count=0
for row in read('source-snapshot-verification.json'):
    data=z.read(row['file']);rev=row['head']
    check('focused tar identity '+row['file'],len(data)==row['bytes'] and sha(data)==row['sha256'] and textgit('rev-parse',rev+'^{tree}')==row['tree'])
    with tarfile.open(fileobj=io.BytesIO(data),mode='r:') as tar:
        members=[x for x in tar.getmembers() if x.isfile()]
        check('focused tar exact coverage '+row['file'],len(members)==row['file_count']==len(row['files']) and {x.name for x in members}=={x['path'] for x in row['files']})
        for x in row['files']:
            b=tar.extractfile(x['path']).read();check('focused source '+rev+' '+x['path'],len(b)==x['bytes'] and sha(b)==x['sha256'] and oid('blob',b)==x['git_blob']==filemap(rev)[x['path']][2]);snapshot_count+=1

# Preserve every original classifier branch; discard only the known later fixed-hint extension in a copied AST.
old=function(blob(DONOR,'src/patchtrace/diagnostics.py'),'describe_backend_exit')
new=function(blob(CURRENT,'src/patchtrace/diagnostics.py'),'describe_backend_exit')
normalized=copy.deepcopy(new);matches=[]
for node in ast.walk(normalized):
    if isinstance(node,ast.If) and len(node.orelse)==1 and isinstance(node.orelse[0],ast.If):
        child=node.orelse[0]
        if "symbols are disabled, but the symbol is already downloaded" in ast.unparse(child.test):matches.append((node,child))
check('one later cached-symbol extension only',len(matches)==1)
node,child=matches[0];node.orelse=child.orelse
check('all original classifier AST exact after removing extension',equal(normalized,old))
test_names=['test_exit_diagnostics_identify_common_failures_without_echoing_raw_logs','test_unknown_exit_diagnostics_keep_original_status_code','test_nonzero_backend_exit_preserves_classified_error_and_log']
for name in test_names:check('original regression function exact '+name,equal(function(blob(DONOR,'tests/test_jobs.py'),name),function(blob(CURRENT,'tests/test_jobs.py'),name)))
param=function(blob(DONOR,'tests/test_jobs.py'),test_names[0]).decorator_list[0]
check('original six parameterized classifier cases plus2',len(param.args[1].elts)==6)
for p in ['docs/modules.md','docs/qa.md','docs/specs/architecture.md']:
    additions=[x[1:] for x in difflib.unified_diff(blob(BASE,p).decode().splitlines(),blob(DONOR,p).decode().splitlines()) if x.startswith('+') and not x.startswith('+++') and x[1:].strip()]
    check('complete introduced documentation retained '+p,bool(additions) and all(x in blob(CURRENT,p).decode() for x in additions))
raise_node=ast.parse('raise RuntimeError(describe_backend_exit(result.returncode, sanitized_log))').body[0]
for rev in [DONOR,CURRENT]:
    data=blob(rev,'src/patchtrace/backend.py');tree=ast.parse(data)
    check('classifier integration retained '+rev,any(equal(n,raise_node) for n in ast.walk(tree) if isinstance(n,ast.Raise)))
    text=data.decode();check('redacted log saved before classification '+rev,text.index('sanitized_log = redact_log(result.log_tail)')<text.index("write_text(sanitized_log")<text.index('raise RuntimeError(describe_backend_exit')))
old_fixture=function(blob(DONOR,'tests/test_jobs.py'),'fake_runtime');new_fixture=function(blob(CURRENT,'tests/test_jobs.py'),'fake_runtime');normalized_fixture=copy.deepcopy(new_fixture)
normalized_fixture.body=[x for x in normalized_fixture.body if not (isinstance(x,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='real_run' for t in x.targets)) and not (isinstance(x,ast.FunctionDef) and x.name=='run_fake') and not (isinstance(x,ast.Expr) and isinstance(x.value,ast.Call) and any(isinstance(a,ast.Constant) and a.value=='run_process' for a in x.value.args))]
check('maintained fixture only adds explicit script bridge',equal(normalized_fixture,old_fixture))
check('same authored fake script writer',equal(function(blob(DONOR,'tests/test_jobs.py'),'write_backend'),function(blob(CURRENT,'tests/test_jobs.py'),'write_backend')))
bridge=next(x for x in new_fixture.body if isinstance(x,ast.FunctionDef) and x.name=='run_fake')
check('fixture bridge preserves preceding interpreter flags','[*argv[:index], str(package / \'__main__.py\'), *argv[index + 2:]]' in ast.unparse(bridge) and 'return real_run(argv, **kwargs)' in ast.unparse(bridge))
launch=function(blob(CURRENT,'src/patchtrace/backend.py'),'_ghidriff_argv')
check('current real argv retains isolated interpreter',"'-I', '-X', 'utf8'" in ast.unparse(launch))

outcomes={}
for label,(passed,failed) in {'historical-tests-before-fix':(0,8),'original-donor-tests':(8,0),'original-tests-current-source':(7,1),'maintained-current-tests':(10,0)}.items():
    rows=ET.fromstring(z.read(label+'.xml')).findall('.//testcase');fail=[x for x in rows if x.find('failure') is not None];errors=[x for x in rows if x.find('error') is not None];skips=[x for x in rows if x.find('skipped') is not None]
    check(label+' exact actual outcome',len(rows)-len(fail)-len(errors)-len(skips)==passed and len(fail)==failed and not errors and not skips)
    outcomes[label]={'passed':passed,'failed':failed,'errors':0,'skipped':0,'failure_names':[x.attrib['name'] for x in fail]}
    if label=='original-tests-current-source':check('sole current original-fixture failure retained',fail[0].attrib['name']=='test_nonzero_backend_exit_preserves_classified_error_and_log' and 'Ghidriff installation is missing' in ET.tostring(fail[0],encoding='unicode'))
    binding=json.loads(z.read(label+'-binding.json'));rev=BEFORE if label=='historical-tests-before-fix' else DONOR if label=='original-donor-tests' else CURRENT
    for b in binding['bindings']:
        relative='src/patchtrace/'+b['module'].split('.')[-1]+'.py';check(label+' exact module binding '+relative,b['sha256']==sha(blob(rev,relative)) and b['path'].endswith('/'+relative))
    check(label+' disclosed non-rebound environment',not binding['environment_rebound'] and 'repair-pages-config-hold' in binding['editable_direct_url'])
fixtures=read('fixture-output-receipt.json')['files'];fixture_logs={}
for row in fixtures:
    data=z.read(row['path']);check('controlled fixture output '+row['path'],len(data)==row['bytes'] and sha(data)==row['sha256'])
    label=row['path'].split('/')[1];fixture_logs[(label,Path(row['path']).name)]=data
check('old fixture fails at isolated cwd import',b"No module named ghidriff" in fixture_logs[('original-tests-current-source','analysis.log')] and b'code 1' in fixture_logs[('original-tests-current-source','failure.txt')])
check('maintained fake output and classified failure equal donor',fixture_logs[('original-donor-tests','analysis.log')]==fixture_logs[('maintained-current-tests','analysis.log')] and fixture_logs[('original-donor-tests','failure.txt')]==fixture_logs[('maintained-current-tests','failure.txt')] and b'code 7' in fixture_logs[('maintained-current-tests','failure.txt')] and b'JDK' in fixture_logs[('maintained-current-tests','failure.txt')])
for row in read('validation-receipts.json'):
    check('isolated author command '+row['label'],'-I' in row['command'] and '-B' in row['command'] and row['source_clean_after'])

inventory_path='docs/engineering/branch-recovery-20261120-2bad.json';inventory_bytes=blob(CURRENT,inventory_path);inventory=json.loads(inventory_bytes)
(OUT/'original-181-16-inventory.json').write_bytes(inventory_bytes)
check('original canonical181/16 counts',inventory['counts']['classifications']['unmatched-patches-review-required']==181 and inventory['counts']['classifications']['patch-equivalent-semantics-unreviewed']==16)
record=next(x for x in inventory['branches'] if x['head']==DONOR)
check('exact donor in original181bucket',record['classification']=='unmatched-patches-review-required' and record['unmatched_nonmerge_commits']==nonmerges and not record['delete_authorized'])
selected=read('selected-original-census-record.json');older=json.loads(z.read('prior-inputs/docs/engineering/consolidation-inventory.json'))
check('selected full prior inventory row exact',[x for x in older['branches'] if x['branch']=='fix/backend-exit-diagnostics']==[selected])
check('historical census not rewritten or globally closed',review['historical_census']=={'unmatched':181,'patch_equivalent':16,'unchanged':True,'remaining_work_recounted':False} and not review['deletion_authorized'])
check('authoritative d60 ledger snapshot exact',sha(blob(CURRENT,'docs/engineering/task-ledger.json'))==read('selection-boundary.json')['authoritative_ledger_sha256'])
bundle=AUTHOR/'backend-exit-diagnostics-history.bundle';receipt=read('bundle-receipt.json')
check('exact original history bundle',bundle.stat().st_size==receipt['bytes'] and sha(bundle.read_bytes())==receipt['sha256'])
verification=subprocess.run(['git','-C',str(REPO),'bundle','verify',str(bundle)],capture_output=True,text=True)
check('bundle verifies read-only',verification.returncode==0)
check('second explicit bundle prerequisite already ancestor of main prerequisite',subprocess.run(['git','-C',str(REPO),'merge-base','--is-ancestor','0f1b4ce5a0b51526fdceb5533f0553321899fd2a',BASE],capture_output=True).returncode==0)
(OUT/'bundle-verification.txt').write_text(verification.stdout+verification.stderr)
check('no ancestry inclusion claimed',subprocess.run(['git','-C',str(REPO),'merge-base','--is-ancestor',DONOR,CURRENT],capture_output=True).returncode==1)
ref=read('fresh-donor-ref.json');check('author ref snapshot exact named donor',ref['data']['ref']=='refs/heads/fix/backend-exit-diagnostics' and ref['data']['object']['sha']==DONOR)
check('no source or native acceptance claims',not review['native_acceptance_claimed'] and not review['hosted_acceptance_claimed'] and not review['real_target_execution'] and not review['release_ready_claimed'])

proof={'schema':'patchtrace/backend-exit-independent-checks/1','donor':DONOR,'base':BASE,'current':CURRENT,'check_count':len(checks),'checks':checks,'preserved_historical_source_versions':preserved,'focused_snapshot_files_verified':snapshot_count,'unique_commits':7,'nonmerge_commits':6,'net_paths':6,'historical_paths':13,'retained_test_outcomes':outcomes,'new_product_or_native_tests':0,'blockers':[]}
(OUT/'checks.json').write_text(json.dumps(proof,indent=2)+'\n')
result={'schema':'patchtrace/historical-backend-exit-independent-review/1','reviewed_at':datetime.now(timezone.utc).isoformat(),'classification':'SUPERSEDED','verdict':'CLEAR_COMPLETE_NAMED_BRANCH_DISPOSITION','blockers':[],'donor_head':DONOR,'donor_tree':'ca7b3bf15c27588560eb09c31802b58be5d7c12b','base':BASE,'comparison_head':CURRENT,'comparison_tree':'4a07cd88ded407bef30a8aeb81961e4041822dc2','whole_branch_scope':{'commits':7,'nonmerge':6,'merge':1,'net_paths':6,'historical_paths':13,'inherited_main_only_paths':7,'preserved_historical_source_versions':preserved,'focused_tar_files':snapshot_count},'semantic':'Every original classifier AST branch remains after removal of exactly one later cached-symbol fixed-hint branch. Original regression definitions, integration raise, specification, module and QA lines remain. Maintained fixture only adds explicit script launch while retaining isolated interpreter flags.','retained_actual_results':outcomes,'obsolete_fixture_failure_explanation_verified':True,'classifier_tail_limit_unit':'The slice is 2*1024*1024 Python string characters; this is unchanged, not a new UTF-8 byte-limit claim.','bundle_prerequisites':[BASE,'0f1b4ce5a0b51526fdceb5533f0553321899fd2a'],'second_bundle_prerequisite_is_ancestor_of_first':True,'original_census':{'unmatched':181,'patch_equivalent':16,'donor_original_bucket':'unmatched-patches-review-required','unchanged':True,'no_remaining_work_recount':True},'mechanical_checks':len(checks),'new_product_or_native_tests_run':0,'author_archive_sha256':'bc29de9d8b82fd720773d845e641986fb52a00c34ce168c7adf5f1b8cb5035ff','source_ref_PR_CI_ledger_mutations':False,'branch_deletion_authorized':False,'full_inventory_closed':False,'release_or_native_acceptance_claimed':False,'next_action':'Root may record this one complete named disposition while retaining branch/history/failures and all wider gates; no source port needed.'}
(OUT/'review.json').write_text(json.dumps(result,indent=2)+'\n')
for name in ['REVIEW.md','source-history-and-paths.json','semantic-proofs.json','fixture-output-receipt.json','selected-original-census-record.json','archive-receipt.json']:
    shutil.copyfile(AUTHOR/name,OUT/('author-'+name))
shutil.copyfile(archive,OUT/'immutable-author-backend-exit-review.zip')
(OUT/'REVIEW.md').write_text(f'''# Historical backend-exit diagnostics — independent disposition

**SUPERSEDED is supported for the complete named branch. No missing compatible contribution or blocking classification issue was found.**

Exact donor `{DONOR}` / tree `ca7b3bf15c27588560eb09c31802b58be5d7c12b` is compared with frozen d60 `{CURRENT}` / tree `4a07cd88ded407bef30a8aeb81961e4041822dc2`, merge base `{BASE}`. All seven unique commits (six nonmerge plus one merge), eight parent diffs, six net changed paths and thirteen historical paths were independently checked against Git objects. The seven historical-only paths equal the merge base at the donor tip, so they are inherited incoming-main changes, not omitted unique branch work.

The maintained classifier retains the exact original AST after removing only one later cached-symbol-conflict branch. All original fixed hints, return-code formatting, fallback and character-tail bound remain. The backend import/classification call and redacted log-before-classification sequence remain; introduced module/specification/QA lines remain verbatim. All three original test definitions, including six parameterized cases, remain AST-identical.

The retained results are **parent8 failures; donor8 passes; unchanged original fixture on current7 passes/1 failure; maintained current10 passes**. These are overlapping selections, not an aggregate acceptance count. The original-current failure is specifically the old fixture's implicit working-directory package import under current `-I` isolation. Its saved log reports the missing module and exit1. The maintained fixture adds only an explicit authored-script launch bridge, preserving interpreter flags and the original assertion; its saved fake log and exit7/JDK failure text are byte-identical to the donor's. This supports the stronger-isolation explanation without weakening an assertion or deleting the original failure.

The author archive is exactly173 members /3,502,609 bytes, SHA256 `bc29de9d8b82fd720773d845e641986fb52a00c34ce168c7adf5f1b8cb5035ff`; every manifest member/CRC passed. {preserved} preserved historical source versions and {snapshot_count} focused tar files bind to exact Git blobs. The seven-commit history bundle verifies read-only and declares both736 and0f1 prerequisites;0f1 is already an ancestor of736. The original canonical181/16 snapshot and the exact donor's membership in the181 unmatched bucket are independently verified and retained, without a global recount or decrement.

This review performed **{len(checks)} mechanical source/history/evidence checks and no product/native reruns**. Only the author's already retained small fake-Python process evidence is assessed; no Ghidra, Java, native target or platform acceptance is inferred. No source/ref/PR/CI/ledger edits occurred. Preserve the branch, original source, all failures and broader gates. Root may add this one scoped disposition; no code port is needed.
''')
files=sorted(x for x in OUT.iterdir() if x.is_file());rows=[{'path':x.name,'bytes':x.stat().st_size,'sha256':sha(x.read_bytes())} for x in files]
mf=OUT/'evidence-manifest.json';mf.write_text(json.dumps({'schema':'patchtrace/evidence-manifest/1','files':rows,'lists_itself':False},indent=2)+'\n')
dest=OUT/'historical-backend-exit-independent.zip'
with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as out:
    for p in files+[mf]:out.write(p,p.name)
with zipfile.ZipFile(dest) as out:
    assert out.testzip() is None
    for row in rows:assert sha(out.read(row['path']))==row['sha256']
seal={'archive_file':dest.name,'archive_bytes':dest.stat().st_size,'archive_members':len(rows)+1,'archive_sha256':sha(dest.read_bytes()),'manifest_sha256':sha(mf.read_bytes()),'review_sha256':sha((OUT/'review.json').read_bytes()),'mechanical_checks':len(checks),'CRC_and_all_member_hashes_verified':True}
(OUT/'archive-receipt.json').write_text(json.dumps(seal,indent=2)+'\n');print(json.dumps(seal,indent=2))
