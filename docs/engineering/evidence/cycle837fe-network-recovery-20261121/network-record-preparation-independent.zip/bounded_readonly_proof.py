"""Independent preparation proof; reads Git and writes only this evidence directory."""
from __future__ import annotations

import ast
from copy import deepcopy
from datetime import datetime, timezone
from hashlib import sha1, sha256
from pathlib import Path
import json
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/837fe19aae3a')
OUT = Path(__file__).resolve().parent
REPO = ROOT / 'PatchTrace-network-recovery-followup'
SOURCE = '9610919d29010d53cf00af3b7c38207ffd84f945'
TREE = '3d5e2965ef26235610a08fd8378cac078c6bd9a0'
NETWORK = '96baaee20f390a3f2a5629de3764d32323bb80e5'
BASE = 'd60ac40daf767fe6a93ae152feb21235f6e75e0b'
BASE_TREE = '4a07cd88ded407bef30a8aeb81961e4041822dc2'
OLD_MAIN = '3a16290c0fcc4e0c21712fe10474a3ff33fad336'
MERGE = 'ea16019601486c831941f9bc1a7ba5862a170317'
REMOTE = '5c07bfd1a41b399fee86545206ed1c5e9aec0c26'
CHECKS = []
RESULTS = {}


def digest(data):
    return sha256(data).hexdigest()


def check(label, condition, detail=None):
    row = {'label': label, 'passed': bool(condition)}
    if detail is not None:
        row['detail'] = detail
    CHECKS.append(row)
    if not condition:
        raise AssertionError(label)


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def save(name, data):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    if isinstance(data, (dict, list)):
        data = (json.dumps(data, indent=2, ensure_ascii=False) + '\n').encode()
    path.write_bytes(data)


def entries(commit):
    result = {}
    for row in git('ls-tree', '-rz', commit).split(b'\0'):
        if not row:
            continue
        meta, path = row.split(b'\t', 1)
        mode, kind, oid = meta.decode().split()
        result[path.decode()] = {'mode': mode, 'kind': kind, 'oid': oid}
    return result


def object_parts(oid, namespace):
    check(f'{namespace}: actual type', git('cat-file', '-t', oid).strip() == b'commit')
    raw = git('cat-file', 'commit', oid)
    check(f'{namespace}: actual Git object digest', sha1(b'commit ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == oid)
    save(f'git-objects/{oid}.commit', raw)
    header, message = raw.split(b'\n\n', 1)
    parents = [line[7:].decode() for line in header.splitlines() if line.startswith(b'parent ')]
    trees = [line[5:].decode() for line in header.splitlines() if line.startswith(b'tree ')]
    check(f'{namespace}: single complete tree', len(trees) == 1)
    subject, _, body = message.partition(b'\n')
    check(f'{namespace}: both markers in actual subject and body', all(marker in subject and marker in body for marker in [b'[no release]', b'[no deploy]']))
    return {'oid': oid, 'tree': trees[0], 'parents': parents, 'message': message, 'raw_sha256': digest(raw)}


def verify_archive(path, expected_hash, size, members):
    data = path.read_bytes()
    check(f'{path.name}: archive hash and byte count', digest(data) == expected_hash and len(data) == size)
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        check(f'{path.name}: exact member count and no duplicate members', len(names) == len(set(names)) == members)
        check(f'{path.name}: all CRCs', archive.testzip() is None)
        manifest = json.loads(archive.read('manifest.json'))
        rows = manifest['files']
        check(f'{path.name}: manifest exhausts all payloads', {item['path'] for item in rows} == set(names) - {'manifest.json'})
        for item in rows:
            raw = archive.read(item['path'])
            check(f'{path.name}: {item["path"]}', len(raw) == item['bytes'] and digest(raw) == item['sha256'])
    save('inputs/' + path.name, data)
    return {'path': str(path), 'sha256': digest(data), 'bytes': len(data), 'members': members, 'manifest_sha256': digest(archive_manifest_bytes(path))}


def archive_manifest_bytes(path):
    with zipfile.ZipFile(path) as archive:
        return archive.read('manifest.json')


def source_and_objects():
    check('Frozen source and tree', git('rev-parse', 'HEAD').decode().strip() == SOURCE and git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE)
    check('Source starts clean', not git('status', '--porcelain=v1').strip())
    proof_path = ROOT / 'evidence/network-tooling-code-publication-preparation/actual-git-object-proof-v2.json'
    raw = proof_path.read_bytes()
    check('V2 actual object proof exact hash', digest(raw) == '318206b597943d6790b76d6a81efecf88b6daab4fd735c09603dfaac9c08f156')
    proof = json.loads(raw)
    mapping_path = proof_path.with_name('object-mapping-v2.json')
    mapping = json.loads(mapping_path.read_bytes())['mapping']
    save('inputs/actual-git-object-proof-v2.json', raw)
    save('inputs/object-mapping-v2.json', mapping_path.read_bytes())
    rows = proof['objects']
    check('Exactly seven tooling mappings', len(rows) == 7)
    ordered = git('rev-list', '--reverse', f'{NETWORK}..{SOURCE}').decode().splitlines()
    check('Exactly seven original tooling commits retained in order', ordered == [row['local'] for row in rows])
    actual = []
    for row in rows:
        local = object_parts(row['local'], row['local'][:8] + ' local')
        remote = object_parts(row['remote'], row['remote'][:8] + ' remote')
        check(f'{row["local"][:8]}: complete trees equal', local['tree'] == remote['tree'] == row['tree'])
        check(f'{row["local"][:8]}: ordered mapped parents', [mapping.get(p, p) for p in local['parents']] == remote['parents'] == row['ordered_parents'])
        check(f'{row["local"][:8]}: actual messages byte equal', local['message'] == remote['message'])
        check(f'{row["local"][:8]}: retained raw remote object hash', remote['raw_sha256'] == row['remote_commit_bytes_sha256'])
        actual.append({k: v for k, v in remote.items() if k != 'message'} | {'local': local['oid']})
    check('Final remote complete tree', actual[-1]['oid'] == REMOTE and actual[-1]['tree'] == TREE)
    donors = [BASE, 'e3928ab8c8e2deee7bb01b0f857205f68a1abda2', '1d475d926314ae116442bfe2b7cd268ad95ea12c', 'd0a4bdf439775999340ea760d96a087e032ee6dd', 'e2127864cb481026db0157082d688b8a36595e3b']
    for donor in donors:
        for end in [SOURCE, REMOTE]:
            check(f'Public donor {donor[:8]} is ancestor of {end[:8]}', subprocess.run(['git', 'merge-base', '--is-ancestor', donor, end], cwd=REPO).returncode == 0)
    a, b, c = entries(NETWORK), entries(SOURCE), entries(BASE)
    paths = sorted(path for path in set(a) | set(b) if a.get(path) != b.get(path))
    check('Seven tooling commits change exactly eleven distinct paths', len(paths) == 11, paths)
    network_changed = sorted(path for path in set(c) | set(a) if a.get(path) != c.get(path))
    net_tests = [p for p in network_changed if p.startswith('tests/')]
    check('All network source runtime entries identical after tooling', {p: row for p, row in a.items() if p.startswith('src/')} == {p: row for p, row in b.items() if p.startswith('src/')})
    for p in net_tests:
        check(f'Network test unchanged: {p}', a[p] == b[p])
    records = ['docs/engineering/task-ledger.json', 'docs/engineering-handoffs/cycle837fe-combined-pr349-20261121.md', 'docs/qa.md', 'tasks/todo.md']
    for path in records:
        check(f'Prior records unchanged since network96: {path}', a[path] == b[path])
    ledger = git('show', SOURCE + ':' + records[0])
    check('Entire ledger still equal to public d60', ledger == git('show', BASE + ':' + records[0]))
    parsed = json.loads(ledger)
    check('Original ledger 116 unique ordered tasks and 46 notes', len(parsed['tasks']) == len({x['id'] for x in parsed['tasks']}) == 116 and len(parsed['notes']) == 46)
    all_paths = sorted(p for p in set(b) | set(c) if b.get(p) != c.get(p))
    check('Complete 29-path source union equals retained proof', all_paths == proof['changed_paths_above_d60'] and len(all_paths) == 29)
    commits = git('rev-list', f'{BASE}..{SOURCE}').decode().splitlines()
    check('All 38 original unique commits above d60', len(commits) == len(set(commits)) == proof['unique_commits_above_d60'] == 38)
    merge = object_parts(MERGE, 'Actual PR357 merge')
    check('Actual main ordered parents and tree', merge['parents'] == [OLD_MAIN, BASE] and merge['tree'] == BASE_TREE)
    check('Actual PR357 content already incorporated', not git('diff', '--name-only', BASE, MERGE).strip())
    save('source-path-proof.json', {'source': SOURCE, 'tree': TREE, 'network_source': NETWORK, 'tooling_paths': paths, 'original_29_paths': all_paths, 'network_test_paths_preserved': net_tests, 'records_preserved': records, 'unchanged_entries_since_network96': sum(a.get(p) == b.get(p) for p in set(a) | set(b)), 'source_commits_above_d60': commits, 'remote_objects': actual, 'ledger_sha256': digest(ledger), 'ledger_tasks': 116, 'ledger_notes': 46})
    RESULTS['source'] = {'head': SOURCE, 'tree': TREE, 'remote_equivalent': REMOTE, 'original_commits': 38, 'changed_paths': 29, 'tooling_commits': 7, 'tooling_paths': 11, 'preserved_network_tests': net_tests}


def qualification_and_archives():
    root = ROOT / 'evidence'
    archives = [
        (root / 'network-tooling-final-source-qualification/network-tooling-final-source-qualification.zip', '5c366c8c43e1a971d4f06adf4a1b2c1de1446941fb8e4d72fdfdcd91f72f14e5', 22442, 15),
        (root / 'network-tooling-code-publication-preparation/network-tooling-code-object-preparation.zip', 'c9690c50e54c72e98a3c084a6ac021320899b38bc109d669cd8a032800f5b857', 23713, 10),
    ]
    RESULTS['archives'] = [verify_archive(*args) for args in archives]
    folder = root / 'network-tooling-final-source-qualification'
    raw = (folder / 'qualification.json').read_bytes()
    check('Qualification exact hash', digest(raw) == 'dc73940da64e06d8594dde7566f65c6d2e8d5e8e3c5f7975342b4ea0191ce814')
    q = json.loads(raw)
    check('Qualification source and tree exact', q['source'] == SOURCE and q['tree'] == TREE)
    check('Exactly 26 deduplicated selectors', len(q['selectors']) == len(set(q['selectors'])) == 26)
    for name in ['source-before.json', 'source-after.json']:
        before = json.loads((folder / name).read_bytes())
        check(f'{name}: clean exact source', before == {'head': SOURCE, 'tree': TREE, 'status': ''})
    nodes = ET.fromstring((folder / 'maintained.xml').read_bytes()).findall('.//testcase')
    identity = [(n.attrib.get('classname'), n.attrib.get('name')) for n in nodes]
    check('JUnit 656 unique cases', len(nodes) == len(set(identity)) == 656)
    failures = [n for n in nodes if n.find('failure') is not None or n.find('error') is not None]
    skipped = [(n.attrib.get('classname'), n.attrib.get('name'), n.find('skipped').attrib) for n in nodes if n.find('skipped') is not None]
    check('No failed/error cases', not failures)
    check('Exactly both unchanged strict C5 expected failures', len(skipped) == 2 and all(row[2].get('type') == 'pytest.xfail' for row in skipped) and {row[1] for row in skipped} == {'test_all_explicit_workflow_pip_installs_are_protected', 'test_pip_downloads_require_hashes'})
    check('654 passes with no ordinary skip', len(nodes) - len(skipped) == 654)
    check('Root JUnit summary matches raw XML', q['maintained']['junit'] == {'cases': 656, 'passed': 654, 'failed': 0, 'errors': 0, 'skipped': 0, 'xfailed': 2})
    check('Root process succeeded with isolated source invocation', q['maintained']['exit_code'] == 0 and '-I' in q['maintained']['argv'] and '-B' in q['maintained']['argv'])
    for entry in q['tooling']:
        check(f'Root {entry["label"]} actual success and source', entry['exit_code'] == 0 and entry['source_after'] == {'head': SOURCE, 'tree': TREE, 'status': ''})
    binding = json.loads((folder / 'source-binding.json').read_bytes())
    for module, row in binding['modules'].items():
        path = Path(row['path'])
        check(f'Actual source binding {module}', path.is_relative_to(REPO) and digest(path.read_bytes()) == row['sha256'])
    seven = {'pytest': '9.2.0', 'hypothesis': '6.170.17', 'iniconfig': '2.3.1', 'packaging': '26.3', 'pluggy': '1.7.0', 'pygments': '2.21.0', 'sortedcontainers': '2.4.0'}
    check('All seven exact selected tooling versions', {k: v['version'] for k, v in binding['tooling'].items()} == seven)
    check('No native/full/environment claim', not q['full_suite_run'] and not q['native_or_windows_claim'] and not q['environment_rebound_or_installed'] and q['separate_source_counts_not_aggregated'])
    check('Earlier C5 and pilot failures retained by original ancestor chain', subprocess.run(['git', 'merge-base', '--is-ancestor', '1dcb9729e00ba1197861f801b83e7d414d38950b', SOURCE], cwd=REPO).returncode == 0)
    ff_path = root / 'network-sigstore-integration/fast-forward-proof.json'
    save('inputs/fast-forward-proof.json', ff_path.read_bytes())
    ff = json.loads(ff_path.read_bytes())
    check('FF source and independent Sigstore receipt', ff['after'] == SOURCE and ff['tree'] == TREE and ff['independent_review_sha256'] == '6182bb5e31714177922a4db3a8c24758efd9c6793c59d682b1df7ffeb71998cb' and not ff['remote_ref_moved'])
    RESULTS['qualification'] = {'source': SOURCE, 'tree': TREE, 'root_passed': 654, 'strict_xfailed': 2, 'unique_cases': 656, 'selectors': 26, 'new_tests_run_by_reviewer': 0, 'ruff_pip_check': 'retained exact-source successful receipts', 'scope': 'Local bounded source qualification; final record-head hosted QA and applicable native/platform qualification remain outstanding.'}


def helper_guard_controls():
    path = OUT / 'initial-assemble_network_recovery_records.py'
    text = path.read_text()
    tree = ast.parse(text)
    main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
    statements = main.body
    start = next(i for i, n in enumerate(statements) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'promotion' for t in n.targets))
    end = next(i for i, n in enumerate(statements) if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'qualification' for t in n.targets))
    promote = compile(ast.fix_missing_locations(ast.Module(body=statements[start:end], type_ignores=[])), str(path), 'exec')
    sig_node = next(n for n in statements if isinstance(n, ast.If) and "sigstore_source" in ast.unparse(n.test))
    sig_gate = compile(ast.fix_missing_locations(ast.Module(body=[sig_node], type_ignores=[])), str(path), 'exec')
    promotion = {'merged': True, 'pr_number': 357, 'source_head': BASE, 'source_tree': BASE_TREE, 'all_applicable_automated_jobs_passed': True, 'opt_outs_verified': True, 'merge_commit': MERGE, 'actual_parents': [OLD_MAIN, BASE], 'actual_tree': BASE_TREE}
    cases = []

    def guard(ok, message):
        if not ok:
            raise RuntimeError(message)

    def invoke(label, code, context, expected):
        scope = {'context': context, 'git': git, 'BASE': BASE, 'BASE_TREE': BASE_TREE, 'OLD_MAIN': OLD_MAIN, 'source': SOURCE, 'repo': REPO, 'subprocess': subprocess, 'check': guard}
        try:
            exec(code, scope)
            accepted, error = True, None
        except Exception as exc:
            accepted, error = False, f'{type(exc).__name__}: {exc}'
        cases.append({'label': label, 'accepted': accepted, 'expected_acceptance': expected, 'meets_expected': accepted == expected, 'error': error})

    invoke('Actual full SHA promotion', promote, {'actual_pr357_promotion': deepcopy(promotion)}, True)
    for label, patch in [('noncanonical_revision_expression', {'merge_commit': MERGE + '^0'}), ('wrong_ordered_parents', {'actual_parents': [BASE, OLD_MAIN]}), ('wrong_tree', {'actual_tree': TREE}), ('unmerged', {'merged': False}), ('wrong_PR', {'pr_number': 356}), ('unqualified', {'all_applicable_automated_jobs_passed': False})]:
        value = deepcopy(promotion); value.update(patch)
        invoke(label, promote, {'actual_pr357_promotion': value}, False)
    value = {'sigstore_source': SOURCE, 'independent_sigstore_review': {'source': SOURCE, 'tree': TREE, 'verdict': 'CLEAR', 'blockers': []}}
    invoke('Exact Sigstore source review', sig_gate, deepcopy(value), True)
    invoke('Absent Sigstore review fields', sig_gate, {}, False)
    value['independent_sigstore_review']['verdict'] = 'BLOCKED'
    invoke('Non-clear Sigstore review', sig_gate, value, False)
    save('original-helper-guard-controls.json', {'helper_sha256': digest(path.read_bytes()), 'method': 'Execute only parsed promotion/Sigstore validation statements with actual read-only Git; never invoke main or write repository files.', 'cases': cases, 'findings': [c for c in cases if not c['meets_expected']]})
    check('Original actual full-SHA promotion accepted', cases[0]['meets_expected'])
    check('Original explicit wrong parent/tree/state guards reject', all(c['meets_expected'] for c in cases[2:7]))
    check('Exact original Sigstore review accepted and non-clear refused', cases[7]['meets_expected'] and cases[-1]['meets_expected'])
    RESULTS['original_helper_findings'] = [c for c in cases if not c['meets_expected']]
    RESULTS['helper_initial_sha256'] = digest(path.read_bytes())


def main():
    try:
        source_and_objects()
        qualification_and_archives()
        helper_guard_controls()
        check('Frozen source remains clean and exact', git('rev-parse', 'HEAD').decode().strip() == SOURCE and not git('status', '--porcelain=v1').strip())
        RESULTS['mechanical_checks'] = len(CHECKS)
        RESULTS['mechanical_failed'] = sum(not c['passed'] for c in CHECKS)
        RESULTS['scope'] = 'PREPARATION ONLY; no final assembled-record clearance, no new product tests, no remote operations or source/environment mutation.'
    finally:
        save('checks.json', CHECKS)
        save('preparation-proof.json', RESULTS)
    print(json.dumps({'checks': len(CHECKS), 'failed': sum(not c['passed'] for c in CHECKS), 'helper_findings': len(RESULTS.get('original_helper_findings', [])), 'source': SOURCE, 'tree': TREE}))


if __name__ == '__main__':
    main()
