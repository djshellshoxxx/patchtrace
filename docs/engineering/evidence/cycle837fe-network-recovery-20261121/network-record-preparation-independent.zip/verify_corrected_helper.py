"""Memory-only controls for corrected record guards and history preservation."""
from __future__ import annotations
import ast
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import json
import subprocess

ROOT = Path('/workspace/scratch/837fe19aae3a')
OUT = Path(__file__).resolve().parent
REPO = ROOT / 'PatchTrace-network-recovery-followup'
SOURCE = '9610919d29010d53cf00af3b7c38207ffd84f945'
TREE = '3d5e2965ef26235610a08fd8378cac078c6bd9a0'
BASE = 'd60ac40daf767fe6a93ae152feb21235f6e75e0b'
BASE_TREE = '4a07cd88ded407bef30a8aeb81961e4041822dc2'
OLD_MAIN = '3a16290c0fcc4e0c21712fe10474a3ff33fad336'
MERGE = 'ea16019601486c831941f9bc1a7ba5862a170317'
ROWS = []

def check(label, okay, detail=None):
    row = {'label': label, 'passed': bool(okay)}
    if detail is not None:
        row['detail'] = detail
    ROWS.append(row)
    if not okay:
        raise AssertionError(label)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def assigned(node, name):
    return isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == name for t in node.targets)

def main():
    helper = ROOT / 'assemble_network_recovery_records.py'
    raw = helper.read_bytes()
    check('Corrected helper exact frozen SHA', sha256(raw).hexdigest() == '65f53340375845bf4d473a7343a97f908448dbbf2aacc7f0e37b7569b2ecad05')
    snapshot = OUT / 'corrected-assemble_network_recovery_records.py'
    snapshot.write_bytes(raw)
    parsed = ast.parse(raw)
    declarations = [n for n in parsed.body if isinstance(n, (ast.Import, ast.ImportFrom, ast.Assign)) or (isinstance(n, ast.FunctionDef) and n.name in ['check', 'sha', 'encode'])]
    constants = {'__file__': str(snapshot)}
    exec(compile(ast.fix_missing_locations(ast.Module(body=declarations, type_ignores=[])), str(snapshot), 'exec'), constants)
    body = next(n for n in parsed.body if isinstance(n, ast.FunctionDef) and n.name == 'main').body
    index = lambda name: next(i for i, n in enumerate(body) if assigned(n, name))
    compile_part = lambda items: compile(ast.fix_missing_locations(ast.Module(body=items, type_ignores=[])), str(snapshot), 'exec')
    promotion_code = compile_part(body[index('promotion'):index('qualification')])
    sig_start = next(i for i, n in enumerate(body) if isinstance(n, ast.Expr) and isinstance(n.value, ast.Call) and any(isinstance(v, ast.Constant) and v.value == 'Exact final Sigstore source and tree required' for v in n.value.args))
    sig_code = compile_part(body[sig_start:index('original_raw')])
    ledger_nodes = body[index('original_raw'):index('report')]
    ledger_code = compile_part(ledger_nodes)
    branch = git('branch', '--show-current').decode().strip()
    promotion = {'merged': True, 'pr_number': 357, 'source_head': BASE, 'source_tree': BASE_TREE, 'all_applicable_automated_jobs_passed': True, 'opt_outs_verified': True, 'merge_commit': MERGE, 'actual_parents': [OLD_MAIN, BASE], 'actual_tree': BASE_TREE}

    def execute(code, context, **overrides):
        scope = dict(constants)
        scope.update(repo=REPO, git=git, context=context, source=SOURCE, tree=TREE, branch=branch, raw_context=json.dumps(context).encode(), promotion=deepcopy(promotion), qualification={'source': SOURCE, 'tree': TREE, 'details': []})
        scope.update(overrides)
        exec(code, scope)
        return scope

    def rejection(label, code, context, **kwargs):
        try:
            execute(code, context, **kwargs)
        except (RuntimeError, KeyError, TypeError) as exc:
            check(label, True, f'{type(exc).__name__}: {exc}')
        else:
            check(label, False, 'Unexpected acceptance')

    execute(promotion_code, {'actual_pr357_promotion': deepcopy(promotion)})
    check('Accept actual literal full SHA with exact parents/tree/markers', True)
    ledger_oid = git('rev-parse', SOURCE + ':docs/engineering/task-ledger.json').decode().strip()
    for label, value in [('revision expression', MERGE + '^0'), ('uppercase SHA', MERGE.upper()), ('terminal LF', MERGE + '\n'), ('abbreviation', MERGE[:12]), ('missing identity', None), ('tree object', BASE_TREE), ('blob object', ledger_oid)]:
        p = deepcopy(promotion); p['merge_commit'] = value
        rejection('Reject nonliteral/noncommit ' + label, promotion_code, {'actual_pr357_promotion': p})
    for label, patch in [('wrong parents', {'actual_parents': [BASE, OLD_MAIN]}), ('wrong tree', {'actual_tree': TREE}), ('unmerged state', {'merged': False}), ('wrong PR', {'pr_number': 356}), ('incomplete qualification', {'all_applicable_automated_jobs_passed': False})]:
        p = deepcopy(promotion); p.update(patch)
        rejection('Reject promotion ' + label, promotion_code, {'actual_pr357_promotion': p})
    valid_sig = {'sigstore_source': SOURCE, 'independent_sigstore_review': {'source': SOURCE, 'tree': TREE, 'verdict': 'CLEAR', 'blockers': []}}
    execute(sig_code, deepcopy(valid_sig))
    check('Accept exact mandatory Sigstore review', True)
    rejection('Reject absent Sigstore fields', sig_code, {})
    for label, patch in [('wrong source', {'source': BASE}), ('wrong tree', {'tree': BASE_TREE}), ('non-clear review', {'verdict': 'BLOCKED'})]:
        value = deepcopy(valid_sig); value['independent_sigstore_review'].update(patch)
        rejection('Reject Sigstore ' + label, sig_code, value)
    rejection('Reject wrong current source', sig_code, deepcopy(valid_sig), source=BASE)
    rejection('Reject wrong current tree', sig_code, deepcopy(valid_sig), tree=BASE_TREE)
    value = deepcopy(valid_sig); value['sigstore_source'] = BASE
    rejection('Reject wrong Sigstore context identity', sig_code, value)

    raw_ledger = git('show', SOURCE + ':docs/engineering/task-ledger.json')
    original = json.loads(raw_ledger)
    added = {k: 'INDEPENDENT MEMORY CONTROL ONLY' for k in constants['REQUIRED']}
    added.update(id='independent-in-memory-control-only', status='TESTING', target_integration_branch=branch, blockers=[], evidence_links=[])
    context = {'task_updates': [{'id': original['tasks'][0]['id'], 'before': deepcopy(original['tasks'][0]), 'patch': {'status': 'TESTING', 'evidence_links': ['in-memory-only']}}], 'additional_tasks': [added], 'new_task_ids': [added['id']], 'remote_publication': {'status': 'MEMORY CONTROL ONLY'}, 'continuation': {'status': 'MEMORY CONTROL ONLY'}, 'network_recovery': {'status': 'MEMORY CONTROL ONLY'}, 'windows_recovery_update': {'before': deepcopy(original['windows_recovery_837fe']), 'patch': {'status': 'MERGED', 'source_commit': BASE, 'source_tree': BASE_TREE, 'qualification': {'actual_main': MERGE, 'source': BASE}}}}
    value = deepcopy(context)
    result = execute(ledger_code, value)
    ledger = result['ledger']
    check('Original full ledger not mutated', result['original'] == original)
    check('All 116 prior task IDs/order preserved', [x['id'] for x in ledger['tasks'][:116]] == [x['id'] for x in original['tasks']])
    check('Exactly one memory-only addition', len(ledger['tasks']) == 117 and ledger['tasks'][-1] == added)
    check('All 46 notes preserved', ledger['notes'] == original['notes'] and len(ledger['notes']) == 46)
    check('All 115 unmodified prior rows exact', ledger['tasks'][1:116] == original['tasks'][1:])
    check('Whole modified-task before image retained', ledger['continuation_history'][-1]['changed_tasks_before'] == [original['tasks'][0]])
    check('Entire prior continuation history retained', ledger['continuation_history'][:-1] == original['continuation_history'])
    check('All prior current fields retained', ledger['continuation_history'][-1]['prior_current_fields'] == {k: original[k] for k in constants['CURRENT'] if k in original})
    check('Entire original Windows checkpoint retained', ledger['continuation_history'][-1]['prior_windows_recovery_837fe'] == original['windows_recovery_837fe'])
    check('Current Windows status binds actual qualified d60', all(ledger['windows_recovery_837fe'][k] == v for k, v in context['windows_recovery_update']['patch'].items()))
    changed = set(constants['CURRENT']) | {'tasks', 'continuation_history', 'pr357_main_promotion_837fe', 'network_recovery_837fe', 'windows_recovery_837fe'}
    check('All other original top-level objects preserved', all(ledger[k] == v for k, v in original.items() if k not in changed))
    check('Current candidate merge/release flags remain false', ledger['main_merge_eligible'] is False and ledger['release_ready'] is False)
    check('Original context unmutated', value == context)
    ledger['tasks'][0]['evidence_links'].append('changed only output')
    ledger['tasks'][-1]['evidence_links'].append('changed only output')
    ledger['current_qualification']['details'].append('changed only output')
    ledger['continuation_history'][-1]['changed_tasks_before'][0]['status'] = 'MEMORY'
    ledger['continuation_history'][-1]['prior_windows_recovery_837fe']['status'] = 'MEMORY'
    ledger['windows_recovery_837fe']['qualification']['actual_main'] = 'MEMORY'
    ledger['notes'].append('changed only output')
    check('Modified task, additions and histories all deep copied', value == context and result['original'] == original and result['qualification']['details'] == [])
    check('Original raw ledger emitted byte-exact', result['outputs'][constants['E'] / 'prior-ledger-d60.json'] == raw_ledger)
    check('Extracted transformation contains no file or ref writers', all(not isinstance(n, ast.Call) or not isinstance(n.func, ast.Attribute) or n.func.attr not in ['write_bytes', 'write_text', 'mkdir', 'unlink', 'rename', 'replace'] for s in ledger_nodes for n in ast.walk(s)))
    mutations = {
        'duplicate update': lambda c: c['task_updates'].append(deepcopy(c['task_updates'][0])),
        'unknown original task': lambda c: c['task_updates'][0].update(id='nonexistent'),
        'mismatched full before row': lambda c: c['task_updates'][0]['before'].update(description='different'),
        'original task ID patch': lambda c: c['task_updates'][0]['patch'].update(id='different'),
        'invalid patched state': lambda c: c['task_updates'][0]['patch'].update(status='NEARLY-DONE'),
        'duplicate new task': lambda c: (c['additional_tasks'].append(deepcopy(c['additional_tasks'][0])), c['new_task_ids'].append(c['new_task_ids'][0])),
        'new ID collides with original': lambda c: (c['additional_tasks'][0].update(id=original['tasks'][0]['id']), c.update(new_task_ids=[original['tasks'][0]['id']])),
        'new order mismatch': lambda c: c.update(new_task_ids=['wrong']),
        'missing required new field': lambda c: c['additional_tasks'][0].pop('next_action'),
        'invalid new state': lambda c: c['additional_tasks'][0].update(status='NEARLY-DONE'),
        'wrong new task branch': lambda c: c['additional_tasks'][0].update(target_integration_branch='other'),
        'wrong whole Windows before snapshot': lambda c: c['windows_recovery_update']['before'].update(status='different'),
        'wrong Windows promoted state': lambda c: c['windows_recovery_update']['patch'].update(status='TESTING'),
        'wrong Windows promoted source': lambda c: c['windows_recovery_update']['patch'].update(source_commit=SOURCE),
        'wrong Windows promoted tree': lambda c: c['windows_recovery_update']['patch'].update(source_tree=TREE),
    }
    for label, mutate in mutations.items():
        value = deepcopy(context); mutate(value)
        rejection('Reject ledger ' + label, ledger_code, value)
    check('Source stayed clean and exact', git('rev-parse', 'HEAD').decode().strip() == SOURCE and not git('status', '--porcelain=v1').strip())
    check('Corrected helper unchanged during controls', helper.read_bytes() == raw)
    (OUT / 'context-builder-preparation.py').write_bytes((ROOT / 'build_network_recovery_context.py').read_bytes())

try:
    main()
finally:
    result = {'scope': 'PREPARATION ONLY: extracted actual helper statements, read-only Git and memory-only synthetic task data; main never invoked; no product tests or repository writes.', 'helper_sha256': '65f53340375845bf4d473a7343a97f908448dbbf2aacc7f0e37b7569b2ecad05', 'checks': ROWS, 'passed': sum(r['passed'] for r in ROWS), 'failed': sum(not r['passed'] for r in ROWS)}
    (OUT / 'corrected-helper-controls.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'passed': result['passed'], 'failed': result['failed']}))
