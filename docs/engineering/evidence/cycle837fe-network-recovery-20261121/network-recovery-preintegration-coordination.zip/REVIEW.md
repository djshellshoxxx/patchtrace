# Network recovery — preintegration coordination

**No requested head changed, and no new visible ownership statement prohibits root-owned isolated integration. All draft, qualification and main-merge holds remain intact.** Observation cut: **2026-11-21 14:06:13 UTC**. This is metadata/path/ancestry review, not independent source qualification or authority to merge an unqualified head.

| PR | Exact head | Reported PR base SHA | State |
|---|---|---|---|
| 352 | `e3928ab8c8e2deee7bb01b0f857205f68a1abda2` | `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4` | Non-draft / open |
| 353 | `d0a4bdf439775999340ea760d96a087e032ee6dd` | `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4` | Non-draft / open |
| 354 | `a41c7a0d594d1fe26c16da395e6f6f9b33b07eca` | `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4` | Draft / open |
| 355 | `e2127864cb481026db0157082d688b8a36595e3b` | `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4` | Draft / open |
| 356 | `1d475d926314ae116442bfe2b7cd268ad95ea12c` | `a41c7a0d594d1fe26c16da395e6f6f9b33b07eca` | Draft / open |
| 357 | `d60ac40daf767fe6a93ae152feb21235f6e75e0b` | `3a16290c0fcc4e0c21712fe10474a3ff33fad336` | Non-draft / open |

The actual live `main` ref is `3a16290c0fcc4e0c21712fe10474a3ff33fad336`. PR352–355 still report902 as their base SHA with `base.ref=main`; this report preserves those API values separately from the current live main ref. PR356 remains stacked on the354 branch. Final direct Git-ref GETs confirm every head and main still match the initial metadata reads.

## Discussions and ownership

All six PRs have **zero issue comments, zero submitted reviews and zero inline review comments** in complete fresh listings. There are no visible inline review threads to reconcile, and no pagination was needed. No external author was messaged. The absence claim covers captured repository metadata only.

PR352 and353 retain their original authoring-time unverified qualification statements. PR354,355 and356 remain drafts. Their required full/hosted qualification, independent review, current-head checks and ownership reconciliation are not waived by local reviews or by private import. PR356 specifically retains its parent354 qualification and later main-reconciliation conditions. Importing the full existing356 ancestry into an owned branch is not merging either draft to main or changing those PRs.

PR357's published body records Root837FE ownership through **17:00 UTC**, while this assignment records **16:30 UTC**. Both are later than the observation cut; this report does not extend the task's authority. No other captured PR body or discussion declares a new active timed lease prohibiting the proposed private work. Missing qualification is not treated as an indefinite exclusive lease.

## Integration order and path preservation

1. Start a separate owned integration from frozen `d60ac40d`; keep PR357 and its running qualification unchanged.
2. Import exact356. Its ancestry already retains all six354 commits plus four356 commits. Preserve both NET finding records and the complete `findings.json` index.
3. Import exact `aa01a50844fed15823c6e03491ce3bc671a5ecfc`. It retains the five352 commits plus the completion repair. Although its files do not overlap356's, enrichment uses the shared helper, so the actual new combined tree requires consumer tests.
4. Import exact353 and355 histories. Their runtime files are distinct from these other changes.
5. Preserve all current d60 and donor QA/todo content during record reconciliation. The concrete overlap among aa01,353 and d60 is **`docs/qa.md` and `tasks/todo.md`**. Full356 has no changed-path overlap with d60,353 or355. The354 and356 versions of `netutil.py` and `findings.json` are already ordered within356; this inventory does not show an additional findings-index conflict against the other imports. Any new local clarification must retain existing entries.
6. Qualify the resulting exact source, retain author holds, and refresh main/heads/ownership/checks before guarded main promotion or later metadata reconciliation. Do not transfer PR357's results to the combined source.

The complete path lists and merge-base proofs are in `path-and-ancestry-review.json`. Current main is already an ancestor ofd60; aa01 and356 share902 as their merge base. No code, records, refs, PRs or CI were modified, and no tests were run by this coordination pass.
