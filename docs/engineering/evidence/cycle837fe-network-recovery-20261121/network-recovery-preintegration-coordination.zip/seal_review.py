"""Seal fresh read-only coordination metadata, path intersections and ancestry."""
import hashlib
import json
import zipfile
from pathlib import Path

OUT=Path('/workspace/scratch/837fe19aae3a/evidence/network-recovery-preintegration-coordination')
expected={352:'e3928ab8c8e2deee7bb01b0f857205f68a1abda2',353:'d0a4bdf439775999340ea760d96a087e032ee6dd',354:'a41c7a0d594d1fe26c16da395e6f6f9b33b07eca',355:'e2127864cb481026db0157082d688b8a36595e3b',356:'1d475d926314ae116442bfe2b7cd268ad95ea12c',357:'d60ac40daf767fe6a93ae152feb21235f6e75e0b'}
main='3a16290c0fcc4e0c21712fe10474a3ff33fad336';base='9023761a4066ac1c50c127ac09d0ba5f56cdc9e4'
checks=[]

def read(n):return json.loads((OUT/n).read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def check(label,condition):
    assert condition,label
    checks.append(label)

rows=[]
for n,head in expected.items():
    pr=read(f'pr-{n}.json');ref=read(f'final-ref-pr-{n}.json')
    check(f'{n} exact initial and final live head',pr['head']['sha']==head and ref['object']['sha']==head)
    check(f'{n} still open unmerged',pr['state']=='open' and not pr['merged'])
    check(f'{n} exact draft state',pr['draft']==(n in (354,355,356)))
    expbase=expected[354] if n==356 else main if n==357 else base
    check(f'{n} exact reported PR base',pr['base']['sha']==expbase)
    counts={}
    for kind in ('issue-comments','reviews','review-comments'):
        data=read(f'pr-{n}-{kind}.json')
        check(f'{n} {kind} empty and unpaginated',isinstance(data,list) and len(data)==0)
        counts[kind]=len(data)
    if n<357:
        data=read(f'pr-{n}-files.json')
        check(f'{n} complete bounded changed-file listing',len(data)==pr['changed_files'] and len(data)<100)
    rows.append({'number':n,'head':head,'head_ref':pr['head']['ref'],'reported_base':pr['base']['sha'],'base_ref':pr['base']['ref'],'state':pr['state'],'draft':pr['draft'],'merged':pr['merged'],'author':pr['user']['login'],'author_body_updated_at':pr['updated_at'],'discussion_counts':counts,'body_evidence':f'pr-{n}.json'})
check('main unchanged across initial and final GET',read('main.json')['object']['sha']==read('final-main-ref.json')['object']['sha']==main)
path=read('path-and-ancestry-review.json');ancestry=path['ancestry']
check('354 fully retained through356',ancestry['354_is_356_ancestor'] and ancestry['354_356_merge_base']==expected[354] and ancestry['356_commits_from902']==10)
check('352 fully retained throughaa01',ancestry['352_is_aa01_ancestor'] and ancestry['aa01_commits_from902']==6)
check('current main already in frozen d60 ancestry',ancestry['current_main_is_d60_ancestor'])
check('aa01 and356 have common902base',ancestry['aa01_356_merge_base']==base)
check('record conflict surface353andaa01',path['intersections']['aa01_full_from902 vs 353']==['docs/qa.md','tasks/todo.md'])
check('record conflict surface incoming branches vsd60',path['intersections']['aa01_full_from902 vs d60_from902']==path['intersections']['353 vs d60_from902']==['docs/qa.md','tasks/todo.md'])
check('356and355 no same-path intersections with d60 or each other',path['intersections']['356_full_from902 vs d60_from902']==path['intersections']['355 vs d60_from902']==path['intersections']['356_full_from902 vs 355']==[])
hold_text={352:'Qualification status — NOT YET VERIFIED',353:'Current qualification — NOT VERIFIED',354:'Remaining gates — keep as draft',355:'Merge hold (draft)',356:'Qualify parent #354 first.',357:'Root837FE owns this integration through2026-11-21T17:00:00Z'}
for n,text in hold_text.items():check(f'{n} captured hold/ownership wording',text in read(f'pr-{n}.json')['body'])
cut=read('observation-cut.json')['current_time']
review={'schema':'patchtrace/network-recovery-preintegration-coordination/1','observed_through':cut,'scope':'Read-only visible GitHub PR/ref/discussion metadata plus exact local path/ancestry comparison. Not source qualification or main-merge approval.','verdict':'NO_CHANGED_HEAD_OR_NEW_VISIBLE_OWNERSHIP_PROHIBITION_TO_PRIVATE_INTEGRATION','changed_heads':[],'current_main':main,'frozen_PR357':expected[357],'PRs':rows,'discussion_summary':{'PRs':6,'issue_comments':0,'submitted_reviews':0,'inline_review_comments':0,'visible_inline_threads':0,'pagination_needed':False},'ownership':{'new_visible_prohibition_on_root_owned_isolated_integration':False,'scope_of_absence_claim':'Captured public repository bodies, issue comments, submitted reviews and inline comments only; no assertion about unseen private communication.','PR357_public_lease':'2026-11-21T17:00:00Z or explicit earlier handoff','current_root_task_lease':'2026-11-21T16:30:00Z','lease_difference_disclosed':True,'review_does_not_extend_authority':True,'other_PRs_no_explicit_active_timed_lease_found':True,'qualification_or_draft_hold_is_not_inferred_as_an_indefinite_exclusive_lease':True},'holds_preserved':{'352':'Authoring-time NOT YET VERIFIED statement and required exact-head/full/hosted qualification; separate root integration untouched.','353':'Authoring-time NOT VERIFIED statement, independent/current-head qualification and no blocking findings; separate PR352/root integration maintained.','354':'Keep draft; exact-head Linux/Windows/full/Ruff/independent review and fresh integration ownership reconciliation; no merge until qualified.','355':'Draft merge hold for hosted/full/Ruff/independent review and live main/head/protection/ownership reconciliation.','356':'Draft stacked on354; parent qualification and later main reconciliation/final-head verification; coordinate with active integration owner; neither PR merged unqualified.','357':'Current root integration frozen atd60; exact final-source hosted gates remain pending; no source modification during qualification.'},'path_and_ancestry':path,'recommended_private_integration_order':[{'step':1,'action':'Create owned isolated integration from exact frozen d60; leave PR357 source/ref and running qualification unchanged.'},{'step':2,'action':'Import exact356, retaining its six354 and four356 commits; preserve both NET findings and their findings.json index.'},{'step':3,'action':'Import exactaa01 child, retaining five352 commits plus its completion admission repair; validate enrichment against the actual356 helper in the new tree.'},{'step':4,'action':'Import exact353 and355 source histories; their runtime files are distinct. Preserve all donor QA/todo appendices and existing d60 prefixes/histories.'},{'step':5,'action':'Resolve records additively; keep findings.json complete. No current same-path conflict in findings.json against d60/353/355 is shown by this inventory; the354/356 versions are already stacked in356.'},{'step':6,'action':'Qualify the actual integrated head and applicable full/hosted/platform gates. Refresh heads/main/ownership/checks before any guarded main promotion or later PR metadata reconciliation.'}],'runtime_coupling':'Enrichment and other consumers call the shared netutil helper despite different source paths; absence of textual overlap is not integration acceptance.','new_product_tests':0,'source_ref_PR_CI_mutations':False,'external_author_messages_sent':False,'independent_source_qualification_claimed':False,'authors_holds_waived':False,'main_merge_approved':False,'mechanical_checks':len(checks),'checks':checks}
(OUT/'review.json').write_text(json.dumps(review,indent=2)+'\n')
table='\n'.join(f"| {r['number']} | `{r['head']}` | `{r['reported_base']}` | {'Draft' if r['draft'] else 'Non-draft'} / open |" for r in rows)
(OUT/'REVIEW.md').write_text(f'''# Network recovery — preintegration coordination

**No requested head changed, and no new visible ownership statement prohibits root-owned isolated integration. All draft, qualification and main-merge holds remain intact.** Observation cut: **{cut}**. This is metadata/path/ancestry review, not independent source qualification or authority to merge an unqualified head.

| PR | Exact head | Reported PR base SHA | State |
|---|---|---|---|
{table}

The actual live `main` ref is `{main}`. PR352–355 still report902 as their base SHA with `base.ref=main`; this report preserves those API values separately from the current live main ref. PR356 remains stacked on the354 branch. Final direct Git-ref GETs confirm every head and main still match the initial metadata reads.

## Discussions and ownership

All six PRs have **zero issue comments, zero submitted reviews and zero inline review comments** in complete fresh listings. There are no visible inline review threads to reconcile, and no pagination was needed. No external author was messaged. The absence claim covers captured repository metadata only.

PR352 and353 retain their original authoring-time unverified qualification statements. PR354,355 and356 remain drafts. Their required full/hosted qualification, independent review, current-head checks and ownership reconciliation are not waived by local reviews or by private import. PR356 specifically retains its parent354 qualification and later main-reconciliation conditions. Importing the full existing356 ancestry into an owned branch is not merging either draft to main or changing those PRs.

PR357's published body records Root837FE ownership through **17:00 UTC**, while this assignment records **16:30 UTC**. Both are later than the observation cut; this report does not extend the task's authority. No other captured PR body or discussion declares a new active timed lease prohibiting the proposed private work. Missing qualification is not treated as an indefinite exclusive lease.

## Integration order and path preservation

1. Start a separate owned integration from frozen `d60ac40d`; keep PR357 and its running qualification unchanged.
2. Import exact356. Its ancestry already retains all six354 commits plus four356 commits. Preserve both NET finding records and the complete `findings.json` index.
3. Import exact `aa01a50844fed15823c6e03491ce3bc671a5ecfc`. It retains the five352 commits plus the completion repair. Although its files do not overlap356's, enrichment uses the shared helper, so the actual new combined tree requires consumer tests.
4. Import exact353 and355 histories. Their runtime files are distinct from these other changes.
5. Preserve all current d60 and donor QA/todo content during record reconciliation. The concrete overlap among aa01,353 and d60 is **`docs/qa.md` and `tasks/todo.md`**. Full356 has no changed-path overlap with d60,353 or355. The354 and356 versions of `netutil.py` and `findings.json` are already ordered within356; this inventory does not show an additional findings-index conflict against the other imports. Any new local clarification must retain existing entries.
6. Qualify the resulting exact source, retain author holds, and refresh main/heads/ownership/checks before guarded main promotion or later metadata reconciliation. Do not transfer PR357's results to the combined source.

The complete path lists and merge-base proofs are in `path-and-ancestry-review.json`. Current main is already an ancestor ofd60; aa01 and356 share902 as their merge base. No code, records, refs, PRs or CI were modified, and no tests were run by this coordination pass.
''')
files=sorted(x for x in OUT.iterdir() if x.is_file());rows=[{'path':x.name,'bytes':x.stat().st_size,'sha256':sha(x.read_bytes())} for x in files]
mf=OUT/'evidence-manifest.json';mf.write_text(json.dumps({'schema':'patchtrace/evidence-manifest/1','files':rows,'lists_itself':False},indent=2)+'\n')
archive=OUT/'network-recovery-preintegration-coordination.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[mf]:z.write(p,p.name)
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in rows:assert sha(z.read(row['path']))==row['sha256']
receipt={'archive_file':archive.name,'archive_bytes':archive.stat().st_size,'archive_members':len(rows)+1,'archive_sha256':sha(archive.read_bytes()),'manifest_sha256':sha(mf.read_bytes()),'review_sha256':sha((OUT/'review.json').read_bytes()),'mechanical_checks':len(checks),'CRC_and_all_member_hashes_verified':True}
(OUT/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
