"""Apply only the owned local exact-segment evidence transport revision."""
from pathlib import Path
from io import BytesIO
from copy import deepcopy
import datetime, hashlib, json, shutil, subprocess, sys, traceback, zipfile
ROOT=Path(__file__).resolve().parent; REPO=ROOT/'PatchTrace-network-recovery-followup'
REL=Path('docs/engineering/evidence/cycle837fe-network-recovery-20261121'); E=REPO/REL
OUT=ROOT/'evidence/network-record-transport-repair'
LEDGER=Path('docs/engineering/task-ledger.json'); REPORT=Path('docs/engineering/cycle837fe-network-recovery-20261121.md')
OLD_NAME='sigstore-tooling-hash-closure-independent.zip'; INDEX_NAME='sigstore-tooling-archive-parts.json'
HELPER_NAME='reassemble-sigstore-evidence.py'; ARCHIVE_NAME='record-transport-repair.zip'; PROOF_NAME='record-transport-repair-proof.json'
SOURCE='9610919d29010d53cf00af3b7c38207ffd84f945'; TREE='3d5e2965ef26235610a08fd8378cac078c6bd9a0'
ORIGINAL_SHA='81a7e43597b9100c7b41a0a4ebcb477db8511d7f222a589faa1e5821140959b3'
RECEIPT_SHA='07d811e45bb15b0e1b21a5660ffdab4badc6fef7ae2502cc775e5ba96676941c'
checks=[]; commands=[]; events=[]
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(data):return hashlib.sha256(data).hexdigest()
def blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def encode(value):return (json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode()
def check(ok,name,detail=None):
    checks.append({'name':name,'passed':bool(ok),'detail':detail})
    if not ok:raise RuntimeError(name)
def git(*args):
    argv=['git','--no-optional-locks','-c','core.fsmonitor=false',*args]
    p=subprocess.run(argv,cwd=REPO,capture_output=True,check=False)
    commands.append({'argv':argv,'cwd':str(REPO),'exit_code':p.returncode,'stdout_sha256':sha(p.stdout),'stdout':p.stdout.decode() if len(p.stdout)<3000 else None,'stderr':p.stderr.decode(),'recorded_at':now()})
    check(p.returncode==0,'read-only Git command completed',args);return p.stdout
def verify_helper(directory,name):
    argv=[sys.executable,str(directory/HELPER_NAME),'--verify-only'];p=subprocess.run(argv,cwd=directory,capture_output=True,text=True,check=False)
    receipt={'argv':argv,'cwd':str(directory),'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr,'helper_sha256':sha((directory/HELPER_NAME).read_bytes()),'recorded_at':now()}
    (OUT/name).write_bytes(encode(receipt));check(p.returncode==0,'actual helper verifies without output creation',str(directory))
    check(json.loads(p.stdout)=={'verified':True,'bytes':16865753,'sha256':ORIGINAL_SHA,'members':145,'output':None},'actual helper returns original archive identity')

def main():
    check(git('rev-parse','HEAD','HEAD^{tree}').decode().splitlines()==[SOURCE,TREE],'exact frozen source/tree')
    receipt_path=ROOT/'evidence/network-record-assembly/assembly-receipt.json';receipt_raw=receipt_path.read_bytes()
    check(sha(receipt_raw)==RECEIPT_SHA,'pinned original assembly receipt');receipt=json.loads(receipt_raw)
    check(len(receipt['outputs'])==67 and sum(r['bytes'] for r in receipt['outputs'])==50012691,'original 67 outputs/50,012,691 bytes')
    originals={}
    for row in receipt['outputs']:
        path=Path(row['path']);data=(REPO/path).read_bytes()
        check(len(data)==row['bytes'] and sha(data)==row['sha256'] and blob(data)==row['git_blob'],'before identity: '+row['path']);originals[path]=data
    check(len(originals)==67 and not OUT.exists(),'67 unique outputs; new repair directory unused');OUT.mkdir();before=OUT/'before';before.mkdir()
    v4_path=ROOT/'evidence/network-record-preparation/static-inputs-v4.json';v4_raw=v4_path.read_bytes();v4=json.loads(v4_raw)
    context=json.loads(originals[REL/'assembly-context.json']);ledger=json.loads(originals[LEDGER])
    check(context['static_inputs']==v4['inputs'] and len(v4['inputs'])==57,'v4 equals original 57 context inputs')
    protected={}
    for row in v4['inputs']:
        path=Path(row['source_path']);data=path.read_bytes()
        check(len(data)==row['bytes'] and sha(data)==row['sha256'] and blob(data)==row['git_blob'],'original static input: '+row['name'])
        protected[str(path)]={'bytes':len(data),'sha256':sha(data)}
    source_archive=ROOT/'evidence/sigstore-tooling-hash-closure-independent'/OLD_NAME;source_seal=source_archive.parent/'archive-receipt.json'
    historical_seal=ROOT/'evidence/historical-ghidra-dotpaths-independent/archive-receipt.json'
    for path in (v4_path,receipt_path,source_archive,source_seal,historical_seal):
        data=path.read_bytes();protected[str(path)]={'bytes':len(data),'sha256':sha(data)}
    copies={'assembly-receipt.json':receipt_raw,'assembly-context.json':originals[REL/'assembly-context.json'],'manifest.json':originals[REL/'manifest.json'],'task-ledger.json':originals[LEDGER],'report.md':originals[REPORT],'preservation.json':originals[REL/'preservation.json'],'static-inputs-v4.json':v4_raw,'original-sigstore-archive-receipt.json':source_seal.read_bytes()}
    for name,data in copies.items():(before/name).write_bytes(data)
    status_before=git('status','--porcelain=v1').decode()
    check(not git('diff','--name-only','HEAD','--','src','tests','tools','.github').strip(),'runtime/tests/tools/workflows match frozen HEAD')
    error={'recorded_at':now(),'reported_by':'root','operation':'create_blob base64 original Sigstore independent ZIP','original_bytes':16865753,'original_sha256':ORIGINAL_SHA,'error_verbatim':'HTTP 400: {"detail":"MCP request body is invalid or exceeds the 16 MiB limit"}','successful_static_blobs_before':40,'ref_or_PR_changed':False,'same_oversized_payload_retried':False,'peer_performed_remote_call':False}
    (OUT/'transport-error.json').write_bytes(encode(error));original=originals[REL/OLD_NAME]
    check(len(original)==16865753 and sha(original)==ORIGINAL_SHA and original==source_archive.read_bytes(),'unchanged original archive identity')
    parts=[]
    for number,(start,end) in enumerate(((0,9999999),(9999999,len(original))),1):
        data=original[start:end];name=f'sigstore-independent.zip.part{number:02d}';(OUT/name).write_bytes(data)
        parts.append({'name':name,'offset':start,'bytes':len(data),'sha256':sha(data),'git_blob':blob(data),'base64_offset':(start//3)*4,'base64_bytes':((len(data)+2)//3)*4})
    check(parts[0]['bytes']%3==0 and [p['bytes'] for p in parts]==[9999999,6865754],'exact split and reusable base64 boundary')
    check(b''.join((OUT/p['name']).read_bytes() for p in parts)==original,'concatenation equals original bytes')
    with zipfile.ZipFile(BytesIO(original)) as z:check(len(z.namelist())==len(set(z.namelist()))==145 and z.testzip() is None,'all 145 original members/CRCs verified')
    index={'schema':'patchtrace/split-evidence-archive/1','original_archive_name':OLD_NAME,'original_archive_bytes':len(original),'original_archive_sha256':ORIGINAL_SHA,'original_archive_members':145,'parts':parts,'reassemble_with':HELPER_NAME,'reason':'Base64 request exceeded the 16 MiB transport limit; exact segments preserve sealed bytes without repacking.','original_archive_unchanged':True}
    (OUT/INDEX_NAME).write_bytes(encode(index));shutil.copyfile(ROOT/'reassemble_sigstore_evidence.py',OUT/HELPER_NAME);shutil.copyfile(__file__,OUT/'repair-driver.py')
    verify_helper(OUT,'reassembly-verification-before.json')
    old_link=(REL/OLD_NAME).as_posix();new_link=(REL/INDEX_NAME).as_posix()
    lm=[(i,j) for i,t in enumerate(ledger['tasks']) for j,x in enumerate(t.get('evidence_links',[])) if x==old_link]
    cm=[(i,j) for i,t in enumerate(context['additional_tasks']) for j,x in enumerate(t.get('evidence_links',[])) if x==old_link]
    check(lm==[(124,0)] and cm==[(8,0)],'only expected exact ledger/context evidence links selected')
    ids=[t['id'] for t in ledger['tasks']]
    check(len(ids)==len(set(ids))==130 and len(ledger['notes'])==46,'130 task IDs and 46 notes')
    baseline_raw=git('show',SOURCE+':'+LEDGER.as_posix());check(baseline_raw==originals[REL/'prior-ledger-d60.json'],'prior ledger remains exact frozen bytes')
    baseline=json.loads(baseline_raw);by_id={t['id']:t for t in baseline['tasks']}
    check(len(baseline['tasks'])==116 and len(baseline['notes'])==46 and ids[:116]==[t['id'] for t in baseline['tasks']] and ledger['notes']==baseline['notes'],'116 baseline task IDs/order and original notes retained')
    check(all(u['before']==by_id[u['id']] for u in context['task_updates']),'all deep task before-images match baseline')
    changed_ids={u['id'] for u in context['task_updates']}
    check(all(t==by_id[t['id']] for t in ledger['tasks'][:116] if t['id'] not in changed_ids),'all 111 untouched baseline rows deep-equal')
    check(ledger['continuation_history'][-1]['changed_tasks_before']==[u['before'] for u in context['task_updates']],'deep before-images retained in continuation history')
    preflight={'schema':'patchtrace/network-record-transport-preflight/1','source':SOURCE,'tree':TREE,'original_assembly_receipt_sha256':RECEIPT_SHA,'original_outputs':67,'original_total_bytes':50012691,'original_static_plan_sha256':sha(v4_raw),'original_context_sha256':sha(copies['assembly-context.json']),'original_report_sha256':sha(copies['report.md']),'original_ledger_sha256':sha(copies['task-ledger.json']),'parts':parts,'ledger_leaf':['tasks',124,'evidence_links',0],'context_leaf':['additional_tasks',8,'evidence_links',0],'old_link':old_link,'new_link':new_link,'expected_outputs_after':72,'runtime_unchanged':True,'product_tests_executed':0,'prior_history_unchanged':True,'new_historical_review_incorporated':False,'preflight_checks':deepcopy(checks),'protected_inputs':protected}
    (OUT/'preflight.json').write_bytes(encode(preflight))
    (OUT/'discovery-probes.json').write_bytes(encode({'probes':[{'probe':'broad rg filename listing','exit_code':0,'display':'Truncated; repeated using exact preparation directory and v4 plan.','used_as_complete_evidence':False},{'probe':'initial helper replacement via apply_patch','result':'Rejected before write: invalid patch: multiple operations target the same path.','candidate_mutation':False,'resolution':'Wrote only the owned helper using one replacement operation.'}],'product_tests_executed':0,'remote_retries':0}))
    archive_inputs={str(p.relative_to(OUT)):p for p in sorted(before.iterdir())}
    for name in ('transport-error.json','preflight.json','discovery-probes.json','repair-driver.py',HELPER_NAME,INDEX_NAME,'reassembly-verification-before.json'):archive_inputs[name]=OUT/name
    archive_manifest={'schema':'patchtrace/transport-repair-archive-manifest/1','files':[{'path':name,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for name,p in sorted(archive_inputs.items())]}
    (OUT/'repair-archive-manifest.json').write_bytes(encode(archive_manifest))
    with zipfile.ZipFile(OUT/ARCHIVE_NAME,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name,p in sorted(archive_inputs.items()):z.write(p,name)
        z.writestr('repair-archive-manifest.json',encode(archive_manifest))
    with zipfile.ZipFile(OUT/ARCHIVE_NAME) as z:
        check(z.testzip() is None and len(z.namelist())==len(archive_inputs)+1,'small repair archive CRC/member check')
        check(all(sha(z.read(r['path']))==r['sha256'] and len(z.read(r['path']))==r['bytes'] for r in archive_manifest['files']),'original assembly snapshots and transport error preserved in repair archive')
    new_inputs=[]
    for name in [p['name'] for p in parts]+[INDEX_NAME,HELPER_NAME,ARCHIVE_NAME]:
        path=OUT/name;data=path.read_bytes();new_inputs.append({'name':name,'source_path':str(path),'bytes':len(data),'sha256':sha(data),'git_blob':blob(data),'provenance':{'kind':'exact-segment-transport-revision','original_archive_sha256':ORIGINAL_SHA,'original_assembly_receipt_sha256':RECEIPT_SHA}})
    old_input=[r for r in v4['inputs'] if r['name']==OLD_NAME];check(len(old_input)==1,'one whole-ZIP static input replaced')
    v5=deepcopy(v4);v5.update(observed_at=now(),inputs=[deepcopy(r) for r in v4['inputs'] if r['name']!=OLD_NAME]+new_inputs,prior_static_plan_sha256=sha(v4_raw),new_inputs=new_inputs,removed_inputs=old_input,post_assembly_transport_revision=True,local_transport_revision_authorized=True,original_assembly_receipt_sha256=RECEIPT_SHA)
    check(len(v5['inputs'])==61 and v5['inputs'][:40]==v4['inputs'][:40],'61 inputs retain first 40 uploaded static blobs unchanged');(OUT/'static-inputs-v5.json').write_bytes(encode(v5))
    revised_ledger=deepcopy(ledger);revised_context=deepcopy(context);revised_ledger['tasks'][124]['evidence_links'][0]=new_link;revised_context['additional_tasks'][8]['evidence_links'][0]=new_link
    appendix=('\n## Post-assembly evidence transport revision\n\n'
        'The original assembled record set contained 67 outputs totaling 50,012,691 bytes. Its receipt, context, ledger, report, manifest and preservation record are retained in [the transport repair archive](evidence/cycle837fe-network-recovery-20261121/record-transport-repair.zip), together with the unchanged v4 static plan and the reported HTTP 400 transport failure. The 16,865,753-byte sealed Sigstore peer ZIP exceeded the MCP request-body limit after base64 encoding. No same-payload retry or ref/PR change was made.\n\n'
        'The pending record copy now uses two exact byte segments of 9,999,999 and 6,865,754 bytes. [The segment index](evidence/cycle837fe-network-recovery-20261121/sigstore-tooling-archive-parts.json) records their order, sizes, SHA-256 digests and Git blob identities. [The reassembly helper](evidence/cycle837fe-network-recovery-20261121/reassemble-sigstore-evidence.py) verifies them with `--verify-only`; `--output PATH` creates a reconstructed archive exclusively. Concatenation preserves original SHA-256 `81a7e43597b9100c7b41a0a4ebcb477db8511d7f222a589faa1e5821140959b3`, all 145 members and their CRCs, without repacking. The original sealed archive and seal remain unchanged.\n\n'
        'Only the exact current Sigstore evidence link in the new ledger task and matching assembly-context task now points to the segment index. The context records revised static inputs and the report digest, with an explicit post-assembly transport revision. The retained assembly driver, context builder, report template and v4 plan describe the original assembly; its before-images are preserved instead of rewriting that history. [The repair proof](evidence/cycle837fe-network-recovery-20261121/record-transport-repair-proof.json) records the controlled delta.\n\n'
        'All 130 task IDs, all 46 notes, the 116-task baseline and complete prior/deep before-images remain. QA, TODO, the handoff, prior-ledger bytes, other archives and runtime/tests/source identity are unchanged. No newly reviewed historical branch is incorporated. This local repair runs no product or full suite tests and makes no hosted qualification, publication or release claim. Independent final-record audit remains pending.\n')
    revised_report=originals[REPORT]+appendix.encode();revised_context['static_inputs']=deepcopy(v5['inputs']);revised_context['report_path']=str(REPO/REPORT);revised_context['report_sha256']=sha(revised_report)
    revised_context['post_assembly_transport_revision']={'recorded_at':now(),'scope':'exact-segment transport adaptation of assembled local records','original_assembly_receipt_sha256':RECEIPT_SHA,'original_context_sha256':sha(copies['assembly-context.json']),'original_report_sha256':sha(copies['report.md']),'original_static_plan_sha256':sha(v4_raw),'original_assembly_before_images':(REL/ARCHIVE_NAME).as_posix(),'repair_archive_sha256':sha((OUT/ARCHIVE_NAME).read_bytes()),'proof':(REL/PROOF_NAME).as_posix(),'static_plan_path':str(OUT/'static-inputs-v5.json'),'static_plan_sha256':sha(encode(v5)),'after_assembly_receipt_path':str(OUT/'after-assembly-receipt.json'),'original_builders_are_original_assembly_evidence':True,'runtime_changed':False,'new_historical_review_incorporated':False,'independent_final_record_audit':'PENDING'}
    ledger_raw=encode(revised_ledger);context_raw=encode(revised_context);restored=deepcopy(revised_ledger);restored['tasks'][124]['evidence_links'][0]=old_link
    check(restored==ledger and revised_ledger['tasks'][:116]==ledger['tasks'][:116] and revised_ledger['continuation_history']==ledger['continuation_history'],'one ledger leaf changes; all history/deep before-images preserved')
    check([t['id'] for t in revised_ledger['tasks']]==ids and revised_ledger['notes']==ledger['notes'],'130 task IDs/order and 46 notes unchanged')
    restored_context=deepcopy(revised_context);restored_context['additional_tasks'][8]['evidence_links'][0]=old_link
    for k in ('static_inputs','report_path','report_sha256'):restored_context[k]=deepcopy(context[k])
    del restored_context['post_assembly_transport_revision'];check(restored_context==context,'context changes only specified link/inputs/report fields and explicit revision')
    check(revised_report.startswith(originals[REPORT]) and revised_report.count(originals[REPORT])==1,'whole original report remains exactly once as prefix')
    outputs=dict(originals);del outputs[REL/OLD_NAME]
    for row in new_inputs:outputs[REL/row['name']]=Path(row['source_path']).read_bytes()
    outputs[LEDGER]=ledger_raw;outputs[REPORT]=revised_report;outputs[REL/'assembly-context.json']=context_raw
    proof={'schema':'patchtrace/network-record-transport-repair/1','recorded_at':now(),'source':SOURCE,'tree':TREE,'original_assembly_receipt_sha256':RECEIPT_SHA,'original_archive_sha256':ORIGINAL_SHA,'original_archive_bytes':16865753,'original_archive_members':145,'parts':parts,'repair_archive':ARCHIVE_NAME,'repair_archive_sha256':sha(outputs[REL/ARCHIVE_NAME]),'static_plan_sha256':sha(encode(v5)),'original_static_plan_sha256':sha(v4_raw),'current_context_sha256':sha(context_raw),'current_ledger_sha256':sha(ledger_raw),'current_report_sha256':sha(revised_report),'original_report_prefix_bytes':len(originals[REPORT]),'original_report_prefix_sha256':sha(originals[REPORT]),'ledger_changes':[{'json_path':['tasks',124,'evidence_links',0],'task_id':ids[124],'before':old_link,'after':new_link}],'context_changes':['additional_tasks[8].evidence_links[0]','static_inputs','report_path','report_sha256','post_assembly_transport_revision'],'tasks':130,'notes':46,'baseline_tasks':116,'all_task_ids_and_order_preserved':True,'all_other_task_rows_preserved':True,'prior_notes_history_and_deep_before_images_preserved':True,'original_preservation_record_unchanged':True,'qa_todo_handoff_unchanged':True,'all_other_archives_unchanged':True,'original_v4_builders_and_template_unchanged':True,'original_sealed_archive_and_seal_unchanged':True,'original_census_181_16_unchanged':True,'new_historical_review_incorporated':False,'runtime_tests_and_source_head_unchanged':True,'product_tests_executed':0,'remote_calls':0,'ref_pr_commit_ci_mutations':False,'original_error_retained':True,'independent_final_record_audit':'PENDING','primary_before_inventory_outputs':67,'expected_after_inventory_outputs':72}
    outputs[REL/PROOF_NAME]=encode(proof)
    manifest={'schema':'patchtrace/evidence-manifest/1','source':SOURCE,'tree':TREE,'files':[{'path':p.relative_to(REL).as_posix(),'bytes':len(data),'sha256':sha(data)} for p,data in sorted(outputs.items()) if p.is_relative_to(REL) and p!=REL/'manifest.json']};outputs[REL/'manifest.json']=encode(manifest)
    check(len(outputs)==72 and len(manifest['files'])==66,'final 72 outputs and 66 manifest payloads')
    changed={p for p in outputs if p in originals and outputs[p]!=originals[p]}
    check(changed=={LEDGER,REPORT,REL/'assembly-context.json',REL/'manifest.json'},'only four existing pending-record files change')
    check(all(outputs[p]==originals[p] for p in originals if p not in changed and p!=REL/OLD_NAME),'62 other original outputs unchanged')
    for path,data in originals.items():check((REPO/path).read_bytes()==data,'pre-apply original unchanged: '+path.as_posix())
    for path in outputs.keys()-originals.keys():check(not (REPO/path).exists(),'new candidate path unused: '+path.as_posix())
    events.append({'at':now(),'event':'All preparation checks passed; applying authorized local transport delta'})
    for path,data in sorted(outputs.items()):
        if path not in originals or data!=originals[path]:(REPO/path).write_bytes(data)
    check((E/OLD_NAME).read_bytes()==original and source_archive.read_bytes()==original,'original preserved before removal of candidate duplicate');(E/OLD_NAME).unlink()
    verify_helper(E,'reassembly-verification-after.json')
    check({p.name for p in E.iterdir() if p.is_file()}=={p.name for p in outputs if p.is_relative_to(REL)},'exact candidate evidence directory after apply')
    for path,data in outputs.items():check((REPO/path).read_bytes()==data,'after identity: '+path.as_posix())
    for path,expected in protected.items():
        data=Path(path).read_bytes();check({'bytes':len(data),'sha256':sha(data)}==expected,'protected input unchanged: '+path)
    check(git('rev-parse','HEAD','HEAD^{tree}').decode().splitlines()==[SOURCE,TREE],'source HEAD/tree unchanged after apply')
    check(not git('diff','--name-only','HEAD','--','src','tests','tools','.github').strip(),'runtime/tests/tools/workflows unchanged after apply')
    status_after=git('status','--porcelain=v1').decode();check(status_before==status_after,'top-level worktree ownership surface unchanged')
    after={'schema':'patchtrace/network-post-assembly-transport-receipt/1','source':SOURCE,'tree':TREE,'applied':True,'completed_at':now(),'original_assembly_receipt_sha256':RECEIPT_SHA,'context_sha256':sha(context_raw),'static_plan_path':str(OUT/'static-inputs-v5.json'),'static_plan_sha256':sha(encode(v5)),'outputs':[{'path':p.as_posix(),'bytes':len(data),'sha256':sha(data),'git_blob':blob(data)} for p,data in sorted(outputs.items())],'output_count':len(outputs),'total_output_bytes':sum(map(len,outputs.values())),'preservation':receipt['preservation'],'transport_repair':proof,'changed_existing_paths':sorted(p.as_posix() for p in changed),'removed_candidate_duplicate':(REL/OLD_NAME).as_posix(),'added_paths':sorted(p.as_posix() for p in outputs.keys()-originals.keys()),'static_input_count':len(v5['inputs']),'task_ids':ids,'tasks':130,'notes':46,'check_count':len(checks),'failed_checks':[c for c in checks if not c['passed']],'independent_final_record_audit':'PENDING','source_mutations':False,'remote_calls':0,'original_assembly_receipt_preserved':True,'historical_review_seal_preserved':True,'status_before':status_before,'status_after':status_after}
    (OUT/'after-assembly-receipt.json').write_bytes(encode(after))
    (OUT/'repair-archive-receipt.json').write_bytes(encode({'archive':ARCHIVE_NAME,'bytes':(OUT/ARCHIVE_NAME).stat().st_size,'sha256':sha((OUT/ARCHIVE_NAME).read_bytes()),'members':len(archive_inputs)+1,'crc_verified':True,'payload_manifest_sha256':sha(encode(archive_manifest)),'contains_original_whole_archive_or_parts':False}))
    events.append({'at':now(),'event':'Controlled local record transport revision complete and frozen'})
    print(json.dumps({'applied':True,'outputs':len(outputs),'total_bytes':after['total_output_bytes'],'static_inputs':len(v5['inputs']),'tasks':130,'notes':46,'checks':len(checks),'failed':0,'parts':parts,'after_receipt_sha256':sha(encode(after)),'static_plan_sha256':sha(encode(v5)),'context_sha256':sha(context_raw),'ledger_sha256':sha(ledger_raw),'report_sha256':sha(revised_report),'manifest_sha256':sha(outputs[REL/'manifest.json']),'repair_proof_sha256':sha(outputs[REL/PROOF_NAME]),'repair_archive_sha256':sha(outputs[REL/ARCHIVE_NAME])},indent=2))

if __name__=='__main__':
    try:main()
    except BaseException:
        if OUT.exists():(OUT/'failure.txt').write_text(traceback.format_exc())
        raise
    finally:
        if OUT.exists():(OUT/'execution-checks.json').write_bytes(encode({'checks':checks,'commands':commands,'events':events,'count':len(checks),'failed':[c for c in checks if not c['passed']]}))
