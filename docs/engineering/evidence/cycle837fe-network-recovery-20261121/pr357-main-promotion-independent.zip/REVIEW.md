# Independent audit of actual PR357 main promotion

**Verdict: CLEAR for the recorded promotion. New actual-main qualification remains a separate stream.**

This review did not author the root promotion. It independently checked the sealed promotion archive, the actual fetched Git commit, the fresh guard and merge request/result records, exact PR body preservation, and full continuation before/update/later-live records. It ran no product tests or CI and made no source, ref, schedule or person-message changes.

## Actual promoted object

| Property | Independently verified value |
|---|---|
| Actual merge | `ea16019601486c831941f9bc1a7ba5862a170317` |
| First parent | `3a16290c0fcc4e0c21712fe10474a3ff33fad336` |
| Second parent | `d60ac40daf767fe6a93ae152feb21235f6e75e0b` |
| Complete tree | `4a07cd88ded407bef30a8aeb81961e4041822dc2` |
| Server merge time | `2026-11-21T15:32:22Z` |
| Fresh guard read | `2026-11-21T15:31:52.776Z` |
| Guard age at merge | **29.224 seconds** |

The raw local Git commit hashes back to ea160 using Git's commit-object framing and equals the sealed actual-merge-commit.txt byte-for-byte. Its ordered parents match the previous main and qualified d60 head. The actual complete tree equals d60's local fetched tree, and the complete d60-to-ea160 diff is empty. The immutable source qualification and its independent 287-check delta bind the same tree to synthetic merge 254d.

The actual title and body both retain **[no release] [no deploy]**. Their complete text equals the recorded merge request. That request uses merge method merge and expected_head_sha d60ac40daf767fe6a93ae152feb21235f6e75e0b. The successful result identifies ea160, and the postmerge API record confirms the closed/merged PR, actual main ref, commit tree, ordered parents and message. The commit timestamp equals the server's merged_at value.

## Guard and qualification references

The raw premerge guard shows PR357 open, non-draft, unmerged and cleanly mergeable, with the exact d60 head and prior main3a. Reviews, issue comments, inline comments, rulesets and reviewer/team requests contain no blockers in that capture. The combined status is successful, including its returned Snyk status.

All **18 check runs** are completed on d60. **16 succeeded**; **release-gate** and **release** are the two intentional publication skips. Every check completed before the fresh guard. Their IDs, names and conclusions exactly match the immutable final qualified job inventory. Both qualified workflows were pull_request runs on attempt1, and the 16 successful checkout receipts identify synthetic254d. Skips are retained as skips.

The reported full-suite numbers match the immutable source qualification:

| Platform | Passed | Skipped | Expected failures | Main JUnit cases | Failures/errors |
|---|---:|---:|---:|---:|---:|
| Linux | 24,336 | 53 | 4 | 24,393 | 0 / 0 |
| Windows | 24,205 | 185 | 3 | 24,393 | 0 / 0 |

The final source record has documented open gates and seven expected-failure records. The independent completion delta records **287 checks and zero failures**. Their archive bytes/hashes/member counts and named JSON hashes were checked, without copying the 3 MB source archive into this companion:

| Immutable reference | SHA-256 |
|---|---|
| final-d60-evidence.zip, 3,038,215 bytes / 145 members | `0b70d118ec79e9a88230eb7dd404bc7ebf5080f78c6d2c15614dccdb493a6b08` |
| final-qualification.json | `a6f59daaa6d1dc3b495705ec26c6f392a2a4a383b846d20f7a4ccc8c397ea5f1` |
| completion-delta-review.zip, 12,608 bytes / 4 members | `884b388584e1f5b840f6bdeb9242442eeac302c1555749420b28464be5b1bcad` |
| completion-delta-review.json | `653b4f4c42ade27077153a948128517902bdef89861e5153ac1738eecc96c58c` |

The promotion record explicitly states that checks on actual main ea160 are a new, separate qualification stream, pending at that capture. This audit does not infer their later status from source-tree equality. It finds no new-main success, untriggered-lane acceptance or release/deployment claim introduced by the promotion. Existing native/corpus, manual, accessibility, trust, provenance and L1–L3 limits remain open.

## Exact PR body preservation

The full prior body in the update request equals the fresh premerge body and the initial postmerge body. The update adds exactly **2,087 characters** before all **4,874 prior characters**, producing **6,961 characters**. Both the update response and a subsequent fresh body read exactly equal this concatenation. The prior UTF-8 suffix is unchanged, not merely summarized or replaced.

Prior body SHA-256: `ca30668e24e2846316cb8226ba8da4a607c981fa6dac3fdcb3d026fe2d3c934b`.  
Actual body SHA-256: `ab798f65468731c09cd4a8c23da00a43c324f304dbd597e5fd437a27e55a5520`.

## Continuation schedule, history and timing

Root supplied its retained original normalized before snapshot and original update response in a separate raw companion, without rewriting the sealed promotion archive. This review copied those raw inputs into original-continuation-raw and compared them with its own read-only automation peek.

The original update equals the exact **4,365-character prefix** plus all **63,965 prior prompt characters**, giving **68,330 characters**. The later live prompt is byte-identical to that complete after response. The hourly VEVENT schedule, task title, enabled state, timing mode, timezone, conversation and environment selection are preserved. The complete previous observer last-run and latest-result records remain identical in the later live response, including their historical premerge observation and unknown delivery status.

- Prior prompt SHA-256: `f32faf5d7eed78c017a85264670dfcbe8f874ab2c6de973d460ff5c903c47939`.
- Original after/later live prompt SHA-256: `9aae88a8b60ab1a7238b6806703f888c4e091ed9757af5bd65e1c50ad7a9fb38`.
- Original server update response: **2026-11-21 15:34:47.917190 UTC**.
- Later live metadata updated_at: **2026-11-21 15:35:09.386592 UTC**.
- Prepared prefix label: **2026-11-21 15:36 UTC**.

The checkpoint explicitly identifies 15:36 as a prepared label and the server update time as authoritative. The later timestamp is retained as a distinct metadata observation; its cause is not inferred. Identical prompt/schedule/history bytes establish that this later metadata observation did not replace those preserved values. Root ownership through19:00 UTC and scheduled observer-only behavior remain explicit in the new prefix.

## Parent preservation and audit limits

All **179 observed parent input files** remained byte-identical after the audit. The promotion archive is still 38,590 bytes / 12 members with SHA-256 `0982c1ae8982f28439b0f0d69aee48b2f335872e5ef4290a4527151ee9319c61`; its manifest remains `09319ca2edab77d727aba4d755fc6544f54293ea422f41cd284dca18cd59065e`, and actual-main-proof.json remains `a072f04226548408cf5a6c5f25dd371819ff279fae66de53f1dfed459e29038a`. Every promotion archive member matched its manifest and original file.

There are **81 mechanical evidence checks, zero failed checks**. These are audit assertions, not new product tests or a new CI qualification.

The initial audit helper additionally tried to resolve synthetic254d in the inspected local Git object store and received exit128 because that object was absent. Actual ea160 and d60 objects were available. The original helper and stderr are retained. The corrected audit uses the explicitly requested immutable final-qualification/287-delta reference for the synthetic identity, while retaining independent local-Git checks for actual main and source. No fetch, ref mutation or parent edit was used to resolve this evidence-location issue.

Files: review.json contains every check; independently-read-actual-commit.txt contains the fetched commit bytes; live-continuation-peek.json and original-continuation-raw contain full preservation inputs; parent snapshots record all input hashes. This companion does not duplicate the large source qualification archive. Root retains ownership of next integration and of the separate actual-main qualification stream.
