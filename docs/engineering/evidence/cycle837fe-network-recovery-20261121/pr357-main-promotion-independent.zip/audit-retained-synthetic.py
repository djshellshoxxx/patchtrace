"""Independent read-only audit of actual PR357 promotion; no source/CI/ref/test execution."""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import shutil
import subprocess
import zipfile
from pathlib import Path

ROOT = Path('/workspace/scratch/837fe19aae3a')
OUT = ROOT / 'evidence/pr357-main-promotion-independent'
PARENT = ROOT / 'evidence/pr357-main-promotion'
RAW_CONTINUATION = ROOT / 'evidence/pr357-main-promotion-continuation-raw'
REPO = ROOT / 'PatchTrace-windows-recovery-followup'
ACTUAL = 'ea16019601486c831941f9bc1a7ba5862a170317'
SOURCE = 'd60ac40daf767fe6a93ae152feb21235f6e75e0b'
PREVIOUS = '3a16290c0fcc4e0c21712fe10474a3ff33fad336'
SYNTHETIC = '254d26e58ef03a03e50c78b5f90c6ef7d9bf9e57'
TREE = '4a07cd88ded407bef30a8aeb81961e4041822dc2'
checks = []


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def check(name, condition, detail=None):
    row = {'check': name, 'passed': bool(condition)}
    if detail is not None:
        row['detail'] = detail
    checks.append(row)


def timestamp(text):
    return dt.datetime.fromisoformat(text.replace('Z', '+00:00'))


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


archive = PARENT / 'pr357-main-promotion.zip'
check('promotion archive exact size and SHA256', archive.stat().st_size == 38590 and sha(archive.read_bytes()) == '0982c1ae8982f28439b0f0d69aee48b2f335872e5ef4290a4527151ee9319c61')
check('promotion manifest exact SHA256', sha((PARENT / 'manifest.json').read_bytes()) == '09319ca2edab77d727aba4d755fc6544f54293ea422f41cd284dca18cd59065e')
manifest = read(PARENT / 'manifest.json')
with zipfile.ZipFile(archive) as z:
    check('promotion archive has exactly 12 unique members and valid CRC', len(z.namelist()) == len(set(z.namelist())) == 12 and z.testzip() is None)
    check('promotion member inventory equals manifest plus manifest', set(z.namelist()) == {x['path'] for x in manifest['files']} | {'manifest.json'})
    check('archived manifest equals sealed filesystem manifest', z.read('manifest.json') == (PARENT / 'manifest.json').read_bytes())
    for entry in manifest['files']:
        data = z.read(entry['path'])
        check('promotion member ' + entry['path'], len(data) == entry['bytes'] and sha(data) == entry['sha256'] and data == (PARENT / entry['path']).read_bytes())
check('actual main proof exact SHA256', sha((PARENT / 'actual-main-proof.json').read_bytes()) == 'a072f04226548408cf5a6c5f25dd371819ff279fae66de53f1dfed459e29038a')

raw_commit = git('cat-file', 'commit', ACTUAL)
(OUT / 'independently-read-actual-commit.txt').write_bytes(raw_commit)
headers, message = raw_commit.decode().split('\n\n', 1)
parents = [line.split(' ', 1)[1] for line in headers.splitlines() if line.startswith('parent ')]
tree = next(line.split(' ', 1)[1] for line in headers.splitlines() if line.startswith('tree '))
subject, body = message.split('\n\n', 1)
object_hash = hashlib.sha1(b'commit ' + str(len(raw_commit)).encode() + b'\0' + raw_commit).hexdigest()
check('actual raw Git object hashes to named commit', object_hash == ACTUAL)
check('actual raw Git object equals sealed fetched bytes', raw_commit == (PARENT / 'actual-merge-commit.txt').read_bytes())
check('actual commit ordered parents', parents == [PREVIOUS, SOURCE], parents)
check('actual commit tree', tree == TREE)
trees = {c: git('rev-parse', c + '^{tree}').decode().strip() for c in [ACTUAL, SOURCE]}
retained_qualification = read(ROOT / 'evidence/final-d60-qualification/final-qualification.json')
check('retained synthetic identity is exact qualified synthetic', retained_qualification['source']['synthetic_merge_sha'] == SYNTHETIC)
trees[SYNTHETIC] = retained_qualification['source']['synthetic_merge_tree_sha']
check('actual, qualified source and retained synthetic complete tree identities match', all(t == TREE for t in trees.values()), {'trees': trees, 'actual_and_source_basis': 'fetched local Git objects', 'synthetic_basis': 'immutable final-qualification.json, independently hash-verified below'})
diff = git('diff-tree', '--no-commit-id', '-r', '--name-status', SOURCE, ACTUAL)
check('complete qualified source versus actual main diff empty', diff == b'')
for marker in ['[no release]', '[no deploy]']:
    check('actual title retains ' + marker, marker in subject)
    check('actual body retains ' + marker, marker in body)

request = read(PARENT / 'merge-request.json')
result = read(PARENT / 'merge-result.json')
guard = read(PARENT / 'premerge-guard.json')
post = read(PARENT / 'postmerge-api.json')
actual_proof = read(PARENT / 'actual-main-proof.json')
check('merge request exact repository and PR357', request['repository_full_name'].lower() == 'djshellshoxxx/patchtrace' and request['pr_number'] == 357)
check('merge request guarded exact qualified head and merge method', request['expected_head_sha'] == SOURCE and request['merge_method'] == 'merge')
check('actual merge title/body equal requested content', message == request['commit_title'] + '\n\n' + request['commit_message'])
check('merge response succeeded with actual object', result['result']['isError'] is False and result['result']['structuredContent']['merged'] is True and result['result']['structuredContent']['sha'] == ACTUAL)
check('postmerge API confirms closed merged PR357 and unchanged head', post['pr']['number'] == 357 and post['pr']['state'] == 'closed' and post['pr']['merged'] is True and post['pr']['head']['sha'] == SOURCE and post['pr']['merge_commit_sha'] == ACTUAL)
check('postmerge main ref and commit identify actual object', post['main']['object']['sha'] == post['commit']['sha'] == ACTUAL)
check('postmerge API tree/parents/message equal raw Git object', post['commit']['tree']['sha'] == tree and [p['sha'] for p in post['commit']['parents']] == parents and post['commit']['message'] == message)
commit_epoch = int(next(line for line in headers.splitlines() if line.startswith('committer ')).rsplit(' ', 2)[1])
check('actual commit timestamp equals server merged_at', dt.datetime.fromtimestamp(commit_epoch, dt.timezone.utc) == timestamp(post['pr']['merged_at']))

pr = guard['pr']
check('fresh premerge PR open, non-draft, unmerged and cleanly mergeable', pr['number'] == 357 and pr['state'] == 'open' and pr['draft'] is False and pr['merged'] is False and pr['mergeable'] is True and pr['mergeable_state'] == 'clean')
check('fresh guard exact head and previous main', pr['head']['sha'] == guard['head']['object']['sha'] == SOURCE and pr['base']['sha'] == guard['main']['object']['sha'] == PREVIOUS)
check('fresh guard tested synthetic merge identity', pr['merge_commit_sha'] == SYNTHETIC)
check('fresh reviews/comments/inline/rulesets contain no blockers', all(guard[k] == [] for k in ['reviews', 'comments', 'inline', 'rulesets']))
check('no pending reviewer/team requests in raw guard', pr['requested_reviewers'] == [] and pr['requested_teams'] == [])
check('raw branch has no additional required status contexts', guard['branch']['name'] == 'main' and guard['branch']['protection']['required_status_checks']['contexts'] == [] and guard['branch']['protection']['required_status_checks']['checks'] == [])
raw_checks = guard['checks']['check_runs']
check('raw guard complete check inventory exactly 18', guard['checks']['total_count'] == len(raw_checks) == 18 and len({x['id'] for x in raw_checks}) == 18)
check('all 18 raw checks are completed on exact d60', all(x['status'] == 'completed' and x['head_sha'] == SOURCE for x in raw_checks))
successful = [x for x in raw_checks if x['conclusion'] == 'success']
skipped = [x for x in raw_checks if x['conclusion'] == 'skipped']
check('raw checks contain 16 successes and exactly two publication skips', len(successful) == 16 and len(skipped) == 2 and {x['name'] for x in skipped} == {'release', 'release-gate'})
check('combined status and every returned status succeed on d60', guard['status']['sha'] == SOURCE and guard['status']['state'] == 'success' and guard['status']['total_count'] == len(guard['status']['statuses']) == 1 and all(x['state'] == 'success' for x in guard['status']['statuses']))
guard_time, merge_time = timestamp(guard['retrieved_at']), timestamp(post['pr']['merged_at'])
guard_age = (merge_time - guard_time).total_seconds()
check('all checks completed before fresh guard and merge', all(timestamp(x['completed_at']) <= guard_time for x in raw_checks) and guard_time < merge_time)
check('merge response and postmerge read follow actual merge', merge_time <= timestamp(result['received_at']) <= timestamp(post['retrieved_at']))

body_request = read(PARENT / 'body-update-request.json')
body_actual = read(PARENT / 'body-update-verification.json')
check('old PR body equals both fresh guard and pre-update postmerge value', body_request['prior_body'] == pr['body'] == post['pr']['body'])
check('PR body request is exact prefix plus complete old suffix', body_request['request_body'] == body_request['prefix'] + body_request['prior_body'])
check('body-update response and fresh verification equal exact request', body_request['response']['isError'] is False and body_request['response']['structuredContent']['body'] == body_request['request_body'] == body_actual['actual_body'])
check('actual old PR body suffix preserved byte-for-byte as UTF8', body_actual['actual_body'][len(body_request['prefix']):].encode() == body_request['prior_body'].encode())
check('body lengths and source/result identities are correct', len(body_request['prefix']) == body_actual['prefix_characters'] == 2087 and len(body_actual['actual_body']) == body_actual['actual_body_characters'] == 6961 and body_actual['source_head'] == SOURCE and body_actual['actual_merge'] == ACTUAL and body_actual['merged'] is True)

references = [
    ('evidence/final-d60-qualification/final-d60-evidence.zip', '0b70d118ec79e9a88230eb7dd404bc7ebf5080f78c6d2c15614dccdb493a6b08', 3038215, 145),
    ('evidence/final-d60-evidence-audit/completion-delta-review.zip', '884b388584e1f5b840f6bdeb9242442eeac302c1555749420b28464be5b1bcad', 12608, 4),
]
reference_records = []
for rel, expected, size, members in references:
    path = ROOT / rel
    with zipfile.ZipFile(path) as z:
        valid = path.stat().st_size == size and sha(path.read_bytes()) == expected and len(z.namelist()) == members and z.testzip() is None
    check('immutable referenced archive ' + rel, valid)
    reference_records.append({'path': rel, 'sha256': expected, 'bytes': size, 'members': members, 'copied_into_companion': False})
qualification_path = ROOT / 'evidence/final-d60-qualification/final-qualification.json'
delta_path = ROOT / 'evidence/final-d60-evidence-audit/completion-delta-review.json'
check('final qualification JSON exact referenced hash', sha(qualification_path.read_bytes()) == 'a6f59daaa6d1dc3b495705ec26c6f392a2a4a383b846d20f7a4ccc8c397ea5f1')
check('287-check independent delta exact referenced hash', sha(delta_path.read_bytes()) == '653b4f4c42ade27077153a948128517902bdef89861e5153ac1738eecc96c58c')
qualification, delta = read(qualification_path), read(delta_path)
check('final qualification is exact source/synthetic tree with documented open gates', qualification['source']['head_sha'] == SOURCE and qualification['source']['head_tree_sha'] == TREE and qualification['source']['synthetic_merge_sha'] == SYNTHETIC and qualification['source']['synthetic_merge_parents'] == parents and qualification['verdict']['qualification_status'] == 'qualified_with_documented_open_gates')
check('immutable independent delta has 287 checks and zero failures', delta['check_count'] == 287 and delta['failure_count'] == 0 and delta['verdict'] == 'clear_qualified_with_documented_open_gates')
qualified_jobs = [j for run in qualification['runs'] for j in run['jobs']]
check('fresh guard jobs match immutable qualified job identities and outcomes', {(x['id'], x['name'], x['conclusion']) for x in raw_checks} == {(x['id'], x['name'], x['conclusion']) for x in qualified_jobs})
check('referenced run identity/attempt/checkout claims are exact', {run['id'] for run in qualification['runs']} == {44910528283, 44910528348} and all(run['event'] == 'pull_request' and run['head_sha'] == SOURCE and run['run_attempt'] == 1 and run['conclusion'] == 'success' for run in qualification['runs']) and all(j.get('checkout_log_verified') is True and j.get('checkout_sha') == SYNTHETIC for j in qualified_jobs if j['conclusion'] == 'success'))
check('qualification retains 18 total/16 executed/2 intentional skips and seven xfail records', all(qualification['verdict'][k] == v for k, v in {'actual_job_count': 18, 'successful_executed_job_count': 16, 'intentional_skipped_job_count': 2, 'expected_failure_record_count': 7}.items()))
for platform, counts in [('Linux', (24336, 53, 4)), ('Windows', (24205, 185, 3))]:
    actual_counts = qualification['qa']['full_pytest'][platform]
    reports = [x for x in qualification['qa']['junit_reports'] if x['platform'] == platform and x['path'] == 'qa-results.xml']
    check(platform + ' promoted full-suite counts match qualified record', tuple(actual_counts[k] for k in ['passed', 'skipped', 'xfailed']) == counts and len(reports) == 1 and reports[0]['test_cases'] == sum(counts) == 24393 and reports[0]['failures'] == reports[0]['errors'] == 0)
check('promotion references exact qualification and independent delta hashes', actual_proof['source_qualification_archive_sha256'] == references[0][1] and actual_proof['independent_completion_review_sha256'] == sha(delta_path.read_bytes()) and references[0][1] in body and references[1][1] in body)
check('actual-main qualification remains explicitly separate and pending', actual_proof['new_main_qualification'] == 'separate automatic stream pending' and manifest['source_qualification_is_separate'] is True and 'Automatic checks on actual main ea160 are a separate pending qualification stream.' in body_request['prefix'])
check('no release/deployment or broader lane closure claim introduced', actual_proof['release_or_deployment_claimed'] is False and 'This merge does not authorize release, deployment, tagging, or historical branch deletion.' in body and 'No transfer of qualification to untriggered native lanes or the separate network/tooling candidate.' in body and 'Seven existing expected-failure records' in body_request['prefix'])

cont = read(PARENT / 'continuation-update.json')
checkpoint = read(PARENT / 'active-task-checkpoint.json')
before = read(RAW_CONTINUATION / 'before-automation-snapshot.json')
update_response = read(RAW_CONTINUATION / 'after-update-structured-response.json')
after = update_response['automation']
preservation = read(RAW_CONTINUATION / 'prompt-preservation.json')
live = read(OUT / 'live-continuation-peek.json')['automation']
check('continuation original update succeeded for same automation', update_response['success'] is True and before['id'] == after['id'] == live['id'] == checkpoint['automation']['id'])
check('complete prior continuation prompt is exact suffix of original update', after['prompt'] == cont['prefix'] + before['prompt'] and after['prompt'].endswith(before['prompt']))
check('raw companion prefix equals sealed promotion prefix', preservation['exact_prefix'] == cont['prefix'])
check('continuation character counts are independently exact', len(before['prompt']) == cont['prior_prompt_characters'] == 63965 and len(cont['prefix']) == 4365 and len(after['prompt']) == cont['new_prompt_characters'] == checkpoint['automation']['prompt_characters'] == 68330)
check('later live continuation prompt equals complete original after response', live['prompt'].encode() == after['prompt'].encode())
check('hourly schedule exactly preserved before/update/live', before['schedule'] == after['schedule'] == live['schedule'] == cont['schedule_unchanged'] == 'BEGIN:VEVENT\nDTSTART:20261120T011516Z\nRRULE:FREQ=HOURLY\nEND:VEVENT')
check('continuation title/enabled state preserved', before['title'] == after['title'] == live['title'] == 'Continue PatchTrace engineering' and before['is_enabled'] is after['is_enabled'] is live['is_enabled'] is True)
check('timing mode, timezone, conversation and environment selection preserved', all(before.get(k) == after.get(k) for k in ['timing_mode', 'display_schedule', 'default_timezone', 'conversation_id', 'environment_selection', 'environments']))
check('recorded observer history retained exactly in later live response', before['run_details'] == live['run_details'] == cont['last_observer_result'])
check('actual original update time is authoritative across retained records', after['updated_at'] == cont['updated_at'] == checkpoint['automation']['actual_update_time'] == preservation['server_update_receipt_time'] == '2026-11-21T15:34:47.917190+00:00')
check('later metadata timestamp is retained without assuming its cause', live['updated_at'] == '2026-11-21T15:35:09.386592+00:00' and timestamp(live['updated_at']) > timestamp(after['updated_at']))
check('prepared 15:36 prefix label is explicitly distinguished in checkpoint', '2026-11-21 15:36 UTC' in cont['prefix'].splitlines()[0] and checkpoint['automation']['note'] == 'Prefix label1536 is a prepared checkpoint label; server update timestamp is authoritative.')
check('continuation keeps observer-only root ownership and separate new-main qualification', 'While root is active, scheduled runs observe only' in cont['prefix'] and 'NEW separate ea160 automaticQA/Pages' in cont['prefix'] and 'Nevertransfer resultsbetweenSHAs.' in cont['prefix'] and cont['root_lease_until'] == checkpoint['root_lease_until'] == '2026-11-21T19:00:00Z')

copy_dir = OUT / 'original-continuation-raw'
copy_dir.mkdir(exist_ok=False)
raw_copies = []
for path in sorted(RAW_CONTINUATION.glob('*.json')):
    shutil.copyfile(path, copy_dir / path.name)
    raw_copies.append({'original': str(path.relative_to(ROOT)), 'copy': str((copy_dir / path.name).relative_to(OUT)), 'sha256': sha(path.read_bytes())})
snapshot = read(OUT / 'parent-file-snapshot-before.json')
unchanged = []
for entry in snapshot['files']:
    path = ROOT / entry['path']
    unchanged.append({'path': entry['path'], 'unchanged': path.is_file() and path.stat().st_size == entry['size'] and sha(path.read_bytes()) == entry['sha256']})
check('all 179 observed parent files remain byte-identical', len(unchanged) == 179 and all(x['unchanged'] for x in unchanged))
(OUT / 'parent-preservation-after.json').write_text(json.dumps({'files': unchanged, 'all_unchanged': all(x['unchanged'] for x in unchanged)}, indent=2) + '\n')

failures = [x for x in checks if not x['passed']]
review = {
    'schema': 'patchtrace/pr357-main-promotion-independent-review/1',
    'completed_at': dt.datetime.now(dt.timezone.utc).isoformat(),
    'verdict': 'clear_promotion_with_separate_new_main_qualification' if not failures else 'blocked',
    'author_independence': 'Reviewer did not author root PR357 promotion; prior pilot/Sigstore author work is outside this bounded review.',
    'actual_main': ACTUAL, 'ordered_parents': parents, 'tree': tree,
    'actual_raw_commit_sha256': sha(raw_commit), 'check_count': len(checks), 'failure_count': len(failures),
    'checks': checks, 'failures': failures,
    'guard_retrieved_at': guard['retrieved_at'], 'actual_merge_at': post['pr']['merged_at'],
    'guard_age_at_merge_seconds': guard_age,
    'raw_checks': {'total': 18, 'successful_executed': 16, 'publication_skips': [x['name'] for x in skipped]},
    'pr_body_preservation': {'prefix_characters': len(body_request['prefix']), 'prior_characters': len(body_request['prior_body']), 'actual_characters': len(body_actual['actual_body']), 'prior_sha256_utf8': sha(body_request['prior_body'].encode()), 'actual_sha256_utf8': sha(body_actual['actual_body'].encode()), 'exact_prior_suffix': True},
    'references_not_duplicated': reference_records,
    'qualification_json_sha256': sha(qualification_path.read_bytes()), 'independent287_json_sha256': sha(delta_path.read_bytes()),
    'continuation': {'id': before['id'], 'before_characters': len(before['prompt']), 'prefix_characters': len(cont['prefix']), 'after_characters': len(after['prompt']), 'before_prompt_sha256_utf8': sha(before['prompt'].encode()), 'after_and_live_prompt_sha256_utf8': sha(after['prompt'].encode()), 'prepared_prefix_label': '2026-11-21 15:36 UTC', 'original_server_update_at': after['updated_at'], 'later_live_metadata_updated_at': live['updated_at'], 'later_timestamp_cause': 'not inferred', 'exact_prior_suffix_and_live_after_equality': True, 'schedule_and_recorded_history_preserved': True, 'original_raw_copies': raw_copies},
    'parent_files_preserved': len(unchanged),
    'limits': ['Qualification references remain exact d60/synthetic254d evidence.', 'New actual-main QA/Pages is a separate stream; no success is inferred here.', 'Seven inherited xfail records and documented broad gates remain open.', 'No release/deployment or other-lane acceptance is claimed.', 'This task performed static evidence reads and one read-only automation peek; no tests, CI, source/ref/schedule writes or person-directed messages.', 'The initial audit tried to resolve synthetic254d in this local object store and received exit128; the corrected audit references its immutable qualified identity instead, without fetching or changing refs.']
}
(OUT / 'review.json').write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps({'verdict': review['verdict'], 'check_count': len(checks), 'failure_count': len(failures), 'failures': failures, 'guard_age_at_merge_seconds': guard_age, 'parents_preserved': len(unchanged), 'continuation': review['continuation']}, indent=2))
if failures:
    raise SystemExit(1)
