"""Read-only audit of frozen actual records; writes only independent evidence."""
from pathlib import Path
from copy import deepcopy
from hashlib import sha1, sha256
from io import BytesIO
from datetime import datetime, timezone
import json, re, stat, subprocess, zipfile

R=Path('/workspace/scratch/837fe19aae3a')
O=Path(__file__).resolve().parent
P=R/'PatchTrace-network-recovery-followup'
E=Path('docs/engineering/evidence/cycle837fe-network-recovery-20261121')
L=Path('docs/engineering/task-ledger.json')
D=Path('docs/engineering/cycle837fe-network-recovery-20261121.md')
PREFIX=[Path('docs/engineering-handoffs/cycle837fe-combined-pr349-20261121.md'),Path('docs/qa.md'),Path('tasks/todo.md')]
S='9610919d29010d53cf00af3b7c38207ffd84f945'; T='3d5e2965ef26235610a08fd8378cac078c6bd9a0'
B='d60ac40daf767fe6a93ae152feb21235f6e75e0b'; BT='4a07cd88ded407bef30a8aeb81961e4041822dc2'
M='ea16019601486c831941f9bc1a7ba5862a170317'; OM='3a16290c0fcc4e0c21712fe10474a3ff33fad336'
RS='5c07bfd1a41b399fee86545206ed1c5e9aec0c26'
CHECKS=[]; PROOF={}
def sha(b): return sha256(b).hexdigest()
def blob(b): return sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def j(p): return json.loads(p.read_bytes())
def git(*a): return subprocess.check_output(['git',*a],cwd=P)
def check(label,ok):
    CHECKS.append({'check':label,'passed':bool(ok)})
    if not ok: raise AssertionError(label)
def diff(a,b,path=()):
    if type(a)!=type(b): return [(list(path),a,b)]
    if isinstance(a,dict): return [v for k in a.keys()|b.keys() for v in diff(a.get(k),b.get(k),path+(k,))]
    if isinstance(a,list): return [v for i in range(max(len(a),len(b))) for v in diff(a[i] if i<len(a) else None,b[i] if i<len(b) else None,path+(i,))]
    return [] if a==b else [(list(path),a,b)]

def run():
    receiptfile=R/'evidence/network-record-transport-repair/after-assembly-receipt.json'
    check('Actual final receipt hash',sha(receiptfile.read_bytes())=='52204f0e7b5f4889d51c52014fa5f0199fc86905a456e9f37c9e068475d209d9')
    receipt=j(receiptfile); originalreceipt=j(O/'initial-assembly-receipt.json')
    check('Original67-output receipt preserved',sha((O/'initial-assembly-receipt.json').read_bytes())=='07d811e45bb15b0e1b21a5660ffdab4badc6fef7ae2502cc775e5ba96676941c')
    ctxraw=(P/E/'assembly-context.json').read_bytes(); c=json.loads(ctxraw)
    check('Current frozen context hash',sha(ctxraw)=='bd39db0388414a2200f1b43c1c33633d5437ecef946fd372035dfd26628ffe12'==receipt['context_sha256'])
    mr=(P/E/'manifest.json').read_bytes(); manifest=json.loads(mr)
    check('Current frozen manifest hash',sha(mr)=='9d1d7f5d39b78ac5162d7349812c52900673f872081ce820a6ff81e061f0c718')
    inv={i['path']:i for i in receipt['outputs']}; oldinv={i['path']:i for i in originalreceipt['outputs']}
    check('Exactly72 unique outputs and50245691bytes',len(inv)==len(receipt['outputs'])==72 and sum(i['bytes'] for i in inv.values())==50245691)
    for path,item in inv.items():
        f=P/path; b=f.read_bytes()
        check('Output '+path,len(b)==item['bytes'] and sha(b)==item['sha256'] and blob(b)==item['git_blob'] and stat.S_ISREG(f.lstat().st_mode) and not f.is_symlink())
        check('Allowed record path '+path,Path(path) in [L,D,*PREFIX] or Path(path).is_relative_to(E))
    check('Exactly four tracked modifications',set(git('diff','--name-only').decode().splitlines())=={str(L),*(str(p) for p in PREFIX)})
    check('No staged changes',not git('diff','--cached','--name-only').strip())
    status=git('status','--porcelain=v1','--untracked-files=all').decode().splitlines()
    check('Status exhausts72 reviewed paths',len(status)==72 and {x[3:] for x in status}==set(inv))
    check('Source runtime tests tools workflows specs unchanged',not git('diff','--name-only','HEAD','--','src','tests','tools','.github','docs/specs').strip())
    efiles={p[len(str(E))+1:]:v for p,v in inv.items() if p.startswith(str(E)+'/') and p!=str(E/'manifest.json')}
    check('Manifest exhausts66 unique payloads',len(manifest['files'])==len({x['path'] for x in manifest['files']})==66 and {x['path'] for x in manifest['files']}==set(efiles))
    for row in manifest['files']: check('Manifest '+row['path'],row['bytes']==efiles[row['path']]['bytes'] and row['sha256']==efiles[row['path']]['sha256'])
    check('61 unique static inputs',len(c['static_inputs'])==len({x['name'] for x in c['static_inputs']})==61)
    for row in c['static_inputs']:
        src=Path(row['source_path']).read_bytes();dst=(P/E/row['name']).read_bytes()
        check('Exact static copy '+row['name'],src==dst and len(src)==row['bytes'] and sha(src)==row['sha256'])
    sp=R/'evidence/network-record-transport-repair/static-inputs-v5.json'
    check('Exact static v5 plan and context',sha(sp.read_bytes())=='566519d17021f7c47e806706bf416d29cd9ce9b861e6d900f6f7c5a06d96ed94' and j(sp)['inputs']==c['static_inputs'])
    removed=set(oldinv)-set(inv);added=set(inv)-set(oldinv);changed={p for p in oldinv.keys()&inv.keys() if oldinv[p]!=inv[p]}
    check('Only original candidate Sigstore duplicate removed',removed=={str(E/'sigstore-tooling-hash-closure-independent.zip')})
    check('Exactly4 expected changed existing outputs',changed=={str(L),str(D),str(E/'assembly-context.json'),str(E/'manifest.json')})
    check('Exactly62 original outputs byte-identical',len(oldinv.keys()&inv.keys()-changed)==62)
    check('Exactly6 transport additions',added=={str(E/n) for n in ['reassemble-sigstore-evidence.py','record-transport-repair-proof.json','record-transport-repair.zip','sigstore-independent.zip.part01','sigstore-independent.zip.part02','sigstore-tooling-archive-parts.json']})
    initialledger=j(O/'initial-task-ledger.json'); ledger=j(P/L)
    check('Transport changes exactly one new ledger link',diff(initialledger,ledger)==[(['tasks',124,'evidence_links',0],str(E/'sigstore-tooling-hash-closure-independent.zip'),str(E/'sigstore-tooling-archive-parts.json'))])
    initialreport=(O/'initial-report.md').read_bytes();report=(P/D).read_bytes()
    check('Complete original report retained as prefix once',report.startswith(initialreport) and report.count(initialreport)==1)
    initialcontext=j(O/'initial-assembly-context.json')
    check('Only five allowed context transport keys changed',{k for k in c.keys()|initialcontext.keys() if c.get(k)!=initialcontext.get(k)}=={'additional_tasks','report_path','report_sha256','static_inputs','post_assembly_transport_revision'})
    check('Only matching new-task context evidence leaf changed',diff(initialcontext['additional_tasks'],c['additional_tasks'])==[([8,'evidence_links',0],str(E/'sigstore-tooling-hash-closure-independent.zip'),str(E/'sigstore-tooling-archive-parts.json'))])
    parts=j(P/E/'sigstore-tooling-archive-parts.json');chunks=[];offset=0
    for i,p in enumerate(parts['parts']):
        data=(P/E/p['name']).read_bytes();chunks.append(data)
        check('Part'+str(i+1)+' size hash Gitblob offset',len(data)==p['bytes']==[9999999,6865754][i] and sha(data)==p['sha256'] and blob(data)==p['git_blob'] and p['offset']==offset)
        offset+=len(data)
    joined=b''.join(chunks);origzip=R/'evidence/sigstore-tooling-hash-closure-independent/sigstore-tooling-hash-closure-independent.zip'
    check('Exact original sealed archive remains and reconstructs',joined==origzip.read_bytes() and len(joined)==16865753 and sha(joined)=='81a7e43597b9100c7b41a0a4ebcb477db8511d7f222a589faa1e5821140959b3')
    with zipfile.ZipFile(BytesIO(joined)) as z:check('Original145unique members all CRCs',len(z.namelist())==len(set(z.namelist()))==145 and z.testzip() is None)
    verify=j(O/'reassembly-verify-only.json');check('Actual helper verify-only succeeded without output',verify['exit_code']==0 and verify['parsed_result']['output'] is None and verify['parsed_result']['sha256']==sha(joined))
    repair=(P/E/'record-transport-repair.zip').read_bytes();check('Repair archive exact seal',len(repair)==218681 and sha(repair)=='cf5099560980aae3427c936ec9735d680988c7fa7851858588a5e170286aa802')
    with zipfile.ZipFile(BytesIO(repair)) as z:
        check('Repair archive16members and CRC',len(z.namelist())==len(set(z.namelist()))==16 and z.testzip() is None)
        for a,b in {'assembly-receipt.json':'initial-assembly-receipt.json','assembly-context.json':'initial-assembly-context.json','task-ledger.json':'initial-task-ledger.json','report.md':'initial-report.md','manifest.json':'initial-manifest.json','preservation.json':'initial-preservation.json'}.items():check('Original interrupted before-image '+a,z.read('before/'+a)==(O/b).read_bytes())
        PROOF['transport_error']=json.loads(z.read('transport-error.json'))
    before_raw=git('show',S+':'+str(L));before=json.loads(before_raw)
    check('Complete baseline ledger exactd60',before_raw==git('show',B+':'+str(L))==(P/E/'prior-ledger-d60.json').read_bytes())
    check('116 unique original rows46notes',len(before['tasks'])==len({t['id'] for t in before['tasks']})==116 and len(before['notes'])==46)
    check('130 unique rows and46 original notes unchanged',len(ledger['tasks'])==len({t['id'] for t in ledger['tasks']})==130 and ledger['notes']==before['notes'])
    check('All116 original IDs/order preserved',[t['id'] for t in ledger['tasks'][:116]]==[t['id'] for t in before['tasks']])
    ids={'837fe-ci-publication-concurrency-recovery','837fe-downloaded-windows-artifact-validation','837fe-live-ghidra-original-archive-recovery','codex5-per-command-audit-gap-20261121-95fe','837fe-codex5-bounded-assessment'}
    check('Exactly five declared prior task updates',len(c['task_updates'])==5 and {u['id'] for u in c['task_updates']}==ids)
    old_by={t['id']:t for t in before['tasks']};new_by={t['id']:t for t in ledger['tasks']}
    for t in before['tasks']:
        if t['id'] not in ids:check('Unchanged old task '+t['id'],new_by[t['id']]==t)
    expected=deepcopy(before);expected_by={t['id']:t for t in expected['tasks']}
    for u in c['task_updates']:
        check('Whole before snapshot '+u['id'],u['before']==old_by[u['id']]);expected_by[u['id']].update(deepcopy(u['patch']))
    check('14new task rows exactly match context',len(c['additional_tasks'])==14 and ledger['tasks'][116:]==c['additional_tasks'] and [t['id'] for t in ledger['tasks'][116:]]==c['new_task_ids'])
    states={'DISCOVERED','OWNED','IMPLEMENTING','TESTING','AUDITING','READY_TO_MERGE','MERGED','BLOCKED','SUPERSEDED','COMPLETE'}
    for t in ledger['tasks'][116:]:check('New task enum and branch '+t['id'],t['status'] in states and t['target_integration_branch']==c['target_integration_branch'])
    expected['tasks'].extend(deepcopy(c['additional_tasks']))
    cur=('updated_at','integration_branch','local_integration_branch','checkpoint_local_commit','aggregate_source_commit','aggregate_source_tree','remote_publication','current_qualification','current_handoff','continuation','main_merge_eligible','release_ready')
    hist={'recorded_at':ledger['updated_at'],'context':'Actual PR357 promotion and separate network/pilot candidate','prior_ledger_evidence':str(E/'prior-ledger-d60.json'),'prior_current_fields':{k:deepcopy(before[k]) for k in cur if k in before},'changed_tasks_before':[deepcopy(u['before']) for u in c['task_updates']],'prior_windows_recovery_837fe':deepcopy(before['windows_recovery_837fe'])}
    expected['continuation_history'].append(hist)
    expected.update(updated_at=ledger['updated_at'],integration_branch=c['target_integration_branch'],local_integration_branch=c['target_integration_branch'],checkpoint_local_commit=S,aggregate_source_commit=S,aggregate_source_tree=T,current_handoff=str(PREFIX[0]),current_qualification=deepcopy(c['current_source_qualification']),remote_publication=deepcopy(c['remote_publication']),continuation=deepcopy(c['continuation']),main_merge_eligible=False,release_ready=False)
    expected['pr357_main_promotion_837fe']=deepcopy(c['actual_pr357_promotion']);expected['network_recovery_837fe']=deepcopy(c['network_recovery'])
    w=c['windows_recovery_update'];check('Complete original Windows checkpoint before',w['before']==before['windows_recovery_837fe']);expected['windows_recovery_837fe'].update(deepcopy(w['patch']))
    check('Entire ledger equals independent complete reconstruction',ledger==expected)
    check('Whole previous history unchanged plus exact new before-entry',ledger['continuation_history'][:-1]==before['continuation_history'] and ledger['continuation_history'][-1]==hist)
    win=ledger['windows_recovery_837fe'];check('Current Windows checkpoint actual qualified merge',win['status']=='MERGED' and win['source_commit']==B and win['source_tree']==BT and win['qualification']['status']=='QUALIFIED_AND_MERGED_PR357' and win['qualification']['actual_main']==M)
    for path in PREFIX:
        old=git('show',S+':'+str(path));prefix=c['record_prefixes'][str(path)].encode();actual=(P/path).read_bytes()
        check('Entire old record once after prefix '+str(path),actual==prefix+old and actual.count(old)==1 and prefix.endswith(b'\n\n'))
    check('Both broad C5 current rows remain blocked',all(new_by[x]['status']=='BLOCKED' and new_by[x]['blockers'] for x in ['codex5-per-command-audit-gap-20261121-95fe','837fe-codex5-bounded-assessment']))
    check('All current merge/release flags remain false',ledger['main_merge_eligible'] is False and ledger['release_ready'] is False and ledger['continuation']['main_merge_eligible'] is False and ledger['continuation']['release_ready'] is False)
    check('Original181/16 census retained',ledger['network_recovery_837fe']['historical_census_unchanged']=={'unmatched':181,'patch_equivalent':16})
    PROOF.update(source=S,tree=T,outputs=72,bytes=50245691,static_inputs=61,manifest_payloads=66,original_outputs_unchanged=62,ledger_tasks=130,prior_tasks=116,notes=46,changed_prior_rows=5,unchanged_prior_rows=111,new_tasks=14,entire_ledger_reconstructed=True,transport_delta={'changed':sorted(changed),'added':sorted(added),'removed':sorted(removed)})
    save_end(c,receipt)

def save_end(c,receipt):
    # Identity and claim checks are completed by the separate bounded companion.
    check('Source HEAD/tree unchanged',git('rev-parse','HEAD').decode().strip()==S and git('rev-parse','HEAD^{tree}').decode().strip()==T)
    check('Actual owned branch matches context',git('branch','--show-current').decode().strip()==c['target_integration_branch']=='integration/patchtrace-network-recovery-20261121-837fe')
    check('Future ordered parent plan',receipt['preservation']['planned_final_record_parents']==[S,M])
    check('Final inventory has remained frozen',all(sha((P/x['path']).read_bytes())==x['sha256'] for x in receipt['outputs']))

try:run()
finally:
    PROOF.update(completed_at=datetime.now(timezone.utc).isoformat(),checks=len(CHECKS),failed=sum(not x['passed'] for x in CHECKS),product_tests_run=0)
    (O/'actual-record-checks.json').write_text(json.dumps(CHECKS,indent=2)+'\n')
    (O/'actual-record-proof.json').write_text(json.dumps(PROOF,indent=2)+'\n')
print(json.dumps({'checks':len(CHECKS),'failed':sum(not x['passed'] for x in CHECKS)}))
