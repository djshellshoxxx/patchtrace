"""Validate record claims and prospective tree without repository writes."""
from pathlib import Path
from hashlib import sha1,sha256
import json,re,subprocess

R=Path('/workspace/scratch/837fe19aae3a');O=Path(__file__).resolve().parent;P=R/'PatchTrace-network-recovery-followup'
E=Path('docs/engineering/evidence/cycle837fe-network-recovery-20261121')
S='9610919d29010d53cf00af3b7c38207ffd84f945';T='3d5e2965ef26235610a08fd8378cac078c6bd9a0';B='d60ac40daf767fe6a93ae152feb21235f6e75e0b';BT='4a07cd88ded407bef30a8aeb81961e4041822dc2';M='ea16019601486c831941f9bc1a7ba5862a170317';OM='3a16290c0fcc4e0c21712fe10474a3ff33fad336';RS='5c07bfd1a41b399fee86545206ed1c5e9aec0c26'
ROWS=[];RESULT={}
def j(name):return json.loads((P/E/name).read_bytes())
def sha(b):return sha256(b).hexdigest()
def git(*a):return subprocess.check_output(['git',*a],cwd=P)
def check(name,ok):
    ROWS.append({'check':name,'passed':bool(ok)})
    if not ok:raise AssertionError(name)
def commit(oid):
    raw=git('cat-file','commit',oid);h,msg=raw.split(b'\n\n',1);subject,_,body=msg.partition(b'\n')
    check(oid[:8]+' actual literal commit identity',re.fullmatch('[0-9a-f]{40}',oid) is not None and git('cat-file','-t',oid).strip()==b'commit' and sha1(b'commit '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==oid)
    check(oid[:8]+' both actual title/body markers',all(x in subject and x in body for x in [b'[no release]',b'[no deploy]']))
    return {'sha':oid,'parents':[x[7:].decode() for x in h.splitlines() if x.startswith(b'parent ')],'tree':next(x[5:].decode() for x in h.splitlines() if x.startswith(b'tree ')),'raw_sha256':sha(raw)}
def run():
    c=j('assembly-context.json');main=commit(M);remote=commit(RS)
    check('Actual357 exact ordered parents and tree',main['parents']==[OM,B] and main['tree']==BT)
    check('Actualmain content already incorporated',not git('diff','--name-only',B,M).strip() and subprocess.run(['git','merge-base','--is-ancestor',B,S],cwd=P).returncode==0)
    check('Verified remote source complete tree',remote['tree']==T and c['remote_publication']['verified_remote_code']==RS and c['remote_publication']['verified_code_tree']==T and c['remote_publication']['base_commit']==M)
    check('No code-ref or record publication preclaim',all(c['remote_publication'][x] is False for x in ['code_ref_published','records_published','ref_moved']))
    prep=j('network-record-preparation-independent-review.json')
    check('Exact sealed preparation235 reused',sha((P/E/'network-record-preparation-independent-review.json').read_bytes())=='b9059fa599fd7d610ba7b00b06af86022b59bb4b72ca4c3fcbd8dfc8a51a20bb' and prep['mechanical_checks']==235 and prep['blockers']==[] and not prep['final_records_approved'])
    for filename,key in [('assembly-driver.py','helper_sha256'),('record-report-template.md','template_sha256'),('record-context-builder.py','context_builder_sha256')]:check('Reviewed bytes '+filename,sha((P/E/filename).read_bytes())==prep[key])
    obj=j('network-tooling-code-object-proof.json');check('Exact seven-object verification retained',sha((P/E/'network-tooling-code-object-proof.json').read_bytes())=='318206b597943d6790b76d6a81efecf88b6daab4fd735c09603dfaac9c08f156' and len(obj['objects'])==7 and obj['source']==S and obj['tree']==T)
    check('Actual38 commits29paths retained',len(git('rev-list',B+'..'+S).splitlines())==38 and len(git('diff','--name-only',B,S).splitlines())==29)
    q=j('network-tooling-final-source-qualification.json');cq=c['current_source_qualification']
    check('Exact root source654/2 receipt retained',sha((P/E/'network-tooling-final-source-qualification.json').read_bytes())=='dc73940da64e06d8594dde7566f65c6d2e8d5e8e3c5f7975342b4ea0191ce814' and q['source']==S and q['tree']==T)
    check('Current ledger exact654pass2xf656distinct26selectors',cq['local_passed']==q['maintained']['junit']['passed']==654 and cq['local_xfailed']==2 and cq['local_unique_cases']==656 and cq['selection_node_count']==len(q['selectors'])==26 and cq['local_failed']==cq['local_errors']==cq['local_ordinary_skipped']==0)
    check('Current full/platform/manual/signature limits', 'PENDING' in cq['full_suite'] and 'PENDING' in cq['platform_native_package'] and 'UNEXECUTED_ACCESS_BLOCKED' in cq['manual_pilot_workflow'] and cq['sigstore_identity_or_artifact_verification']=='NOT_EXECUTED_OUTSIDE_DEPENDENCY_SCOPE' and cq['earlier_counts_additive'] is False)
    sig=j('sigstore-tooling-independent-review.json');pilot=j('pilot-tooling-independent-review.json');net=j('network-combined-review.json')
    for name,d,source in [('sigstore',sig,S),('pilot',pilot,'f08632ab81e6ab24fcc34fc994dd2dda2556d267')]:
        check(name+' component exact source clear',d['source']==source and d['blockers']==[] and d['verdict'].startswith('CLEAR'))
        check(name+' independent receipt bound in context',c['independent_'+name+'_review']['review_sha256']==sha((P/E/(name+'-tooling-independent-review.json')).read_bytes()))
    check('Network96 original source blocker list empty',net['source']['head']=='96baaee20f390a3f2a5629de3764d32323bb80e5' and net['source_blockers']==[])
    check('Actual census42/3/39 plus old41/40 source history',sig['census']['candidate_961']=={'workflows':21,'run_scalars':203,'installing_jobs':38,'commands':42,'protected':3,'unprotected':39} and pilot['census']['before_96']['unprotected']==41 and pilot['census']['after_f086']['unprotected']==40)
    p357=j('pr357-final-qualification.json');promo=c['actual_pr357_promotion'];peer=j('pr357-final-completion-independent-review.json');actualpeer=j('pr357-main-promotion-independent-review.json')
    check('Actual357 qualification exact source18/16/2jobs',p357['source']['head_sha']==B and p357['source']['head_tree_sha']==BT and p357['verdict']['actual_job_count']==18 and p357['verdict']['successful_executed_job_count']==promo['executed_job_successes']==16 and p357['verdict']['intentional_skipped_job_count']==promo['intentional_publication_skips']==2)
    check('Actual357 exact two runs', [x['id'] for x in p357['runs']]==promo['source_specific_runs']==[44910528283,44910528348])
    check('Actual35727WindowsPowerShellcases',p357['verdict']['actual_Windows_PowerShell_cases_passed']==27 and c['windows_recovery_update']['patch']['qualification']['actual_windows_powershell_passed']==27)
    check('Retained287completion81promotion reviews',peer['check_count']==287 and peer['failure_count']==0 and actualpeer['check_count']==81 and actualpeer['failure_count']==0 and actualpeer['actual_main']==M)
    m3=j('main3a-postmerge-qualification.json');m3peer=j('main3a-postmerge-independent-review.json')
    check('Earlier3a14/12/2 source-specific qualification',m3['source']['source_head']==OM and m3['verdict']['actual_job_count']==14 and m3['verdict']['successful_executed_job_count']==12 and m3['verdict']['intentional_skipped_job_count']==2 and m3peer['check_count']==213 and m3peer['failure_count']==0)
    native=j('main-ea160-native-checkpoint.json')
    check('Nativeea checkpoint makes no full-main or hold claim',native['source']['actual_main_sha']==M and native['verdict']['native_five_contracts_complete'] and not native['verdict']['full_main_qualification_claimed'] and not native['verdict']['all_applicable_main_jobs_complete'] and not native['verdict']['actual_release_hold_verified'])
    report=(P/'docs/engineering/cycle837fe-network-recovery-20261121.md').read_bytes();txt=report.decode()
    check('No report placeholders and exact context digest','@@' not in txt and sha(report)==c['report_sha256'])
    check('Report keeps manual/full/accuracy/count boundaries',all(s in txt for s in ['unexecuted/access-blocked','not final main qualification','Full QA remains a hosted gate','two unchanged strict C5 xfails','Earlier480/259/265 selections are not added']))
    ni=json.loads((O/'transport-nested-member-index.json').read_bytes())
    check('Report historical native summary hash actually retained','7e5dd4e9af1d224fded1d69eb9cb4934b8d18f170c3cebde2337bf61645ae771' in ni)
    # Compute Git tree IDs in memory; no hash-object -w, index or repository write.
    entries={}
    for raw in git('ls-tree','-rz',S).split(b'\0'):
        if raw:
            meta,path=raw.split(b'\t',1);mode,kind,oid=meta.decode().split();entries[path.decode()]=(mode,oid)
    def tree_id(flat):
        node={}
        for path,value in flat.items():
            cur=node;parts=path.split('/')
            for part in parts[:-1]:cur=cur.setdefault(part,{})
            cur[parts[-1]]=value
        def encode(n):
            rows=[]
            for name,value in n.items():
                directory=isinstance(value,dict); mode,oid=('40000',encode(value)) if directory else value
                rows.append((name.encode()+(b'/' if directory else b''),mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(oid)))
            raw=b''.join(value for _,value in sorted(rows));return sha1(b'tree '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
        return encode(node)
    check('Independent pure tree encoder reproduces frozen source',tree_id(entries)==T)
    receipt=json.loads((O/'transport-after-assembly-receipt.json').read_bytes())
    for row in receipt['outputs']:entries[row['path']]=('100644',row['git_blob'])
    prospective=tree_id(entries)
    RESULT.update(source=S,tree=T,actual_main=main,remote_equivalent=remote,prospective_reviewed_record_tree=prospective,prospective_tree_method='Pure in-memory Git tree encoding; no repository/index writes',planned_record_parents=[S,M],planned_remote_parents=[RS,M],root_local_counts={'passed':654,'strict_C5_xfailed':2,'distinct':656,'selectors':26},new_source_hosted_qualification='PENDING')

try:run()
finally:
    RESULT.update(check_count=len(ROWS),failed=sum(not r['passed'] for r in ROWS))
    (O/'claims-ancestry-checks.json').write_text(json.dumps(ROWS,indent=2)+'\n')
    (O/'claims-ancestry-proof.json').write_text(json.dumps(RESULT,indent=2)+'\n')
print(json.dumps(RESULT,indent=2))
