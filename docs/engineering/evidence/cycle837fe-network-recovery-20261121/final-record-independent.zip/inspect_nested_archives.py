"""Read every archived byte and inspect nested evidence manifests without extraction."""
from pathlib import Path, PurePosixPath
from hashlib import sha256
from io import BytesIO
import json
import zipfile

ROOT = Path('/workspace/scratch/837fe19aae3a')
OUT = Path(__file__).resolve().parent
REPO = ROOT / 'PatchTrace-network-recovery-followup'
EVIDENCE = REPO / 'docs/engineering/evidence/cycle837fe-network-recovery-20261121'
CONTEXT = json.loads((OUT / 'initial-assembly-context.json').read_bytes())
ARCHIVES = {}
EDGES = []
INDEX = {}
ERRORS = []

def sha(data):
    return sha256(data).hexdigest()

def visit(data, chain):
    digest = sha(data)
    EDGES.append({'chain': chain, 'sha256': digest, 'bytes': len(data)})
    if digest in ARCHIVES:
        return
    with zipfile.ZipFile(BytesIO(data)) as archive:
        infos = archive.infolist()
        names = [i.filename for i in infos]
        result = {'sha256': digest, 'first_chain': chain, 'bytes': len(data), 'members': len(infos), 'unique_names': len(names) == len(set(names)), 'crc_ok': archive.testzip() is None, 'payload_bytes': sum(i.file_size for i in infos), 'manifests': [], 'payloads': []}
        ARCHIVES[digest] = result
        if not result['unique_names'] or not result['crc_ok']:
            ERRORS.append({'chain': chain, 'reason': 'duplicate name or CRC failure'})
        payloads = {}
        manifests = []
        for info in infos:
            if info.is_dir():
                continue
            raw = archive.read(info.filename)
            item = {'path': info.filename, 'bytes': len(raw), 'sha256': sha(raw)}
            payloads[info.filename] = item
            result['payloads'].append(item)
            INDEX.setdefault(item['sha256'], []).append({'archive_sha256': digest, 'member': info.filename, 'bytes': len(raw)})
            if 'manifest' in PurePosixPath(info.filename).name.lower() and info.filename.endswith('.json'):
                try:
                    value = json.loads(raw)
                except (ValueError, UnicodeError):
                    continue
                manifests.append((info.filename, value))
            if info.filename.endswith('.zip'):
                visit(raw, chain + ['member:' + info.filename])
        for name, value in manifests:
            rows = None
            key = None
            if isinstance(value, list):
                rows, key = value, '<root-list>'
            elif isinstance(value, dict):
                for candidate in ['files', 'members', 'entries', 'artifacts', 'payloads']:
                    if isinstance(value.get(candidate), list) and any(isinstance(x, dict) and 'sha256' in x for x in value[candidate]):
                        rows, key = value[candidate], candidate
                        break
            manifest = {'path': name, 'row_key': key, 'keys': list(value) if isinstance(value, dict) else 'list', 'checked': [], 'unresolved': []}
            result['manifests'].append(manifest)
            if rows is None:
                continue
            for row in rows:
                if not isinstance(row, dict) or 'sha256' not in row:
                    continue
                rowpath = next((row[k] for k in ['path', 'file', 'name', 'relative_path', 'filename'] if isinstance(row.get(k), str)), None)
                size = next((row[k] for k in ['bytes', 'size', 'size_bytes'] if isinstance(row.get(k), int)), None)
                if rowpath is None:
                    manifest['unresolved'].append({'row': row, 'reason': 'no supported path'})
                    continue
                parent = PurePosixPath(name).parent
                candidates = [rowpath, (parent / rowpath).as_posix()]
                target = next((p for p in candidates if p in payloads), None)
                if target is None:
                    manifest['unresolved'].append({'row': row, 'reason': 'path not inside this archive'})
                    continue
                item = payloads[target]
                okay = item['sha256'] == row['sha256'] and (size is None or item['bytes'] == size)
                manifest['checked'].append({'row_path': rowpath, 'member': target, 'sha256': item['sha256'], 'bytes': item['bytes'], 'passed': okay})
                if not okay:
                    ERRORS.append({'chain': chain, 'manifest': name, 'row': row, 'actual': item})

try:
    for item in CONTEXT['static_inputs']:
        if item['name'].endswith('.zip'):
            data = (EVIDENCE / item['name']).read_bytes()
            assert len(data) == item['bytes'] and sha(data) == item['sha256']
            visit(data, [item['name']])
finally:
    report = {'unique_archives': len(ARCHIVES), 'archive_instances': len(EDGES), 'unique_member_digests': len(INDEX), 'total_members_in_unique_archives': sum(a['members'] for a in ARCHIVES.values()), 'total_payload_bytes': sum(a['payload_bytes'] for a in ARCHIVES.values()), 'checked_manifest_rows': sum(len(m['checked']) for a in ARCHIVES.values() for m in a['manifests']), 'unresolved_manifests': [{'archive_sha256': a['sha256'], 'chain': a['first_chain'], 'manifest': m} for a in ARCHIVES.values() for m in a['manifests'] if m['unresolved']], 'errors': ERRORS, 'archives': list(ARCHIVES.values()), 'archive_edges': EDGES}
    (OUT / 'nested-archive-proof.json').write_text(json.dumps(report, indent=2) + '\n')
    (OUT / 'nested-member-index.json').write_text(json.dumps(INDEX, indent=2) + '\n')
print(json.dumps({k: v for k, v in report.items() if k not in ['archives', 'archive_edges', 'unresolved_manifests']}))
print('unresolved_manifest_count', len(report['unresolved_manifests']))
for item in report['unresolved_manifests']:
    print(json.dumps({'chain': item['chain'], 'manifest': item['manifest']['path'], 'unresolved_count': len(item['manifest']['unresolved']), 'example': item['manifest']['unresolved'][:1]}))
assert not ERRORS
