from pathlib import Path
import hashlib, json, subprocess
ROOT = Path(__file__).resolve().parent
REPO = ROOT / 'PatchTrace-network-recovery-followup'
OUT = ROOT / 'evidence/network-tooling-code-publication-preparation/sigstore-append'
BASE = 'f08632ab81e6ab24fcc34fc994dd2dda2556d267'
HEAD = '9610919d29010d53cf00af3b7c38207ffd84f945'
TREE = '3d5e2965ef26235610a08fd8378cac078c6bd9a0'
REMOTE_BASE = 'af5606bc233c7e86bcac9242709ce33d42e5b420'
def git(*args): return subprocess.check_output(['git', *args], cwd=REPO)
assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert git('rev-parse', 'HEAD^{tree}').decode().strip() == TREE and not git('status', '--porcelain=v1').strip()
assert not git('diff', '--name-only', BASE, REMOTE_BASE).strip()
OUT.mkdir(exist_ok=False)
known = {line.split()[2] for line in git('ls-tree', '-r', BASE).decode().splitlines()}
order = git('rev-list', '--reverse', BASE + '..' + HEAD).decode().splitlines()
assert len(order) == 3
seen = {BASE}; commits = []; blobs = {}
for commit in order:
    parents = git('show', '-s', '--format=%P', commit).decode().split()
    assert len(parents) == 1 and parents[0] in seen
    message = git('cat-file', 'commit', commit).decode().split('\n\n', 1)[1]
    subject, _, body = message.partition('\n')
    assert all(marker in subject and marker in body for marker in ('[no release]', '[no deploy]'))
    entries = []
    for path in git('diff', '--name-only', parents[0], commit).decode().splitlines():
        raw = git('ls-tree', commit, '--', path).decode().strip()
        mode, kind, tail = raw.split(' ', 2); blob, name = tail.split('\t', 1)
        assert mode == '100644' and kind == 'blob' and name == path
        data = git('show', commit + ':' + path)
        assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == blob
        entries.append({'path': path, 'mode': mode, 'type': kind, 'sha': blob})
        if blob not in known and blob not in blobs:
            dest = OUT / 'novel-blobs' / blob; dest.parent.mkdir(exist_ok=True); dest.write_bytes(data)
            blobs[blob] = {'sha': blob, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'local_path': str(dest), 'original_source': commit, 'original_path': path}
    commits.append({'local_commit': commit, 'local_tree': git('rev-parse', commit + '^{tree}').decode().strip(), 'local_ordered_parents': parents, 'first_parent_tree': git('rev-parse', parents[0] + '^{tree}').decode().strip(), 'message': message, 'tree_elements': entries}); seen.add(commit)
plan = {'schema': 'patchtrace/tooling-git-data-publication-plan/1', 'source': HEAD, 'tree': TREE, 'base': BASE, 'remote_equivalent_base': REMOTE_BASE, 'ordered_commits': commits, 'novel_blobs': list(blobs.values()), 'source_independent_review': 'CLEAR', 'remote_objects_created': False, 'ref_moved': False, 'pr_created': False}
(OUT / 'publication-plan-v1.json').write_text(json.dumps(plan, indent=2) + '\n')
(OUT / 'prepare-driver-v1.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'commits': len(commits), 'novel_blobs': len(blobs), 'bytes': sum(x['bytes'] for x in blobs.values())}))
