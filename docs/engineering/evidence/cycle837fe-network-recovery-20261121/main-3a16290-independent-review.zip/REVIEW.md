# Independent audit of sealed main3a post-merge evidence

**Result: clear.** The bounded audit completed 213 mechanical assertions with no evidence inconsistency. It inspected only the retained sealed main3a archive and its external receipts. It makes no acceptance claim for PR357.

## Exact source and archive

Source: `3a16290c0fcc4e0c21712fe10474a3ff33fad336`; complete tree: `6001ef506c38930fd590bd827f428b997c3b2797`; ordered parents: `9023761a4066ac1c50c127ac09d0ba5f56cdc9e4`, `d6679abc6dfddbadce0391c8d18289f7f96338d6`. Retained API commit, PR351 merge and main-ref records agree. Both publication-hold markers appear in the actual merge subject and body.

The parent archive is `main-3a16290-postmerge-evidence.zip`, 3,679,987 bytes, SHA-256 `14180b596d46a22319bd07c9afc79bac7bcbc5e09819f4097f074da140d1d0a1`. Its manifest hash is `5b28af58583c93897f7695684c30a9a8c74eaa3c3ec768ab94297d39d7c5af1e`; the qualification JSON hash is `012039fd73085d30e61dd79bf47024988980df3929956ab360dd4917dbab905d`. All 90 payload hashes, the embedded manifest, exact ZIP inventory and CRCs verify.

## Actual hosted results

The retained final discovery lists exactly two automatic push runs, QA `44906524287` and Pages `44906524308`, both successful on attempt 1. Their 14 jobs comprise 12 executed successes and two publication skips. All 12 executed logs identify main3a as the actual checkout. All ten required QA jobs passed.

| Evidence | Verified result |
|---|---|
| Linux full suite | 24,295 passed; 53 skipped; 4 expected failures; 21 warnings |
| Windows full suite | 24,164 passed; 185 skipped; 3 expected failures; 22 warnings |
| Full JUnit, each platform | 24,352 cases; zero failures/errors |
| Separate boundary controls | Linux 108 passed / 2 skipped; Windows 107 passed / 3 skipped |
| Ubuntu Qt shards 1–4 | 13,320 / 10,860 / 9,840 / 8,460 passes; shard 1 has 40 warnings |
| Windows Qt | 10,620 passes; 10 warnings |
| Windows frozen CLI | 64 actual PASS lines; zero FAIL lines |
| Ubuntu 22.04 and 24.04 frozen CLI | 64 actual PASS lines and zero FAIL lines each |

Both original QA artifact ZIPs match their API lengths/digests, CRCs and extracted XML bytes. Parsed JUnit counts and exact expected-failure IDs agree with the final record. Windows build, portable checksum/extraction/runtime and installer install/launch/non-destructive uninstall are supported by the completed steps and actual receipts. Linux packaging and both smoke jobs bind to artifact `14711490994`; the download digests, tar checksum, executable extraction, offscreen/XCB self-tests and full frozen CLI steps all agree.

Large Windows/Linux product bytes were not locally downloaded. Their API metadata and hosted producer/consumer checksum/runtime receipts support the stated claims; this review does not substitute a local product-byte rehash.

## Publication holds and preserved history

Release-gate job `136853186469` actually reported `publish=true` for five counted merges. Separate release job `136880181515` was actually skipped after successful QA dependencies. The fresh retained 59-release list agrees with the copied main902 baseline on every declared identity field; no API-visible release has a publication time at or after the main3a merge at this observation cut. This does not assert equality of release asset bytes.

Pages passed 248 tests with one skip, built successfully, skipped configure-pages, uploaded its artifact successfully and skipped deploy job `136862103266`. The original nested `pages-completion-main-3a.zip` is unchanged: 1,511,254 bytes, SHA-256 `1b9cec5fed0b85fe85caf95181f14b4a1a09c7f75fb0e25c5e6685059a6031c9`. Its inventory, all payload hashes and CRCs verify. Site artifact `14709361319` and its `artifact.tar` member match the metadata and upload log. The Pages raw log is retained once inside that nested archive.

Original queued `jobs-snapshot-004.json` remains unchanged at SHA-256 `e472597adeb243cfc0a2b5ef35c34dee3e9b085463a052c38737aea587765907`. The earlier main902 Pages404 remains an explicit separate failure pointer.

Seven platform expected-failure records remain open: both CODEX-5 cases on both platforms, missing live Ghidra directory on both platforms, and missing llvm-pdbutil on Linux. Neither later Windows27 results nor untriggered native lanes are attributed to this source.

`review.json` contains the individual assertions and parsed counts. `audit.py` only reads ZIP/JSON/XML/log bytes. No network requests, tests, native/target execution, downloads, source/ref/CI changes or parent-file modifications occurred. This small review archive references the exact parent archive hash and does not duplicate its payload.
