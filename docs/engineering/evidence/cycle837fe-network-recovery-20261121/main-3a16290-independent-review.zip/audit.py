"""Parse and hash sealed evidence only; no network or project execution."""
import collections
import datetime
import hashlib
import io
import json
import pathlib
import re
import stat
import xml.etree.ElementTree as ET
import zipfile

ROOT = pathlib.Path('/workspace/scratch/837fe19aae3a/evidence/main-3a16290-publication-holds')
OUT = pathlib.Path(__file__).parent
HEAD = '3a16290c0fcc4e0c21712fe10474a3ff33fad336'
TREE = '6001ef506c38930fd590bd827f428b997c3b2797'
PARENTS = ['9023761a4066ac1c50c127ac09d0ba5f56cdc9e4','d6679abc6dfddbadce0391c8d18289f7f96338d6']
ARCHIVE = 'main-3a16290-postmerge-evidence.zip'
ARCHIVE_SHA = '14180b596d46a22319bd07c9afc79bac7bcbc5e09819f4097f074da140d1d0a1'
MANIFEST_SHA = '5b28af58583c93897f7695684c30a9a8c74eaa3c3ec768ab94297d39d7c5af1e'
QUAL_SHA = '012039fd73085d30e61dd79bf47024988980df3929956ab360dd4917dbab905d'
PAGES_SHA = '1b9cec5fed0b85fe85caf95181f14b4a1a09c7f75fb0e25c5e6685059a6031c9'
SNAPSHOT_SHA = 'e472597adeb243cfc0a2b5ef35c34dee3e9b085463a052c38737aea587765907'
checks = []
def sha(b): return hashlib.sha256(b).hexdigest()
def check(name, condition): checks.append({'name':name,'passed':bool(condition)})
def safe(name, info):
    p = pathlib.PurePosixPath(name)
    return not p.is_absolute() and '..' not in p.parts and not stat.S_ISLNK(info.external_attr >> 16)
def frozen(log): return {x:len(re.findall(r'^\S+Z '+x+r' ',log,re.M)) for x in ['PASS','FAIL']}

b = (ROOT/ARCHIVE).read_bytes()
check('Parent ZIP exact size and SHA256', len(b)==3679987 and sha(b)==ARCHIVE_SHA)
z = zipfile.ZipFile(io.BytesIO(b))
pages_container = zipfile.ZipFile(io.BytesIO(z.read('pages-completion-main-3a.zip')))
def read(name): return z.read(name) if name in z.namelist() else pages_container.read(name)
def obj(name): return json.loads(read(name))
manifest_bytes = (ROOT/'post-main-evidence-manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
receipt_bytes = (ROOT/'post-main-archive-receipt.json').read_bytes()
receipt = json.loads(receipt_bytes)
check('Parent manifest exact hash and embedded bytes', sha(manifest_bytes)==MANIFEST_SHA and read('post-main-evidence-manifest.json')==manifest_bytes)
check('Parent ZIP CRC', z.testzip() is None)
check('Parent ZIP complete inventory', len(z.namelist())==91 and len(manifest['files'])==90 and set(z.namelist())=={f['path'] for f in manifest['files']}|{'post-main-evidence-manifest.json'})
for f in manifest['files']:
    content=read(f['path'])
    check('Parent member '+f['path'], safe(f['path'],z.getinfo(f['path'])) and len(content)==f['bytes'] and sha(content)==f['sha256'])
check('External archive receipt identities', receipt['archive_sha256']==ARCHIVE_SHA and receipt['manifest_sha256']==MANIFEST_SHA and receipt['qualification_sha256']==QUAL_SHA and receipt['archive_bytes']==len(b) and receipt['archive_member_count']==len(z.namelist()))
q = obj('post-main-qualification.json')
check('Qualification exact SHA256', sha(read('post-main-qualification.json'))==QUAL_SHA and (ROOT/'post-main-qualification.json').read_bytes()==read('post-main-qualification.json'))
guard=obj('final-source-run-release-guard.json')
commit=guard['source_commit']; source=q['source']
check('Final API source/tree/ordered parents', commit['sha']==HEAD and commit['tree']['sha']==TREE and [p['sha'] for p in commit['parents']]==PARENTS)
check('Final main ref/source summary identities', guard['main_ref']['object']['sha']==HEAD and source['source_head']==HEAD and source['source_tree']==TREE and source['ordered_parents']==PARENTS)
subject,body=commit['message'].split('\n',1)
check('Both holds in actual subject and body', all(m in subject and m in body for m in ['[no release]','[no deploy]']))
pr=obj('actual-merge-pr351.json')
check('Actual PR351 merge receipt', pr['number']==351 and pr['merged'] and pr['merge_commit_sha']==HEAD and pr['head']['sha']==PARENTS[1] and pr['base']['sha']==PARENTS[0] and pr['merged_at']=='2026-11-21T12:58:35Z')
expected_runs={44906524287,44906524308}
check('Only two actual discovered source runs', guard['runs']['total_count']==2 and {r['id'] for r in guard['runs']['workflow_runs']}==expected_runs)
groups=obj('final-job-records.json')['runs']
jobs={j['id']:j for g in groups for j in g['jobs']}
check('Fourteen actual jobs,12 successful and2 skipped', len(jobs)==14 and collections.Counter(j['conclusion'] for j in jobs.values())=={'success':12,'skipped':2} and all(j['status']=='completed' and j['head_sha']==HEAD and j['run_attempt']==1 for j in jobs.values()))
check('Actual skip job IDs', {j['id'] for j in jobs.values() if j['conclusion']=='skipped'}=={136880181515,136862103266})
logs={}
for run_id in expected_runs:
    r=obj(f'final-run-{run_id}.json')
    check(f'{run_id}: completed exact-source push', r['head_sha']==HEAD and r['event']=='push' and r['status']=='completed' and r['conclusion']=='success' and r['run_attempt']==1)
for jid,j in jobs.items():
    if j['conclusion']=='skipped':
        check(f'{jid}: skipped without execution', not j['steps'] and j['runner_id'] is None)
        continue
    raw=obj(f'raw-job-{jid}.json'); log=read(f'logs/{jid}.log').decode('utf-8');logs[jid]=log
    check(f'{jid}: exact raw log binding', raw['decoded_log']==log and raw['job_record']['id']==jid and raw['run_id']==j['run_id'] and raw['head_sha']==HEAD)
    check(f'{jid}: actual checkout', raw['checkouts']==[HEAD] and bool(re.search(r'^\S+Z '+HEAD+r'\r?$',log,re.M)))
check('All12 executed logs present', len(logs)==12)
check('Summary actual run/job inventory', {r['id'] for r in q['runs']}==expected_runs and {j['id'] for r in q['runs'] for j in r['jobs']}==set(jobs))
check('Ten required QA jobs successful', len(q['qa']['required_job_ids'])==10 and all(jobs[x]['conclusion']=='success' for x in q['qa']['required_job_ids']))

full=[]; junit_rows=[]; xf=[]
for platform,jid,aid in [('Linux',136853186420,14710099824),('Windows',136853186206,14711281365)]:
    declared=q['qa']['full_pytest'][platform]
    pattern=r'^\S+Z (\d+) passed, (\d+) skipped, (\d+) xfailed, (\d+) warnings in ([0-9.]+)s'
    observed=re.findall(pattern,logs[jid],re.M)
    check(platform+': one full pytest summary',len(observed)==1)
    values=observed[0]; actual=dict(zip(['passed','skipped','xfailed','warnings','seconds'],[int(v) for v in values[:4]]+[float(values[4])]))
    check(platform+': full stdout counts', all(declared[k]==v for k,v in actual.items()) and declared['summary_line'] in logs[jid])
    ar=obj(f'qa-artifact-{platform.lower()}-{aid}.json'); ab=read(f'artifacts/{aid}/original.zip'); az=zipfile.ZipFile(io.BytesIO(ab))
    check(platform+': QA artifact identity and digest', ar['artifact']['workflow_run']['head_sha']==HEAD and ar['artifact']['workflow_run']['id']==44906524287 and len(ab)==ar['artifact']['size_in_bytes'] and 'sha256:'+sha(ab)==ar['artifact']['digest'] and sha(ab)==ar['local_zip_sha256'] and az.testzip() is None)
    check(platform+': hosted upload digest agrees', 'SHA256 digest of uploaded artifact zip is '+sha(ab) in logs[jid])
    for m in ar['members']:
        mb=az.read(m['name'])
        check(platform+': JUnit artifact member '+m['name'],len(mb)==m['bytes'] and sha(mb)==m['sha256'] and read(f"artifacts/{aid}/{m['name']}")==mb)
    for xmlname in ['qa-results.xml','pair-publication-results.xml']:
        doc=ET.fromstring(az.read(xmlname)); cases=list(doc.iter('testcase'))
        skip=[c for c in cases if c.find('skipped') is not None]
        fail=[c for c in cases if c.find('failure') is not None]; err=[c for c in cases if c.find('error') is not None]
        current_xf=[]
        for c in skip:
            s=c.find('skipped')
            if s.get('type')=='pytest.xfail': current_xf.append({'id':c.get('classname')+'::'+c.get('name'),'type':s.get('type'),'message':s.get('message')})
        row={'platform':platform,'artifact_id':aid,'path':xmlname,'test_cases':len(cases),'failures':len(fail),'errors':len(err),'skipped_including_xfails':len(skip),'xfails':current_xf}
        declared_xml=next(r for r in q['qa']['junit_reports'] if r['platform']==platform and r['path']==xmlname)
        check(platform+': exact parsed JUnit '+xmlname,row==declared_xml and not fail and not err)
        if xmlname=='qa-results.xml':
            check(platform+': JUnit/full count reconciliation',len(cases)==24352 and len(cases)-len(skip)==actual['passed'] and len(skip)-len(current_xf)==actual['skipped'] and len(current_xf)==actual['xfailed'])
            xf.extend({'platform':platform,'artifact_id':aid,**v} for v in current_xf)
        else:
            boundary=q['qa']['boundary_controls'][platform]
            check(platform+': boundary independently counted',len(cases)==110 and len(cases)-len(skip)==boundary['passed'] and len(skip)==boundary['skipped'])
        junit_rows.append(row)
    full.append({'platform':platform,**actual})
check('All7 platform expected failures remain open',xf==q['open_gates']['actual_expected_failures'] and len(xf)==7 and q['open_gates']['CODEX5_repository_wide_hash_closure_remains_open'] and q['open_gates']['TierW_native_tool_blocks_remain_open'])
qt=q['qa']['qt']
check('All five Qt jobs/count mapping',len(qt)==5 and {r['job_id']:r['passed'] for r in qt}=={136853186439:13320,136853186409:10860,136853186517:9840,136853186511:8460,136853186471:10620})
for r in qt:
    log=logs[r['job_id']];matches=re.findall(r'^\S+Z (\d+) passed(?:, (\d+) warnings)? in ([0-9.]+)s',log,re.M)
    check(str(r['job_id'])+': Qt stdout independently parsed',len(matches)==1 and int(matches[0][0])==r['passed'] and int(matches[0][1] or 0)==r['warnings'] and float(matches[0][2])==r['seconds'] and r['summary_line'] in log)

win=q['qa']['windows_producer']; wl=logs[win['job_id']]
check('Windows frozen actual64PASS0FAIL',frozen(wl)=={'PASS':64,'FAIL':0} and win['frozen_cli']['passed']==64 and win['frozen_cli']['failed']==0)
for key in ['portable_smoke','installer_smoke']:
    check('Windows '+key,win[key]['passed'] and win[key]['receipt_line'] in wl)
check('Windows installer checksum', 'SHA-256: '+win['installer_smoke']['installer_sha256'] in wl)
for s in win['required_job_steps']:
    check('Windows executed step '+s['name'],s['conclusion']=='success' and s in jobs[win['job_id']]['steps'])
products=[win['product_artifact'],q['qa']['linux_package']['product_artifact']]
for p,jid in zip(products,[136853186206,136878394950]):
    api=next(a for a in guard['qa_artifacts']['artifacts'] if a['id']==p['id'])
    check(str(p['id'])+': product source/digest/API/upload binding',api['workflow_run']['id']==44906524287 and api['workflow_run']['head_sha']==HEAD and api['digest']==p['digest'] and api['size_in_bytes']==p['size_in_bytes'] and 'SHA256 digest of uploaded artifact zip is '+p['digest'].removeprefix('sha256:') in logs[jid])
check('Large products not claimed locally downloaded',q['artifacts']['large_product_binaries_downloaded_locally'] is False)
smokes=q['qa']['linux_frozen_smokes']; lp=q['qa']['linux_package']['product_artifact']
check('Both Ubuntu frozen jobs', {r['name'] for r in smokes}=={'linux-smoke (ubuntu-22.04)','linux-smoke (ubuntu-24.04)'})
for r in smokes:
    jid=r['job_id'];log=logs[jid];steps=jobs[jid]['steps']
    check(f'{jid}: actual frozen64PASS0FAIL',frozen(log)=={'PASS':64,'FAIL':0} and r['passed']==64 and r['failed']==0)
    check(f'{jid}: actual same artifact download/digest',r['downloaded_product_id']==lp['id'] and r['downloaded_artifact_digest']==lp['digest'] and f"(ID: {lp['id']}, Size: {lp['size_in_bytes']}, Expected Digest: {lp['digest']})" in log and 'SHA256 digest of downloaded artifact is '+lp['digest'].removeprefix('sha256:') in log)
    check(f'{jid}: tar checksum and executable extraction',bool(re.search(r'^\S+Z PatchTrace-0.1.0-linux-x86_64.tar.gz: OK\r?$',log,re.M)) and any('tar xzf PatchTrace-0.1.0-linux-x86_64.tar.gz && test -x PatchTrace/PatchTrace' in s['name'] and s['conclusion']=='success' for s in steps))
    check(f'{jid}: offscreen/XCB/fullCLI success',all(any(fragment in s['name'] and s['conclusion']=='success' for s in steps) for fragment in ['QT_QPA_PLATFORM=offscreen PatchTrace/PatchTrace --self-test','QT_QPA_PLATFORM=xcb xvfb-run -a PatchTrace/PatchTrace --self-test','Full frozen Linux CLI smoke (CODEX-14)']))

hold=q['qa']['release_hold'];gate=hold['release_gate']
check('Actual release gate true5 separately successful',gate['publish'] is True and gate['milestones']==5 and gate['actual_summary_line'] in logs[gate['job_id']] and jobs[gate['job_id']]['conclusion']=='success')
check('Actual release136880181515 skipped',hold['actual_release']['job_id']==136880181515 and jobs[136880181515]['name']=='release' and jobs[136880181515]['conclusion']=='skipped' and not jobs[136880181515]['steps'])
sources=obj('pinned-workflow-sources.json')['sources'];qa_source=next(s['decoded_source'] for s in sources if s['path'].endswith('qa-windows.yml'));pages_source=next(s['decoded_source'] for s in sources if s['path'].endswith('pages.yml'))
check('Actual no-release condition preserved',hold['source_condition'] in qa_source and '[no release]' in commit['message'])

pb=read('pages-completion-main-3a.zip');pz=zipfile.ZipFile(io.BytesIO(pb));pm=json.loads(pz.read('pages-completion-evidence-manifest.json'))
check('Nested original Pages archive unchanged',len(pb)==1511254 and sha(pb)==PAGES_SHA and pb==(ROOT/'pages-completion-main-3a.zip').read_bytes())
check('Nested Pages CRC/inventory',pz.testzip() is None and len(pz.namelist())==11 and set(pz.namelist())=={f['path'] for f in pm['files']}|{'pages-completion-evidence-manifest.json'})
for f in pm['files']:
    content=pz.read(f['path']);check('Pages member '+f['path'],safe(f['path'],pz.getinfo(f['path'])) and len(content)==f['bytes'] and sha(content)==f['sha256'])
page=json.loads(pz.read('pages-hold-completion.json'));site=page['artifact'];sid=site['artifact']['id'];sb=pz.read(site['local_original_zip']);sz=zipfile.ZipFile(io.BytesIO(sb))
check('Original Pages site artifact hash/length/source',sid==14709361319 and len(sb)==1474056 and site['artifact']['digest']=='sha256:'+sha(sb) and sha(sb)=='05ddfa1ef706a548101d6e2a6aabffbf349243f53e0a44dcc4c04b674c32b79d' and site['artifact']['workflow_run']['head_sha']==HEAD and site['artifact']['workflow_run']['id']==44906524308)
check('Site artifact ZIP CRC/inventory',sz.testzip() is None and sz.namelist()==['artifact.tar'])
for f in site['members']:
    content=sz.read(f['name']);check('Site payload '+f['name'],len(content)==f['bytes'] and sha(content)==f['sha256'])
check('Pages raw log retained once in nested archive', 'logs/136853186416.log' not in z.namelist() and pz.read('logs/136853186416.log').decode('utf-8')==logs[136853186416])
ps=jobs[136853186416]['steps']
check('Actual configure skip/upload success/build success',jobs[136853186416]['conclusion']=='success' and any('actions/configure-pages@983d7736d9b0ae728b81ab479565c72886d7745b' in s['name'] and s['conclusion']=='skipped' for s in ps) and any('actions/upload-pages-artifact@56afc609e74202658d3ffba0e8f6dda462b719fa' in s['name'] and s['conclusion']=='success' for s in ps) and any(s['name']=='Build the site into site/dist' and s['conclusion']=='success' for s in ps))
check('Actual Pages deploy skipped with successful build',jobs[136862103266]['name']=='deploy' and jobs[136862103266]['conclusion']=='skipped' and jobs[136853186416]['conclusion']=='success')
check('Pages site248pass1skip and uploaded artifact digest',page['site_tests']['passed']==248 and page['site_tests']['skipped']==1 and page['site_tests']['summary_line'] in logs[136853186416] and 'SHA256 digest of uploaded artifact zip is '+sha(sb) in logs[136853186416])
check('No-deploy condition retained in Pages source',pages_source.count("!contains(github.event.head_commit.message, '[no deploy]')")==2)
snap=obj('jobs-snapshot-004.json');sj=next(j for g in snap['jobs'] for j in g['jobs'] if j['id']==136853186416)
check('Original snapshot004 immutable queued cut',sha(read('jobs-snapshot-004.json'))==SNAPSHOT_SHA and (ROOT/'jobs-snapshot-004.json').read_bytes()==read('jobs-snapshot-004.json') and snap['observed']['current_time']=='2026-11-21 13:22:29 UTC' and sj['status']=='queued' and sj['runner_id']==0 and not sj['steps'])

comparison=obj('release-baseline-comparison.json');baseline=obj('release-baseline-main902.json');fields=comparison['compared_fields'];current=guard['releases']
select=lambda rows:{r['id']:{k:r.get(k) for k in fields} for r in rows}
check('Release baseline exact copied hash',sha(read('release-baseline-main902.json'))==comparison['baseline_sha256'])
check('Fresh59-release identity list unchanged',len(current)==len(baseline['releases'])==59 and select(current)==select(baseline['releases']) and comparison['release_identity_list_unchanged'] and not comparison['added_ids'] and not comparison['removed_ids'] and not comparison['changed_release_identity_ids'])
check('No API-visible release published after main3a merge',not [r for r in current if r.get('published_at') and r['published_at']>=source['merged_at']] and not comparison['releases_published_at_or_after_source_merge'])
check('Prior902 Pages failure remains explicit',q['prior_publication_failure']['failed_job_id']==136802040292 and q['prior_publication_failure']['run_id']==44889511406 and q['prior_publication_failure']['archive_sha256']=='74d7390d7ded8087bc6869bab34c997e16e63a4a77d5b7f75d8291da0c3052bf')
failures=[c for c in checks if not c['passed']]
report={'schema':'patchtrace/sealed-main-evidence-independent-audit/1','completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'verdict':'clear' if not failures else 'inconsistency_found','scope':'Read-only audit of sealed main3a automatic post-merge QA and publication holds. Does not qualify PR357.','source':{'head':HEAD,'tree':TREE,'ordered_parents':PARENTS},'parent_archive':{'path':str(ROOT/ARCHIVE),'bytes':len(b),'sha256':sha(b),'manifest_sha256':MANIFEST_SHA,'qualification_sha256':QUAL_SHA,'external_receipt_sha256':sha(receipt_bytes),'members':len(z.namelist()),'payloads':len(manifest['files'])},'nested_pages_archive':{'sha256':sha(pb),'bytes':len(pb),'members':len(pz.namelist()),'site_artifact_id':sid,'site_artifact_sha256':sha(sb)},'snapshot004_sha256':SNAPSHOT_SHA,'check_count':len(checks),'failure_count':len(failures),'checks':checks,'full_platform_counts':full,'qt_counts':[{'job_id':r['job_id'],'name':r['name'],'passed':r['passed'],'warnings':r['warnings']} for r in qt],'parsed_junit':junit_rows,'expected_failure_records':xf,'actual_jobs':{'count':14,'executed_success':12,'publication_skips':[136880181515,136862103266]},'release_identity_comparison':{'current_count':59,'baseline_count':59,'unchanged':True,'scope':'Compared retained API-visible release identity fields; release asset byte equality is not asserted.'},'limitations':['No fresh API query or run triggered by this review. Exact source identity is checked against retained API/log records.','Large Windows/Linux product binaries are not present; their metadata and actual hosted producer/consumer checksum/runtime receipts are checked.','Seven platform expected-failure records remain open. No native coverage or Windows27 results transfer from later PR357.'],'network_reads':False,'product_test_or_native_execution':False,'source_ref_CI_or_parent_evidence_changes':False}
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'checks':len(checks),'failures':failures,'review_sha256':sha((OUT/'review.json').read_bytes()),'full':full,'qt':report['qt_counts'],'xfails':len(xf)},indent=2))
