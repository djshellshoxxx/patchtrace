"""Bounded immutable publication-object and proof-only append check."""
import hashlib
import json
import shutil
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/workspace/scratch/837fe19aae3a')
OUT = ROOT/'evidence/windows-final-publication-independent'
PRE = ROOT/'evidence/windows-recovery-records-independent/final-assembled'
REPO = ROOT/'PatchTrace-windows-recovery-followup'
LOCAL = 'e76856c3801304a8a1990bd00bc98d761c6b2213'
REMOTE = 'd60ac40daf767fe6a93ae152feb21235f6e75e0b'
TREE = '4a07cd88ded407bef30a8aeb81961e4041822dc2'
SOURCE = 'f596471b8909ec8e28e0624041d60f03d520591d'
R_SOURCE = '4202e5e79e2aea6366c75261d74544ea48368ca5'
MAIN = '3a16290c0fcc4e0c21712fe10474a3ff33fad336'
EV = 'docs/engineering/evidence/cycle837fe-windows-recovery-20261121/'
ADDED = {'assembled-record-qualification.json','assembled-record-validation.zip','final-assembled-independent-review.json','final-assembled-independent.zip','post-review-evidence-addition.json','pre-independent-review-manifest.json'}
checks = []

def check(label, condition):
    assert condition, label
    checks.append(label)

def sha(b):
    return hashlib.sha256(b).hexdigest()

def oid(kind, b):
    return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()

def git(*args):
    return subprocess.check_output(['git','-C',str(REPO),*args])

def blob(rev, p):
    return git('show',f'{rev}:{p}')

def tree(rev):
    answer = {}
    for row in git('ls-tree','-r','-z',rev).split(b'\0'):
        if row:
            left, path = row.split(b'\t',1)
            mode, kind, ident = left.decode().split()
            answer[path.decode()] = (mode,kind,ident)
    return answer

api = json.loads((OUT/'fresh-remote-commit.json').read_text())
pr = json.loads((OUT/'fresh-pr357.json').read_text())
messages = []
for rev, parents in [(LOCAL,[SOURCE,MAIN]),(REMOTE,[R_SOURCE,MAIN])]:
    raw = git('cat-file','commit',rev); (OUT/f'commit-{rev}.txt').write_bytes(raw)
    check(rev+' exact commit hash',oid('commit',raw)==rev)
    header, message = raw.decode().split('\n\n',1)
    check(rev+' exact tree',header.splitlines()[0]=='tree '+TREE)
    check(rev+' ordered parents',[x[7:] for x in header.splitlines() if x.startswith('parent ')]==parents)
    subject, body = message.split('\n',1)
    check(rev+' both markers subject and body',all(t in subject and t in body for t in ['[no release]','[no deploy]']))
    messages.append(message)
check('local and remote complete tree identity',tree(LOCAL)==tree(REMOTE) and not git('diff','--name-only',LOCAL,REMOTE))
check('actual tree content hash',oid('tree',git('cat-file','tree',TREE))==TREE)
check('actual local and remote message content identical; recorded terminal LF representation difference only',messages[0].rstrip('\n')==messages[1].rstrip('\n'))
check('fresh REST remote object matches',api['sha']==REMOTE and api['tree']['sha']==TREE and [x['sha'] for x in api['parents']]==[R_SOURCE,MAIN] and api['message'].rstrip()==messages[1].rstrip())
check('fresh PR357 exact publication',pr['number']==357 and pr['state']=='open' and not pr['merged'] and pr['head']['sha']==REMOTE and pr['base']['sha']==MAIN and pr['base']['ref']=='main')
check('worktree clean at exact local commit',git('rev-parse','HEAD').decode().strip()==LOCAL and not git('status','--porcelain=v1','--untracked-files=all') and not git('ls-files','-u'))
check('source local and remote code same complete tree',tree(SOURCE)==tree(R_SOURCE))
check('actual main is an ancestor',subprocess.run(['git','-C',str(REPO),'merge-base','--is-ancestor',MAIN,LOCAL],capture_output=True).returncode==0)
inventory=json.loads((PRE/'assembled-file-inventory.json').read_text())
old_paths={x['path'] for x in inventory}
changed=set(git('diff-tree','-r','--no-commit-id','--name-only',SOURCE,LOCAL).decode().splitlines())
check('exact first-parent 102-record delta',len(changed)==102 and changed==old_paths|{EV+x for x in ADDED})
for row in inventory:
    if row['path']==EV+'manifest.json': continue
    b=blob(LOCAL,row['path'])
    check('sealed output preserved '+row['path'],sha(b)==row['sha256'] and len(b)==row['bytes'])
base_tree=tree(SOURCE); final_tree=tree(LOCAL)
check('all other source and modes preserved',all(final_tree.get(p)==v for p,v in base_tree.items() if p not in changed))
check('no deletions or executable modes introduced',all(p in final_tree and final_tree[p][:2]==('100644','blob') for p in changed))
preserved=blob(LOCAL,EV+'pre-independent-review-manifest.json')
check('old outer manifest copied byte-exact',preserved==(PRE/'manifest-reviewed.json').read_bytes() and sha(preserved)=='f27d58dc196f6f4ff9c52673f52efc06c45fbf92dbdf5507f8fc922723f729f1')
bindings={'final-assembled-independent-review.json':PRE/'review.json','final-assembled-independent.zip':PRE/'final-assembled-independent.zip','assembled-record-qualification.json':PRE/'root-record-qualification.json','assembled-record-validation.zip':PRE/'root-assembled-record-validation.zip'}
for name,path in bindings.items():
    check('new immutable proof binding '+name,blob(LOCAL,EV+name)==path.read_bytes())
manifest_b=blob(LOCAL,EV+'manifest.json');manifest=json.loads(manifest_b)
check('new outer manifest exact advertised digest',sha(manifest_b)=='50933fd689018ae06dbfb49260a28cde17668dee0c56120ce46c238f85c5f59f')
check('outer manifest full payload coverage',len(manifest['payloads'])==93 and {EV+x['path'] for x in manifest['payloads']}=={p for p in final_tree if p.startswith(EV)}-{EV+'manifest.json'})
old_manifest=json.loads(preserved)
check('all prior payload rows exact',manifest['payloads'][:87]==old_manifest['payloads'])
for row in manifest['payloads']:
    b=blob(LOCAL,EV+row['path'])
    check('final payload binding '+row['path'],len(b)==row['bytes'] and sha(b)==row['sha256'])
addition=json.loads(blob(LOCAL,EV+'post-review-evidence-addition.json'))
expected_rows=sorted([{k:x[k] for k in ('path','bytes','sha256')} for x in inventory],key=lambda x:x['path'])
check('append receipt original inventory exact',sorted(addition['reviewed_outputs'],key=lambda x:x['path'])==expected_rows)
check('append receipt unchanged scope',addition['only_existing_file_modified']=='manifest.json' and not addition['current_docs_ledger_context_report_source_changed'] and addition['reviewed_manifest_sha256']==sha(preserved))
check('append receipt five payload additions plus self',{x['path'] for x in addition['additions']}==ADDED-{'post-review-evidence-addition.json'})
for row in addition['additions']:
    b=blob(LOCAL,EV+row['path']);check('append receipt exact file '+row['path'],len(b)==row['bytes'] and sha(b)==row['sha256'])
for name in ['manifest.json','post-review-evidence-addition.json']:(OUT/name).write_bytes(blob(LOCAL,EV+name))
shutil.copyfile(ROOT/'windows-recovery-final-publication-mapping.json',OUT/'publication-mapping.json')
shutil.copyfile(PRE/'review.json',OUT/'prior-assembled-review.json')
(OUT/'reviewed-output-inventory.json').write_bytes((PRE/'assembled-file-inventory.json').read_bytes())
review={'schema':'patchtrace/windows-final-publication-independent/1','observed_at':datetime.now(timezone.utc).isoformat(),'verdict':'CLEAR_EXACT_FINAL_OBJECT_AND_PROOF_ONLY_APPEND','blockers':[],'local_commit':LOCAL,'remote_commit':REMOTE,'complete_tree':TREE,'local_ordered_parents':[SOURCE,MAIN],'remote_ordered_parents':[R_SOURCE,MAIN],'both_markers_separately_in_subject_and_body':True,'fresh_PR':{'number':357,'state':pr['state'],'head':pr['head']['sha'],'base':pr['base']['sha'],'created_at':pr['created_at']},'original_95_non_manifest_outputs_preserved':True,'original_manifest_byte_exact_copy':True,'exact_six_new_proof_files':sorted(ADDED),'first_parent_record_delta_files':102,'protected_source_and_all_other_tracked_bytes_modes_preserved':True,'final_manifest_sha256':sha(manifest_b),'check_count':len(checks),'checks':checks,'previous_674_record_checks_not_repeated':True,'new_product_native_tests_run':0,'source_refs_PR_CI_mutations':False,'final_hosted_qualification_claimed':False,'main_merge_eligible':False,'release_ready':False,'remaining':'Exact published d60/PR357 head must pass required hosted/full/platform/native/27 Windows cases and guarded merge conditions; broader gates and all author holds remain.'}
(OUT/'review.json').write_text(json.dumps(review,indent=2)+'\n')
(OUT/'REVIEW.md').write_text(f'# Final publication object review\n\n**Clear: exact final objects and proof-only append; no blocker.**\n\nLocal `{LOCAL}` and remote `{REMOTE}` have complete tree `{TREE}` and the expected ordered parents. Actual raw commit hashes, tree hash, fresh remote REST object and PR357 metadata agree. Both actual subject and body retain both opt-out markers. The local worktree is clean.\n\nAll 95 previously reviewed non-manifest outputs are byte-identical; the original manifest is preserved exactly. The only additions are the six listed immutable review/validation/proof files, and the outer manifest is refreshed to 93 payloads. All protected source and other tracked file/mode identities remain unchanged. The first-parent records delta has 102 paths.\n\n{len(checks)} bounded object/binding checks passed. No prior 674-case semantic review or product/native tests were repeated. No source/ref/PR/CI mutation was made. Final-source hosted qualification and guarded main promotion remain pending; this review does not claim merge eligibility or release readiness.\n')
files=sorted(x for x in OUT.rglob('*') if x.is_file());rows=[{'path':str(x.relative_to(OUT)),'bytes':x.stat().st_size,'sha256':sha(x.read_bytes())} for x in files]
mf=OUT/'evidence-manifest.json';mf.write_text(json.dumps({'schema':'patchtrace/evidence-manifest/1','files':rows,'lists_itself':False},indent=2)+'\n')
archive=OUT/'windows-final-publication-independent.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for x in files+[mf]:z.write(x,str(x.relative_to(OUT)))
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for row in rows:assert sha(z.read(row['path']))==row['sha256']
receipt={'archive_file':archive.name,'archive_bytes':archive.stat().st_size,'archive_members':len(rows)+1,'archive_sha256':sha(archive.read_bytes()),'manifest_sha256':sha(mf.read_bytes()),'review_sha256':sha((OUT/'review.json').read_bytes()),'check_count':len(checks),'all_crc_and_member_hashes_verified':True}
(OUT/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
