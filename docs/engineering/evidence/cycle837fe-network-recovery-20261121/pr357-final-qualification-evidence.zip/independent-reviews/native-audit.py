"""Read-only retained-evidence audit; does not import project code or execute fixtures."""
import ast
import collections
import datetime
import hashlib
import json
import pathlib
import re
import stat
import zipfile

ROOT = pathlib.Path('/workspace/scratch/837fe19aae3a/evidence/final-d60-qualification')
OUT = pathlib.Path(__file__).parent
HEAD = 'd60ac40daf767fe6a93ae152feb21235f6e75e0b'
TREE = '4a07cd88ded407bef30a8aeb81961e4041822dc2'
BASE = '3a16290c0fcc4e0c21712fe10474a3ff33fad336'
MERGE = '254d26e58ef03a03e50c78b5f90c6ef7d9bf9e57'
RUN = 44910528348
PIN = 'c3b458661d69e26e203d739c0c82d143cc8a4a29d9e571f099c2cf4bda62a120'
checks = []
inputs = {}

def check(name, condition):
    checks.append({'name': name, 'passed': bool(condition)})

def data(name):
    path = ROOT / name
    value = path.read_bytes()
    inputs[name] = {'bytes': len(value), 'sha256': hashlib.sha256(value).hexdigest()}
    return value

def obj(name):
    return json.loads(data(name))

def blob(text):
    b = text.encode('utf-8')
    return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()

summary = obj('native-summary.json')
identity = obj('initial-source-and-runs.json')
plan = obj('required-gate-plan.json')
run = obj(f'final-run-{RUN}.json')
jobs = obj('final-native-job-records.json')['jobs']
meta = obj('final-native-artifact-metadata.json')['artifacts']
diff = obj('source-tree-diff.json')
check('Native summary immutable hash', inputs['native-summary.json']['sha256'] == 'cbaaa286b375672c158d1daa6db63b3f10a66be0d5c23ea31a9d03d5aac87aa5')
check('API head and complete tree', identity['head']['sha'] == HEAD and identity['head']['tree']['sha'] == TREE)
check('API synthetic and complete tree', identity['merge']['sha'] == MERGE and identity['merge']['tree']['sha'] == TREE)
check('API synthetic ordered parents', [p['sha'] for p in identity['merge']['parents']] == [BASE, HEAD])
check('PR head/base/merge identities', identity['pr']['head']['sha'] == HEAD and identity['pr']['base']['sha'] == BASE and identity['pr']['merge_commit_sha'] == MERGE)
check('Retained complete-tree receipt', identity['tree_receipt']['sha'] == TREE and identity['tree_receipt']['truncated'] is False)
check('Final native event/head/attempt/conclusion', run['event'] == 'pull_request' and run['head_sha'] == HEAD and run['run_attempt'] == 1 and run['status'] == 'completed' and run['conclusion'] == 'success')
check('Five distinct native jobs', len(jobs) == 5 and len({j['id'] for j in jobs}) == 5)
check('Native summary does not claim full qualification', summary['scope_closes_only_five_native_contracts'] and summary['full_repository_qualification_claimed'] is False)
check('Gate plan makes no execution claim', plan['actual_execution_acceptance_claimed'] is False)

workflows = obj('pinned-workflow-sources.json')['sources']
workflow_texts = {s['path']: s['decoded_source'] for s in workflows}
for s in workflows:
    check('Workflow Git blob: ' + s['path'], blob(s['decoded_source']) == s['final_tree_blob_sha'] == plan['workflow_blobs'][s['path']])
    check('Workflow final source identity: ' + s['path'], s['bound_to_final_head'] == HEAD and s['same_blob_as_fetched_checkpoint'] is True)
native_source = workflow_texts['.github/workflows/live-backend.yml']
qa_source = workflow_texts['.github/workflows/qa-windows.yml']
ordered_fragments = ["$ErrorActionPreference = 'Stop'", "Get-FileHash -LiteralPath $archive -Algorithm SHA256", "Remove-Item -LiteralPath ghidra-runtime -Recurse -Force", "Expand-Archive -LiteralPath $archive -DestinationPath ghidra-runtime", '"GHIDRA_INSTALL_DIR=$ghidra"']
positions = [native_source.index(f) for f in ordered_fragments]
check('Native source hashes before fresh extraction/export', positions == sorted(positions))
check('Original archive key and pin', 'key: ghidra-archive-v1-${{ env.GHIDRA_SHA256 }}' in native_source and 'GHIDRA_SHA256: ' + PIN in native_source)

cache_outcomes = []
positives = []
for job in jobs:
    jid = job['id']
    raw = obj(f'raw-job-{jid}.json')
    log = data(f'logs/{jid}.log').decode('utf-8')
    check(f'{jid}: raw log exact retained bytes', raw['decoded_log'] == log)
    check(f'{jid}: successful source-specific attempt', job['head_sha'] == HEAD and job['run_id'] == RUN and job['run_attempt'] == 1 and job['conclusion'] == 'success')
    check(f'{jid}: actual checkout line', bool(re.search(r'^\S+Z ' + MERGE + r'\r?$', log, re.M)))
    check(f'{jid}: raw checkout receipt', raw['head_sha'] == HEAD and raw['run_id'] == RUN and raw['checkouts'] == [MERGE] and raw['expected_checkout'] == MERGE)
    receipt = obj(f'original-ghidra-archive-cache-{jid}.json')
    cache = receipt['original_archive_cache']
    miss = bool(re.search(r'^\S+Z Cache not found for input keys: ghidra-archive-v1-' + PIN + r'\r?$', log, re.M))
    hit = bool(re.search(r'^\S+Z Cache restored from key: ghidra-archive-v1-' + PIN + r'\r?$', log, re.M))
    mode = 'miss' if miss else 'hit' if hit else 'unresolved'
    saved = 'Cache saved with key: ghidra-archive-v1-' + PIN in log
    declined = 'Failed to save: Unable to reserve cache with key ghidra-archive-v1-' + PIN in log
    skipped = 'Cache hit occurred on the primary key ghidra-archive-v1-' + PIN + ', not saving cache.' in log
    save = 'saved' if saved else 'reservation_declined' if declined else 'primary_key_hit_save_skipped' if skipped else 'unresolved'
    check(f'{jid}: cache mode and post-save', mode == cache['status'] and save == cache['post_save_outcome'] and miss != hit and sum([saved, declined, skipped]) == 1)
    check(f'{jid}: actual hash verification line', bool(re.search(r'^\S+Z Verified Ghidra archive SHA-256: ghidra-archive/ghidra.zip \(' + PIN + r'\)\r?$', log, re.M)))
    step = next(s for s in job['steps'] if s['name'] == 'Install pinned Ghidra (verify archive before fresh extraction)')
    check(f'{jid}: fresh extraction step successful', step['status'] == 'completed' and step['conclusion'] == 'success' and step == cache['fresh_extraction_step'])
    row = next(r for r in summary['original_Ghidra_archive_cache']['per_job'] if r['job_id'] == jid)
    check(f'{jid}: summary cache attribution', row['mode'] == mode and row['post_save'] == save)
    for key in ['verification_lines','save_lines','skip_lines','reservation_declined_lines']:
        check(f'{jid}: summary {key} exist in raw log', all(line in log for line in row[key]))
    positive = re.findall(r'^\S+Z Known patch accepted: (\d+) change records\r?$', log, re.M)
    if positive:
        positives.append(jid)
        check(f'{jid}: exactly one known patch change', positive == ['1'])
    cache_outcomes.append({'job_id': jid, 'mode': mode, 'post_save': save, 'checkout': MERGE})
check('Three distinct positive variants', sorted(positives) == sorted(summary['actual_outcomes']['positive_job_ids']) and len(positives) == 3)
negative = summary['actual_outcomes']['expected_negative_cached_pdb_control']
negative_log = data(f"logs/{negative['job_id']}.log").decode('utf-8')
check('Expected-negative control preserved', negative['contract_passed'] and not negative['positive_analysis_claimed'] and all(x in negative_log for x in negative['actual_error_lines']) and 'FileExistsError: Symbols are disabled, but the symbol is already downloaded' in negative_log)
check('Cache aggregate 3 misses/2 hits and 1 save/2 declines/2 skips', collections.Counter(c['mode'] for c in cache_outcomes) == {'miss':3,'hit':2} and collections.Counter(c['post_save'] for c in cache_outcomes) == {'saved':1,'reservation_declined':2,'primary_key_hit_save_skipped':2})

artifact_rows = []
for a in meta:
    aid = a['id']
    receipt = obj(f'artifact-{aid}.json')
    path = f'artifacts/{aid}/original.zip'
    b = data(path)
    sha = hashlib.sha256(b).hexdigest()
    check(f'{aid}: artifact API source', a['workflow_run']['head_sha'] == HEAD and a['workflow_run']['id'] == RUN)
    check(f'{aid}: outer ZIP API length/digest', len(b) == a['size_in_bytes'] == receipt['local_zip_bytes'] and a['digest'] == 'sha256:' + sha and receipt['local_zip_sha256'] == sha)
    with zipfile.ZipFile(ROOT/path) as z:
        check(f'{aid}: CRC', z.testzip() is None)
        check(f'{aid}: complete member inventory', set(z.namelist()) == {m['name'] for m in receipt['members']})
        for m in receipt['members']:
            name = m['name']; info = z.getinfo(name); content = z.read(name)
            safe = not pathlib.PurePosixPath(name).is_absolute() and '..' not in pathlib.PurePosixPath(name).parts and not stat.S_ISLNK(info.external_attr >> 16)
            check(f'{aid}: member {name}', safe and len(content) == m['bytes'] and hashlib.sha256(content).hexdigest() == m['sha256'])
            extracted = ROOT/'artifacts'/str(aid)/'extracted'/name
            if extracted.exists():
                check(f'{aid}: retained extraction equals ZIP {name}', extracted.read_bytes() == content)
        for record in receipt['selected_records']:
            check(f'{aid}: selected record exact', json.loads(z.read(record['member'])) == record['data'])
            if record['member'].endswith('/backend-execution.json'):
                summary_record = next(r for r in summary['backend_execution_records'] if r['artifact_id'] == aid and r['member'] == record['member'])
                check(f'{aid}: summary backend execution record exact', summary_record['record'] == record['data'] and record['data']['returncode'] == 0 and record['data']['stop_reason'] == 'exited')
        if aid == 14709594641:
            cache_result = json.loads(z.read('live-cache-diagnostics/result.json'))
            first = json.loads(z.read('live-cache-diagnostics/first.json'))
            second = json.loads(z.read('live-cache-diagnostics/second.json'))
            check('App cache diagnostic artifact contains only three JSON records', len(z.namelist()) == 3 and all(n.startswith('live-cache-diagnostics/') and n.endswith('.json') for n in z.namelist()))
    artifact_rows.append({'id':aid,'bytes':len(b),'sha256':sha,'member_count':len(receipt['members'])})

raw_cache = obj('application-raw-cache-result.json')
check('Summary preserves exact application-cache receipt', raw_cache == summary['actual_outcomes']['application_raw_cache'])
check('App cache acceptance from original ZIP JSON', cache_result['status'] == raw_cache['status'] == 'passed' and cache_result['phase'] == 'acceptance')
check('App cache phases match original ZIP JSON', first['run'] == raw_cache['first_run'] and second['run'] == raw_cache['second_run'] and first['java_probes'] == raw_cache['java_probes_first'] and second['java_probes'] == raw_cache['java_probes_second'])
check('App cache digest/count/events match original ZIP JSON', first['raw_sha256'] == raw_cache['first_raw_sha256'] and second['raw_sha256'] == raw_cache['second_raw_sha256'] and first['match_count'] == second['match_count'] == raw_cache['match_count_each'] and [e for e in second['events'] if e['stage'] == 'cache'] == raw_cache['second_cache_events'])
check('App raw cache equal diagnostic hashes', raw_cache['first_raw_sha256'] == raw_cache['second_raw_sha256'] == '0095038a9d3e6026fa500cece69ddd93ab8882325d932ea31512f3d62bd00a42')
check('App raw cache records completed', raw_cache['first_run']['status'] == raw_cache['second_run']['status'] == 'completed' and raw_cache['match_count_each'] == 1)
check('App raw cache explicitly reused', {'stage':'cache','message':'raw output reused from cache'} in raw_cache['second_cache_events'])

source_doc = obj('pinned-powershell-test-sources.json')
binding = obj('pinned-powershell-test-source-binding.json')
check('Test-source receipt SHA256 binding', inputs['pinned-powershell-test-sources.json']['sha256'] == binding['source_file_sha256'])
selector_rows = []
for source in source_doc['sources']:
    path = source['path']; text = source['source']; tree = ast.parse(text)
    selector = next(s for s in plan['PowerShell']['selectors'] if s['path'] == path)
    bind = next(s for s in binding['sources'] if s['path'] == path)
    check('PowerShell source Git blob: '+path, blob(text) == selector['blob_sha'] == plan['workflow_blobs'][path] == bind['git_blob_sha'])
    functions = {n.name:n for n in tree.body if isinstance(n, ast.FunctionDef)}
    actual = []
    for name,node in functions.items():
        if not name.startswith('test_') or not any(a.arg == 'powershell' for a in node.args.args):
            continue
        count = 1
        for dec in node.decorator_list:
            if isinstance(dec, ast.Call) and isinstance(dec.func, ast.Attribute) and dec.func.attr == 'parametrize':
                values = dec.args[1]
                if isinstance(values,(ast.List,ast.Tuple)):
                    count *= len(values.elts)
                elif isinstance(values,ast.Name):
                    count *= {'MEMBERS':4, 'ARTIFACTS':2}[values.id]
                else:
                    raise ValueError('Unexpected parametrization AST')
        actual.append({'name':name,'expanded_case_count':count})
    planned = [{'name':f['name'],'expanded_case_count':f['expanded_case_count']} for f in selector['functions']]
    check('Exact PowerShell selectors: '+path, actual == planned)
    check('Windows missing PowerShell fails: '+path, 'if sys.platform == "win32":\n            pytest.fail(' in text)
    check('PowerShell fixture invokes subprocess: '+path, '[powershell, "-NoProfile", "-NonInteractive", "-File",' in text)
    selector_rows.append({'path':path,'blob_sha':blob(text),'cases':sum(a['expanded_case_count'] for a in actual),'functions':actual,'static_only_test_count':sum(n.startswith('test_') for n in functions)-len(actual)})
check('Windows27 planned counts', [r['cases'] for r in selector_rows] == [17,10] and sum(r['cases'] for r in selector_rows) == plan['PowerShell']['required_actual_Windows_cases'] == 27)

validate = qa_source.split('  windows-validate:\n',1)[1].split('  # Repeats the GUI',1)[0]
check('Required Windows validation is independent same-run job', 'needs: qa' in validate and 'runs-on: windows-latest' in validate and 'timeout-minutes: 45' in validate and 'run-id:' not in validate and 'continue-on-error:' not in validate and '\n    if:' not in validate)
check('Windows consumer downloads correct named artifact', 'name: PatchTrace-windows-x64\n          path: dist' in validate)
check('Both Windows inner payload names required', '$artifactNames = @("PatchTrace-0.1.0-windows-x64.zip", "PatchTrace-Windows-x64-Setup.exe")' in validate)
check('Windows verifier precedes both actual smokes', validate.index('Verified downloaded artifact SHA-256:') < validate.index('./tools/test_windows_portable.ps1 -Archive') < validate.index('./tools/test_windows_installer.ps1 -Installer'))
check('Both Linux frozen platforms required in source and plan', 'os: [ubuntu-22.04, ubuntu-24.04]' in qa_source and plan['required_QA']['ubuntu_frozen_smokes'] == ['ubuntu-22.04','ubuntu-24.04'])
check('Linux frozen receipts cover digest, executable, offscreen, XCB and full CLI', all(s in qa_source for s in ['sha256sum -c PatchTrace-0.1.0-linux-x86_64.tar.gz.sha256','tar xzf PatchTrace-0.1.0-linux-x86_64.tar.gz && test -x PatchTrace/PatchTrace','QT_QPA_PLATFORM=offscreen PatchTrace/PatchTrace --self-test','QT_QPA_PLATFORM=xcb xvfb-run -a PatchTrace/PatchTrace --self-test','python tools/frozen_smoke.py "$PWD/PatchTrace/PatchTrace"']))
check('Required executed QA job count', plan['required_QA']['expected_required_executed_job_count'] == 2+5+1+1+2 == 11)
check('Release requires windows-validate and holds remain', 'needs: [qa, qt-gate, windows-validate, linux-smoke, release-gate]' in qa_source and "!contains(github.event.head_commit.message, '[no release]')" in qa_source)

failures = [c for c in checks if not c['passed']]
report = {
    'schema':'patchtrace/retained-evidence-independent-audit/1',
    'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope':'Retained PR357 native records and static Windows27/final gate plan only; no live API fetch or product/fixture execution.',
    'source':{'head':HEAD,'tree':TREE,'base':BASE,'synthetic_merge':MERGE,'native_run':RUN},
    'verdict':'clear_with_pending_full_qualification' if not failures else 'inconsistency_found',
    'full_QA_qualified':False,
    'failure_count':len(failures),'check_count':len(checks),'checks':checks,
    'native_cache_outcomes':cache_outcomes,'artifacts':artifact_rows,'windows27_source_selectors':selector_rows,
    'resolved_portability_observation':'Both exact test-module source bytes and their Git blob/hash binding were added to the still-unsealed parent evidence; independent recomputation matches the gate plan.',
    'pending_final_receipt_requirements':[
        'Both full platform summaries, corresponding original JUnit ZIP/API hash bindings, expected failures and skipped tests; boundary counts separately.',
        'All five actual Qt completions and exact source checkout logs.',
        'Exactly27 selected Windows JUnit cases actually passed, with zero skipped/failure/error; static-only cases excluded.',
        'Windows producer build/frozen/portable/install/uninstall and product artifact ID/digest.',
        'Separate windows-validate job/runner and actual same-run download ID/envelope digest plus both inner artifact checksum lines before portable/install/uninstall completion.',
        'Linux package and both Ubuntu frozen jobs with same artifact identity, checksum/tar/runtime receipts, offscreen/XCB and full CLI counts.',
        'Actual PR release-gate and release skipped job records, completed QA run, fresh source/run applicability guard before sealing.'
    ],
    'limitations':[
        'Source/tree consistency is checked against the retained API commit/PR and complete-tree receipts, not a new network read or independent reconstruction of the complete Git tree.',
        'The original Ghidra ZIP digest/extraction proof is hosted log and API-step evidence; the large Ghidra download is not locally present.',
        'Application raw-cache diagnostic JSON contains equal hashes and explicit reuse but not the underlying raw output bytes; independent recomputation of that raw hash is not claimed.',
        'Three positives are synthetic known-patch cases; the cached-PDB expected-negative control is not a fourth positive result.',
        'Native completion and static27 selection do not close pending full QA, package or separate Windows consumer gates.'
    ],
    'input_files':inputs,
    'source_ref_CI_or_settings_mutations':False,'network_reads':False,'local_native_or_fixture_execution':False
}
OUT.mkdir(parents=True,exist_ok=True)
(OUT/'audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'verdict':report['verdict'],'checks':len(checks),'failures':failures,'audit_sha256':hashlib.sha256((OUT/'audit.json').read_bytes()).hexdigest(),'artifacts':artifact_rows,'selectors':selector_rows},indent=2))
