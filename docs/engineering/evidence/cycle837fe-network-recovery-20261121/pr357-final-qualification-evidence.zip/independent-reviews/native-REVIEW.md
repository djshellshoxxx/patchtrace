# PR357 retained native evidence and Windows27 plan audit

The retained native summary and static final gate plan are consistent with the inspected source records. This bounded review does not qualify the still-pending full QA or platform jobs.

The source is head `d60ac40daf767fe6a93ae152feb21235f6e75e0b`, complete tree `4a07cd88ded407bef30a8aeb81961e4041822dc2`, base `3a16290c0fcc4e0c21712fe10474a3ff33fad336`, and synthetic merge `254d26e58ef03a03e50c78b5f90c6ef7d9bf9e57`. Retained API commit/PR records agree, and all five native logs show the synthetic merge as the actual checkout for pull-request run `44910528348`, attempt 1.

## Native evidence

| Actual job | Original archive outcome | Post-save outcome |
|---|---|---|
| 136865171976, no-adjacent-PDB positive | Miss | Saved |
| 136865172117, application raw cache | Miss | Reservation declined |
| 136865172123, expected-negative cached-PDB control | Miss | Reservation declined |
| 136865172187, clean positive | Hit | Primary-key save skipped |
| 136865172211, seeded-store positive | Hit | Primary-key save skipped |

All five logs contain the exact pinned Ghidra original archive SHA-256 verification. The successful provisioning steps and retained workflow show verification before removal of the prior runtime, unconditional fresh extraction, and runtime export. Two declined save reservations remain distinct from the one successful save. No causal inference identifies another specific job as the reason for a declined reservation.

The three positive variants each report one accepted change. The plain-Ghidriff control records the expected cached-PDB `FileExistsError`; it is not counted as a positive analysis. The application-cache artifact contains completed first/second diagnostics, one match each, equal reported raw hashes and an explicit cache-reuse event. It does not include the raw output bytes needed for an independent local recomputation of that raw hash.

All four original artifact ZIPs match the retained API lengths and SHA-256 digests. CRCs, all 24 member hashes and the retained extracted text/JSON bytes were independently checked. Backend execution records agree with the summary, including the three positive records' unverified JVM-version field.

## Windows27 and remaining gates

AST inspection of the two retained test-module sources confirms exactly 17 PowerShell cases in `tests.test_windows_downloaded_artifacts` and 10 in `tests.test_live_ghidra_archive`. Two and four static-only tests respectively are excluded. Both PowerShell fixtures fail on Windows if `pwsh` is missing. Source Git blob hashing matches the gate plan: `4f7261ad84e87ea3daaf0b25dd7e543949c04d58` and `abf9444843c25100cab70393f653127252890609`.

The initially missing portable source bytes were added to the parent's still-unsealed evidence as `pinned-powershell-test-sources.json` and its binding receipt. This resolves that evidence-portability observation. No execution claim follows from static selector verification.

The final plan correctly requires eleven executed QA jobs: two full suites, five Qt jobs, the separate `windows-validate` job, Linux packaging and both Ubuntu frozen smoke jobs. The final record still needs actual Windows JUnit evidence for all 27 selected cases; the Windows producer's build/frozen/portable/install/uninstall receipts; and the consumer's separate runner, same-run artifact identity, envelope digest, both inner checksum lines, portable run and install/uninstall completion. Both Ubuntu smokes need their actual artifact identity, checksum, executable extraction, offscreen/XCB and full frozen CLI receipts. Actual release skips, final run completion and fresh source/applicability guards remain part of final qualification.

## Scope

Inputs and their SHA-256 hashes, individual assertions, exact native cache attribution and the outstanding final receipt requirements are in `audit.json`. `audit.py` only parses retained text/JSON/Python AST and hashes ZIP bytes. It performs no network requests, project imports, tests, installs, native/target execution, source/ref/CI mutations or changes to the parent's existing receipts. Source tree attribution is checked against retained API and tree receipts, not a new independent Git tree reconstruction.
