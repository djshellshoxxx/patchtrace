# PR357 final hosted qualification

Qualified with documented open gates. Exact head d60ac40daf767fe6a93ae152feb21235f6e75e0b, complete tree 4a07cd88ded407bef30a8aeb81961e4041822dc2, base 3a16290c0fcc4e0c21712fe10474a3ff33fad336, synthetic merge 254d26e58ef03a03e50c78b5f90c6ef7d9bf9e57. Final guard: 2026-11-21 15:20:42 UTC. Head and synthetic complete trees match; synthetic parents are base then head.

Both automatically applicable runs completed successfully on attempt 1: QA 44910528283 and Native Windows Ghidriff 44910528348. Both are pull_request events and every executed checkout log identifies the synthetic merge. There are 18 actual jobs: 16 executed successes and two intentional PR release skips. All 11 required QA jobs passed.

Linux full: 24,336 passed / 53 skipped / 4 expected failures / 21 warnings. Windows full: 24,205 passed / 185 skipped / 3 expected failures / 22 warnings. Both full JUnit reports have 24,393 cases with zero failures/errors. Boundary controls are separate: Linux 108/2, Windows 107/3. Ubuntu Qt shards passed 13,320 / 10,860 / 9,840 / 8,460; Windows Qt passed 10,620.

The exact 27 Windows PowerShell cases passed with no skips, failures or errors: 17 downloaded-artifact checksum cases plus 10 Ghidra archive provisioning cases. Static-only tests are excluded. Every case ID, module blob and Windows JUnit digest is retained. These cases are a subset of the full suite and are not added to its total.

The Windows producer passed build, 64/0 frozen CLI, portable checksum/extraction/runtime and installer install/launch/non-destructive uninstall. The separate windows-validate job 136888380527 used a distinct runner, downloaded the same-run artifact 14712423138, matched its envelope digest, verified both printed inner hashes before execution, and passed downloaded portable and installer acceptance.

Portable ZIP SHA256: 32c25f035b3f26b4b22dc38c3645973125b4361072f6386e4a61b76fb548df41. Setup EXE SHA256: eea6f91d47ade687faf3ba657d337c41b47086744c1d16313915ac695be79117, matching the producer. The Windows artifact envelope SHA256 is 0de3cf9aeeb65d1d885153e2bf79f7a0c08b32009aa82e56093996f22e15309d.

Linux package 136888380493 produced artifact 14712433241, envelope SHA256 daa3ef2d31f8c1273519ee0ddb9630541e23e31012058677aabb3ca7cdfe6db4. Both Ubuntu 22.04 and 24.04 consumers verified its digest and tar checksum, passed offscreen/XCB self-tests and 64/0 frozen CLI assertions. Large product binaries remain represented by their downloadable metadata and hosted checksum/runtime receipts.

Native acceptance consists of three synthetic positive known-patch variants with one accepted change each, one expected-negative cached-PDB control, and one application raw-cache case. Original Ghidra ZIP caching recorded three misses and two hits: one successful save, two declined reservations, and two primary-key save skips. All five jobs verified the pinned archive hash before fresh extraction. The separate application-cache case reports equal raw hashes and explicit reuse; its diagnostic artifact does not contain the raw output bytes. Native limitations remain explicit.

Actual PR release-gate 136865172968 and release 136889308090 were skipped. These PR results do not preclaim any later main merge, release hold or Pages hold. Root retains guarded merge authority.

Seven actual platform expected-failure records remain open: two CODEX5 gates on both platforms, missing live Ghidra directory on both platforms, and missing llvm-pdbutil on Linux. Other native workflows were not automatically triggered for this head; no old-source result is counted as fresh acceptance. Original PR349 registry failures and superseded/cancelled source records remain linked through the predecessor index and prior archive pointers.

All 16 completed executed-job logs, raw API identities, source guards, small original QA/native artifact ZIPs and their hashes are retained. The original native summary and earlier bounded independent reviews remain unchanged. The initial README describes the initial observation; this file and final-qualification.json provide the completed verdict.

No retry, dispatch, cancellation, source/ref/merge/settings change or local native/target execution was performed by this observer.
