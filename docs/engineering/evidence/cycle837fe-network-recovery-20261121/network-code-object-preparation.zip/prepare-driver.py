from pathlib import Path
import subprocess,json,hashlib
R=Path('/workspace/scratch/837fe19aae3a');P=R/'PatchTrace-network-recovery-followup';O=R/'evidence/network-code-publication-preparation'
H='96baaee20f390a3f2a5629de3764d32323bb80e5';B='d60ac40daf767fe6a93ae152feb21235f6e75e0b';T='4343dce701f20d3b6bc591297d1a887bb05cc461'
def g(*a):return subprocess.check_output(['git',*a],cwd=P)
assert g('rev-parse','HEAD').decode().strip()==H and g('rev-parse','HEAD^{tree}').decode().strip()==T and not g('status','--porcelain=v1').strip()
O.mkdir(exist_ok=False)
public=[B,'e3928ab8c8e2deee7bb01b0f857205f68a1abda2','1d475d926314ae116442bfe2b7cd268ad95ea12c','d0a4bdf439775999340ea760d96a087e032ee6dd','e2127864cb481026db0157082d688b8a36595e3b']
known={x.split()[2] for c in public for x in g('ls-tree','-r',c).decode().splitlines()}
order=['aa01a50844fed15823c6e03491ce3bc671a5ecfc','17962c2403a82a67dea256b163a4a44255948682','8919d8d9ccdc6df8159bfbe6e8daf677a663df1c','29e9286b24323c905f4b9b847a606ce9102b0e06','8fff682f720af634a05939f3e94a9ca273243cb3',H]
seen=set(public);commits=[];blobs={}
for c in order:
 parents=g('show','-s','--format=%P',c).decode().split();assert all(p in seen for p in parents)
 message=g('cat-file','commit',c).decode().split('\n\n',1)[1];subject,_,body=message.partition('\n')
 assert all(m in subject and m in body for m in ['[no release]','[no deploy]'])
 entries=[]
 for name in g('diff','--name-only',parents[0],c).decode().splitlines():
  raw=g('ls-tree',c,'--',name).decode().strip();mode,kind,rest=raw.split(' ',2);blob,path=rest.split('\t',1)
  assert mode=='100644' and kind=='blob' and path==name
  data=g('show',c+':'+name);assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==blob
  entries.append({'path':name,'mode':mode,'type':kind,'sha':blob})
  if blob not in known and blob not in blobs:
   f=O/'novel-blobs'/blob;f.parent.mkdir(exist_ok=True);f.write_bytes(data)
   blobs[blob]={'sha':blob,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'local_path':str(f),'original_source':c,'original_path':name}
 commits.append({'local_commit':c,'local_tree':g('rev-parse',c+'^{tree}').decode().strip(),'local_ordered_parents':parents,'first_parent_tree':g('rev-parse',parents[0]+'^{tree}').decode().strip(),'message':message,'tree_elements':entries});seen.add(c)
plan={'schema':'patchtrace/git-data-publication-plan/1','source':H,'tree':T,'base':B,'known_public_parents':public,'ordered_commits':commits,'novel_blobs':list(blobs.values()),'remote_objects_created':False,'ref_moved':False,'pr_created':False,'remaining':'Actual357 main promotion, separately reviewed pilot child if integrated, final records and hosted qualification; every eventual actual remote tree/parent edge requires verification'}
f=O/'publication-plan.json';f.write_text(json.dumps(plan,indent=2)+'\n');(O/'prepare-driver.py').write_bytes(Path(__file__).read_bytes())
assert not g('status','--porcelain=v1').strip()
print(json.dumps({'commits':len(commits),'novel_blobs':len(blobs),'novel_blob_bytes':sum(x['bytes'] for x in blobs.values()),'plan_sha256':hashlib.sha256(f.read_bytes()).hexdigest()}))
