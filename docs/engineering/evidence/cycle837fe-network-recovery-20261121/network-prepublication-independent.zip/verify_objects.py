"""Read-only actual Git object comparison; no product tests or publication."""
from pathlib import Path
import hashlib,json,subprocess
O=Path(__file__).resolve().parent; R=O.parents[1]
P=R/'PatchTrace-network-recovery-followup'; E=R/'evidence/network-code-publication-preparation'
H='96baaee20f390a3f2a5629de3764d32323bb80e5'; T='4343dce701f20d3b6bc591297d1a887bb05cc461'
REMOTE='00da7e1d5d13f16acba6f6eb54d00f0167e5c62e'; B='d60ac40daf767fe6a93ae152feb21235f6e75e0b'
checks=[]
def g(*a):return subprocess.check_output(['git','-C',str(P),*a])
def v(*a):return g(*a).decode().strip()
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(k,b):return hashlib.sha1(k.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def check(n,c):
 checks.append({'check':n,'passed':bool(c)});(O/'object-checks.json').write_text(json.dumps(checks,indent=2)+'\n');assert c,n
def obj(s):
 b=g('cat-file','commit',s); check('actual object SHA '+s,oid('commit',b)==s)
 d=O/'actual-commits';d.mkdir(exist_ok=True);(d/s).write_bytes(b)
 h,m=b.split(b'\n\n',1);lines=h.decode().splitlines()
 return {'sha':s,'tree':next(x[5:] for x in lines if x.startswith('tree ')),
         'parents':[x[7:] for x in lines if x.startswith('parent ')],'message':m.decode(),'raw_sha256':sha(b)}
check('clean exact96 before',v('rev-parse','HEAD')==H and v('rev-parse','HEAD^{tree}')==T and not v('status','--porcelain=v1'))
check('frozen actual proof hash',sha((E/'actual-git-object-proof.json').read_bytes())=='44bbfd7ce3996bb7b7d26531407ef57baa35a12edd94985009118878bdd9e803')
mapping=json.loads((E/'object-mapping.json').read_text()); proof=json.loads((E/'actual-git-object-proof.json').read_text()); plan=json.loads((E/'publication-plan.json').read_text())
expected=[('aa01a50844fed15823c6e03491ce3bc671a5ecfc','5e4f9090b0a5c1c8a1aa2bfe4bb706356cfdaefb'),('17962c2403a82a67dea256b163a4a44255948682','0fb401a0c86e92b13eaa49c023f6f8d77a4c78d5'),('8919d8d9ccdc6df8159bfbe6e8daf677a663df1c','fb2a3bc857532fdfbcec809c83d7c525e9577de6'),('29e9286b24323c905f4b9b847a606ce9102b0e06','d0e7aacb71554a83a5af9706d34b95988c6ed589'),('8fff682f720af634a05939f3e94a9ca273243cb3','37a1df96c9b8d84c51aaf965725b4ea2beab9199'),(H,REMOTE)]
check('exact6pairs',[(x['local'],x['remote']) for x in mapping['commits']]==expected);translate=dict(expected);objects=[]
for row in mapping['commits']:
 a,b=obj(row['local']),obj(row['remote']); claim=next(x for x in proof['commits'] if x['local']==a['sha'])
 check('complete trees '+a['sha'],a['tree']==b['tree']==row['tree']==claim['tree'] and g('ls-tree','-r','-z',a['sha'])==g('ls-tree','-r','-z',b['sha']) and g('diff','--name-only',a['sha'],b['sha'])==b'')
 check('ordered mapped parents '+a['sha'],a['parents']==row['ordered_local_parents'] and b['parents']==row['ordered_remote_parents']==claim['parents']==[translate.get(x,x) for x in a['parents']])
 exact=a['message']==b['message'];check('message equality or one LF omission '+a['sha'],exact or (a['message'].endswith('\n') and b['message']==a['message'][:-1]))
 check('proof message status '+a['sha'],claim['message_exact']==exact and claim['remote']==b['sha'])
 for label,record in [('local',a),('remote',b)]:
  subject,_,body=record['message'].partition('\n');check('both markers subject/body '+label+a['sha'],all(x in subject and x in body for x in ['[no release]','[no deploy]']))
 p=next(x for x in plan['ordered_commits'] if x['local_commit']==a['sha']); paths=g('diff','--name-only',a['parents'][0],a['sha']).decode().splitlines()
 check('complete planned first-parent delta '+a['sha'],p['local_tree']==a['tree'] and p['message']==a['message'] and p['local_ordered_parents']==a['parents'] and [x['path'] for x in p['tree_elements']]==paths)
 for item in p['tree_elements']:
  data=g('show',a['sha']+':'+item['path']);check('planned entry '+a['sha']+':'+item['path'],g('ls-tree',a['sha'],'--',item['path']).decode().strip()==item['mode']+' '+item['type']+' '+item['sha']+'\t'+item['path'] and oid('blob',data)==item['sha'] and item['mode']=='100644' and item['type']=='blob')
 objects.append({'local':a,'remote':b,'message_exact':exact})
donors=[B,'e3928ab8c8e2deee7bb01b0f857205f68a1abda2','a41c7a0d594d1fe26c16da395e6f6f9b33b07eca','1d475d926314ae116442bfe2b7cd268ad95ea12c','d0a4bdf439775999340ea760d96a087e032ee6dd','e2127864cb481026db0157082d688b8a36595e3b']
for s in donors:check('original public ancestor '+s,subprocess.run(['git','-C',str(P),'merge-base','--is-ancestor',s,REMOTE]).returncode==0)
check('31 commits and exact finaltree',len(v('rev-list',B+'..'+REMOTE).splitlines())==31 and v('rev-parse',REMOTE+'^{tree}')==T)
check('eight novelblobs',len(plan['novel_blobs'])==len(mapping['uploaded_blobs'])==8)
for row in plan['novel_blobs']:
 data=(E/'novel-blobs'/row['sha']).read_bytes();check('novelblob exact '+row['sha'],len(data)==row['bytes'] and sha(data)==row['sha256'] and oid('blob',data)==row['sha'] and data==g('show',row['original_source']+':'+row['original_path'])==g('cat-file','blob',row['sha']))
checkpoint=json.loads((E/'verified-objects-checkpoint.json').read_text())
check('pending creation snapshot then actual verification',mapping['actual_git_verification']=='PENDING' and checkpoint['mapping_pending_field_is_prior_creation_snapshot'] and checkpoint['actual_fetched_commits_verified']==6 and checkpoint['remote_equivalent']==REMOTE and checkpoint['tree']==T)
check('recorded object-only scope',all(not d[k] for d,k in [(mapping,'ref_moved'),(mapping,'pr_created'),(proof,'remote_ref_moved'),(proof,'pr_created'),(checkpoint,'ref_moved'),(checkpoint,'pr_created')]))
check('clean exact96 after',v('rev-parse','HEAD')==H and v('rev-parse','HEAD^{tree}')==T and not v('status','--porcelain=v1'))
result={'source':H,'tree':T,'remote_equivalent':REMOTE,'checks':len(checks),'all_passed':True,'objects':objects,'public_ancestors':donors,'actual_object_verification':True,'fresh_remote_ref_inventory':False,'no_product_or_mutation_operations':True}
(O/'object-proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'checks':len(checks),'all_passed':True,'source':H,'remote_equivalent':REMOTE}))
