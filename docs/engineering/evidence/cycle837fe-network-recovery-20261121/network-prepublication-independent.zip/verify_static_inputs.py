"""Verify existing bytes through exact sealed archive/member chains; no application."""
from pathlib import Path
from io import BytesIO
import hashlib,json,zipfile
O=Path(__file__).resolve().parent;R=O.parents[1];E=R/'evidence'
C=E/'network-code-publication-preparation';P=E/'network-record-preparation/static-inputs-v1.json';checks=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def check(n,c):
 checks.append({'check':n,'passed':bool(c)});(O/'static-checks.json').write_text(json.dumps(checks,indent=2)+'\n');assert c,n
check('exact static plan hash',sha(P.read_bytes())=='5e4c1c36fc26fb2586020873b5eaf805ec6d73d5dc2fff0c75ba7ba1fa92104c')
plan=json.loads(P.read_text());rows=plan['inputs'];check('23 inputs16615652 bytes',len(rows)==len({x['name'] for x in rows})==23 and sum(x['bytes'] for x in rows)==16615652)
archive=C/'network-code-object-preparation.zip';check('code archive hash/size',sha(archive.read_bytes())=='544bb192e9d9a3fb73c748916070d97fd8189ca52ee4e45f622d6709b5d7a352' and archive.stat().st_size==16230)
with zipfile.ZipFile(archive) as z:
 m=z.read('manifest.json');manifest=json.loads(m)
 check('code archive full list/CRC/manifest',len(z.namelist())==7 and z.testzip() is None and set(z.namelist())=={x['path'] for x in manifest['files']}|{'manifest.json'} and sha(m)=='beb4eeaba1c3e21e47089a66bbb76381914aa3b2c3a3762e208889fb5da016a8')
 for row in manifest['files']:
  b=z.read(row['path']);check('new code sealed member '+row['path'],len(b)==row['bytes'] and sha(b)==row['sha256'] and b==(C/row['path']).read_bytes())
outers={};chains=[]
for row in rows:
 path=Path(row['source_path']);b=path.read_bytes();p=row['provenance'];check('selected input bytes/hash/gitsha '+row['name'],path.name==row['name'] and len(b)==row['bytes'] and sha(b)==row['sha256'] and blob(b)==row['git_blob'])
 if 'archive' in p:
  original=Path(p['archive']).read_bytes();check('exact original outer '+row['name'],b==original and sha(original)==p['sha256'])
  with zipfile.ZipFile(BytesIO(b)) as z:check('outer CRC/unique members '+row['name'],z.testzip() is None and len(z.namelist())==len(set(z.namelist())))
  outers[row['sha256']]=b;chains.append({'name':row['name'],'outer':row['name'],'chain':[],'sha256':row['sha256']})
 else:
  original=(E/p['outer_archive']).read_bytes();check('selected outer for chain '+row['name'],sha(original)==p['outer_sha256'] and original==outers[p['outer_sha256']]);chain=[]
  for member in p['member_chain']:
   with zipfile.ZipFile(BytesIO(original)) as z:
    check('unique nested member '+row['name']+':'+member,z.namelist().count(member)==1);original=z.read(member)
   chain.append({'member':member,'bytes':len(original),'sha256':sha(original)})
  check('complete nested chain exact '+row['name'],original==b);chains.append({'name':row['name'],'outer':p['outer_archive'],'chain':chain,'sha256':row['sha256']})
check('six outer archives no duplicate input payloads',len(outers)==6 and len({x['sha256'] for x in rows})==23)
check('explicit nested retention',plan['nested_evidence_preserved_without_duplicate_outer_copies'] and {x['name'] for x in rows if 'archive' in x['provenance']}=={'network-recovery-combined-independent.zip','pr352-independent-source-review.zip','network-recovery-preintegration-coordination.zip','historical-backend-exit-independent.zip','windows-final-publication-independent.zip','network-code-object-preparation.zip'})
check('unapplied with all4 gates',not plan['apply_authorized_now'] and len(plan['blockers'])==4 and plan['code_source']=='96baaee20f390a3f2a5629de3764d32323bb80e5' and plan['code_tree']=='4343dce701f20d3b6bc591297d1a887bb05cc461')
def selected(name):return Path(next(x['source_path'] for x in rows if x['name']==name)).read_bytes()
with zipfile.ZipFile(BytesIO(selected('pr352-independent-source-review.zip'))) as z:
 check('original PR352 full red and component evidence retained',all(x in z.namelist() for x in ['current-independent-boundaries.xml','pr352-boundaries-with-pr356-component.xml','author-parent-red.xml','review.json','source-history.json']))
 check('original PR352 blocked disposition unchanged',json.loads(z.read('review.json'))['verdict']=='BLOCKED_AS_IS')
with zipfile.ZipFile(BytesIO(selected('historical-backend-exit-independent.zip'))) as z:
 check('whole historical donor author archive and independent proof retained','immutable-author-backend-exit-review.zip' in z.namelist() and 'review.json' in z.namelist())
with zipfile.ZipFile(BytesIO(selected('network-recovery-combined-independent.zip'))) as z:
 required=['immutable-evidence/network-recovery-integration.zip','immutable-evidence/network-recovery-combined-qualification.zip','immutable-evidence/netutil-354-356-independent-review.zip','immutable-evidence/netutil-354-356-boundary-review.zip','immutable-evidence/enrichment-completion-deadline-independent.zip','immutable-evidence/pr355-independent-review.zip','reviewer-harness-initial/source-verification.stderr.txt','independent-controls.xml']
 check('complete combined nested source/red/current proofs retained',all(x in z.namelist() for x in required))
 check('combined review no broad readiness claim',not json.loads(z.read('review.json'))['full_hosted_native_package_or_release_acceptance_claimed'])
result={'source':plan['code_source'],'tree':plan['code_tree'],'checks':len(checks),'all_passed':True,'static_plan_sha256':sha(P.read_bytes()),'files':23,'bytes':16615652,'outer_archives':6,'nested_chains':chains,'records_applied':False,'blockers_retained':plan['blockers'],'prior_repo_evidence_references':plan['prior_repo_evidence_referenced']}
(O/'static-proof.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'checks':len(checks),'all_passed':True,'files':23,'bytes':16615652,'outer_archives':6}))
