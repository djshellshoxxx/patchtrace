from pathlib import Path
from io import BytesIO
import hashlib,json,zipfile
from datetime import datetime,timezone
R=Path('/workspace/scratch/837fe19aae3a');O=R/'evidence/network-record-preparation';S=O/'static-v1';S.mkdir(parents=True,exist_ok=False)
A={
 'combined':('network-recovery-combined-independent/network-recovery-combined-independent.zip','42fe3f67ded1a3bd4c2750fb4cbdd61ca55a8ba242bcb6e0e4226f8fe10c891c'),
 'original352':('pr352-independent-review/pr352-independent-source-review.zip','86d451af3770421a60bd0b6e17f2344669c026fec39a9b4a91f8566a56ba55e4'),
 'coordination':('network-recovery-preintegration-coordination/network-recovery-preintegration-coordination.zip','32868c8ce2e9c6cc4c8e84a9eff8d2f021365776a0d6d04bab9a4faa62b3d003'),
 'historical':('historical-backend-exit-independent/historical-backend-exit-independent.zip','e305c2ea1f2ed309455820170380d2a76a98268437b64625185d208bcf3cbcd5'),
 'publication357':('windows-final-publication-independent/windows-final-publication-independent.zip','2ad4aea19e9eeedd6dada1292b8b36937bd0940678407dd5e78f666f9de7bf7e'),
 'objects':('network-code-publication-preparation/network-code-object-preparation.zip','544bb192e9d9a3fb73c748916070d97fd8189ca52ee4e45f622d6709b5d7a352')}
inputs=[];archives={}
def add(name,data,origin):
 assert '/' not in name and not (S/name).exists();(S/name).write_bytes(data)
 inputs.append({'name':name,'source_path':str(S/name),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest(),'provenance':origin})
for key,(relative,expected) in A.items():
 data=(R/'evidence'/relative).read_bytes();assert hashlib.sha256(data).hexdigest()==expected
 with zipfile.ZipFile(BytesIO(data)) as z:assert z.testzip() is None
 archives[key]=data;add(Path(relative).name,data,{'archive':str(R/'evidence'/relative),'sha256':expected})
rows=[
 ('network-combined-review.json','combined',['review.json']),
 ('network-combined-source-proof.json','combined',['source-and-receipt-proof.json']),
 ('network-combined-qualification.json','combined',['immutable-evidence/network-recovery-combined-qualification.zip','qualification.json']),
 ('network-integration-source-proof.json','combined',['immutable-evidence/network-recovery-integration.zip','final-source-proof.json']),
 ('network-integration-record.json','combined',['immutable-evidence/network-recovery-integration.zip','source-integration.json']),
 ('netutil-source-review.json','combined',['immutable-evidence/netutil-354-356-independent-review.zip','review.json']),
 ('netutil-boundary-review.json','combined',['immutable-evidence/netutil-354-356-boundary-review.zip','review.json']),
 ('enrichment-completion-independent-review.json','combined',['immutable-evidence/enrichment-completion-deadline-independent.zip','review.json']),
 ('enrichment-completion-author-handoff.json','combined',['immutable-evidence/enrichment-completion-deadline-independent.zip','immutable-author-repair.zip','handoff.json']),
 ('pr352-original-review.json','original352',['review.json']),
 ('preintegration-coordination-review.json','coordination',['review.json']),
 ('historical-backend-exit-independent-review.json','historical',['review.json']),
 ('historical-backend-exit-author-review.json','historical',['immutable-author-backend-exit-review.zip','review.json']),
 ('pr357-publication-independent-review.json','publication357',['review.json']),
 ('network-code-object-proof.json','objects',['actual-git-object-proof.json']),
 ('network-code-object-mapping.json','objects',['object-mapping.json']),
 ('network-code-object-checkpoint.json','objects',['verified-objects-checkpoint.json'])]
for name,key,chain in rows:
 data=archives[key]
 for member in chain:
  with zipfile.ZipFile(BytesIO(data)) as z:data=z.read(member)
 json.loads(data);add(name,data,{'outer_archive':A[key][0],'outer_sha256':A[key][1],'member_chain':chain})
plan={'schema':'patchtrace/network-static-record-inputs/1','observed_at':datetime.now(timezone.utc).isoformat(),'code_source':'96baaee20f390a3f2a5629de3764d32323bb80e5','code_tree':'4343dce701f20d3b6bc591297d1a887bb05cc461','inputs':inputs,'apply_authorized_now':False,'blockers':['Pilot-tooling implementation and independent review if integrated','Actual qualified PR357 main promotion and ancestry proof','Separate main3a acceptance archive','Final candidate source and independently reviewed records'],'archives_preserved_byte_exact':True,'nested_evidence_preserved_without_duplicate_outer_copies':True,'prior_repo_evidence_referenced':['PR353 review in d60 records','PR355 review in d60 records and combined archive']}
f=O/'static-inputs-v1.json';f.write_text(json.dumps(plan,indent=2)+'\n');(O/'prepare-static-driver.py').write_bytes(Path(__file__).read_bytes())
print(json.dumps({'inputs':len(inputs),'bytes':sum(x['bytes'] for x in inputs),'plan_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'source_worktree_modified':False}))
