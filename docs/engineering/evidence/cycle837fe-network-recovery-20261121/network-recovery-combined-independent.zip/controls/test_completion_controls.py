"""Independent completion boundaries using fake responses; no network or target execution."""
import threading

import pytest

from patchtrace import netutil
from patchtrace.enrichment import intelligence as it
from patchtrace.enrichment.contracts import EnrichmentError

CVE = 'CVE-2024-38063'
BODY = b'{"synthetic":"completion-boundary"}'


def setup_attempt(monkeypatch, phase, expiry, at, *, cancellation=False):
    times = {'logical': 10.0, 'wall': 100.0}
    cancel = threading.Event()
    monkeypatch.setattr(it.time, 'monotonic', lambda: times['wall'])
    monkeypatch.setattr(it, 'TOTAL_TIMEOUT', 1.0)
    calls = []
    closed = []

    def boundary():
        for key in ('logical', 'wall'):
            if expiry in (key, 'both'):
                times[key] = (10.0 if key == 'logical' else 100.0) + at
        if cancellation:
            cancel.set()

    class Response:
        status = 200
        headers = {}
        body = BODY

        def read(self, size):
            data, self.body = self.body[:size], self.body[size:]
            if not data and phase == 'eof':
                boundary()
            return data

        def close(self):
            closed.append(threading.current_thread().ident)
            if phase == 'close':
                boundary()

    def opener(*args):
        calls.append(args)
        return Response()

    plan = it.plan_requests([CVE], ['msrc'])
    kw = {'opener': opener, 'cancel': cancel, 'clock': lambda: times['logical']}
    return plan, it.FetchConsent.for_plan(plan), kw, calls, closed


@pytest.mark.parametrize('phase', ['eof', 'close'])
@pytest.mark.parametrize('expiry', ['logical', 'wall', 'both'])
@pytest.mark.parametrize('at', [0.999, 1.0, 1.001], ids=['before','equal','after'])
def test_completion_admission_clock_boundary(monkeypatch, phase, expiry, at):
    plan, consent, kw, calls, closed = setup_attempt(monkeypatch, phase, expiry, at)
    if at < 1:
        result = it.fetch(plan, consent, **kw)
        assert result[CVE]['msrc'].body == BODY
    else:
        with pytest.raises(EnrichmentError) as exc:
            it.fetch(plan, consent, **kw)
        assert exc.value.code == 'PT-ENRICH-NETWORK'
        assert exc.value.recoverable and exc.value.message == 'total timeout exceeded'
        assert 'synthetic' not in str(exc.value)
    assert len(calls) == len(closed) == 1
    assert closed[0] != threading.current_thread().ident
    assert netutil.abandoned_count() == 0


@pytest.mark.parametrize('expiry', ['neither','logical','wall','both'])
def test_explicit_cancel_at_completion_keeps_precedence(monkeypatch, expiry):
    plan, consent, kw, calls, closed = setup_attempt(monkeypatch, 'close', expiry, 1.0, cancellation=True)
    with pytest.raises(EnrichmentError) as exc:
        it.fetch(plan, consent, **kw)
    assert exc.value.code == 'PT-ENRICH-CANCEL' and exc.value.recoverable
    assert len(calls) == len(closed) == 1 and netutil.abandoned_count() == 0


@pytest.mark.parametrize('expiry', ['logical','wall'])
def test_partial_fetch_does_not_publish_late_body(monkeypatch, expiry):
    plan, consent, kw, calls, closed = setup_attempt(monkeypatch, 'close', expiry, 1.0)
    results, errors = it.fetch_all(plan, consent, **kw)
    assert results == {}
    assert set(errors) == {(CVE, 'msrc')}
    assert errors[(CVE, 'msrc')].code == 'PT-ENRICH-NETWORK'
    assert len(calls) == len(closed) == 1 and netutil.abandoned_count() == 0
