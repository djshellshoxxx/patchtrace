"""Independent, synthetic PR352 boundary checks; no real network or product edits."""
import threading
import time

import pytest

from patchtrace import netutil
from patchtrace.enrichment import intelligence as it
from patchtrace.enrichment.contracts import EnrichmentError


def plan_and_consent():
    plan = it.plan_requests(["CVE-2024-38063"], ("msrc",))
    return plan, it.FetchConsent.for_plan(plan)


def wait_for(predicate, limit=2.0):
    end = time.monotonic() + limit
    while not predicate() and time.monotonic() < end:
        time.sleep(0.005)
    return predicate()


@pytest.mark.parametrize("phase", ("eof", "close"))
def test_completed_attempt_past_wall_deadline_is_not_published(monkeypatch, phase):
    """A completed worker can signal done before the supervisor's next polling check."""
    wall = [0.0]
    monkeypatch.setattr(it.time, "monotonic", lambda: wall[0])
    monkeypatch.setattr(it, "TOTAL_TIMEOUT", 0.5)
    closed = threading.Event()

    class Response:
        status = 200
        headers = {}

        def read(self, size):
            if phase == "eof":
                wall[0] = 1.0
            return b""

        def close(self):
            if phase == "close":
                wall[0] = 1.0
            closed.set()

    plan, consent = plan_and_consent()
    try:
        with pytest.raises(EnrichmentError) as exc:
            it.fetch(plan, consent, opener=lambda *args: Response(), clock=lambda: 0.0)
        assert exc.value.code == "PT-ENRICH-NETWORK"
    finally:
        assert closed.is_set()
        assert netutil.abandoned_count() == 0


def test_completed_attempt_before_wall_deadline_still_succeeds(monkeypatch):
    wall = [0.0]
    monkeypatch.setattr(it.time, "monotonic", lambda: wall[0])
    monkeypatch.setattr(it, "TOTAL_TIMEOUT", 0.5)

    class Response:
        status = 200
        headers = {}

        def read(self, size):
            return b""

        def close(self):
            wall[0] = 0.25

    plan, consent = plan_and_consent()
    result = it.fetch(plan, consent, opener=lambda *args: Response(), clock=lambda: 0.0)
    assert result["CVE-2024-38063"]["msrc"].body == b""
    assert netutil.abandoned_count() == 0


def test_whole_attempt_timeout_keeps_blocked_close_counted(monkeypatch):
    release = threading.Event()
    closing = threading.Event()
    closed = threading.Event()
    monkeypatch.setattr(it, "TOTAL_TIMEOUT", 0.12)

    class Response:
        status = 200
        headers = {}

        def read(self, size):
            return b""

        def close(self):
            closing.set()
            release.wait(2)
            closed.set()

    plan, consent = plan_and_consent()
    start = time.monotonic()
    try:
        with pytest.raises(EnrichmentError) as exc:
            it.fetch(plan, consent, opener=lambda *args: Response())
        assert exc.value.code == "PT-ENRICH-NETWORK"
        assert time.monotonic() - start < 0.9
        assert closing.is_set() and not closed.is_set()
        assert netutil.abandoned_count() == 1
    finally:
        release.set()
        assert closed.wait(2)
        assert wait_for(lambda: netutil.abandoned_count() == 0)


@pytest.mark.parametrize("phase", ("connect", "read"))
def test_total_deadline_also_applies_to_unset_cancel_event(monkeypatch, phase):
    release = threading.Event()
    closed = threading.Event()
    cancel = threading.Event()
    monkeypatch.setattr(it, "TOTAL_TIMEOUT", 0.12)

    class Response:
        status = 200
        headers = {}

        def read(self, size):
            if phase == "read":
                release.wait(2)
            return b""

        def close(self):
            closed.set()

    def opener(*args):
        if phase == "connect":
            release.wait(2)
        return Response()

    plan, consent = plan_and_consent()
    start = time.monotonic()
    try:
        with pytest.raises(EnrichmentError) as exc:
            it.fetch(plan, consent, opener=opener, cancel=cancel)
        assert exc.value.code == "PT-ENRICH-NETWORK"
        assert time.monotonic() - start < 0.9
        assert not cancel.is_set()
    finally:
        release.set()
        assert closed.wait(2)
        assert wait_for(lambda: netutil.abandoned_count() == 0)


def test_cancelled_late_opener_cleanup_holds_resource_slot():
    """The existing inner opener worker still needs PR356's cleanup-lifetime repair."""
    opened = threading.Event()
    release_open = threading.Event()
    closing = threading.Event()
    release_close = threading.Event()
    closed = threading.Event()
    cancel = threading.Event()
    baseline = {t.ident for t in threading.enumerate() if t.name == "patchtrace-net"}
    assert netutil.abandoned_count() == 0

    class Response:
        status = 200
        headers = {}

        def read(self, size):
            return b""

        def close(self):
            closing.set()
            release_close.wait(2)
            closed.set()

    def opener(*args):
        opened.set()
        release_open.wait(2)
        return Response()

    def trigger_cancel():
        assert opened.wait(2)
        cancel.set()

    trigger = threading.Thread(target=trigger_cancel, daemon=True)
    trigger.start()
    plan, consent = plan_and_consent()
    workers = lambda: [t for t in threading.enumerate()
                       if t.name == "patchtrace-net" and t.ident not in baseline]
    try:
        with pytest.raises(EnrichmentError) as exc:
            it.fetch(plan, consent, opener=opener, cancel=cancel)
        assert exc.value.code == "PT-ENRICH-CANCEL"
        assert wait_for(lambda: len(workers()) == 1)
        release_open.set()
        assert closing.wait(2) and not closed.is_set()
        assert netutil.abandoned_count() == 1, "late response cleanup still holds one worker/socket"
    finally:
        release_open.set()
        release_close.set()
        trigger.join(2)
        assert closed.wait(2)
        assert wait_for(lambda: netutil.abandoned_count() == 0 and not workers())
