"""At most five inert call workers; no actual sockets or external traffic."""
import http.client
import io
import json
import threading
import time
from pathlib import Path
from types import SimpleNamespace

import pytest
import netutil_boundary_under_review as netutil


def test_five_pre_admitted_calls_against_strict_helper_docstring_cap():
    cancel, release, entered_all = threading.Event(), threading.Event(), threading.Event()
    lock = threading.Lock()
    worker_ids, outcomes, threads = [], [], []
    observed = {'source_label': netutil.REVIEW_LABEL, 'docstring_cap': netutil.MAX_ABANDONED}
    assert netutil.MAX_ABANDONED == 4 and netutil.abandoned_count() == 0

    def call():
        with lock:
            worker_ids.append(threading.get_ident())
            if len(worker_ids) == 5:
                entered_all.set()
        release.wait(3)
        return None

    def caller():
        try:
            netutil.interruptible(call, cancel, poll=0.005)
        except BaseException as exc:
            with lock:
                outcomes.append(type(exc).__name__)
        else:
            with lock:
                outcomes.append('returned')

    try:
        for i in range(5):
            t = threading.Thread(target=caller, name=f'review-caller-{i}', daemon=True)
            threads.append(t)
            t.start()
        assert entered_all.wait(1), 'five calls must be admitted before cancellation'
        observed['admitted_workers'] = len(worker_ids)
        observed['abandoned_before_cancel'] = netutil.abandoned_count()
        cancel.set()
        for t in threads:
            t.join(1)
        assert not any(t.is_alive() for t in threads)
        observed['caller_outcomes'] = list(outcomes)
        observed['abandoned_after_cancel'] = netutil.abandoned_count()
        assert outcomes == ['Cancelled'] * 5
        with pytest.raises(netutil.TooManyAbandoned):
            netutil.interruptible(lambda: pytest.fail('no sixth worker may start'), threading.Event())
        observed['later_admission_refused'] = True
        assert netutil.abandoned_count() <= netutil.MAX_ABANDONED, 'strict helper docstring cap exceeded by previously admitted concurrent calls'
    finally:
        cancel.set()
        release.set()
        for t in threads:
            t.join(1)
        end = time.monotonic() + 2
        while time.monotonic() < end:
            remaining = [t for t in threading.enumerate() if t.ident in worker_ids]
            if not remaining and netutil.abandoned_count() == 0:
                break
            time.sleep(0.005)
        observed['after_release_abandoned'] = netutil.abandoned_count()
        observed['workers_alive_after_release'] = len([t for t in threading.enumerate() if t.ident in worker_ids])
        Path(netutil.REVIEW_OUTPUT).write_text(json.dumps(observed, indent=2) + '\n')
        assert observed['after_release_abandoned'] == 0 and observed['workers_alive_after_release'] == 0


class TimeoutSocket:
    def __init__(self, timeout):
        self.timeout, self.changes = timeout, []

    def gettimeout(self):
        return self.timeout

    def settimeout(self, value):
        self.changes.append(value)
        self.timeout = value


def response_with(raw_marker):
    fp = io.BytesIO()
    if raw_marker != 'absent':
        fp.raw = raw_marker
    return http.client.HTTPResponse(SimpleNamespace(makefile=lambda *_: fp))


@pytest.mark.parametrize('current,remaining,expected,changes', [
    (None, 0.5, 0.5, [0.5]), (2.0, 0.5, 0.5, [0.5]),
    (0.1, 0.5, 0.1, []), (0.5, 0.5, 0.5, []), (0.0, 0.5, 0.0, []),
    (None, 0.0001, 0.001, [0.001]), (0.0005, 0.0001, 0.0005, []),
    (0.002, 0.0001, 0.001, [0.001]),
])
def test_known_http_timeout_never_extended(current, remaining, expected, changes):
    sock = TimeoutSocket(current)
    response = response_with(SimpleNamespace(_sock=sock))
    try:
        netutil._shorten_http_socket_timeout(response, remaining)
        assert sock.timeout == expected and sock.changes == changes
        assert current is None or sock.timeout <= current
    finally:
        response.close()


def test_unknown_transport_not_inspected_or_changed():
    class Unknown:
        @property
        def fp(self):
            pytest.fail('unknown transport private attributes must not be inspected')

        def settimeout(self, value):
            pytest.fail('unknown transport must not be changed')

    netutil._shorten_http_socket_timeout(Unknown(), 0.1)


@pytest.mark.parametrize('raw_marker', ['absent', None, SimpleNamespace(), SimpleNamespace(_sock=None)])
def test_known_http_missing_socket_is_unchanged(raw_marker):
    response = response_with(raw_marker)
    fp = response.fp
    try:
        netutil._shorten_http_socket_timeout(response, 0.1)
        assert response.fp is fp and not fp.closed
    finally:
        response.close()
