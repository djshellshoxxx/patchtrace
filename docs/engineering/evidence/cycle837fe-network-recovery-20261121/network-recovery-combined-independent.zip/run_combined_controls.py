"""Read-only exact combined-source replay of previously sealed inert controls."""
from pathlib import Path
import datetime
import hashlib
import importlib
import importlib.metadata
import json
import os
import subprocess
import sys
import threading

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
REPO = ROOT / 'PatchTrace-network-recovery-followup'
HEAD = '96baaee20f390a3f2a5629de3764d32323bb80e5'
TREE = '4343dce701f20d3b6bc591297d1a887bb05cc461'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def state():
    return {'head': git('rev-parse', 'HEAD').decode().strip(),
            'tree': git('rev-parse', 'HEAD^{tree}').decode().strip(),
            'status': git('status', '--porcelain=v1').decode()}


before = state()
assert before == {'head': HEAD, 'tree': TREE, 'status': ''}
assert sys.flags.isolated and sys.dont_write_bytecode
os.environ['PYTEST_DISABLE_PLUGIN_AUTOLOAD'] = '1'
os.environ['QT_QPA_PLATFORM'] = 'offscreen'
os.environ['XDG_CACHE_HOME'] = str(OUT / '_tmp' / 'cache')
sys.path[:0] = [str(REPO / 'src'), str(REPO), str(REPO / 'tests')]
bindings = []
for name in ('patchtrace.netutil', 'patchtrace.enrichment.intelligence',
             'patchtrace.intelligence.csaf.transport', 'patchtrace.optional_deps'):
    mod = importlib.import_module(name)
    rel = 'src/' + name.replace('.', '/') + '.py'
    expected = git('show', HEAD + ':' + rel)
    actual = Path(mod.__file__).resolve()
    assert actual == REPO / rel
    assert actual.read_bytes() == expected
    bindings.append({'module': name, 'path': str(actual),
                     'git_blob': git('rev-parse', HEAD + ':' + rel).decode().strip(),
                     'sha256': hashlib.sha256(expected).hexdigest()})
from patchtrace import netutil
sys.modules['netutil_boundary_under_review'] = netutil
assert netutil.abandoned_count() == 0
worker_ids_before = {t.ident for t in threading.enumerate() if t.name == 'patchtrace-net'}
try:
    editable = json.loads(importlib.metadata.distribution('patchtrace').read_text('direct_url.json'))
except (importlib.metadata.PackageNotFoundError, TypeError):
    editable = None
receipt = {'source': HEAD, 'tree': TREE, 'before': before,
           'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'executable': sys.executable, 'python_version': sys.version,
           'isolated': bool(sys.flags.isolated), 'dont_write_bytecode': sys.dont_write_bytecode,
           'module_bindings': bindings, 'existing_editable_metadata': editable,
           'environment_installed_or_rebound': False,
           'actual_combined_netutil_used_for_socket_alias': True}
(OUT / 'source-binding.json').write_text(json.dumps(receipt, indent=2) + '\n')
args = [
    '-q', '-c', '/dev/null', '--noconftest', '-p', 'no:cacheprovider',
    '--rootdir=' + str(OUT), '--basetemp=' + str(OUT / '_tmp' / 'pytest'),
    '--junitxml=' + str(OUT / 'independent-controls.xml'),
    str(OUT / 'controls/test_completion_controls.py'),
    str(OUT / 'controls/test_review_attempt_boundaries.py'),
    str(OUT / 'controls/test_boundaries.py') + '::test_known_http_timeout_never_extended',
    str(OUT / 'controls/test_boundaries.py') + '::test_unknown_transport_not_inspected_or_changed',
    str(OUT / 'controls/test_boundaries.py') + '::test_known_http_missing_socket_is_unchanged',
]
import pytest
code = int(pytest.main(args))
receipt.update({'pytest_arguments': args, 'exit_code': code, 'after': state(),
                'abandoned_after': netutil.abandoned_count(),
                'new_net_workers_after': [t.name for t in threading.enumerate()
                     if t.name == 'patchtrace-net' and t.ident not in worker_ids_before]})
(OUT / 'control-run.json').write_text(json.dumps(receipt, indent=2) + '\n')
assert receipt['after'] == before
assert receipt['abandoned_after'] == 0 and receipt['new_net_workers_after'] == []
raise SystemExit(code)
