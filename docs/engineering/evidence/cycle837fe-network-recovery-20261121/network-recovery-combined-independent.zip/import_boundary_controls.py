"""Controlled optional-import exceptions and control-flow propagation; no target input."""
from pathlib import Path
import builtins
import importlib.util
import json
import sys

REPO = Path('/workspace/scratch/837fe19aae3a/PatchTrace-network-recovery-followup')
OUT = Path(__file__).resolve().parent
SOURCE = REPO / 'src/patchtrace/optional_deps.py'
sys.path[:0] = [str(REPO / 'src')]
from patchtrace import optional_deps

assert Path(optional_deps.__file__).resolve() == SOURCE
baseline = {name: cap.available for name, cap in optional_deps.probe().items()}
rows = []
for package, capability in [('rapidfuzz', 'rapidfuzz'), ('iced_x86', 'iced-x86'), ('yara_x', 'yara-x')]:
    for exception in (OSError, KeyboardInterrupt, SystemExit):
        name = 'patchtrace._independent_import_' + package + '_' + exception.__name__
        spec = importlib.util.spec_from_file_location(name, SOURCE)
        candidate = importlib.util.module_from_spec(spec)
        fault = exception('authored independent import-boundary control')
        real_import = builtins.__import__

        def failing_import(import_name, *args, **kwargs):
            if import_name == package:
                raise fault
            return real_import(import_name, *args, **kwargs)

        sys.modules[name] = candidate
        observed = None
        try:
            builtins.__import__ = failing_import
            try:
                spec.loader.exec_module(candidate)
            except BaseException as caught:
                observed = caught
        finally:
            builtins.__import__ = real_import
            sys.modules.pop(name, None)
        if exception is OSError:
            assert observed is None
            caps = candidate.probe()
            assert not caps[capability].available and caps[capability].version == ''
            assert 'OSError' in caps[capability].detail and 'patchtrace[' in caps[capability].detail
            assert {k: v.available for k, v in caps.items() if k != capability} == {
                k: v for k, v in baseline.items() if k != capability}
            outcome = 'Unavailable capability with actionable preserved error; unrelated capabilities unchanged'
        else:
            assert observed is fault
            outcome = 'Original control-flow exception propagated by identity'
        rows.append({'package': package, 'fault': exception.__name__, 'passed': True, 'outcome': outcome})
(OUT / 'import-boundary-controls.json').write_text(json.dumps({'controls': rows, 'count': len(rows),
    'source': str(SOURCE), 'synthetic': True, 'native_fault_acceptance': False}, indent=2) + '\n')
print(json.dumps({'passed_controls': len(rows)}))
