"""Independent read-only reconstruction, object, preservation and receipt checks."""
from pathlib import Path
import ast
import copy
import datetime
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
REPO = ROOT / 'PatchTrace-network-recovery-followup'
EVIDENCE = ROOT / 'evidence'
AUTHOR = EVIDENCE / 'network-recovery-integration'
QUAL = EVIDENCE / 'network-recovery-combined-qualification'
HEAD = '96baaee20f390a3f2a5629de3764d32323bb80e5'
TREE = '4343dce701f20d3b6bc591297d1a887bb05cc461'
BASE = 'd60ac40daf767fe6a93ae152feb21235f6e75e0b'
COMMON = '9023761a4066ac1c50c127ac09d0ba5f56cdc9e4'
PARENT = '8fff682f720af634a05939f3e94a9ca273243cb3'
APPENDS = {'docs/qa.md', 'tasks/todo.md'}
STAGES = [
    ('netutil354356', BASE, '1d475d926314ae116442bfe2b7cd268ad95ea12c',
     '17962c2403a82a67dea256b163a4a44255948682', '202d6e32048bd2b6d2fa2d080c13834b8df7dbdf'),
    ('enrichment352', '17962c2403a82a67dea256b163a4a44255948682',
     'aa01a50844fed15823c6e03491ce3bc671a5ecfc',
     '8919d8d9ccdc6df8159bfbe6e8daf677a663df1c', '5b28c2079d1fd3c35240f51aad2cb64105de788d'),
    ('csaf353', '8919d8d9ccdc6df8159bfbe6e8daf677a663df1c',
     'd0a4bdf439775999340ea760d96a087e032ee6dd',
     '29e9286b24323c905f4b9b847a606ce9102b0e06', 'b87e8052c2f5830fa92b414e94d23daaa73dcba3'),
    ('optional355', '29e9286b24323c905f4b9b847a606ce9102b0e06',
     'e2127864cb481026db0157082d688b8a36595e3b', PARENT,
     'd440d1a7cdb550ab1f989ebd73d9cd000208a7cd'),
]
checks = []


def check(label, condition, **details):
    row = {'check': label, 'passed': bool(condition), **details}
    checks.append(row)
    (OUT / 'checks.json').write_text(json.dumps(checks, indent=2) + '\n')
    assert condition, row


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def val(*args):
    return git(*args).decode().strip()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(commit, path):
    return git('show', commit + ':' + path)


def tree_entries(commit):
    entries = {}
    for line in git('ls-tree', '-r', '-z', commit).split(b'\0'):
        if not line:
            continue
        meta, path = line.split(b'\t', 1)
        entries[path.decode()] = meta.decode()
    return entries


def changed(a, b):
    return git('diff', '--name-only', a, b).decode().splitlines()


def object_record(commit):
    raw = git('cat-file', 'commit', commit)
    header, message = raw.split(b'\n\n', 1)
    lines = header.decode().splitlines()
    return {'commit': commit, 'tree': next(x[5:] for x in lines if x.startswith('tree ')),
            'parents': [x[7:] for x in lines if x.startswith('parent ')],
            'message': message.decode(), 'raw_commit_sha256': sha(raw)}


check('exact clean frozen source', val('rev-parse', 'HEAD') == HEAD
      and val('rev-parse', 'HEAD^{tree}') == TREE and not val('status', '--porcelain=v1'))
actual = object_record(HEAD)
check('final ordered parent', actual['parents'] == [PARENT])
for part, text in [('subject', actual['message'].split('\n', 1)[0]),
                   ('body', actual['message'].split('\n', 1)[1])]:
    check('final markers in ' + part, '[no release]' in text and '[no deploy]' in text)

records = json.loads((AUTHOR / 'source-integration.json').read_text())
all_paths, reconstructions, stages = set(), [], []
for label, before, incoming, commit, expected_tree in STAGES:
    record = next(x for x in records['records'] if x['label'] == label)
    obj = object_record(commit)
    check(label + ' actual ordered parents/tree', obj['parents'] == [before, incoming]
          and obj['tree'] == expected_tree)
    check(label + ' exact merge base', val('merge-base', before, incoming) == COMMON)
    paths = changed(COMMON, incoming)
    all_paths.update(paths)
    check(label + ' complete incoming path set', paths == record['incoming_paths'])
    check(label + ' exact first-parent scope', changed(before, commit) == paths)
    previous, resulting, donor = (tree_entries(x) for x in (before, commit, incoming))
    check(label + ' all other paths/modes/blobs preserved',
          {k:v for k,v in previous.items() if k not in paths} ==
          {k:v for k,v in resulting.items() if k not in paths})
    for path in paths:
        if path not in APPENDS:
            check(label + ' incoming file exactly retained: ' + path,
                  resulting[path] == donor[path] and blob(commit, path) == blob(incoming, path))
            continue
        common, ours, theirs, result = (blob(c, path) for c in (COMMON, before, incoming, commit))
        prefix, suffix = theirs.endswith(common), theirs.startswith(common)
        check(label + ' one-sided record addition: ' + path,
              common and theirs.count(common) == 1 and prefix != suffix)
        addition = theirs[:-len(common)] if prefix else theirs[len(common):]
        expected = addition + ours if prefix else ours + addition
        check(label + ' exact record reconstruction: ' + path,
              bool(addition) and addition not in ours and result == expected
              and result.count(ours) == 1 and result.count(addition) == 1)
        proof = {'stage': label, 'path': path, 'addition_side': 'prefix' if prefix else 'suffix',
                 'addition_bytes': len(addition), 'addition_sha256': sha(addition),
                 'common_sha256': sha(common), 'previous_sha256': sha(ours),
                 'incoming_sha256': sha(theirs), 'result_sha256': sha(result)}
        reconstructions.append(proof)
        if label == 'enrichment352':
            evidence_base = AUTHOR / label / path.replace('/', '__')
            resolution = next(x for x in record['resolutions'] if x['path'] == path)
            for i, data in enumerate((common, ours, theirs), 1):
                check('conflict exact stage ' + str(i) + ': ' + path,
                      Path(str(evidence_base) + '.stage' + str(i)).read_bytes() == data
                      and resolution['stages'][str(i)] == {'bytes': len(data), 'sha256': sha(data)})
            check('conflict exact resolved receipt: ' + path,
                  Path(str(evidence_base) + '.resolved').read_bytes() == result
                  and resolution['addition_sha256'] == sha(addition)
                  and resolution['resolved_bytes'] == len(result)
                  and resolution['resolved_sha256'] == sha(result))
    check(label + ' recorded scope and identities truthful', record['before'] == before
          and record['incoming'] == incoming and record['commit'] == commit
          and record['tree'] == expected_tree and record['ordered_parents'] == obj['parents'])
    check(label + ' conflict list scoped', record['conflicts'] ==
          (['docs/qa.md', 'tasks/todo.md'] if label == 'enrichment352' else []))
    stages.append(obj)

check('complete 18-path union', len(all_paths) == 18
      and changed(BASE, HEAD) == sorted(all_paths) == records['complete_changed_paths'])
base_entries, final_entries = tree_entries(BASE), tree_entries(HEAD)
unchanged = {k:v for k,v in base_entries.items() if k not in all_paths}
check('every other baseline file/mode/blob retained', unchanged ==
      {k:v for k,v in final_entries.items() if k not in all_paths},
      unchanged_tracked_entries=len(unchanged))
for path in APPENDS:
    check('complete original d60 record retained once: ' + path,
          blob(HEAD, path).count(blob(BASE, path)) == 1)
check('findings index exact356, no additional merge edits',
      blob(HEAD, 'docs/engineering/bug-hunt/findings.json') ==
      blob(STAGES[0][2], 'docs/engineering/bug-hunt/findings.json'))

netpath = 'src/patchtrace/netutil.py'
before, after = blob(PARENT, netpath), blob(HEAD, netpath)
check('only final child path is netutil', changed(PARENT, HEAD) == [netpath])
check('prior netutil is exact356', before == blob(STAGES[0][2], netpath))
before_ast, after_ast = ast.parse(before), ast.parse(after)
old_fn = next(x for x in before_ast.body if isinstance(x, ast.FunctionDef) and x.name == 'interruptible')
new_fn = next(x for x in after_ast.body if isinstance(x, ast.FunctionDef) and x.name == 'interruptible')
old_doc, new_doc = old_fn.body[0].value.value, new_fn.body[0].value.value
check('exact docstring-only text replacement', old_doc != new_doc
      and after.decode().count(new_doc) == 1
      and after.decode().replace(new_doc, old_doc) == before.decode())
new_fn.body[0] = copy.deepcopy(old_fn.body[0])
check('entire runtime AST unchanged after only target docstring normalization',
      ast.dump(before_ast, include_attributes=False) == ast.dump(after_ast, include_attributes=False))
check('H9 specification unchanged in docstring child',
      blob(PARENT, 'docs/specs/enrichment-hardening-backlog.md') ==
      blob(HEAD, 'docs/specs/enrichment-hardening-backlog.md'))
doc_claim = json.loads((AUTHOR / 'docstring-clarification/proof.json').read_text())
check('docstring proof is exact values', doc_claim['old_docstring'] == old_doc
      and doc_claim['new_docstring'] == new_doc)
check('all original non-docstring runtime/test/spec contributions reach final exactly',
      all(blob(HEAD, p) == blob(incoming, p)
          for _, _, incoming, _, _ in STAGES
          for p in changed(COMMON, incoming) if p not in APPENDS and p != netpath))

all_commits = git('rev-list', '--reverse', '--topo-order', BASE + '..' + HEAD).decode().splitlines()
check('31 unique commits retained above d60', len(all_commits) == len(set(all_commits)) == 31)
root_history = json.loads((AUTHOR / 'complete-source-history.json').read_text())
check('root complete history enumerates actual commits',
      [x['commit'] for x in root_history['commits']] == all_commits and root_history['count'] == 31)
actual_history = []
for commit in all_commits:
    obj = object_record(commit)
    claim = next(x for x in root_history['commits'] if x['commit'] == commit)
    check('complete object/history: ' + commit,
          claim['tree'] == obj['tree'] and claim['parents'] == obj['parents']
          and claim['message'] == git('show','-s','--format=%B',commit).decode()
          and claim['first_parent_paths'] == changed(obj['parents'][0], commit))
    actual_history.append(obj)
incoming_groups = []
expected_counts = {'netutil354356': 10, 'enrichment352': 6, 'csaf353': 6, 'optional355': 4}
for label, _, incoming, _, _ in STAGES:
    commits = git('rev-list', '--reverse', COMMON + '..' + incoming).decode().splitlines()
    check(label + ' all original commits ancestors', len(commits) == expected_counts[label]
          and set(commits) <= set(all_commits)
          and subprocess.run(['git','-C',str(REPO),'merge-base','--is-ancestor',incoming,HEAD]).returncode == 0)
    incoming_groups.append({'label': label, 'head': incoming, 'count': len(commits), 'commits': commits})
for ref in ('a41c7a0d594d1fe26c16da395e6f6f9b33b07eca',
            'e3928ab8c8e2deee7bb01b0f857205f68a1abda2', BASE):
    check('explicit original ancestor: ' + ref,
          subprocess.run(['git','-C',str(REPO),'merge-base','--is-ancestor',ref,HEAD]).returncode == 0)

guard = json.loads((AUTHOR / 'initial-preparation-guard.json').read_text())
check('initial helper guard failure preserved/bound',
      sha((AUTHOR / 'initial-integration-helper.py').read_bytes()) == guard['helper_sha256']
      == '05b654f6d35bf5d9b7877633f0c54d135c55333f4da1e0187ff161630faed446'
      and guard['source_head_after_first_successful_import'] == STAGES[0][3]
      and guard['failed_before_incoming_merge'] == STAGES[1][2]
      and guard['product_failure'] is False)
check('initial incorrect suffix predicate really fails without executing helper',
      not blob(STAGES[1][2], 'docs/qa.md').startswith(blob(COMMON, 'docs/qa.md')))

snapshots = json.loads((AUTHOR / 'source-snapshots.json').read_text())
check('complete 36 baseline/final presence records', len(snapshots) == 36 and
      {(x['commit'],x['path']) for x in snapshots} == {(c,p) for c in (BASE,HEAD) for p in all_paths})
for row in snapshots:
    entries = base_entries if row['commit'] == BASE else final_entries
    present = row['path'] in entries
    check('snapshot presence: ' + row['commit'][:8] + ':' + row['path'], row['present'] == present)
    if present:
        data = blob(row['commit'], row['path'])
        check('snapshot bytes/hash/blob: ' + row['commit'][:8] + ':' + row['path'],
              data == (AUTHOR / 'source' / row['commit'] / row['path']).read_bytes()
              and len(data) == row['bytes'] and sha(data) == row['sha256']
              and val('rev-parse', row['commit'] + ':' + row['path']) == row['git_blob'])

archive_checks = []
for directory, name, expected_sha, size, count, manifest_sha in [
    (AUTHOR, 'network-recovery-integration.zip',
     '0b75faf312ea69e1d895a1ca7c6ff6bfa09104c5ab003b7fb9e87a6878bb98fd',1749533,68,
     '48707b8e8b0ccc634df5a15cf90cfef8bb6e12a652cebbc9d6ce068fe41e7039'),
    (QUAL, 'network-recovery-combined-qualification.zip',
     'c45742011888c485379883cc69c3fab5a90c07f70fdd61d9a2906d4e4a367c94',16513,15,
     'ba31cc355c8bec8c27c7f0f929d4af7f3fe2d1b92ad72207d6d1b10f5d592276'),
]:
    archive = directory / name
    data = archive.read_bytes()
    check('archive hash/size: ' + name, sha(data) == expected_sha and len(data) == size)
    manifest = (directory / 'manifest.json').read_bytes()
    check('archive manifest digest: ' + name, sha(manifest) == manifest_sha)
    rows = json.loads(manifest)['files']
    with zipfile.ZipFile(archive) as z:
        check('archive complete member list/CRC: ' + name,
              len(z.namelist()) == count == len(rows) + 1
              and len(set(z.namelist())) == count and z.testzip() is None
              and set(z.namelist()) == {x['path'] for x in rows} | {'manifest.json'}
              and z.read('manifest.json') == manifest)
        for row in rows:
            payload = z.read(row['path'])
            check('sealed payload: ' + name + ':' + row['path'],
                  len(payload) == row['bytes'] and sha(payload) == row['sha256']
                  and payload == (directory / row['path']).read_bytes())
    archive_checks.append({'archive': str(archive), 'sha256': expected_sha,
                           'bytes': size, 'members': count, 'manifest_sha256': manifest_sha})

bundle = AUTHOR / 'network-recovery-source.bundle'
verify = subprocess.run(['git','-C',str(REPO),'bundle','verify',str(bundle)],capture_output=True)
(OUT / 'bundle-verification.stdout.txt').write_bytes(verify.stdout)
(OUT / 'bundle-verification.stderr.txt').write_bytes(verify.stderr)
check('source bundle verifies read-only', verify.returncode == 0)
header = bundle.read_bytes().split(b'\n\n', 1)[0].decode()
check('bundle exact prerequisite and source advertised',
      [x[1:].split(' ',1)[0] for x in header.splitlines() if x.startswith('-')] == [COMMON, BASE]
      and HEAD in header)
check('additional bundle boundary902 already ancestor of prerequisite d60',
      subprocess.run(['git','-C',str(REPO),'merge-base','--is-ancestor',COMMON,BASE]).returncode == 0)

def junit(path):
    cases = list(ET.parse(path).getroot().iter('testcase'))
    identities = [(x.attrib.get('classname'),x.attrib.get('name')) for x in cases]
    return {'cases':len(cases), 'distinct_cases':len(set(identities)),
            'failures':sum(x.find('failure') is not None for x in cases),
            'errors':sum(x.find('error') is not None for x in cases),
            'skipped':sum(x.find('skipped') is not None for x in cases)}, identities

own_counts, own_ids = junit(OUT / 'independent-controls.xml')
check('44 distinct independent cases green', own_counts ==
      {'cases':44,'distinct_cases':44,'failures':0,'errors':0,'skipped':0})
check('unchanged formerly failing cleanup control included once',
      sum(x[1] == 'test_cancelled_late_opener_cleanup_holds_resource_slot' for x in own_ids) == 1)
optional = json.loads((OUT / 'import-boundary-controls.json').read_text())
check('9 separate optional controls all green on combined module',
      optional['count'] == 9 and all(x['passed'] for x in optional['controls'])
      and optional['source'] == str(REPO / 'src/patchtrace/optional_deps.py'))
run = json.loads((OUT / 'control-run.json').read_text())
check('isolated control execution and cleanup source exact', run['exit_code'] == 0
      and run['before'] == run['after'] == {'head':HEAD,'tree':TREE,'status':''}
      and run['isolated'] and run['dont_write_bytecode']
      and run['abandoned_after'] == 0 and run['new_net_workers_after'] == []
      and not run['environment_installed_or_rebound'])
for row in run['module_bindings']:
    path = Path(row['path']).relative_to(REPO).as_posix()
    check('actual independent import blob/hash: ' + row['module'],
          sha(blob(HEAD,path)) == row['sha256'] and val('rev-parse',HEAD+':'+path) == row['git_blob'])

root_counts, root_ids = junit(QUAL / 'maintained.xml')
q = json.loads((QUAL / 'qualification.json').read_text())
check('root 480 maintained result independently recounted, not rerun', root_counts ==
      {'cases':480,'distinct_cases':480,'failures':0,'errors':0,'skipped':0}
      and q['source'] == HEAD and q['tree'] == TREE and len(set(q['selectors'])) == 17
      and q['maintained']['exit_code'] == 0 and all(x['exit_code'] == 0 for x in q['tooling']))
check('root explicit separate remaining gates/no full-native claim', not q['full_suite_run']
      and not q['native_or_windows_claim'] and not q['environment_rebound_or_installed']
      and q['source_before_and_after_exact_and_clean'])
root_bindings = json.loads((QUAL / 'source-binding.json').read_text())['modules']
for name, row in root_bindings.items():
    path = Path(row['path']).relative_to(REPO).as_posix()
    check('root actual import hash: ' + name, sha(blob(HEAD,path)) == row['sha256'])

check('worktree exact clean after all review actions', val('rev-parse','HEAD') == HEAD
      and val('rev-parse','HEAD^{tree}') == TREE and not val('status','--porcelain=v1'))
result = {'source':HEAD,'tree':TREE,'parent':PARENT,'base':BASE,
          'observed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'check_count':len(checks),'all_passed':all(x['passed'] for x in checks),
          'changed_paths':sorted(all_paths),'unchanged_tracked_entries':len(unchanged),
          'commit_count':len(all_commits),'incoming_groups':incoming_groups,
          'ordered_integration_stages':stages,'complete_history':actual_history,
          'record_reconstructions':reconstructions,'docstring_only_ast_unchanged':True,
          'archives':archive_checks,'independent_pytest':own_counts,
          'independent_optional_controls':9,'root_maintained_result_verified':root_counts,
          'root_maintained_tests_rerun':False,'full_native_or_external_target_tests':False}
(OUT / 'source-and-receipt-proof.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['source','tree','check_count','all_passed','commit_count',
                 'unchanged_tracked_entries','independent_pytest','independent_optional_controls',
                 'root_maintained_result_verified']},indent=2))
