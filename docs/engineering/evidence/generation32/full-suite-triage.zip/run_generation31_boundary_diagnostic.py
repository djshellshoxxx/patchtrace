"""One authorized, bounded run of two existing display-text tests; no source edits."""
from __future__ import annotations

import hashlib
import json
import os
import signal
import subprocess
import time
import xml.etree.ElementTree as ET
from datetime import UTC, datetime
from pathlib import Path

import psutil

ROOT = Path('/workspace/scratch/b1d1356aa953')
REPO = ROOT / 'patchtrace-integration'
OUT = ROOT / 'generation31-full-suite-triage'
PYTHON = ROOT / 'patchtrace-venv/bin/python'
EXPECTED = 'a024f9ece556daa6e4f095c52fe9a8cc4c31ce28'
NODE = 'tests/test_codetext_tokens.py::test_hostile_text_is_covered_within_a_loose_time_bound'
WALL_CAP = 60.0
RSS_CAP = 768 * 1024 * 1024
LOG = OUT / 'boundary-diagnostic.log'
JUNIT = OUT / 'boundary-diagnostic.xml'
RECEIPT = OUT / 'boundary-diagnostic-run.json'
SAMPLES = OUT / 'boundary-diagnostic-samples.json'


def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


OUT.mkdir(exist_ok=True)
assert git('rev-parse', 'HEAD') == EXPECTED
assert not git('status', '--porcelain')
assert not any(path.exists() for path in [LOG, JUNIT, RECEIPT, SAMPLES]), 'One-shot output already exists'
command = [str(PYTHON), '-m', 'pytest', '-vv', '--setup-show', '--durations=2',
           '--junitxml=' + str(JUNIT), NODE + '[number-tails-c]', NODE + '[number-tails-asm]']
env = dict(os.environ, QT_QPA_PLATFORM='offscreen', PYTHONPATH=str(REPO / 'src'))
info = {
    'schema': 'patchtrace-bounded-boundary-diagnostic/1',
    'source_commit': EXPECTED,
    'source_tree': git('rev-parse', 'HEAD^{tree}'),
    'started_at_utc': datetime.now(UTC).isoformat(),
    'command': command,
    'cwd': str(REPO),
    'explicit_environment': {key: env[key] for key in ['QT_QPA_PLATFORM', 'PYTHONPATH']},
    'fresh_process': True,
    'start_new_session': True,
    'repetitions': 1,
    'input_amplified': False,
    'original_assertion_elapsed_seconds': 3.0,
    'diagnostic_wall_cap_seconds': WALL_CAP,
    'diagnostic_process_tree_rss_cap_bytes': RSS_CAP,
    'sampling_interval_seconds': 0.05,
    'cap_semantics': 'A cap hit is diagnostic-incomplete, separate from unchanged acceptance assertions.',
    'state': 'running',
}
RECEIPT.write_text(json.dumps(info, indent=2) + '\n')
samples = []
events = []
cap_hit = None
stop_sent_at = None
last_offset = 0
pending_line = b''
started = time.monotonic()
with LOG.open('wb') as log:
    child = subprocess.Popen(command, cwd=REPO, env=env, stdout=log,
                             stderr=subprocess.STDOUT, start_new_session=True)
    process = psutil.Process(child.pid)
    info['child_pid'] = child.pid
    with LOG.open('rb') as reader:
        while child.poll() is None:
            elapsed = time.monotonic() - started
            pids, rss_values = [], []
            try:
                observed = [process, *process.children(recursive=True)]
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                observed = [process]
            for proc in observed:
                try:
                    pids.append(proc.pid)
                    rss_values.append(proc.memory_info().rss)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    pass
            total_rss = sum(rss_values)
            available = psutil.virtual_memory().available
            new_data = reader.read()
            if new_data:
                last_offset += len(new_data)
                pending_line += new_data
                parts = pending_line.split(b'\n')
                pending_line = parts.pop()
                for part in parts:
                    line = part.decode('utf-8', errors='replace')
                    if any(token in line for token in ['SETUP', 'TEARDOWN', '::test_', 'PASSED', 'FAILED', 'ERROR']):
                        events.append({'observed_elapsed_seconds': elapsed, 'line': line})
            samples.append({'elapsed_seconds': elapsed, 'process_tree_rss_bytes': total_rss,
                            'process_count': len(rss_values), 'host_available_bytes': available,
                            'log_bytes_observed': last_offset})
            if cap_hit is None and (elapsed >= WALL_CAP or total_rss > RSS_CAP):
                cap_hit = 'wall-time' if elapsed >= WALL_CAP else 'process-tree-rss'
                stop_sent_at = elapsed
                events.append({'observed_elapsed_seconds': elapsed, 'diagnostic_cap_hit': cap_hit})
                try:
                    os.killpg(child.pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
            if stop_sent_at is not None and elapsed - stop_sent_at >= 5:
                try:
                    os.killpg(child.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            time.sleep(0.05)
        returncode = child.wait()
duration = time.monotonic() - started
info.update(state='completed', returncode=returncode, diagnostic_cap_hit=cap_hit,
            finished_at_utc=datetime.now(UTC).isoformat(), duration_seconds=duration,
            sampled_peak_process_tree_rss_bytes=max((x['process_tree_rss_bytes'] for x in samples), default=0),
            sampled_min_host_available_bytes=min((x['host_available_bytes'] for x in samples), default=0),
            samples_count=len(samples), final_head=git('rev-parse', 'HEAD'),
            final_worktree_status=git('status', '--porcelain'), log_sha256=digest(LOG),
            phase_observation_method='pytest --setup-show/verbose lines sampled from its log; timestamps are observation times, not profiler measurements')
if JUNIT.exists():
    info['junit_sha256'] = digest(JUNIT)
    xml = ET.parse(JUNIT).getroot()
    info['junit_suites'] = [dict(suite.attrib) for suite in xml.iter('testsuite')]
    info['junit_cases'] = [dict(case.attrib) for case in xml.iter('testcase')]
SAMPLES.write_text(json.dumps({'samples': samples, 'phase_events': events}, indent=2) + '\n')
info['samples_sha256'] = digest(SAMPLES)
RECEIPT.write_text(json.dumps(info, indent=2) + '\n')
print(json.dumps(info, indent=2), flush=True)
