# Generation 31 — terminated full-suite triage

## Decision

The original full-suite attempt is **incomplete after SIGKILL; the kill's origin remains unestablished**. There is no supported basis to label it an OOM kill, a configured launcher timeout, a CodeText defect, or a successful qualification. The authorized isolated diagnostic passed its **two unchanged existing cases once**, and local testing stopped there.

Reviewed source: `a024f9ece556daa6e4f095c52fe9a8cc4c31ce28`, tree `1eb4f2197e22c9e46d25bded163ee241835572e6`. The tracked integration worktree remained clean throughout collection and the two-node diagnostic. There were no source edits, assertion changes, input amplification, whole-suite reruns, or remote mutations.

Machine-readable findings and artifact hashes are in [generation31-full-suite-triage.json](generation31-full-suite-triage.json).

## Original termination: established facts

The retained [launcher](run_generation30_full.py) started the same virtual environment's `python -m pytest -q` with `QT_QPA_PLATFORM=offscreen`, the integration checkout's `src` on `PYTHONPATH`, and JUnit output requested outside the repository. It uses `subprocess.run` without a timeout and records the child's actual return code. It converts a negative signal return into `128 - returncode` for its own exit status.

| Observation | Original evidence |
| --- | --- |
| Start | 2026-11-20 15:58:53.322845 UTC |
| Finish receipt | 2026-11-20 16:08:16.640276 UTC |
| Elapsed | 563.257508 seconds |
| Pytest child return | `-9`, corresponding to SIGKILL |
| Launcher exit | `137`, matching the retained conversion and coordinator's session report |
| Recorded maximum RSS | 1,113,696 KiB, about 1.06 GiB |
| Log | 4,045 bytes; SHA-256 `657c58634782f452d7e75f71412b85d348691c92279a42d0f48bb48009740848` |
| JUnit, terminal traceback, final pytest summary | Absent |
| Initial/final tracked status | Clean, same source commit |

The [original receipt](generation30-evidence/full-suite-run.json) says `state: completed` because the launcher finished recording its subprocess. That field does not establish successful pytest completion. The [original log](generation30-evidence/full-suite.log) is unchanged and its hash still matches the receipt.

The RSS number comes from `getrusage(RUSAGE_CHILDREN)` in the launcher. It is a child-process high-water statistic, not a synchronized sum of the process tree or the system's memory use. It does not reveal a memory quota or explain the signal.

## How far the run got

The original log contains **3,635 dot markers and 10 skip markers**, totaling **3,645 reported outcomes**. It contains no `F` or `E` markers. The last complete progress line shows **15%** after 3,600 markers, followed by another 45 markers and no final newline. These are partial reports; the final dot can precede that test's teardown. They must not be presented as a terminal 3,635-test pass or a completed suite.

The separately authorized collection-only command completed successfully on the same frozen source and virtual environment. It collected **23,936 unique node IDs**, with no test execution, in **22.63 seconds** according to pytest; launcher wall time was **29.464 seconds**, and its child maximum RSS was **540,280 KiB**. All 50 original displayed percentages agree with this collection's size. [Collection receipt](generation31-full-suite-triage/collection-run.json), [raw collection](generation31-full-suite-triage/collection.log), and [ordered node IDs](generation31-full-suite-triage/ordered-nodeids.json) are retained.

Under this fresh collection's ordering, the boundary is:

| One-based ordinal | Node | Original report |
| --- | --- | --- |
| 3,645 | `tests/test_codetext_tokens.py::test_hostile_text_is_covered_within_a_loose_time_bound[number-tails-c]` | Last dot marker |
| 3,646 | `tests/test_codetext_tokens.py::test_hostile_text_is_covered_within_a_loose_time_bound[number-tails-asm]` | Next expected node; no recorded result |

This identifies a diagnostic candidate, not a stack-confirmed killed call. The original run did not persist its active node or phase. The signal could have arrived during the preceding teardown or the next setup/call. Under the same ordering, **20,291 collected nodes lack original outcome markers**.

Before the diagnostic, the checkout's cached node list had only 141 entries and a 15:50:31 UTC modification time, predating the full run; it could not identify the last active node. The newest original temporary directory belonged to the final CLI secondary-run test, ordinal 3,015. Subsequent CodeText tests do not require a new `tmp_path`, so this timestamp was an earlier progress clue, not the termination location. The later diagnostic can update ignored pytest cache files; tracked source remained unchanged.

## Scope of the candidate and resource requirements

The ordinary path is `patchtrace.codetext.tokens.tokenize` → `_scan_line` → `_scan_c` or `_scan_asm`, followed by `open_comment_lines` and the test's coverage assertions. It processes synthetic display text. The selected tests perform no GUI interaction, native comparator execution, or execution of analyzed binaries; pytest's installed Qt plugin remains loaded normally.

The existing fixture has **117,030 ASCII characters**, across **30 newline-terminated lines of 3,900 non-newline characters each**. It is below the unchanged **4,096-character line limit** and **1,048,576-character document limit**. The existing timed operation assertion remains **less than 3.0 seconds**. The later, separate 150 ms benchmark was not reached under the mapped original progress and was not included in the diagnostic.

The test file, tokenizer, and name-classification module have identical Git blobs at generation 29 (`6c8b33b8`) and the frozen candidate. This comparison provides no reason to change the generation 30 integration. It does not rule out an older or order-dependent issue.

## Authorized two-case diagnostic

One fresh child ran exactly the two boundary nodes above, once, with the original virtual environment and environment overrides. Additional pytest arguments supplied verbose output, `--setup-show`, two duration entries, and a separate JUnit file. An external observer sampled the child's process-tree RSS and log phase output. The observer used a **60-second wall cap** and **768 MiB sampled process-tree RSS cap**, separately recorded as diagnostic limits. Neither cap triggered. No original assertion was changed.

| Result | Evidence |
| --- | --- |
| Terminal pytest result | **2 passed in 14.37 seconds** |
| Child exit | `0` |
| JUnit | 2 tests, 0 failures, 0 errors, 0 skips |
| Outer diagnostic wall time | 18.284739 seconds |
| Sampled peak process-tree RSS | 87,842,816 bytes, **83.77 MiB** |
| Sampling | 181 samples; one process observed throughout |
| Reported slowest phases | Initial C-case setup 11.04 seconds; ASM call 0.63 seconds |
| Source identity/status afterward | Same `a024f9ec` / `1eb4f219`; clean tracked worktree |

The long initial setup is distinct from the timed operation inside the test; the original three-second assertion passed. RSS is a sampled maximum, not a claim of continuous allocation tracing. Phase timestamps are the observer's log-read times. [Raw diagnostic log](generation31-full-suite-triage/boundary-diagnostic.log), [JUnit](generation31-full-suite-triage/boundary-diagnostic.xml), [run receipt](generation31-full-suite-triage/boundary-diagnostic-run.json), [phase/RSS observations](generation31-full-suite-triage/boundary-diagnostic-samples.json), and [one-shot launcher](run_generation31_boundary_diagnostic.py) are retained.

Both cases passing excludes an immediate reproduced isolated failure in this invocation. It does not reproduce the accumulated state of 3,645 preceding outcomes, prove the absence of an order-dependent issue, explain the original kill, or convert the full run into a pass. Testing stopped after these two cases.

## Supported cause versus hypotheses

**Supported mechanism:** the pytest child terminated by SIGKILL. **Unestablished origin:** why the signal was delivered.

- **OOM or a memory quota:** possible, but unsupported as an attribution. The exposed namespace has no `/sys/fs/cgroup` directory or memory-event counters. Ordinary `dmesg` access returns `Operation not permitted`; no readable conventional kernel log files were present. There is no original per-process memory trace or kill-time memory snapshot.
- **External timeout, supervisor action, or another signal sender:** possible, but not identified. The retained launcher has no timeout. The elapsed time alone cannot establish an external deadline.
- **Deterministic failure of the boundary cases:** not reproduced. Both existing cases passed once, unchanged. No original assertion traceback exists.
- **Source mutation during qualification:** not supported. The original receipt, collection, diagnostic, and final status checks agree on the frozen source.
- **Disk or system pressure:** no kill-time evidence establishes it. Later memory and filesystem observations are contextual only. In particular, `/tmp` is a memory-backed filesystem, and the exposed system reports no swap; those facts do not establish why the earlier process died.

The [postmortem resource observation](generation31-full-suite-triage/resource-observation.json) explicitly records that it was taken from a later tool process. Its process limits and available-memory readings must not be assigned to the killed pytest process.

## Historical comparison

The preserved earlier aggregate receipt for `bffcfa99` also reports SIGKILL, after **1,729.332 seconds** and **19,877 markers**, with two failure markers and no terminal JUnit. Its diagnostic record likewise reports unavailable cgroup/kernel evidence and an unestablished kill cause. Its original collection/log alignment shows dots for the same two named CodeText nodes. These are historical partial reports, not current acceptance evidence. The historical source object was unavailable locally for a new blob comparison.

An older ASM investigation also retains a genuine **156.169465 ms** failure against the unchanged **150 ms** benchmark, and its recovered change only improved measurement reporting. That separate timing result neither explains this SIGKILL nor justifies adjusting a threshold.

## Precise next actions

1. Preserve the original failed qualification attempt, this collection, and the isolated diagnostic as separate records. Use **“incomplete — SIGKILL, cause unestablished”** for the full run; retain the two passes only as focused diagnostic evidence.
2. Stop local test execution for this triage. No additional repeat, input enlargement, test exclusion, source change, or acceptance-threshold change is justified by these results.
3. Before attributing the kill, obtain an existing runner/orchestrator termination reason or kill-time memory/limit telemetry if the supported execution environment exposes it. Do not substitute later free-memory readings for those records.
4. For future source-pinned aggregate qualification on a supported runner, retain ordered collection IDs, flushed per-node/phase records, process-tree resource samples, visible memory-limit/event counters, and the runner's termination reason from the start. Keep the existing full-suite and platform gates unchanged; this report does not satisfy them.
