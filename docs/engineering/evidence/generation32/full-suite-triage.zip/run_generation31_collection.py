"""Bounded collection-only diagnostic; writes evidence outside the source checkout."""
from __future__ import annotations

import hashlib
import json
import os
import platform
import re
import resource
import subprocess
import time
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path('/workspace/scratch/b1d1356aa953')
REPO = ROOT / 'patchtrace-integration'
OUT = ROOT / 'generation31-full-suite-triage'
PYTHON = ROOT / 'patchtrace-venv/bin/python'
EXPECTED = 'a024f9ece556daa6e4f095c52fe9a8cc4c31ce28'
OUT.mkdir(exist_ok=True)


def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


head = git('rev-parse', 'HEAD')
assert head == EXPECTED, head
assert not git('status', '--porcelain')
command = [str(PYTHON), '-m', 'pytest', '--collect-only', '-q']
env = dict(os.environ, QT_QPA_PLATFORM='offscreen', PYTHONPATH=str(REPO / 'src'))
info = {
    'schema': 'patchtrace-collection-diagnostic/1',
    'source_commit': head,
    'source_tree': git('rev-parse', 'HEAD^{tree}'),
    'started_at_utc': datetime.now(UTC).isoformat(),
    'command': command,
    'cwd': str(REPO),
    'explicit_environment': {key: env[key] for key in ['QT_QPA_PLATFORM', 'PYTHONPATH']},
    'python': platform.python_version(),
    'wall_timeout_seconds': 120,
    'test_execution_requested': False,
}
started = time.monotonic()
with (OUT / 'collection.log').open('w') as handle:
    try:
        result = subprocess.run(command, cwd=REPO, env=env, stdout=handle,
                                stderr=subprocess.STDOUT, timeout=120)
        info['returncode'] = result.returncode
        info['timed_out'] = False
    except subprocess.TimeoutExpired:
        info['returncode'] = None
        info['timed_out'] = True
usage = resource.getrusage(resource.RUSAGE_CHILDREN)
info.update(finished_at_utc=datetime.now(UTC).isoformat(),
            duration_seconds=time.monotonic() - started,
            max_rss_kib=usage.ru_maxrss,
            final_head=git('rev-parse', 'HEAD'),
            final_worktree_status=git('status', '--porcelain'))
raw = (OUT / 'collection.log').read_bytes()
info['log_sha256'] = hashlib.sha256(raw).hexdigest()
lines = raw.decode('utf-8', errors='replace').splitlines()
nodeids = [line for line in lines if line.startswith('tests/') and '::' in line]
summary = [line for line in lines if re.search(r'\d+ tests? collected', line)]
(OUT / 'ordered-nodeids.json').write_text(json.dumps(nodeids, indent=2) + '\n')
info['parsed_nodeid_count'] = len(nodeids)
info['collection_summary_lines'] = summary
info['ordered_nodeids_sha256'] = hashlib.sha256((OUT / 'ordered-nodeids.json').read_bytes()).hexdigest()
info['boundary_items'] = [{'ordinal_one_based': i + 1, 'nodeid': nodeids[i]}
                          for i in range(max(0, 3645 - 8), min(len(nodeids), 3645 + 9))]
(OUT / 'collection-run.json').write_text(json.dumps(info, indent=2) + '\n')
print(json.dumps(info, indent=2), flush=True)
