"""Assemble retained evidence without executing tests or editing the checkout."""
from __future__ import annotations

import ast
import collections
import hashlib
import json
import re
import subprocess
import zipfile
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path('/workspace/scratch/b1d1356aa953')
REPO = ROOT / 'patchtrace-integration'
OUT = ROOT / 'generation31-full-suite-triage'


def artifact(path: Path) -> dict:
    data = path.read_bytes()
    return {'path': str(path.relative_to(ROOT)), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


receipt = json.loads((ROOT / 'generation30-evidence/full-suite-run.json').read_text())
collection = json.loads((OUT / 'collection-run.json').read_text())
diagnostic = json.loads((OUT / 'boundary-diagnostic-run.json').read_text())
nodeids = json.loads((OUT / 'ordered-nodeids.json').read_text())
raw = (ROOT / 'generation30-evidence/full-suite.log').read_bytes()
markers, percentages = '', []
for lineno, line in enumerate(raw.decode().splitlines(), 1):
    match = re.fullmatch(r'([.sFxXE]+)(?: \[\s*(\d+)%\])?', line)
    assert match is not None, (lineno, line)
    markers += match[1]
    if match[2] is not None:
        percentages.append({'line': lineno, 'reported_count': len(markers),
                            'percent': int(match[2]),
                            'matches_collection': int(match[2]) == len(markers) * 100 // len(nodeids)})
assert all(item['matches_collection'] for item in percentages)
assert len(nodeids) == len(set(nodeids)) == 23936

paths = ['tests/test_codetext_tokens.py', 'src/patchtrace/codetext/tokens.py',
         'src/patchtrace/codetext/names.py']
base = '6c8b33b851a22fb16d39b31693922359cd34ad12'
source_checks = []
for path in paths:
    before, after = git('rev-parse', f'{base}:{path}'), git('rev-parse', f'HEAD:{path}')
    source_checks.append({'path': path, 'base_blob': before, 'current_blob': after,
                          'equal': before == after, 'sha256': artifact(REPO / path)['sha256']})


def literal(node: ast.AST):
    if isinstance(node, ast.Constant) and isinstance(node.value, (str, int)):
        return node.value
    if isinstance(node, ast.BinOp) and isinstance(node.op, (ast.Add, ast.Mult)):
        a, b = literal(node.left), literal(node.right)
        return a + b if isinstance(node.op, ast.Add) else a * b
    raise TypeError(type(node).__name__)


tree = ast.parse((REPO / paths[0]).read_text())
fixture_dict = next(node.value for node in tree.body if isinstance(node, ast.Assign)
                    and any(isinstance(target, ast.Name) and target.id == 'HOSTILE'
                            for target in node.targets))
fixture = next(literal(value) for key, value in zip(fixture_dict.keys, fixture_dict.values)
               if literal(key) == 'number-tails')
historical_archive = REPO / 'docs/engineering/evidence/aggregate-qualification-20261120.zip'
with zipfile.ZipFile(historical_archive) as archive:
    assert archive.testzip() is None
    historic_receipt = json.loads(archive.read('aggregate-1/receipt.json'))
    historic_access = json.loads(archive.read('diagnostic-access.json'))
    oldids = [line for line in archive.read('collection-bffcfa99.txt').decode().splitlines()
              if line.startswith('tests/') and '::' in line]
    old_markers = ''
    for line in archive.read('aggregate-1/pytest.log').decode().splitlines():
        match = re.fullmatch(r'([.sFxXE]+)(?:\s+\[\s*\d+%\])?', line)
        if match:
            old_markers += match[1]
    historic_nodes = []
    for node in [nodeids[len(markers) - 1], nodeids[len(markers)]]:
        idx = oldids.index(node)
        historic_nodes.append({'nodeid': node, 'ordinal_one_based': idx + 1,
                               'progress_marker': old_markers[idx]})

temp_root = Path('/tmp/pytest-of-agent/pytest-42')
temp_rows = []
if temp_root.exists():
    for path in temp_root.iterdir():
        if path.is_symlink():
            continue
        stat = path.stat()
        temp_rows.append({'name': path.name, 'mtime_ns': stat.st_mtime_ns,
                          'mtime_utc': datetime.fromtimestamp(stat.st_mtime, UTC).isoformat()})
    temp_rows.sort(key=lambda row: row['mtime_ns'], reverse=True)

artifact_paths = [ROOT / 'generation30-evidence/full-suite.log',
                  ROOT / 'generation30-evidence/full-suite-run.json',
                  ROOT / 'run_generation30_full.py',
                  ROOT / 'run_generation31_collection.py',
                  ROOT / 'run_generation31_boundary_diagnostic.py',
                  OUT / 'collection.log', OUT / 'collection-run.json',
                  OUT / 'ordered-nodeids.json', OUT / 'resource-observation.json',
                  OUT / 'boundary-diagnostic.log', OUT / 'boundary-diagnostic.xml',
                  OUT / 'boundary-diagnostic-run.json', OUT / 'boundary-diagnostic-samples.json',
                  historical_archive]
evidence = {
    'schema': 'patchtrace-terminated-full-suite-triage/1',
    'observed_at_utc': datetime.now(UTC).isoformat(),
    'source_commit': git('rev-parse', 'HEAD'),
    'source_tree': git('rev-parse', 'HEAD^{tree}'),
    'tracked_worktree_status': git('status', '--porcelain'),
    'decision': 'qualification-incomplete; SIGKILL-origin-unestablished; two isolated boundary cases passed',
    'full_run': {key: receipt[key] for key in ['source_commit', 'source_tree',
                 'started_at_utc', 'finished_at_utc', 'duration_seconds', 'returncode',
                 'max_rss_kib', 'user_cpu_seconds', 'system_cpu_seconds']},
    'wrapper_exit_status': 137,
    'wrapper_exit_status_basis': '128 - child returncode in retained launcher, corroborated by parent session report',
    'launcher_timeout_configured': False,
    'junit_exists_for_original_run': (ROOT / 'generation30-evidence/full-suite.xml').exists(),
    'original_log_hash_matches_receipt': hashlib.sha256(raw).hexdigest() == receipt['log_sha256'],
    'partial_progress': {
        'markers': dict(collections.Counter(markers)), 'marker_total': len(markers),
        'failure_or_error_markers': sum(markers.count(c) for c in 'FE'),
        'last_displayed_percent': percentages[-1]['percent'],
        'additional_markers_after_last_percent': len(markers) - percentages[-1]['reported_count'],
        'percent_lines_matching_fresh_collection': len(percentages),
        'fresh_collection_total': len(nodeids),
        'nodes_without_reported_markers_under_same_order': len(nodeids) - len(markers),
        'last_reported_candidate': {'ordinal_one_based': len(markers), 'nodeid': nodeids[len(markers)-1]},
        'next_candidate': {'ordinal_one_based': len(markers)+1, 'nodeid': nodeids[len(markers)]},
        'qualification': 'Markers do not certify completed teardown or a terminal pass. Mapping assumes fresh same-source collection order; no original active-node trace exists.'},
    'collection_only': {key: collection[key] for key in ['command', 'returncode', 'duration_seconds',
                        'max_rss_kib', 'parsed_nodeid_count', 'collection_summary_lines',
                        'log_sha256', 'ordered_nodeids_sha256', 'final_worktree_status']},
    'resource_evidence': {
        'observation_file': str((OUT / 'resource-observation.json').relative_to(ROOT)),
        'cgroup_counters_available': False, 'kernel_log_available': False,
        'original_process_limits_captured': False,
        'original_process_tree_rss_trace_captured': False,
        'max_rss_qualification': 'Launcher RUSAGE_CHILDREN maximum; no synchronized process-tree/host-total measurement or memory-cap observation.',
        'postmortem_qualification': 'Resource snapshot comes from a later tool process; it cannot reconstruct kill-time pressure or limits.',
        'oom_attribution': 'unestablished',
        'external_timeout_or_supervisor_attribution': 'unestablished',
        'product_failure_attribution': 'unestablished'},
    'secondary_progress_clue': {
        'temporary_root': str(temp_root), 'latest_entries': temp_rows[:5],
        'last_temp_test_ordinal': next(i + 1 for i, node in enumerate(nodeids)
                                      if node.endswith('::test_interrupt_after_first_engine_keeps_its_stored_set')),
        'qualification': 'The newest temp directory identifies an earlier fixture, not the final active test; subsequent CodeText cases do not need tmp_path.'},
    'cache_observed_before_diagnostic': {
        'count': 141, 'mtime_utc': '2026-11-20T15:50:31.755801+00:00',
        'sha256': 'e4cb63a7fea18a3987d4982bc63c66a7b569a096411d9d1b7e822f8bb56841cf',
        'qualification': 'Predated original full run; not its execution trace. The later two-node run can update ignored pytest cache files.'},
    'candidate_path': {
        'package': 'patchtrace.codetext.tokens',
        'ordinary_scope': 'Synthetic display-text tokenization and coverage assertions; no GUI interaction, target binary or native comparator execution.',
        'calls': ['tokenize', '_scan_line', '_scan_c or _scan_asm', 'open_comment_lines', 'assert_covers'],
        'fixture': {'characters': len(fixture), 'ascii_bytes': len(fixture.encode('ascii')),
                    'line_count': len(fixture.splitlines()),
                    'nonnewline_characters_per_line': len(fixture.splitlines()[0]),
                    'existing_max_line_characters': 4096,
                    'existing_max_document_characters': 1048576, 'input_amplified': False},
        'original_elapsed_assertion_seconds': 3.0,
        'separate_150ms_benchmark_reached_by_progress_mapping': False,
        'source_comparison_base': base, 'source_comparisons': source_checks},
    'historical_comparison': {
        'source': historic_receipt['source_head'], 'returncode': historic_receipt['exit_code'],
        'duration_seconds': historic_receipt['elapsed_seconds'],
        'partial_markers': len(old_markers), 'kill_cause': historic_access['cause'],
        'same_named_node_markers': historic_nodes,
        'limitation': 'Historical source object unavailable locally; old names/progress are not current qualification or proof of identical historical source blobs.'},
    'bounded_diagnostic': diagnostic,
    'next_action': 'Stop local testing after the two passes. Preserve original incomplete run and seek runner kill/memory telemetry before attributing cause; future aggregate qualification needs a supported source-pinned runner.',
    'additional_tests_executed': 2, 'whole_suite_reruns': 0,
    'input_amplification': False, 'assertion_changes': False, 'source_edits': False,
    'remote_mutations': False,
    'artifacts': [artifact(path) for path in artifact_paths],
}
assert evidence['original_log_hash_matches_receipt']
assert evidence['tracked_worktree_status'] == ''
assert diagnostic['returncode'] == 0 and diagnostic['diagnostic_cap_hit'] is None
target = ROOT / 'generation31-full-suite-triage.json'
target.write_text(json.dumps(evidence, indent=2) + '\n')
print(json.dumps({'saved': str(target), 'sha256': artifact(target)['sha256'],
                  'decision': evidence['decision'], 'candidate': evidence['partial_progress']['next_candidate'],
                  'additional_tests_executed': 2, 'source_edits': False}, indent=2))
