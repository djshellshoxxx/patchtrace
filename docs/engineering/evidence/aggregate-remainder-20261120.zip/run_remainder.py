from __future__ import annotations
import collections
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import resource
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT=Path('/workspace/scratch/4c8dc848d760/pt-final-qa')
OUT=Path('/workspace/scratch/4c8dc848d760/validation/remainder-bffcfa99')
PY='/workspace/scratch/4c8dc848d760/venv/bin/python'
COLLECTION=Path('/workspace/scratch/4c8dc848d760/validation/collection-bffcfa99.txt')
ORIGINAL=Path('/workspace/scratch/4c8dc848d760/validation/aggregate-1/pytest.log')

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def now(): return dt.datetime.now(dt.timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
def save(value): (OUT/'manifest.json').write_text(json.dumps(value,indent=2)+'\n')
def key(node):
    parts=node.split('::')
    path=parts[0][:-3].replace('/','.')
    return ('.'.join([path,*parts[1:-1]]),parts[-1])

nodes=[x for x in COLLECTION.read_text().splitlines() if x.startswith('tests/') and '::' in x]
markers=''
for line in ORIGINAL.read_text().splitlines():
    m=re.fullmatch(r'([.sFxEX]+)(?:\s+\[\s*\d+%\])?',line)
    if not m: raise ValueError(f'Unexpected nonprogress line: {line!r}')
    markers+=m.group(1)
first_unreported=len(markers)
boundary=nodes[first_unreported].split('::')[0]
start=next(i for i,x in enumerate(nodes) if x.split('::')[0]==boundary)
remaining=nodes[start:]
by_module=collections.OrderedDict()
for node in remaining: by_module.setdefault(node.split('::')[0],[]).append(node)
batches=[]
mods=[]
count=0
for module,selected in by_module.items():
    if mods and count+len(selected)>300:
        batches.append(mods);mods=[];count=0
    mods.append(module);count+=len(selected)
if mods: batches.append(mods)

env=os.environ.copy();env['QT_QPA_PLATFORM']='offscreen';env['PYTHONPATH']=str(ROOT/'src')
manifest={
    'purpose':'Diagnostic coverage of modules not reached by the interrupted unsplit suite; does not qualify as a full-suite pass.',
    'source_head':git('rev-parse','HEAD'),'source_tree':git('rev-parse','HEAD^{tree}'),
    'initial_worktree_status':git('status','--porcelain'),
    'started_at':now(),'state':'running','runner_sha256':sha(Path(__file__)),
    'original_collection_sha256':sha(COLLECTION),'original_progress_log_sha256':sha(ORIGINAL),
    'original_collected_node_count':len(nodes),'original_progress_count':len(markers),
    'original_progress_counts':dict(collections.Counter(markers)),
    'boundary_module':boundary,'boundary_node_index_zero_based':start,
    'first_unreported_node_index_zero_based':first_unreported,
    'first_unreported_node':nodes[first_unreported],
    'original_failure_progress_nodes':[{'index':i,'nodeid':nodes[i]} for i,c in enumerate(markers) if c in 'FE'],
    'selected_node_count':len(remaining),'overlap_with_reported_progress_nodes':nodes[start:first_unreported],
    'previously_unreported_node_count':len(nodes)-first_unreported,
    'batch_test_count_limit':300,'batch_count':len(batches),
    'environment':{k:env.get(k) for k in ['QT_QPA_PLATFORM','PYTHONPATH','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','PYTHONHASHSEED']},
    'batches':[]
}
(OUT/'selected-nodeids.json').write_text(json.dumps(remaining,indent=2)+'\n')
save(manifest)
print(json.dumps({'started_at':manifest['started_at'],'selected':len(remaining),'batches':len(batches)}),flush=True)
for index,modules in enumerate(batches,1):
    stem=f'batch-{index:02d}'
    expected=[n for module in modules for n in by_module[module]]
    xmlpath=OUT/f'{stem}.xml'
    command=[PY,'-m','pytest','-q','--tb=short',f'--junitxml={xmlpath}','--durations=10',*modules]
    record={'number':index,'modules':modules,'expected_nodeids':expected,'expected_count':len(expected),'command':command,'started_at':now(),'state':'running'}
    manifest['batches'].append(record);save(manifest)
    start_time=time.monotonic()
    with (OUT/f'{stem}.log').open('wb') as log:
        process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
        _,status,usage=os.wait4(process.pid,0)
        process.returncode=os.waitstatus_to_exitcode(status)
    record.update({'ended_at':now(),'elapsed_seconds':round(time.monotonic()-start_time,3),'exit_code':process.returncode,'peak_rss_kib':usage.ru_maxrss,'user_cpu_seconds':usage.ru_utime,'system_cpu_seconds':usage.ru_stime,'state':'completed'})
    record['log']={'name':f'{stem}.log','sha256':sha(OUT/f'{stem}.log'),'bytes':(OUT/f'{stem}.log').stat().st_size}
    if xmlpath.exists():
        record['junit']={'name':xmlpath.name,'sha256':sha(xmlpath),'bytes':xmlpath.stat().st_size}
        key_to_nodes=collections.defaultdict(list)
        for node in expected: key_to_nodes[key(node)].append(node)
        counts=collections.Counter();results=[];covered=[];unmatched=[]
        for testcase in ET.parse(xmlpath).getroot().iter('testcase'):
            k=(testcase.attrib.get('classname',''),testcase.attrib.get('name',''))
            candidates=key_to_nodes.get(k,[])
            if len(candidates)!=1: unmatched.append({'junit_key':k,'candidates':candidates})
            node=candidates[0] if len(candidates)==1 else None
            if node: covered.append(node)
            outcome='passed'
            if testcase.find('failure') is not None: outcome='failed'
            elif testcase.find('error') is not None: outcome='error'
            elif testcase.find('skipped') is not None:
                outcome='xfail' if testcase.find('skipped').attrib.get('type')=='pytest.xfail' else 'skipped'
            counts[outcome]+=1
            results.append({'nodeid':node,'outcome':outcome,'seconds':testcase.attrib.get('time')})
        resultpath=OUT/f'{stem}-node-results.json';resultpath.write_text(json.dumps(results,indent=2)+'\n')
        record.update({'outcomes':dict(counts),'observed_testcases':len(results),'distinct_reconciled_nodeids':len(set(covered)),'missing_expected_nodeids':sorted(set(expected)-set(covered)),'unexpected_or_ambiguous_junit_cases':unmatched,'node_results':{'name':resultpath.name,'sha256':sha(resultpath)}})
    else: record['junit_missing']=True
    save(manifest)
    print(json.dumps({k:record.get(k) for k in ['number','expected_count','elapsed_seconds','exit_code','peak_rss_kib','outcomes','junit_missing','missing_expected_nodeids','unexpected_or_ambiguous_junit_cases']}),flush=True)
    if process.returncode not in (0,1):
        manifest['state']='stopped_after_abnormal_batch';break
else: manifest['state']='completed'
manifest.update({'ended_at':now(),'final_source_head':git('rev-parse','HEAD'),'final_source_tree':git('rev-parse','HEAD^{tree}'),'final_worktree_status':git('status','--porcelain')})
counts=collections.Counter()
covered=[]
for b in manifest['batches']:
    counts.update(b.get('outcomes',{}))
    if b.get('node_results'):
        covered.extend(x['nodeid'] for x in json.loads((OUT/b['node_results']['name']).read_text()) if x['nodeid'])
manifest['outcomes']=dict(counts)
manifest['distinct_reconciled_nodeids']=len(set(covered))
manifest['duplicated_reconciled_nodeids']=len(covered)-len(set(covered))
manifest['missing_selected_nodeids']=sorted(set(remaining)-set(covered))
save(manifest)
print(json.dumps({k:manifest[k] for k in ['state','ended_at','outcomes','distinct_reconciled_nodeids','duplicated_reconciled_nodeids','missing_selected_nodeids','final_worktree_status']}),flush=True)
