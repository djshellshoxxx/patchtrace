# Interrupted-suite remainder diagnostic coverage

This is bounded diagnostic coverage on frozen source `bffcfa99d6a5044024256edbc0457ab20c92cbae`. It is **not a passing unsplit full-suite qualification** and does not explain the earlier SIGKILL or replace its failures.

## Selection and reconciliation

- Original collection: 23,756 nodes.
- Original partial output: 19,877 progress markers, including 2 failures; no final traceback or JUnit from that run.
- First unreported node: `tests/test_ui_engine_setup.py::test_discovery_prefills_one_and_runs_nothing`.
- The complete boundary module was selected to preserve module fixtures, starting at zero-based node index 19,875.
- Diagnostic selection: 3,881 distinct nodes, including exactly 2 overlaps with already printed progress and 3,879 previously unreported nodes.
- Every expected node reconciled to exactly one JUnit testcase. Missing, ambiguous, extra, and duplicate selected IDs: zero.

## Execution and results

- Fourteen sequential fresh pytest processes, grouping whole modules up to 300 nodes per batch.
- `QT_QPA_PLATFORM=offscreen`; `PYTHONPATH` points at the frozen checkout's `src`; no source, assertion, skip, dependency, or policy changes.
- All fourteen process exits: 0.
- **3,849 passed; 32 skipped; 0 failed; 0 errors; 0 xfails.**
- Started `2026-11-20T00:44:02.768339+00:00`; ended `2026-11-20T00:51:44.505127+00:00`; wall interval 461.737 seconds.
- Highest `wait4`-reported child peak RSS: 845,428 KiB. This is a per-process resource observation, not total host or concurrent-process memory and not evidence of the prior kill cause.
- Frozen source HEAD, tree and clean tracked worktree state unchanged before/after.

## Existing skips

- 32: BLOCKED (recorded, not a pass): msvc-free: missing clang (not installed (not on PATH)), lld-link (not installed (not on PATH)), llvm-pdbutil (not installed (not on PATH)), llvm-objdump (not installed (not on PATH)), llvm-nm (not installed (not on PATH)), llvm-strip (not installed (not on PATH))

## Evidence

`manifest.json` contains every exact command, node selection, process result, timestamps, source identities, RSS measurement and SHA-256 of raw logs, JUnit XML and reconciled node results. `selected-nodeids.json` defines the distinct diagnostic selection. `skipped-tests.json` preserves each exact JUnit skip reason. `run_remainder.py` is the executed scratch harness and is hash-bound in the manifest.

The two original progress failures remain separate findings in the unsplit attempt. Completion of these diagnostic batches must not erase that outcome or be attributed to a later source revision.
