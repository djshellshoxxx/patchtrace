"""Bounded review controls importing the supplied exact inventory source."""
from pathlib import Path
import argparse, contextlib, csv, hashlib, importlib.util, io, json, subprocess, tempfile

parser=argparse.ArgumentParser()
parser.add_argument('--source-root',type=Path,required=True)
parser.add_argument('--output',type=Path,required=True)
args=parser.parse_args()
source=args.source_root/'tools'/'branch_inventory.py'
spec=importlib.util.spec_from_file_location('independent_inventory_controls',source)
tool=importlib.util.module_from_spec(spec); spec.loader.exec_module(tool)
receipts=[]

def git(repo,*argv):
 return subprocess.check_output(['git','-C',str(repo),*argv],stderr=subprocess.STDOUT,text=True,timeout=15).strip()

def record(name, **values):
 receipts.append({'name':name,'status':'passed',**values})

with tempfile.TemporaryDirectory(prefix='inventory-review-git-') as temporary:
 temp=Path(temporary)
 for fmt in ['sha1','sha256']:
  repo=temp/fmt; repo.mkdir()
  git(repo,'init','--quiet','--initial-branch=main','--object-format='+fmt)
  git(repo,'config','user.name','Inventory review fixture')
  git(repo,'config','user.email','fixture@example.invalid')
  (repo/'fixture.txt').write_text('synthetic local data\n',encoding='utf-8')
  git(repo,'add','fixture.txt'); git(repo,'commit','--quiet','-m','Synthetic fixture')
  oid=git(repo,'rev-parse','HEAD')
  assert len(oid)==(40 if fmt=='sha1' else 64)
  rows=[{'branch':'review/évidence','tip_sha':oid,'pr':'-','last_commit':'fixture','category':'unresolved','delete_safe':'no','note':'quoted "value"\t\n'+'x'*140000}]
  snapshot=repo/'captured.tsv'; snapshot.write_text(tool.render(rows),encoding='utf-8',newline='')
  old_limit=csv.field_size_limit()
  assert tool.branches(tool.Git(repo),'origin',snapshot)==[('review/évidence',oid)]
  assert csv.field_size_limit()==old_limit
  record(fmt+'-canonical-large-quoted-replay',oid_length=len(oid),snapshot_bytes=snapshot.stat().st_size)
  git(repo,'tag','-a','retained-object','-m','Synthetic annotated tag')
  tag_oid=git(repo,'rev-parse','refs/tags/retained-object')
  snapshot.write_text('branch\ttip_sha\nreview\t'+tag_oid+'\n',encoding='utf-8')
  try: tool.branches(tool.Git(repo),'origin',snapshot)
  except ValueError as error: assert str(error)=='branch snapshot tip does not match commit object'
  else: raise AssertionError('annotated tag object was accepted')
  record(fmt+'-annotated-tag-object-refused')
  blob=git(repo,'rev-parse',oid+':fixture.txt')
  snapshot.write_text('branch\ttip_sha\nreview\t'+blob+'\n',encoding='utf-8')
  output=repo/'output.tsv'; output.write_bytes(b'retained prior output\n')
  pulls=repo/'pulls.json'; pulls.write_text('[]',encoding='utf-8')
  with contextlib.redirect_stderr(io.StringIO()):
   try: tool.main(['--repo',str(repo),'--main',oid,'--candidate',oid,'--pulls-json',str(pulls),'--refs-tsv',str(snapshot),'--output',str(output)])
   except SystemExit as error: assert error.code==2
   else: raise AssertionError('blob object was accepted as commit')
  assert output.read_bytes()==b'retained prior output\n'
  record(fmt+'-blob-object-refused-preserving-output')
  snapshot.write_text('branch\ttip_sha\nreview\t'+oid+'\n',encoding='utf-8')
  with contextlib.redirect_stdout(io.StringIO()):
   assert tool.main(['--repo',str(repo),'--main',oid,'--candidate',oid,'--pulls-json',str(pulls),'--refs-tsv',str(snapshot),'--output',str(output)])==0
  parsed=list(csv.DictReader(io.StringIO(output.read_text(encoding='utf-8')),delimiter='\t'))
  assert len(parsed)==1 and parsed[0]['tip_sha']==oid and parsed[0]['delete_safe']=='no'
  record(fmt+'-complete-offline-cli-publication')
 path=temp/'duplicate-escaped-key.json'
 path.write_bytes(b'[{"head":{},"\\u0068ead":{"ref":"private-input"}}]')
 try: tool.read_json(path)
 except ValueError as error:
  assert str(error)=='invalid pull-request metadata: duplicate JSON key'
  assert 'private-input' not in str(error)
 else: raise AssertionError('escaped duplicate key accepted')
 record('escaped-equivalent-key-refused-with-fixed-message')
 path=temp/'bad-utf8.json'; path.write_bytes(b'[{"note":"\xffprivate-input"}]')
 try: tool.read_json(path)
 except ValueError as error: assert str(error)=='invalid pull-request metadata JSON'
 else: raise AssertionError('invalid UTF-8 accepted')
 record('real-invalid-utf8-refused-with-fixed-message')
 original_limit=tool.MAX_METADATA_BYTES; tool.MAX_METADATA_BYTES=32
 path=temp/'oversized.json'; path.write_bytes(b'[{}]'+b' '*33)
 try: tool.read_json(path)
 except ValueError as error: assert str(error)=='pull-request metadata exceeds 32 MiB'
 else: raise AssertionError('oversized metadata accepted')
 finally: tool.MAX_METADATA_BYTES=original_limit
 record('bounded-pr-metadata-reader-refuses-before-decoding')
result={'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'git_version':subprocess.check_output(['git','--version'],text=True).strip(),'controls':receipts,'count':len(receipts),'limitations':'Synthetic local Git and metadata controls only; no complete repository suite, hosted or native acceptance.'}
args.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
