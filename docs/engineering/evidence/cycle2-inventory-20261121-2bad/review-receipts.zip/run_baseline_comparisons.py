from pathlib import Path
import hashlib, json, os, subprocess, time, xml.etree.ElementTree as ET
ROOT=Path('/tmp/patchtrace-2bad-inventory-review')
OUT=Path('/tmp/patchtrace-2bad-inventory-evidence')
PY=Path('/workspace/scratch/2bade0b323c3/qualification-venv/bin/python')
TESTS=['test_branch_inventory.py','test_branch_inventory_pr_json_strict_20261120.py']
CASES=[
 ('large-field-baseline','39c38a02f126963fc03827fa49741255590227ad','test_branch_inventory.py','snapshot_replays_large_quoted_evidence_and_restores_csv_limit'),
 ('column-shape-baseline','b461ac64eb9beb74449ce2b18b6795a2af34a02a','test_branch_inventory.py','snapshot_refuses_malformed_columns or snapshot_accepts_reordered_columns or invalid_snapshot_headers'),
 ('immutable-oid-baseline','eaae7e504f8b43051f0c0d6d57c314d37c66d7ff','test_branch_inventory.py','snapshot_rejects_noncanonical_tip or snapshot_refuses_tag_object or snapshot_full_commit_oid'),
 ('strict-json-baseline','a63a20b2a272d53a09422222050080823fc3c664','test_branch_inventory_pr_json_strict_20261120.py',''),
]
receipts=[]
for name,revision,test,select in CASES:
 stage=OUT/name
 (stage/'tools').mkdir(parents=True,exist_ok=True)
 (stage/'tests').mkdir(exist_ok=True)
 raw=subprocess.check_output(['git','show',f'{revision}:tools/branch_inventory.py'],cwd=ROOT)
 (stage/'tools'/'branch_inventory.py').write_bytes(raw)
 test_raw=(ROOT/'tests'/test).read_bytes()
 (stage/'tests'/test).write_bytes(test_raw)
 xml=OUT/(name+'.xml'); log=OUT/(name+'.log')
 cmd=[str(PY),'-m','pytest','-q','-c','/dev/null','-p','no:cacheprovider','--confcutdir',str(stage/'tests'),str(stage/'tests'/test),'--junitxml='+str(xml)]
 if select: cmd+=['-k',select]
 started=time.monotonic()
 with log.open('wb') as stream:
  result=subprocess.run(cmd,cwd=stage,stdout=stream,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},timeout=45)
 suites=ET.parse(xml).getroot().findall('testsuite')
 summary={key:sum(int(s.get(key,'0')) for s in suites) for key in ['tests','failures','errors','skipped']}
 receipt={'name':name,'revision':revision,'runtime_blob':subprocess.check_output(['git','rev-parse',f'{revision}:tools/branch_inventory.py'],cwd=ROOT,text=True).strip(),'runtime_sha256':hashlib.sha256(raw).hexdigest(),'test_sha256':hashlib.sha256(test_raw).hexdigest(),'test':test,'selection':select or 'all','command':cmd,'exit_code':result.returncode,'seconds':round(time.monotonic()-started,6),**summary,'log':log.name,'junit':xml.name}
 receipts.append(receipt)
 print(json.dumps(receipt),flush=True)
(OUT/'baseline-comparisons.json').write_text(json.dumps(receipts,indent=2)+'\n')
