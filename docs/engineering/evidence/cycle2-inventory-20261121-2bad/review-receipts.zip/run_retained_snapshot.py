from pathlib import Path
import csv, hashlib, importlib.util, io, json, subprocess, zipfile
ROOT=Path('/tmp/patchtrace-2bad-inventory-review')
OUT=Path('/tmp/patchtrace-2bad-inventory-evidence')
DONOR='c07774ecf5a3f7337834f95a9a4c51c8ec5fad44'
ARCHIVE='docs/engineering/evidence/cycle95fe/cycle-95fe-evidence.zip'
raw_archive=subprocess.check_output(['git','show',DONOR+':'+ARCHIVE],cwd=ROOT,timeout=20)
archive=zipfile.ZipFile(io.BytesIO(raw_archive))
raw=archive.read('raw/branch-inventory.tsv')
snapshot=OUT/'retained-captured-inventory.tsv'; snapshot.write_bytes(raw)
spec=importlib.util.spec_from_file_location('retained_inventory_reader',ROOT/'tools'/'branch_inventory.py')
tool=importlib.util.module_from_spec(spec); spec.loader.exec_module(tool)
old_limit=csv.field_size_limit(tool.MAX_METADATA_BYTES)
try: rows=list(csv.DictReader(io.StringIO(raw.decode('utf-8'),newline=''),delimiter='\t',strict=True))
finally: csv.field_size_limit(old_limit)
expected=sorted((row['branch'],row['tip_sha']) for row in rows if row['branch']!='main')
assert len(expected)==353
returned=tool.branches(tool.Git(ROOT),'origin',snapshot)
assert returned==expected
assert csv.field_size_limit()==old_limit
rendered=tool.render(rows).encode('utf-8')
assert rendered==raw
result={'donor_commit':DONOR,'donor_archive':ARCHIVE,'archive_sha256':hashlib.sha256(raw_archive).hexdigest(),'member':'raw/branch-inventory.tsv','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'rows':len(rows),'exact_branch_tip_pairs':len(returned),'same_rendered_bytes':rendered==raw,'csv_limit_restored':csv.field_size_limit()==old_limit,'source_sha256':hashlib.sha256((ROOT/'tools'/'branch_inventory.py').read_bytes()).hexdigest(),'scope':'Captured snapshot parsing, exact commit resolution and serialization compatibility; no fresh semantic history analysis or completeness claim.'}
(OUT/'retained-snapshot.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
