# Native fixture toolchain capability check

The 32 existing compiler-dependent skips remain **blocked** on frozen source
`bffcfa99d6a5044024256edbc0457ab20c92cbae`. No pass is claimed and no test was
rerun only to reproduce the already known skips.

The required `clang`, `lld-link`, `llvm-pdbutil`, `llvm-objdump`, `llvm-nm` and
`llvm-strip` commands, including the project's supported version-suffixed names,
are absent from the current PATH. `/usr/lib/llvm-19` contains `lib` only, without
a `bin` directory. The ordinary known LLVM locations checked in the receipt do
not provide an executable toolchain.

The task runs as UID 1000. `sudo` is unavailable and
`/usr/local/bin/cloud-agent-packages` does not exist. The
`cloud-environment-runtime` skill's Packages guidance directs system dependency
installation through that helper and requires escalation for non-root use. The
current task explicitly excludes escalation. The ordinary `apt-cache policy`
query also reports permission denied reading
`/etc/apt/apt.conf.d/80-applied-apt-retries`; no configuration or permission was
changed to work around it. The inspected project specification and hosted
workflow use an installed LLVM toolchain; no supported user-level alternative
was identified there.

No package installation, network-policy change, Python-environment modification,
source edit or analyzed-target execution occurred. The source HEAD, tree and
clean worktree status remain unchanged. The source only generates and inspects
authored PE fixtures when the required compiler tools are present.

`capability-receipt.json` preserves exact capability observations and package
query results. `selected-nodeids.json` records exactly the original 32 skipped
node IDs, and the receipt contains their explicit replay command for a runner
with the required tools. These capabilities do not establish native Windows,
full-suite or accuracy qualification.
