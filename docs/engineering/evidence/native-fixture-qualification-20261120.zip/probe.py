"""Read-only capability receipt for the existing native fixture-toolchain skips."""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/workspace/scratch/4c8dc848d760/pt-final-qa')
OUT = Path(__file__).resolve().parent
SKIPS = Path('/workspace/scratch/4c8dc848d760/validation/remainder-bffcfa99/skipped-tests.json')
TOOLS = ('clang', 'lld-link', 'llvm-pdbutil', 'llvm-objdump', 'llvm-nm', 'llvm-strip')
SUFFIXES = ('', '-18', '-19', '-20', '-17')


def command(argv):
    result = subprocess.run(argv, cwd=ROOT, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return {'argv': argv, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr}


before = command(['git', 'status', '--porcelain'])
rows = json.loads(SKIPS.read_text())
nodes = [row['classname'].replace('.', '/') + '.py::' + row['name'] for row in rows]
assert len(nodes) == len(set(nodes)) == 32
selection = ['python', '-m', 'pytest', '-q', *nodes, '--junitxml=native-fixture-results.xml']
(OUT/'selected-nodeids.json').write_text(json.dumps(nodes, indent=2)+'\n')

helper = Path('/usr/local/bin/cloud-agent-packages')
record = {
    'schema': 'patchtrace-native-fixture-capability/1',
    'recorded_at': datetime.now(timezone.utc).isoformat(),
    'source_head': command(['git', 'rev-parse', 'HEAD'])['stdout'].strip(),
    'source_tree': command(['git', 'rev-parse', 'HEAD^{tree}'])['stdout'].strip(),
    'status_before': before,
    'python': sys.version,
    'uid': os.getuid(),
    'tools_on_path': {name: {name+suffix: shutil.which(name+suffix) for suffix in SUFFIXES} for name in TOOLS},
    'known_tool_directories': {str(path): {'exists': path.exists(), 'is_directory': path.is_dir()}
        for path in [Path('/usr/lib/llvm-19/bin'), Path('/opt/llvm/bin'), Path('/opt/llvm-19/bin'),
                     Path('/usr/local/swift/usr/bin')]},
    'llvm19_directory_entries': sorted(path.name for path in Path('/usr/lib/llvm-19').iterdir()),
    'system_install_capabilities': {
        'cloud_agent_packages': {'exists': helper.exists(), 'executable': os.access(helper, os.X_OK)},
        'sudo': shutil.which('sudo'),
        'apt_get': shutil.which('apt-get'),
    },
    'package_queries': [
        command(['dpkg-query', '-W', '-f=${binary:Package} ${Version}\n',
                 'clang-19', 'lld-19', 'llvm-19', 'llvm-19-tools']),
        command(['apt-cache', 'policy', 'clang-19', 'lld-19', 'llvm-19', 'llvm-19-tools']),
    ],
    'original_skip_file_sha256': hashlib.sha256(SKIPS.read_bytes()).hexdigest(),
    'original_skipped_cases': len(nodes),
    'replay_command_when_tools_are_available': selection,
    'replay_environment': {'QT_QPA_PLATFORM': 'offscreen', 'PYTHONPATH': 'src:tests'},
    'outcome': 'blocked-missing-tools-and-supported-install-helper',
    'pytest_replayed': False,
    'installs_attempted': False,
    'source_or_venv_changed': False,
    'escalation_or_network_policy_change': False,
    'status_after': command(['git', 'status', '--porcelain']),
    'source_head_after': command(['git', 'rev-parse', 'HEAD'])['stdout'].strip(),
    'source_tree_after': command(['git', 'rev-parse', 'HEAD^{tree}'])['stdout'].strip(),
    'limitations': [
        'This records ordinary selected-environment capabilities, not a system-wide filesystem absence proof.',
        'The cloud runtime Packages guidance requires cloud-agent-packages for system dependencies; it is absent.',
        'The task forbids escalation and no sudo executable is available.',
        'No project-supported user-level toolchain installation was found in the inspected build specification/workflow.',
        'Original skips are preserved; no test was converted to passed or rerun solely to reproduce the known skip.',
        'This does not qualify native Windows, full-suite acceptance or empirical accuracy.',
    ],
}
assert record['status_before']['stdout'] == record['status_after']['stdout'] == ''
assert record['source_head'] == record['source_head_after']
assert record['source_tree'] == record['source_tree_after']
(OUT/'capability-receipt.json').write_text(json.dumps(record, indent=2)+'\n')
print(json.dumps({k: record[k] for k in ('source_head', 'outcome', 'original_skipped_cases',
                                      'pytest_replayed', 'installs_attempted')}, indent=2))
