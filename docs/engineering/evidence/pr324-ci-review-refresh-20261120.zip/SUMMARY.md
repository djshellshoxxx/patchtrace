# PR #324 CI refresh after Linux full QA completed

Status captured **2026-11-20 01:03:45 UTC**. Earlier snapshots remain untouched.
PR #324 still has head `3862cb5de3256efec8f6392a3b6fb4d9e600c377` and base
`f2458aae22ea6177be64cfc2fb439a79950f00ff`; it is open, draft, mergeable and
`unstable`. These receipts do not qualify the newer PR #325 source.

QA run: https://github.com/djshellshoxxx/patchtrace/actions/runs/44644147625

## Newly completed checks

| Check | Terminal evidence |
|---|---|
| Linux full QA, job 135982353601 | **23,699 passed, 51 skipped, 6 xfailed**, 21 warnings in **2,269.52 seconds**; job completed success at 00:59:07 UTC. |
| Linux pair-publication selection in that job | **108 passed, 2 skipped** in 2.29 seconds; skips require native Windows sharing/handle and reparse/rooted-open acceptance. |
| Configured whole-tree Ruff in that job | `All checks passed!` |
| Linux Qt shard 4/4, 20 repeats, job 135982354090 | **9,660 repeated executions passed**, 40 warnings in **2,139.76 seconds**; job completed success at 00:59:39 UTC. |

The full JUnit contains exactly **23,756 testcases, zero failures and zero
errors**. Its 57 JUnit skipped elements distinguish 51 `pytest.skip` records and
six `pytest.xfail` records. `artifact-summary.json` preserves every skip reason.
Skips include optional dependencies/tooling and native platform acceptance; a
green job does not convert these to verified acceptance. Pair-publication cases
overlap the full suite, and Qt counts are repetitions; do not add these totals.

The two node IDs aligned with failure markers in the interrupted local run are
both passing testcase records in this hosted JUnit:

- `tests.test_gui_table::test_data_calls_are_independent_of_the_row_count`
- `tests.test_network_consent_guard::test_a_local_unix_socket_is_not_network`

This establishes their hosted outcomes, not the cause of the original local
failures or SIGKILL. The original local traceback did not survive.

Both newly retrieved logs record actual checkout
`deab5a058da7814f6fbef9b108faa73695c3882e`. The previously verified Git-data mapping
is copied into this refresh: that merge checkout and PR #324's head share the
complete tree `59c37a3ba7f2c67607bbca60eeb7e683ef391e47`.

## Exact local fixture selection on hosted Linux

The 32 exact node IDs supplied in the coordinator's
`validation/native-fixture-qualification/selected-nodeids.json` each match exactly
one testcase in the hosted full JUnit: **32 passed, zero skipped, zero failures
or errors, zero missing or ambiguous matches**. These are outcomes within the
full-suite total, not additional tests. `native-fixture-reconciliation.json`
records every node, outcome and duration, bound to the selection, JUnit and
artifact SHA-256 identities. The exact selected list is also preserved.

This supplies hosted Linux evidence for those selected cases at PR #324's source.
The local missing-toolchain capability block remains recorded. Compiler versions,
broader native acceptance and any outcome for PR #325 are not inferred.

## Remaining and unchanged checks

At capture, **Windows full QA, Windows Qt and Linux Qt shard 1/4 are still in
progress**. No completed failing job is present. The two native Windows Ghidriff
workflow runs remain successful across their five variants each; Linux Qt shards
2/4 and 3/4 remain successful. The release gate is skipped on the PR workflow.
The QA workflow itself has no terminal conclusion yet. No package artifact or
Windows package acceptance is claimed.

## Artifact integrity and retained files

The `qa-Linux` artifact, ID **14589828924**, was downloaded through the GitHub
connector. Its **409,710-byte** ZIP passed a CRC check and matches GitHub's SHA-256:

`af1c563a9fa6077c309d500278eeb6d8fdaf6c79384052e6abfbba2d4f56cfd9`

It contains the full raw `qa-results.xml`, `pair-publication-results.xml` and
`qa-leg-result.txt` (`success`). `artifact-summary.json` records member sizes and
hashes plus independently parsed counts and skip reasons. The complete decoded
Linux QA and Qt4 logs, compact public snapshot, source mapping and two selected
testcase records are retained beside it. `checksums.json` hashes every evidence
file in this refresh.

No remote write, retry, cancellation, workflow dispatch, dependency install,
source edit, merge or release was performed. Running jobs were not waited on.
