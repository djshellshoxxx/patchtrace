# PR #324 hosted CI review

Captured 2026-11-20 00:53–00:54 UTC. This is a source-pinned observation,
not a terminal qualification of the still-running QA workflow.

- PR: https://github.com/djshellshoxxx/patchtrace/pull/324
- Head: `3862cb5de3256efec8f6392a3b6fb4d9e600c377`
- Base: `f2458aae22ea6177be64cfc2fb439a79950f00ff`
- PR remains open and draft, mergeable but `unstable`.
- QA workflow: https://github.com/djshellshoxxx/patchtrace/actions/runs/44644147625

## Completed and pending results

| Scope | Observation |
|---|---|
| Native Windows Ghidriff PR workflow 44644147564 | Completed success, all five scenario jobs. |
| Native Windows Ghidriff push workflow 44644052715 | Completed success, all five scenario jobs. |
| Linux Qt shard 2/4, 20 repeats | 10,680 repeated executions passed in 1,324.01 seconds. |
| Linux Qt shard 3/4, 20 repeats | 8,640 repeated executions passed in 1,368.38 seconds. |
| Linux and Windows full QA | Both in the unsplit pytest step; terminal outcome unavailable. |
| Linux Qt shards 1/4 and 4/4, Windows Qt | In progress; terminal outcome unavailable. |
| Pair-publication controls in both QA legs | Completed step success. Counts await the QA artifacts. |
| QA JUnit/package artifacts | None available at capture. Packaging steps had not run. |
| Release gate | Intentionally skipped on this pull-request workflow. |

No completed failing job was present to diagnose. A later failure or success
requires a fresh observation. The repeated Qt counts are not distinct cases and
must not be added to full-suite or focused test totals.

Both completed Qt logs record checkout
`deab5a058da7814f6fbef9b108faa73695c3882e`. GitHub Git-data responses independently
confirm that this PR merge commit and the reported head have the same complete
tree, `59c37a3ba7f2c67607bbca60eeb7e683ef391e47`. The merge parents are the recorded
base and head. Exact source identity is retained in `source-identities.json`.

## Native evidence scope

The five native variants are the expected plain-Ghidriff cached-symbol failure
reproduction, PatchTrace clean analysis, seeded-symbol-store analysis, seeded
analysis without adjacent PDB files, and a byte-identical raw-cache hit. Job
success includes the expected reproduction; it is not five general accuracy
measurements.

The coordinator's downloaded clean-analysis artifact 14587409583 was independently
CRC-checked and SHA-256 verified here:
`1d1ea1d90856a31d9ee0c49e0af7cb8df09f8e9163aa3a3badc2a853ba029343`, 96,580 bytes.
Its backend receipt records actual process exit 0 after 93.953 seconds, Ghidra
12.0.4, Ghidriff 1.0.0, PyGhidra 3.2.0 and Python 3.12.10. The runtime JVM version
is explicitly `unverified`. This is native Windows execution on authored
fixtures, not empirical binary-analysis accuracy or qualification of a newer
acquisition follow-up.

`snapshot-20261120-0053.json` retains compact public PR, check, run, job/step and
artifact metadata. The two completed Qt terminal logs are retained in full as
decoded by the GitHub connector. `native-clean-receipt.json` preserves the
independently checked backend receipt; the full ZIP remains at the coordinator's
existing `validation/pr324-native-patchtrace-clean.zip` path. `checksums.json`
records every local evidence file.

No workflow was retried, cancelled or dispatched. No remote write, source edit,
installation, merge, release or test replay was performed in this review.
