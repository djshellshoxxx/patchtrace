"""Read-only audit controls against a pinned exported source; authored temp fixtures only."""
from __future__ import annotations

import pytest

from patchtrace import persistence, verified_backup
from patchtrace.sample import synthetic_pe
from patchtrace.service import ProjectService


@pytest.fixture
def service(tmp_path):
    older, newer = tmp_path / "older.bin", tmp_path / "newer.bin"
    older.write_bytes(synthetic_pe(0))
    newer.write_bytes(synthetic_pe(1))
    verified_backup.forget_all()
    with ProjectService.create(older, newer, "Authored audit fixture", tmp_path / "case") as svc:
        yield svc
    verified_backup.forget_all()


def _notes(project):
    return [annotation.text for annotation in project.annotations]


def test_backup_cleanup_failure_preserves_original_cancellation(service, tmp_path, monkeypatch):
    before = service.store.load(recover_interrupted=False)
    interruption = KeyboardInterrupt("authored backup cancellation")
    destination = tmp_path / "backup"

    def interrupted_copy(*_args, **_kwargs):
        raise interruption

    def refused_cleanup(*_args, **_kwargs):
        raise PermissionError("authored staging cleanup refusal")

    caught = None
    with monkeypatch.context() as patch:
        patch.setattr(persistence.shutil, "copytree", interrupted_copy)
        patch.setattr(persistence.shutil, "rmtree", refused_cleanup)
        try:
            service.backup(destination)
        except BaseException as failure:
            caught = failure

    assert not destination.exists()
    assert service.store.load(recover_interrupted=False) == before
    assert len(list(tmp_path.glob(".patchtrace-backup-*"))) == 1
    assert caught is interruption, (
        f"Original cancellation was replaced by {type(caught).__name__}: {caught}"
    )


def test_backup_cli_retains_cancelled_exit_when_stage_cleanup_fails(
        service, tmp_path, monkeypatch, capsys):
    import json

    from patchtrace import cli

    root = service.root
    before = service.project
    service.close()

    def interrupted_copy(*_args, **_kwargs):
        raise KeyboardInterrupt("authored backup cancellation")

    def refused_cleanup(*_args, **_kwargs):
        raise PermissionError("authored staging cleanup refusal")

    with monkeypatch.context() as patch:
        patch.setattr(persistence.shutil, "copytree", interrupted_copy)
        patch.setattr(persistence.shutil, "rmtree", refused_cleanup)
        code = cli.main(["project", "backup", str(root), "--out", str(tmp_path / "copy"), "--json"])
    out, err = capsys.readouterr()
    result = json.loads(out)
    with ProjectService.open(root, maintenance=False) as reopened:
        assert reopened.project == before
    assert not (tmp_path / "copy").exists()
    assert "Traceback" not in err
    assert code == 5 and result["status"] == "cancelled", {"code": code, "result": result}


def _interrupt_first_history_backup(service, monkeypatch):
    monkeypatch.setattr(persistence, "HISTORY_KEEP", 1)
    interruption = KeyboardInterrupt("authored interruption after snapshot commit")

    def interrupted_backup(*_args, **_kwargs):
        raise interruption

    with monkeypatch.context() as patch:
        patch.setattr(verified_backup, "ensure_verified_backup", interrupted_backup)
        with pytest.raises(KeyboardInterrupt) as caught:
            service.annotate(service.project.artifacts[0].id, "first committed note")
    assert caught.value is interruption
    committed = service.store.load(recover_interrupted=False)
    assert _notes(committed) == ["first committed note"]
    assert not service.store.connection.in_transaction
    return committed


def test_post_commit_history_interruption_preserves_service_snapshot(service, monkeypatch):
    committed = _interrupt_first_history_backup(service, monkeypatch)
    assert service.project == committed, {
        "service_notes": _notes(service.project),
        "committed_notes": _notes(committed),
    }


def test_followup_annotation_retains_prior_committed_note(service, monkeypatch):
    _interrupt_first_history_backup(service, monkeypatch)
    service.annotate(service.project.artifacts[0].id, "second note")
    committed = service.store.load(recover_interrupted=False)
    assert _notes(committed) == ["first committed note", "second note"], {
        "observed_current_notes": _notes(committed),
        "history_rows": len(service.store.history()),
    }


def test_pre_commit_interruption_keeps_previous_memory_and_database(service, monkeypatch):
    before = service.store.load(recover_interrupted=False)

    def interrupted_save(_candidate):
        raise KeyboardInterrupt("authored pre-commit interruption")

    with monkeypatch.context() as patch:
        patch.setattr(service.store, "save", interrupted_save)
        with pytest.raises(KeyboardInterrupt):
            service.annotate(service.project.artifacts[0].id, "uncommitted note")
    assert service.project == before
    assert service.store.load(recover_interrupted=False) == before
