"""Independent backup outcome controls, using only authored temporary projects."""
from __future__ import annotations

import errno
import json
import sqlite3
from pathlib import Path

import pytest

from patchtrace import cli, persistence, verified_backup
from patchtrace.sample import synthetic_pe
from patchtrace.service import ProjectService


@pytest.fixture
def case(tmp_path):
    inputs = (tmp_path / 'old.bin', tmp_path / 'new.bin')
    for index, path in enumerate(inputs):
        path.write_bytes(synthetic_pe(index))
    input_bytes = tuple(path.read_bytes() for path in inputs)
    verified_backup.forget_all()
    with ProjectService.create(*inputs, 'Independent backup review', tmp_path / 'source') as service:
        yield service
    assert tuple(path.read_bytes() for path in inputs) == input_bytes
    verified_backup.forget_all()


def _stages(root):
    return list(root.glob('.patchtrace-backup-*'))


def test_database_copy_setup_failure_survives_busy_cleanup(case, tmp_path, monkeypatch):
    before = case.store.load(recover_interrupted=False)
    original = sqlite3.OperationalError('authored destination database failure')

    def refuse_database(*_args, **_kwargs):
        raise original

    def busy_cleanup(*_args, **_kwargs):
        raise OSError(errno.EBUSY, 'authored directory busy')

    with monkeypatch.context() as patch:
        patch.setattr(persistence.sqlite3, 'connect', refuse_database)
        patch.setattr(persistence.shutil, 'rmtree', busy_cleanup)
        with pytest.raises(sqlite3.OperationalError) as caught:
            case.backup(tmp_path / 'copy')
    assert caught.value is original
    assert len(original.__notes__) == 1
    assert original.__notes__[0].startswith('PT-STORAGE: temporary backup cleanup failed;')
    assert str(tmp_path) not in original.__notes__[0]
    assert not (tmp_path / 'copy').exists()
    assert len(_stages(tmp_path)) == 1
    assert case.store.load(recover_interrupted=False) == before


def test_real_publication_collision_retains_independent_destination(case, tmp_path, monkeypatch):
    publish = persistence._publish_no_replace
    destination = tmp_path / 'copy'
    before = case.store.load(recover_interrupted=False)

    def collide(stage, final):
        final.mkdir()
        (final / 'independent.txt').write_bytes(b'preserve this authored independent owner')
        publish(stage, final)

    def busy_cleanup(*_args, **_kwargs):
        raise OSError(errno.EBUSY, 'authored directory busy')

    with monkeypatch.context() as patch:
        patch.setattr(persistence, '_publish_no_replace', collide)
        patch.setattr(persistence.shutil, 'rmtree', busy_cleanup)
        with pytest.raises(FileExistsError) as caught:
            case.backup(destination)
    assert caught.value.errno == errno.EEXIST
    assert len(caught.value.__notes__) == 1
    assert {p.name for p in destination.iterdir()} == {'independent.txt'}
    assert (destination / 'independent.txt').read_bytes() == b'preserve this authored independent owner'
    assert len(_stages(tmp_path)) == 1
    assert case.store.load(recover_interrupted=False) == before


def test_success_never_probes_consumed_stage(case, tmp_path, monkeypatch):
    publish = persistence._publish_no_replace
    exists = Path.exists
    consumed = []

    def track_publish(stage, final):
        publish(stage, final)
        consumed.append(stage)

    def reject_obsolete_probe(path):
        assert path not in consumed, 'successful publication must not inspect the consumed pathname'
        return exists(path)

    with monkeypatch.context() as patch:
        patch.setattr(persistence, '_publish_no_replace', track_publish)
        patch.setattr(Path, 'exists', reject_obsolete_probe)
        result = case.backup(tmp_path / 'copy')
    assert len(consumed) == 1 and result == tmp_path / 'copy'
    with ProjectService.open(result, maintenance=False) as copied:
        assert copied.project == case.project


def test_already_removed_failed_stage_keeps_primary_without_false_note(case, tmp_path, monkeypatch):
    remove = persistence.shutil.rmtree
    interruption = KeyboardInterrupt('authored cancellation after stage disposal')

    def dispose_and_cancel(_source, destination):
        remove(destination.parent)
        raise interruption

    with monkeypatch.context() as patch:
        patch.setattr(persistence.shutil, 'copytree', dispose_and_cancel)
        with pytest.raises(KeyboardInterrupt) as caught:
            case.backup(tmp_path / 'copy')
    assert caught.value is interruption
    assert not getattr(interruption, '__notes__', [])
    assert not _stages(tmp_path)
    assert not (tmp_path / 'copy').exists()


def test_cli_database_stage_cancellation_survives_cleanup_fault(case, tmp_path, monkeypatch, capsys):
    source = case.root
    before = case.project
    case.close()
    connect = persistence.sqlite3.connect

    def interrupt_destination(path, *args, **kwargs):
        if Path(path).parent.name.startswith('.patchtrace-backup-'):
            raise KeyboardInterrupt('authored cancellation at database setup')
        return connect(path, *args, **kwargs)

    def cleanup_fault(*_args, **_kwargs):
        raise OSError(errno.EBUSY, 'authored cleanup refusal')

    with monkeypatch.context() as patch:
        patch.setattr(persistence.sqlite3, 'connect', interrupt_destination)
        patch.setattr(persistence.shutil, 'rmtree', cleanup_fault)
        result = cli.main(['project', 'backup', str(source), '--out', str(tmp_path / 'copy'), '--json'])
    stdout, stderr = capsys.readouterr()
    envelope = json.loads(stdout)
    assert result == 5 and envelope['status'] == 'cancelled'
    assert envelope['result'] is None
    assert 'Traceback' not in stderr
    assert not (tmp_path / 'copy').exists()
    assert len(_stages(tmp_path)) == 1
    with ProjectService.open(source, maintenance=False) as reopened:
        assert reopened.project == before
