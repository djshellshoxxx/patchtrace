"""Negative control: remove exactly one mapping while retaining its registry entry."""
from dataclasses import replace

import pytest


@pytest.fixture(autouse=True)
def remove_only_search_why_mapping(request, monkeypatch):
    if request.node.name != 'test_every_registry_id_is_applied_somewhere':
        return
    from patchtrace.search import qt_panel
    original = qt_panel.COLUMNS
    assert len(original) == 6
    assert sum(column.tip_id == 'search.col.why' for column in original) == 1
    mutated = tuple(replace(column, tip_id='') if column.key == 'why' else column for column in original)
    assert sum(a != b for a, b in zip(original, mutated, strict=True)) == 1
    monkeypatch.setattr(qt_panel, 'COLUMNS', mutated)

