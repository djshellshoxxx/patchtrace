# Independent Search header-help review

Reviewed candidate `b51b17615e2c72e167bfec15727336eaf7cfb57f`, tree
`1f123b7893c977796d89656959285e565adf1db2`, against
`6b6fcd3597a604212032ffc453477aeb6edc69ff` in a separate detached checkout
and source-bound Python environment. Author/root trees and remote state were
not modified. Review checkout was clean before and after.

## Outcome

No runtime or wiring blocker found. One low-severity help-text accuracy issue
should be corrected before accepting the six texts as fully verified.

### Finding S-H1: Why help promises reasons the details do not display

`src/patchtrace/search/tooltip_data.py`, `search.col.why`, says:
`Read-only. Select the row to inspect all recorded reasons and limits.`

`search/view_model.py:_why` can display the first evidence item's reason codes
when `rank_reasons` is empty. `detail_sections` instead displays only
`hit.rank_reasons` or the generic `matched the query`; it never renders the
stored `Evidence.reasons`. This affects even the first item's displayed
fallback reason, and reason details from other evidence are not displayed.

An authored, contract-valid input reproduced a Why cell of `text-words` while
the detail pane contains only `matched the query` in its reasons section.
Both recorded `text-words` and `name-words` codes and their details are absent.
The exact input, cell output, detail output and tooltip entries are retained
in `semantic-observation.json`. No binary, native engine or remote input was
executed.

Small scoped correction: replace the promise with
`Read-only. Select the row for ranking context, provenance and recorded limits.`
This preserves the existing runtime scope and avoids adding an unrequested
details feature. The Match help could similarly say that provenance for the
listed matching evidence is in the details: the pane lists other evidence's
kind/origin/locator, but does not reproduce every other matching snippet.
The Match phrase is a precision suggestion, not a separately established
runtime defect.

## Semantic review

| Header | Actual source behavior and disposition |
| --- | --- |
| Side | `sides_of` unions evidence sides and pairing counterpart sides. The help correctly explains that Both does not prove matching on both builds. |
| Kind | `row_view` takes the first evidence item's kind; provenance details may include other kinds. Text matches. |
| Match | `_match` uses the first item's title and optional snippet. Other evidence has provenance rows; use the more precise wording suggested above. |
| Where | `_where` uses the first locator and can borrow a known counterpart RVA, preferring newer, only if both RVA and file offset are absent. The retained navigation locator stays the first evidence locator. Text matches that distinction. |
| Change | `_change` combines available pairing category and recorded presence context, with Unknown/non-function fallbacks. Text preserves uncertainty and does not infer cause or absence. |
| Why | `_why` selects the first two rank reasons, then first evidence reason codes, then matched. The primary description is correct; the effect sentence overpromises detail visibility (S-H1). |

## Registration, roles, and behavior

SearchController registers TIPS before creating widgets. Both result reset and
result fill prepare the same six mapped COLUMNS. The normal host activation
path is exercised by the global audit; the candidate adds no exemptions.

Independent probes cleared all six registry entries before constructing a
controller and verified registration. They then removed/restored each entry
after rows existed, verified plain-title fallback and live escaped rich-text
lookup, and confirmed stable display/accessibility labels and no queries,
navigation or background work from reads.

ToolTipRole returns registered rich help. WhatsThisRole remains None for all
six headers; that is unchanged inherited behavior and the contract explicitly
serves header help through ToolTipRole. Native screen-reader and what's-this
work remain separate; this review does not claim them complete.

Independent populated-controller checks preserved cells, per-cell tooltips,
accessible text, row identity, selected row, sorted order and query generation
across all header reads. The Search header remains nonclickable for local
sorting, preserving the existing query-level sorting design.

## Executed verification

| Check | Exact result |
| --- | --- |
| Five maintained affected files | 140 passed, zero failed/skipped, 21.65 seconds |
| Three independent controller/role/sort/registration probes | 3 passed, 0.71 seconds |
| Negative control removing only Why's ColumnSpec mapping | Global actual-header audit failed exactly with `AssertionError: ['search.col.why']`; 1 expected failure, 2.73 seconds |
| Whole-tree Ruff | Passed |
| Dependency consistency | Passed |
| Source binding | `patchtrace` resolved inside the independent review checkout under Python `-I` |
| Tracked source state | Clean before and after; exact candidate SHA/tree unchanged |

The negative control uses an isolated pytest plugin to replace only one
ColumnSpec's tip_id with an empty string. It leaves all six registry entries,
the other five mappings, the global audit source and its exemptions untouched.
No test was weakened. The original failure log and JUnit are retained.

These are source-bound offscreen checks, not a full-suite, hosted, Windows,
native accessibility, packaging or release-acceptance claim. Evidence and
commands are recorded in `review-receipt.json`, the logs/XML, the independent
probe file and the mutation plugin in this directory.
