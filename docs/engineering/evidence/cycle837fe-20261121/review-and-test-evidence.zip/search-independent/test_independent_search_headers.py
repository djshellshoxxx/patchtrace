"""Independent actual-controller probes; authored inputs, no native acceptance claim."""
from PySide6.QtCore import Qt
from test_ui_search_panel import Rig, hit, result

from patchtrace import tooltips
from patchtrace.search import qt_panel

H = Qt.Orientation.Horizontal
D = Qt.ItemDataRole.DisplayRole
A = Qt.ItemDataRole.AccessibleTextRole
T = Qt.ItemDataRole.ToolTipRole
W = Qt.ItemDataRole.WhatsThisRole


def close(rig):
    rig.controller.shutdown()
    rig.shell.tasks.shutdown()


def test_controller_registers_all_search_columns_before_prepared_header_reads(qtbot, monkeypatch):
    for column in qt_panel.COLUMNS:
        monkeypatch.delitem(tooltips.REGISTRY, column.tip_id, raising=False)
    rig = Rig(qtbot, open_=False)
    try:
        model = rig.panel.table.table_model
        assert model.rowCount() == 0
        for i, column in enumerate(qt_panel.COLUMNS):
            assert column.tip_id in tooltips.REGISTRY
            assert model.headerData(i, H, T) == tooltips.tooltip(column.tip_id)
            assert model.headerData(i, H, D) == model.headerData(i, H, A) == column.title
            # The inherited contract serves rich header help in ToolTipRole only.
            assert model.headerData(i, H, W) is None
        assert not rig.calls and not rig.controller.tasks.busy()
    finally:
        close(rig)


def test_each_search_header_can_fall_back_and_observe_late_registry_restore(qtbot, monkeypatch):
    rig = Rig(qtbot)
    try:
        rig.search()
        model = rig.panel.table.table_model
        before = (rig.rows(), tuple(rig.calls), rig.controller.generation, model.key_at(0))
        for i, column in enumerate(qt_panel.COLUMNS):
            original = tooltips.REGISTRY[column.tip_id]
            monkeypatch.delitem(tooltips.REGISTRY, column.tip_id)
            assert model.headerData(i, H, T) == column.title
            late = tooltips.TooltipEntry('<late> & help', 'Independent late registration.', 'Read only.')
            monkeypatch.setitem(tooltips.REGISTRY, column.tip_id, late)
            rendered = model.headerData(i, H, T)
            assert '&lt;late&gt; &amp; help' in rendered and '<late>' not in rendered
            assert model.headerData(i, H, D) == model.headerData(i, H, A) == column.title
            assert model.headerData(i, H, W) is None
            monkeypatch.setitem(tooltips.REGISTRY, column.tip_id, original)
            assert model.headerData(i, H, T) == tooltips.tooltip(column.tip_id)
        assert (rig.rows(), tuple(rig.calls), rig.controller.generation, model.key_at(0)) == before
        assert not rig.controller.tasks.busy()
    finally:
        close(rig)


def test_header_reads_preserve_sorted_cells_selection_and_query_state(qtbot):
    seen = []

    def searcher(_service, request, _cancel):
        seen.append(request)
        return result(hits=[hit(0, title='Zulu'), hit(1, title='Alpha')], total=2)

    rig = Rig(qtbot, searcher=searcher)
    try:
        rig.search()
        table, model = rig.panel.table, rig.panel.table.table_model
        assert not table.horizontalHeader().sectionsClickable()
        table.selectRow(0)
        selected = table.current_key()
        model.sort(2, Qt.SortOrder.AscendingOrder)
        assert [model.key_at(i) for i in range(2)] == ['h1', 'h0']
        assert table.current_key() == selected
        cells = tuple(tuple(model.index(row, col).data(role) for role in (D, A, T))
                      for row in range(2) for col in range(6))
        before = (model.sort_state, table.current_key(), tuple(seen), rig.controller.generation)
        for i in range(6):
            assert model.headerData(i, H, T) == tooltips.tooltip(qt_panel.COLUMNS[i].tip_id)
            assert model.headerData(i, H, W) is None
        assert (model.sort_state, table.current_key(), tuple(seen), rig.controller.generation) == before
        assert tuple(tuple(model.index(row, col).data(role) for role in (D, A, T))
                     for row in range(2) for col in range(6)) == cells
        assert not rig.nav.anchors and not rig.shell.copied
    finally:
        close(rig)

