from datetime import datetime, timezone
from pathlib import Path
import json
import os
import subprocess
import time

ROOT = Path('/workspace/scratch/837fe19aae3a/PatchTrace-search-review')
OUT = Path('/workspace/scratch/837fe19aae3a/evidence/search-independent')
PYTHON = '/workspace/scratch/837fe19aae3a/search-review-venv/bin/python'


def git(*args):
    return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()


env = os.environ.copy()
env.update(QT_QPA_PLATFORM='offscreen', PYTHONDONTWRITEBYTECODE='1')
for key in ('PYTHONPATH', 'PYTHONHOME'):
    env.pop(key, None)
receipt = {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
           'status_before': git('status', '--short'), 'started_utc': datetime.now(timezone.utc).isoformat(),
           'results': []}
assert receipt['head'] == 'b51b17615e2c72e167bfec15727336eaf7cfb57f'
assert receipt['tree'] == '1f123b7893c977796d89656959285e565adf1db2'
assert not receipt['status_before']
checks = [
    ('source-binding', [PYTHON, '-I', '-c',
     'import json,pathlib,sys,patchtrace;print(json.dumps({"python":sys.executable,"source":str(pathlib.Path(patchtrace.__file__).resolve())}))']),
    ('maintained', [PYTHON, '-I', '-m', 'pytest', '-q', 'tests/test_search_header_help.py',
     'tests/test_ui_search_panel.py', 'tests/test_search_view_model.py', 'tests/test_tooltips.py',
     'tests/test_gui_table.py', '--junitxml=' + str(OUT / 'maintained.xml')]),
    ('independent', [PYTHON, '-I', '-c',
     'import sys,pytest;sys.path.insert(0,' + repr(str(ROOT / 'tests')) + ');raise SystemExit(pytest.main(' +
     repr(['-q', str(OUT / 'test_independent_search_headers.py'), '--junitxml=' + str(OUT / 'independent.xml')]) + '))']),
    ('missing-why-mutation', [PYTHON, '-I', '-c',
     'import sys,pytest;sys.path.insert(0,' + repr(str(OUT)) + ');raise SystemExit(pytest.main(' +
     repr(['-q', '-p', 'search_header_mutation', 'tests/test_tooltips.py::test_every_registry_id_is_applied_somewhere',
           '--junitxml=' + str(OUT / 'missing-why-mutation.xml')]) + '))']),
    ('ruff', [PYTHON, '-I', '-m', 'ruff', 'check', 'src', 'tests', 'tools']),
    ('dependencies', [PYTHON, '-I', '-m', 'pip', 'check']),
]
for name, command in checks:
    start = time.monotonic()
    with (OUT / (name + '.log')).open('w') as stream:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
    row = {'name': name, 'command': command, 'returncode': result.returncode,
           'seconds': round(time.monotonic() - start, 3)}
    receipt['results'].append(row)
    print(json.dumps(row), flush=True)
    (OUT / 'review-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
receipt['status_after'] = git('status', '--short')
receipt['finished_utc'] = datetime.now(timezone.utc).isoformat()
assert not receipt['status_after']
(OUT / 'review-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
