from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import subprocess

import patchtrace
from patchtrace.search import tooltip_data, view_model as vm
from patchtrace.search.contracts import SearchHit

root = Path('/workspace/scratch/837fe19aae3a/PatchTrace-search-review')
out = Path('/workspace/scratch/837fe19aae3a/evidence/search-independent')
old = 'b51b17615e2c72e167bfec15727336eaf7cfb57f'
new = '0069d0d28a8a8695d72f6ca960beaa7756b082ce'


def git(*args):
    return subprocess.check_output(['git', '-C', str(root), *args], text=True).strip()


assert git('rev-parse', 'HEAD') == new
assert git('rev-parse', 'HEAD^{tree}') == '6ebd9e8173cbb62218f308e0b33e89d1a43f71f3'
assert not git('status', '--short')
assert Path(patchtrace.__file__).resolve().is_relative_to(root)
assert git('diff', '--name-only', old, new) == 'src/patchtrace/search/tooltip_data.py'
prior = git('show', old + ':src/patchtrace/search/tooltip_data.py')
old_match = 'Shows the indexed text behind this result; other matching evidence is in the details.'
new_match = 'Provenance for the listed matching evidence is in the details.'
old_why = 'Read-only. Select the row to inspect all recorded reasons and limits.'
new_why = 'Read-only. Select the row for ranking context, provenance and recorded limits.'
assert prior.count(old_match) == prior.count(old_why) == 1
assert prior.replace(old_match, new_match).replace(old_why, new_why) == git('show', new + ':src/patchtrace/search/tooltip_data.py')
assert tooltip_data.ENTRIES['search.col.match'][1] == new_match
assert tooltip_data.ENTRIES['search.col.why'][2] == new_why
observation = json.loads((out / 'semantic-observation.json').read_text())
hit = SearchHit.model_validate_json(json.dumps(observation['input']))
assert vm.detail_text(hit) == observation['details']
assert list(vm.row_view(hit).cells) == observation['cells']
assert all(section in vm.detail_text(hit) for section in ('Why it ranks here', 'Provenance', 'Limitations'))
assert all(fragment in vm.detail_text(hit) for fragment in ('String older from ghidra', 'Function newer from ghidra',
                                                           'independent recorded limit'))
receipt = {
    'reviewed_at': datetime.now(timezone.utc).isoformat(), 'head': new, 'tree': git('rev-parse', 'HEAD^{tree}'),
    'previous_reviewed_head': old, 'source_import': str(Path(patchtrace.__file__).resolve()),
    'changed_files': git('diff', '--name-only', old, new).splitlines(),
    'changed_text_entries': ['search.col.match:why', 'search.col.why:effect'],
    'checks': {'exact_two_text_edits': True, 'original_semantic_input_replayed_unchanged': True,
               'new_promises_match_available_detail_sections': True, 'source_checkout_clean': True},
    'finding': 'S-H1 closed',
    'reviewer_harness_correction': 'Initial Python-value replay of JSON lists refused by strict tuples; use the existing JSON validation path. Initial failure retained separately.',
    'qualification_scope': 'Text-only independent source re-review. Original 140 maintained and 3 independent passes remain attached to b51b1761; no new broad test run is claimed.',
}
(out / 'review-addendum.json').write_text(json.dumps(receipt, indent=2) + '\n')
(out / 'review-addendum.md').write_text(
    '# Search header-help review addendum\n\n'
    f'Final candidate `{new}`, tree `{receipt["tree"]}`.\n\n'
    '**S-H1 closed. No remaining blocker in the reviewed Search header-help scope.**\n\n'
    f'The only source change since reviewed `{old}` is exactly two strings in `search/tooltip_data.py`. '
    'Why now offers ranking context, provenance and recorded limits without promising all recorded reasons. '
    'Match now explicitly offers provenance for the listed matching evidence. Both accurately describe the existing details pane.\n\n'
    'The original authored semantic input was replayed against the exact final source: all cells and detail text are unchanged, '
    'and the newly named detail sections/provenance/limits are present. Source binding and clean checkout identity were verified. '
    'No mapping, registry, role, sorting, cell, accessibility, navigation, query or test implementation changed.\n\n'
    'No unrelated broad tests were rerun. Original independent 140 maintained passes, 3 additional passes and the exact one-mapping '
    'audit failure remain evidence for their recorded b51b1761 source. Author final-source 68 passes and Ruff are separately recorded '
    'in `search-help-evidence/review-fix-receipt.json`; this addendum does not count those as independent execution. '
    'Native/hosted/full-suite acceptance remains outside this bounded text re-review.\n\n'
    'The initial reviewer-only replay used Python model validation on JSON-form lists and was correctly refused by the strict tuple '
    'contract. The successful replay uses model_validate_json, preserving the contract. This harness correction and initial failure '
    'are retained in review-addendum-initial-failure.json; no application edit or weakened validator was involved.\n')
manifest = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(out.iterdir())
            if p.is_file() and p.name != 'manifest.json'}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
