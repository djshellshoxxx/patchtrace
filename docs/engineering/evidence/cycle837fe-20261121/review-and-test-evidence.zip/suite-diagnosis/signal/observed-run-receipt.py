import json
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

label, repo, output, *command = sys.argv[1:]
dest=Path(output)
dest.mkdir(parents=True,exist_ok=True)
def git(*args):
    return subprocess.check_output(['git','-C',repo,*args],text=True).strip()
record={'label':label,'command':command,'cwd':repo,'head':git('rev-parse','HEAD'),'tree':git('rev-parse','HEAD^{tree}'),'dirty_before':git('status','--porcelain'),'started_at':datetime.now(timezone.utc).isoformat(),'qt_platform':os.environ.get('QT_QPA_PLATFORM'),'pythonpath':os.environ.get('PYTHONPATH')}
start=time.monotonic()
with (dest/(label+'.log')).open('w') as log:
    process=subprocess.Popen(command,cwd=repo,stdout=log,stderr=subprocess.STDOUT)
    record['pid']=process.pid
    (dest/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
    code=process.wait()
record.update(returncode=code,seconds=round(time.monotonic()-start,3),finished_at=datetime.now(timezone.utc).isoformat(),head_after=git('rev-parse','HEAD'),dirty_after=git('status','--porcelain'))
(dest/(label+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
print((dest/(label+'.log')).read_text()[-12000:])
raise SystemExit(code if code>=0 else 128-code)
