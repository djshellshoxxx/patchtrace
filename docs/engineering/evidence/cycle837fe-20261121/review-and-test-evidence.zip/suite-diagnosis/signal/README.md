# Full-suite SIGKILL evidence review

**Cause remains unestablished.** This read-only review did not obtain evidence assigning the kill to memory exhaustion, a timeout, a Qt defect, or a host policy.

## Confirmed event

Frozen source `b51b17615e2c72e167bfec15727336eaf7cfb57f`, tree `1f123b7893c977796d89656959285e565adf1db2`, remained clean and unchanged. The child returned **-9 (SIGKILL)** after **1,417.602 seconds**, from **2026-11-21 05:12:24.951573 UTC** to **05:36:02.553354 UTC**. The supervisor then wrote its receipt and exited 137. The last printed progress is **83%**. There is no terminal pytest summary or requested JUnit file. This is an incomplete run, not a full-suite pass.

The retained supervisor calls `subprocess.Popen` followed by `process.wait()` without a timeout, alarm, resource limit, or kill call. The original preflight records unlimited CPU, address-space, and data limits. It contains no cgroup counters or process memory sampling. The Qt fixtures, Qt cleanup helper, and job supervisor have identical Git blobs in PR348 and the tested source; that limited comparison does not exclude every external or compiled-runtime cause.

## Available host evidence and limits

- `/proc/self/cgroup` reports `0::/`. `/sys/fs/cgroup` does not exist, no cgroup mount is exposed, and `/proc/pressure/memory` is absent.
- `dmesg` returns **Operation not permitted**. `journalctl -k` reports **No journal files were found**. `/var/log/kern.log` and `/var/log/syslog` do not exist.
- A later ordinary process in the recorded environment has unlimited CPU/address-space/data/RSS limits, zero interval timers, no `PYTEST_ADDOPTS` or `PYTEST_TIMEOUT`, and only Hypothesis and pytest-qt entry points. Those observations cannot reconstruct the terminated child's runtime.
- The post-termination memory snapshot is retained, but it cannot prove or exclude a transient peak, an unexposed limit, or another host action. No child RSS/high-water sample, kernel OOM event, policy/quota receipt, or signal sender identity was obtained.
- Earlier repository reports retain SIGKILLs at different elapsed times and on different trees. They neither establish a universal deadline nor prove a common cause with this event.

The separately logged failure before the kill is being diagnosed independently. The available records do not establish that it caused the later SIGKILL.

## Next least-invasive step

Inspect existing exact-final-source hosted qualification. If another required run must diagnose termination, preserve low-overhead pytest node/phase events plus per-child resource/high-water observations, and obtain runner/kernel/host termination records. Keep fixture sizes, assertions, test selection, skip policy, and acceptance budgets unchanged. Do not rerun an unsplit aggregate merely to obtain another unexplained return code.

This inspection executed **no tests**, used no escalation, changed no source or limits, and performed no remote writes. Its JSON records and original-file hashes are retained beside this report.
