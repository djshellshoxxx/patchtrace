# Independent service snapshot review

**Disposition: no blocking finding remains in the reviewed scope. SVC-R1 and SVC-R2 are closed.**

Final service source: `1ce478b3f5dee036f54cb9e39353ef82cf1610c0`, tree `52b9926d6db21b4f76140c6385f67380acd0b988`.
Combined source: `b880c317add4de3ac22c87cd842abb0e7ccc615d`, tree `74a4ee3714ea492e84c2a2a3aaf41fa54849e404`.
The service implementation, its H2 contract and maintained regression file have identical blobs in both sources.

## Findings and closure

SVC-R1: after a failed outcome-reconciliation read, the initial latch guarded `_commit` but not `backup`. Backup could recover a stored running run and write/prune snapshots while that service still required reopening. The independent original control observed a successful backup and a history change from three rows to one. No note-loss or irreversible-history-loss claim was made for this path.

SVC-R2: a healthy backup could itself commit interrupted-run recovery, then be interrupted during deferred history maintenance before assigning the service snapshot. Independent controls observed `running` in memory and `failed` on disk, followed by a normal annotation restoring `running` to disk. This was separate from the intentional successful-backup recovery behavior.

The final source uses a shared entry guard for `_commit` and backup and shared outcome reconciliation for exceptions from either operation. Reconciliation reloads with `recover_interrupted=False`, preserves the original exception and does not write another snapshot. If that read also fails, the service remains latched until reopening. A healthy or reopened backup still performs its intended running-job recovery.

## Actual independent verification

| Source | Result |
| --- | --- |
| Initial `38e2d98f` | First independent batch: 7 passed, 1 failed; additional backup-recovery batch: 2 failed; maintained storage/corrections/UI selection: 139 passed |
| Final author `1ce478b3` | Independent controls plus maintained storage/corrections/UI selection: **155 passed**, no failures/skips |
| Combined `b880c317` | Ten independent controls plus both service and backup regression files: **34 passed**, no failures/skips |
| Combined `b880c317` | Whole-tree Ruff, dependency consistency, whitespace and isolated source binding passed; checkout remained clean |

The 155- and 34-case results are different selections on different complete source trees. They overlap each other and author/root tests; do not sum them.

The review traced every ordinary core snapshot editor through `_commit`, confirmed nonrecovering reads for export/discard, and reviewed correction exchange's use of `service.save()`. No additional snapshot-write bypass was established. Prepared import may stage evidence before snapshot application; this review does not claim that the uncertainty latch prohibits every filesystem operation.

All probes used authored temporary project files, real SQLite and offscreen UI. No analyzed binary or native analysis engine was executed. Full-suite, hosted and Windows acceptance remain with the coordinator.

## Evidence

`final-review.json` records source/blob identities, source-specific results and SHA-256 evidence digests. Original failed logs and JUnit files remain unchanged. `test_independent_service_recovery_initial.py` is byte-identical to the original eight-case control file, verified against the earlier recorded digest. The final control file additionally includes the two SVC-R2 cases.
