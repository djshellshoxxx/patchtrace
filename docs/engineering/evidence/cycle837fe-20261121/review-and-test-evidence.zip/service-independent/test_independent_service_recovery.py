"""Independent authored-project controls for save outcome reconciliation."""
from __future__ import annotations

import pytest

from patchtrace import persistence, verified_backup
from patchtrace.models import AnalysisRun
from patchtrace.sample import synthetic_pe
from patchtrace.service import ProjectService


@pytest.fixture
def service(tmp_path):
    older, newer = tmp_path / 'older.bin', tmp_path / 'newer.bin'
    older.write_bytes(synthetic_pe(0))
    newer.write_bytes(synthetic_pe(1))
    verified_backup.forget_all()
    try:
        with ProjectService.create(older, newer, 'Independent service review', tmp_path / 'case') as svc:
            yield svc
    finally:
        verified_backup.forget_all()


def _notes(project):
    return tuple(annotation.text for annotation in project.annotations)


def _fail_after_commit(service, monkeypatch, failure, *, fail_read=False):
    monkeypatch.setattr(persistence, 'HISTORY_KEEP', 1)
    calls = []
    load = service.store.load

    def interrupted_backup(*_args, **_kwargs):
        raise failure

    def reconciled_load(*, recover_interrupted=True):
        calls.append(recover_interrupted)
        if fail_read:
            raise ValueError('authored unavailable snapshot read')
        return load(recover_interrupted=recover_interrupted)

    with monkeypatch.context() as patch:
        patch.setattr(verified_backup, 'ensure_verified_backup', interrupted_backup)
        patch.setattr(service.store, 'load', reconciled_load)
        with pytest.raises(type(failure)) as raised:
            service.annotate(service.project.artifacts[0].id, 'committed before interruption')
    assert raised.value is failure
    assert calls == [False]
    committed = service.store.load(recover_interrupted=False)
    assert _notes(committed) == ('committed before interruption',)
    assert not service.store.connection.in_transaction
    return committed


@pytest.mark.parametrize('failure_type', (KeyboardInterrupt, SystemExit, OSError))
def test_reconciles_exact_snapshot_without_recovery_write(service, monkeypatch, failure_type):
    running = AnalysisRun(status='running')
    candidate = service.project.model_copy(deep=True)
    candidate.runs.append(running)
    service._commit(candidate)
    history = service.store.history()
    committed = _fail_after_commit(service, monkeypatch, failure_type('authored postcommit interruption'))
    assert service.project == committed
    assert service.project.runs[0].status == 'running'
    assert len(service.store.history()) == len(history) + 1
    service.annotate(service.project.artifacts[0].id, 'subsequent note')
    assert _notes(service.project) == ('committed before interruption', 'subsequent note')


@pytest.mark.parametrize('operation', ('save', 'annotate', 'record_terminal_run', 'swap_orientation'))
def test_latched_snapshot_edit_paths_never_reach_store_save(service, monkeypatch, operation):
    committed = _fail_after_commit(service, monkeypatch, KeyboardInterrupt('authored cancellation'), fail_read=True)
    history = service.store.history()

    def forbidden_save(_candidate):
        pytest.fail('uncertain service reached the snapshot writer')

    with monkeypatch.context() as patch:
        patch.setattr(service.store, 'save', forbidden_save)
        with pytest.raises(ValueError, match='PT-STORAGE:.*reopen'):
            if operation == 'annotate':
                service.annotate(service.project.artifacts[0].id, 'must not be written')
            elif operation == 'record_terminal_run':
                service.record_terminal_run(AnalysisRun(status='cancelled'))
            else:
                getattr(service, operation)()
    assert service.store.load(recover_interrupted=False) == committed
    assert service.store.history() == history


def test_latched_service_backup_cannot_commit_running_job_recovery(service, monkeypatch, tmp_path):
    running = AnalysisRun(status='running')
    candidate = service.project.model_copy(deep=True)
    candidate.runs.append(running)
    service._commit(candidate)
    committed = _fail_after_commit(service, monkeypatch, KeyboardInterrupt('authored cancellation'), fail_read=True)
    assert committed.runs[0].status == 'running'
    history = service.store.history()
    destination = tmp_path / 'should-not-back-up-unreconciled-service'
    failure = None
    result = None
    try:
        result = service.backup(destination)
    except ValueError as caught:
        failure = caught
    after = service.store.load(recover_interrupted=False)
    observed = {
        'failure': str(failure) if failure else None,
        'result': str(result) if result else None,
        'history_before': len(history),
        'history_after': len(service.store.history()),
        'run_status_before': committed.runs[0].status,
        'run_status_after': after.runs[0].status,
        'destination_exists': destination.exists(),
        'latch': service._commit_uncertain,
    }
    assert failure is not None and 'reopen' in str(failure), observed
    assert after == committed
    assert service.store.history() == history
    assert not destination.exists()


def _interrupt_backup_recovery(service, monkeypatch, tmp_path):
    candidate = service.project.model_copy(deep=True)
    candidate.runs.append(AnalysisRun(status='running'))
    service._commit(candidate)
    monkeypatch.setattr(persistence, 'HISTORY_KEEP', 1)
    failure = KeyboardInterrupt('authored backup-recovery postcommit interruption')

    def interrupted_maintenance(*_args, **_kwargs):
        raise failure

    with monkeypatch.context() as patch:
        patch.setattr(verified_backup, 'ensure_verified_backup', interrupted_maintenance)
        with pytest.raises(KeyboardInterrupt) as raised:
            service.backup(tmp_path / 'cancelled-backup')
    assert raised.value is failure
    committed = service.store.load(recover_interrupted=False)
    assert committed.runs[0].status == 'failed'
    assert not service.store.connection.in_transaction
    assert not (tmp_path / 'cancelled-backup').exists()
    return committed


def test_backup_recovery_interruption_refreshes_the_committed_service_snapshot(service, monkeypatch, tmp_path):
    committed = _interrupt_backup_recovery(service, monkeypatch, tmp_path)
    assert service.project == committed, {
        'memory_status': service.project.runs[0].status,
        'stored_status': committed.runs[0].status,
        'uncertain_latch': service._commit_uncertain,
    }


def test_edit_after_backup_interruption_does_not_resurrect_running_job(service, monkeypatch, tmp_path):
    _interrupt_backup_recovery(service, monkeypatch, tmp_path)
    service.annotate(service.project.artifacts[0].id, 'note after backup cancellation')
    committed = service.store.load(recover_interrupted=False)
    assert committed.runs[0].status == 'failed', committed.runs[0].model_dump()
    assert _notes(committed) == ('note after backup cancellation',)
