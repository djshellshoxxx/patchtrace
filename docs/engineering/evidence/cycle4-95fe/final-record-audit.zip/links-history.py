"""Read-only cycle4 documentation history and local Markdown destination audit."""
from __future__ import annotations

import difflib
import hashlib
import json
import re
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from urllib.parse import unquote, urlsplit

REPO = Path('/workspace/scratch/patchtrace-95fe-c4/coordinator')
OUT = Path('/workspace/scratch/patchtrace-95fe-c4/record-audit-final-evidence')


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True)


head = git('rev-parse', 'HEAD').strip()
assert head == '36584f8153983d64605dd7f4141e88c9fabfa6ef'
tracked = git('diff', '--name-only', 'HEAD').splitlines()
untracked = git('ls-files', '--others', '--exclude-standard').splitlines()
markdown = sorted(p for p in tracked + untracked if p.endswith('.md'))
snapshots = {p: (REPO / p).read_bytes() for p in tracked + untracked}
results = {'observed_at_utc': datetime.now(timezone.utc).isoformat(), 'head': head,
           'checks': {}, 'limitations': [
               'External URLs, live follow-up PR contents and remote ownership were not fetched.',
               'No local fragment-bearing Markdown link was found; fragment-anchor behavior was not needed.',
               'Archive contents, source mappings and test results are assigned to the parent auditor.',
           ]}
checks = results['checks']

old = json.loads(git('show', 'HEAD:docs/engineering/task-ledger.json'))
current = json.loads(snapshots['docs/engineering/task-ledger.json'])
assert current['tasks'][:len(old['tasks'])] == old['tasks']
old_changed = [k for k in old if k not in ('tasks', 'updated_at') and old[k] != current.get(k)]
assert not old_changed
assert set(current) - set(old) == {'parallel_followup_cycle4'}
added = current['tasks'][len(old['tasks']):]
added_ids = [x['id'] for x in added]
assert len(added_ids) == len(set(added_ids)) == 3
assert not set(added_ids) & {x['id'] for x in old['tasks']}
assert current['main_merge_eligible'] is False and current['release_ready'] is False
checks['ledger_history'] = {
    'old_tasks_preserved_as_exact_semantic_prefix': len(old['tasks']),
    'current_tasks': len(current['tasks']), 'added_task_ids': added_ids,
    'old_nonmetadata_fields_changed': old_changed,
    'metadata_change': {'updated_at_before': old['updated_at'], 'updated_at_after': current['updated_at']},
    'additive_top_level_key': 'parallel_followup_cycle4',
    'main_merge_eligible': current['main_merge_eligible'], 'release_ready': current['release_ready'],
    'serialization_note': 'Existing escaped Unicode became literal Unicode in a few strings; decoded values are unchanged.',
}

before_feature = json.loads(git('show', 'HEAD:docs/engineering/feature-status-20261119.json'))
after_feature = json.loads(snapshots['docs/engineering/feature-status-20261119.json'])
assert all(v == after_feature.get(k) for k, v in before_feature.items())
assert set(after_feature) - set(before_feature) == {'cycle4_parallel_followup'}
assert after_feature['cycle4_parallel_followup'] == current['parallel_followup_cycle4']
checks['feature_status'] = {'all_previous_values_preserved': True,
                            'additive_top_level_key': 'cycle4_parallel_followup',
                            'followup_object_equals_ledger': True}

checks['markdown_history'] = []
for path in tracked:
    if not path.endswith('.md'):
        continue
    before = git('show', 'HEAD:' + path).splitlines(keepends=True)
    after = snapshots[path].decode().splitlines(keepends=True)
    operations = difflib.SequenceMatcher(None, before, after, autojunk=False).get_opcodes()
    destructive = [x for x in operations if x[0] not in ('equal', 'insert')]
    assert not destructive, (path, destructive)
    checks['markdown_history'].append({'path': path, 'old_lines': len(before),
                                       'new_lines': len(after), 'insertion_only': True})

links = []
for path in markdown:
    text = snapshots[path].decode()
    candidates = [(m.start(), m.group(1), 'inline') for m in re.finditer(r'!?\[[^\]]*\]\(([^\n)]*)\)', text)]
    candidates += [(m.start(), m.group(1), 'reference') for m in re.finditer(r'^\s*\[[^\]]+\]:\s*(\S+)', text, re.M)]
    for offset, raw, kind in candidates:
        target = raw.strip()
        if not target or target.startswith(('#', 'http:', 'https:', 'mailto:', 'data:', 'sandbox:')):
            continue
        if target.startswith('<') and '>' in target:
            target = target[1:target.index('>')]
        else:
            target = target.split(' "', 1)[0]
        parsed = urlsplit(target)
        if parsed.scheme:
            continue
        destination = (REPO / path).parent / unquote(parsed.path)
        resolved = destination.resolve()
        inside_repo = resolved.is_relative_to(REPO)
        exists = resolved.exists()
        assert inside_repo and exists, (path, target, resolved)
        links.append({'source': path, 'line': text[:offset].count('\n') + 1,
                      'target': target, 'kind': kind, 'resolved': str(resolved.relative_to(REPO)),
                      'exists': exists, 'inside_repo': inside_repo, 'fragment': parsed.fragment})
checks['markdown_links'] = {'files': markdown, 'destinations_checked': len(links),
                            'missing': [], 'outside_repository': [],
                            'fragment_links': [x for x in links if x['fragment']], 'rows': links}

owner_paths = [p for p in markdown if p in tracked or p in (
    'docs/engineering/cycle4-consolidation-20261121-95fe.md',
    'docs/engineering-handoffs/cycle4-20261121-95fe.md')]
checks['owner_boundary_presence'] = []
for path in owner_paths:
    text = snapshots[path].decode()
    assert '837FE' in text, path
    checks['owner_boundary_presence'].append(path)
followup = current['parallel_followup_cycle4']
assert '837FE' in followup['ownership'] and 'does not replace' in followup['scope']
handoff = snapshots['docs/engineering-handoffs/cycle4-20261121-95fe.md'].decode()
assert 'Do not duplicate or mutate that work while its lease is active.' in handoff
assert '[no release]' in handoff and '[no deploy]' in handoff
checks['ownership_semantic_review'] = (
    'New report, handoff, all six indexes, QA/todo/release introduction and additive ledger preserve '
    '837FE ownership of PR349, Search/storage repairs and CODEX-1 Action pins. New instructions require '
    'fresh coordination and exact-head qualification; they do not supersede the foreign lease.'
)

for path, data in snapshots.items():
    assert (REPO / path).read_bytes() == data, ('changed during read-only audit', path)
assert git('rev-parse', 'HEAD').strip() == head
checks['inspected_file_digests'] = [
    {'path': p, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    for p, data in sorted(snapshots.items())
]
results['status'] = 'passed-no-blocking-history-owner-or-local-link-finding'
(OUT / 'links-history.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps({'status': results['status'], 'ledger_tasks_preserved': len(old['tasks']),
                  'added_tasks': len(added_ids), 'insertion_only_markdown_files': len(checks['markdown_history']),
                  'markdown_files_checked': len(markdown), 'relative_destinations_checked': len(links),
                  'missing_destinations': 0, 'source_unchanged_during_audit': True}, indent=2))
