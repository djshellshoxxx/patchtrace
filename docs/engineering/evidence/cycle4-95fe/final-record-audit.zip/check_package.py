"""Verify the assembled cycle4 records without changing coordinator source."""
from __future__ import annotations

import collections
import hashlib
import json
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/workspace/scratch/patchtrace-95fe-c4')
REPO = ROOT / 'coordinator'
PACKAGE = REPO / 'docs/engineering/evidence/cycle4-95fe'
OUT = ROOT / 'record-audit-final-evidence'
DOC = '36584f8153983d64605dd7f4141e88c9fabfa6ef'
BASE = '11f51c105bf63946f59373ae605b937c4fee607a'


def git(*args, cwd=REPO, data=None):
    return subprocess.run(['git', *args], cwd=cwd, input=data, check=True,
                          capture_output=True).stdout.decode().strip()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_text())


q = read(PACKAGE / 'qualification.json')
mapping = read(PACKAGE / 'code-publication-mapping.json')['source_mapping']
result = {'captured_at_utc': datetime.now(timezone.utc).isoformat(), 'source': DOC,
          'qualification_sha256': sha((PACKAGE / 'qualification.json').read_bytes()), 'checks': {}}
checks = result['checks']
assert git('rev-parse', 'HEAD') == DOC
assert git('diff', DOC, '--', 'src', 'tests', 'tools', '.github') == ''
assert not git('ls-files', '--others', '--exclude-standard', '--', 'src', 'tests', 'tools', '.github')
checks['source_unchanged'] = True
checks['tracked_doc_changes'] = git('diff', '--name-only', DOC).splitlines()
assert all(p.startswith(('docs/', 'tasks/')) for p in checks['tracked_doc_changes'])

local_to_remote = {m['local_commit']: m['remote_commit'] for m in mapping}
assert len(mapping) == len(local_to_remote) == 10
for row in mapping:
    raw = git('show', '-s', '--format=%T%n%P', row['local_commit']).splitlines()
    assert raw[0] == row['tree'] and raw[1].split() == row['local_parents']
    assert [local_to_remote.get(p, p) for p in row['local_parents']] == row['remote_parents']
assert local_to_remote[q['tested_local_commit']] == q['tested_remote_code_checkpoint']
assert local_to_remote[DOC] == q['reviewed_documentation_remote_checkpoint']
remote = read(OUT / 'remote-commit-verification.json')
assert len(remote['rows']) == 10 and all(row['verified'] for row in remote['rows'])
checks['commit_mappings'] = {'local': 10, 'independent_rest_verified': 10}

prefixes = {'buildenv-author': 'buildenv-evidence', 'buildenv-spec': 'buildenv-spec-evidence',
            'buildenv-standards': 'buildenv-standards-evidence', 'pages-spec': 'pages-spec-evidence',
            'pages-standards': 'pages-standards-evidence', 'root': 'root-evidence',
            'record-audit-initial': 'record-audit-evidence'}
checks['archives'] = []
for item in q['archives']:
    path = PACKAGE / item['path']
    assert path.stat().st_size == item['bytes'] and sha(path.read_bytes()) == item['sha256']
    with zipfile.ZipFile(path) as z:
        raw_manifest = json.loads(z.read('manifest.json'))
        if isinstance(raw_manifest, list):
            entries = raw_manifest
        elif 'payloads' in raw_manifest:
            entries = raw_manifest['payloads']
        else:
            entries = [dict(path=n, **v) for n, v in raw_manifest.items()]
        assert len(z.namelist()) == len(set(z.namelist()))
        assert set(z.namelist()) == {'manifest.json'} | {e['path'] for e in entries}
        copied = 0
        for entry in entries:
            data = z.read(entry['path'])
            assert sha(data) == entry['sha256']
            assert len(data) == entry.get('bytes', entry.get('size'))
            if item['path'] == 'cycle4-review-evidence.zip':
                first, _, rest = entry['path'].partition('/')
                original = (ROOT / prefixes[first] / rest if first in prefixes else
                            ROOT / rest if first in ('controls', 'reviews') else
                            PACKAGE / entry['path'])
                assert original.read_bytes() == data, entry['path']
                copied += 1
        checks['archives'].append({'name': item['path'], 'payloads': len(entries),
                                   'entries': len(z.namelist()), 'original_payloads_compared': copied,
                                   'bytes': path.stat().st_size, 'sha256': sha(path.read_bytes())})

with zipfile.ZipFile(PACKAGE / 'cycle4-review-evidence.zip') as z:
    cases = {}
    for c in ET.fromstring(z.read('root/final-affected-selection.xml')).iter('testcase'):
        identity = c.attrib['classname'] + '::' + c.attrib['name']
        assert identity not in cases
        state = 'passed'
        for tag in ('failure', 'error', 'skipped'):
            element = c.find(tag)
            if element is not None:
                state = 'xfailed' if tag == 'skipped' and element.get('type') == 'pytest.xfail' else tag
                break
        cases[identity] = state
    assert collections.Counter(cases.values()) == {'passed': 391, 'xfailed': 2}
    assert len(cases) == q['final_source']['unique_identities'] == 393
    assert cases['tests.test_site_screens::test_renderer_draws_the_real_gui_offscreen'] == 'passed'
    for label in ('final-pip-check', 'final-ruff', 'final-source-binding', 'final-whitespace'):
        receipt = json.loads(z.read('root/' + label + '.json'))
        assert receipt['head'] == receipt['head_after'] == DOC
        assert receipt['tree'] == q['reviewed_documentation_tree']
        assert receipt['returncode'] == 0 and receipt['dirty_before'] == receipt['dirty_after'] == ''
    checks['final_counts'] = dict(collections.Counter(cases.values()))
    checks['coordinator_finish_receipts'] = 4

bundle_meta = q['source_history_bundle']
bundle = PACKAGE / bundle_meta['path']
data = bundle.read_bytes()
assert len(data) == bundle_meta['bytes'] and sha(data) == bundle_meta['sha256']
header, pack = data.split(b'\n\n', 1)
assert header.startswith(b'# v2 git bundle\n') and pack.startswith(b'PACK')
header_lines = header.decode().splitlines()[1:]
prerequisites = [line[1:].split()[0] for line in header_lines if line.startswith('-')]
tips = [line.split()[0] for line in header_lines if not line.startswith('-')]
assert prerequisites == [BASE] and tips == [DOC]
verification = subprocess.run(['git', 'bundle', 'verify', str(bundle)], cwd=REPO,
                              capture_output=True, text=True, check=True)
(OUT / 'bundle-verification.log').write_text(verification.stdout + verification.stderr)
# Index the actual bundle pack in a separate bare repository; source repo is never mutated.
# Existing baseline objects may satisfy thin-pack bases. Then inspect packed objects to prove
# every one of the ten original commits is present in the supplied bundle itself.
audit_repo = OUT / 'bundle-verification.git'
git('init', '--bare', str(audit_repo), cwd=ROOT)
common = Path(git('rev-parse', '--git-common-dir'))
if not common.is_absolute():
    common = (REPO / common).resolve()
(audit_repo / 'objects/info/alternates').write_text(str(common / 'objects') + '\n')
indexed = git('index-pack', '--stdin', '--fix-thin', cwd=audit_repo, data=pack)
pack_sha = indexed.split()[-1]
verify_pack = git('verify-pack', '-v', str(audit_repo / 'objects/pack' / ('pack-' + pack_sha + '.idx')),
                  cwd=audit_repo)
packed_commits = {line.split()[0] for line in verify_pack.splitlines()
                  if len(line.split()) >= 2 and line.split()[1] == 'commit'}
assert packed_commits == set(local_to_remote), (packed_commits, set(local_to_remote))
checks['source_bundle'] = {'header': header.decode(), 'sha256': sha(data), 'bytes': len(data),
                           'packed_commit_count': len(packed_commits),
                           'packed_commit_ids': sorted(packed_commits), 'indexed_pack': pack_sha,
                           'git_verify': 'passed', 'actual_pack_commit_membership': 'passed'}
result['status'] = 'passed-final-package-core-checks'
(OUT / 'package-checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'commit_mappings': checks['commit_mappings'],
                  'archives': checks['archives'], 'counts': checks['final_counts'],
                  'packed_original_commits': len(packed_commits),
                  'coordinator_finish_receipts': checks['coordinator_finish_receipts']}, indent=2))
