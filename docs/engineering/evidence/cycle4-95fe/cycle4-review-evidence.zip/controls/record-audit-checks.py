"""Read-only evidence and Git-object audit; does not run repository tests."""
from __future__ import annotations

import collections
import email
import hashlib
import json
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from packaging.markers import default_environment
from packaging.requirements import Requirement
from packaging.utils import canonicalize_name

BASE_DIR = Path('/workspace/scratch/patchtrace-95fe-c4')
REPO = BASE_DIR / 'coordinator'
BASE = '11f51c105bf63946f59373ae605b937c4fee607a'
TESTED = '8c5e77e2c1ad3f6cfa62c2e474f7bcc2f4af1dd5'
DOC = '36584f8153983d64605dd7f4141e88c9fabfa6ef'
BUILD = 'b65fba2f5567f0b129331364bbf6db1cd699c901'
PAGES = '305d2d10fafeb4a7c8e566cdd0a3f67cccd97ec1'
OUT = BASE_DIR / 'record-audit-evidence'
OUT.mkdir(exist_ok=True)


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()


def blob(ref, path):
    return git('rev-parse', ref + ':' + path)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


result = {'captured_at_utc': datetime.now(timezone.utc).isoformat(), 'base': BASE,
          'tested': TESTED, 'document_head': DOC, 'checks': {}}
checks = result['checks']
assert git('rev-parse', TESTED + '^{tree}') == '6fe242cc10a5e7c3afe74c40a0f701cbab73aef1'
assert git('diff', '--name-only', TESTED, DOC).splitlines() == ['site/README.md']
source_paths = {
    BUILD: ['src/patchtrace/buildenv/panel_model.py', 'src/patchtrace/buildenv/tooltip_entries.py',
            'tests/test_buildenv_header_help.py', 'tests/test_tooltips.py'],
    PAGES: ['.github/workflows/pages.yml', 'tools/site/requirements-ci.lock',
            'tests/test_site_dependency_lock.py', 'tests/test_site_workflow.py'],
}
checks['reviewed_blob_comparisons'] = []
for ref, paths in source_paths.items():
    for path in paths:
        sha = blob(ref, path)
        assert sha == blob(TESTED, path) == blob(DOC, path), path
        checks['reviewed_blob_comparisons'].append({'path': path, 'reviewed_source': ref, 'blob': sha})
checks['retained_commits'] = [dict(zip(['commit', 'parents', 'subject'], line.split('|', 2))) for line in
    git('log', '--reverse', '--topo-order', '--format=%H|%P|%s', BASE + '..' + DOC).splitlines()]
assert len(checks['retained_commits']) == 10
for ref in (BUILD, PAGES):
    subprocess.run(['git', '-C', str(REPO), 'merge-base', '--is-ancestor', ref, TESTED], check=True)
unchanged = ['src/patchtrace/service.py', 'src/patchtrace/persistence.py',
             'src/patchtrace/search/qt_panel.py', 'tests/conftest.py', 'pyproject.toml']
checks['foreign_scope_and_fixture_blobs'] = [{'path': p, 'blob': blob(BASE, p)} for p in unchanged]
assert all(blob(BASE, p) == blob(DOC, p) for p in unchanged)
old_workflow = git('show', BASE + ':.github/workflows/pages.yml')
new_workflow = git('show', DOC + ':.github/workflows/pages.yml')
assert [line for line in old_workflow.splitlines() if 'uses:' in line] == [
    line for line in new_workflow.splitlines() if 'uses:' in line]
checks['action_refs_unchanged'] = True


def junit(path):
    cases = {}
    for case in ET.parse(path).getroot().iter('testcase'):
        identity = case.attrib.get('classname', '') + '::' + case.attrib['name']
        assert identity not in cases, ('duplicate junit identity', path, identity)
        state, reason = 'passed', None
        for tag in ('error', 'failure', 'skipped'):
            item = case.find(tag)
            if item is not None:
                state = 'xfailed' if tag == 'skipped' and item.attrib.get('type') == 'pytest.xfail' else tag
                reason = item.attrib.get('message')
                break
        cases[identity] = {'state': state, 'reason': reason}
    return cases


junit_paths = [p for folder in ('root-evidence', 'buildenv-evidence', 'buildenv-standards-evidence',
                                'codex5-evidence', 'pages-evidence') for p in (BASE_DIR / folder).glob('*.xml')]
all_cases = {str(p.relative_to(BASE_DIR)): junit(p) for p in junit_paths}
checks['junit_summaries'] = {name: {'counts': dict(collections.Counter(c['state'] for c in cases.values())),
                                 'nonpassing': {i: c for i, c in cases.items() if c['state'] != 'passed'}}
                            for name, cases in all_cases.items()}
final = all_cases['root-evidence/final-affected-selection.xml']
assert collections.Counter(c['state'] for c in final.values()) == {'passed': 391, 'xfailed': 2}
checks['final_identity_count'] = len(final)
checks['overlap_with_final'] = {name: len(set(cases) & set(final)) for name, cases in all_cases.items()}
screen = 'tests.test_site_screens::test_renderer_draws_the_real_gui_offscreen'
assert final[screen]['state'] == 'passed'
assert all_cases['pages-evidence/pages-site-tests.xml'][screen]['state'] == 'skipped'
checks['screenshot_disposition'] = {'site_only': 'existing PySide6-unavailable skip', 'full_environment': 'passed'}

checks['source_receipts'] = []
for folder in ('root-evidence', 'buildenv-evidence', 'buildenv-spec-evidence',
               'buildenv-standards-evidence', 'codex5-evidence', 'pages-evidence'):
    for p in (BASE_DIR / folder).glob('*.json'):
        d = read_json(p)
        if isinstance(d, dict) and all(k in d for k in ('head', 'tree', 'returncode', 'dirty_before', 'dirty_after')):
            assert git('rev-parse', d['head'] + '^{tree}') == d['tree'], p
            assert d['dirty_before'] == d['dirty_after'] == '', p
            assert d['head_after'] == d['head'], p
            checks['source_receipts'].append({'path': str(p.relative_to(BASE_DIR)), 'head': d['head'],
                                              'returncode': d['returncode']})

checks['loose_manifests'] = []
for folder in ('buildenv-evidence', 'buildenv-spec-evidence', 'buildenv-standards-evidence'):
    path = BASE_DIR / folder / 'manifest.json'
    d = read_json(path)
    entries = d.get('payloads') or [dict(path=p, **v) for p, v in d['files'].items()]
    root = BASE_DIR if folder == 'buildenv-spec-evidence' else path.parent
    for item in entries:
        data = (root / item['path']).read_bytes()
        assert digest(data) == item['sha256'], item['path']
        assert len(data) == item.get('bytes', item.get('size')), item['path']
    checks['loose_manifests'].append({'path': str(path.relative_to(BASE_DIR)), 'payloads_verified': len(entries)})

checks['archives'] = []
for name in ('codex5-research-evidence.zip', 'pages-implementation-evidence.zip'):
    path = BASE_DIR / name
    with zipfile.ZipFile(path) as archive:
        manifest = json.loads(archive.read('manifest.json'))
        entries = manifest if isinstance(manifest, list) else [dict(path=p, **v) for p, v in manifest.items()]
        assert set(archive.namelist()) == {item['path'] for item in entries} | {'manifest.json'}
        for item in entries:
            data = archive.read(item['path'])
            assert digest(data) == item['sha256']
            assert len(data) == item.get('bytes', item.get('size'))
    checks['archives'].append({'path': name, 'payloads_verified': len(entries),
                               'bytes': path.stat().st_size, 'sha256': digest(path.read_bytes())})

verification = read_json(BASE_DIR / 'codex5-evidence/site-wheel-verification.json')
lock_text = git('show', DOC + ':tools/site/requirements-ci.lock')
lock = {m[0]: (m[1], m[2]) for m in re.findall(r'^([a-z]+)==([0-9.]+) --hash=sha256:([0-9a-f]{64})$',
                                              lock_text, re.M)}
assert len(lock) == 7
checks['wheel_checks'] = []
checks['active_dependency_edges'] = []
env = default_environment()
env.update(python_version='3.12', python_full_version='3.12.14', sys_platform='linux',
           platform_machine='x86_64', implementation_name='cpython', platform_python_implementation='CPython', extra='')
for row in verification['rows']:
    name, version = row['name'], row['version']
    data = (BASE_DIR / 'codex5-evidence/wheelhouse' / row['filename']).read_bytes()
    assert len(data) == row['size'] and digest(data) == row['sha256']
    assert lock[name] == (version, digest(data))
    upstream = read_json(BASE_DIR / 'codex5-evidence' / f'pypi-{name}-{version}.json')
    artifacts = [u for u in upstream['urls'] if u['filename'] == row['filename']]
    assert len(artifacts) == 1
    u = artifacts[0]
    assert u['digests']['sha256'] == digest(data) and u['size'] == len(data) and not u['yanked']
    with zipfile.ZipFile(BASE_DIR / 'codex5-evidence/wheelhouse' / row['filename']) as wheel:
        metadata_files = [n for n in wheel.namelist() if n.endswith('.dist-info/METADATA')]
        assert len(metadata_files) == 1
        metadata = email.message_from_bytes(wheel.read(metadata_files[0]))
        assert canonicalize_name(metadata['Name']) == name and metadata['Version'] == version
        for value in metadata.get_all('Requires-Dist', []):
            requirement = Requirement(value)
            if requirement.marker and not requirement.marker.evaluate(env):
                continue
            dependency = canonicalize_name(requirement.name)
            assert dependency in lock and lock[dependency][0] in requirement.specifier
            checks['active_dependency_edges'].append({'from': name, 'to': dependency, 'requirement': value})
    checks['wheel_checks'].append({'name': name, 'version': version, 'filename': row['filename'],
                                  'sha256': digest(data), 'bytes': len(data)})
assert len(checks['active_dependency_edges']) == 4
checks['site_install_mode'] = read_json(BASE_DIR / 'pages-evidence/pages-hashed-install.json')['command']
assert '--no-index' in checks['site_install_mode'] and '--find-links' in checks['site_install_mode']
checks['remote_mutation_claim_limit'] = 'Local source and coordination receipt only; this audit performed no remote writes or dispatches.'
result['status'] = 'passed-initial-local-record-audit'
(OUT / 'initial-checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'status': result['status'], 'blob_checks': len(checks['reviewed_blob_comparisons']),
                  'retained_commits': len(checks['retained_commits']), 'final_cases': checks['final_identity_count'],
                  'counts': checks['junit_summaries']['root-evidence/final-affected-selection.xml']['counts'],
                  'source_receipts': len(checks['source_receipts']), 'wheel_checks': len(checks['wheel_checks']),
                  'dependency_edges': len(checks['active_dependency_edges']), 'archives': checks['archives']}, indent=2))
