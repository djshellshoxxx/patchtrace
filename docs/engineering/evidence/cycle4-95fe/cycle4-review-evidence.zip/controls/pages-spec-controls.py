"""Independent read-only Pages specification controls on frozen Git objects."""
from __future__ import annotations

import ast
import email
import hashlib
import json
import re
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path

from packaging.markers import default_environment
from packaging.requirements import Requirement
from packaging.specifiers import SpecifierSet
from packaging.utils import canonicalize_name, parse_wheel_filename

ROOT = Path('/workspace/scratch/patchtrace-95fe-c4')
REPO = ROOT / 'pages'
EVIDENCE = ROOT / 'codex5-evidence'
BASE = '11f51c105bf63946f59373ae605b937c4fee607a'
HEAD = '305d2d10fafeb4a7c8e566cdd0a3f67cccd97ec1'


def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()


def blob(ref, path):
    return subprocess.check_output(['git', '-C', str(REPO), 'show', f'{ref}:{path}'], text=True)


def lock_rows(text):
    rows = {}
    for line in text.splitlines():
        if not line.strip() or line.startswith('#'):
            continue
        match = re.fullmatch(r'([a-z][a-z0-9-]*)==([^ ]+) --hash=sha256:([0-9a-f]{64})', line)
        assert match, line
        name, version, digest = match.groups()
        assert name not in rows
        rows[name] = (version, digest)
    return rows


started = datetime.now(timezone.utc).isoformat()
before = git('status', '--porcelain')
lock = lock_rows(blob(HEAD, 'tools/site/requirements-ci.lock'))
assert set(lock) == {'segno', 'pillow', 'pytest', 'iniconfig', 'packaging', 'pluggy', 'pygments'}
assert lock['segno'][0] == '1.6.6' and lock['pillow'][0] == '12.3.0' and lock['pytest'][0] == '9.2.0'
environment = default_environment()
environment.update(python_version='3.12', python_full_version='3.12.14', sys_platform='linux',
                   platform_system='Linux', platform_machine='x86_64', os_name='posix',
                   implementation_name='cpython', platform_python_implementation='CPython', extra='')
verified, edges = [], []
for name, (version, digest) in sorted(lock.items()):
    raw = json.loads((EVIDENCE / f'pypi-{name}-{version}.json').read_text())
    candidates = [x for x in raw['urls'] if x['digests']['sha256'] == digest]
    assert len(candidates) == 1, (name, candidates)
    upstream = candidates[0]
    assert upstream['packagetype'] == 'bdist_wheel' and not upstream['yanked']
    wheel = EVIDENCE / 'wheelhouse' / upstream['filename']
    data = wheel.read_bytes()
    assert len(data) == upstream['size'] and hashlib.sha256(data).hexdigest() == digest
    wheel_name, wheel_version, _, tags = parse_wheel_filename(wheel.name)
    assert canonicalize_name(wheel_name) == name and str(wheel_version) == version
    if name == 'pillow':
        assert {str(t) for t in tags} == {'cp312-cp312-manylinux_2_27_x86_64', 'cp312-cp312-manylinux_2_28_x86_64'}
    else:
        assert {str(t) for t in tags} == {'py3-none-any'}
    with zipfile.ZipFile(wheel) as archive:
        metadata_paths = [p for p in archive.namelist() if p.endswith('.dist-info/METADATA')]
        assert len(metadata_paths) == 1
        metadata = email.message_from_bytes(archive.read(metadata_paths[0]))
    assert canonicalize_name(metadata['Name']) == name and metadata['Version'] == version
    assert '3.12.14' in SpecifierSet(metadata.get('Requires-Python', ''))
    for text in metadata.get_all('Requires-Dist', []):
        requirement = Requirement(text)
        if requirement.marker is not None and not requirement.marker.evaluate(environment):
            continue
        target = canonicalize_name(requirement.name)
        assert target in lock and lock[target][0] in requirement.specifier, (name, text)
        edges.append({'source': name, 'target': target, 'requirement': text, 'version': lock[target][0]})
    verified.append({'name': name, 'version': version, 'filename': wheel.name,
                     'sha256': digest, 'size': len(data), 'metadata_url': f'https://pypi.org/pypi/{name}/{version}/json'})
assert len(edges) == 4

old_install = 'python -m pip install --only-binary=:all: -r tools/site/requirements.txt pytest'
new_install = 'python -m pip install --require-hashes --only-binary=:all: -r tools/site/requirements-ci.lock'
old_test = 'python -m pytest -q tests/test_site_*.py'
new_test = 'python -m pytest --noconftest --disable-plugin-autoload -q tests/test_site_*.py'
workflow = blob(HEAD, '.github/workflows/pages.yml')
assert workflow.count(new_install) == workflow.count(new_test) == 1
assert workflow.replace(new_install, old_install).replace(new_test, old_test) == blob(BASE, '.github/workflows/pages.yml')
for path in ['tests/conftest.py', 'pyproject.toml', 'tools/site/requirements.txt']:
    assert blob(HEAD, path) == blob(BASE, path)
test_path = 'tests/test_site_workflow.py'
old_ast = ast.parse(blob(BASE, test_path))
new_ast = ast.parse(blob(HEAD, test_path).replace(new_test, old_test).replace('tools/site/requirements-ci.lock', 'tools/site/requirements.txt'))
assert ast.dump(old_ast) == ast.dump(new_ast)
changes = git('diff', '--name-only', BASE, HEAD).splitlines()
assert changes == sorted(['.github/workflows/pages.yml', 'docs/specs/pages-build-isolation-and-hashes.md',
                          'site/README.md', 'tests/test_site_dependency_lock.py', 'tests/test_site_workflow.py',
                          'tools/site/requirements-ci.lock'])

author = ROOT / 'pages-evidence'
bad = lock_rows((author / 'bad-hash.lock').read_text())
assert bad == {**lock, 'pillow': ('12.3.0', '0' * 64)}
missing = lock_rows((author / 'missing-dependency.lock').read_text())
assert missing == {k: v for k, v in lock.items() if k != 'pluggy'}
for label, code, diagnostic in [
    ('pages-hashed-install', 0, 'Successfully installed'),
    ('pages-damaged-hash-refusal', 1, 'DO NOT MATCH THE HASHES'),
    ('pages-missing-dependency-refusal', 1, 'all requirements must have their versions pinned with =='),
]:
    receipt = json.loads((author / (label + '.json')).read_text())
    assert receipt['head'] == HEAD and receipt['dirty_before'] == receipt['dirty_after'] == ''
    assert receipt['returncode'] == code and diagnostic in (author / (label + '.log')).read_text()

result = {'started_at': started, 'finished_at': datetime.now(timezone.utc).isoformat(),
          'base': BASE, 'head': HEAD, 'tree': git('rev-parse', HEAD + '^{tree}'),
          'dirty_before': before, 'dirty_after': git('status', '--porcelain'), 'python': sys.executable,
          'wheels_verified': verified, 'active_dependency_edges': edges,
          'workflow_preserved_except_two_commands': True, 'existing_test_assertions_preserved': True,
          'app_fixtures_and_portable_inputs_unchanged': True, 'original_pip_controls_verified': True,
          'result': 'passed', 'scope': 'Independent data/source controls; no extra repository pytest pass count.'}
print(json.dumps(result, indent=2))
