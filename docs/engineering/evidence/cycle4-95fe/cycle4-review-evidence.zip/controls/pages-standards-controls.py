"""Read-only exact-source checks for the Pages standards review."""
from __future__ import annotations

import email
import hashlib
import json
import re
import subprocess
import sys
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from xml.etree import ElementTree as ET

from packaging.markers import default_environment
from packaging.requirements import Requirement
from packaging.specifiers import SpecifierSet
from packaging.tags import sys_tags
from packaging.utils import canonicalize_name, parse_wheel_filename

ROOT = Path('/workspace/scratch/patchtrace-95fe-c4')
REPO = ROOT / 'pages'
BASE = '11f51c105bf63946f59373ae605b937c4fee607a'
HEAD = '305d2d10fafeb4a7c8e566cdd0a3f67cccd97ec1'
OUT = ROOT / 'pages-standards-evidence'
OUT.mkdir(exist_ok=True)

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], text=True).strip()

def blob(ref, path):
    return subprocess.check_output(['git', '-C', str(REPO), 'show', f'{ref}:{path}'])

started = datetime.now(timezone.utc).isoformat()
assert git('rev-parse', 'HEAD') == HEAD
assert not git('status', '--porcelain')
lock = blob(HEAD, 'tools/site/requirements-ci.lock').decode()
entries = {}
for line in lock.splitlines():
    if not line or line.startswith('#'):
        continue
    match = re.fullmatch(r'([a-z][a-z0-9-]*)==([0-9.]+) --hash=sha256:([0-9a-f]{64})', line)
    assert match, line
    name, version, digest = match.groups()
    assert name not in entries
    entries[name] = {'version': version, 'sha256': digest}
assert set(entries) == {'segno', 'pillow', 'pytest', 'iniconfig', 'packaging', 'pluggy', 'pygments'}

environment = default_environment()
environment.update(python_version='3.12', python_full_version='3.12.14', sys_platform='linux',
                   platform_system='Linux', platform_machine='x86_64', implementation_name='cpython',
                   platform_python_implementation='CPython', os_name='posix', extra='')
compatible = set(sys_tags())
rows, active_edges = [], []
for name, entry in entries.items():
    metadata_file = ROOT / 'codex5-evidence' / f'pypi-{name}-{entry["version"]}.json'
    upstream = json.loads(metadata_file.read_text())
    candidates = [item for item in upstream['urls'] if item['digests']['sha256'] == entry['sha256']]
    assert len(candidates) == 1, name
    candidate = candidates[0]
    assert not candidate['yanked'] and candidate['packagetype'] == 'bdist_wheel'
    wheel = ROOT / 'codex5-evidence/wheelhouse' / candidate['filename']
    data = wheel.read_bytes()
    assert hashlib.sha256(data).hexdigest() == entry['sha256']
    assert len(data) == candidate['size']
    parsed_name, parsed_version, _, wheel_tags = parse_wheel_filename(wheel.name)
    assert canonicalize_name(parsed_name) == name and str(parsed_version) == entry['version']
    assert wheel_tags & compatible, wheel.name
    with zipfile.ZipFile(wheel) as archive:
        members = [n for n in archive.namelist() if n.endswith('.dist-info/METADATA')]
        assert len(members) == 1
        metadata = email.message_from_bytes(archive.read(members[0]))
    assert canonicalize_name(metadata['Name']) == name
    assert metadata['Version'] == entry['version']
    assert '3.12.14' in SpecifierSet(metadata.get('Requires-Python', ''))
    for raw in metadata.get_all('Requires-Dist', []):
        requirement = Requirement(raw)
        if requirement.marker and not requirement.marker.evaluate(environment):
            continue
        dependency = canonicalize_name(requirement.name)
        assert dependency in entries, (name, raw)
        assert not requirement.url and not requirement.extras, (name, raw)
        assert entries[dependency]['version'] in requirement.specifier
        active_edges.append({'from': name, 'requirement': raw, 'locked': entries[dependency]['version']})
    rows.append({'name': name, **entry, 'filename': wheel.name, 'size': len(data),
                 'pypi_metadata_sha256': hashlib.sha256(metadata_file.read_bytes()).hexdigest(),
                 'verified': True})
assert len(active_edges) == 4

old = blob(BASE, '.github/workflows/pages.yml').decode()
expected = old.replace('python -m pip install --only-binary=:all: -r tools/site/requirements.txt pytest',
                      'python -m pip install --require-hashes --only-binary=:all: -r tools/site/requirements-ci.lock')
expected = expected.replace('python -m pytest -q tests/test_site_*.py',
                            'python -m pytest --noconftest --disable-plugin-autoload -q tests/test_site_*.py')
assert expected.encode() == blob(HEAD, '.github/workflows/pages.yml')
unchanged = ['src', 'tests/conftest.py', 'pyproject.toml', 'tests/test_site_screens.py',
             'tests/test_codex_pkg_workflows.py', 'tools/site/requirements.txt']
assert not git('diff', '--name-only', BASE, HEAD, '--', *unchanged)

def cases(path):
    result = {}
    for case in ET.parse(path).getroot().iter('testcase'):
        identity = f'{case.attrib["classname"]}::{case.attrib["name"]}'
        assert identity not in result
        status = 'failed' if case.find('failure') is not None else 'error' if case.find('error') is not None else 'skipped' if case.find('skipped') is not None else 'passed'
        result[identity] = status
    return result

before = cases(ROOT / 'codex5-evidence/site-only-isolated-conftest-control.xml')
after = cases(ROOT / 'pages-evidence/pages-site-tests.xml')
assert len(before) == 244 and len(after) == 248
assert set(before) <= set(after)
assert all(after[k] == v for k, v in before.items())
added = sorted(set(after) - set(before))
assert len(added) == 4 and all('test_site_dependency_lock' in n for n in added)
assert list(after.values()).count('passed') == 247
assert [n for n, status in after.items() if status == 'skipped'] == ['tests.test_site_screens::test_renderer_draws_the_real_gui_offscreen']
receipt_names = ['pages-hashed-install', 'pages-damaged-hash-refusal', 'pages-missing-dependency-refusal',
                 'pages-site-tests', 'pages-build', 'pages-installed-scope', 'pages-pip-check', 'pages-ruff']
receipts = []
for name in receipt_names:
    record = json.loads((ROOT / 'pages-evidence' / f'{name}.json').read_text())
    assert record['head'] == record['head_after'] == HEAD
    assert record['tree'] == '9bb0dd33372693c0ccf3836d39c97d7c6afca94f'
    assert not record['dirty_before'] and not record['dirty_after']
    assert record['returncode'] == (1 if 'refusal' in name else 0)
    receipts.append({'name': name, 'returncode': record['returncode'], 'exact_clean_source': True})
assert not git('status', '--porcelain')
result = {'started_at': started, 'finished_at': datetime.now(timezone.utc).isoformat(),
          'reviewer': 'cycle4_pages_standards', 'python': sys.executable, 'base': BASE, 'head': HEAD,
          'tree': git('rev-parse', f'{HEAD}^{{tree}}'), 'dirty_after': '', 'rows': rows,
          'active_dependency_edges': active_edges, 'workflow_only_two_commands_changed': True,
          'protected_paths_unchanged': unchanged, 'original_site_cases_preserved': len(before),
          'new_site_test_identities': added, 'author_receipts_verified': receipts,
          'scope': 'Read-only artifact/metadata, source and recorded-evidence verification; no package code or pytest suite executed.'}
(OUT / 'controls-result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'passed': True, 'wheels': len(rows), 'dependency_edges': len(active_edges),
                  'original_site_cases_preserved': len(before), 'added_cases': len(added), 'head': HEAD}, indent=2))
