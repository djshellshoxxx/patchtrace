"""Independent, bounded copy/row semantic controls for the Build environment header review."""
from __future__ import annotations

import ast
import json
import subprocess
from pathlib import Path
from types import SimpleNamespace

import patchtrace
from patchtrace.buildenv.contracts import BuildChange
from patchtrace.buildenv.panel_model import COLUMNS
from patchtrace.buildenv.tooltip_entries import TIPS
from patchtrace.buildenv.view_model import fact_rows

BASE = '11f51c105bf63946f59373ae605b937c4fee607a'
HEAD = 'b65fba2f5567f0b129331364bbf6db1cd699c901'
ROOT = Path('/workspace/scratch/patchtrace-95fe-c4/buildenv-spec')
assert Path(patchtrace.__file__).resolve().is_relative_to(ROOT)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip() == HEAD

cases = (
    ('changed', 'old packer', 'new packer', 'changed'),
    ('added', None, 'new packer', 'added'),
    ('removed', 'old packer', None, 'removed'),
    ('unchanged', 'same packer', 'same packer', 'same'),
    ('one-sided-unknown', 'old packer', None, 'unknown (one side)'),
)
changes = tuple(BuildChange(key='packer', older=older, newer=newer, change=change,
                            kind='descriptive', strength='weak', basis=('diec', 'pe-header'))
                for change, older, newer, _ in cases)
rows = fact_rows(SimpleNamespace(changes=changes), '3.21')
status_copy = TIPS['build_env.col.status'].why.lower()
for row, (change, older, newer, label) in zip(rows, cases, strict=True):
    assert row.status == label
    assert label in status_copy
    assert row.older == (older or '-')
    assert row.newer == (newer or '-')
    assert row.basis == 'Detect It Easy 3.21, signature, PE header field'
assert 'unknown is not a difference' in status_copy
assert [column.title for column in COLUMNS] == ['Fact', 'OLDER', 'NEWER', 'Status', 'Basis']
assert all(column.tip_id == 'build_env.col.' + column.key for column in COLUMNS)
assert all(column.tip_id in TIPS for column in COLUMNS)

def source_ast(ref, path):
    return ast.parse(subprocess.check_output(['git', 'show', f'{ref}:{path}'], cwd=ROOT, text=True))

path = 'src/patchtrace/buildenv/panel_model.py'
before, after = source_ast(BASE, path), source_ast(HEAD, path)
removed = 0
for node in ast.walk(after):
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id == 'ColumnSpec':
        removed += sum(keyword.arg == 'tip_id' for keyword in node.keywords)
        node.keywords = [keyword for keyword in node.keywords if keyword.arg != 'tip_id']
assert removed == 5
assert ast.dump(before, include_attributes=False) == ast.dump(after, include_attributes=False)

path = 'src/patchtrace/buildenv/tooltip_entries.py'
before, after = source_ast(BASE, path), source_ast(HEAD, path)
removed_tips = []
for node in after.body:
    if isinstance(node, ast.Assign) and any(isinstance(target, ast.Name) and target.id == 'TIPS'
                                          for target in node.targets):
        values = [(key, value) for key, value in zip(node.value.keys, node.value.values, strict=True)
                  if not (isinstance(key, ast.Constant) and str(key.value).startswith('build_env.col.'))]
        removed_tips = [key.value for key in node.value.keys
                        if isinstance(key, ast.Constant) and str(key.value).startswith('build_env.col.')]
        node.value.keys = [key for key, _ in values]
        node.value.values = [value for _, value in values]
assert set(removed_tips) == {column.tip_id for column in COLUMNS}
assert ast.dump(before, include_attributes=False) == ast.dump(after, include_attributes=False)

print(json.dumps({'source': str(patchtrace.__file__), 'head': HEAD,
                  'semantic_status_cases_passed': len(cases),
                  'production_ast_controls_passed': 2,
                  'scope': 'Synthetic row-copy and exact AST controls only; no target/native execution'}, indent=2))
