"""Independent, in-memory binding removal; no production file is changed."""
import dataclasses
import json
from pathlib import Path

import pytest
from patchtrace.buildenv import panel_model, qt_panel

expected = Path('/workspace/scratch/patchtrace-95fe-c4/buildenv-standards').resolve()
assert Path(panel_model.__file__).resolve().is_relative_to(expected)
assert panel_model.COLUMNS[-1].tip_id == 'build_env.col.basis'
mutated = tuple(dataclasses.replace(c, tip_id='') if c.key == 'basis' else c
                for c in panel_model.COLUMNS)
assert len(mutated) == 5
assert sum(a != b for a, b in zip(panel_model.COLUMNS, mutated)) == 1
panel_model.COLUMNS = mutated
qt_panel.COLUMNS = mutated
print(json.dumps({'source': panel_model.__file__, 'mutation': 'basis tip_id empty in memory only'}))
raise SystemExit(pytest.main([
    '-q', 'tests/test_tooltips.py::test_every_registry_id_is_applied_somewhere',
    '--junitxml=/workspace/scratch/patchtrace-95fe-c4/buildenv-standards-evidence/missing-basis-global.xml',
]))
