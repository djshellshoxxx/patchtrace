# Pages isolated, hashed build lane — author handoff

## Frozen source

Base: `11f51c105bf63946f59373ae605b937c4fee607a`.
Final source: `305d2d10fafeb4a7c8e566cdd0a3f67cccd97ec1`.
Final tree: `9bb0dd33372693c0ccf3836d39c97d7c6afca94f`.
Worktree: `/workspace/scratch/patchtrace-95fe-c4/pages`.
Branch: `codex/patchtrace-pages-hashed-tools-20261121-95fe`.

Ordered commits:

- `cde114219932f3c93ace1bab516b554b264a7e93` — docs(pages): specify isolated tests and hashed Linux build dependencies
- `f4ed82d8292bf4b1c06244ebc0befa936ba242b7` — test(pages): require a complete hashed isolated site environment
- `305d2d10fafeb4a7c8e566cdd0a3f67cccd97ec1` — fix(pages): isolate site tests and verify every CI dependency wheel

## Changed behavior

The Pages job installs a seven-distribution complete lock for Linux x86-64,
CPython 3.12 with SHA-256 checking and binary-only distributions. Pillow12.3.0
and Segno1.6.6 retain their existing portable build pins; pytest9.2.0 and its
four current Linux runtime dependencies are now explicit. Normal dependency
resolution is retained. Only the install and pytest run commands differ in the
workflow; Action references, triggers, permissions, artifact and deployment
blocks are byte-preserved.

The complete site-test selection uses `--noconftest --disable-plugin-autoload`
to preserve its existing site-only dependency contract. No shared fixture,
application source, pyproject setting, assertion, or skip marker changed.

## Actual evidence

- Independent research baseline: unchanged-source site-only invocation errors
  before the test body because the shared KEV fixture imports absent pydantic.
  Retained separately in `codex5-evidence/site-only-baseline.*`.
- Four new source-contract cases failed before production edits on clean
  `f4ed82d8`; baseline receipts are retained here.
- Fresh Python3.12 environment initially contained only pip25.0.1. Hashed,
  binary-only installation from the independently verified local PyPI
  wheelhouse succeeded. The installed scope is exactly pip plus the seven
  locked distributions; isolated Python confirms no pydantic, PySide6 or
  PatchTrace installation.
- Full site selection on final source: **247 passed, 1 skipped**. The sole
  unchanged skip is `tests.test_site_screens::test_renderer_draws_the_real_gui_offscreen`
  because PySide6 is intentionally absent.
- Real site build passed its built-in quality gate. Existing warnings report
  no owner-provided logo and an empty donation address. Five existing screenshots
  were copied; no GUI screenshot regeneration is claimed.
- A damaged Pillow SHA-256 fails with the intended hash mismatch. Omitting
  pluggy fails because its transitive requirement is not pinned in hash mode.
  Each control used its own fresh environment and left only pip installed.
- Whole-tree Ruff, pip check, full-range whitespace, and the exact-two-command
  workflow delta verification passed. Final worktree is clean.

Commands, logs, clean-state/source receipts and JUnit are in this directory.
The valid/refusal pip executions use `--no-index --find-links` against the
verified wheelhouse: they prove actual local pip integrity/closure behavior,
not live hosted package-index resolution. Metadata, URLs, downloaded-byte hash
checks and wheel METADATA closure are in the separate research evidence bundle.
No package binaries are included in these evidence ZIPs.

## Review and integration boundaries

Independent review and combined-candidate qualification remain with the
coordinator. Other repository pip-install lanes and the global CODEX-5 strict
xfail remain open. Native GUI, screen-reader, actual hosted Pages execution,
and deployment acceptance are separate. No workflow was dispatched and no
remote ref, PR349, main, release or deployment was changed.

Root837FE owns the Action-reference upgrade. The changed source assertions in
`test_site_workflow.py` concern only the install/test command expectations;
retain that owner's separate Action-ref assertions when combining changes.

Primary documentation read:

- https://pip.pypa.io/en/stable/topics/secure-installs/
- https://docs.pytest.org/en/stable/reference/reference.html#command-line-flags

