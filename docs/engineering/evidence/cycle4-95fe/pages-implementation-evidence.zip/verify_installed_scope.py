import importlib.metadata
import importlib.util
import json
import sys

names = {d.metadata["Name"].lower(): d.version for d in importlib.metadata.distributions()}
assert set(names) == {"pip", "segno", "pillow", "pytest", "iniconfig", "packaging", "pluggy", "pygments"}, names
assert all(importlib.util.find_spec(name) is None for name in ("pydantic", "PySide6", "patchtrace"))
print(json.dumps({"executable": sys.executable, "distributions": names, "application_dependencies_absent": True}, indent=2))
