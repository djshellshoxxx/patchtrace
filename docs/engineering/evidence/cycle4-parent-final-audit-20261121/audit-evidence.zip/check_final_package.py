#!/usr/bin/env python3
"""Bounded read-only audit of frozen C4 parent-integration record package."""
import collections
import datetime
import difflib
import hashlib
import io
import json
from pathlib import Path
import posixpath
import re
import subprocess
import tempfile
import urllib.parse
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/patchtrace-95fe-c4')
REPO = ROOT/'coordinator'
OUT = Path(__file__).resolve().parent
OLD = '111803d54cfebc1b779f4832a069904b3ee91a7c'
NEW = '39a95c549d48eb523e9efdfda394bb9f184e2b16'
PARENT = 'daee337c48c63dda8aeac149c407e900c79dcc86'
TREE = 'd3264bf26f83d039fa212c26b47c094f86691c3f'
PREFIX = 'docs/engineering/evidence/cycle4-parent-20261121/'
FAILURES = []

def check(ok, label):
    if not ok:
        FAILURES.append(label)
    return bool(ok)

def git(*args):
    return subprocess.check_output(['git',*args],cwd=REPO)

def blob(ref,path):
    return git('show',ref+':'+path)

def digest(data):
    return dict(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())

def obj(name):
    return json.loads(blob(NEW,PREFIX+name))

def tree(ref,path='.'):
    out={}
    for entry in git('ls-tree','-r','-z',ref,'--',path).split(b'\0'):
        if entry:
            meta,p=entry.split(b'\t',1);out[p.decode()]=meta.decode()
    return out

def clean(receipt, ref=OLD, tree_id=TREE):
    return receipt.get('head')==receipt.get('head_after')==ref and receipt.get('tree')==tree_id and receipt.get('dirty_before')==receipt.get('dirty_after')==''

meta=git('show','-s','--format=%H %T %P',NEW).decode().split()
check(meta==[NEW,'f53e92d6bc128c929295f6baf3c6241081ee6ed2',OLD],'frozen commit, tree and parent')
changed=git('diff','--name-only',OLD,NEW).decode().splitlines()
check(all(p.startswith('docs/') or p=='tasks/todo.md' for p in changed),'only documentation/evidence changed')
newtree=tree(NEW)
directory=obj('manifest.json')
directory_rows=[]
for f in directory['files']:
    raw=blob(NEW,PREFIX+f['path']);good=digest(raw)=={k:f[k] for k in ['bytes','sha256']}
    directory_rows.append(dict(path=f['path'],**digest(raw),valid=check(good,'directory digest '+f['path'])))
check(len(directory_rows)==12 and {r['path'] for r in directory_rows}=={p[len(PREFIX):] for p in newtree if p.startswith(PREFIX)}-{'manifest.json'},'12 exact directory payloads')

archive_raw=blob(NEW,PREFIX+'qualification-and-review-evidence.zip')
z=zipfile.ZipFile(io.BytesIO(archive_raw));names=z.namelist();manifest=json.loads(z.read('manifest.json'))
check(len(names)==len(set(names))==55,'55 unique ZIP entries')
check(manifest['payload_count']==54 and len(manifest['files'])==54 and {f['path'] for f in manifest['files']}==set(names)-{'manifest.json'},'54 exact archive payloads')
check(manifest['source_commit']==OLD and manifest['source_tree']==TREE,'archive source binding')
source_dirs={'root':ROOT/'parent-upgrade-evidence','merge-review':ROOT/'parent-merge-review-evidence','record-review':ROOT/'parent-merge-record-evidence'}
archive_rows=[]
for f in manifest['files']:
    raw=z.read(f['path']);category,rel=f['path'].split('/',1);original=source_dirs[category]/rel
    valid=check(digest(raw)=={k:f[k] for k in ['bytes','sha256']},'archive digest '+f['path'])
    original_ok=check(original.is_file() and original.read_bytes()==raw,'archive original bytes '+f['path'])
    archive_rows.append(dict(path=f['path'],original=str(original),**digest(raw),digest_valid=valid,original_bytes_equal=original_ok))

qualification=obj('qualification.json')
check(qualification['archive']==dict(path='qualification-and-review-evidence.zip',**digest(archive_raw),payload_count=54),'qualification archive size/hash/count')
for local,archived in [('code-publication-mapping.json','root/code-publication-mapping.json'),('combined-identity-summary.json','root/combined-identity-summary.json'),('merge-resolution.json','root/merge-resolution.json'),('ruff-scope-disposition.json','root/ruff-scope-disposition.json'),('parent-upgrade-bundle.json','root/parent-upgrade-bundle.json'),('source-history-verification.log','root/parent-upgrade-bundle-verification.log'),('merge-review.md','merge-review/review.md'),('record-review.md','record-review/parent-merge-record-audit.md')]:
    check(blob(NEW,PREFIX+local)==z.read(archived),'standalone/archived equality '+local)

def junit(name):
    cases=[]
    for t in ET.fromstring(z.read(name)).iter('testcase'):
        state='passed';detail=None
        for tag in ['failure','error','skipped']:
            child=t.find(tag)
            if child is not None:
                state='xfailed' if tag=='skipped' and child.get('type')=='pytest.xfail' else tag
                detail=dict(type=child.get('type'),message=child.get('message'));break
        cases.append(dict(id=t.get('classname','')+'::'+t.get('name',''),status=state,detail=detail))
    return cases

cases=junit('root/combined-after.xml');ids=[c['id'] for c in cases];outcomes=dict(collections.Counter(c['status'] for c in cases))
summary=obj('combined-identity-summary.json')
check(len(ids)==len(set(ids))==581 and outcomes=={'passed':580,'xfailed':1},'581 distinct cases, 580 pass and one xfail')
check(summary['identities']==ids and summary['outcomes']==outcomes and summary['source']==OLD and summary['tree']==TREE,'identity summary matches JUnit and source')
xfails=[c for c in cases if c['status']=='xfailed'];registry=[c for c in cases if c['id'].startswith('tests.test_spec_registry::')]
check(xfails==[dict(id='tests.test_codex_pkg_workflows::test_pip_downloads_require_hashes',status='xfailed',detail={'type':'pytest.xfail','message':'CODEX-5'})],'exact CODEX-5 expected failure')
check(len(registry)==summary['registry_cases']==110 and all(c['status']=='passed' for c in registry),'110 included passing registry cases')
check(next(c['status'] for c in cases if c['id']=='tests.test_codex_pkg_workflows::test_remote_actions_are_immutable')=='passed','CODEX-1 now passes')
required={}
for name in ['combined-after','combined-maintained-ruff','combined-dependencies','combined-source-binding']:
    receipt=json.loads(z.read('root/'+name+'.json'))
    check(clean(receipt) and receipt['returncode']==0,name+': passed clean tested-source receipt')
    required[name]=receipt
check(sum(a.startswith('tests/') for a in required['combined-after']['command'])==21,'21 combined selectors')
check(required['combined-maintained-ruff']['command'][1:]==['-m','ruff','check','src','tests','tools'],'required maintained Ruff scope')
check(required['combined-dependencies']['command'][1:]==['-m','pip','check'],'pip check command')
check(required['combined-source-binding']['command'][1:3]==['-I','-c'] and b'coordinator/src/patchtrace/__init__.py' in z.read('root/combined-source-binding.log'),'isolated source binding')
q=qualification['qualification']
check(q==dict(passed=580,expected_failures=1,expected_failure_ids=['CODEX-5'],ordinary_skips=0,failures=0,errors=0,unique_identities=581,selectors=21,included_registry_identities=110,receipt='qualification-and-review-evidence.zip::root/combined-after.json'),'qualification counts and source receipt')
check(qualification['tested_local_source']==OLD and qualification['tested_tree']==TREE and qualification['main_merge_eligible'] is False and qualification['release_ready'] is False,'qualification source and release holds')

before=json.loads(z.read('root/registry-before.json'));clean_before=json.loads(z.read('root/registry-before-clean.json'))
before_cases=junit('root/registry-before.xml');clean_cases=junit('root/registry-before-clean.xml')
check(before['head']=='a76189cc0e7ec4312baf3662da5946d39bdd019c' and before['dirty_before'] and before['dirty_after'] and before['returncode']==1,'initial registry receipt retained as dirty')
check(clean(clean_before,'e7391634a46bbb1f9f1fdc3563abadb837d1b45b','419af4313bc711437886c4d2bd6c72c8062bf679') and clean_before['returncode']==1,'clean failing merge receipt')
check([(c['id'],c['status']) for c in before_cases]==[(c['id'],c['status']) for c in clean_cases],'dirty and clean baseline identities/outcomes agree')
check(collections.Counter(c['status'] for c in clean_cases)=={'passed':108,'failure':2},'retained 108 pass / 2 fail baseline')

ruff=json.loads(z.read('root/combined-ruff.json'));rufflog=z.read('root/combined-ruff.log').decode();disposition=obj('ruff-scope-disposition.json')
diagnostic_paths=re.findall(r'(?m)^\s*-->\s+([^:\n]+):\d+:\d+',rufflog)
check(clean(ruff) and ruff['returncode']==1 and ruff['command'][1:]==['-m','ruff','check','.'],'broad lint failure retained')
check(len(diagnostic_paths)==disposition['diagnostic_count']==1063 and len(set(diagnostic_paths))==disposition['unique_files']==138,'1063 diagnostics in 138 files')
check(dict(collections.Counter(p.split('/')[0] for p in diagnostic_paths))==disposition['path_prefix_counts']=={'docs':1052,'help':11},'all diagnostics in docs/help')
check({f['path'] for f in disposition['files']}==set(diagnostic_paths),'disposition lists actual affected files')
ruff_files=[]
for path in sorted(set(diagnostic_paths)):
    raw=blob(OLD,path);equal=raw==blob(PARENT,path)==blob(NEW,path)
    ruff_files.append(dict(path=path,unchanged=check(equal,'unchanged lint diagnostic file '+path),**digest(raw)))
for p in ['AGENTS.md','.github/workflows/qa-windows.yml']:
    check(b'python -m ruff check src tests tools' in blob(OLD,p),'required Ruff scope documented in '+p)

old_evidence=tree(OLD,'docs/engineering/evidence');retained=[]
check(len(old_evidence)==372,'372 original sealed files')
for p,entry in sorted(old_evidence.items()):
    raw=blob(OLD,p);same=entry==newtree.get(p) and raw==blob(NEW,p)
    retained.append(dict(path=p,git_entry=entry,unchanged=check(same,'sealed evidence '+p),**digest(raw)))
check(set(tree(NEW,'docs/engineering/evidence'))-set(old_evidence)=={PREFIX+f['path'] for f in directory['files']}|{PREFIX+'manifest.json'},'only new package added to sealed evidence')

metadata_records=[]
for path,key in [('docs/engineering/task-ledger.json','parallel_followup_cycle4'),('docs/engineering/feature-status-20261119.json','cycle4_parallel_followup')]:
    a,b=(json.loads(blob(ref,path)) for ref in [OLD,NEW]);current=b[key]
    unchanged={k:a[k]==b.get(k) for k in a if k not in {'updated_at',key}}
    check(all(unchanged.values()) and set(a)==set(b),path+': all unrelated metadata unchanged')
    check(current['initial_source_history']==a[key],path+': full initial C4 object retained')
    check(current['qualification']==q and current['tested_source']==OLD and current['tested_tree']==TREE and current['base']==PARENT,path+': current qualification consistent')
    check(current['ownership']==a[key]['ownership'] and current['status']=='parent-integrated-reviewed-local-qualified-hosted-pending',path+': ownership and pending hosted status')
    if path.endswith('task-ledger.json'):
        check(len(b['tasks'])==93 and b['tasks']==a['tasks'], 'all 93 task objects unchanged')
    metadata_records.append(dict(path=path,unchanged_fields=unchanged,initial_source_history_exact=current['initial_source_history']==a[key],qualification_equal=current['qualification']==q,old_digest=digest(blob(OLD,path)),new_digest=digest(blob(NEW,path))))

histories=[];links=[]
for p in changed:
    if not p.endswith('.md'):
        continue
    exists=p in tree(OLD,p)
    old=blob(OLD,p).decode().splitlines(True) if exists else []
    new=blob(NEW,p).decode().splitlines(True)
    operations=[x for x in difflib.SequenceMatcher(None,old,new,autojunk=False).get_opcodes() if x[0]!='equal']
    check(all(op=='insert' for op,*_ in operations),p+': additions only')
    if exists:
        histories.append(dict(path=p,old_lines=len(old),new_lines=len(new),operations=operations))
    for op,a,b,c,d in operations:
        added=''.join(new[c:d])
        for target in re.findall(r'\]\(([^)]+)\)',added):
            target=target.split(' "',1)[0].strip('<>');u=urllib.parse.urlsplit(target)
            if u.scheme or u.netloc:
                continue
            resolved=posixpath.normpath(posixpath.join(posixpath.dirname(p),urllib.parse.unquote(u.path))) if u.path else p
            valid=resolved in newtree or any(x.startswith(resolved.rstrip('/')+'/') for x in newtree)
            links.append(dict(file=p,target=target,resolved=resolved,valid=check(valid,'new Markdown link '+p+' -> '+target),fragment=u.fragment))
check(len(histories)==12,'12 existing Markdown histories preserved by insertion only')
check(all(not l['fragment'] for l in links),'new links have no unresolved anchor checks')

header_controls=json.loads(z.read('merge-review/header-controls.json'));audit_id='tests.test_tooltips::test_every_registry_id_is_applied_somewhere'
check(any(c['id']==audit_id and c['status']=='passed' for c in cases),'positive header audit overlaps combined passes')
for stem,expected_status,expected_id in [('header-positive','passed',None),('header-missing-buildenv-basis','failure','build_env.col.basis'),('header-missing-search-why','failure','search.col.why')]:
    receipt=json.loads(z.read('merge-review/'+stem+'.json'));items=junit('merge-review/'+stem+'.xml')
    check(clean(receipt) and len(items)==1 and items[0]['id']==audit_id and items[0]['status']==expected_status,stem+': retained clean actual audit result')
    if expected_id:
        check(items[0]['detail']['message']=="AssertionError: ['"+expected_id+"']\nassert not {'"+expected_id+"'}",stem+': exact missing ID')
source_review=json.loads(z.read('merge-review/source-controls.json'));pages_review=json.loads(z.read('merge-review/pages-helper/pages-merge-review.json'))
check(source_review['source']==OLD and source_review['source_tree']==TREE and source_review['parent_production_files']==672 and len(source_review['production_changed_paths'])==2,'retained source review backs 670 unchanged production files')
check(source_review['registered_header_counts']=={'strings':8,'search':6,'build_env':5},'retained review backs 8/6/5 headers')
check(len(pages_review['action_references'])==5 and all(pages_review['checks'].values()),'retained Pages review backs five pins and two command substitutions')

mapping=obj('code-publication-mapping.json')['commits'];lookup={m['local_commit']:m['remote_commit'] for m in mapping}
check(len(mapping)==13,'13 recorded mappings')
for item in mapping:
    values=git('show','-s','--format=%T %P',item['local_commit']).decode().split()
    check(item['tree']==values[0] and item['local_parents']==values[1:],'mapping local objects '+item['local_commit'])
    check(item['remote_parents']==[lookup.get(p,p) for p in item['local_parents']],'mapping ordered parent correspondence '+item['local_commit'])
check(lookup[OLD]==qualification['tree_identical_remote_code_checkpoint']=='7ddb1130ca501b9cfda9949aa49e684f9f4b8f26','qualified code mapping')
bundle=blob(NEW,PREFIX+'original-source-history.bundle');bundle_info=obj('parent-upgrade-bundle.json')
header=bundle.split(b'\n\n',1)[0].decode();prerequisites=[l[1:].split()[0] for l in header.splitlines() if l.startswith('-')]
check(set(prerequisites)==set(bundle_info['prerequisites'])=={'36584f8153983d64605dd7f4141e88c9fabfa6ef',PARENT},'bundle prerequisites')
expected_commits=git('rev-list','--reverse','--topo-order',OLD,'^36584f8153983d64605dd7f4141e88c9fabfa6ef','^'+PARENT).decode().splitlines()
check(bundle_info['original_commits']==expected_commits and len(expected_commits)==3,'three original local commits')
check(qualification['original_source_history']['sha256']==digest(bundle)['sha256'] and qualification['original_source_history']['bytes']==len(bundle),'bundle qualification digest')
with tempfile.NamedTemporaryFile(dir=OUT,suffix='.bundle') as tmp:
    tmp.write(bundle);tmp.flush()
    verify=subprocess.run(['git','bundle','verify',tmp.name],cwd=REPO,capture_output=True)
(OUT/'bundle-verification.log').write_bytes(verify.stdout+verify.stderr)
check(verify.returncode==0,'independent read-only bundle verification')

result=dict(status='FAIL' if FAILURES else 'PASS',failures=FAILURES,recorded_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),frozen_commit=NEW,frozen_tree=meta[1],tested_source=OLD,tested_tree=TREE,scope='Frozen-object record audit and inspection of existing archived receipts; no tests, project imports, checkout changes, or remote calls.',changed_paths=changed,directory_manifest=directory_rows,archive=dict(**digest(archive_raw),payload_count=54,files=archive_rows),qualification=dict(cases=cases,outcomes=outcomes,unique_identities=len(set(ids)),registry_cases=len(registry),required_receipts=required),retained_nonacceptance=dict(initial_registry_dirty=True,initial_registry_receipt_digest=digest(z.read('root/registry-before.json')),clean_registry_outcomes=dict(collections.Counter(c['status'] for c in clean_cases)),ruff=dict(diagnostic_count=len(diagnostic_paths),unique_files=len(set(diagnostic_paths)),files=ruff_files,receipt=ruff)),original_evidence=retained,metadata=metadata_records,markdown_histories=histories,new_relative_links=links,independent_review_support=dict(header_controls=header_controls,source=source_review,pages=pages_review),source_history=dict(bundle_digest=digest(bundle),header=header,original_commits=expected_commits,verification_returncode=verify.returncode,local_mapping_rows_checked=len(mapping),remote_objects_freshly_queried=False))
(OUT/'controls.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(dict(status=result['status'],failures=FAILURES,directory_payloads=len(directory_rows),archive_payloads=len(archive_rows),original_evidence=len(retained),histories=len(histories),new_relative_links=len(links),outcomes=outcomes,registry_cases=len(registry)),indent=2))
raise SystemExit(bool(FAILURES))
