"""Run disjoint affected selections; never replace the unsplit full-suite gate."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path('/workspace/scratch/2bade0b323c3/PatchTrace')
OUT = Path('/tmp/patchtrace-2bad-bounded-evidence')
PYTHON = '/workspace/scratch/2bade0b323c3/qualification-venv/bin/python'
selection = json.loads((OUT / 'selection.json').read_text())


def source():
    def git(*args):
        return subprocess.check_output(['git', '-C', str(ROOT), *args], text=True).strip()
    return {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
            'status': git('status', '--porcelain')}


original = source()
receipts = []
all_cases = []
for number, files in enumerate(selection['batches'], 1):
    destination = OUT / f'batch-{number}'
    destination.mkdir(exist_ok=True)
    command = [PYTHON, '-m', 'pytest', '-q', '-p', 'no:cacheprovider', *files,
               '--basetemp=' + f'/tmp/patchtrace-2bad-bounded-temp-{number}',
               '--junitxml=' + str(destination / 'results.xml')]
    env = dict(os.environ, QT_QPA_PLATFORM='offscreen', PYTHONDONTWRITEBYTECODE='1',
               PYTHONPATH=str(ROOT / 'src'), PYTHONUNBUFFERED='1')
    receipt = {'number': number, 'command': command, 'source_before': source(),
               'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    started = time.monotonic()
    with (destination / 'stdout.log').open('wb') as stream:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
    receipt.update(returncode=result.returncode, elapsed_seconds=time.monotonic() - started,
                   source_after=source(), child_high_water_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
    receipt['source_unchanged'] = receipt['source_before'] == receipt['source_after'] == original
    receipt['stdout_sha256'] = hashlib.sha256((destination / 'stdout.log').read_bytes()).hexdigest()
    junit = destination / 'results.xml'
    if junit.exists():
        cases = list(ET.parse(junit).getroot().iter('testcase'))
        identities = [(c.get('classname'), c.get('name')) for c in cases]
        all_cases.extend(identities)
        receipt['testcases'] = len(cases)
        receipt['failures'] = sum(c.find('failure') is not None for c in cases)
        receipt['errors'] = sum(c.find('error') is not None for c in cases)
        receipt['skipped'] = sum(c.find('skipped') is not None for c in cases)
        receipt['passed'] = len(cases) - receipt['failures'] - receipt['errors'] - receipt['skipped']
    (destination / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    receipts.append(receipt)
    print(json.dumps(receipt), flush=True)
    print((destination / 'stdout.log').read_text(errors='replace')[-2000:], flush=True)
summary = {'source': original, 'source_unchanged': source() == original,
           'batches': receipts, 'unique_cases': len(set(all_cases)),
           'duplicate_cases': len(all_cases) - len(set(all_cases)),
           'passed': sum(r.get('passed', 0) for r in receipts),
           'skipped': sum(r.get('skipped', 0) for r in receipts),
           'all_batches_successful': all(r['returncode'] == 0 for r in receipts),
           'full_suite_accepted': False}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary), flush=True)
raise SystemExit(0 if summary['all_batches_successful'] else 1)
