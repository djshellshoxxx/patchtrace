import collections, concurrent.futures, datetime, json, pathlib, subprocess
repo = pathlib.Path("/workspace/scratch/b1d1356aa953/PatchTrace")
output = pathlib.Path("/workspace/scratch/b1d1356aa953/patchtrace-git-inventory.json")
candidate = "origin/codex/patchtrace-qa-ruff-imports-20261120-g29"
def git(*args, check=True):
    r = subprocess.run(["git", *args], cwd=repo, text=True, capture_output=True, check=check)
    return r.stdout.strip()
main = git("rev-parse", "origin/main")
candidate_sha = git("rev-parse", candidate)
old = json.loads(git("show", candidate + ":docs/engineering/consolidation-inventory.json"))
old_rows = {row["branch"]: row for row in old["branches"]}
remote = json.loads(pathlib.Path("/workspace/scratch/b1d1356aa953/patchtrace-remote-inventory.json").read_text())
prs = json.loads(pathlib.Path("/workspace/scratch/b1d1356aa953/patchtrace-all-prs.json").read_text())
prs_by_branch = collections.defaultdict(list)
for p in prs:
    prs_by_branch[p["head"]].append(p)
runs_by_sha = collections.defaultdict(list)
for run in remote["latest_workflow_runs"]:
    runs_by_sha[run["head_sha"]].append(run)
raw_refs = git("for-each-ref", "--format=%(refname:short)\t%(objectname)\t%(subject)", "refs/remotes/origin").splitlines()
refs = [line.split("\t", 2) for line in raw_refs if not line.startswith("origin/HEAD\t") and not line.startswith("origin\t")]
def ancestor(a, b):
    return subprocess.run(["git", "merge-base", "--is-ancestor", a, b], cwd=repo, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
def branch_row(item):
    ref, sha, subject = item
    name = ref.removeprefix("origin/")
    prev = old_rows.get(name)
    reuse = bool(prev and prev["head"] == sha and old["main"] == main)
    merge_base = git("merge-base", "origin/main", ref)
    behind, ahead = map(int, git("rev-list", "--left-right", "--count", "origin/main..." + ref).split())
    candidate_contains = ancestor(ref, candidate)
    main_contains = ancestor(ref, "origin/main")
    if reuse:
        compare = prev["comparison"]
        changed_files = [old["file_catalog"][i] for i in prev.get("source_delta_file_ids", [])]
    else:
        cherries = git("cherry", "origin/main", ref).splitlines()
        compare = {
            "baseline": main,
            "ancestor": main_contains,
            "unmatched_nonmerge_commits": [line[2:] for line in cherries if line.startswith("+ ")],
            "equivalent_nonmerge_commits": [line[2:] for line in cherries if line.startswith("- ")],
            "merge_commits": git("rev-list", "--merges", "origin/main.." + ref).splitlines()
        }
        changed_files = git("diff", "--name-only", merge_base, ref).splitlines()
    if name == "main":
        state = "BASELINE"
    elif sha == candidate_sha:
        state = "CURRENT CANDIDATE"
    elif candidate_contains:
        state = "CONTAINED BY ANCESTRY"
    elif name == "codex/asm-lexer-performance-20261119":
        state = "EQUIVALENT — SKIP"
    elif compare.get("unmatched_nonmerge_commits"):
        state = "UNKNOWN — INVESTIGATE"
    else:
        state = "PATCH EQUIVALENT — SEMANTICS UNREVIEWED"
    row = {
        "branch": name, "head": sha, "subject": subject,
        "merge_base_main": merge_base, "ahead_main": ahead, "behind_main": behind,
        "in_main_by_ancestry": main_contains,
        "in_candidate_by_ancestry": candidate_contains,
        "git_comparison": compare, "changed_files_from_merge_base": changed_files,
        "test_files_changed": [p for p in changed_files if p.startswith("tests/")],
        "pull_requests": prs_by_branch[name],
        "recent_workflow_observations": runs_by_sha[sha],
        "prior_disposition": prev.get("disposition") if prev else None,
        "classification": state,
        "semantic_review": "No full semantic or behavioral review is claimed by this census.",
        "security_impact": "Not newly reviewed", "performance_impact": "Not newly reviewed",
        "git_evidence_provenance": "Exact main/head Git comparison reused from " + candidate_sha + ":docs/engineering/consolidation-inventory.json; ancestry and divergence refreshed." if reuse else "Fresh local merge-base, rev-list, cherry and diff.",
        "delete_authorized": False
    }
    if name == "codex/asm-lexer-performance-20261119":
        paths = ["tests/test_codetext_tokens.py", "docs/consolidation/ASM_LEXER_PERFORMANCE_20261119.md",
                 "docs/consolidation/evidence/asm-lexer-full-suite-checkpoint-20261119.zip",
                 "docs/consolidation/evidence/asm-lexer-performance-20261119.zip"]
        identical = not git("diff", ref, candidate, "--", *paths)
        row["semantic_review"] = "All four valuable diagnostic/evidence files are byte-identical to the current candidate; docs/engineering/asm-diagnostics-recovery.md records selective extraction. Shared historical QA/todo text is not reapplied."
        row["extracted_files_byte_identical"] = identical
    return row
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    branches = list(pool.map(branch_row, refs))
pulls=[]
for p in prs:
    q=dict(p)
    available = subprocess.run(["git", "cat-file", "-e", p["head_sha"] + "^{commit}"], cwd=repo, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode == 0
    q["head_object_available"] = available
    if available:
        q["head_in_main_by_ancestry"] = ancestor(p["head_sha"], "origin/main")
        q["head_in_candidate_by_ancestry"] = ancestor(p["head_sha"], candidate)
    pulls.append(q)
tags=[]
for line in git("show-ref", "--tags", "--dereference").splitlines():
    sha, ref = line.split()
    if ref.endswith("^{}"):
        continue
    commit = git("rev-parse", ref + "^{commit}")
    tags.append({"tag": ref.removeprefix("refs/tags/"), "object": sha, "commit":commit, "in_main_by_ancestry":ancestor(commit,"origin/main"),"in_candidate_by_ancestry":ancestor(commit,candidate)})
result = {
    "schema":"patchtrace/consolidation-census/3",
    "observed_at_utc":remote["observed_at_utc"],
    "generated_at_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "repository":remote["repository"], "main":main,
    "candidate":candidate_sha, "candidate_branch":candidate.removeprefix("origin/"),
    "candidate_tree":git("rev-parse",candidate+"^{tree}"),
    "coverage":{
        "remote_branches":len(branches), "all_state_prs":len(pulls),
        "open_prs":sum(p["state"]=="open" for p in pulls),
        "closed_unmerged_prs":sum(p["state"]=="closed" and p["merged_at"] is None for p in pulls),
        "merged_prs":sum(p["merged_at"] is not None for p in pulls),
        "pr_head_objects_available":sum(p["head_object_available"] for p in pulls),
        "tags":len(tags), "releases":len(remote["releases"])
    },
    "classification_counts":dict(collections.Counter(r["classification"] for r in branches)),
    "limits":[
        "Complete remote branch/tag enumeration and four-page all-state PR enumeration were read at this snapshot.",
        "Git comparisons from the older census are reused only for byte-identical main/head identities and labeled per row.",
        "Ancestry and patch IDs do not prove feature preservation; full semantic or behavioral review of all 341 branches is not claimed.",
        "The latest 100 workflow runs do not establish full historical CI status; exact final-head checks must be refreshed.",
        "No branches were merged, deleted, rebased or mutated by this read-only inventory."
    ],
    "branches":branches, "pull_requests":pulls, "tags":tags,
    "latest_releases":remote["releases"][:10]
}
output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
print(json.dumps({"path":str(output),"coverage":result["coverage"],"classification_counts":result["classification_counts"]},indent=2))
