from __future__ import annotations

import datetime
import json
import os
import subprocess
import time
from pathlib import Path

ROOT = Path('/workspace/scratch/837fe19aae3a/review-codex1')
OUT = Path('/workspace/scratch/837fe19aae3a/evidence/codex1-independent')
PYTHON = '/workspace/scratch/837fe19aae3a/review-codex1-venv/bin/python'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def run(label, args):
    command = [PYTHON, *args]
    before = {'head': git('rev-parse', 'HEAD'), 'tree': git('rev-parse', 'HEAD^{tree}'),
              'status': git('status', '--porcelain')}
    assert before['status'] == ''
    start = time.monotonic()
    stamp = datetime.datetime.now(datetime.timezone.utc).isoformat()
    env = dict(os.environ)
    env.pop('PYTHONPATH', None)
    env['QT_QPA_PLATFORM'] = 'offscreen'
    with (OUT / f'{label}.log').open('w') as output:
        result = subprocess.run(command, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT)
    receipt = {'label': label, 'command': command, 'cwd': str(ROOT), 'before': before,
               'after': {'head': git('rev-parse', 'HEAD'), 'status': git('status', '--porcelain')},
               'started_at': stamp, 'seconds': round(time.monotonic() - start, 3), 'returncode': result.returncode}
    (OUT / f'{label}.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'label': label, 'returncode': result.returncode, 'seconds': receipt['seconds']}), flush=True)
    if result.returncode:
        print((OUT / f'{label}.log').read_text()[-12000:], flush=True)
    return result.returncode


results = []
results.append(run('source-verification', [str(OUT / 'verify_workflows.py')]))
results.append(run('independent-controls', ['-m', 'pytest', '-q', str(OUT / 'test_independent_controls.py'),
                                          '--junitxml=' + str(OUT / 'independent-controls.xml')]))
selection = ['tests/test_codex_pkg_workflows.py', 'tests/test_codex_pkg_packaging.py',
             'tests/test_backend_bundle_workflow.py', 'tests/test_unified_corpus_workflow.py',
             'tests/test_unified_live_tool.py', 'tests/test_unified_live_workflow.py',
             'tests/test_live_cache_diagnostics.py', 'tests/test_release_gate.py', 'tests/test_site_workflow.py',
             'tests/test_workflows.py', 'tests/test_corpus_cache_archive_integrity_20261121.py',
             'tests/test_corpus_archive_cache_hit_shell_20261121.py']
results.append(run('maintained-selection', ['-m', 'pytest', '-q', *selection,
                                          '--junitxml=' + str(OUT / 'maintained-selection.xml')]))
results.append(run('ruff', ['-m', 'ruff', 'check', 'src', 'tests', 'tools']))
results.append(run('dependencies', ['-m', 'pip', 'check']))
results.append(run('binding', ['-I', '-c',
    'import patchtrace; from pathlib import Path; p=Path(patchtrace.__file__).resolve(); '
    f'assert p.is_relative_to(Path({str(ROOT)!r})); print(p)']))
raise SystemExit(any(results))
