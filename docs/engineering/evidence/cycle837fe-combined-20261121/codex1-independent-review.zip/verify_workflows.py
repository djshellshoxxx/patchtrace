from __future__ import annotations

import copy
import hashlib
import json
import re
import subprocess
from pathlib import Path

import yaml

ROOT = Path('/workspace/scratch/837fe19aae3a/review-codex1')
OUT = Path('/workspace/scratch/837fe19aae3a/evidence/codex1-independent')
RESEARCH = Path('/workspace/scratch/837fe19aae3a/evidence/action-pins')
BASE = '11f51c105bf63946f59373ae605b937c4fee607a'
HEAD = 'ad0997044ddd2c957ad0de1ede8db4c7dab00317'
CODE = 'ff6c79f1a9c97877d061995cae40be38e42154f9'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True)


def unwrap(record):
    if record.get('isError'):
        raise AssertionError('Captured upstream request failed')
    current = record
    while isinstance(current, dict):
        if isinstance(current.get('content'), str):
            return current['content']
        current = current.get('structuredContent')
    raise AssertionError('Missing captured response')


def obj(record):
    return json.loads(unwrap(record))


pinmap = json.loads((RESEARCH / 'pin-map.json').read_text())
raw = json.loads((RESEARCH / 'raw-upstream-evidence.json').read_text())
mapping = {row['reference']: row for row in pinmap['pins']}
annotations = {obj(v['result'])['sha']: obj(v['result']) for v in raw['annotations'].values()}


def peel(pointer):
    chain = []
    while pointer['type'] == 'tag':
        assert pointer['sha'] not in chain
        chain.append(pointer['sha'])
        pointer = annotations[pointer['sha']]['object']
    assert pointer['type'] == 'commit'
    return pointer['sha'], chain


upstream = []
for reference in raw['refs']:
    row = mapping[reference['reference']]
    repository = row['repository']
    assert reference['tag_ref']['url'] == row['ref_api_url']
    tag = obj(reference['tag_ref']['result'])
    resolved, chain = peel(tag['object'])
    assert resolved == row['commit']
    captures = {item['value']['kind']: item['value'] for item in reference['captures']
                if item['status'] == 'fulfilled'}
    assert len(captures) == 3
    assert captures['commit']['url'] == row['commit_api_url']
    commit = obj(captures['commit']['result'])
    assert commit['sha'] == row['commit']
    assert commit['html_url'] == f'https://github.com/{repository}/commit/{resolved}'
    version_records = obj(captures['tags']['result'])
    release_checks = []
    for version in row['matching_release_tags']:
        version_record = next(r for r in version_records if r['ref'] == f'refs/tags/{version}')
        release_commit, release_chain = peel(version_record['object'])
        assert release_commit == resolved
        release_checks.append({'version': version, 'commit': release_commit, 'peeled_tags': release_chain})
    manifest = unwrap(captures['manifest']['result']).encode()
    assert captures['manifest']['url'] == row['manifest_url']
    assert manifest == (RESEARCH / row['manifest_file']).read_bytes()
    assert hashlib.sha256(manifest).hexdigest() == row['manifest_sha256']
    parsed = yaml.safe_load(manifest)
    assert parsed['runs']['using'] == row['runtime']
    upstream.append({'reference': row['reference'], 'commit': resolved, 'major_tag_peel': chain,
                     'release_checks': release_checks, 'manifest_sha256': row['manifest_sha256'],
                     'commit_signature_verified': commit['verification']['verified']})

uses = re.compile(r'^(?P<prefix>\s*(?:- )?uses:\s*)(?P<ref>\S+)(?P<comment>\s+#.*)?$')
immutable = re.compile(r'[^@]+@[0-9a-fA-F]{40}')
paths = git('ls-tree', '-r', '--name-only', HEAD, '--', '.github/workflows').splitlines()
inverse = {row['pin']: row['reference'] for row in mapping.values()}


def normalize(node):
    if isinstance(node, dict):
        return {key: inverse.get(value, value) if key == 'uses' and isinstance(value, str)
                else normalize(value) for key, value in node.items()}
    if isinstance(node, list):
        return [normalize(value) for value in node]
    return node


records = []
old_pins = []
changed_count = 0
direct_count = 0
for path in paths:
    if not path.endswith(('.yml', '.yaml')):
        continue
    before = git('show', f'{BASE}:{path}')
    after = git('show', f'{HEAD}:{path}')
    before_lines, after_lines = before.splitlines(), after.splitlines()
    assert len(before_lines) == len(after_lines), path
    modifications = []
    for number, (old, new) in enumerate(zip(before_lines, after_lines, strict=True), 1):
        old_use, new_use = uses.fullmatch(old), uses.fullmatch(new)
        if old != new:
            assert old_use is not None and new_use is not None, (path, number)
            assert old_use['prefix'] == new_use['prefix']
            row = mapping[old_use['ref']]
            assert new_use['ref'] == row['pin']
            assert new_use['comment'].strip() == '# ' + row['matching_release_tags'][0]
            modifications.append({'line': number, 'before': old_use['ref'], 'after': new_use['ref']})
            changed_count += 1
        elif old_use and immutable.fullmatch(old_use['ref']):
            old_pins.append({'file': path, 'line': number, 'reference': old_use['ref'],
                             'comment': old_use['comment']})
        if new_use and not new_use['ref'].startswith(('./', 'docker://')):
            assert immutable.fullmatch(new_use['ref']), (path, number, new_use['ref'])
            assert new_use['comment'] and re.fullmatch(r'\s+# v\d+(?:\.\d+)*(?:[, ].*)?', new_use['comment'])
            direct_count += 1
    assert normalize(yaml.safe_load(after)) == normalize(yaml.safe_load(before)), path
    records.append({'file': path, 'changed_uses': len(modifications), 'changes': modifications,
                    'normalized_yaml_equal': True})

assert changed_count == 176
assert direct_count == 178
assert len(old_pins) == 2
assert sum(bool(r['changes']) for r in records) == 21
source_diff = git('diff', '--name-only', CODE, HEAD, '--', 'src', 'tests', 'tools', '.github', 'docs/specs')
assert not source_diff
assert not git('status', '--porcelain')

result = {
    'base': BASE, 'reviewed_head': HEAD, 'reviewed_tree': git('rev-parse', f'{HEAD}^{{tree}}').strip(),
    'tested_code': CODE, 'later_source_unchanged': True,
    'changed_files': sum(bool(r['changes']) for r in records), 'changed_uses': changed_count,
    'direct_immutable_uses': direct_count, 'preexisting_pins_preserved': old_pins,
    'upstream': upstream, 'workflows': records,
    'raw_upstream_sha256': hashlib.sha256((RESEARCH / 'raw-upstream-evidence.json').read_bytes()).hexdigest(),
    'pin_map_sha256': hashlib.sha256((RESEARCH / 'pin-map.json').read_bytes()).hexdigest(),
    'verification': 'Only direct uses values/version comments differ, including all parsed workflow keys, scripts, conditions and parameters.'
}
(OUT / 'workflow-upstream-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['reviewed_head', 'reviewed_tree', 'changed_files', 'changed_uses', 'direct_immutable_uses']}))
