from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest

ROOT = Path('/workspace/scratch/837fe19aae3a/review-codex1')
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / 'tests'))


def module(filename):
    name = 'independent_' + filename.removesuffix('.py')
    spec = importlib.util.spec_from_file_location(name, ROOT / 'tests' / filename)
    loaded = importlib.util.module_from_spec(spec)
    sys.modules[name] = loaded
    spec.loader.exec_module(loaded)
    return loaded


PKG = module('test_codex_pkg_packaging.py')
WORKFLOWS = module('test_codex_pkg_workflows.py')
SITE = module('test_site_workflow.py')
UNIFIED = module('test_unified_live_tool.py')
CHECKOUT = 'actions/checkout@11d5960a326750d5838078e36cf38b85af677262'
DOWNLOAD = 'actions/download-artifact@d3f86a106a0bac45b974a628896c90dbdf5c8093'


def test_actual_global_gate_refuses_one_mutable_action(monkeypatch):
    monkeypatch.setattr(WORKFLOWS, 'workflow_sources', lambda: [('controlled.yml', ' - uses: actions/checkout@v4')])
    with pytest.raises(AssertionError, match='controlled.yml:1: actions/checkout@v4'):
        WORKFLOWS.test_remote_actions_are_immutable()


def test_actual_global_gate_accepts_commit_and_local_action(monkeypatch):
    monkeypatch.setattr(WORKFLOWS, 'workflow_sources', lambda: [('controlled.yml',
        f' - uses: {CHECKOUT} # v4.4.0\n - uses: ./local-action')])
    WORKFLOWS.test_remote_actions_are_immutable()


def test_linux_checkout_comment_cannot_replace_action(monkeypatch):
    original = PKG._linux_smoke_job()
    altered = original.replace('uses: ' + CHECKOUT, 'run: echo checkout # uses: ' + CHECKOUT)
    assert altered != original
    monkeypatch.setattr(PKG, '_linux_smoke_job', lambda: altered)
    with pytest.raises(AssertionError, match='linux-smoke missing actions/checkout'):
        PKG.test_linux_package_runs_full_cli_smoke()


def test_linux_checkout_order_is_still_enforced(monkeypatch):
    original = PKG._linux_smoke_job()
    altered = original.replace(CHECKOUT, 'TEMP_REVIEW_CHECKOUT').replace(DOWNLOAD, CHECKOUT).replace(
        'TEMP_REVIEW_CHECKOUT', DOWNLOAD)
    monkeypatch.setattr(PKG, '_linux_smoke_job', lambda: altered)
    with pytest.raises(AssertionError):
        PKG.test_linux_package_runs_full_cli_smoke()


def test_pages_deploy_comment_cannot_replace_action(monkeypatch):
    pin = 'actions/deploy-pages@d6db90164ac5ed86f2b6aed7e0febac5b3c0c03e'
    altered = SITE.TEXT.replace('uses: ' + pin, 'run: echo deploy # uses: ' + pin)
    assert altered != SITE.TEXT
    monkeypatch.setattr(SITE, 'TEXT', altered)
    with pytest.raises(AssertionError, match='actions/deploy-pages'):
        SITE.test_official_pages_actions_use_reviewed_immutable_commits()


@pytest.mark.parametrize('lines', [
    ['      - name: "Quoted # text: still quoted"'],
    ["      - name: 'Quoted # text: still quoted'"],
    ['      - name: https://example.invalid/fragment#retained'],
    ['      - name: Valid # ignored: comment:'],
    ['      - run: |', '          REPORT: value # shell script text', '      - name: Next'],
])
def test_scalar_comment_repair_retains_valid_yaml_forms(monkeypatch, lines):
    monkeypatch.setattr(UNIFIED, 'workflow_lines', lambda: lines)
    UNIFIED.test_workflow_has_no_tabs_and_unquoted_colon_values_outside_block_scalars()


@pytest.mark.parametrize('line', [
    '      - name: Invalid: value # permitted comment follows invalid value',
    '      - name: Invalid: # permitted comment follows terminal colon',
    '      - name: Invalid#fragment: value',
])
def test_scalar_comment_repair_refuses_actual_colon_errors(monkeypatch, line):
    monkeypatch.setattr(UNIFIED, 'workflow_lines', lambda: [line])
    with pytest.raises(pytest.fail.Exception, match='plain scalar'):
        UNIFIED.test_workflow_has_no_tabs_and_unquoted_colon_values_outside_block_scalars()
