# Windows Intel version-name repair

## Source and scope

Base PR #349 `11f51c105bf63946f59373ae605b937c4fee607a`.
Spec-first commit `47d8228b10f330728eb20ed99a688074cd49bd17`.
Unchanged-runtime failing-control commit `e18177302fce5d58e92a677bae89d7732d94a8d6`.
Final authored source `eeb7bc07eff8b1028adc40fbad8d04deecfdd539`, tree
`e937a9b143b6513e7166bc318828a342127d58a7`.
Branch `codex/patchtrace-intel-version-20261121-837fe`.

The two existing adapter patterns now accept the optional literal `.exe` after
exact `capa` and `floss` program names. The new group is noncapturing, so existing
version fields and FLOSS build-suffix parsing are unchanged. No other production
logic changed. Zero exit, supported major, executable SHA-256 pin, explicit
untested-build opt-in, help/option and backend admission still apply.

## Actual verification

The new 34-control selection on unchanged runtime produced **10 failed, 24 passed**.
Failures cover the valid Windows names on stdout/stderr, then the downstream
major-version and pin checks that previously never became reachable for those
names. The baseline log/JUnit remain unchanged.

Final normal-conftest offscreen selection: **169 passed, 0 failed, 0 skipped** in
11.05 seconds. This includes the 34 new controls and eight maintained adapter,
runner, CLI, setup, parser, audit and provisioner files. Counts overlap; do not
add 34 to 169. Whole-tree Ruff, pip check, isolated Python source binding and
`git diff --check` passed. All receipts name the exact clean tested source.

Positive controls cover Unix/Windows names, stdout/stderr, CRLF, and existing
FLOSS `v`/build suffixes. Negative controls reject prefix and suffix lookalikes,
unescaped-dot lookalikes, different extensions, unsupported major versions,
unpinned builds without explicit opt-in, and nonzero version exits. Test runner
responses exercise actual adapter admission and process-wrapper plumbing;
the authored regular file is hashed but never executed.

## Native limits and separate diagnostic follow-up

The earlier PR349 Windows job reported capa identification failure with exit0
and FLOSS failure with exit1. Actual probe streams were not retained. This
repair establishes the confirmed source-format contract only: it does not prove
the cause of that capa execution or resolve the FLOSS process failure. No live
tool, target input, full suite, workflow, remote ref or release was run or changed.

For the separate native failure, retain bounded version/help probe stdout and
stderr, exact arguments and exit status in the existing live-test evidence.
A test-side runner recorder limited to `--version`, `--help` and `-H` can capture
that information without changing application failure messages or loosening
live assertions. Diagnose the actual Windows result before claiming compatibility.

## Integration handoff

The worktree is clean; the three commits after PR349 can be merged from the
shared Git object database. Only the two adapter files, the dedicated regression
file, and the T3.1 contract section are owned by this change. Global ledger,
workflow, QA, todo and index files were left to the coordinator. Independent
review and exact combined-head qualification remain pending. Author ownership
is released to the coordinator; there is no background test process.
