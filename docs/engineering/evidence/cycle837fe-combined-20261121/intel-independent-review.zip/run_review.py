from __future__ import annotations

import datetime
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

label, checkout, python = sys.argv[1:4]
root = Path(checkout)
evidence = Path(__file__).resolve().parent
selected = [str(evidence / 'test_version_admission_controls.py')]
if label == 'diagnostics-final':
    selected = [str(evidence / 'test_probe_observation_controls.py'),
                'tests/test_intel_probe_diagnostics.py', 'tests/test_live_harness.py',
                'tests/test_live_cache_diagnostics.py', 'tests/test_intel_tools_runner.py',
                'tests/test_provision_intel_tools.py', 'tests/test_intel_tools_audit.py']
if label == 'version-final':
    selected += [
        'tests/test_intel_tool_version_names.py', 'tests/test_intel_tools_audit.py',
        'tests/test_intel_tools_runner.py', 'tests/test_intel_tools_floss_wb3.py',
        'tests/test_intel_tools_parsers.py', 'tests/test_capa_setup.py',
        'tests/test_capa_cli.py', 'tests/test_intel_tools_cli.py',
        'tests/test_provision_intel_tools.py',
    ]
command = [python, '-m', 'pytest', '-q', *selected,
           f'--junitxml={evidence / (label + ".xml")}']
git = lambda *args: subprocess.check_output(['git', *args], cwd=root, text=True).strip()
receipt = {
    'command': command, 'cwd': str(root), 'head': git('rev-parse', 'HEAD'),
    'tree': git('rev-parse', 'HEAD^{tree}'), 'dirty_before': git('status', '--porcelain'),
    'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
env = os.environ.copy()
env.pop('PYTHONPATH', None)
env['QT_QPA_PLATFORM'] = 'offscreen'
started = time.monotonic()
with (evidence / (label + '.log')).open('w') as log:
    result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
receipt.update(returncode=result.returncode, seconds=round(time.monotonic() - started, 3),
               finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
               head_after=git('rev-parse', 'HEAD'), dirty_after=git('status', '--porcelain'),
               log_sha256=hashlib.sha256((evidence / (label + '.log')).read_bytes()).hexdigest())
(evidence / (label + '.json')).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
print((evidence / (label + '.log')).read_text()[-5000:])
raise SystemExit(result.returncode)
