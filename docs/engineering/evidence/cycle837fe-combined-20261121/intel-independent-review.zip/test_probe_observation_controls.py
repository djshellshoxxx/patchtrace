"""Independent observer controls using authored results; no native execution."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path

import patchtrace
import pytest

from patchtrace.intelligence.tools import capa, floss, pins, process
from patchtrace.jobs import ProcessResult

ROOT = Path(patchtrace.__file__).resolve().parents[2]
SPEC = importlib.util.spec_from_file_location('independent_probe_diag', ROOT / 'tests/intel_probe_diagnostics.py')
diagnostics = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(diagnostics)


def test_nested_contexts_restore_each_delegate_without_extra_execution(monkeypatch):
    outcome = process.Execution(0, None, 'same', '', False, 1)
    calls = []

    def original(executable, args, **kwargs):
        calls.append((executable, args, kwargs))
        return outcome

    monkeypatch.setattr(process, 'run_version_probe', original)
    with diagnostics.capture_version_probes() as outer:
        outer_delegate = process.run_version_probe
        with diagnostics.capture_version_probes() as inner:
            assert process.run_version_probe(Path('/private/floss.exe'), ['--version']) is outcome
        assert process.run_version_probe is outer_delegate
        assert process.run_version_probe(Path('/private/floss.exe'), ['-H']) is outcome
    assert process.run_version_probe is original
    assert len(calls) == 2 and len(outer['probes']) == 2 and len(inner['probes']) == 1


def test_redaction_precedes_truncation_of_long_credential_value(monkeypatch):
    value = 'private' * 1500
    raw = 'native diagnostic token=' + value
    outcome = process.Execution(1, None, '', raw, False, 4)
    monkeypatch.setattr(process, 'run_version_probe', lambda *a, **kw: outcome)
    with diagnostics.capture_version_probes() as document:
        assert process.run_version_probe(Path('/private/floss.exe'), ['--version']) is outcome
    entry = document['probes'][0]
    assert entry['stderr'] == 'native diagnostic token=[redacted]'
    assert entry['stderr_chars'] == len(raw)
    assert entry['stderr_truncated'] is False
    assert value not in json.dumps(document)
    assert entry['returncode'] == 1


def test_observation_error_cannot_replace_underlying_exception(monkeypatch):
    original_error = OSError('underlying diagnostic must stay private')

    def original(*args, **kwargs):
        raise original_error

    def broken_formatter(*args, **kwargs):
        raise ValueError('formatting diagnostic must stay private')

    monkeypatch.setattr(process, 'run_version_probe', original)
    monkeypatch.setattr(diagnostics, 'redact_log', broken_formatter)
    with pytest.raises(OSError) as caught, diagnostics.capture_version_probes() as document:
        process.run_version_probe(Path('/private/floss.exe'), ['--version'])
    assert caught.value is original_error
    assert process.run_version_probe is original
    assert document['probes'] == [{'observation_error_class': 'ValueError'}]
    assert 'private' not in json.dumps(document)


@pytest.mark.parametrize('engine', ['capa', 'floss'])
def test_observer_integrates_with_actual_adapter_probe(tmp_path, monkeypatch, engine):
    module, config, version, help_flag, help_name = {
        'capa': (capa, capa.CapaConfig, '9.4.0', '--help', 'help.stdout.txt'),
        'floss': (floss, floss.FlossConfig, '3.1.1', '-H', 'help-advanced.stdout.txt'),
    }[engine]
    executable = tmp_path / f'{engine}.exe'
    executable.write_bytes(b'independent adapter observer fixture; never executed')
    monkeypatch.setitem(pins.PINNED_EXECUTABLES[engine], hashlib.sha256(executable.read_bytes()).hexdigest(),
                        'independent observer control')
    help_text = (ROOT / 'tests/fixtures/intel_tools' / engine / help_name).read_text()
    version_text = f'{engine} {version}\n'
    original = process.run_version_probe
    calls = []

    def controlled_runner(argv, **kwargs):
        calls.append(tuple(argv))
        if argv[1:] == ['--version']:
            return ProcessResult(0, version_text, None, '')
        assert argv[1:] == [help_flag]
        return ProcessResult(0, help_text, None, '')

    with diagnostics.capture_version_probes() as document:
        manifest = module.probe(config(executable), runner=controlled_runner, use_cache=False)
    assert manifest.supported and manifest.pin_status == 'pinned'
    assert process.run_version_probe is original
    assert len(calls) == len(document['probes']) == 2
    assert [p['argv'] for p in document['probes']] == [[executable.name, '--version'],
                                                     [executable.name, help_flag]]
    assert [p['stdout'] for p in document['probes']] == [version_text, help_text[-4096:]]
    assert [p['returncode'] for p in document['probes']] == [0, 0]
    assert str(tmp_path) not in json.dumps(document)
