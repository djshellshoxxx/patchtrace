# Independent Intel source review

**No blocking source finding** in the version-name repair or diagnostic observer.
This verdict covers the exact component sources below, not an untested combined
integration or native Windows acceptance.

| Component | Reviewed source | Complete tree |
| --- | --- | --- |
| Windows version-name repair | `eeb7bc07eff8b1028adc40fbad8d04deecfdd539` | `e937a9b143b6513e7166bc318828a342127d58a7` |
| Live-probe diagnostic observer | `03db821b65b19ebe57044d2e1eee2da0c3605a08` | `a783e551564db1ce65c81f4483e9488f0c57daf3` |
| Shared unchanged baseline | `11f51c105bf63946f59373ae605b937c4fee607a` | `4939056ceb0e02b419c820b9e5748c869c40a857` |

## Version admission

The optional `.exe` groups are literal and noncapturing. Existing anchors,
flags, version captures and FLOSS suffix grammar remain intact. Independent AST
comparison proves every other production node in both adapters is unchanged.
Exit status, supported major, executable digest, explicit untested-build opt-in,
help requirements and backend admission therefore retain their existing logic.

The reviewer ran the maintained selection plus 16 fresh controls: **185 passed**.
The same 16 fresh controls on exact PR349 produced **8 failed, 8 passed**. The
failures reproduce Windows-name refusal and the resulting failure to reach
identified-version help checks. On the repaired source, valid Windows names on
stdout/stderr reach proper admission; failed help, missing required options,
uppercase/path/doubled-extension lookalikes and nonzero exits remain refused.
The author evidence's 15 manifest members also verify.

## Diagnostic retention

The reviewer independently ran **110 passing cases**, including five fresh
controls. Those controls exercise nested context restoration without extra
execution, redaction before truncating a long credential value, preservation of
the original exception when formatting fails, and actual capa/FLOSS probe
plumbing with controlled runner responses. The output contains a deliberately
mocked blocked-DIE case; that is a passing harness control, not a native result.

One observer import, one delegating context and five additive diagnostic keyword
arguments account for the complete live-test change. Removing those additions
from its AST gives exactly the PR349 AST, so its support/pin/golden and
failure/skip decisions are unchanged. The observer captures only known probe
flags and executable basenames, forwards original objects and returns identical
results, restores the prior callable, and never initiates a new process. Stream
and metadata limits are explicit; credentials are redacted before text tails
are shortened. Environment values and arbitrary arguments are not serialized.
All 21 diagnostic-author manifest members verify.

## Qualification limits

The 185 and 110 selections overlap and must not be added. They already include
the 16 and five independent controls. Each source was clean before and after
its run and was bound to its own isolated interpreter; exact commands, source
identities, JUnit and complete logs are retained beside this review.

The source repair does not prove the cause of the older capa exit-zero failure.
The older FLOSS exit-one failure is still unresolved and refused. No native
compatibility, whole-suite, analyzed-target execution or release acceptance is
claimed. Inspect subsequent exact-source Windows probe diagnostics and complete
combined qualification before any promotion requiring those results.

No candidate source, index, ref, workflow or remote state was modified by this
reviewer. The detached review checkouts contain only the already-authored code;
independent controls and receipts are outside those checkouts.
