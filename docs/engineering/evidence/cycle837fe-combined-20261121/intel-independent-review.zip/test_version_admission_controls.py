"""Independent probe admission checks; controlled responses, no executable runs."""
from __future__ import annotations

import hashlib
import importlib
from pathlib import Path

import pytest

from patchtrace.intelligence.tools import capa, floss, pins
from patchtrace.jobs import ProcessResult

CASES = {
    'capa': (capa, capa.CapaConfig, '9.4.0', '--help', 'help.stdout.txt'),
    'floss': (floss, floss.FlossConfig, '3.1.1', '-H', 'help-advanced.stdout.txt'),
}


def admit(tmp_path, monkeypatch, engine, *, name=None, stderr=False,
          help_exit=0, missing_help=False, version_exit=0):
    module, config, version, help_flag, fixture = CASES[engine]
    source = Path(importlib.import_module('patchtrace').__file__).resolve().parents[2]
    help_text = (source / 'tests' / 'fixtures' / 'intel_tools' / engine / fixture).read_text()
    executable = tmp_path / f'{engine}.exe'
    executable.write_bytes(b'independent probe fixture: not executable')
    digest = hashlib.sha256(executable.read_bytes()).hexdigest()
    monkeypatch.setitem(pins.PINNED_EXECUTABLES[engine], digest, 'independent review fixture')
    banner = f'{name or engine + ".exe"} {version}\r\n'
    calls = []

    def runner(argv, **kwargs):
        calls.append(tuple(argv))
        assert Path(argv[0]) == executable
        assert kwargs['separate_streams'] is True
        if argv[1:] == ['--version']:
            return ProcessResult(version_exit, '' if stderr else banner, None, banner if stderr else '')
        assert argv[1:] == [help_flag]
        return ProcessResult(help_exit, 'unrelated text' if missing_help else help_text, None, '')

    report = module.probe(config(executable), runner=runner, use_cache=False)
    assert calls == [(str(executable), '--version'), (str(executable), help_flag)]
    assert report.executable_sha256 == digest
    return report


@pytest.mark.parametrize('engine', CASES)
@pytest.mark.parametrize('stderr', [False, True])
def test_windows_names_are_admitted_with_valid_help(tmp_path, monkeypatch, engine, stderr):
    report = admit(tmp_path, monkeypatch, engine, stderr=stderr)
    assert report.supported, report.reason
    assert report.pin_status == 'pinned'
    assert report.version == CASES[engine][2]


@pytest.mark.parametrize('engine', CASES)
def test_windows_name_does_not_bypass_failed_help(tmp_path, monkeypatch, engine):
    report = admit(tmp_path, monkeypatch, engine, help_exit=7)
    assert not report.supported
    assert report.version == CASES[engine][2]
    assert 'help' in report.reason.lower() or '-H' in report.reason


@pytest.mark.parametrize('engine', CASES)
def test_windows_name_does_not_bypass_required_help_options(tmp_path, monkeypatch, engine):
    report = admit(tmp_path, monkeypatch, engine, missing_help=True)
    assert not report.supported
    assert report.version == CASES[engine][2]
    assert 'help' in report.reason.lower() or 'option' in report.reason.lower()


@pytest.mark.parametrize('engine', CASES)
@pytest.mark.parametrize('name', ['CAPITAL', 'path', 'double'])
def test_unrequested_program_name_variants_stay_invalid(tmp_path, monkeypatch, engine, name):
    value = {'CAPITAL': engine.upper() + '.EXE', 'path': 'folder/' + engine + '.exe',
             'double': engine + '.exe.exe'}[name]
    report = admit(tmp_path, monkeypatch, engine, name=value)
    assert not report.supported
    assert report.version is None


@pytest.mark.parametrize('engine', CASES)
def test_nonzero_version_exit_is_still_invalid(tmp_path, monkeypatch, engine):
    report = admit(tmp_path, monkeypatch, engine, version_exit=1)
    assert not report.supported
    assert report.version is None

