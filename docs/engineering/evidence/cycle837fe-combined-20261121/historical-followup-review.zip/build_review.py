from __future__ import annotations

import ast
import datetime
import difflib
import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path(__file__).resolve().parent
FROZEN = json.loads((OUT / 'frozen-target.json').read_text())
ROOT = Path(FROZEN['root'])
TARGET = FROZEN['head']
ROWS = json.loads((OUT / 'expanded-inventory.json').read_text())['branches']
LIVE = {x['branch']: x['response']['object']['sha'] for x in
        json.loads((OUT / 'live-ref-responses.json').read_text())['refs']}


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()


def source(ref, path):
    return subprocess.check_output(['git', 'show', ref + ':' + path], cwd=ROOT, text=True)


def declarations(text):
    result = {}

    def descend(node, prefix=''):
        for child in getattr(node, 'body', []):
            if isinstance(child, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
                name = prefix + child.name
                result[name] = child
                if isinstance(child, ast.ClassDef):
                    descend(child, name + '.')

    descend(ast.parse(text))
    return result


def normalized(node):
    return ast.dump(node, include_attributes=False)


def compare(head, path, names=None):
    donor, current = source(head, path), source(TARGET, path)
    before, after = declarations(donor), declarations(current)
    selected = names if names is not None else list(before)
    rows = []
    for name in selected:
        a = normalized(before[name])
        b = normalized(after[name]) if name in after else None
        rows.append({'declaration': name, 'present': b is not None, 'ast_identical': a == b,
                     'donor_ast_sha256': hashlib.sha256(a.encode()).hexdigest(),
                     'target_ast_sha256': hashlib.sha256(b.encode()).hexdigest() if b else None})
    return {'path': path, 'donor_blob': git('rev-parse', head + ':' + path),
            'target_blob': git('rev-parse', TARGET + ':' + path),
            'byte_identical': donor == current,
            'donor_bytes_sha256': hashlib.sha256(donor.encode()).hexdigest(),
            'target_bytes_sha256': hashlib.sha256(current.encode()).hexdigest(),
            'declarations': rows,
            'new_target_declarations': sorted(set(after) - set(before))}


SCOPES = [
    {
        'branch': 'codex/consolidate-backup-stability-20261102',
        'scope': 'Repeated complete backup-byte observations before trusting a cached verification verdict.',
        'classification': 'DUPLICATE',
        'behavior': 'The entire verified_backup.py implementation is byte-identical. _fingerprint obtains two complete observations and returns a version only when they agree; _fingerprint_once retains bounded regular-file hashing and identity/change checks. Every original test declaration remains AST-identical, including the original no-change-time cached-reuse control. Later test additions do not remove the donor controls.',
        'excluded': 'Full filesystem concurrency guarantees, fresh native Windows execution, all future writer behavior, and historical QA/document assertions are not requalified.',
        'production': {'src/patchtrace/verified_backup.py': ['_fingerprint', '_fingerprint_once', '_stat_key']},
        'tests': {'tests/test_verified_backup_byte_integrity.py': None},
    },
    {
        'branch': 'integrate/gui-inspection-20261105',
        'scope': 'Ignore an obsolete inspection failure after the current project inspection key changes.',
        'classification': 'DUPLICATE',
        'behavior': 'MainWindow._inspection_failed is AST-identical. A mismatched supplied key returns before changing the inspection error, emitting status or appending a log; a current or unspecified key follows the retained failure path. The complete stale-inspection regression file is byte-identical.',
        'excluded': 'The same donor also changed export privacy copy; that already-reviewed export scope is deliberately excluded here. Broader success-path/lifecycle changes and native GUI acceptance are not reviewed.',
        'production': {'src/patchtrace/ui.py': ['MainWindow._inspection_failed']},
        'tests': {'tests/test_audit116_stale_inspection_failure.py': None},
    },
    {
        'branch': 'integrate/project-adoption-20261105',
        'scope': 'Transactional adoption of an incoming project, including prior service and recent-project preference rollback.',
        'classification': 'DUPLICATE',
        'behavior': 'The complete project_adoption.py helper and its test file are byte-identical; MainWindow.set_service remains the same thin AST-equivalent delegation. The previous service stays open until incoming render/preferences/menu work succeeds. Failure restores the prior pointer and preference state, attempts view recovery, closes only a rejected different service, and reraises. Readopting the same service does not close it.',
        'excluded': 'All other MainWindow evolution, service close-error contracts, prior manual platform claims and whole-branch document equivalence are not evaluated.',
        'production': {'src/patchtrace/gui/qt/project_adoption.py': ['adopt_project'], 'src/patchtrace/ui.py': ['MainWindow.set_service']},
        'tests': {'tests/test_gui_project_adoption.py': None},
    },
    {
        'branch': 'repair/wizard-lock-retry-20261105',
        'scope': 'Shared read-only creation preflight for retained lock-only destinations, and retention of an already committed acquired project on later provenance/final-copy failure.',
        'classification': 'SUPERSEDED',
        'behavior': 'The donor preflight contract remains called by New/Acquisition dialogs, acquisition.check_project_root, KB destination checking and attachment admission. The shared helper now additionally inspects the nearest existing ancestor when lstat reports a missing destination; the KB path also refuses a Windows junction. Donor dialog methods, acquisition workflow and promote function, are AST-equivalent in the named paths; the attachment _begin destination guard remains an identical subtree inside a later expanded journal path. promote still closes and retains the committed project instead of deleting it after later verification/provenance failure. All original creation-retry test declarations remain unchanged, with an added Windows missing-parent control.',
        'excluded': 'Later acquisition network/provenance behavior, other quarantine cleanup methods, complete KB attachment evolution and platform execution are outside scope. The unchanged import-boundary helper tests are checked, but the unrelated evolving domain-import inventory is excluded.',
        'production': {
            'src/patchtrace/persistence.py': ['creation_directory_available'],
            'src/patchtrace/ui.py': ['NewProjectDialog.accept', 'AcquisitionDialog.download'],
            'src/patchtrace/acquisition/workflow.py': ['check_project_root'],
            'src/patchtrace/acquisition/quarantine.py': ['promote'],
            'src/patchtrace/kbcorrelation/investigation_service.py': ['_new_destination'],
            'src/patchtrace/kbcorrelation/store.py': ['ProjectAttachment._begin'],
        },
        'tests': {
            'tests/test_gui_creation_retry.py': None,
            'tests/test_acquisition_hardening.py': ['test_promote_failure_after_create_retains_the_committed_project'],
            'tests/test_kbc_contracts.py': ['test_investigation_destination_preflight_has_no_database_escape', 'test_workspace_destination_preflight_is_exact_helper_import'],
        },
    },
    {
        'branch': 'work/investigation-accessibility-20261105',
        'scope': 'Investigation field mnemonic buddies, ordered keyboard traversal and focus on a missing workspace field.',
        'classification': 'SUPERSEDED',
        'behavior': 'The original labeled-field construction loop is retained as an identical AST subtree, including field buddies and the original mnemonic text. The final tab-order application loop is also identical. Current initialization extends the ordered list for stored-product and separately consented metadata controls; its original product selector remains before the older binary field. The missing-workspace guard still sets keyboard focus to the correct field. The complete original accessibility regression file is byte-identical.',
        'excluded': 'New product/metadata features, every new mnemonic combination, native screen-reader/manual accessibility and broad investigation lifecycle are not qualified.',
        'production': {'src/patchtrace/kbcorrelation/investigation_qt.py': ['InvestigationDialog.__init__', 'InvestigationDialog._submit']},
        'tests': {'tests/test_kb_accessibility_20261105.py': None},
    },
    {
        'branch': 'work/persistence-security-20261105',
        'scope': 'Preserve ordinary writer-lock identity validation before writing lock metadata.',
        'classification': 'DUPLICATE',
        'behavior': 'The complete ProjectLock class is AST-identical, including _check_identity and initialization. The same regular-file/link-count/handle-path identity checks occur around kernel lock acquisition before metadata writes, and descriptor cleanup remains present. The complete original regression file is byte-identical. This is a retention comparison, not a new attack or platform reproduction.',
        'excluded': 'Other persistence methods and later backup/state reconciliation, new race analysis, fresh filesystem/native acceptance and all transitive dependencies are not requalified.',
        'production': {'src/patchtrace/persistence.py': ['ProjectLock', 'ProjectLock._check_identity', 'ProjectLock.__init__']},
        'tests': {'tests/test_persistence_security_20261105.py': None},
    },
]

records = []
for scope in SCOPES:
    row = next(x for x in ROWS if x['branch'] == scope['branch'])
    head = row['head']
    assert LIVE[scope['branch']] == head
    pr = next(p for p in row['pull_requests'] if p['head_matches_snapshot'])
    base = pr['base_sha']
    record = {k: v for k, v in scope.items() if k not in {'production', 'tests'}}
    record.update({'head': head, 'donor_tree': git('rev-parse', head + '^{tree}'),
                   'pull_request': pr, 'original_pr_base': base,
                   'original_pr_unique_commits': git('rev-list', '--reverse', base + '..' + head).splitlines(),
                   'captured_main': 'fdc2696c23bdbfe7668348f25e3b336ce33039f7',
                   'merge_bases_with_captured_main': git('merge-base', '--all', head, 'fdc2696c23bdbfe7668348f25e3b336ce33039f7').splitlines(),
                   'merge_bases_with_target': git('merge-base', '--all', head, TARGET).splitlines(),
                   'unique_commits_vs_target': git('rev-list', head, '^' + TARGET).splitlines(),
                   'original_pr_changed_paths': git('diff', '--name-status', base, head).splitlines(),
                   'live_ref_verified': True,
                   'live_ref_url': 'https://api.github.com/repos/djshellshoxxx/PatchTrace/git/ref/heads/' + scope['branch'],
                   'whole_branch_status': 'PARTIALLY_REVIEWED',
                   'source_recovery_required_in_named_scope': False,
                   'delete_authorized': False,
                   'production_comparisons': [compare(head, p, names) for p, names in scope['production'].items()],
                   'test_source_comparisons': [compare(head, p, names) for p, names in scope['tests'].items()]})
    for path, names in scope['production'].items():
        before, after = source(head, path), source(TARGET, path)
        bd, ad = declarations(before), declarations(after)
        for name in names:
            assert name in ad
            if normalized(bd[name]) != normalized(ad[name]):
                diff = ''.join(difflib.unified_diff(ast.get_source_segment(before, bd[name]).splitlines(True),
                                                   ast.get_source_segment(after, ad[name]).splitlines(True),
                                                   fromfile=head + ':' + name, tofile=TARGET + ':' + name))
                slug = scope['branch'].replace('/', '--') + '--' + name.replace('.', '-') + '.diff'
                (OUT / slug).write_text(diff)
    # Every specifically retained test declaration must match, not merely exist.
    assert all(d['present'] and d['ast_identical'] for c in record['test_source_comparisons'] for d in c['declarations'])
    records.append(record)

# The donor destination guard remains before journal publication in the adapted attachment method.
wizard = next(x for x in records if x['branch'] == 'repair/wizard-lock-retry-20261105')
path = 'src/patchtrace/kbcorrelation/store.py'
bd = declarations(source(wizard['head'], path)); ad = declarations(source(TARGET, path))
begin_before, begin_after = bd['ProjectAttachment._begin'], ad['ProjectAttachment._begin']
guard = next(n for n in ast.walk(begin_before) if isinstance(n, ast.If) and 'creation_directory_available' in normalized(n.test))
assert normalized(guard) in {normalized(n) for n in ast.walk(begin_after)}
current_nodes = begin_after.body
guard_index = next(i for i, n in enumerate(current_nodes) if normalized(n) == normalized(guard))
publication_index = next(i for i, n in enumerate(current_nodes) if isinstance(n, ast.Expr) and 'journal_put' in normalized(n))
assert guard_index < publication_index
wizard['adaptation_checks'] = {'attachment_preflight_guard_ast_identical': True,
                               'preflight_precedes_journal_publication': True,
                               'surrounding_journal_evolution_excluded': True}

# Explicit structural evidence for the adapted accessibility scope.
access = next(x for x in records if x['branch'] == 'work/investigation-accessibility-20261105')
path = 'src/patchtrace/kbcorrelation/investigation_qt.py'
bd = declarations(source(access['head'], path)); ad = declarations(source(TARGET, path))
donor_init, target_init = bd['InvestigationDialog.__init__'], ad['InvestigationDialog.__init__']
target_subtrees = {normalized(n) for n in ast.walk(target_init)}
loops = [n for n in ast.walk(donor_init) if isinstance(n, ast.For)]
field_loop = next(n for n in loops if 'Advisory &workspace' in normalized(n))
tab_loop = next(n for n in loops if 'setTabOrder' in normalized(n))
guard = next(n for n in ast.walk(bd['InvestigationDialog._submit']) if isinstance(n, ast.If) and
             'Choose an advisory workspace directory before continuing.' in normalized(n))
access['adaptation_checks'] = {
    'original_labeled_field_loop_ast_identical': normalized(field_loop) in target_subtrees,
    'original_tab_order_application_loop_ast_identical': normalized(tab_loop) in target_subtrees,
    'workspace_focus_guard_ast_identical': normalized(guard) in {normalized(n) for n in ast.walk(ad['InvestigationDialog._submit'])},
    'current_scope_order': "position = tab_order.index(self.fields['older']); tab_order[position:position] = [product_filter, browse_products, self.scope]",
}
assert all(v is True for k, v in access['adaptation_checks'].items() if k.endswith('identical'))

report = {'schema': 'patchtrace.bounded-historical-semantic-followup/1',
          'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'reviewer': 'historical_semantics_followup independent read-only worker',
          'target_local_commit': TARGET, 'target_tree': FROZEN['tree'],
          'captured_inventory_heads': 364,
          'records': records,
          'counts': {'named_scopes_reviewed': len(records), 'DUPLICATE': 4, 'SUPERSEDED': 2,
                     'whole_branches_fully_reviewed': 0, 'new_ports_needed_in_reviewed_scopes': 0},
          'limits': ['No test execution, target/tool execution, source/index/ref change, merge, or deletion.',
                     'Source and regression retention are compared; runtime/native/manual acceptance is not inferred.',
                     'All six donor heads are ancestors of main and the frozen target, including three closed-unmerged PR heads; source comparison independently establishes the named behavior retention.',
                     'The existing 181 unmatched / 16 patch-equivalent branch-level backlog is not decremented by these scoped reviews.',
                     'The target was frozen before later root integration/index changes; comparison identities do not drift.']}
(OUT / 'semantic-dispositions.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'scopes': len(records), 'production_paths': sum(len(x['production_comparisons']) for x in records),
                  'test_paths': sum(len(x['test_source_comparisons']) for x in records),
                  'retained_test_declarations': sum(len(c['declarations']) for x in records for c in x['test_source_comparisons']),
                  'target': TARGET}, indent=2))
