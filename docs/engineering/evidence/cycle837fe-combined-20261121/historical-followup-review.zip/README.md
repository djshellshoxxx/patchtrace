# Bounded historical reliability review — six additional scopes

## Finding

No unique implementation needs recovery in the six named scopes below. Four scopes retain the donor behavior exactly in the reviewed declarations; two are retained within newer implementations. These are source comparisons with explicit exclusions. **No whole branch is declared fully reviewed or safe to delete.**

## Frozen comparison identity

- Target local commit: `4ca982e708685889ac2c6f8bedecf79443e6664c`.
- Complete target tree: `6a4f9124f9e9e1af6621975fe8c8fc1a1f0cacac`.
- Review completed: `2026-11-21T06:22:06.129797+00:00`.
- The target is the combined PR #349 successor after storage/Search, direct Action pins, Windows Intel version-name parsing and probe-diagnostic source integration. Subsequent root changes do not alter this frozen comparison.
- All six live Git-ref responses match the captured donor heads. The complete 364-head inventory was decoded and its canonical hash verified before selection. The 54 MB expanded input is a scratch intermediate and is excluded from this publication set.

## Scoped dispositions

| Donor | Reviewed behavior | Scoped disposition | Whole branch |
| --- | --- | --- | --- |
| [codex/consolidate-backup-stability-20261102](https://github.com/djshellshoxxx/patchtrace/pull/162) (`f1a55c4c`) | Repeated complete backup-byte observations before trusting a cached verification verdict. | DUPLICATE | PARTIALLY_REVIEWED |
| [integrate/gui-inspection-20261105](https://github.com/djshellshoxxx/patchtrace/pull/196) (`3fa22c61`) | Ignore an obsolete inspection failure after the current project inspection key changes. | DUPLICATE | PARTIALLY_REVIEWED |
| [integrate/project-adoption-20261105](https://github.com/djshellshoxxx/patchtrace/pull/198) (`1c97defa`) | Transactional adoption of an incoming project, including prior service and recent-project preference rollback. | DUPLICATE | PARTIALLY_REVIEWED |
| [repair/wizard-lock-retry-20261105](https://github.com/djshellshoxxx/patchtrace/pull/219) (`38be184c`) | Shared read-only creation preflight for retained lock-only destinations, and retention of an already committed acquired project on later provenance/final-copy failure. | SUPERSEDED | PARTIALLY_REVIEWED |
| [work/investigation-accessibility-20261105](https://github.com/djshellshoxxx/patchtrace/pull/226) (`b5d4bcea`) | Investigation field mnemonic buddies, ordered keyboard traversal and focus on a missing workspace field. | SUPERSEDED | PARTIALLY_REVIEWED |
| [work/persistence-security-20261105](https://github.com/djshellshoxxx/patchtrace/pull/227) (`1a1e1951`) | Preserve ordinary writer-lock identity validation before writing lock metadata. | DUPLICATE | PARTIALLY_REVIEWED |

All six exact donor heads are ancestors of captured main and the frozen comparison target. Three associated PRs were closed without a direct PR merge, but their heads were retained through other integration history. Ancestry was checked separately; each behavior disposition below relies on actual source/test comparison. This does **not** decrement the existing 181 unmatched / 16 patch-equivalent branch-level backlog.

### PR #162: codex/consolidate-backup-stability-20261102

The entire verified_backup.py implementation is byte-identical. _fingerprint obtains two complete observations and returns a version only when they agree; _fingerprint_once retains bounded regular-file hashing and identity/change checks. Every original test declaration remains AST-identical, including the original no-change-time cached-reuse control. Later test additions do not remove the donor controls.

**Excluded:** Full filesystem concurrency guarantees, fresh native Windows execution, all future writer behavior, and historical QA/document assertions are not requalified.

Exact donor: `f1a55c4cf21ddb0dea243bd417b74f86caaed142`; tree `61ddda8e5b94e4eaaeb13e9939625740d1124067`. Original PR base: `ce8c65bf41541cf6adb52289d2a530ce2817a53a`. The [machine-readable review](semantic-dispositions.json) records original commits, changed paths, merge bases, file blobs and declaration digests.

### PR #196: integrate/gui-inspection-20261105

MainWindow._inspection_failed is AST-identical. A mismatched supplied key returns before changing the inspection error, emitting status or appending a log; a current or unspecified key follows the retained failure path. The complete stale-inspection regression file is byte-identical.

**Excluded:** The same donor also changed export privacy copy; that already-reviewed export scope is deliberately excluded here. Broader success-path/lifecycle changes and native GUI acceptance are not reviewed.

Exact donor: `3fa22c611697d7593755c329fd762bfb47b39b84`; tree `0b465c0989ea00da15da51270619db0e021b21dd`. Original PR base: `5d504ff5c046bfb758623182b472976003632bba`. The [machine-readable review](semantic-dispositions.json) records original commits, changed paths, merge bases, file blobs and declaration digests.

### PR #198: integrate/project-adoption-20261105

The complete project_adoption.py helper and its test file are byte-identical; MainWindow.set_service remains the same thin AST-equivalent delegation. The previous service stays open until incoming render/preferences/menu work succeeds. Failure restores the prior pointer and preference state, attempts view recovery, closes only a rejected different service, and reraises. Readopting the same service does not close it.

**Excluded:** All other MainWindow evolution, service close-error contracts, prior manual platform claims and whole-branch document equivalence are not evaluated.

Exact donor: `1c97defacd54a593a8ecdcda2b9c11c85b073791`; tree `e008808535f0e565485f9c6b750a79d5eef0320e`. Original PR base: `5d504ff5c046bfb758623182b472976003632bba`. The [machine-readable review](semantic-dispositions.json) records original commits, changed paths, merge bases, file blobs and declaration digests.

### PR #219: repair/wizard-lock-retry-20261105

The donor preflight contract remains called by New/Acquisition dialogs, acquisition.check_project_root, KB destination checking and attachment admission. The shared helper now additionally inspects the nearest existing ancestor when lstat reports a missing destination; the KB path also refuses a Windows junction. Donor dialog methods, acquisition workflow and promote function, are AST-equivalent in the named paths; the attachment _begin destination guard remains an identical subtree inside a later expanded journal path. promote still closes and retains the committed project instead of deleting it after later verification/provenance failure. All original creation-retry test declarations remain unchanged, with an added Windows missing-parent control.

**Excluded:** Later acquisition network/provenance behavior, other quarantine cleanup methods, complete KB attachment evolution and platform execution are outside scope. The unchanged import-boundary helper tests are checked, but the unrelated evolving domain-import inventory is excluded.

Exact donor: `38be184cda6fbe6f79a6f265b04e2efc6a2688dd`; tree `2b0736953403c4f1b2c64426bdbe11218132de62`. Original PR base: `f33e2a0aaa3399644367f2419fee21cfe2e8702b`. The [machine-readable review](semantic-dispositions.json) records original commits, changed paths, merge bases, file blobs and declaration digests.

### PR #226: work/investigation-accessibility-20261105

The original labeled-field construction loop is retained as an identical AST subtree, including field buddies and the original mnemonic text. The final tab-order application loop is also identical. Current initialization extends the ordered list for stored-product and separately consented metadata controls; its original product selector remains before the older binary field. The missing-workspace guard still sets keyboard focus to the correct field. The complete original accessibility regression file is byte-identical.

**Excluded:** New product/metadata features, every new mnemonic combination, native screen-reader/manual accessibility and broad investigation lifecycle are not qualified.

Exact donor: `b5d4bceabdc34f520120d9dc336d975768e20483`; tree `264bfbec7179e9bacf8302908080b7fd2dcc5b3c`. Original PR base: `afc8a2967ba3dec6b1ac3351d20dd08c193ba9bc`. The [machine-readable review](semantic-dispositions.json) records original commits, changed paths, merge bases, file blobs and declaration digests.

### PR #227: work/persistence-security-20261105

The complete ProjectLock class is AST-identical, including _check_identity and initialization. The same regular-file/link-count/handle-path identity checks occur around kernel lock acquisition before metadata writes, and descriptor cleanup remains present. The complete original regression file is byte-identical. This is a retention comparison, not a new attack or platform reproduction.

**Excluded:** Other persistence methods and later backup/state reconciliation, new race analysis, fresh filesystem/native acceptance and all transitive dependencies are not requalified.

Exact donor: `1a1e1951c55cdef46ff248145031639674ce1c63`; tree `42400f01fa4e4959b4b0ca2e99e97fb51f060fad`. Original PR base: `afc8a2967ba3dec6b1ac3351d20dd08c193ba9bc`. The [machine-readable review](semantic-dispositions.json) records original commits, changed paths, merge bases, file blobs and declaration digests.

## Verification and practical limits

- Performed 12 scoped production-file comparisons and eight test-file comparisons. All **53 retained test-source declarations** in the selected evidence are AST-identical. This includes fixtures/helpers and is **not a test execution count**.
- Independently checked the unchanged field-construction loop, tab-order application loop and missing-workspace focus guard in the adapted accessibility implementation.
- Checked that the attachment destination-preflight guard remains AST-identical and precedes journal publication, while excluding newer journal-provenance behavior from this disposition.
- No pytest, native engine, target binary, network analysis operation or platform accessibility session was executed. Existing source assertions do not establish fresh runtime acceptance.
- No repository source, index, ref, PR or workflow was modified; no merge, port, branch deletion or broad supersession is authorized by this report.
- A reviewer-only builder initially named the later `_acquisition` method as the donor destination-preflight method. Inspection showed the guard is in `_begin` on both trees. That mapping assumption was corrected; the original diagnostic is retained in `reviewer-initial-method-assumption.txt`. No application defect or test failure was inferred from it.

## Next action

Retain these scoped dispositions in the existing authoritative ledger, preserve each donor branch and continue semantic review of excluded behavior where it has not already been covered. No additional code port is warranted for the named behavior. Root should keep qualification of its newer exact combined source separate.

## Evidence

`semantic-dispositions.json` is the authoritative record for this bounded review. `live-ref-responses.json` retains official Git-ref responses; source diffs and immutable blob/AST hashes support the comparisons. `build_review.py` reproduces the read-only comparison from a repository containing the exact objects and the decoded existing inventory. The publication manifest deliberately excludes `expanded-inventory.json`. The compact ZIP includes every listed publication member, without checkout copies or runtime data.
