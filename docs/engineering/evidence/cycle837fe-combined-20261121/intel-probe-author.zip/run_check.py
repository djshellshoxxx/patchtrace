from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time
ROOT = Path('/workspace/scratch/837fe19aae3a/intel-probe-evidence-source')
OUT = Path('/workspace/scratch/837fe19aae3a/evidence/intel-probe-evidence')
label = sys.argv[1]
cmd = sys.argv[2:]
def git(*args):
    return subprocess.check_output(['git',*args],cwd=ROOT,text=True).strip()
r = {'label':label,'cwd':str(ROOT),'command':cmd,'head':git('rev-parse','HEAD'),
     'tree':git('rev-parse','HEAD^{tree}'),'status_before':git('status','--porcelain'),
     'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
start=time.monotonic()
with (OUT/(label+'.log')).open('wb') as output:
    result=subprocess.run(cmd,cwd=ROOT,env={**os.environ,'QT_QPA_PLATFORM':'offscreen'},stdout=output,stderr=subprocess.STDOUT)
r.update(returncode=result.returncode,seconds=round(time.monotonic()-start,3),
         finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
         head_after=git('rev-parse','HEAD'),status_after=git('status','--porcelain'))
r['log_sha256']=hashlib.sha256((OUT/(label+'.log')).read_bytes()).hexdigest()
(OUT/(label+'.json')).write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(r,indent=2))
print((OUT/(label+'.log')).read_text()[-5000:])
