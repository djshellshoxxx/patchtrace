# Live Intel probe diagnostic evidence

Implemented on PR #349 base `11f51c105bf63946f59373ae605b937c4fee607a`.
Final clean source **`03db821b65b19ebe57044d2e1eee2da0c3605a08`**, tree
**`a783e551564db1ce65c81f4483e9488f0c57daf3`**; branch
`codex/patchtrace-intel-probe-evidence-20261121-837fe`.

## Behavior

The existing live-test probe is observed once through a delegating context.
Original executable/argument objects and keyword values, result identity,
exception identity and callable restoration are verified. At most four fixed
version/help observations are stored, with omission count and explicitly
truncated/redacted separate stream tails, exact exit/reason/spawn/oversize and
elapsed fields. Environment and parent executable path are not recorded;
unrecognized argument vectors are forwarded without observation. The existing
per-engine artifact receives the data for failed/blocked/passed outcomes.
No workflow edit or second probe is required.

The 64-line helper is test-only; the application, runtime contracts, adapters,
shared specs, workflows and global engineering indexes remain untouched. The
existing supported/pinned predicates, failed run statuses, golden comparisons,
DIE advisory skip and absent-tool behavior remain unchanged.

## Retained outcomes

- Spec first: `ceea21d41f9fc6c24b9b0b51be8db37de461df9a`.
- Real unchanged-harness red controls: `de2f1b0aa13cdb8154c4a5a2d123e56ab6697f5b`,
  **2 failed** because both original failed-probe status records lacked output.
- Initial author controls: **3 failed / 12 passed**. The three failures were an
  authored fixture error (`side` placed on result rather than result.run).
  Only the fixture was corrected; these receipts remain retained.
- Corrected controls: **15 passed** on the recorded working source.
- Final clean committed source: **105 passed**, zero failed/skipped, 11.54s;
  includes those 15 controls and maintained harness/cache/runner/provisioner/
  adapter-audit selections. Do not add these overlapping counts together.
- Whole-tree Ruff, pip check, whitespace and isolated source binding passed.

Every receipt records command, cwd, exact commit/tree, before/after status,
exit, timestamps and log digest. The two baseline failures, the author fixture
failure and all JUnit/logs remain present.

## Boundaries and handoff

These are controlled mocked outcomes, never native acceptance. This worker
ran no downloaded Intel engine or analyzed target. The separately observed
Windows capa exit0 failure and FLOSS exit1 failure are not declared fixed by
this diagnostic patch. Inspect the next exact-source Windows artifact and
retain that actual outcome. Independent source review is still required.

The combined coordinator owns global ledger/QA/todo/index updates. Suggested
entry: LIVE-INTEL-PROBE-EVIDENCE, source complete and author-tested, review and
hosted evidence pending. Existing live-status artifact upload already uses
`if: always()`; do not add duplicate workflow invocations.
