# PR #349: Windows Intel tools advisory disposition

## Observed result

Exact PR head **11f51c105bf63946f59373ae605b937c4fee607a**, tree **4939056ceb0e02b419c820b9e5748c869c40a857**; job checkout **301d21b5da515833cc6e000d9ea5f2e944d67a16**. The local clean publication 43b7b997 has the same tree.

[Windows job 136743396511](https://github.com/djshellshoxxx/PatchTrace/actions/runs/44870397141/job/136743396511) reports GitHub success because the test step uses the existing Windows advisory `continue-on-error`. Its actual pytest result is **2 failed, 1 passed, 1 skipped in 18.96 seconds**:

| Scope | Actual outcome |
| --- | --- |
| capa 9.4.0 | Version probe failed identification despite process exit 0 |
| FLOSS 3.1.1 | Version probe failed; process exit 1 |
| DIE 3.21 | Passed the pinned-tool synthetic-pair golden comparison |
| FLOSS offline control | Blocked/skipped: `unshare -rn` is unavailable on Windows |

The raw job log and job REST record are retained. A green advisory conclusion is not capa/FLOSS native acceptance. Nothing here establishes real-input accuracy.

## Existing format mismatch found

The official pinned [capa source](https://github.com/mandiant/capa/blob/v9.4.0/capa/main.py) and [FLOSS source](https://github.com/mandiant/flare-floss/blob/v3.1.1/floss/main.py) construct their version display with argparse's program name and do not set a fixed `prog` in the inspected parser construction. Windows executable names in PatchTrace's verified asset manifest are `capa.exe` and `floss.exe`.

The actual PatchTrace adapter regex constants require a `capa ` or `floss ` prefix. Controlled, standard-library argparse output for these executable names confirms the exact current regexes accept `capa 9.4.0` / `floss 3.1.1` and reject `capa.exe 9.4.0` / `floss.exe 3.1.1`. This is a confirmed source-format gap; the four text controls are saved in `version-format-controls.json`. They execute no tool binary and do not provide native compatibility evidence.

This gap is consistent with the observed capa exit-0 failure, but the actual probe stdout/stderr were not included in the job output, so it is not a proven causal explanation of that execution. FLOSS's observed exit 1 remains a separate unresolved failure: accepting a suffix cannot convert that result into a successful version probe.

## Baseline attribution

All nine inspected files—workflow, live test, pin manifest, provisioner, capa/FLOSS adapters, shared tool process wrapper, shared engine environment and subprocess implementation—are byte-identical at main `fdc2696c`, PR #348 `6b6fcd35`, and PR #349's complete source tree. See `source-identities.json` for full immutable refs and Git blobs. This is existing source behavior; no new PR #349 application regression is demonstrated. Environment behavior has not been compared with an equivalent baseline Windows execution.

## Required next work

1. Keep the two failed native acceptance records and the offline skip explicit; do not remove or soften their live assertions.
2. Capture bounded raw stdout/stderr, exact exit and actual argument vector for version/help probes on the supported Windows runner. Existing `Execution` objects contain the raw streams, but the generic version failure loses that evidence before the live status report is written. Diagnose FLOSS exit 1 from actual evidence rather than assuming the same cause as capa.
3. A narrow, reviewed format repair can accept only the optional literal `.exe` suffix for the proper tool names, with negative controls for arbitrary prefixes and unchanged version/major/pin gates. Its offline tests must be distinguished from real Windows acceptance.
4. Requalify the exact repaired head on Windows before claiming capa/FLOSS compatibility. Do not infer native acceptance from this read-only investigation or from the Linux leg.

No repository file, branch, workflow or remote state was modified; no analyzed binary, native engine, upstream executable or emulation was run. The publication checkout remained clean.
