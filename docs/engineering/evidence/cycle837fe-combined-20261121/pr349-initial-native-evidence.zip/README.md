# PR349 exact-head qualification refresh

Initial snapshot: **2026-11-21T05:56:09Z**, with PR/main/QA state refreshed unchanged at **2026-11-21T06:00:22Z**. These are observations of PR349 head `11f51c105bf63946f59373ae605b937c4fee607a`, complete tree `4939056ceb0e02b419c820b9e5748c869c40a857`. Main remains `fdc2696c23bdbfe7668348f25e3b336ce33039f7`. The PR is open, non-draft, mergeable, and its mergeable state is `unstable`; this is not merge qualification. The local `43b7b997` tree is identical and clean.

## Workflow state

| Workflow | Observed state | Scope |
| --- | --- | --- |
| [Optional dependency wheels probe](https://github.com/djshellshoxxx/patchtrace/actions/runs/44870397137) | completed / success | 2 observed jobs |
| [Live intel tools acceptance](https://github.com/djshellshoxxx/patchtrace/actions/runs/44870397141) | completed / success | 3 observed jobs |
| [Live BinDiff acceptance](https://github.com/djshellshoxxx/patchtrace/actions/runs/44870397208) | completed / success | 2 observed jobs |
| [Live rizin rz-diff acceptance](https://github.com/djshellshoxxx/patchtrace/actions/runs/44870397216) | completed / success | 2 observed jobs |
| [QA and Windows standalone](https://github.com/djshellshoxxx/patchtrace/actions/runs/44870397228) | in_progress / pending | 8 observed jobs |
| [Native Windows Ghidriff acceptance](https://github.com/djshellshoxxx/patchtrace/actions/runs/44870397150) | completed / success | 5 observed jobs |
| [Corpus Tier R (sharded)](https://github.com/djshellshoxxx/patchtrace/actions/runs/44870397157) | completed / success | 6 observed jobs |

Full Windows and Linux QA are still executing pytest. Their Ruff/build/frozen/installer steps have not completed. Two Ubuntu Qt jobs have succeeded; the remaining two Ubuntu shards and Windows Qt job are running. The Linux package and two Ubuntu frozen-CLI jobs are not yet available in this snapshot. `release-gate` is intentionally skipped. No final full-suite or packaging count is inferred from progress.

## Acceptance established by actual logs

- Native Windows Ghidriff: all five jobs report success. The raw-cache-hit job's actual log records a byte-identical cache hit with SHA-256 prefix `e01c4a21f9c2f701` and one identical match. Platform-specific skipped sibling steps are retained in raw REST data.
- BinDiff: the Windows and Linux live acceptance selections each report **1 passed**. Linux provisioning retains its existing trust-on-first-use/independent-verification limitation; job success does not close that provenance gate.
- Rizin: Windows and Linux live output each records `status: passed` with engine `status: ok`.
- Linux Intel tools: **4 passed**. Windows Intel outcomes are different, detailed below.
- Tier R: both shards ran `ENGINES=rz-diff`. Each records six cases and empty failed/blocked lists. A source-only byte-identical zlib case is explicitly skipped rather than fabricated as a discriminating pair.

## CODEX-6 real cache acceptance

[Shard 0](https://github.com/djshellshoxxx/PatchTrace/actions/runs/44870397157/job/136744625274) records a miss for key `rizin-archive-v1-9102249a9f0b6319c5334a2e5cf8d9cc3f2035e1d3def027c41f6a90f647e8cf`, a successful checksum of `rizin-archive/rizin-v0.9.1-static-x86_64.tar.xz`, then a saved cache.

[Shard 1](https://github.com/djshellshoxxx/PatchTrace/actions/runs/44870397157/job/136744625346) restores a real hit on that same key and then records **the original archive checksum OK before use**. The cached original-archive path therefore has actual rizin cache-hit evidence on this exact source, in addition to authored shell fixtures. The Ghidra restore/install path is skipped on both shards because only rz-diff was selected; this run supplies no Ghidra archive-path acceptance.

## Windows Intel advisory hold

The Windows Intel job is marked successful, but its actual tests record **2 failed, 1 passed, 1 skipped**. capa and FLOSS version identification fail; DIE 3.21 succeeds. Offline FLOSS is skipped because Windows lacks the `unshare -rn` isolation path. This is not successful Windows capa/FLOSS compatibility. The independent source/log diagnosis is under `intel-advisory/`. Official pinned source plus four actual-regex text controls confirm an existing format gap: `capa.exe` and `floss.exe` version banners are rejected. This is consistent with capa exiting zero but is not a proven explanation of its actual run because the child stdout/stderr were not retained. FLOSS exit 1 is a separate unresolved native failure; accepting a suffix alone cannot repair it. Nine relevant files are identical at main, PR348 and PR349. A narrow optional-literal-`.exe` repair with negative controls and bounded supported-Windows diagnostics is actionable; exit-code, major-version and executable-pin gates must remain strict.

All `src/` blobs and the live-Intel workflow are unchanged from PR348. This rules out a direct modification to those files by PR349; it does not prove that a changing environment or upstream dependency is harmless, or that old sources accepted these exact Windows tools. No newly introduced source regression is asserted without further evidence.

## Evidence and follow-up

`raw-rest.json` retains initial full PR/main/workflow/job snapshots; `final-refresh.json` retains the unchanged 06:00:22Z PR/main/QA state; `logs/` retains eight complete decoded logs. `source-identity.json` records clean local/published tree equality and the empty application/live-Intel diff from PR348. `qualification-summary.json` provides the machine-readable observation set.

Next: qualify the new combined Search/storage/workflow source independently, retain this earlier source's outcomes separately, inspect final full/Qt/package and both-Ubuntu frozen-CLI results, and resolve or explicitly retain the Windows Intel acceptance boundary. Do not transfer these check results to a different tree. No source modification, workflow rerun/dispatch, target-binary execution, or merge was performed by this review.
