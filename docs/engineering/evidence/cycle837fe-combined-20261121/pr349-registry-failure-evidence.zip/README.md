# PR349 Linux full QA failure and scoped registry repair

## Exact hosted failure

[Linux job 136743396804](https://github.com/djshellshoxxx/PatchTrace/actions/runs/44870397228/job/136743396804) ended in failure on PR349 head `11f51c105bf63946f59373ae605b937c4fee607a`, tree `4939056ceb0e02b419c820b9e5748c869c40a857`. Its full decoded log is retained unchanged as `linux-job-136743396804.log`. The earlier qualification snapshots remain intact.

Actual full pytest summary: **1 failed, 24,066 passed, 53 skipped, 4 xfailed, 21 warnings in 2,350.86 seconds**. The only failing node is:

`tests/test_spec_registry.py::test_registry_cites_spec_file_by_path[docs/specs/pages-deployment-control.md]`

The maintained contract walks specification files and requires each exact backticked repository path in `docs/specs/REGISTRY.md`. PR349 adds the Pages deployment-control specification without registering it. This is a confirmed metadata completeness defect. No environment hypothesis or runtime regression is needed to explain it. Later dependent Linux steps did not establish successful build/package qualification.

## Combined-source controls

The registry blob `82acfe3325fa3427713f46cc653a185d38ca76d1` is identical on PR349, combined `3a3c6a687b3acef7ee8b38420b83398f5e2d1dab`, and subsequent combined `4ca982e708685889ac2c6f8bedecf79443e6664c`. The Pages omission remains on those sources.

An initial narrow replay copied immutable combined `3a3c6a68` specification files and the actual maintained registry test to an isolated snapshot. It returned **2 failed, 105 passed in 0.19 seconds**: Pages and the newly added `docs/specs/ci-action-pinning.md` were unregistered. This initial standalone test did not load application conftest; its scope is only the documentation registry contract.

Root then assigned a one-file repair on current combined `4ca982e7`, which also adds `docs/specs/live-intel-probe-diagnostics.md`. A private source-bound environment and the normal repository conftest reproduced **3 failed, 105 passed in 0.50 seconds**, exactly the three unregistered paths. All original failed controls remain retained.

## Implemented repair

Commit **`2a67980cfeb88ad72bf8ad523d2bafc8426e5b7c`**, tree **`2666e72d5efd51600b170cef033103c9947bae3b`**, parent `4ca982e7`, on branch `codex/patchtrace-spec-registry-20261121-837fe` changes only **`docs/specs/REGISTRY.md`** (10 inserted lines).

It registers all three specifications with unique proposed nonnumeric aliases, following the existing registry's path-first/provisional-alias convention without reusing historical numeric allocations. Each row describes the actual candidate scope and keeps hosted/native/transitive acceptance boundaries explicit. The old main-status tables are not refreshed or relabelled.

The unchanged maintained registry selection with normal conftest now reports **108 passed in 0.58 seconds**. Isolated Python import binding points to the owned worktree; the checkout is clean; patch whitespace passes; the registry test blob is unchanged. No application source or test contract was modified. Root will independently inspect this one-file diff and replay it in the final combined selection; this local result does not retroactively turn the original hosted run green.

## Evidence and handoff

`source-identities.json` records exact trees, registry/spec/test blobs and path-presence controls. `registry-reproduction.{json,log}` retains the first immutable-source replay. `registry-author-baseline.{json,log}` and `registry-author-final.{json,log}` retain source-bound normal-conftest outcomes. `registry-repair.patch` retains the exact committed diff and parent identity. The full Linux log and job metadata remain unchanged.

The one-file ownership is released to root for integration. No full suite was repeated, no workflow was retried or dispatched, no remote state was changed, and no native engine or target binary was executed. The initial copied reproduction checkout is an intermediate derived from immutable Git and is excluded from the compact evidence archive.
