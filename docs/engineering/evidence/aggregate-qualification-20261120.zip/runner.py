"""Run the repository-mandated unsplit suite against one isolated, immutable checkout."""
from __future__ import annotations

import hashlib
import importlib.metadata
import json
import os
import platform
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

root = Path(sys.argv[1]).resolve()
out = Path(sys.argv[2]).resolve()
out.mkdir(parents=True, exist_ok=False)

def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()

def utc() -> str:
    return datetime.now(timezone.utc).isoformat()

head = git('rev-parse', 'HEAD')
tree = git('rev-parse', 'HEAD^{tree}')
status = git('status', '--porcelain')
if status:
    raise RuntimeError('Qualification checkout must start clean: '+status)
env = os.environ.copy()
env.update(QT_QPA_PLATFORM='offscreen', PYTHONPATH=str(root/'src'))
command = [sys.executable, '-m', 'pytest', '-q', '--junitxml='+str(out/'qa-results.xml'), '--durations=20']
record = {
    'source_head': head, 'source_tree': tree, 'checkout': str(root),
    'command': command, 'started_at': utc(), 'status': 'running',
    'python': sys.version, 'platform': platform.platform(), 'machine': platform.machine(),
    'processor_count': os.cpu_count(),
    'environment': {key: env.get(key) for key in ('QT_QPA_PLATFORM','PYTHONPATH','PYTHONHASHSEED','OMP_NUM_THREADS','OPENBLAS_NUM_THREADS')},
    'packages': {dist.metadata['Name']: dist.version for dist in importlib.metadata.distributions()},
}
(out/'receipt.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
started = time.monotonic()
with (out/'pytest.log').open('w', encoding='utf-8') as log:
    result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
record.update(status='completed', exit_code=result.returncode, ended_at=utc(),
              elapsed_seconds=round(time.monotonic()-started,3),
              source_head_after=git('rev-parse','HEAD'), source_tree_after=git('rev-parse','HEAD^{tree}'),
              final_worktree_status=git('status','--porcelain'))
record['files'] = {p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
                   for p in out.iterdir() if p.name != 'receipt.json' and p.is_file()}
(out/'receipt.json').write_text(json.dumps(record,indent=2,sort_keys=True)+'\n')
print(json.dumps({key:record[key] for key in ('source_head','status','exit_code','elapsed_seconds','ended_at','final_worktree_status')},indent=2))
raise SystemExit(result.returncode)
