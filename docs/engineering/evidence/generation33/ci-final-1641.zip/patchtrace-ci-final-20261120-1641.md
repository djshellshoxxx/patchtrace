# Final read-only PatchTrace CI snapshot

Observed **2026-11-20 16:41:21 UTC**. States were read without waiting for active work.

## Published source identity

[PR342](https://github.com/djshellshoxxx/patchtrace/pull/342) remains draft at `5cc3f2a540f2e49e8b86e20decf7d4f62ce89d0a`, base `6c8b33b851a22fb16d39b31693922359cd34ad12`, proposed merge `7628fd5e6ce8d5472e2723ab4ff4e50b297b5947`. These identities are unchanged from the previous snapshot; the previously verified head/merge tree is `559c18105a2a79960811f4f6f2c011c0bf15cc7c`.

The coordinator's later local `71b535cc` destination-guard work is **not** the published source represented here. Its separately reported 493 passes, one native Windows skip, Ruff and whitespace checks do not become hosted acceptance through this snapshot.

## New concrete failure

[Push-native workflow44770501981](https://github.com/djshellshoxxx/patchtrace/actions/runs/44770501981) finished **failure**: four legs succeeded, but [raw-cache-hit job136406567877](https://github.com/djshellshoxxx/patchtrace/actions/runs/44770501981/job/136406567877) failed at `tools/live_cache_check.py:37`:

```text
AssertionError: second run was not a cache hit; java=unverified
Process completed with exit code 1.
```

The failed log verifies checkout `5cc3f2a540f2e49e8b86e20decf7d4f62ce89d0a`. The first comparison's Java identity was unverified. The source already retries an initial Java probe timeout once, using 15-second then 30-second bounds. Other probe/parse failures also produce unknown. Unknown runtime identity deliberately prevents raw-cache admission. The log does not expose the probe result, so a timeout, host-load or parsing cause is **not established**.

The PR-event [raw-cache-hit counterpart136407264141](https://github.com/djshellshoxxx/patchtrace/actions/runs/44770702812/job/136407264141) succeeded at16:32:40UTC. Preserve both results; the successful counterpart does not resolve the failed acceptance result.

A diagnosability gap is visible: the harness creates its two projects in `TemporaryDirectory`, whose cleanup runs on the assertion. The uploader searches `live-project/runs/` and `live-project/project.sqlite3` and reported **no artifacts**. A useful bounded follow-up is to retain first/second run and Java-probe diagnostics under a declared artifact directory on failure, without weakening version admission or the cache-hit assertion.

## Other initial-head gates

| Workflow | Observed outcome |
| --- | --- |
| [QA44770702902](https://github.com/djshellshoxxx/patchtrace/actions/runs/44770702902) | Both full QA jobs running; three Qt jobs running and two queued; release gate skipped |
| [PR-native44770702812](https://github.com/djshellshoxxx/patchtrace/actions/runs/44770702812) | Clean and raw-cache legs succeeded; seeded-store running; two legs queued |
| [Live intel44770702749](https://github.com/djshellshoxxx/patchtrace/actions/runs/44770702749) | Workflow success: Linux and Windows tool jobs succeeded, live-build environment skipped |

No combined acceptance claim follows while these gates remain incomplete or failed.

## Generation 29 predecessor

[PR340 run44763480171](https://github.com/djshellshoxxx/patchtrace/actions/runs/44763480171) now has **both full QA jobs and all five Qt jobs successful**. Linux package job136419440706 is queued; smoke has not started. Release gate is skipped. Main packaging's earlier apt failure remains separate historical evidence.

## Next blocker and evidence

Diagnose the retained failed initial-head raw-cache gate, finish the still-active initial-source gates, and qualify the later local source separately after publication. No failure cause or success is inferred from queued state.

Compact per-job records are in `patchtrace-ci-final-20261120-1641.json`. The newly failed decoded log is retained as `patchtrace-pr342-native-cache-failure-20261120-1630.log`, normalized to LF. Earlier completed logs were not downloaded again. No workflows, remote refs, worktrees or commits were changed.

