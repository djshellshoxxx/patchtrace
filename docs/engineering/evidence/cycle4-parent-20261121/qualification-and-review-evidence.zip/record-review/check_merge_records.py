#!/usr/bin/env python3
"""Read-only frozen Git-object record audit; no project tests or imports."""
import collections
import datetime
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

REPO = Path('/workspace/scratch/patchtrace-95fe-c4/coordinator')
OUT = Path(__file__).resolve().parent
RECEIPTS = OUT.parent / 'parent-upgrade-evidence'
REFS = dict(base='11f51c105bf63946f59373ae605b937c4fee607a', c4='a76189cc0e7ec4312baf3662da5946d39bdd019c', parent='daee337c48c63dda8aeac149c407e900c79dcc86', merge='e7391634a46bbb1f9f1fdc3563abadb837d1b45b', final='111803d54cfebc1b779f4832a069904b3ee91a7c')
FAILURES = []

def check(ok, label):
    if not ok:
        FAILURES.append(label)
    return bool(ok)

def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)

def blob(side, path):
    return git('show', REFS[side] + ':' + path)

def digest(data):
    return dict(size=len(data), sha256=hashlib.sha256(data).hexdigest())

def canonical_digest(obj):
    return digest(json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode())['sha256']

def tree(side, path):
    result = {}
    for line in git('ls-tree', '-r', '-z', REFS[side], '--', path).split(b'\0'):
        if line:
            head, name = line.split(b'\t', 1)
            mode, kind, oid = head.decode().split()
            result[name.decode()] = dict(mode=mode, kind=kind, git_blob=oid)
    return result

metadata = {}
for side, ref in REFS.items():
    fields = git('show', '-s', '--format=%H %T %P', ref).decode().split()
    metadata[side] = dict(commit=fields[0], tree=fields[1], parents=fields[2:])
check(metadata['merge']['parents'] == [REFS['c4'], REFS['parent']], 'ordered merge parents')
check(metadata['final']['parents'] == [REFS['merge']], 'registry-only parent')
check(metadata['final']['tree'] == 'd3264bf26f83d039fa212c26b47c094f86691c3f', 'final tree')
check(git('merge-base', REFS['c4'], REFS['parent']).decode().strip() == REFS['base'], 'three-way base')

lp = 'docs/engineering/task-ledger.json'
ledgers = {side: json.loads(blob(side, lp)) for side in REFS}
parent, c4, final = (ledgers[s] for s in ['parent', 'c4', 'final'])
suffix = c4['tasks'][len(ledgers['base']['tasks']):]
ids = [t['id'] for t in final['tasks']]
fields = {k: parent[k] == final.get(k) for k in parent if k not in {'updated_at', 'tasks'}}
ledger = dict(
    counts={s: len(v['tasks']) for s, v in ledgers.items()},
    parent_prefix=check(len(parent['tasks']) == 90 and final['tasks'][:90] == parent['tasks'], 'parent 90 task prefix'),
    c4_suffix=check(len(suffix) == 3 and final['tasks'][90:] == suffix, 'C4 three-task suffix'),
    unique_ids=check(len(ids) == len(set(ids)) == 93, '93 unique task IDs'),
    parent_nonmetadata_fields=fields,
    all_parent_nonmetadata_fields=check(all(fields.values()), 'parent nonmetadata fields'),
    added_fields=sorted(set(final)-set(parent)),
    c4_parallel_field=check(c4['parallel_followup_cycle4'] == final.get('parallel_followup_cycle4'), 'C4 parallel field'),
    merge_to_final_identical=check(blob('merge', lp) == blob('final', lp), 'ledger unchanged after merge'),
    updated_at={s: v['updated_at'] for s, v in ledgers.items()},
    tasks=[dict(index=i, id=t['id'], canonical_sha256=canonical_digest(t), source='parent' if i<90 else 'c4') for i,t in enumerate(final['tasks'])],
    blobs={s: digest(blob(s,lp)) for s in REFS},
)
check(ledger['added_fields'] == ['parallel_followup_cycle4'], 'only additive C4 field')

paths = ['docs/engineering/' + n + '.md' for n in ['AUDIT_FINDINGS', 'BRANCH_INVENTORY', 'CONSOLIDATION_LEDGER', 'FEATURE_MATRIX', 'INTEGRATION_QUEUE', 'WORKER_HANDOFF']]
paths += ['docs/qa.md', 'tasks/todo.md', 'docs/engineering/release-readiness-20261119.md']
histories = []
for path in paths:
    data = {s: blob(s,path) for s in ['base','c4','parent','final']}
    lines = {s: v.splitlines(keepends=True) for s,v in data.items()}
    changes, other = [], []
    for side in ['c4','parent']:
        for op,a,b,c,d in difflib.SequenceMatcher(None,lines['base'],lines[side],autojunk=False).get_opcodes():
            if op == 'equal':
                continue
            if op != 'insert':
                other.append([side,op,a,b,c,d])
                continue
            raw = b''.join(lines[side][c:d])
            changes.append(dict(source=side, base_offset=a, added_lines=d-c, raw=raw, occurrences=data['final'].count(raw), **digest(raw)))
    rebuilt = []
    for i in range(len(lines['base'])+1):
        rebuilt.extend(x['raw'] for x in changes if x['base_offset'] == i)
        if i < len(lines['base']):
            rebuilt.append(lines['base'][i])
    exact = check(b''.join(rebuilt) == data['final'], path + ': exact three-way union')
    check(not other, path + ': insertion-only branches')
    check(all(x['occurrences'] == 1 for x in changes), path + ': additions occur exactly once')
    histories.append(dict(path=path, exact_three_way_union=exact, noninsertions=other, line_counts={s:len(v) for s,v in lines.items()}, blobs={s:digest(v) for s,v in data.items()}, insertions=[{k:v for k,v in x.items() if k!='raw'} for x in changes]))

preserved_documents = []
for path in ['docs/engineering/feature-status-20261119.json','docs/engineering/cycle4-consolidation-20261121-95fe.md','docs/engineering-handoffs/cycle4-20261121-95fe.md']:
    raw = blob('final',path)
    preserved_documents.append(dict(path=path, exact=check(blob('c4',path)==raw,path+': C4 preserved'), **digest(raw)))

parent_tree = tree('parent','docs/engineering/evidence')
c4_tree = tree('c4','docs/engineering/evidence/cycle4-95fe')
final_tree = tree('final','docs/engineering/evidence')
union = {**parent_tree, **c4_tree}
check(not set(parent_tree)&set(c4_tree), 'disjoint parent and C4 evidence namespaces')
exact_union = check(final_tree==union, 'entire evidence tree is exact union')
files = []
for path, entry in sorted(union.items()):
    side = 'c4' if path in c4_tree else 'parent'
    old, new = blob(side,path), blob('final',path)
    files.append(dict(path=path, source=side, exact_bytes=check(old==new,path+': sealed bytes'), **entry, **digest(new)))
evidence = dict(parent_files=len(parent_tree), c4_files=len(c4_tree), final_files=len(final_tree), exact_union=exact_union, files=files)

space_paths = {'docs/engineering/evidence/cycle4-95fe/source-bundle-verification.txt':'c4','docs/engineering/evidence/cycle837fe-20261121/source-history-verification.txt':'parent'}
space_files = []
for path, side in space_paths.items():
    raw = blob('final',path)
    space_files.append(dict(path=path, source=REFS[side], exact_bytes=check(raw==blob(side,path),path+': raw receipt preserved'), trailing_space_lines=[i+1 for i,line in enumerate(raw.splitlines()) if line.endswith((b' ',b'\t'))], **digest(raw)))
whitespace = {}
for name, extra in [('all',[]),('excluding-sealed-receipts',['--','.',*[':(exclude)'+p for p in space_paths]])]:
    proc = subprocess.run(['git','diff','--check',REFS['base'],REFS['final'],*extra],cwd=REPO,capture_output=True)
    (OUT/('whitespace-'+name+'.log')).write_bytes(proc.stdout+proc.stderr)
    whitespace[name] = dict(returncode=proc.returncode, output=(proc.stdout+proc.stderr).decode())
check(whitespace['excluding-sealed-receipts']['returncode']==0 and not whitespace['excluding-sealed-receipts']['output'], 'all other paths whitespace clean')
reported = {s.split(':',1)[0] for s in whitespace['all']['output'].splitlines() if ': trailing whitespace.' in s}
check(whitespace['all']['returncode']==2 and reported==set(space_paths), 'only two raw receipt whitespace findings')

changed = git('diff','--name-only',REFS['merge'],REFS['final']).decode().splitlines()
check(changed==['docs/specs/REGISTRY.md'], 'only registry changed after merge')
check(blob('final','docs/specs/REGISTRY.md').startswith(blob('merge','docs/specs/REGISTRY.md')), 'registry prior history exact prefix')
(OUT/'registry-only.diff').write_bytes(git('diff',REFS['merge'],REFS['final']))
test_blobs = {s:git('rev-parse',REFS[s]+':tests/test_spec_registry.py').decode().strip() for s in ['parent','merge','final']}
check(len(set(test_blobs.values()))==1,'registry test blob unchanged')
recorded = {}
for stem, side in [('registry-before-clean','merge'),('combined-after','final')]:
    rawj, rawx = ((RECEIPTS/(stem+ext)).read_bytes() for ext in ['.json','.xml'])
    receipt = json.loads(rawj)
    cases = []
    for case in ET.fromstring(rawx).iter('testcase'):
        if case.get('classname') != 'tests.test_spec_registry':
            continue
        status = next((kind for kind in ['failure','error','skipped'] if case.find(kind) is not None),'passed')
        cases.append(dict(id=case.get('classname')+'::'+case.get('name'), status=status))
    clean = receipt.get('head')==receipt.get('head_after')==REFS[side] and receipt.get('tree')==metadata[side]['tree'] and receipt.get('dirty_before')==receipt.get('dirty_after')==''
    check(clean,stem+': clean frozen source binding')
    recorded[stem] = dict(path_prefix=str(RECEIPTS/stem), json_digest=digest(rawj), xml_digest=digest(rawx), head=receipt['head'], tree=receipt['tree'], clean_binding=clean, returncode=receipt['returncode'], cases=cases, outcomes=dict(collections.Counter(c['status'] for c in cases)))
before, after = (recorded[s] for s in ['registry-before-clean','combined-after'])
check(before['outcomes']=={'passed':108,'failure':2} and before['returncode']==1,'recorded 108 pass/2 fail baseline')
check(after['outcomes']=={'passed':110} and after['returncode']==0,'recorded 110 pass registry subset')
check({c['id'] for c in before['cases']}=={c['id'] for c in after['cases']},'same 110 registry identities')
check({c['id'] for c in before['cases'] if c['status']=='failure'}=={'tests.test_spec_registry::test_registry_cites_spec_file_by_path[docs/specs/'+p+']' for p in ['buildenv-header-help.md','pages-build-isolation-and-hashes.md']},'exact two missing C4 registrations')

result = dict(status='FAIL' if FAILURES else 'PASS', failures=FAILURES, recorded_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), scope='Read-only frozen Git-object comparisons and existing local receipts. No repository tests, imports, remote operations, or checkout mutations.', git=metadata, ledger=ledger, markdown_histories=histories, preserved_c4_documents=preserved_documents, sealed_evidence=evidence, raw_receipt_whitespace=dict(files=space_files,checks=whitespace), registry=dict(changed_paths=changed,test_blobs=test_blobs,recorded_results=recorded), coordinator_merge_resolution=dict(path=str(RECEIPTS/'merge-resolution.json'),**digest((RECEIPTS/'merge-resolution.json').read_bytes())))
(OUT/'controls.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n')
print(json.dumps(dict(status=result['status'],failures=FAILURES,ledger_counts=ledger['counts'],histories=len(histories),parent_evidence=len(parent_tree),c4_evidence=len(c4_tree),final_evidence=len(final_tree),registry_before=before['outcomes'],registry_after=after['outcomes']),indent=2))
raise SystemExit(bool(FAILURES))
