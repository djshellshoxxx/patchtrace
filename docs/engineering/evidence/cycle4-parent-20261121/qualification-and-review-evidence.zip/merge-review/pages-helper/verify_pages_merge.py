"""Read-only, exact-commit Pages merge preservation review."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import re
import subprocess

REPO = Path('/workspace/scratch/patchtrace-95fe-c4/coordinator')
OUT = Path(__file__).resolve().parent
SOURCE = '111803d54cfebc1b779f4832a069904b3ee91a7c'
PARENT = 'daee337c48c63dda8aeac149c407e900c79dcc86'
PRIOR = 'a76189cc0e7ec4312baf3662da5946d39bdd019c'
MERGE = 'e7391634a46bbb1f9f1fdc3563abadb837d1b45b'

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

def blob(ref, path):
    return git('show', f'{ref}:{path}')

def text(ref, path):
    return blob(ref, path).decode()

def transform_once(value, replacements):
    for before, after in replacements:
        assert value.count(before) == 1, before
        value = value.replace(before, after)
    return value

workflow = '.github/workflows/pages.yml'
reviewed = text(SOURCE, workflow)
parent_workflow = text(PARENT, workflow)
commands = [
    ('python -m pip install --only-binary=:all: -r tools/site/requirements.txt pytest',
     'python -m pip install --require-hashes --only-binary=:all: -r tools/site/requirements-ci.lock'),
    ('python -m pytest -q tests/test_site_*.py',
     'python -m pytest --noconftest --disable-plugin-autoload -q tests/test_site_*.py'),
]
assert transform_once(parent_workflow, commands) == reviewed
uses = re.findall(r'^\s*(?:- )?uses: (\S+)\s+# (\S+)\s*$', reviewed, re.M)
parent_uses = re.findall(r'^\s*(?:- )?uses: (\S+)\s+# (\S+)\s*$', parent_workflow, re.M)
assert uses == parent_uses and len(uses) == 5
assert all(re.fullmatch(r'[\w./-]+@[0-9a-f]{40}', action) for action, version in uses)
changed_workflows = git('diff', '--name-only', PARENT, SOURCE, '--', '.github/workflows').decode().splitlines()
assert changed_workflows == [workflow]

test_file = 'tests/test_site_workflow.py'
expected_test = transform_once(text(PARENT, test_file), [
    commands[1],
    ("assert 'tools/site/requirements.txt' in TEXT", "assert 'tools/site/requirements-ci.lock' in TEXT"),
])
assert expected_test == text(SOURCE, test_file)

preserved_paths = [
    'tools/site/requirements-ci.lock',
    'tools/site/requirements.txt',
    'site/README.md',
    'docs/specs/pages-build-isolation-and-hashes.md',
    'tests/test_site_dependency_lock.py',
]
preserved = {}
for path in preserved_paths:
    value = blob(SOURCE, path)
    assert value == blob(PRIOR, path), path
    preserved[path] = {'bytes': len(value), 'sha256': hashlib.sha256(value).hexdigest(),
                       'identical_to_prior_c4': True}
for path in ['tests/conftest.py', 'pyproject.toml', 'tools/site/requirements.txt']:
    assert blob(SOURCE, path) == blob(PARENT, path), path

registry_path = 'docs/specs/REGISTRY.md'
registry = text(SOURCE, registry_path)
parent_registry = text(PARENT, registry_path)
assert registry.startswith(parent_registry)
assert text(MERGE, registry_path) == parent_registry
spec_paths = ['docs/specs/buildenv-header-help.md', 'docs/specs/pages-build-isolation-and-hashes.md']
for path in spec_paths:
    assert registry.count(f'`{path}`') == 1
assert len(registry[len(parent_registry):].splitlines()) == 9
assert git('diff', '--name-only', MERGE, SOURCE).decode().splitlines() == [registry_path]

result = {
    'schema': 'patchtrace-pages-merge-review/1',
    'recorded_at_utc': datetime.now(timezone.utc).isoformat(),
    'source_commit': SOURCE,
    'source_tree': git('rev-parse', f'{SOURCE}^{{tree}}').decode().strip(),
    'parent_commit': PARENT,
    'prior_c4_commit': PRIOR,
    'merge_commit': MERGE,
    'checks': {
        'workflow_is_parent_plus_exact_two_command_substitutions': True,
        'all_other_workflow_bytes_preserved': True,
        'all_other_workflow_files_preserved': True,
        'five_parent_action_pins_and_release_comments_preserved': True,
        'workflow_test_is_parent_plus_exact_two_expected_command_assertions': True,
        'shared_application_conftest_and_pyproject_preserved': True,
        'parent_registry_is_exact_prefix': True,
        'new_spec_citations_each_exactly_once': True,
        'registration_commit_changes_only_registry': True,
    },
    'action_references': [{'reference': action, 'version_comment': version} for action, version in uses],
    'prior_c4_byte_identity': preserved,
    'findings': [],
    'scope': 'Static exact-commit merge preservation. No pytest, live index installation, GitHub workflow execution or deployment performed.',
}
(OUT / 'pages-merge-review.json').write_text(json.dumps(result, indent=2) + '\n')
(OUT / 'pages-merge-review.md').write_text(f'''# Pages merge preservation review

Result: **passed; zero findings** in `{SOURCE}` (tree `{result['source_tree']}`).

Compared with published parent `{PARENT}` and prior C4 `{PRIOR}`:

- The entire Pages workflow equals the parent bytes after exactly two substitutions: the hash-locked install command and isolated full site-test command. All five full Action commit pins and release comments, triggers, permissions, concurrency, deployment condition, environment, artifact path and job dependencies remain intact. Every other workflow file is unchanged from the parent.
- `tests/test_site_workflow.py` equals the parent after exactly the two corresponding expectation changes. The parent's immutable-Action assertions and upload-artifact source check are retained.
- The lock, portable declarations, site README, isolation/hash specification and dependency-lock tests are byte-identical to prior reviewed C4. The shared application conftest and pyproject are byte-identical to the parent.
- The complete parent registry text is an exact prefix. Both new specifications are cited exactly once in nine added lines. Commit `{SOURCE}` changes only the registry from merged source `{MERGE}`.

These are independent static/source checks, **not additional pytest passes**. They do not establish hosted index installation, native GUI acceptance, or Pages deployment. No repository mutation or network request was performed.

Reproducible checker: `verify_pages_merge.py`; machine-readable source binding and hashes: `pages-merge-review.json`.
''')
manifest = []
for path in sorted(OUT.iterdir()):
    if path.name == 'manifest.json' or not path.is_file():
        continue
    value = path.read_bytes()
    manifest.append({'path': path.name, 'bytes': len(value), 'sha256': hashlib.sha256(value).hexdigest()})
(OUT / 'manifest.json').write_text(json.dumps({'payloads': manifest}, indent=2) + '\n')
print(json.dumps(result, indent=2))
