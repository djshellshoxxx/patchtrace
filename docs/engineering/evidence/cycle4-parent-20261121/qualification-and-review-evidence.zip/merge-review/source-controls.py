"""Read-only exact-source controls for the bounded C4 parent merge review."""
from pathlib import Path
import hashlib,json,subprocess
REPO=Path('/workspace/scratch/patchtrace-95fe-c4/parent-merge-review')
OUT=Path(__file__).parent
BASE='11f51c105bf63946f59373ae605b937c4fee607a'
PRIOR='a76189cc0e7ec4312baf3662da5946d39bdd019c'
PARENT='daee337c48c63dda8aeac149c407e900c79dcc86'
SOURCE='111803d54cfebc1b779f4832a069904b3ee91a7c'
MERGE='e7391634a46bbb1f9f1fdc3563abadb837d1b45b'
def git(*args):
 return subprocess.check_output(['git','-C',str(REPO),*args])
def blob(rev,path):
 return git('show',f'{rev}:{path}')
def tree(rev):
 result={}
 for entry in git('ls-tree','-rz','--full-tree',rev).split(b'\0'):
  if entry:
   metadata,path=entry.split(b'\t',1)
   mode,kind,sha=metadata.decode().split()
   result[path.decode()]={'mode':mode,'kind':kind,'sha':sha}
 return result
assert git('rev-parse','HEAD').decode().strip()==SOURCE
assert not git('status','--porcelain').strip()
parent_tree=tree(PARENT)
source_tree=tree(SOURCE)
changes={p for p in parent_tree.keys()|source_tree.keys() if parent_tree.get(p)!=source_tree.get(p)}
production_changes=sorted(p for p in changes if p.startswith('src/'))
assert production_changes==['src/patchtrace/buildenv/panel_model.py','src/patchtrace/buildenv/tooltip_entries.py']
prior_tree=tree(PRIOR)
base_tree=tree(BASE)
prior_code_changes={p for p in prior_tree.keys()|base_tree.keys() if prior_tree.get(p)!=base_tree.get(p) and p.startswith(('src/','tests/','tools/','.github/'))}
combined_paths={'.github/workflows/pages.yml','tests/test_site_workflow.py','tests/test_tooltips.py'}
unchanged_c4=sorted(prior_code_changes-combined_paths)
assert all(prior_tree[p]==source_tree[p] for p in unchanged_c4)
tooltip_path='tests/test_tooltips.py'
merged_audit=blob(SOURCE,tooltip_path).decode()
addition="    # Build environment also prepares its columns on the real project hook.\n    assert window.panels.show_panel('build_env') is not None\n    assert window.panels.controller('build_env').table.horizontalHeader().count() == 5\n"
assert merged_audit.count(addition)==1
assert merged_audit.replace(addition,'')==blob(PARENT,tooltip_path).decode()
assert "assert window.panels.controller('search').panel.table.horizontalHeader().count() == 6" in merged_audit
assert "assert window.panels.controller('strings').panel.table.horizontalHeader().count() == 8" in merged_audit
assert blob(SOURCE,'src/patchtrace/tooltips.py')==blob(PARENT,'src/patchtrace/tooltips.py')
assert git('diff','--name-only',MERGE,SOURCE).decode().splitlines()==['docs/specs/REGISTRY.md']
parent_ledger=json.loads(blob(PARENT,'docs/engineering/task-ledger.json'))
source_ledger=json.loads(blob(SOURCE,'docs/engineering/task-ledger.json'))
assert source_ledger['tasks'][:len(parent_ledger['tasks'])]==parent_ledger['tasks']
assert len(source_ledger['tasks'])==len(parent_ledger['tasks'])+3
assert all(source_ledger[k]==v for k,v in parent_ledger.items() if k not in ('updated_at','tasks'))
assert not source_ledger['main_merge_eligible'] and not source_ledger['release_ready']
result={'source':SOURCE,'source_tree':git('rev-parse',SOURCE+'^{tree}').decode().strip(),'parent':PARENT,'prior_c4':PRIOR,'merge':MERGE,'clean_source':True,'parent_production_files':sum(p.startswith('src/') for p in parent_tree),'production_changed_paths':production_changes,'all_other_parent_production_blobs_preserved':True,'prior_c4_code_changed_paths':sorted(prior_code_changes),'prior_c4_code_paths_preserved_exactly':unchanged_c4,'shared_paths_reviewed_separately':sorted(combined_paths),'global_audit_parent_preserved_plus_only_buildenv_activation':True,'registered_header_counts':{'strings':8,'search':6,'build_env':5},'tooltip_registry_implementation_unchanged':True,'registry_commit_only_changes_registry':True,'ledger_parent_tasks_preserved':len(parent_ledger['tasks']),'ledger_total_tasks':len(source_ledger['tasks']),'ledger_other_parent_fields_preserved':True,'holds_remain_false':True,'read_blobs_sha256':{p:hashlib.sha256(blob(SOURCE,p)).hexdigest() for p in sorted(prior_code_changes)}}
(OUT/'source-controls.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
