"""Run the unchanged real-host registry audit with at most one in-memory mutation."""
import dataclasses,sys
import pytest
mode=sys.argv[1]
xml=sys.argv[2]
if mode=='missing-buildenv-basis':
 from patchtrace.buildenv import qt_panel as panel
 target='build_env.col.basis'
elif mode=='missing-search-why':
 from patchtrace.search import qt_panel as panel
 target='search.col.why'
else:
 assert mode=='positive'
 panel=None
 target=None
if panel is not None:
 assert sum(column.tip_id==target for column in panel.COLUMNS)==1
 panel.COLUMNS=tuple(dataclasses.replace(column,tip_id='') if column.tip_id==target else column for column in panel.COLUMNS)
print(f'CONTROL mode={mode} removed_mapping={target}')
raise SystemExit(pytest.main(['-q','tests/test_tooltips.py::test_every_registry_id_is_applied_somewhere','--junitxml='+xml]))
