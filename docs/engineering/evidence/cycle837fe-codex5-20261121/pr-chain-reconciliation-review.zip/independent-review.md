# Independent premerge PR-chain metadata review

**Recommendation:** after an actual qualified PR349 main merge and a fresh exact-head check, close the still-open PR345, PR346, PR347 and PR348 drafts as consolidated. No specific unaccounted compatible PR346 contribution was identified in the bounded existing accounting. There is no present instruction to close anything before that merge.

## Exact reviewed identities

The supplied PR snapshot was observed at **2026-11-21 08:59:00 UTC**. All four PRs are open, draft and unmerged. Their bases are old feature branches. The reviewed primary is `ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e`, tree `c3f09435deb99ca0ddb3406e27ab315dba7740cf`; the clean local `06ea27de0936f1f8eb1aeca264833c21845a7f36` checkout has the same complete tree.

| PR | Exact head | Recorded base | Basis for later metadata closure |
| --- | --- | --- | --- |
| 345 | `39c38a02f126963fc03827fa49741255590227ad` | g41 `67f7e08ea9bee61653f8ab5ad66048d3e7141810` | Exact head is an ancestor of reviewed PR349 |
| 346 | `c07774ecf5a3f7337834f95a9a4c51c8ec5fad44` | g41 `67f7e08ea9bee61653f8ab5ad66048d3e7141810` | Reviewed compatible contributions selectively recovered; original documentation and evidence retained |
| 347 | `b461ac64eb9beb74449ce2b18b6795a2af34a02a` | PR345 `39c38a02f126963fc03827fa49741255590227ad` | Exact head is an ancestor of reviewed PR349 |
| 348 | `6b6fcd3597a604212032ffc453477aeb6edc69ff` | PR347 `b461ac64eb9beb74449ce2b18b6795a2af34a02a` | Exact head is an ancestor of reviewed PR349 |

An open draft's `merge_commit_sha` is not evidence that the PR was merged: every supplied record has `merged: false` and `merged_at: null`.

## PR346 accounting

The authoritative sibling handoff, historical ledger object and Cycle2 report agree on the accepted scope. Five named donor file blobs were recovered exactly into PR347: candidate-admission implementation and regression tests, inventory replay implementation and tests, and the Qt investigation tests. Candidate and Qt blobs remain exact through reviewed PR349. Inventory subsequently received the independently reviewed validation improvements recorded in Cycle2; PR348 and PR349 share those later tool/test blobs. The two shared table/help implementation blobs are identical across all five reviewed heads.

The recorded selective test recovery also includes the two form-feed CSV/JSON controls. PR345's newer report/TaskRunner work, Linux force-replacement refusal and additional Evidence/help tests were intentionally retained. The sibling handoff explicitly rejects overwriting the refusal tests with the old donor's Linux overwrite expectation. This review used that completed source audit rather than repeating it.

There are **13 PR346-side-only commits absent from PR349 ancestry**. They include documentation commits and merge commits; calling them “13 source-code commits” is inaccurate. Their identities are retained in the machine report. Closing the PR as consolidated does not convert them into ancestors or justify deleting the branch.

All **20** paths in the Cycle3 document-recovery manifest were absent at PR348. Each original donor and recovery-commit blob matches the recorded Git blob, byte count and SHA-256. In reviewed PR349, **14 are still byte-identical**. The **six current indexes contain additions only**, with every original line retained in order. This preserves the original qualification, semantic-review records, raw evidence archive, commit mapping and code-history bundle while allowing current status additions.

No specific missing compatible contribution was found in this bounded accounting. Do not describe this result as a new whole-branch semantic audit or blanket PR346 ancestry/supersession finding.

## Safe coordinator action after main promotion

Verify PR349's actual merged state, merge commit and current-main ancestry; refresh each historical PR head/base/state. If the head remains the reviewed identity, add its prepared factual reconciliation comment and close it if still open. For #345/#347/#348, confirm the refreshed head is in actual main ancestry. For #346, retain the selective-recovery explanation and evidence links.

Preserve original PR bodies, bases, branches, commit histories and failures. Do not retarget or separately merge these old feature-base PRs merely to obtain a GitHub merged flag. If any refreshed head has new work or a specific unaccounted contribution is discovered, keep that affected PR open for separate accounting.

The original NSIS503/retry and interrupted local runs remain separate evidence. Later successful checks do not rewrite them. Metadata reconciliation does not close CODEX-5, native/manual/provenance/L1-L2-L3 acceptance or the historical **181 unmatched / 16 patch-equivalent** backlog.

## Evidence and review boundary

`independent-review.json` contains exact ancestry, per-PR original-body hashes, donor/recovery/current blob identities, all 20 recovery comparisons, the 13 branch-only commit identities, existing-audit source references and action prerequisites. `independent-sources/` preserves the source handoffs/reports, original recovery manifest, prior independent record audit and a clearly labeled ledger excerpt. `recommended-pr-comments.md` contains reviewable comment drafts with an explicit actual-merge placeholder.

No product tests, repeated semantic donor audits, remote requests, source edits, ref mutations, PR mutations or ledger changes were performed. Only this evidence directory was written. The PR snapshot and original bodies remain unchanged. This review is conditional metadata clearance, not a claim that PR349 has already merged.
