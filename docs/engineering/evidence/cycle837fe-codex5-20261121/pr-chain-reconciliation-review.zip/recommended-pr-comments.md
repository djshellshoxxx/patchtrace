# Prepared PR reconciliation comments

These comments are prepared for use **only after an actual qualified PR349 main merge**. Replace `ACTUAL_PR349_MERGE_SHA` with the observed merge commit, verify current main contains that source, and refresh each exact PR head and state immediately before the metadata action. If a head changed, reassess that PR before closing it. Leave the original descriptions, bases, branches and commit histories intact. Do not perform a separate source merge to change a GitHub merged flag.

## PR345 — close as consolidated

Closing this stacked draft as consolidated into main through #349, merged at `ACTUAL_PR349_MERGE_SHA`. The unchanged PR345 head `39c38a02f126963fc03827fa49741255590227ad` is in the resulting main ancestry through the reviewed successor chain #347 → #348 → #349.

The report, TaskRunner lifecycle, publication-refusal and Evidence/help work remains in that chain. This metadata closure preserves the original branch and PR description. The original NSIS feed HTTP503, its later successful retry, and interrupted local runs retain their separate source-specific records; this closure does not rewrite them.

The current engineering ledger remains the authority for unfinished work. No separate merge of this old feature-base PR is needed.

## PR346 — close as consolidated by selective recovery

Closing this stacked draft as consolidated by selective recovery into main through #347 → #348 → #349, with #349 merged at `ACTUAL_PR349_MERGE_SHA`. The reviewed PR346 head remains `c07774ecf5a3f7337834f95a9a4c51c8ec5fad44`.

PR346's head was **not merged as an ancestor of PR349**. Its 13 branch-side-only commits, including documentation and merge commits, remain preserved on the original branch. The [sibling reconciliation](https://github.com/djshellshoxxx/PatchTrace/blob/ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e/docs/engineering-handoffs/sibling-reconciliation-20261120.md) accounts for candidate-admission ordering and its tests, bounded inventory replay and its tests, two Qt diagnostic cases, and the form-feed CSV/JSON controls. Shared GUI work was retained once. Later inventory validation improvements and PR345's Linux force-replacement refusal remain authoritative; the incompatible old donor overwrite expectation was deliberately not substituted.

Cycle3 also recovered the [20 original documentation and evidence files](https://github.com/djshellshoxxx/PatchTrace/blob/ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e/docs/engineering/evidence/cycle3-95fe/document-recovery.json) with their recorded original blobs. Fourteen remain byte-identical in the reviewed PR349 tree; the six current indexes received additions while retaining every original line. Original evidence, failures, source-specific qualification and differences remain available.

The bounded reconciliation identified no specific unaccounted compatible contribution requiring this draft to remain open. This closes the obsolete integration request; it does not assert wholesale branch ancestry, erase history, or close unrelated engineering gates. The original branch and PR description are retained.

## PR347 — close as consolidated

Closing this stacked draft as consolidated into main through #349, merged at `ACTUAL_PR349_MERGE_SHA`. The unchanged PR347 head `b461ac64eb9beb74449ce2b18b6795a2af34a02a` is in the resulting main ancestry through #348 and #349.

The selective PR346 recovery recorded here remains integrated, including candidate admission, bounded inventory replay, Qt diagnostics and form-feed controls, while PR345's report, lifecycle, Evidence/help and Linux refusal behavior is preserved. The later inventory repairs remain in the successor chain.

The original branch, PR description, source-specific test records and failures are retained. This is reconciliation of the stacked integration request, without a separate merge against its old feature base.

## PR348 — close as consolidated

Closing this stacked draft as consolidated into main through #349, merged at `ACTUAL_PR349_MERGE_SHA`. The unchanged PR348 head `6b6fcd3597a604212032ffc453477aeb6edc69ff` is in the resulting main ancestry.

The reviewed inventory-validation recovery and eight Strings header-help mappings remain in the integrated source, together with the preceding #345/#347 work. PR348's hosted results remain evidence for their exact source; the actual #349 merge rests on its own qualification.

The original branch, PR description and failure/evidence history are retained. This closes the old feature-base integration request; unfinished engineering gates continue in the current ledger.
