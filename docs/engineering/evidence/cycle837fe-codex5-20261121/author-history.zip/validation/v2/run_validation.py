"""Owned-checkout validation receipt, no target-binary execution."""
from pathlib import Path
import datetime, hashlib, json, os, subprocess, sys, time
repo=Path('/workspace/scratch/837fe19aae3a/repair-codex5-command-audit-v2')
out=Path(__file__).resolve().parent
python='/workspace/scratch/837fe19aae3a/codex5-audit-v2-venv/bin/python'
mode=sys.argv[1]
commands={
 'affected':[python,'-m','pytest','-q','tests/test_codex5_command_audit_20261121.py','tests/test_codex_pkg_workflows.py','tests/test_spec_registry.py'],
 'ruff':[python,'-m','ruff','check','src','tests','tools'],
 'pip':[python,'-m','pip','check'],
 'binding':[python,'-I','-c',"import inspect,json,pathlib,sys,importlib.metadata as m; import patchtrace,yaml; root=pathlib.Path('/workspace/scratch/837fe19aae3a/repair-codex5-command-audit-v2'); p=pathlib.Path(inspect.getfile(patchtrace)).resolve(); assert p==root/'src/patchtrace/__init__.py',p; d=json.loads(m.distribution('patchtrace').read_text('direct_url.json')); assert d['url']=='file://'+str(root),d; print(json.dumps({'python':sys.executable,'prefix':sys.prefix,'patchtrace':str(p),'direct_url':d,'yaml':yaml.__file__,'yaml_version':m.version('PyYAML'),'pytest_version':m.version('pytest'),'ruff_version':m.version('ruff')},indent=2))"],
}
def git(*args):return subprocess.check_output(['git','-C',str(repo),*args],text=True).strip()
def sources():
 paths=['tools/ci_pip_install_audit.py','tests/test_codex5_command_audit_20261121.py','tests/test_codex_pkg_workflows.py','pyproject.toml','docs/specs/ci-pip-command-audit.md','docs/specs/REGISTRY.md','docs/modules.md','docs/audits/codex-workflows-1.md','docs/engineering-handoffs/codex5-command-audit-20261121.md','docs/engineering/evidence/codex5-per-command-audit-20261121.json']
 paths += [str(p.relative_to(repo)) for p in sorted((repo/'.github/workflows').glob('*.yml'))]
 return {p:hashlib.sha256((repo/p).read_bytes()).hexdigest() for p in paths}
receipt={'command':commands[mode],'cwd':str(repo),'source_base':git('rev-parse','HEAD'),'dirty_before':git('status','--short'),'sources_before':sources(),'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
env=os.environ.copy();env['QT_QPA_PLATFORM']='offscreen';env.pop('PYTHONPATH',None)
start=time.monotonic()
with (out/f'{mode}.log').open('w') as log:
 p=subprocess.run(commands[mode],cwd=repo,env=env,stdout=log,stderr=subprocess.STDOUT,text=True)
receipt.update({'exit_code':p.returncode,'elapsed_seconds':round(time.monotonic()-start,3),'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head_after':git('rev-parse','HEAD'),'sources_after':sources()})
receipt['source_files_unchanged']=receipt['sources_before']==receipt['sources_after']
(out/f'{mode}.json').write_text(json.dumps(receipt,indent=2)+'\n')
print((out/f'{mode}.log').read_text()[-6000:])
print(json.dumps({k:receipt[k] for k in ['command','exit_code','elapsed_seconds','source_files_unchanged']}))
sys.exit(p.returncode)
