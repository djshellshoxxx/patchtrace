from pathlib import Path
import importlib.util
import sys
import pytest

SNAPSHOT = Path(__file__).resolve().parents[1]
sys.dont_write_bytecode = True

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

scanner = load("tools.ci_pip_install_audit", SNAPSHOT / "ci_pip_install_audit.py")
gate_module = load("review_frozen_c5_test", SNAPSHOT / "test_codex5_command_audit_20261121.py")

@pytest.fixture(autouse=True, params=["parser_error", "empty_discovery", "known_unprotected", "protected_only"])
def scenario(request, tmp_path, monkeypatch):
    cases = {
        "parser_error": "jobs: [",
        "known_unprotected": "jobs: {sample: {steps: [{run: 'python -m pip install sample-package'}]}}",
        "protected_only": "jobs: {sample: {steps: [{run: 'python -m pip install --require-hashes -r lock.txt'}]}}",
    }
    if request.param in cases:
        (tmp_path / "fixture.yml").write_text(cases[request.param])
    monkeypatch.setattr(gate_module, "WORKFLOWS", tmp_path)

test_typed_gate = gate_module.test_all_explicit_workflow_pip_installs_are_protected
