# Independent review of CODEX-5 V2 4cbe4790

**Disposition: blocked only on the identified executable process-substitution omission.** The prior five lexical counterexamples and missing specification registration are repaired.

- Commit: `4cbe479023067b05b688cd1c1b02994b0228e305`.
- Tree: `98a4fc483085f9a1489508bc00a67f0284cb0168`.
- Parent: blocked V1 `93b053a88e4373d9f5c69cd68f96e1a49305d579`.
- Integration ancestor: frozen PR349 `ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e`.
- Exact scanner blob: `30414e029061f069b02f0855c8f9796a3f7736bc`.

## Remaining blocker

The scanner returns an empty successful result for both unquoted input and output process substitutions containing an explicit installer when passed to an output command. The declared contract requires unsupported matching substitution/grouping/redirection to raise `WorkflowAuditError`. A narrow quote-aware refusal of those executable forms is sufficient; evaluating process substitution or implementing general shell syntax is unnecessary.

The initial `shell-boundary-controls.json` retains 13 cases (12 passed, one input-process-substitution failure). The expanded, deduplicated `extended-shell-controls.json` retains **20 distinct cases: 18 passed, two failures**, covering both process-substitution directions. It includes all nine earlier lexical controls. Single-quoted, double-quoted, escaped and commented process-looking text remain literal; a completed non-installer substitution followed by an independent direct install remains visible. Multiline dollar substitution is already rejected. These commands were only strings passed to the scanner; none was executed.

## Independent verification completed

The exact clean V2 checkout and dedicated environment independently reproduce **214 passed and two strict CODEX-5 expected failures**, 216 distinct maintained test identities, zero failures/errors/ordinary skips. The selection is the new audit module, original workflow audit and unchanged spec-registry module. The source import path and editable distribution identity were asserted under `python -I`; the checkout was clean before and after. See `maintained.json`, `maintained.log` and `maintained.xml`.

Bounded Ruff checks of the two Python paths and environment `pip check` pass (`lint-dependencies.json`). These are not a full-suite or hosted qualification.

Four independent controls exercise the actual typed expected-failure gate again. Invalid YAML and empty discovery produce ordinary failures, known unprotected installs produce the dedicated XFAIL, and protected-only input produces XPASS(strict). The receipt intentionally contains three red outcomes and one expected failure; these prove mark semantics and are not additional product defects. See `typed-xfail-controls/receipt.json`.

The exact current corpus is **21 workflows / 200 actual run scalars / 42 direct installers / 41 unprotected installers**. All 21 workflows, original CODEX-5 test, dependency declaration, ledger and QA remain byte-identical to ae69; all runtime `src/` paths are unchanged.

The original donor handoff is retained as an exact prefix with an explicitly identified repair appendage. Every original donor JSON field is unchanged; V2 adds only a separate `repair_qualification` object. The three original positive donor test functions (17 parameterized/concrete cases) retain identical ASTs. The required registry entry is now present. See `preservation-and-census.json`.

## Qualification boundary

The original V1 full attempt is separate: root reports child SIGKILL `-9`, wrapper `247`, after 498.536 seconds at roughly 26%, without an aggregate result or established cause. It is neither a clean ae69 success nor a V2 full-suite pass. This review did not restart it or infer a cause.

No authored source, workflow or reference was changed. Prior donor and V1 red evidence remain retained. Final approval requires the exact V3 correction and replay of these bounded controls; broad CODEX-5 lock closure stays open.
