# Independent review of CODEX-5 repair 93b053a8

Disposition: **blocked pending shell-context correction and specification registration**.

Source commit: `93b053a88e4373d9f5c69cd68f96e1a49305d579`; tree `90e69cbc319d4bc6076a4701964a4a3bb376a516`; direct parent `ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e`.

## Blocking results

The exact scanner Git blob `40361a3220767b9efed1a06338728e82f1f8ec76` was loaded from an immutable source snapshot and fed only local authored YAML strings. No shell or package command was executed.

Five of nine independently checked shell-context cases fail the declared contract:

1. A word-attached hash before a command separator causes a later explicit installer to disappear.
2. Multiline backtick command substitution containing an explicit installer returns an empty successful result.
3. A quoted semicolon argument in literal echo output is incorrectly interpreted as a command separator and invents an installer.
4. A quoted logical-operator argument in literal printf output produces the same false installer.
5. Installer/substitution text wholly inside a real shell comment is incorrectly treated as executable unsupported syntax.

The first two reproduce the author's disclosed post-freeze gaps. The latter three independently demonstrate lost quote/comment context. The four positive companion cases distinguish escaped/quoted hashes, a real comment, and a correctly rejected direct substitution.

Receipt: `shell-boundary-controls.json`. Repair must retain these controls, preserve lexical quote/comment context before splitting, and report unsupported executable substitution as an explicit audit error. The source-only audit need not become a general shell interpreter.

A separate maintained gate also fails: `tests/test_spec_registry.py::test_registry_cites_spec_file_by_path[docs/specs/ci-pip-command-audit.md]`. The new contract is missing its required literal path in `docs/specs/REGISTRY.md`; registration in `docs/modules.md` is separate. The unmodified maintained selector was executed against an immutable archive of this head's specification files and produced exactly one failure, zero errors/skips. Receipt: `spec-registry-controls/receipt.json`.

## Verified improvements and preservation

- The original three independent YAML controls pass: literal-block header comments, folded blank-line boundaries and metadata keys named run.
- The actual conditional Ghidriff install is now recognized.
- The actual ae69 workflow census is independently reproduced: **21 workflows, 200 real run scalars, 42 explicit installers and 41 unprotected installers**. Receipt: `original-controls-and-current-census.json`.
- All 21 workflow files, the original CODEX-5 test, pyproject, ledger and QA are byte-identical to ae69. Both original donor handoff/evidence files are byte-identical to the donor. Receipt: `identity-preservation.json`.
- The new typed strict expected failure behaves correctly under independent pytest controls using the actual authored marked gate: invalid YAML and empty discovery fail normally; a known unprotected install produces the intended typed XFAIL; protected-only input produces XPASS(strict). The three deliberate red outcomes are acceptance controls, not three additional product defects. Receipt: `typed-xfail-controls/receipt.json`.

The author's 87-pass/two-xfail affected run remains author evidence. Its already-started full run began against pre-commit modified working-tree bytes; it is not a clean ae69 run and cannot qualify a later corrected commit.

No current source, authored source, workflow or ref was modified. Further qualification must identify the corrected immutable source and retain these red receipts. The broad CODEX-5 hash/dependency closure remains open.
