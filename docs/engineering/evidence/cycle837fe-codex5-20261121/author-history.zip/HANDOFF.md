# CODEX-5 command-audit candidate handoff

## Immutable source

- Final local head: `5b5328ee83ee4990b3311f7ac90e2f5e5f76f800`.
- Tree: `1e12edd510399fd92da6867cd071394ceb7fc95b`.
- Exact integration base: `ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e`.
- Local commit chain: `93b053a88e4373d9f5c69cd68f96e1a49305d579` -> `4cbe479023067b05b688cd1c1b02994b0228e305` -> `5b5328ee83ee4990b3311f7ac90e2f5e5f76f800`. Earlier candidates remain explicitly blocked historical stages.
- Donor: `codex/patchtrace-codex5-per-command-audit-20261121` at `36b58a7d857690a8bf0093bcee1edd5036189b30`, originally based on `f928a0cef29eac2b603d390c40fb86448111b91b`. Original six files and the scoped branch delta are archival inputs, not a wholesale integration instruction.
- Owned final checkout: `/workspace/scratch/837fe19aae3a/repair-codex5-command-audit-v3`; private branch `codex5-command-audit-repair-v3-20261121`; clean when sealed.

## Result and limits

The audit now uses the existing PyYAML dev dependency to extract actual job step run strings. It retains quote/escape context until command boundaries and real comments are known; conditional/negated direct installs are recognized. Unsupported executable substitution remains an explicit error, including input/output process substitution. Quoted/escaped literals remain data. Only the dedicated missing-boundary exception qualifies for the additive strict xfail; parser, dependency and empty-discovery errors are hard failures.

Author gates: **226 passed, two strict CODEX-5 xfailed**; whole-tree Ruff and pip consistency passed. Source binding in an isolated interpreter and local editable metadata points to this owned checkout. All 13 retained peer controls replayed successfully. Exact current census: **21 workflows, 200 step run strings, 42 explicit installs, 41 unprotected**; only Pages has its existing boundary flag. This is a bounded source audit, not a general shell interpreter or complete wheel hash-closure implementation. CODEX-5 remains open.

Root also independently qualified the same clean head/tree with **1548 passed and two strict CODEX-5 expected failures** across 66 selectors (1550 distinct cases, 84.021 seconds wall time), plus whole-tree Ruff, pip and isolated import/editable binding. Its checkout was clean before and after. The author 226-case selection overlaps this root selection; the counts are **not additive**. Root receipts and raw stdout are preserved under `root-qualification/`. The raw controlled live-probe diagnostic is retained and does not establish native acceptance.

Final immutable peer review is requested separately. Supported hosted qualification must run on root's final combined source. No full-suite, native, release, deployment, paid-call or transitive-lock success is inferred from these checks.

## Candidate-owned paths

- `docs/audits/codex-workflows-1.md`
- `docs/engineering-handoffs/codex5-command-audit-20261121.md`
- `docs/engineering/evidence/codex5-per-command-audit-20261121.json`
- `docs/modules.md`
- `docs/specs/REGISTRY.md`
- `docs/specs/ci-pip-command-audit.md`
- `tests/test_codex5_command_audit_20261121.py`
- `tools/ci_pip_install_audit.py`

All workflow bytes, `src/`, `pyproject.toml`, the original CODEX-5 test, the existing spec-registry test, global ledger and QA files are unchanged. Audit prose is appended; donor handoff/evidence history is preserved, with later qualification records added. The registry adds only the new specification path and a proposed nonnumeric alias.

## Exact validation commands

Run directory: `/workspace/scratch/837fe19aae3a/repair-codex5-command-audit-v3`.

```sh
QT_QPA_PLATFORM=offscreen /workspace/scratch/837fe19aae3a/codex5-audit-v3-venv/bin/python -m pytest -q tests/test_codex5_command_audit_20261121.py tests/test_codex_pkg_workflows.py tests/test_spec_registry.py
/workspace/scratch/837fe19aae3a/codex5-audit-v3-venv/bin/python -m ruff check src tests tools
/workspace/scratch/837fe19aae3a/codex5-audit-v3-venv/bin/python -m pip check
```

Exact isolated binding command (also retained as argv in `validation/v3/binding.json`):

```sh
/workspace/scratch/837fe19aae3a/codex5-audit-v3-venv/bin/python -I -c 'import inspect,json,pathlib,sys,importlib.metadata as m; import patchtrace,yaml; root=pathlib.Path('"'"'/workspace/scratch/837fe19aae3a/repair-codex5-command-audit-v3'"'"'); p=pathlib.Path(inspect.getfile(patchtrace)).resolve(); assert p==root/'"'"'src/patchtrace/__init__.py'"'"',p; d=json.loads(m.distribution('"'"'patchtrace'"'"').read_text('"'"'direct_url.json'"'"')); assert d['"'"'url'"'"']=='"'"'file://'"'"'+str(root),d; print(json.dumps({'"'"'python'"'"':sys.executable,'"'"'prefix'"'"':sys.prefix,'"'"'patchtrace'"'"':str(p),'"'"'direct_url'"'"':d,'"'"'yaml'"'"':yaml.__file__,'"'"'yaml_version'"'"':m.version('"'"'PyYAML'"'"'),'"'"'pytest_version'"'"':m.version('"'"'pytest'"'"'),'"'"'ruff_version'"'"':m.version('"'"'ruff'"'"')},indent=2))'
```

Meaningful red selectors retained before their corresponding fixes:

- Donor scanner: `tests/test_codex5_command_audit_20261121.py -k independent_recovery_controls`: four failed.
- Frozen 93 scanner: `tests/test_codex5_command_audit_20261121.py -k peer_lexical_controls`: five failed, four positive companions passed.
- Frozen 93 registry: `tests/test_spec_registry.py::test_registry_cites_spec_file_by_path[docs/specs/ci-pip-command-audit.md]`: one failed.
- Frozen 4c scanner: `tests/test_codex5_command_audit_20261121.py -k executable_process_substitution`: four failed, four quoted companions passed.

Each raw receipt retains the exact interpreter, argv, source base and stdout. No shell-script fixture strings were executed.

## Dedicated offline environment setup

The executed V3 setup used fresh paths; it did not rebind the frozen V1/V2 environments:

```sh
/workspace/scratch/837fe19aae3a/combined-venv/bin/python -m venv --without-pip /workspace/scratch/837fe19aae3a/codex5-audit-v3-venv
```

Two plain text `.pth` files were written in the new environment's `lib/python3.12/site-packages/`:

| File | Complete line (followed by newline) |
|---|---|
| `reused-dependencies.pth` | `/workspace/scratch/patchtrace-95fe-c3/venv/lib/python3.12/site-packages` |
| `source-binding.pth` | `/workspace/scratch/837fe19aae3a/repair-codex5-command-audit-v3/src` |

From the owned checkout:

```sh
/workspace/scratch/837fe19aae3a/codex5-audit-v3-venv/bin/python -m pip install --no-deps --no-build-isolation --no-index -e .
```

This reuses installed packages through a plain path; it neither copies/symlinks packages nor evaluates the other environment's editable `.pth` files. Pip installs the local project's editable metadata into the new prefix and explicitly declines to uninstall the project from the outside shared prefix. No dependency downloads occurred. Root should create another fresh environment and substitute its own checkout path in the second `.pth` and editable install, then verify isolated import and direct_url binding. This setup is local validation convenience, not CODEX-5 artifact-lock proof.

## Retained full-run failure

The sole full attempt used the original V1 environment/checkout, starting on dirty pre-commit source based on ae69. Its code bytes later became 93 and remained unchanged. The exact command was:

```sh
QT_QPA_PLATFORM=offscreen /workspace/scratch/837fe19aae3a/codex5-audit-venv/bin/python -m pytest -q
```

It began at `2026-11-21T08:11:53.763819+00:00` and finished at `2026-11-21T08:20:12.300211+00:00`: child exit **-9 (SIGKILL)**, wrapper exit **247**, elapsed **498.536 seconds**, no pytest summary. The cause is undetermined. The raw final stdout and receipt are retained as `validation/v1/full.log` and `validation/v1/full.json`. Do not label this a clean ae69 run, a full pass, an OOM diagnosis, or final-candidate qualification. No full rerun, assertion weakening or limit change followed.

## Recovery and publication constraints

The Git bundle contains the three local repair commits and requires the exact ae69 base; the patch series is an additional review/recovery format. Apply the whole chain or recover its final head: the final single commit alone does not introduce all donor files. Original donor source and scoped ledger delta remain under `original-donor/`; the donor ledger is archival only and must not overwrite root's authoritative ledger. Root owns reconciliation of the scoped task/notes, donor reachability, publication records and any combined follow-up branch.

No remote ref, PR, main, tag, release or deployment was changed by this task. Preserve prior failures and qualify root's actual combined SHA under supported hosted checks before publication/merge decisions. Keep `[no release]` and `[no deploy]` controls effective. Original worktrees and dedicated environments remain intact.

## Archive contents

The portable ZIP contains this handoff, an exact source/commit receipt, the three-commit bundle and patch series, final candidate-owned source files, original donor source/recovery receipts, author V1/V2/V3 red/green records, independent earlier-review records, and the original final full-run stdout/receipt. Unchanged bulk spec mirror copies and Python caches are omitted; original reviewer receipts and relevant registry fixtures are preserved. `MANIFEST.sha256` covers every other archive member. The external archive receipt records the ZIP hash, manifest hash and member count.
