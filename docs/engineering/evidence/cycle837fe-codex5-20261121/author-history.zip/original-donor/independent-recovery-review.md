# CODEX-5 donor recovery: independent assessment

**Disposition: recover the existing scoped work, but do not integrate donor head unchanged.** The scanner improves the original whole-script heuristic for the author's supported examples, but misses one explicit installer in the current workflow tree and fails three valid YAML controls. It does not close CODEX-5. The coordinator's current PR #349 source was left untouched.

## Exact sources

- Donor branch: `codex/patchtrace-codex5-per-command-audit-20261121`.
- Donor head: `36b58a7d857690a8bf0093bcee1edd5036189b30`; tree `a5cbfc9c3f4eb15e1ac4a43339d27bc3dcd09ed2`.
- Donor base: C4 head `f928a0cef29eac2b603d390c40fb86448111b91b`. GitHub compare records eight commits ahead, zero behind and six changed paths. The first commit specifies the audit contract before scanner and tests.
- Frozen comparison target: PR #349 `ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e`; tree `c3f09435deb99ca0ddb3406e27ab315dba7740cf`.
- Local comparison checkout: `repair-tier-r-pin-contract` at `06ea27de0936f1f8eb1aeca264833c21845a7f36`, exactly the same tree as ae69.
- All six donor files in `source/` have been independently checked against the Git blob SHAs returned by the immutable compare response. Identity and comparison responses are retained in `identity.json`, `branch-delta.json` and `current-coverage.json`.

## Required corrections

| Finding | Independent result | Required repair |
| --- | --- | --- |
| Current explicit conditional installer omitted | Current `winbindex-pairs.yml` line 71 contains `if ! python -m pip install --only-binary=:all: ghidriff; then`. Donor reports no installer or violation for this workflow. | Cover this actual command form, or surface matching unsupported syntax as explicit uncertainty; preserve it as a positive regression. |
| Literal YAML block with header comment loses body | A valid `run: | # explanatory comment` block containing one unprotected installer produces zero violations. | Read the actual YAML scalar rather than treating its commented block header as a shell command. |
| Folded scalar loses command boundary | A valid folded `>-` block with a blank line between two installer commands becomes one command in the donor. A flag on the second invocation exempts the first. Expected one violation, actual zero. | Preserve decoded YAML folding and blank-line semantics before shell command analysis. |
| Non-step `run` field creates a false install | An `env` key named `run` produces one violation although the only actual step command is `echo fixture`. | Restrict extraction to actual job step `run` fields. |
| New test does not satisfy configured Ruff import ordering | Scanner passes; new test reports I001 using both the evidence mirror and repository-path stdin checks with the candidate configuration. | Correct the test's import formatting and rerun the bounded lint gate in the repair tree. |

The exact YAML fixtures and observed results are retained in `independent-boundary-controls.json`. They were parsed as strings only; no installer or shell command in a fixture was executed. The actual conditional-install workflow is retained as `current-winbindex-pairs.yml`, Git blob `cb01c229ae802c30a7e0208daf49f09fe09ce772`.

These are contract failures, not evidence of a compromised workflow or third-party activity.

## Current-source coverage

The verified donor scanner was loaded and applied to all 21 current checked-in workflow files. An independent PyYAML traversal of actual `jobs.*.steps[*].run` fields and manual inspection of each matched installer source line established:

| Measure | Result |
| --- | ---: |
| Actual workflow files | 21 |
| Actual step run scalar values | 200 |
| Donor-extracted scalar values | 204 |
| Visible explicit installer occurrences | 42 |
| Occurrences containing a qualifying flag | 1, the Pages hashed-lock install |
| Donor-recognized installer commands | 41 |
| Donor-reported unprotected commands | 40 |
| Unprotected explicit occurrences in the inspected current source | 41 |
| Donor parse errors on current workflows | 0 |

The four extra scalars are empty `defaults.run` mappings: one in `backend-bundle.yml` and three in `unified-live-gates.yml`. They do not currently change the violation count, but shift reported run ordinals and demonstrate incorrect field selection. The missing conditional install accounts for the one omitted actual occurrence. This is a bounded source census, not a general shell interpreter or proof about indirect subprocess installs.

Detailed per-workflow results, all 42 inspected occurrence lines, source hashes and clean checkout receipts are in `current-coverage.json`; the earlier full scan is in `actual-workflow-scan.json`. The census can be reproduced with `collect-current-coverage.py` using the already available private validation interpreter.

## Six-path recovery recipe

Do not merge all donor history into the frozen PR or overwrite the global ledger. Recover the scoped file additions and append-only contract on the separately owned repair source, then retain the independent failures when correcting it.

| Path | Exact donor Git blob | Recovery treatment |
| --- | --- | --- |
| `tools/ci_pip_install_audit.py` | `9c356458d14a6bb7e76d075868dae1cad94a7ce7` | Recover the existing implementation as the repair baseline; correct the findings above. |
| `tests/test_codex5_command_audit_20261121.py` | `0065c0510e179247b06ebd75910d558929080888` | Retain the author's 17 positive cases, add the independent and actual-workflow regressions, fix Ruff and separate parser failure from expected closure failure. |
| `docs/audits/codex-workflows-1.md` | `687485a611ebee81a6d3c7c6e8a2912be4f41cd5` | Its existing prefix is byte-identical to ae69; recover only the 34-line CODEX-5 contract appendix, updating the supported syntax/dependency/error contract before repair implementation. |
| `docs/engineering-handoffs/codex5-command-audit-20261121.md` | `1e242a88e8d66c7e7193ac1f97631d2c84a40be9` | Preserve the original handoff and its limitations as historical provenance; append or separately record the new repair/review disposition. |
| `docs/engineering/evidence/codex5-per-command-audit-20261121.json` | `f706a8aeaeeb1f127ffc62aa524b0a3870f0781f` | Preserve the author's historical exact-byte and fixture evidence unchanged; add new-source receipts separately. |
| `docs/engineering/task-ledger.json` | `b9da4b0ee2f7b8fac4cb49ef15577363e7949023` | Merge only scoped task `codex5-per-command-audit-20261121` and its two evidence notes, with current independent disposition. Retain all current checkpoint, qualification, ownership and unrelated task fields. |

The donor ledger has the stale global checkpoint `2a67980cfeb88ad72bf8ad523d2bafc8426e5b7c`; current ae69 records tested source `829600f8d667b74329a79dd0b0d7964c2e092fd0`. Whole-file ledger replacement would lose subsequent work.

PyYAML already exists as a development-only dependency (`>=6,<7`) in the current project. Using decoded step scalar values is a reasonable repair direction, provided the contract states that dependency and makes missing/invalid YAML or unsupported matching syntax visible. A repair should not relax the contract to accept the demonstrated omissions.

## Strict expected-failure meaning

The original `tests/test_codex_pkg_workflows.py::test_pip_downloads_require_hashes` remains unchanged, with strict CODEX-5 expected failure. Its whole-script heuristic still has the known precision gap; the donor adds a second expected-failure test without replacing it. The original test blob at the current target is `3590e16e7ad5789ecab04679ab323f53ef8a38e3`.

A duplicate strict expected failure is not closure. In the donor's new test, any exception from discovery or parsing is also an expected failure. Therefore a parser regression or missing workflow tree could be hidden by the mark. Repair acceptance must independently establish valid discovery and parsing, then reserve the expected failure for the known unprotected installer inventory. Preserve the old strict gate until a coordinated, independently reviewed replacement is appropriate.

Neither scanner proves complete referenced-lock closure, validates remote find-links provenance, or qualifies indirect installs. The broader package/hash, transitive Action/npm, runtime-version and native/manual gates remain open.

## Prior evidence and ownership

The retained author record reports 17 passing fixture cases and one strict expected failure on two authored workflow fixtures, compileall success, exact Git-blob comparison and three author-side mutation checks. It expressly does not claim a full actual workflow checkout test, successful Ruff, hosted CI or independent peer review. Those limits remain attached to those results.

The handoff says no background workers were claimed and explicitly directs the next worker/root to verify and coordinate recovery. It does not grant the donor integration ownership over PR #349. The older 08:30 ownership timestamp in the donor handoff is historical; live coordinator ownership controls integration. This review did not contact an external owner or independently prove remote worker liveness.

## Review boundary

This review executed only the exact stdlib scanner on local source strings, independent YAML parsing, bounded Ruff checks and read-only Git identity/status commands. The current candidate remained clean before and after. No source file, reference, workflow, package lock, PR, release, deployment or native target was changed or executed. The full suite was not run. The donor fixture pass count is retained as author evidence, not relabeled as an independent full-checkout test result.

The recovered repair requires a new source-specific validation and separate review. The frozen ae69 qualification does not inherit either this donor's claims or a future repair's results.
