"""Read-only source census for the exact donor and frozen candidate; executes no scripts."""
from __future__ import annotations

import datetime
import hashlib
import importlib.util
import json
import pathlib
import re
import subprocess
import sys

import yaml

ROOT = pathlib.Path('/workspace/scratch/837fe19aae3a')
EVIDENCE = ROOT / 'evidence/codex5-per-command-recovery'
CANDIDATE = ROOT / 'repair-tier-r-pin-contract'
DONOR = EVIDENCE / 'source'
sys.dont_write_bytecode = True


def blob(data: bytes) -> str:
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def git(*args: str) -> str:
    return subprocess.check_output(['git', '-C', str(CANDIDATE), *args], text=True).strip()


delta = json.loads((EVIDENCE / 'branch-delta.json').read_text())
sources = []
for changed in delta['files']:
    p = DONOR / changed['filename']
    data = p.read_bytes()
    actual = blob(data)
    assert actual == changed['sha'], (changed['filename'], actual, changed['sha'])
    sources.append({'path': changed['filename'], 'blob': actual,
                    'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)})

spec = importlib.util.spec_from_file_location('donor_scanner', DONOR / 'tools/ci_pip_install_audit.py')
assert spec is not None and spec.loader is not None
scanner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(scanner)

before = git('status', '--porcelain=v1', '--untracked-files=normal')
head = git('rev-parse', 'HEAD')
tree = git('rev-parse', 'HEAD^{tree}')
assert head == '06ea27de0936f1f8eb1aeca264833c21845a7f36'
assert tree == 'c3f09435deb99ca0ddb3406e27ab315dba7740cf'
assert before == ''
pattern = re.compile(r'\b(?:python(?:3(?:\.\d+)?)?\s+-m\s+)?pip(?:3(?:\.\d+)?)?\s+install\b')
workflows = []
occurrences = []
for path in sorted((CANDIDATE / '.github/workflows').glob('*.y*ml')):
    data = path.read_bytes()
    text = data.decode()
    parsed = yaml.safe_load(text)
    runs = []
    for job_name, job in parsed.get('jobs', {}).items():
        if not isinstance(job, dict):
            continue
        for step_index, step in enumerate(job.get('steps', []), 1):
            if not isinstance(step, dict) or not isinstance(step.get('run'), str):
                continue
            script = step['run']
            runs.append(script)
            for line_index, line in enumerate(script.splitlines(), 1):
                if pattern.search(line):
                    occurrences.append({'workflow': path.name, 'job': job_name,
                                        'step_index': step_index, 'step_name': step.get('name'),
                                        'script_line': line_index, 'command_source': line,
                                        'protected_flag_present': '--require-hashes' in line or '--no-index' in line})
    recognized = []
    for ordinal, scalar in enumerate(scanner.run_scalars(text), 1):
        for command in scanner._shell_commands(scalar):
            args = scanner._pip_args(command)
            if args is not None:
                recognized.append({'run_ordinal': ordinal, 'command': command,
                                   'protected': '--require-hashes' in args or '--no-index' in args})
    workflows.append({'path': str(path.relative_to(CANDIDATE)), 'git_blob': blob(data),
                      'sha256': hashlib.sha256(data).hexdigest(), 'actual_step_runs': len(runs),
                      'donor_run_scalars': len(list(scanner.run_scalars(text))),
                      'recognized_installs': recognized, 'reported_violations': scanner.unhashed_installs(text)})

offender = CANDIDATE / '.github/workflows/winbindex-pairs.yml'
offender_text = offender.read_text()
offender_lines = [{'line': n, 'text': line} for n, line in enumerate(offender_text.splitlines(), 1)
                  if pattern.search(line)]
assert offender_lines == [{'line': 71, 'text': '          if ! python -m pip install --only-binary=:all: ghidriff; then'}]
assert scanner.unhashed_installs(offender_text) == []
(EVIDENCE / 'current-winbindex-pairs.yml').write_text(offender_text)
old_test = CANDIDATE / 'tests/test_codex_pkg_workflows.py'
after = git('status', '--porcelain=v1', '--untracked-files=normal')
assert after == before
receipt = {
    'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Exact verified donor code, current checked-in YAML source and independent YAML step-field census only; shell/package commands were never executed.',
    'donor_head': '36b58a7d857690a8bf0093bcee1edd5036189b30',
    'candidate_remote_head': 'ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e',
    'candidate_local_head': head, 'candidate_tree': tree,
    'candidate_clean_before': before == '', 'candidate_clean_after': after == '',
    'source_blobs': sources, 'workflow_count': len(workflows),
    'actual_step_run_count': sum(w['actual_step_runs'] for w in workflows),
    'donor_scalar_count': sum(w['donor_run_scalars'] for w in workflows),
    'visible_explicit_install_occurrences': len(occurrences),
    'protected_occurrences': sum(o['protected_flag_present'] for o in occurrences),
    'donor_recognized_installs': sum(len(w['recognized_installs']) for w in workflows),
    'donor_reported_violations': sum(len(w['reported_violations']) for w in workflows),
    'current_false_negative': {'workflow': str(offender.relative_to(CANDIDATE)),
                               'git_blob': blob(offender.read_bytes()), 'source': offender_lines,
                               'expected_unprotected_installs': 1, 'donor_reported_violations': 0},
    'unchanged_original_audit_test_blob': blob(old_test.read_bytes()),
    'occurrence_census_note': 'All matched current-source lines were manually inspected as executable explicit installers; this is a bounded census of this exact source, not a general shell classifier.',
    'occurrences': occurrences, 'workflows': workflows,
}
(EVIDENCE / 'current-coverage.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: v for k, v in receipt.items() if k not in {'occurrences', 'workflows', 'source_blobs'}}, indent=2))
