"""Read-only, source-bound promotion-control inspection. Does not run project code or CI."""
from __future__ import annotations

import hashlib
import json
import re
import subprocess
import zipfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/workspace/scratch/837fe19aae3a/repair-tier-r-pin-contract')
EVIDENCE = Path('/workspace/scratch/837fe19aae3a/evidence')
OUT = Path(__file__).resolve().parent
LOCAL = '06ea27de0936f1f8eb1aeca264833c21845a7f36'
HEAD = 'ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e'
TREE = 'c3f09435deb99ca0ddb3406e27ab315dba7740cf'
BASE = 'fdc2696c23bdbfe7668348f25e3b336ce33039f7'
MERGE = '66f153a8372ad93c72e2f5b10365dcf210681684'


def git(*args: str) -> str:
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True)


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


sources: list[dict] = []


def source(path: str) -> str:
    data = subprocess.check_output(['git', 'show', f'{LOCAL}:{path}'], cwd=ROOT)
    sources.append({'path': path, 'blob': git('rev-parse', f'{LOCAL}:{path}').strip(),
                    'bytes': len(data), 'sha256': digest(data)})
    return data.decode('utf-8')


inputs: list[dict] = []


def receipt(path: str) -> dict:
    data = (EVIDENCE / path).read_bytes()
    inputs.append({'path': str(EVIDENCE / path), 'bytes': len(data), 'sha256': digest(data)})
    return json.loads(data)


def blocks(text: str) -> dict[str, str]:
    text = text.split('\njobs:\n', 1)[1]
    matches = list(re.finditer(r'^  ([\w-]+):\n', text, re.M))
    return {match[1]: text[match.start():matches[i + 1].start() if i + 1 < len(matches) else len(text)]
            for i, match in enumerate(matches)}


def key(block: str, name: str) -> str | None:
    match = re.search(rf'^    {re.escape(name)}: (.+)$', block, re.M)
    return match[1] if match else None


checks: list[dict] = []


def check(name: str, result: bool, evidence: object = None) -> None:
    checks.append({'id': name, 'passed': bool(result), 'evidence': evidence})


check('local_head_and_tree', git('rev-parse', 'HEAD').strip() == LOCAL
      and git('rev-parse', f'{LOCAL}^{{tree}}').strip() == TREE, {'local': LOCAL, 'tree': TREE})
check('working_tree_clean', not git('status', '--porcelain').strip())
initial = receipt('final-ae69-qualification/initial-run-and-source-records.json')
pr, remote, merge = initial['responses'][:3]
check('captured_remote_source_identity', pr['head']['sha'] == HEAD and pr['base']['sha'] == BASE
      and pr['merge_commit_sha'] == MERGE and remote['sha'] == HEAD and remote['tree']['sha'] == TREE
      and merge['sha'] == MERGE and merge['tree']['sha'] == TREE
      and [p['sha'] for p in merge['parents']] == [BASE, HEAD], initial['observed'])

qa = source('.github/workflows/qa-windows.yml')
pages = source('.github/workflows/pages.yml')
gate = source('tools/release_gate.py')
backend = source('.github/workflows/backend-bundle.yml')
intel = source('.github/workflows/live-intel-tools.yml')
tier = source('.github/workflows/corpus-tier-r.yml')
for path in ['AGENTS.md', 'docs/specs/windows-acceptance-and-milestone-builds.md',
             'docs/specs/pages-deployment-control.md', 'docs/specs/pages-build-isolation-and-hashes.md',
             'docs/specs/live-intel-probe-diagnostics.md', 'tests/test_release_gate.py',
             'tests/test_site_workflow.py', 'docs/engineering/cycle837fe-native-c4-20261121.md',
             'docs/plans/accuracy-program-handoff-20261107.md', 'tasks/todo.md']:
    source(path)
historical = source('docs/engineering/evidence/cycle837fe-native-c4-20261121/daee-native-observations.md')

jobs = blocks(qa)
pages_jobs = blocks(pages)
release_condition = "(startsWith(github.ref, 'refs/tags/v') || needs.release-gate.outputs.publish == 'true') && !contains(github.event.head_commit.message, '[no release]')"
deploy_condition = "github.event_name != 'push' || !contains(github.event.head_commit.message, '[no deploy]')"
check('release_job_actual_push_head_hold', key(jobs['release'], 'if') == release_condition,
      key(jobs['release'], 'if'))
check('release_required_jobs', key(jobs['release'], 'needs') == '[qa, qt-gate, linux-smoke, release-gate]',
      key(jobs['release'], 'needs'))
check('release_gate_push_only_read_only', key(jobs['release-gate'], 'if') == "github.event_name == 'push'"
      and '      contents: read' in jobs['release-gate'] and 'contents: write' not in jobs['release-gate'])
check('release_cadence_is_fail_open_and_does_not_implement_hold', '[no release]' not in gate
      and "True, 0, f'gate error, publishing anyway:" in gate and 'THRESHOLD = 3' in gate)
check('publication_hold_does_not_skip_acceptance', all('[no release]' not in jobs[j]
      for j in ['qa', 'qt-gate', 'linux-package', 'linux-smoke', 'release-gate']))
check('linux_downstream_dependencies', key(jobs['linux-package'], 'needs') == '[qa, qt-gate]'
      and key(jobs['linux-smoke'], 'needs') == 'linux-package')
qt_matrix = re.findall(r'- os: (\S+)\n\s+repeat: (\d+)\n\s+shard: (\S+)', jobs['qt-gate'])
check('all_five_qt_matrix_legs_retained', qt_matrix == [('ubuntu-latest', '20', f'{i}/4') for i in range(1, 5)]
      + [('windows-latest', '5', '1/1')], qt_matrix)
check('windows_acceptance_commands_retained', all(command in jobs['qa'] for command in [
      'python -m pytest -q --junitxml=qa-results.xml', 'python -m ruff check src tests tools',
      'python tools/build_windows.py', 'tools/frozen_smoke.py', 'tools/test_windows_portable.ps1',
      'tools/package_windows_installer.py', 'tools/test_windows_installer.ps1']))
check('linux_both_frozen_smoke_lanes_retained', all(value in jobs['linux-smoke'] for value in [
      'ubuntu-22.04', 'ubuntu-24.04', 'sha256sum -c', '--self-test', 'xvfb-run',
      'python tools/frozen_smoke.py "$PWD/PatchTrace/PatchTrace"']))
check('pages_actual_push_head_hold', key(pages_jobs['deploy'], 'if') == deploy_condition
      and key(pages_jobs['deploy'], 'needs') == 'build', key(pages_jobs['deploy'], 'if'))
check('pages_build_remains_enabled', key(pages_jobs['build'], 'if') is None
      and '[no deploy]' not in pages_jobs['build'] and all(command in pages_jobs['build'] for command in [
          '--require-hashes --only-binary=:all: -r tools/site/requirements-ci.lock',
          '--noconftest --disable-plugin-autoload -q tests/test_site_*.py',
          'python tools/site/build_site.py', 'actions/upload-pages-artifact@']))
check('pages_has_no_pr_trigger', 'pull_request:' not in pages and 'workflow_dispatch:' in pages)
check('dispatch_only_checks_are_expected_skips', key(blocks(intel)['live-buildenv'], 'if') ==
      "github.event_name == 'workflow_dispatch'" and key(blocks(tier)['msvc-advisory'], 'if') ==
      "github.event_name == 'workflow_dispatch' && vars.TIER_R_MSVC == '1'")
check('backend_bundle_push_is_tag_only', "  push:\n    tags: ['v*']\n" in backend
      and 'branches:' not in backend.split('\npermissions:', 1)[0])

paths = git('diff', '--name-only', BASE, LOCAL).splitlines()
pages_changed = [p for p in paths if p == '.github/workflows/pages.yml' or p.startswith(('site/', 'tools/site/'))]
check('main_diff_matches_pages_path_filters', bool(pages_changed), pages_changed)
check('native_windows_ghidriff_is_applicable', any(p.startswith(('src/', 'tools/live_', 'tests/fixtures/'))
      or p == 'tools/seed_symbol_cache.py' for p in paths))

workflow_paths = git('ls-tree', '-r', '--name-only', LOCAL, '.github/workflows').splitlines()
push_workflows, write_capable = [], []
for p in workflow_paths:
    if not p.endswith(('.yml', '.yaml')):
        continue
    text = source(p) if p not in {item['path'] for item in sources} else git('show', f'{LOCAL}:{p}')
    trigger = re.search(r'^on:\n(.*?)(?=^[^ \n#]|\Z)', text, re.M | re.S)
    if trigger and re.search(r'^  push:', trigger[1], re.M):
        push_workflows.append({'path': p, 'main_branch_trigger': 'branches: [main' in trigger[1]})
    if re.search(r'^\s+(?:contents|pages|id-token): write', text, re.M):
        write_capable.append(p)
check('write_capable_workflow_inventory', sorted(write_capable) == sorted([
      '.github/workflows/qa-windows.yml', '.github/workflows/pages.yml', '.github/workflows/backend-bundle.yml']),
      write_capable)

snapshot = receipt('final-ae69-qualification/jobs-snapshot-011.json')
check('qualification_snapshot_source_matches', snapshot['head'] == snapshot['current_pr_head'] == HEAD
      and snapshot['current_pr_base'] == BASE and snapshot['current_pr_merge'] == MERGE)
qa_jobs = next(o['jobs'] for o in snapshot['observations'] if o['run_id'] == 44881740990)
if isinstance(qa_jobs, dict):
    qa_jobs = qa_jobs['jobs']
qa_summary = [{k: j.get(k) for k in ['id', 'name', 'status', 'conclusion']} for j in qa_jobs]
nonqa = receipt('final-ae69-qualification/non-qa-final-run-records.json')
intel_receipt = receipt('final-ae69-intel/summary.json')
check('seven_nonqa_workflows_completed', len(nonqa['runs']) == 6 and all(
      r['head_sha'] == HEAD and r['status'] == 'completed' and r['conclusion'] == 'success'
      for r in nonqa['runs']) and intel_receipt['head_sha'] == HEAD
      and intel_receipt['workflow_conclusion'] == 'success')
intel_summary = {os: {'pytest_counts': p['pytest_counts'], 'checks': {
    k: {z: v.get(z) for z in ['status', 'version', 'reason']} for k, v in p['checks'].items()}}
    for os, p in intel_receipt['platforms'].items()}
check('intel_windows_namespace_remains_blocked',
      intel_summary['windows']['checks']['floss-offline']['status'] == 'blocked')

artifact_records = receipt('final-ae69-qualification/artifact-records-tier-r.json')
verified_artifacts, tier_summary, windows_summary = [], {}, {}
for item in artifact_records['artifacts']:
    if item['name'] not in ['tier-r-aggregate', 'tier-r-windows-advisory']:
        continue
    p = EVIDENCE / 'final-ae69-qualification/artifacts' / f"{item['id']}.zip"
    data = p.read_bytes()
    with zipfile.ZipFile(p) as z:
        crc = z.testzip()
        if item['name'] == 'tier-r-aggregate':
            tier_summary = json.loads(z.read('ci-summary.json'))
        else:
            win = json.loads(z.read('shard-0.json'))
            windows_summary = {'cases': len(win['cases']), 'reports': len(win['reports']),
                               'status_reasons': sorted({(c['status'], c['reason']) for c in win['cases']})}
    good = digest(data) == item['digest'].removeprefix('sha256:') and crc is None
    verified_artifacts.append({'name': item['name'], 'id': item['id'], 'bytes': len(data),
                               'sha256': digest(data), 'api_digest_and_crc_match': good})
check('tier_r_selected_artifact_identity', all(a['api_digest_and_crc_match'] for a in verified_artifacts))
engine = tier_summary['engines'][0]
check('tier_r_existing_warning_preserved', tier_summary['status'] == 'warning'
      and (engine['attempted'], engine['completed'], engine['failed']) == (11, 5, 6)
      and tier_summary['report_sha256'] in historical)
check('tier_r_windows_findings_not_passes', windows_summary == {
      'cases': 11, 'reports': 0, 'status_reasons': [('findings', 'exit 1')]})

report = {
    'generated_utc': datetime.now(timezone.utc).isoformat(),
    'scope': 'Static promotion controls and existing source-specific receipts only; no project tests, native tools, target execution, CI dispatch or source/ref mutations.',
    'source': {'local': LOCAL, 'head': HEAD, 'tree': TREE, 'base': BASE, 'synthetic_merge': MERGE},
    'pre_main_eligibility': 'PENDING: full QA, four Qt legs, downstream Linux package and two frozen smoke lanes in snapshot 011; final qualification is root-owned.',
    'static_check_count': len(checks), 'all_static_checks_pass': all(c['passed'] for c in checks),
    'checks': checks, 'sources': sorted(sources, key=lambda p: p['path']), 'receipt_inputs': inputs,
    'changed_path_count': len(paths), 'pages_path_matches': pages_changed,
    'push_workflows': push_workflows, 'write_capable_workflows': write_capable,
    'qa_snapshot_observed': snapshot['observed'], 'qa_snapshot': qa_summary,
    'nonqa_observed': nonqa['observed'],
    'nonqa_runs': [{k: r[k] for k in ['id', 'name', 'head_sha', 'status', 'conclusion']}
                   for r in nonqa['runs']],
    'intel_run': intel_receipt['workflow_run_id'], 'intel': intel_summary,
    'tier_r': tier_summary, 'tier_r_windows_advisory': windows_summary,
    'verified_selected_artifacts': verified_artifacts,
    'limitations': [
        'Existing captured REST evidence is used; this checker does not freshly poll GitHub.',
        'Static inspection does not execute the GitHub expression engine or prove a hosted deployment hold.',
        'The cadence tool can output publish=true while the release job correctly skips under [no release].',
        'Expected-head REST guard constrains the PR head, not the base; root must refresh main and requalify a changed merge tree.',
        'Existing warnings, blocked namespace checks, dispatch-only skips and broader release/accuracy gates are not converted to passes.',
    ],
}
(OUT / 'source-controls.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'checks': len(checks), 'passed': sum(c['passed'] for c in checks),
                  'failed': [c['id'] for c in checks if not c['passed']],
                  'report': str(OUT / 'source-controls.json')}))
raise SystemExit(0 if report['all_static_checks_pass'] else 1)
