# PR349 final main-promotion control review

## Disposition

**No new defect found in the inspected publication holds. Merge eligibility is still pending.** The captured 08:07:47 UTC QA snapshot has both full QA legs and four Qt legs running; Linux packaging and both Ubuntu frozen smoke jobs must complete afterward. This review does not replace root's final qualification or waive any acceptance requirement.

Reviewed immutable source:

| Identity | Value |
| --- | --- |
| PR349 head | `ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e` |
| Source tree | `c3f09435deb99ca0ddb3406e27ab315dba7740cf` |
| Equivalent clean local commit | `06ea27de0936f1f8eb1aeca264833c21845a7f36` |
| Captured base main | `fdc2696c23bdbfe7668348f25e3b336ce33039f7` |
| PR synthetic merge | `66f153a8372ad93c72e2f5b10365dcf210681684`, same tree |

The read-only checker completed **26/26 source/evidence checks**. These are static inspections and receipt checks, not project tests or hosted expression-engine execution. Source blob IDs, sizes, hashes, receipt hashes and observed states are in [source-controls.json](source-controls.json); [check_controls.py](check_controls.py) reproduces the inspection without running repository code. The checker initially had one missing closing parenthesis; correcting only this private checker allowed its first complete inspection to finish. No source, refs, workflows, CI, native tool or analyzed target were changed or executed.

## Concrete gate checklist

### Before the REST merge

1. Refresh PR349 head, main, mergeability and all applicable check/job results. Require the head above and the expected main. The REST `sha` parameter guards the PR head; it does not guard a concurrently moving base. A changed main or merge tree requires renewed qualification. The captured REST state was open, unmerged and `unstable` while tests ran.
2. Require both complete `qa` jobs, including full pytest, Ruff and actual Windows build, frozen EXE smoke, portable ZIP extraction outside checkout, pinned NSIS installer creation, installation, launch and uninstall. Do not stop at a pytest success line. The Windows memory-cap measurement is explicitly non-gating; inspect any failure without promoting it to a pass.
3. Require all **five** Qt legs: Ubuntu repeats20 shards1/4–4/4 and Windows repeats5 shard1/1. Then require `linux-package` and **both** `linux-smoke` jobs on Ubuntu22.04 and24.04, including archive digest, offscreen/xcb self-tests and the full extracted application's `frozen_smoke.py` check. The package waits for both QA and Qt; the two smoke lanes wait for that package.
4. Confirm applicable native checks and their retained artifacts on this source. Native Windows Ghidriff is explicitly required by the Windows acceptance spec for the changed source paths. It is **not** in the release job's `needs`; that independent owner gate must be checked separately. Advisory green status must not hide an actual failure.
5. Reconcile all new failures, cancellations, timed-out jobs, unexpected skips and blocking independent findings before promotion. Preserve known blocked/advisory/dispatch-only boundaries below. Existing CODEX-5, provenance, historical review, native/manual/trust/accessibility and separate L1/L2/L3 release gates do not become passes through integration. The latest current-scope handoff authorizes only qualified main integration with publishing holds; it makes no project-completion claim.

### REST merge payload and result

Use the already planned `PUT /repos/djshellshoxxx/patchtrace/pulls/349/merge`, `merge_method=merge`, with `sha=ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e`. Put **`[no release] [no deploy]` in the resulting merge commit title/body**. PR metadata or ancestor messages alone do not control either push hold. Avoid whole-workflow CI-skip markers anywhere in that complete message. No tag creation or workflow dispatch is part of this gate.

After success, fetch the actual resulting main commit and verify both markers, parents and tree. Expected parents are the refreshed unchanged base and PR head; expected tree is `c3f09435deb99ca0ddb3406e27ab315dba7740cf`. Keep the actual resulting merge SHA distinct from the PR synthetic merge SHA.

### After the main push

| Control | What source actually enforces | Required observation |
| --- | --- | --- |
| Release cadence | `release-gate` runs on push and is read-only. `tools/release_gate.py` may return `publish=true` at the third milestone, for a release marker/tag, missing/unreachable prior beta or any internal error. It does **not** implement `[no release]`. | Record its real output/reason. `publish=false` is **not** required for the hold to work. |
| GitHub release | `release` requires QA, Qt, Linux smoke and release-gate, and separately rejects a push head message containing `[no release]`. | Verify the actual main push's `release` job is **skipped**, even if cadence returns true. A green PR with skipped push-only gate does not establish this outcome. |
| Pages | Main push matching `site/**`, `tools/site/**` or `pages.yml` runs build/tests/artifact upload. Only `deploy` checks `[no deploy]`; it also needs build success. | Inspect the matching push run: build enabled, deploy **skipped**. Candidate changes include all three path families. Observe GitHub's actual trigger selection. |
| Other main checks | QA, Tier R, native Ghidriff, live Rizin and unified extraction have main-push triggers with their existing path filters. | Record new main-source results separately; do not copy PR outcomes into uncompleted main jobs. |
| Separate backend publisher | Backend-bundle push trigger is `v*` tags only, with separate manual/reusable workflow inputs. | A plain main merge does not invoke this publisher. Do not create a tag or dispatch it. |

The Pages marker is push-only: `workflow_dispatch` deliberately retains deployment behavior. It must not be used to validate this hold. Both markers apply to the actual push, not every later push. The only workflows in this source with publishing write permissions are qa-windows, Pages and backend-bundle.

## Observed limits that remain visible

At 08:08:50 UTC all six observed non-QA workflows completed successfully; the separate Intel receipt brings the total to seven. Native Ghidriff has five successful jobs; Rizin, BinDiff, optional-dependency and unified workflows each have their observed successful OS jobs. These aggregate statuses are not blanket native-acceptance claims.

| Observation | Exact disposition |
| --- | --- |
| Intel run44881741040 | Linux4passed; Windows3passed/1skipped. Capa9.4.0, FLOSS3.1.1 and DIE3.21 actually pass synthetic-pair checks on both OSes. Windows FLOSS offline artifact remains `blocked`: `unshare -rn` unavailable. |
| Windows BinDiff | Its actual log retains the Linux-only network-namespace check as BLOCKED/manual on Windows. Workflow success does not establish Windows offline behavior. |
| Tier R run44881741002 | Aggregate is **warning**:11 attempted engine pairs,5 completed,6 failed,0 blocked; corpus outcomes11ok/1skipped are a different count. Canonical report digest `364c87d3a16c6cca92c325eb2f4d593c5e9562561e39b787004c1d6248642b4a` equals the previously documented gap. This is retained coverage debt, not new successful coverage. |
| Tier R Windows advisory | Artifact contains11 `findings`, each `exit 1`, and zero substantive reports. Never describe these as11 native passes. |
| Cache scope | Existing receipts show both Linux shards rehashed their restored Rizin archives. Selected engine is only Rizin; skipped Ghidra installation/cache steps establish no Ghidra cache acceptance. |
| Expected job skips | PR `release-gate`, Intel `live-buildenv` and Tier R MSVC advisory are excluded by their event conditions. MSVC additionally requires repository variable `TIER_R_MSVC=1`. These are not test passes or newly missing PR jobs. |

The seven green workflow conclusions do not override these records, the still-running QA, or the separate release/accuracy gates. Root owns the final eligibility decision and subsequent main-push observation.

## Evidence and ownership

Primary governing sources: `AGENTS.md`; Windows acceptance spec sections1.1/1.2; Pages deployment-control and dependency-isolation specs; current engineering handoff; current workflow and release-gate source. Exact blob/hash references are in the JSON. Native/CI observations come from the already captured `final-ae69-intel` and `final-ae69-qualification` evidence; no duplicate API polling or CI execution was used. The two selected Tier R ZIPs were independently checked against their API digests and ZIP CRCs.

**Bounded review complete; ownership of `evidence/final-main-gate-review` released to root.** The isolated CODEX-5 author scope was not accessed or changed.
