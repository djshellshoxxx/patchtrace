# Independent historical license-gate review

**Verdict: no blocker found in the proposed classification, `semantically-integrated-no-unique-missing-delta-found`, for the complete contribution of `claude/bundle-license-gate`.** No source recovery is needed for the reviewed branch scope. This conclusion neither authorizes ref deletion nor revises the historical 181 unmatched / 16 patch-equivalent census.

## Source and full scope

| Identity | Exact value |
| --- | --- |
| Donor head | `d3617acf9af7834582b4962a8c149969a7d55a22` |
| Donor tree | `af31f6eb189620941de8db8718f203d8b8dce77c` |
| Comparison baseline | `ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e` |
| Baseline tree | `c3f09435deb99ca0ddb3406e27ab315dba7740cf` |
| Sole merge base | `21a005e242177f07a984937a7cd924e826c17b9f` |
| Retained test-execution source | `5b5328ee83ee4990b3311f7ac90e2f5e5f76f800` |
| Test-execution tree | `1e12edd510399fd92da6867cd071394ceb7fc95b` |

Independent Git reads reproduce exactly **11 changed paths, 647 insertions and 34 deletions**, and the four branch-side-only commits: `246eed794dbda3d3ebc6f2a8f29736ec09b94fb6`, `c9a01b6f4e6e51b35b0685dcac96c4cdc1400101`, merge `0016de7264a1c9cd651a469eb49f01ad1ba22773`, and final formatting commit `d3617acf9af7834582b4962a8c149969a7d55a22`. There are three unmatched nonmerge commits. The merge's remerge diff is empty; the final Windows-builder commit preserves its parent's complete module AST.

The worker's retained GitHub responses identify the same branch head and PR65 as closed/merged at `2026-10-15T05:42:17Z`, with merge `00db4c9c0ce53d1c4c556f3530e8c54163e91e95`. That merge is independently verified as an ancestor of the exact baseline. This reviewer did not repeat the remote refresh. The original branch's unmatched patch identities are consistent with this separate integration history and do not imply missing implementation.

All three sets of 11 retained source snapshots—merge base, donor and baseline—match their Git objects, hashes and lengths. The 11 relevant execution paths, the entire `src/` tree and all workflows match the baseline. Relevant test configuration, helper/runtime imports and source-binding receipts also agree. No complete-tree equivalence between baseline and execution is claimed; the separately reviewed CODEX-5 additions remain distinct.

## Semantic accounting

The independent symbol comparison confirms **69 of 74 changed top-level symbols are AST-identical**, with no absent changed symbols. The total includes eight named module assignments; it is not a count of 74 functions. The changed module-level constants, import and docstring are also retained.

| Exception | Independent finding |
| --- | --- |
| `build_backend` | The complete license validation, approval decision, NOTICE generation and inventory-write block is retained verbatim. Reviewed differences add jlink reduction, `keep_fid`/additional strip rules and runtime-policy output. |
| Linux builder `main` | The **entire `if args.full` attachment branch** is AST-identical, including `release=args.release`, checks and archive creation. Other differences add resource and installed-file-list checks. |
| Windows builder `main` | The **entire `if args.full` attachment branch** is AST-identical. Other differences concern resources/version identity, notices, launcher validation and optional dependency inventory. |
| Pin-checker `main` | The only AST change is replacing ordinary JSON loading with the current strict `parse_pin` call. Normalizing only that assignment makes the entire function equal. |
| Strip regression | The only AST change lowers the aggregate stripped-file minimum from five to four for later jlink behavior. The explicit GPL-directory absence assertion and stripped-byte lower bound remain unchanged. |

The entire payload-validation test module is byte-identical. The original `license_policy` JSON subtree, GPL strip/keep constraints and full policy-notice section are unchanged. Independent YAML parsing confirms all workflow semantics are equal after normalizing only Action revision suffixes; the full license-gate step, including its condition, environment and script, is exactly equal.

The original integration differs from the donor on only three reviewed paths: the unrelated CODEX-9 xfail removal and two optional `iced-x86` collection additions. The retained exact patch supports that explanation. The complete 11-path review covers policy data, notices, workflow and imports in addition to the Python symbol comparison.

## Test provenance and preserved results

No project tests were rerun by this independent reviewer. Existing raw JUnit, logs, selectors, source hashes and execution receipts reconcile as follows:

| Retained run | Reconciled result | Scope |
| --- | --- | --- |
| Maintained source/current pin | **251 passed, 1 ordinary skip**, zero failures/errors; 252 distinct cases | Exact relevant baseline-equivalent bytes at the frozen V3 checkout. The existing source-to-wheel test skipped for its setuptools/wheel prerequisite; source binding records wheel absent. |
| Unchanged donor regressions | **51 passed**, zero skips/failures/errors; exactly 32 changed test functions | All four original donor test modules are unchanged. Eight maintained tool files and the exact original donor pin fixture match their stated Git sources. |

The donor selector set equals the complete set of branch-changed test functions. The historical pin fixture is explicitly distinguished from the current shipping pin; the two runs overlap and must not be added. The existing isolated import and editable-install records bind runtime imports to exact baseline-equivalent bytes. Original donor assumptions and unselected functions remain preserved in the untouched modules.

The reviewer initially used a function/class-only symbol enumerator, which omitted the author's eight correctly counted named assignments. The assertion failure, original verifier and diagnosis are preserved. Extending only the reviewer enumerator resolved the accounting discrepancy; no source or author-evidence change was needed.

## Archive and preservation

The original archive is **1,292,224 bytes, 114 unique members**, SHA-256 `a86b0478942988b249857c600a964cfb521b096cebbfe69ddb47f6e7e2ae8769`. All **113 manifest-listed payloads** match both their recorded hash and retained disk file, and the embedded/external manifests are identical. ZIP CRC checks pass.

The retained history pack verifies successfully and contains exactly the **39 Git objects** reachable from the donor above the recorded prerequisite base. The original empty-bundle attempt remains a separate retained failure; no ref was created to work around it. Recovery requires the stated base history.

The original source worktree stayed clean. This reviewer changed no source, test, workflow, environment, ledger, PR, branch or other ref. Only this independent evidence directory was written. No legal, native packaging, final-artifact, source-offer-completeness or new owner-approval claim follows from this source classification.

`review.json` records the exact checks and counts. `verify_accounting.py` reproduces the bounded Git/AST/JSON/YAML/XML/hash verification without executing project or donor source. The original worker archive remains the full portable source/test/provenance record.
