"""Read-only independent verification of the retained historical license review."""

import ast
import copy
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import xml.etree.ElementTree as ET
import zipfile

import yaml


WORK = Path('/workspace/scratch/837fe19aae3a/repair-codex5-command-audit-v3')
EVIDENCE = Path('/workspace/scratch/837fe19aae3a/evidence/historical-license-review')
OUT = Path(__file__).resolve().parent
DONOR = 'd3617acf9af7834582b4962a8c149969a7d55a22'
BASELINE = 'ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e'
EXECUTION = '5b5328ee83ee4990b3311f7ac90e2f5e5f76f800'
BASE = '21a005e242177f07a984937a7cd924e826c17b9f'
SQUASH = '00db4c9c0ce53d1c4c556f3530e8c54163e91e95'


def digest(value):
    return hashlib.sha256(value).hexdigest()


def git(*args):
    return subprocess.run(['git', '-C', str(WORK), *args], check=True, capture_output=True).stdout


def source(commit, path):
    return git('show', f'{commit}:{path}')


def ast_text(node):
    return ast.dump(node, include_attributes=False)


def symbols(content):
    return {node.name: node for node in ast.parse(content).body
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))}


def function(commit, path, name):
    return symbols(source(commit, path))[name]


def json_file(name):
    return json.loads((EVIDENCE / name).read_text())


def normalize_actions(value):
    if isinstance(value, dict):
        return {key: (item.split('@', 1)[0] if key == 'uses' and isinstance(item, str)
                      else normalize_actions(item)) for key, item in value.items()}
    if isinstance(value, list):
        return [normalize_actions(item) for item in value]
    return value


classification = json_file('classification.json')
census = json_file('source-census.json')
start_status = git('status', '--porcelain=v1').decode()
assert not start_status
assert git('rev-parse', 'HEAD').decode().strip() == EXECUTION
paths = git('diff', '--name-only', BASE, DONOR).decode().splitlines()
commits = git('rev-list', '--reverse', f'{BASELINE}..{DONOR}').decode().splitlines()
nonmerges = git('rev-list', '--reverse', '--no-merges', f'{BASELINE}..{DONOR}').decode().splitlines()
assert paths == classification['accounted_paths'] == census['changed_paths']
assert len(paths) == 11
assert commits == classification['unique_commits']
assert nonmerges == classification['unique_nonmerge_commits']
assert git('merge-base', '--all', BASELINE, DONOR).decode().splitlines() == [BASE]
git('merge-base', '--is-ancestor', SQUASH, BASELINE)
assert not git('show', '--remerge-diff', '--format=', '0016de7264a1c9cd651a469eb49f01ad1ba22773')
assert ast_text(ast.parse(source(DONOR, 'tools/build_windows.py'))) == ast_text(
    ast.parse(source(DONOR + '^', 'tools/build_windows.py')))

snapshots = []
for row in census['paths']:
    path = row['path']
    for label, commit in [('merge-base', BASE), ('donor', DONOR), ('baseline', BASELINE), ('execution', EXECUTION)]:
        content = source(commit, path)
        expected = row[label]
        assert len(content) == expected['bytes']
        assert digest(content) == expected['sha256']
        assert git('rev-parse', f'{commit}:{path}').decode().strip() == expected['git_blob']
        if label != 'execution':
            assert (EVIDENCE / 'source' / label / path).read_bytes() == content
        snapshots.append({'path': path, 'label': label, **expected})
    assert source(BASELINE, path) == source(EXECUTION, path)
assert not git('diff', '--name-only', BASELINE, EXECUTION, '--', 'src', '.github/workflows')

changed_symbols = []
module_nodes = []
donor_test_selectors = []
claimed_symbols = json_file('symbol-comparison.json')
for path in paths:
    if not path.endswith('.py'):
        continue
    prior = symbols(source(BASE, path))
    donor = symbols(source(DONOR, path))
    current = symbols(source(BASELINE, path))
    assert not set(prior).difference(donor)
    rows = []
    for name, node in donor.items():
        if name in prior and ast_text(node) == ast_text(prior[name]):
            continue
        status = 'absent' if name not in current else (
            'same_ast' if ast_text(node) == ast_text(current[name]) else 'different_ast')
        row = {'symbol': name, 'baseline_status': status}
        rows.append(row)
        changed_symbols.append({'path': path, **row})
        if path.startswith('tests/') and name.startswith('test_'):
            donor_test_selectors.append(f'{path}::{name}')
    assert sorted(rows, key=lambda row: row['symbol']) == claimed_symbols[path]['donor_changed_symbols']
    before = {ast_text(node) for node in ast.parse(source(BASE, path)).body}
    now = {ast_text(node) for node in ast.parse(source(BASELINE, path)).body}
    for node in ast.parse(source(DONOR, path)).body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)) or ast_text(node) in before:
            continue
        assert ast_text(node) in now
        module_nodes.append({'path': path, 'node': ast.unparse(node), 'identical_current_ast': True})
assert len(changed_symbols) == 74
assert sum(row['baseline_status'] == 'same_ast' for row in changed_symbols) == 69
assert not any(row['baseline_status'] == 'absent' for row in changed_symbols)

exceptions = {}
for path in ('tools/build_linux.py', 'tools/build_windows.py'):
    nodes = []
    for commit in (DONOR, BASELINE):
        fn = function(commit, path, 'main')
        matches = [node for node in fn.body if isinstance(node, ast.If)
                   and ast_text(node.test) == ast_text(ast.parse('args.full', mode='eval').body)]
        assert len(matches) == 1
        nodes.append(matches[0])
    assert ast_text(nodes[0]) == ast_text(nodes[1])
    exceptions[path + ':main'] = {'entire_args_full_attachment_branch_ast_identical': True}

donor_main = copy.deepcopy(function(DONOR, 'tools/check_backend_pin.py', 'main'))
current_main = copy.deepcopy(function(BASELINE, 'tools/check_backend_pin.py', 'main'))
replacements = []
for fn in (donor_main, current_main):
    targets = [node for node in ast.walk(fn) if isinstance(node, ast.Assign)
               and len(node.targets) == 1 and isinstance(node.targets[0], ast.Name)
               and node.targets[0].id == 'data']
    assert len(targets) == 1
    replacements.append(ast.unparse(targets[0].value))
    targets[0].value = ast.Constant(value='PIN_PARSE')
assert ast_text(donor_main) == ast_text(current_main)
assert replacements == ["json.loads(args.pin.read_text(encoding='utf-8'))", 'parse_pin(args.pin.read_bytes())']
exceptions['tools/check_backend_pin.py:main'] = {'sole_normalized_difference': replacements}

donor_strip = copy.deepcopy(function(DONOR, 'tests/test_build_backend_bundle.py', 'test_strip_rules_remove_docs_and_other_os_natives'))
current_strip = function(BASELINE, 'tests/test_build_backend_bundle.py', 'test_strip_rules_remove_docs_and_other_os_natives')
minimums = [node for node in ast.walk(donor_strip) if isinstance(node, ast.Compare)
            and isinstance(node.left, ast.Attribute) and node.left.attr == 'stripped_files']
assert len(minimums) == 1 and ast.literal_eval(minimums[0].comparators[0]) == 5
minimums[0].comparators[0] = ast.Constant(value=4)
assert ast_text(donor_strip) == ast_text(current_strip)
exceptions['tests/test_build_backend_bundle.py:strip_test'] = {
    'only_change': 'stripped_files minimum 5 to 4', 'gpl_absence_assertion_unchanged': True}

preserved = (EVIDENCE / 'preserved-build-license-block.txt').read_text().removesuffix('\n')
assert preserved in source(DONOR, 'tools/build_backend_bundle.py').decode()
assert preserved in source(BASELINE, 'tools/build_backend_bundle.py').decode()
exceptions['tools/build_backend_bundle.py:build_backend'] = {
    'license_notice_inventory_block_retained': True, 'block_sha256': digest(preserved.encode()),
    'reviewed_later_changes': ['jlink reduction', 'keep_fid and additional strip rules', 'write_runtime_policy']}

donor_policy = json.loads(source(DONOR, 'tools/backend_pin.json'))
current_policy = json.loads(source(BASELINE, 'tools/backend_pin.json'))
assert donor_policy['license_policy'] == current_policy['license_policy']
assert 'GPL/**' in current_policy['strip']['ghidra'] and 'GPL/**' not in current_policy['strip']['keep']
workflow_path = '.github/workflows/backend-bundle.yml'
donor_workflow = yaml.load(source(DONOR, workflow_path), Loader=yaml.BaseLoader)
current_workflow = yaml.load(source(BASELINE, workflow_path), Loader=yaml.BaseLoader)
assert normalize_actions(donor_workflow) == normalize_actions(current_workflow)
gates = [next(step for step in workflow['jobs']['pin']['steps']
              if step.get('name', '').startswith('Pin release gate'))
         for workflow in (donor_workflow, current_workflow)]
assert gates[0] == gates[1]
sections = [source(commit, 'docs/notices.md').decode().split('## Full-bundle licence policy', 1)[1].split('## Known runtime', 1)[0]
            for commit in (DONOR, BASELINE)]
assert sections[0] == sections[1]
assert source(DONOR, 'tests/test_build_full_variants.py') == source(BASELINE, 'tests/test_build_full_variants.py')

archive = EVIDENCE / 'historical-license-review-d3617acf.zip'
assert archive.stat().st_size == 1292224
assert digest(archive.read_bytes()) == 'a86b0478942988b249857c600a964cfb521b096cebbfe69ddb47f6e7e2ae8769'
with zipfile.ZipFile(archive) as zipped:
    assert len(zipped.namelist()) == len(set(zipped.namelist())) == 114
    assert zipped.testzip() is None
    manifest = zipped.read('MANIFEST.sha256')
    assert manifest == (EVIDENCE / 'MANIFEST.sha256').read_bytes()
    members = []
    for line in manifest.decode().splitlines():
        expected, name = line.split('  ', 1)
        archived = zipped.read(name)
        assert digest(archived) == expected
        assert archived == (EVIDENCE / name).read_bytes()
        members.append(name)
    assert set(members) | {'MANIFEST.sha256'} == set(zipped.namelist())

results = {}
for kind in ('maintained', 'donor'):
    xml = ET.parse(EVIDENCE / f'{kind}.xml')
    cases = list(xml.iter('testcase'))
    counts = {'passed': 0, 'skipped': 0, 'failed': 0, 'errors': 0}
    ids = []
    skips = []
    function_selectors = set()
    for case in cases:
        name = case.attrib['name']
        identity = case.attrib['classname'] + '::' + name
        ids.append(identity)
        function_selectors.add(case.attrib['classname'].replace('.', '/') + '.py::' + name.split('[', 1)[0])
        if case.find('failure') is not None:
            counts['failed'] += 1
        elif case.find('error') is not None:
            counts['errors'] += 1
        elif case.find('skipped') is not None:
            counts['skipped'] += 1
            skips.append({'identity': identity, 'attributes': case.find('skipped').attrib, 'text': case.find('skipped').text})
        else:
            counts['passed'] += 1
    assert len(ids) == len(set(ids))
    receipt = json_file(f'{kind}-receipt.json')
    assert receipt['returncode'] == 0
    if kind == 'maintained':
        assert counts == {'passed': 251, 'skipped': 1, 'failed': 0, 'errors': 0}
        assert receipt['head'] == EXECUTION
        assert not receipt['status_before'] and not receipt['status_after']
        for path, expected in receipt['selector_source_sha256'].items():
            assert digest(source(BASELINE, path)) == digest(source(EXECUTION, path)) == expected
    else:
        assert counts == {'passed': 51, 'skipped': 0, 'failed': 0, 'errors': 0}
        selected = [arg for arg in receipt['command'] if arg.startswith('tests/') and '::' in arg]
        assert len(selected) == len(set(selected)) == len(donor_test_selectors) == 32
        assert set(selected) == set(donor_test_selectors) == function_selectors
        assert not receipt['frozen_worktree_before'] and not receipt['frozen_worktree_after']
        for binding in receipt['source_bindings']:
            path = binding['path']
            commit = DONOR if path.startswith('tests/') or path == 'tools/backend_pin.json' else BASELINE
            exact = source(commit, path)
            assert exact == (EVIDENCE / 'donor-replay' / path).read_bytes()
            assert digest(exact) == binding['sha256']
            if commit == BASELINE:
                assert exact == source(EXECUTION, path)
    results[kind] = {'counts': counts, 'distinct_case_count': len(ids), 'distinct_function_count': len(function_selectors), 'skips': skips}

for row in json_file('context-source-binding.json'):
    content = source(BASELINE, row['path'])
    assert digest(content) == row['sha256']
    assert (content == source(EXECUTION, row['path'])) == row['execution_bytes_identical']
for module in json_file('source-binding.json')['imports'].values():
    path = Path(module['path']).relative_to(WORK).as_posix()
    assert digest(source(BASELINE, path)) == digest(source(EXECUTION, path)) == module['sha256']

ref = json.loads(json_file('fresh-branch-ref.json')['structuredContent']['content'])
pr = json.loads(json_file('fresh-pr65.json')['structuredContent']['content'])
assert ref['object']['sha'] == DONOR
assert pr['number'] == 65 and pr['merged'] is True and pr['state'] == 'closed'
assert pr['head']['sha'] == DONOR and pr['merge_commit_sha'] == SQUASH
pack = EVIDENCE / 'original-donor-history.pack'
history = json_file('history-preservation.json')
assert digest(pack.read_bytes()) == history['pack_sha256']
verified_pack = subprocess.run(['git', 'verify-pack', '-v', str(EVIDENCE / 'original-donor-history.idx')], check=True, capture_output=True, text=True)
pack_objects = [line.split()[0] for line in verified_pack.stdout.splitlines() if re.match(r'^[0-9a-f]{40} (?:commit|tree|blob|tag) ', line)]
assert len(pack_objects) == history['object_count'] == 39
assert history['ref_inventory_sha256_before'] == history['ref_inventory_sha256_after']
assert not git('status', '--porcelain=v1')

review = {
    'reviewed_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'verdict': 'No blocker found for semantically-integrated-no-unique-missing-delta-found, limited to this complete historical branch contribution.',
    'branch': classification['branch'], 'donor': DONOR, 'baseline': BASELINE, 'execution': EXECUTION,
    'donor_tree': git('rev-parse', DONOR + '^{tree}').decode().strip(),
    'baseline_tree': git('rev-parse', BASELINE + '^{tree}').decode().strip(),
    'execution_tree': git('rev-parse', EXECUTION + '^{tree}').decode().strip(),
    'merge_base': BASE, 'complete_changed_paths': paths, 'unique_commits': commits,
    'unique_nonmerge_commits': nonmerges,
    'branch_shortstat': git('diff', '--shortstat', BASE, DONOR).decode().strip(),
    'source_snapshot_checks': snapshots,
    'changed_python_symbols': changed_symbols,
    'changed_symbol_counts': {'total': 74, 'same_ast': 69, 'reviewed_exceptions': 5, 'absent': 0},
    'module_scope_changes': module_nodes,
    'semantic_exception_checks': exceptions,
    'policy_subtree_exact': True, 'license_gate_step_exact': gates[0],
    'parsed_workflow_equal_except_action_revisions': True,
    'policy_notice_section_exact': True, 'full_payload_test_module_exact': True,
    'all_11_owned_paths_src_and_workflows_equal_baseline_execution': True,
    'maintained_and_historical_donor_receipts': results,
    'donor_test_functions': sorted(donor_test_selectors),
    'replay_source_bindings_verified': 13,
    'retained_ref_sha': ref['object']['sha'],
    'retained_pr65': {key: pr[key] for key in ('state', 'merged', 'merged_at', 'merge_commit_sha')},
    'pr65_merge_ancestor_of_baseline': True,
    'archive': {'path': str(archive), 'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes()), 'members': 114, 'verified_manifest_members': len(members), 'disk_payloads_equal_archive': True},
    'history_pack': {'verified_objects': len(pack_objects), 'sha256': digest(pack.read_bytes()), 'prerequisite': BASE, 'retained_original_empty_bundle_failure': history['prior_bundle_attempt']},
    'reviewed_classification_sha256': digest((EVIDENCE / 'classification.json').read_bytes()),
    'reviewed_report_sha256': digest((EVIDENCE / 'REVIEW.md').read_bytes()),
    'review_script_sha256': digest(Path(__file__).read_bytes()),
    'source_status_before': start_status,
    'source_status_after': git('status', '--porcelain=v1').decode(),
    'limits': [
        'Tests were not rerun by the independent reviewer. Counts were reconciled from preserved raw JUnit, logs, selectors and exact source bindings.',
        'Maintained 251-pass/1-skip and historical donor 51-pass runs overlap; do not add them.',
        'Historical donor replay uses an original pin fixture and maintained tool bytes; it is not current shipping-pin or native acceptance.',
        'Four implementation extensions and one jlink-related strip-count test adjustment are accounted for; not all 74 symbols are byte-identical.',
        'The committed approval record is historical evidence only; no approval was obtained or expanded.',
        'No native build, final-artifact, source-offer-completeness or legal acceptance is inferred.',
        'Original 181/16 census unchanged; one named whole-branch contribution is classified without ref deletion or broader backlog closure.',
        'The worker retained fresh API responses. This independent review did not perform another network refresh.',
    ],
    'operations': {'project_tests_run': 0, 'source_edits': 0, 'environment_changes': 0, 'remote_requests': 0, 'ref_changes': 0, 'pr_changes': 0, 'ledger_changes': 0, 'evidence_only_writes': True},
}
(OUT / 'review.json').write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps({'verdict': review['verdict'], 'symbols': review['changed_symbol_counts'], 'results': results, 'archive': review['archive'], 'review_sha256': digest((OUT / 'review.json').read_bytes())}, indent=2))
