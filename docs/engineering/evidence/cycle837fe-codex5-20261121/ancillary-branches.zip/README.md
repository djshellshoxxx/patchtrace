# Two newly discovered ancillary branches

Current reference: ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e.

Build environment donor09f07582 is superseded by the reviewed C4 implementation. Whole panel-model AST agrees after keyword-order normalization; tooltip IDs and all other tooltip-module code agree, with only five descriptions differing. Seven unchanged donor tests pass against current source. Current real-controller/host/copy/audit coverage remains.

Initial CI evidence donor566c43cd is archived as unique historical evidence, not source work or current acceptance. All11 payloads and original manifests remain; raw/compressed metadata equality and hashes pass.

No runtime, test or workflow was modified, and no Git ref was changed. Original181/16 semantic backlog is unchanged. These are later-added ancillary refs.
