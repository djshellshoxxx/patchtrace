"""Preserve original Git objects in a pack without creating or moving any ref."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/workspace/scratch/837fe19aae3a/repair-codex5-command-audit-v3')
OUT = Path(__file__).resolve().parent
HEAD = 'd3617acf9af7834582b4962a8c149969a7d55a22'
BASE = '21a005e242177f07a984937a7cd924e826c17b9f'

def run(args, **kwargs):
    return subprocess.run(['git', *args], cwd=ROOT, check=False, **kwargs)

def main():
    refs = run(['show-ref'], capture_output=True).stdout
    listing = run(['rev-list', '--objects', HEAD, '^' + BASE], capture_output=True)
    assert listing.returncode == 0
    (OUT / 'original-donor-objects.txt').write_bytes(listing.stdout)
    pack = OUT / 'original-donor-history.pack'
    pack_command = ['pack-objects', '--stdout', '--revs']
    with pack.open('wb') as stream:
        made = run(pack_command, input=(HEAD + '\n^' + BASE + '\n').encode(), stdout=stream, stderr=subprocess.PIPE)
    assert made.returncode == 0, made.stderr
    index_command = ['index-pack', '--strict', '-o', str(OUT / 'original-donor-history.idx'), str(pack)]
    indexed = run(index_command, capture_output=True)
    assert indexed.returncode == 0, indexed.stderr
    after = run(['show-ref'], capture_output=True).stdout
    assert refs == after
    receipt = {'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'donor_head': HEAD, 'prerequisite_base': BASE, 'object_count': len(listing.stdout.splitlines()), 'pack_command': ['git', *pack_command], 'pack_stdin': HEAD + '\n^' + BASE + '\n', 'pack_returncode': made.returncode, 'index_command': ['git', *index_command], 'index_returncode': indexed.returncode, 'index_stdout': indexed.stdout.decode(), 'index_stderr': indexed.stderr.decode(), 'ref_inventory_sha256_before': hashlib.sha256(refs).hexdigest(), 'ref_inventory_sha256_after': hashlib.sha256(after).hexdigest(), 'refs_unchanged': True, 'pack_sha256': hashlib.sha256(pack.read_bytes()).hexdigest(), 'pack_bytes': pack.stat().st_size, 'prior_bundle_attempt': {'command': ['git','bundle','create',str(OUT/'original-donor-history.bundle'),HEAD,'^'+BASE], 'returncode':128, 'stderr':'fatal: Refusing to create empty bundle.\n', 'explanation':'No local ref points at this historical head. No ref was created; a strict-verified raw pack and original files/commit records preserve the donor instead.'}, 'recovery_note':'This pack contains exact original donor objects reachable from HEAD but not from BASE. A recovery repository must already contain the prerequisite BASE history. Run Git recovery only in an explicitly owned repository; this review changed no ref.'}
    (OUT / 'history-preservation.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({k:receipt[k] for k in ['object_count','pack_bytes','pack_sha256','refs_unchanged','index_returncode']},indent=2))

if __name__ == '__main__':
    main()
