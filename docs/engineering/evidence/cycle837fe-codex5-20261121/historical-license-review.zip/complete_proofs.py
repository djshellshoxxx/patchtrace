"""Retain reproducible semantic, history, and prior-census receipts without mutating project source."""
from __future__ import annotations
import ast
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

import yaml

ROOT = Path('/workspace/scratch/837fe19aae3a/repair-codex5-command-audit-v3')
OUT = Path(__file__).resolve().parent
DONOR = 'd3617acf9af7834582b4962a8c149969a7d55a22'
BASELINE = 'ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e'
SQUASH = '00db4c9c0ce53d1c4c556f3530e8c54163e91e95'
BRANCH = 'claude/bundle-license-gate'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def dump(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, sort_keys=True) + '\n')

def source(label, path):
    return (OUT / 'source' / label / path).read_text()

def function(label, path, name):
    return next(n for n in ast.parse(source(label, path)).body if isinstance(n, ast.FunctionDef) and n.name == name)

def same(a, b):
    return ast.dump(a, include_attributes=False) == ast.dump(b, include_attributes=False)

def action_names(doc):
    if isinstance(doc, dict):
        return {k: (v.split('@')[0] if k == 'uses' and isinstance(v, str) else action_names(v)) for k,v in doc.items()}
    if isinstance(doc, list):
        return [action_names(x) for x in doc]
    return doc

def matched_records(value):
    if isinstance(value, dict):
        if BRANCH in value or BRANCH in value.values() or ('origin/' + BRANCH) in value.values():
            return [value]
        found = []
        for v in value.values():
            found.extend(matched_records(v))
        return found
    if isinstance(value, list):
        return [x for v in value for x in matched_records(v)]
    return []

def main():
    census = json.loads((OUT / 'source-census.json').read_text())
    paths = census['changed_paths']
    prior = []
    for name in ['consolidation-inventory.json', 'branch-recovery-20261120-2bad.json', 'consolidation-inventory-20261120-g30.json']:
        path = ROOT / 'docs/engineering' / name
        data = path.read_bytes()
        doc = json.loads(data)
        prior.append({'path': str(path.relative_to(ROOT)), 'sha256': hashlib.sha256(data).hexdigest(), 'schema': doc.get('schema'), 'observed_at_utc': doc.get('observed_at_utc'), 'matches': matched_records(doc)})
    for name in ['docs/consolidation/BRANCH_INVENTORY.md', 'docs/handoff/README.md', 'docs/handoff/backend-bundle.md']:
        data = (ROOT / name).read_bytes()
        prior.append({'path': name, 'sha256': hashlib.sha256(data).hexdigest(), 'matching_lines': [{'line': i, 'text': line} for i,line in enumerate(data.decode().splitlines(), 1) if BRANCH in line]})
    dump('prior-reports.json', prior)

    context = ['AGENTS.md', 'docs/modules.md', 'docs/specs/REGISTRY.md', 'docs/audits/codex-packaging-1.md', 'docs/specs/offline-backend-installer.md', 'docs/specs/program-e/BUNDLE-licence-notices-and-source-offer-spec.md', 'docs/specs/program-e/BUNDLE-release-checklist.md', 'docs/specs/program-e/BUNDLE-integration-plan.md', 'docs/runbooks/backend-bundle.md', 'tests/test_backend_bundle_workflow.py', 'tests/conftest.py', 'tests/live_status.py', 'pyproject.toml', 'src/patchtrace/backend_bundle.py', 'src/patchtrace/offline_bundle.py', 'src/patchtrace/__init__.py']
    context_proof = []
    for path in context:
        data = git('show', BASELINE + ':' + path)
        target = OUT / 'context/baseline' / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        context_proof.append({'path': path, 'baseline_blob': git('rev-parse', BASELINE + ':' + path).decode().strip(), 'sha256': hashlib.sha256(data).hexdigest(), 'execution_bytes_identical': data == (ROOT / path).read_bytes()})
    dump('context-source-binding.json', context_proof)

    proof = {}
    for path in ['tools/build_linux.py','tools/build_windows.py']:
        calls = []
        for label in ['donor','baseline']:
            calls.append([n for n in ast.walk(function(label,path,'main')) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id == 'attach_backend'])
        assert len(calls[0]) == len(calls[1]) == 1 and same(calls[0][0], calls[1][0])
        proof[path + ':main.attach_backend'] = {'identical_ast': True, 'retained_call': ast.unparse(calls[0][0])}

    donor_func = function('donor','tools/check_backend_pin.py','main')
    current_func = function('baseline','tools/check_backend_pin.py','main')
    replacements=[]
    for fn in [donor_func,current_func]:
        changed=0
        for n in ast.walk(fn):
            if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='data':
                replacements.append(ast.unparse(n.value))
                n.value=ast.Constant(value='PIN_PARSE')
                changed+=1
        assert changed==1
    assert same(donor_func,current_func)
    proof['tools/check_backend_pin.py:main']={'identical_after_only_parse_assignment_normalization':True,'donor_parse':replacements[0],'current_parse':replacements[1],'qualification':'Current parse_pin additionally rejects duplicate keys, nonfinite numbers and unpaired surrogates; approval/placeholder exits and warning logic remain exact.'}

    donor_build = source('donor','tools/build_backend_bundle.py')
    start=donor_build.index("        checker = _load_sibling('check_backend_pin')",donor_build.index('def build_backend('))
    end_marker="(payload / 'LICENSES/THIRD-PARTY.json').write_text(third_party_json, encoding='utf-8', newline='\\n')"
    end=donor_build.index(end_marker,start)+len(end_marker)
    block=donor_build[start:end]
    assert block in source('baseline','tools/build_backend_bundle.py')
    (OUT/'preserved-build-license-block.txt').write_text(block+'\n')
    proof['tools/build_backend_bundle.py:build_backend']={'license_gate_and_notice_block_verbatim_retained':True,'block_sha256':hashlib.sha256(block.encode()).hexdigest(),'later_additions':'keep_fid parameter; jlink reduction; expanded strip rules; runtime-policy output. The branch license gate block and release argument remain.'}

    d=function('donor','tests/test_build_backend_bundle.py','test_strip_rules_remove_docs_and_other_os_natives')
    c=function('baseline','tests/test_build_backend_bundle.py','test_strip_rules_remove_docs_and_other_os_natives')
    count=0
    for n in ast.walk(d):
        if isinstance(n,ast.Compare) and isinstance(n.left,ast.Attribute) and n.left.attr=='stripped_files':
            assert ast.literal_eval(n.comparators[0])==5
            n.comparators[0]=ast.Constant(value=4)
            count+=1
    assert count==1 and same(d,c)
    proof['tests/test_build_backend_bundle.py:strip_test']={'only_ast_difference': 'minimum stripped_files 5 -> 4; current comment explains jmods/src.zip now leave with jlink', 'gpl_directory_absence_assertion_retained':True}

    d=yaml.safe_load(source('donor','.github/workflows/backend-bundle.yml'))
    c=yaml.safe_load(source('baseline','.github/workflows/backend-bundle.yml'))
    assert action_names(d)==action_names(c)
    dg=next(s for s in d['jobs']['pin']['steps'] if 'Pin release gate' in s.get('name',''))
    cg=next(s for s in c['jobs']['pin']['steps'] if 'Pin release gate' in s.get('name',''))
    assert dg==cg
    proof['.github/workflows/backend-bundle.yml']={'whole_parsed_workflow_identical_except_action_revisions':True,'license_gate_step_exact':dg}

    d=json.loads(source('donor','tools/backend_pin.json'))
    c=json.loads(source('baseline','tools/backend_pin.json'))
    assert d['license_policy']==c['license_policy']
    assert 'GPL/**' in c['strip']['ghidra'] and 'GPL/**' not in c['strip']['keep']
    proof['tools/backend_pin.json']={'license_policy_subtree_identical':True,'gpl_strip_retained':True,'gpl_not_kept':True,'policy':c['license_policy']}
    def policy_section(label):
        return source(label,'docs/notices.md').split('## Full-bundle licence policy',1)[1].split('## Known runtime',1)[0]
    assert policy_section('donor')==policy_section('baseline')
    proof['docs/notices.md']={'entire_added_policy_section_verbatim_retained':True,'sha256':hashlib.sha256(policy_section('donor').encode()).hexdigest()}

    parent=git('rev-parse',DONOR+'^').decode().strip()
    a=ast.parse(git('show',parent+':tools/build_windows.py'))
    b=ast.parse(git('show',DONOR+':tools/build_windows.py'))
    assert same(a,b)
    proof['final_style_commit']={'parent':parent,'only_changed_path':'tools/build_windows.py','entire_module_ast_identical':True}
    rem=git('show','--remerge-diff','--format=',parent)
    (OUT/'merge-remerge-diff.txt').write_bytes(rem)
    assert not rem
    proof['merge_resolution']={'commit':parent,'remerge_diff_empty':True,'both_parent_diffs_preserved':True}
    ancestor=subprocess.run(['git','merge-base','--is-ancestor',SQUASH,BASELINE],cwd=ROOT,check=False).returncode
    assert ancestor==0
    (OUT/'squash-to-donor-owned-paths.patch').write_bytes(git('diff','--binary','--full-index',DONOR,SQUASH,'--',*paths))
    (OUT/'squash-commit.txt').write_bytes(git('show','--no-patch','--format=fuller',SQUASH))
    (OUT/'fresh-patch-id-status.txt').write_bytes(git('cherry','-v',BASELINE,DONOR))
    proof['squash_integration']={'commit':SQUASH,'ancestor_of_baseline':True,'whole_tree_equal_to_donor':False,'owned_path_differences':git('diff','--name-only',DONOR,SQUASH,'--',*paths).decode().splitlines(),'difference_explanation':'Only pre-existing CODEX-9 xfail removal and iced-x86 optional collection, unrelated to the branch license/payload gates; complete exact patch retained.'}
    dump('semantic-proofs.json',proof)
    results={}
    for kind in ['maintained','donor']:
        xml=ET.parse(OUT/f'{kind}.xml').getroot()
        suites=list(xml.iter('testsuite'))
        groups={}
        for case in xml.iter('testcase'):
            key=case.attrib.get('classname','')
            item=groups.setdefault(key,{'tests':0,'passed':0,'skipped':0,'failures':0,'errors':0})
            item['tests']+=1
            flags=[tag for tag in ['skipped','failure','error'] if case.find(tag) is not None]
            if not flags:item['passed']+=1
            for tag in flags:item[{'failure':'failures','error':'errors','skipped':'skipped'}[tag]]+=1
        results[kind]={'suites':[s.attrib for s in suites],'per_module':groups}
    dump('test-results-summary.json',results)
    print(json.dumps({'proofs':len(proof),'prior_sources':len(prior),'context_files':len(context),'test_totals':{k:v['suites'] for k,v in results.items()}},indent=2))

if __name__=='__main__':
    main()
