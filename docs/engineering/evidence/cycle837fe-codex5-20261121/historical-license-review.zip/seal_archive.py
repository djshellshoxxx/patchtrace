"""Seal portable evidence; exclude reproducible pytest payloads and self-referential archive outputs."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import zipfile

OUT = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/837fe19aae3a/repair-codex5-command-audit-v3')
ZIP_NAME = 'historical-license-review-d3617acf.zip'

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    state = {'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'head': git('rev-parse','HEAD'), 'tree': git('rev-parse','HEAD^{tree}'), 'status': git('status','--porcelain=v1'), 'original_181_16_census_mutated': False, 'source_or_workflow_or_ledger_changes': False}
    assert state['head']=='5b5328ee83ee4990b3311f7ac90e2f5e5f76f800' and not state['status']
    (OUT/'final-repository-state.json').write_text(json.dumps(state,indent=2)+'\n')
    excluded_roots={'temp-maintained','temp-donor','__pycache__'}
    excluded_files={ZIP_NAME,'MANIFEST.sha256','archive-receipt.json'}
    payload=[]
    for path in sorted(OUT.rglob('*')):
        rel=path.relative_to(OUT)
        if any(part in excluded_roots for part in rel.parts) or rel.as_posix() in excluded_files:
            continue
        if path.is_file():
            assert not path.is_symlink()
            payload.append((rel.as_posix(),path.read_bytes()))
    manifest=(''.join(sha(data)+'  '+name+'\n' for name,data in payload)).encode()
    (OUT/'MANIFEST.sha256').write_bytes(manifest)
    archive=OUT/ZIP_NAME
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as zf:
        for name,data in [*payload,('MANIFEST.sha256',manifest)]:
            info=zipfile.ZipInfo(name,date_time=(2026,11,21,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o100644<<16
            zf.writestr(info,data)
    with zipfile.ZipFile(archive) as zf:
        assert zf.testzip() is None
        assert len(zf.namelist())==len(set(zf.namelist()))==len(payload)+1
        assert zf.read('MANIFEST.sha256')==manifest
        for name,data in payload:
            assert sha(zf.read(name))==sha(data)
    receipt={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'manifest_sha256':sha(manifest),'member_count':len(payload)+1,'manifest_payload_member_count':len(payload),'crc_verified':True,'all_member_hashes_verified':True,'excluded_reproducible_directories':sorted(excluded_roots),'source_head':state['head'],'source_tree':state['tree'],'frozen_source_clean':True,'native_acceptance_claim':False,'census_181_16_unchanged':True}
    (OUT/'archive-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(receipt,indent=2))

if __name__=='__main__':
    main()
