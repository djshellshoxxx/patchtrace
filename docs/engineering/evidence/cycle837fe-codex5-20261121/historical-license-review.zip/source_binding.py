import hashlib
import importlib.metadata
import json
from pathlib import Path
import subprocess
import sys

import patchtrace
from patchtrace import backend_bundle, offline_bundle

ROOT = Path('/workspace/scratch/837fe19aae3a/repair-codex5-command-audit-v3')
OUT = Path('/workspace/scratch/837fe19aae3a/evidence/historical-license-review')
versions = {}
for name in ['pytest', 'pydantic', 'PyYAML', 'pip', 'setuptools', 'wheel']:
    try:
        versions[name] = importlib.metadata.version(name)
    except importlib.metadata.PackageNotFoundError:
        versions[name] = None
imports = {}
for module in [patchtrace, backend_bundle, offline_bundle]:
    path = Path(module.__file__).resolve()
    rel = str(path.relative_to(ROOT))
    data = path.read_bytes()
    baseline = subprocess.check_output(['git', 'show', 'ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e:' + rel], cwd=ROOT)
    assert data == baseline
    imports[module.__name__] = {'path': str(path), 'sha256': hashlib.sha256(data).hexdigest(), 'baseline_bytes_identical': True}
dist = importlib.metadata.distribution('patchtrace')
result = {'executable': sys.executable, 'version': sys.version, 'isolated': sys.flags.isolated, 'dont_write_bytecode': sys.dont_write_bytecode, 'imports': imports, 'versions': versions, 'editable_direct_url': json.loads(dist.read_text('direct_url.json')), 'sys_path': sys.path}
(OUT / 'source-binding.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
