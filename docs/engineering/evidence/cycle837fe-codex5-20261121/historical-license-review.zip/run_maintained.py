"""Bounded maintained source-only qualification; no source writes or provisioning."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/scratch/837fe19aae3a/repair-codex5-command-audit-v3')
OUT = Path(__file__).resolve().parent
PYTHON = '/workspace/scratch/837fe19aae3a/codex5-audit-v3-venv/bin/python'
SELECTORS = ['tests/test_backend_pin.py', 'tests/test_build_backend_bundle.py', 'tests/test_build_full_variants.py', 'tests/test_codex_pkg_packaging.py', 'tests/test_backend_bundle_workflow.py']

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT, text=True).strip()

def main():
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    before = git('status', '--porcelain=v1')
    head = git('rev-parse', 'HEAD')
    assert head == '5b5328ee83ee4990b3311f7ac90e2f5e5f76f800' and not before
    source = {p: hashlib.sha256((ROOT / p).read_bytes()).hexdigest() for p in SELECTORS}
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', QT_QPA_PLATFORM='offscreen', PIP_NO_INDEX='1', PIP_DISABLE_PIP_VERSION_CHECK='1')
    command = [PYTHON, '-m', 'pytest', '-q', '-ra', '-p', 'no:cacheprovider', '--basetemp', str(OUT / 'temp-maintained'), '--junitxml', str(OUT / 'maintained.xml'), *SELECTORS]
    start = time.monotonic()
    with (OUT / 'maintained.log').open('w') as output:
        process = subprocess.run(command, cwd=ROOT, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=300, check=False)
    after = git('status', '--porcelain=v1')
    receipt = {'started_utc': started, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'seconds': time.monotonic()-start, 'head': head, 'tree': git('rev-parse', 'HEAD^{tree}'), 'cwd': str(ROOT), 'command': command, 'environment_overrides': {k:env[k] for k in ['PYTHONDONTWRITEBYTECODE','QT_QPA_PLATFORM','PIP_NO_INDEX','PIP_DISABLE_PIP_VERSION_CHECK']}, 'returncode': process.returncode, 'status_before': before, 'status_after': after, 'selector_source_sha256': source, 'selector_source_unchanged': all(hashlib.sha256((ROOT / p).read_bytes()).hexdigest() == sha for p,sha in source.items()), 'scope': 'Maintained synthetic/static helper tests plus authored local tiny wheel checks; no package build, vendor download, native backend, or target execution.'}
    (OUT / 'maintained-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps(receipt, indent=2))
    print((OUT / 'maintained.log').read_text())

if __name__ == '__main__':
    main()
