"""Read-only historical branch evidence collection; writes only beside this file."""
from __future__ import annotations

import ast
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path('/workspace/scratch/837fe19aae3a/repair-codex5-command-audit-v3')
OUT = Path(__file__).resolve().parent
DONOR = 'd3617acf9af7834582b4962a8c149969a7d55a22'
BASELINE = 'ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e'
EXECUTION = '5b5328ee83ee4990b3311f7ac90e2f5e5f76f800'


def git(*args: str) -> bytes:
    return subprocess.check_output(['git', *args], cwd=ROOT)


def write(path: str, data: bytes) -> None:
    target = OUT / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)


def dump(path: str, data: object) -> None:
    write(path, (json.dumps(data, indent=2, sort_keys=True) + '\n').encode())


def symbols(source: bytes) -> dict[str, str]:
    result = {}
    for node in ast.parse(source).body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            key = node.name
        elif isinstance(node, ast.Assign):
            key = 'assign:' + ','.join(ast.unparse(t) for t in node.targets)
        elif isinstance(node, ast.AnnAssign):
            key = 'assign:' + ast.unparse(node.target)
        else:
            continue
        result[key] = ast.dump(node, include_attributes=False)
    return result


def main() -> None:
    base = git('merge-base', '--all', BASELINE, DONOR).decode().strip()
    paths = git('diff', '--name-only', base, DONOR).decode().splitlines()
    commits = git('rev-list', '--reverse', f'{BASELINE}..{DONOR}').decode().splitlines()
    census = {
        'collected_utc': datetime.now(timezone.utc).isoformat(),
        'read_only_repository': str(ROOT),
        'baseline': BASELINE,
        'baseline_tree': git('rev-parse', f'{BASELINE}^{{tree}}').decode().strip(),
        'donor': DONOR,
        'donor_tree': git('rev-parse', f'{DONOR}^{{tree}}').decode().strip(),
        'execution': EXECUTION,
        'execution_tree': git('rev-parse', f'{EXECUTION}^{{tree}}').decode().strip(),
        'merge_bases': base.splitlines(),
        'unique_commits_including_merge': commits,
        'unique_nonmerge_commits': git('rev-list', '--reverse', '--no-merges', f'{BASELINE}..{DONOR}').decode().splitlines(),
        'changed_paths': paths,
        'changed_path_count': len(paths),
        'baseline_to_execution_changed_paths': git('diff', '--name-only', BASELINE, EXECUTION).decode().splitlines(),
        'worktree_status_before': git('status', '--porcelain=v1').decode(),
    }
    write('branch.patch', git('diff', '--binary', '--full-index', base, DONOR))
    write('donor-to-baseline.patch', git('diff', '--binary', '--full-index', DONOR, BASELINE, '--', *paths))
    write('baseline-to-execution.patch', git('diff', '--binary', '--full-index', BASELINE, EXECUTION))
    write('donor-tree.txt', git('ls-tree', '-r', DONOR))
    write('baseline-tree.txt', git('ls-tree', '-r', BASELINE))
    write('unique-commit-graph.txt', git('log', '--graph', '--format=fuller', f'{BASELINE}..{DONOR}'))
    for commit in commits:
        write(f'commits/{commit}.commit', git('cat-file', 'commit', commit))
        write(f'commits/{commit}.patch', git('show', '--format=fuller', '--binary', '--full-index', '--cc', commit))
        parents = git('rev-list', '--parents', '-n', '1', commit).decode().split()[1:]
        if len(parents) > 1:
            for n, parent in enumerate(parents, 1):
                write(f'commits/{commit}.parent{n}.patch', git('diff', '--binary', '--full-index', parent, commit))
    rows = []
    symbols_report = {}
    for path in paths:
        row = {'path': path}
        blobs = {}
        for label, commit in [('merge-base', base), ('donor', DONOR), ('baseline', BASELINE), ('execution', EXECUTION)]:
            blob = git('show', f'{commit}:{path}')
            blobs[label] = blob
            row[label] = {'git_blob': git('rev-parse', f'{commit}:{path}').decode().strip(), 'sha256': hashlib.sha256(blob).hexdigest(), 'bytes': len(blob)}
            if label != 'execution':
                write(f'source/{label}/{path}', blob)
        row['baseline_execution_byte_identical'] = blobs['baseline'] == blobs['execution']
        row['donor_baseline_byte_identical'] = blobs['donor'] == blobs['baseline']
        rows.append(row)
        if path.endswith('.py'):
            older, donor, current = [symbols(blobs[label]) for label in ('merge-base', 'donor', 'baseline')]
            changed = sorted(key for key in donor if donor[key] != older.get(key))
            symbols_report[path] = {
                'donor_changed_symbols': [{ 'symbol': key, 'baseline_status': 'same_ast' if donor[key] == current.get(key) else ('different_ast' if key in current else 'absent')} for key in changed],
                'donor_deleted_symbols': sorted(set(older) - set(donor)),
                'all_donor_test_functions': [{ 'symbol': key, 'baseline_status': 'same_ast' if donor[key] == current.get(key) else ('different_ast' if key in current else 'absent')} for key in donor if key.startswith('test_')],
            }
    census['paths'] = rows
    # The entire src runtime is byte-identical. Only named CODEX-5 additions differ.
    census['baseline_execution_src_diff'] = git('diff', '--name-status', BASELINE, EXECUTION, '--', 'src').decode()
    census['baseline_execution_workflow_diff'] = git('diff', '--name-status', BASELINE, EXECUTION, '--', '.github/workflows').decode()
    dump('source-census.json', census)
    dump('symbol-comparison.json', symbols_report)
    print(json.dumps({'paths': len(rows), 'unique_commits': commits, 'changed_symbols': {p: len(v['donor_changed_symbols']) for p, v in symbols_report.items()}, 'all_11_baseline_execution_bytes_identical': all(r['baseline_execution_byte_identical'] for r in rows), 'baseline_execution_changed_paths': census['baseline_to_execution_changed_paths']}, indent=2))


if __name__ == '__main__':
    main()
