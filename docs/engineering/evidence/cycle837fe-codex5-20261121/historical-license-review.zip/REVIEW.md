# Historical branch review: claude/bundle-license-gate

## Result and scope

**Classification: semantically integrated in the exact frozen baseline; no unique missing implementation, contract, or branch-added regression was found.** This is a complete review of this branch's 11-path merge-base delta, its three unmatched nonmerge commits, and its merge commit. No application, workflow, test, contract, ledger, repository ref, or PR was changed. The original **181/16 historical census is unchanged**; this evidence supports a scoped classification decision for this one branch only.

The branch introduces strict verification before full backend attachment (historical CODEX-13), an explicit GPL-family policy and release/publish approval gates (historical CODEX-15), a committed Temurin approval record, and associated tests/notices. Those changes are present in the baseline. Current additions around pin parsing, jlink, packaging resources, dependency inventory and immutable Action revisions do not remove these branch changes.

This finding covers source behavior and the bounded synthetic/static regressions below. It makes no Windows/Linux native packaging, backend compatibility, final artifact, source-offer completeness, or legal-acceptance claim. The existing committed approval metadata is preserved as historical evidence; this review neither obtains nor expands owner approval.

## Exact source and fresh reference

| Item | Exact identity |
|---|---|
| Reviewed branch | `claude/bundle-license-gate` |
| Fresh GitHub branch head | `d3617acf9af7834582b4962a8c149969a7d55a22` |
| Donor tree | `af31f6eb189620941de8db8718f203d8b8dce77c` |
| Frozen comparison baseline | `ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e` |
| Baseline tree | `c3f09435deb99ca0ddb3406e27ab315dba7740cf` |
| Sole merge base | `21a005e242177f07a984937a7cd924e826c17b9f` |
| Read-only test execution checkout | `/workspace/scratch/837fe19aae3a/repair-codex5-command-audit-v3` |
| Execution head | `5b5328ee83ee4990b3311f7ac90e2f5e5f76f800` |
| Execution tree | `1e12edd510399fd92da6867cd071394ceb7fc95b` |
| Existing dedicated interpreter | `/workspace/scratch/837fe19aae3a/codex5-audit-v3-venv/bin/python` |

The API ref and PR #65 were refreshed read-only. PR #65 is closed and merged, with `merged_at=2026-10-15T05:42:17Z` and integration commit `00db4c9c0ce53d1c4c556f3530e8c54163e91e95`. That integration commit is an ancestor of `ae69`. Raw responses are retained in `fresh-branch-ref.json` and `fresh-pr65.json`.

**Byte proof precedes behavioral reuse of V3:** all 11 donor-owned paths, the entire `src/` tree, and all workflows are identical between `ae69` and `5b`. The relevant pytest configuration, maintained workflow test, conftest and runtime imports are also identical. The eight differences between those commits are the already-reviewed additive CODEX-5 audit files and their registration/history documentation; the full diff is preserved in `baseline-to-execution.patch`. `source-census.json`, `context-source-binding.json`, and the isolated interpreter's `source-binding.json` bind the results to these exact bytes. Documentation registrations differ only as recorded; no whole-tree identity claim is made.

## Prior reports reconciled

The prior reports were inspected before the new source review. `prior-reports.json` retains their selected records, exact input hashes, and matching handoff lines.

| Prior source | Prior finding | Reconciliation |
|---|---|---|
| `docs/engineering/consolidation-inventory.json` | `retained-for-semantic-review`; three unmatched nonmerge patches; no deletion authorization | Correct ancestry/patch-identity inventory, without a behavioral conclusion |
| `docs/engineering/branch-recovery-20261120-2bad.json` | `unmatched-patches-review-required`; unchanged head; no equivalent patch IDs | The fresh `git cherry` result still has three `+` entries; this does not establish missing behavior after a squash integration |
| `docs/engineering/consolidation-inventory-20261120-g30.json` | `UNKNOWN — INVESTIGATE`; complete 11-path set; no full semantic review claimed | Same complete path set independently reproduced against `ae69` |
| `docs/consolidation/BRANCH_INVENTORY.md` | Retained branch, 4 commits / 3 nonmerge / 11 files, PR #65 | Full scope agrees with the refreshed graph |
| `docs/handoff/README.md` | Older squash-merged branches including this one were unverified by ancestry | Current source/behavior comparison now supplies the missing scoped proof |
| `docs/handoff/backend-bundle.md` | Records branch as merged through #65 | Fresh PR result and ancestor check corroborate that historical statement |

The historical CODEX packaging audit still describes its original CODEX-13/15 findings. The branch's repaired tests are ordinary assertions in both donor and baseline. No audit text, xfail, assertion, or census was changed in this review.

## Complete commit accounting

| Commit | Contribution | Current disposition |
|---|---|---|
| `246eed794dbda3d3ebc6f2a8f29736ec09b94fb6` | Strict payload verification; explicit GPL-family policy; release flags; workflow gate; notice and regression changes across all 11 paths | All unique branch behavior retained |
| `c9a01b6f4e6e51b35b0685dcac96c4cdc1400101` | Records Temurin approval and keeps withdrawn/pending approval tests explicit; 4 paths | Approval record and negative tests retained |
| `0016de7264a1c9cd651a469eb49f01ad1ba22773` | Merges `c9a01b6f` into first parent `21a005e2` | Both parent diffs retained; `git show --remerge-diff --format=` is empty; no extra merge-resolution behavior |
| `d3617acf9af7834582b4962a8c149969a7d55a22` | Multiline import formatting in `tools/build_windows.py` | Entire Python module AST equals its parent; no additional executable behavior |

The branch delta is **647 insertions / 34 deletions in 11 files**. Every original commit record and patch, the merge's two parent diffs, complete tree listings, and the branch-wide patch are preserved. The PR integration tree is not identical to the donor tree: concurrent work was present. On the 11 reviewed paths, the integration differs only in the existing CODEX-9 xfail removal and `iced-x86` optional collection. Those three one-line changes do not remove the license/attachment work; the exact patch is retained in `squash-to-donor-owned-paths.patch`.

## All 11 changed paths

| Path | Donor change and retained behavior | Comparison and bounded evidence |
|---|---|---|
| `.github/workflows/backend-bundle.yml` | Pin release step passes `--allow-unapproved-licenses` only for a non-publishing plan; publishing requires normal `--release` approval enforcement | The entire parsed workflow is equal after normalizing only Action revision suffixes. The complete license gate step, including `if`, `env` and script, is exactly equal. Current workflow module: 13 passed. |
| `docs/notices.md` | Describes engineering policy, Ghidriff entry, recorded Temurin approval, stripped Ghidra GPL directory, and existing qualification caveats | Entire added policy section remains verbatim. Later inventory and desktop-resource notices are additive. |
| `tests/test_backend_pin.py` | Policy shape, SPDX identity, GPL/LGPL/AGPL matching, approval rollback, CLI warning/exit behavior, GPL-strip controls | All 11 branch-changed test functions and the `approved` helper have identical ASTs. Original donor selection: 22 cases passed. Current module: 62 passed. Later tests replace assumptions about unresolved committed pins with verified-pin assertions and an explicit placeholder fixture. |
| `tests/test_build_backend_bundle.py` | Policy-aware NOTICE, pending release refusal, approved release acceptance, malformed GPL-strip policy refusal, GPL-directory removal | Four of the five changed test functions remain AST-identical. The fifth retains its GPL-absence assertion; its sole AST change is minimum strip count 5→4 because jlink now removes `jmods/src.zip`. Original donor selection with original pin: 6 cases passed. Current module: 105 passed, 1 existing skip. |
| `tests/test_build_full_variants.py` | Strict manifest and exact-tree failures before copy, platform mismatch, missing/unreadable component license inventory, unlisted/changed copyleft SPDX, GPL directory, release flag and pending provenance | **Entire file is byte-identical** between donor and baseline, including all helpers and pre-existing controls. Original changed-function selection: 21 cases passed. Current module: 59 passed. |
| `tests/test_codex_pkg_packaging.py` | Converts CODEX-13 and CODEX-15 to ordinary passing assertions tied to manifest verification and explicit policy | Both changed functions are AST-identical and have no xfail. Original donor selection: 2 passed. Current module: 12 passed; unrelated older expected failures were subsequently repaired. |
| `tools/backend_pin.json` | Defines three policy entries, component-ID/exact-SPDX matching, booleans and rationale, recorded Temurin approval, `GPL/**` strip and removal from keep patterns | Entire `license_policy` subtree is identical; GPL strip/keep constraints are retained. Later digest resolution, jlink and other strip additions are separate changes. |
| `tools/build_backend_bundle.py` | Evaluates payload copyleft/GPL-directory policy, refuses pending approval for release, records non-release warning, renders honest NOTICE, exposes `--release` | Four changed functions remain AST-identical. Within extended `build_backend`, the complete license-gate/NOTICE/inventory-write block is verbatim retained. Later jlink, `keep_fid` and runtime-policy additions leave it intact. |
| `tools/build_linux.py` | Canonical strict manifest parsing and full hash verification; license checks; release refusal before copying; non-release warning and pending-approval provenance; `--release` requires `--full` | Eight of nine changed symbols are AST-identical, including every new validator, `payload_problems`, `attach_backend` and `parse_args`. The later-extended `main` retains the exact `attach_backend(... release=args.release ...)` call. |
| `tools/build_windows.py` | Uses shared attachment gate and forwards `release=args.release`; final commit reformats import | The attachment call is AST-identical. Later resource, launcher and notice work is separate. Parent→final donor module AST is identical, proving formatting-only scope. No Windows builder was executed. |
| `tools/check_backend_pin.py` | Enforces policy shape, exact ID/SPDX mapping, GPL-directory policy, approval status, release exit 4 and non-publish warning override | Eleven of twelve changed symbols are AST-identical. `main` differs only in its pin parsing assignment: current `parse_pin` adds strict JSON handling. After normalizing that one assignment, the entire function AST is identical. |

Overall, **69 of 74 changed top-level Python symbols are AST-identical**. The five differences are the four extended implementations and one jlink-adjusted strip test described above. There are no absent changed symbols. Import changes, policy data, workflow data, notices and the merge resolution were reviewed separately; the AST count alone is not the classification argument. `symbol-comparison.json` and `semantic-proofs.json` retain the full checks.

## Contract coverage

1. **Before copying a backend:** strict duplicate-aware manifest parsing and canonical validation; complete declared-file/tree/hash verification; platform match; refusal on missing, extra, wrong-size, wrong-hash or malformed manifests. Link and path constraints remain alongside this gate. Tests verify refusal before the destination is written.
2. **Policy inventory:** GPL, LGPL and AGPL expressions require an explicitly listed component ID with identical SPDX; malformed policy fields and stripped-GPL contradictions are refused. The canonical pin's policy subtree is unchanged from the donor.
3. **Approval lifecycle:** a shipped entry without approval produces a visible non-release warning and pending provenance; release mode refuses it. CLI exit 4, builder error `PT-BUNDLE-LICENSE`, release-flag validation, and rollback of both approved entries remain covered.
4. **Payload policy:** missing/unreadable license inventory, unlisted copyleft components, changed SPDX and Ghidra GPL directory inclusion are refused. The generated NOTICE retains approval/stripped status and engineering-policy wording.
5. **Workflow coupling:** `PUBLISH` controls the non-publishing override; all other workflow semantics are unchanged apart from immutable Action revisions. This is a static workflow finding, not a hosted build result.

These are the contracts the donor actually added. Broader future license-verifier proposals in later documents, native archive completeness, and upstream binaries outside the named GPL directory are not silently treated as completed by this classification.

## Qualification and exact commands

All commands, selectors, source hashes, timestamps, exit codes, stdout and JUnit XML are retained. The fixed checkout was clean before and after both runs. No install, download, environment rebinding, full-suite attempt, application build or native backend run occurred.

### Maintained source and current pin

Environment overrides: `PYTHONDONTWRITEBYTECODE=1`, `QT_QPA_PLATFORM=offscreen`, `PIP_NO_INDEX=1`, `PIP_DISABLE_PIP_VERSION_CHECK=1`.

```text
/workspace/scratch/837fe19aae3a/codex5-audit-v3-venv/bin/python -m pytest -q -ra -p no:cacheprovider
  --basetemp /workspace/scratch/837fe19aae3a/evidence/historical-license-review/temp-maintained
  --junitxml /workspace/scratch/837fe19aae3a/evidence/historical-license-review/maintained.xml
  tests/test_backend_pin.py
  tests/test_build_backend_bundle.py
  tests/test_build_full_variants.py
  tests/test_codex_pkg_packaging.py
  tests/test_backend_bundle_workflow.py
```

**251 passed, 1 skipped, 0 failures/errors; pytest 4.46 seconds.** The one skip is `test_real_wheel_build_from_a_source_tarball_is_byte_compared`, whose existing prerequisite is setuptools plus wheel. Setuptools 84.2.1 is available; **wheel is absent**. The separate tiny locally generated hash-locked wheel install test passed. This is not package-provisioning or vendor-runtime evidence.

### Untouched donor regressions

`run_donor.py` copied the four original donor test modules without edits and selected **all 32 test functions changed by this branch**, as derived from the merge-base AST delta. Exact argv/selectors are in `donor-receipt.json`. **51 parameterized cases passed in 1.01 seconds**, without skips or xfails.

The replay uses byte-identical `ae69`/`5b` tool copies and the isolated environment's `ae69`-equivalent runtime imports. It deliberately uses the **exact original donor pin as a historical synthetic fixture**; its license policy is identical to current. The historical pin lacks later jlink configuration, allowing the untouched donor fake runner to exercise its original license cases. This is a clearly identified mixed-source regression replay, not a qualification of the current shipping pin. The maintained run independently tests the current source and pin. Full original modules, including unselected historical assumptions, remain preserved. The two runs overlap and **must not be summed as distinct coverage**.

### Source binding

`source-binding.json` records Python 3.12.14, pytest 9.2.0, Pydantic 2.14.2, PyYAML 6.0.3, pip 25.0.1, and the existing editable `direct_url` bound to the frozen V3 checkout. The binding check ran with `-B -I`; imported `patchtrace`, `backend_bundle` and `offline_bundle` paths and hashes exactly match `ae69`. No dependency version was changed.

## Preservation, recovery and ownership

The archive contains exact source snapshots for all 11 paths at merge base, donor and baseline; original commit records/patches; both merge-parent diffs; full tree listings; fresh API responses; prior-report extracts and source hashes; semantic proof scripts/results; maintained/donor raw stdout and JUnit; and all replay selectors/source bindings. Reproducible temporary pytest payload directories are excluded from the portable archive; their producing tests are preserved unchanged.

`original-donor-history.pack` and its index preserve **39 original Git objects** above prerequisite `21a005e242177f07a984937a7cd924e826c17b9f`. `git index-pack --strict` succeeded and the ref inventory hash was unchanged. A normal bundle attempt from the bare commit ID was refused as empty because no local ref names that historical head; the failure is retained in `history-preservation.json`. No ref was created to work around it. The verified raw pack, original files and commit records provide preservation without ref mutation. Recovery into a repository requires that recorded base history and a separately authorized destination.

Authoring ownership remains released. The baseline, all CODEX-5 worktrees/environments, PRs, remote branches and authoritative ledger/census remain frozen and untouched. Root owns any later record update or publication decision. No branch deletion or cleanup is authorized by this report.
