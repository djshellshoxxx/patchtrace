"""Replay untouched branch-relevant donor tests with maintained runtime and historical pin fixture."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/workspace/scratch/837fe19aae3a/repair-codex5-command-audit-v3')
OUT = Path(__file__).resolve().parent
VIEW = OUT / 'donor-replay'
PYTHON = '/workspace/scratch/837fe19aae3a/codex5-audit-v3-venv/bin/python'
TOOLS = ['build_backend_bundle.py', 'build_linux.py', 'build_windows.py', 'check_backend_pin.py', 'check_windows_exe.py', 'windows_icon.py', 'windows_version_info.py', 'verify_backend_pins.py']

def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)

def main():
    (VIEW / 'tests').mkdir(parents=True, exist_ok=True)
    (VIEW / 'tools').mkdir(parents=True, exist_ok=True)
    symbol_report = json.loads((OUT / 'symbol-comparison.json').read_text())
    selectors = []
    bindings = []
    for path, info in symbol_report.items():
        if not path.startswith('tests/'):
            continue
        data = (OUT / 'source/donor' / path).read_bytes()
        (VIEW / path).write_bytes(data)
        bindings.append({'path': path, 'origin': 'exact donor test module', 'sha256': hashlib.sha256(data).hexdigest()})
        for symbol in info['donor_changed_symbols']:
            if symbol['symbol'].startswith('test_'):
                selectors.append(path + '::' + symbol['symbol'])
    for name in TOOLS:
        path = 'tools/' + name
        data = (ROOT / path).read_bytes()
        assert data == git('show', 'ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e:' + path)
        (VIEW / path).write_bytes(data)
        bindings.append({'path': path, 'origin': 'exact ae69/5b maintained tool', 'sha256': hashlib.sha256(data).hexdigest()})
    pin_data = (OUT / 'source/donor/tools/backend_pin.json').read_bytes()
    (VIEW / 'tools/backend_pin.json').write_bytes(pin_data)
    bindings.append({'path': 'tools/backend_pin.json', 'origin': 'exact donor pin fixture, not current shipping pin', 'sha256': hashlib.sha256(pin_data).hexdigest()})
    pin = json.loads(pin_data)
    current_pin = json.loads((ROOT / 'tools/backend_pin.json').read_text())
    assert pin['license_policy'] == current_pin['license_policy']
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', QT_QPA_PLATFORM='offscreen', PIP_NO_INDEX='1', PIP_DISABLE_PIP_VERSION_CHECK='1')
    command = [PYTHON, '-m', 'pytest', '-q', '-ra', '-p', 'no:cacheprovider', '--rootdir', str(VIEW), '--confcutdir', str(VIEW), '--basetemp', str(OUT / 'temp-donor'), '--junitxml', str(OUT / 'donor.xml'), *selectors]
    before = git('status', '--porcelain=v1').decode()
    assert not before
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    start = time.monotonic()
    with (OUT / 'donor.log').open('w') as output:
        process = subprocess.run(command, cwd=VIEW, env=env, stdout=output, stderr=subprocess.STDOUT, timeout=180, check=False)
    receipt = {'started_utc': started, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'seconds': time.monotonic()-start, 'command': command, 'cwd': str(VIEW), 'returncode': process.returncode, 'selected_function_count': len(selectors), 'source_bindings': bindings, 'all_source_bindings_unchanged': all(hashlib.sha256((VIEW / item['path']).read_bytes()).hexdigest() == item['sha256'] for item in bindings), 'frozen_worktree_before': before, 'frozen_worktree_after': git('status', '--porcelain=v1').decode(), 'donor_license_policy_equals_current': True, 'scope': 'Unmodified donor tests changed by this branch; exact maintained tool bytes and ae69-equivalent src import, with exact donor pin as the historical synthetic fixture. Donor pin intentionally omits later jlink additions so the unmodified donor FakeRunner remains usable. This replay does not qualify the current shipping pin or any native artifact; maintained run separately covers current source and pin.'}
    (OUT / 'donor-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({'returncode': process.returncode, 'selected_function_count': len(selectors), 'seconds': receipt['seconds'], 'unchanged': receipt['all_source_bindings_unchanged']}))
    print((OUT / 'donor.log').read_text())

if __name__ == '__main__':
    main()
