# Tier R aggregate report

> Measured on test builds of open-source code; says nothing about Windows system files.

- report_sha256: `364c87d3a16c6cca92c325eb2f4d593c5e9562561e39b787004c1d6248642b4a`
- symbols: hidden
- plan: `7f686fab1934b771a8f6daaedb012e750566fe304a32f7d191e132913f0de608`, seed 1, subset smoke, 2 shard(s)
- failing cases: 0

## Engines

| engine | status | version | runs | failures | reason |
|---|---|---|---|---|---|
| rz-diff | partial | 0.9.1 | 5 | 6 | failed: rz-diff reported no functions in the older file, so it compared nothing. rz-diff may not support this file; use another engine for this pair. (and 2 more pairs) |

## Strata

| stratum | engine | pairs | id precision | id recall | changed P | changed R | fp rate |
|---|---|---|---|---|---|---|---|
| cve | rz-diff | 2 | 1.0000 | 0.4361 | 0.0167 | 1.0000 | 0.5130 |
| release | rz-diff | 3 | 0.9655 | 0.4268 | 0.2688 | 1.0000 | 0.5913 |

Aggregate metrics only. No images, binaries or function tables are included.
