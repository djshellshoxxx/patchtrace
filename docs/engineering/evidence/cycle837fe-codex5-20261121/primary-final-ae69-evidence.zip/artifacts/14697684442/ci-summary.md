### Tier R CI status: warning

report_sha256: `364c87d3a16c6cca92c325eb2f4d593c5e9562561e39b787004c1d6248642b4a`

| engine | stratum | attempted | completed | blocked | failed |
|---|---|---|---|---|---|
| rz-diff | all | 11 | 5 | 0 | 6 |
| rz-diff | aa | 1 | 0 | 0 | 1 |
| rz-diff | authored | 1 | 0 | 0 | 1 |
| rz-diff | cve | 2 | 2 | 0 | 0 |
| rz-diff | mutation | 1 | 0 | 0 | 1 |
| rz-diff | noise | 3 | 0 | 0 | 3 |
| rz-diff | release | 3 | 3 | 0 | 0 |

- WARNING rz-diff: only 5 of 11 pairs completed (below 90%)
