# PR 349: completed native and optional-dependency evidence

This receipt records six completed hosted workflows for head `ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e`. It is a native-evidence checkpoint; the full QA, Qt, packaging, and installation qualification is tracked separately.

## Exact source

- Repository: [djshellshoxxx/PatchTrace](https://github.com/djshellshoxxx/PatchTrace)
- PR: [349](https://github.com/djshellshoxxx/PatchTrace/pull/349)
- Head: `ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e`
- Head and synthetic-merge tree: `c3f09435deb99ca0ddb3406e27ab315dba7740cf`
- Base: `fdc2696c23bdbfe7668348f25e3b336ce33039f7`
- Actual checkout: `66f153a8372ad93c72e2f5b10365dcf210681684`
- Synthetic-merge parents: base, then head. The API source records and each retained completed job log establish this relationship.
- Every workflow below completed on attempt 1 with the exact head above.

## Actual outcomes

| Workflow | Hosted conclusion | Evidence and practical scope |
|---|---|---|
| [Ghidriff 44881740983](https://github.com/djshellshoxxx/PatchTrace/actions/runs/44881740983) | Success | Three positive known-patch variants each accepted one change record. A fourth job reproduced the expected disabled-symbol cached-PDB failure. The fifth verified raw-cache reuse, two completed analyses, and one match per analysis. |
| [rizin 44881741061](https://github.com/djshellshoxxx/PatchTrace/actions/runs/44881741061) | Success | Linux and Windows artifacts both say `mocked=false`, `status=passed`, engine status `ok`. Observed match counts are 30 and 322 respectively. These counts establish execution, not match accuracy. |
| [BinDiff 44881741004](https://github.com/djshellshoxxx/PatchTrace/actions/runs/44881741004) | Success | Linux: 7 checks passed, 0 blocked, 0 failed. Windows: 6 passed, 1 blocked, 0 failed; actual acceptance status is `blocked`. The blocked network-isolation check is Linux-only and Windows network behavior remains manual. Inputs are synthetic 20/21-function fixtures. Existing TOFU provenance limits remain. |
| [Optional dependencies 44881741068](https://github.com/djshellshoxxx/PatchTrace/actions/runs/44881741068) | Success | Both OSes reported rapidfuzz 3.14.6, yara-x 1.21.0, and iced-x86 1.21.0 present, with no missing dependencies. This is an availability probe. |
| [Tier R 44881741002](https://github.com/djshellshoxxx/PatchTrace/actions/runs/44881741002) | Success | Actual aggregate status `warning`: rz-diff completed 5 of 11 attempted pairs; 6 failed and 0 were blocked. Corpus preparation separately recorded 11 OK cases and one skipped byte-identical pair. |
| [Unified extraction 44881740985](https://github.com/djshellshoxxx/PatchTrace/actions/runs/44881740985) | Success | Two authored fixture pairs, each with 45 PASS / 0 FAIL on Windows and 46 PASS / 0 FAIL on Linux. Linux includes explicit cross-OS content-digest equality. Downloaded JSON independently confirms the same four input hashes and content digests. |

Ghidriff's two raw outputs have the identical SHA256 `3369565e28dd3fba96f8a34a331f17e6d3dc5bcc54c6dcefff98b7bcdba52ee7`. This proves byte-preserving reuse within that cache test.

Unified extraction verifies structural, retained-GZF, and cross-OS content equivalence on the supplied fixtures. Informational ledger entries retain the intentional omission of NOP/INT3 padding from h1–h3/hm and the coarser hm equivalence classes. The artifact supports no general match-accuracy claim.

## Tier R coverage limits and historical attribution

All six tiny-fixture pairs failed because rz-diff found no functions in the older image. Five zlib pairs completed. The Windows advisory reports 11 findings, all with reason `exit 1`, without a substantive native report. The MSVC advisory was intentionally skipped.

Both actual Linux shard logs record a cache hit for the original rizin archive and a successful SHA256 verification against `9102249a9f0b6319c5334a2e5cf8d9cc3f2035e1d3def027c41f6a90f647e8cf`. Java and Ghidra restoration/installation steps were skipped for `ENGINES=rz-diff`; they supply no Ghidra archive-cache acceptance.

The two actual merges of the current shards produced the same canonical report digest: `364c87d3a16c6cca92c325eb2f4d593c5e9562561e39b787004c1d6248642b4a`.

`historical-tier-r-comparison/comparison.json` independently compares the fresh ae69 aggregate with original PR349 run 44870397157 at head `11f51c105bf63946f59373ae605b937c4fee607a`. The complete aggregate JSON member bytes and pair status/reason mappings are identical. The prior artifact ZIP and its metadata are retained in that explicitly historical folder. This comparison attributes existing coverage gaps; each current acceptance result still comes from the fresh ae69 run.

## Evidence layout

- `native-summary.json`: compact machine-readable outcomes.
- `initial-run-and-source-records.json` and `non-qa-final-run-records.json`: API source/run identity.
- `raw-job-*.json`: complete decoded job text returned by the GitHub connector, with source URL and checkout identity.
- `logs/*.log`: exact UTF-8 bytes of those decoded strings, preserving their returned BOM and line endings. These are not the original GitHub log ZIP bytes.
- `downloaded-artifact-records-native.json`: metadata for all 14 downloaded native artifacts.
- `artifacts/<id>.zip`: original downloaded ZIP bytes, each SHA256 checked against its GitHub API digest.
- `unified-*-ledger.json`, `unified-cross-os-comparison.json`, and `tier-r-cache-evidence.json`: detailed checks tied to the retained logs/artifacts.

The observer performed read-only GitHub retrieval and local text/JSON/ZIP inspection. No native engine or analyzed target was executed locally, and no workflow was retried or dispatched.

