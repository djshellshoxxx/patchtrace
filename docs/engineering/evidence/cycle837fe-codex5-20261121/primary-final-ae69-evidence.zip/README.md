# PR 349 — final ae69 hosted qualification

**All seven workflows owned by this observer completed successfully on attempt 1. All ten required QA jobs and all 28 applicable CI jobs concluded success.** Three jobs were intentionally skipped: the Tier R MSVC advisory and the PR-only release gate/release path. The qualification retains the expected failures and native coverage limits below.

The final API observation was **2026-11-21 09:16:35 UTC**. This is the completed PR qualification receipt. Intel run 44881741040 is separately owned. The actual guarded main merge and its publication hold are separate root receipts.

## Exact source

| Identity | Value |
|---|---|
| Repository / PR | [djshellshoxxx/PatchTrace #349](https://github.com/djshellshoxxx/PatchTrace/pull/349) |
| Head | `ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e` |
| Complete head tree | `c3f09435deb99ca0ddb3406e27ab315dba7740cf` |
| Base | `fdc2696c23bdbfe7668348f25e3b336ce33039f7` |
| Actual synthetic checkout | `66f153a8372ad93c72e2f5b10365dcf210681684` |
| Synthetic tree | `c3f09435deb99ca0ddb3406e27ab315dba7740cf` |

The synthetic commit has exactly the base and head above as its parents, in that order. Every one of the 28 retained applicable job logs records the synthetic checkout. Final API records show no source drift and no rerun.

## Full QA and repeated Qt gates

[QA run 44881740990](https://github.com/djshellshoxxx/PatchTrace/actions/runs/44881740990) completed successfully.

| Full suite | Passed | Skipped | Expected failures | Warnings | Pytest seconds |
|---|---:|---:|---:|---:|---:|
| Linux — job 136778367798 | 24,190 | 53 | 3 | 21 | 2,394.87 |
| Windows — job 136778367868 | 24,059 | 185 | 2 | 22 | 3,575.91 |

Each downloaded full-suite JUnit report contains **24,246 cases, zero failures, and zero errors**. JUnit represents expected failures as a separate `pytest.xfail` skip type; its total skipped values are therefore 56 on Linux and 187 on Windows. Both Ruff steps succeeded.

Separate pair-publication boundary controls recorded **108 passed / 2 skipped on Linux** and **107 passed / 3 skipped on Windows**. Those counts are not added to the full-suite totals.

| Qt gate | Job | Passed | Pytest warnings | Seconds |
|---|---:|---:|---:|---:|
| Ubuntu 20×, shard 1/4 | 136778367760 | 13,320 | 40 | 2,785.05 |
| Ubuntu 20×, shard 2/4 | 136778367826 | 10,860 | 0 | 1,778.21 |
| Ubuntu 20×, shard 3/4 | 136778367746 | 9,840 | 0 | 1,702.03 |
| Ubuntu 20×, shard 4/4 | 136778367617 | 8,460 | 0 | 742.38 |
| Windows 5× | 136778367891 | 10,620 | 10 | 2,965.38 |

Qt counts are repeated executions, kept separate from the full suites. The reported Qt warnings concern the test's deprecated `QApplication.setActiveWindow` call.

## Actual packaged and installed checks

Windows job 136778367868 completed the build, **64 frozen CLI smoke checks with zero failures**, clean portable-ZIP extraction and checksum validation, Qt/dependency checks, pinned NSIS 3.13 installation, installer creation, and actual registration/runtime/self-test/non-destructive uninstall checks.

The built installer SHA256 reported by the actual build is:

`a341cfc25797d8b62d35779c0bc1986cbb2372624931fe9cb37f01637f32bd12`

The non-gating Windows memory-cap measurement is retained separately. Its controlled pipeline reported worker OOM at 64/96/112 MiB caps and success at 128/256 MiB; allocation controls raised MemoryError within their configured limits. These are measured control outcomes, not unexpected CI failures.

Linux package job **136797782885** succeeded on Ubuntu 22.04. The resulting artifact was independently downloaded and its ZIP digest verified by both frozen-smoke jobs:

| Frozen target | Job | Full CLI checks | Tar checksum | GUI self-tests | Missing-library warnings |
|---|---:|---:|---|---|---:|
| Ubuntu 22.04 | 136798676259 | 64 PASS / 0 FAIL | OK | Offscreen and XCB success | 0 |
| Ubuntu 24.04 | 136798676256 | 64 PASS / 0 FAIL | OK | Offscreen and XCB success | 0 |

The packaged executable was the command under test. Exact positive and negative-control check labels are retained in the per-platform receipts; a PASS label retains its stated scope, including actionable-error alternatives for applicable path checks.

## Completed native workflows and their limits

| Workflow | Run | Actual evidence |
|---|---:|---|
| Ghidriff | 44881740983 | Three known-patch positives, one expected cached-PDB negative control, and one raw-cache reuse check. Both raw outputs have SHA256 `3369565e28dd3fba96f8a34a331f17e6d3dc5bcc54c6dcefff98b7bcdba52ee7`. |
| rizin | 44881741061 | Both OS artifacts say passed, `mocked=false`, engine status OK. Observed match counts: Linux 30; Windows 322. |
| BinDiff | 44881741004 | Linux 7 passed / 0 blocked / 0 failed. Windows 6 passed / 1 blocked / 0 failed; actual Windows acceptance remains blocked on the manual network-isolation check. Synthetic 20/21-function fixtures; existing TOFU provenance limitation retained. |
| Optional dependencies | 44881741068 | Both OSes report rapidfuzz 3.14.6, yara-x 1.21.0, iced-x86 1.21.0 present and no missing dependencies. Availability probe. |
| Tier R | 44881741002 | Aggregate warning: 5/11 rz-diff pairs completed; 6 tiny pairs failed because no older-image functions were found. Windows advisory: 11 findings, all exit 1. MSVC advisory skipped. |
| Unified extraction | 44881740985 | Two fixture pairs; each has 45 PASS / 0 FAIL on Windows and 46 PASS / 0 FAIL on Linux, including actual cross-OS content-digest equality for identical DLL inputs. |

These fixture, cache, structural, and equivalence results do not establish general match accuracy or real-driver acceptance. Unified informational hash-equivalence limits remain in its ledgers.

Both Tier R shards used actual original-rizin-archive cache hits and verified the pinned original archive hash. Ghidra/Java steps were skipped for rz-diff, so this supplies no Ghidra archive-cache acceptance. The aggregate bytes and pair outcomes are identical to the retained original PR349 artifact; the explicitly historical comparison attributes an existing coverage gap and transfers no prior acceptance.

See `NATIVE-README.md`, `native-summary.json`, and the individual artifact/ledger files for exact native detail.

## Expected failures that remain open

| Scope | Exact JUnit node | Recorded reason |
|---|---|---|
| Linux and Windows | `tests/test_codex_pkg_workflows.py::test_pip_downloads_require_hashes` | CODEX-5 |
| Linux | `tests/test_tier_w_symbols.py::test_live_llvm_pdbutil_agrees_with_the_stdlib_reader` | llvm-pdbutil absent |
| Linux and Windows | `tests/test_tier_w_symbols.py::test_live_ghidra_export_runs_or_records_blocked` | No --ghidra-dir supplied |

These five platform-specific expected-failure records are retained in `expected-failures-open-gates.json`. Successful synthetic native engine runs do not close them. Full-suite live-acceptance blocked messages and platform skips remain in the original logs/JUnit reports.

## Artifacts and portability

Sixteen original current-source evidence ZIPs were downloaded, SHA256-checked against GitHub metadata, CRC-checked, and compared with every retained extracted member. Large product binaries are excluded from this portable evidence archive.

| Product artifact | Download | Bytes | GitHub ZIP SHA256 |
|---|---|---:|---|
| Windows portable/installer bundle | [14701215350](https://github.com/djshellshoxxx/patchtrace/actions/runs/44881740990/artifacts/14701215350) | 178,992,341 | `364488591dffbbf8bd2d752e7b13159e4f937d1b279e5a0b746990ec441bc857` |
| Linux package | [14701041842](https://github.com/djshellshoxxx/patchtrace/actions/runs/44881740990/artifacts/14701041842) | 118,325,538 | `0cf6583ae689fa9fde971c04a6537bdafb1fcd6a9f8b9c1e5bc844a0ac1420c3` |

Product digests agree with actual upload logs. Both Linux download logs additionally report the same verified digest. Product bytes were not rehashed locally; that distinction is explicit in `product-artifact-references.json`.

## Retained history and archive verification

`predecessor-evidence-index.json` preserves pointers and hashes for the original PR349 Linux/Windows registry failures and the superseded daee/a73 failures, partial results, and cancellations. Current acceptance comes exclusively from the fresh ae69 runs.

`final-qualification.json` is the compact machine-readable receipt. `evidence-manifest.json` lists payload file paths, sizes, and SHA256 hashes. The portable `final-ae69-evidence.zip` contains those payloads and the manifest. The external `archive-receipt.json` records the archive SHA256, manifest SHA256, byte/member counts, and completed CRC/member verification.

Complete job logs preserve the UTF-8 bytes of decoded GitHub connector responses, including returned line endings and BOM; they are not original GitHub log ZIP bytes. No workflow was retried or dispatched, no source/ref was changed, no merge was performed, and no native engine or analyzed target was executed locally by this observer.

The PR release path is intentionally skipped. The source release condition excludes a push whose actual head-commit message contains `[no release]`, even if the release gate proposes publication. Actual guarded-main-merge and post-merge publication-hold evidence is recorded separately.

