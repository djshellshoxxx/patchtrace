# SPEC-08: Binary acquisition (Phase 3a)

Status: developer-ready contract, 2026-10-12. Contract version `acquisition/1`. Verified tool facts: `../research/phase3/acquisition.md` (Winbindex @ aacec0c, live msdl probes 2026-10-12).

## 1. Outcome and boundaries

An analyst names a Windows file (e.g. `clfs.sys`) and picks two builds from a candidate list; PatchTrace downloads both from the Microsoft public symbol server with explicit consent, verifies them, quarantines and identifies them, and creates a normal two-artifact project from them. Nothing is executed, installed or re-hosted. Downloads are for the user only; PatchTrace never redistributes Microsoft binaries or bundles Microsoft DLLs. Winbindex is a metadata source (GPL-3 data, fetched at runtime, never bundled).

Out of scope for `acquisition/1`: extracting files from update packages/ISOs, Insider and ARM64 datasets (x64 only), automatic polling, and non-PE files.

## 2. Modules

| Module | Responsibility | Imports |
|---|---|---|
| `acquisition/contracts.py` | Strict records below | pydantic |
| `acquisition/winbindex.py` | Pure parsing of `<name>.json.gz` into `BuildCandidate`s; URL derivation | stdlib |
| `acquisition/transport.py` | Consented HTTPS GET/HEAD with allowlist, redirects, caps (same pattern as `enrichment/intelligence.py`) | stdlib urllib |
| `acquisition/quarantine.py` | Staging, hashing, PE/PA30 identification, promotion into project inputs | ingestion |
| `acquisition/delta.py` | Optional Windows-only PA30/PA31 reconstruction via the system `msdelta.dll` (ctypes) | ctypes (Windows) |

Pure modules import no network/Qt. The service creates projects through the existing `ProjectService.create`; acquisition only supplies verified local files.

## 3. Records

- `AcquisitionQuery`: `file_name` (lowercase basename, `^[a-z0-9._-]{1,128}$`, PE extension in {exe,dll,sys,efi,drv,ocx,cpl,scr,tsp}), `dataset: Literal['x64']`.
- `BuildCandidate`: `file_name`, `sha256`, `size` (int), `machine_type` (int; must be 34404 for x64 eligibility), `timestamp` (int, uint32), `virtual_size` (int|None), `last_section_va`/`last_section_raw` (int|None), `version` (str|None), `windows_versions` (sorted unique tuple), `kbs` (tuple of `{kb, release_date, release_version}`), `download: Literal['direct','candidates','unavailable']`, `source: 'winbindex@<data-date>'`.
- `DownloadPlan`: ordered candidates (exactly two for a project: older, newer, chosen explicitly by the analyst), exact URLs (`https://msdl.microsoft.com/download/symbols/<name>/<%08X timestamp><%x size>/<name>`), expected sha256 and size.
- `AcquiredArtifact`: local quarantine path, sha256, size, `format: Literal['pe','pa30','pa31','unknown']`, `machine`, provenance `{source_url, redirect_host, retrieved_at, winbindex_record_sha256}`.
- Identity: `acquisition_id = domain_id('acquisition', 1, {file_name, sha256})`. A matching SHA-256 proves identity with the Winbindex record, **not** vendor authenticity; Authenticode verification is out of scope for this version and is labelled as such.

### Telephony provider component names (2026-11-18)

`.tsp` is an allowed PE component suffix. Microsoft documents telephony service
providers as DLLs, including a provider named `MAIN.TSP` in the
[Telephony architecture](https://learn.microsoft.com/en-us/windows/win32/tapi/architecture).
The suffix makes a safe basename eligible for the existing metadata lookup and
explicit acquisition plan; it does not prove PE format, architecture, identity,
product applicability or a vulnerability fix. All existing hash, PE and consent
checks still apply. Do not load a provider, register it with TAPI or execute it.

## 4. Behavior

1. Metadata fetch: `https://winbindex.m417z.com/data/by_filename_compressed/<name>.json.gz` (lowercase, case-sensitive URL). Requires explicit consent naming the host and exact URL. Cap 64 MiB compressed / 256 MiB decompressed; strict JSON syntax, duplicate-key and non-finite-number validation at document scope; unpaired Unicode surrogates are rejected and counted at individual-entry scope so unrelated valid entries remain usable; required per-entry fields `fileInfo.sha256`, `size`, `machineType`, `timestamp` — entries missing any are skipped with a counted warning. All other fields optional. Windows-version keys retained in `BuildCandidate.windows_versions` are display labels only: replace control/format and Unicode line/paragraph separator characters with spaces and bound each label to 64 characters, then sort/deduplicate. If distinct source keys collide after cleaning, include the counted collision warning in `ParseResult`; retain every source mapping's KB refs and keep each binary candidate separate. Never use these cleaned labels as product or binary identity. The preserved upstream source bytes and canonical raw-entry `record_sha256` remain unchanged.
2. Download classification: `direct` when `timestamp` and `virtualSize` exist; `candidates` when `timestamp`, `size` and both `lastSection*` exist; otherwise `unavailable` ("update-package only").
3. Candidate resolution (`candidates`): HEAD each SizeOfImage from `round_up(lastSectionVirtualAddress + (size − lastSectionPointerToRawData), 0x1000)` down to `lastSectionVirtualAddress + 0x1000` in 0x1000 steps; 302 = valid, 404 = invalid, anything else = error; accept only if exactly one is valid. At most 4 concurrent HEADs, 10 s each, overall cap 256 probes.
4. Download: GET, follow exactly one redirect, only to `*.blob.core.windows.net` over HTTPS; never cache the signed blob URL. 404 = "not on symbol server" (a normal outcome, not an error). Cap 512 MiB. Stream to private staging; compute SHA-256 while streaming; reject size or hash mismatch against the plan.
5. Identification: `MZ` + valid PE → `pe` (must be AMD64 PE32+ via existing `ingestion.validate_pe`; promotion subsequently copies and validates through `ProjectService.create`); 4-byte CRC32 + `PA30`/`PA31` at offset 4 (CRC verified: `zlib.crc32(data[4:]) == le32(data[:4])`) → `pa30`/`pa31`; raw `PA30` at offset 0 → `pa30`; else `unknown`. Only `pe` can become a project input.
6. Delta reconstruction (optional, Windows only): `ApplyDeltaB` from the system `msdelta.dll` for PA30; PA31 only with a user-selected `UpdateCompression.dll` path. Requires the exact base file; chain reverse (`r`) then forward (`f`); output must hash to the expected SHA-256. `DeltaFree` always called. On non-Windows the capability reports `unsupported` explicitly. No pure-Python applier is used (none is complete and licensed).
7. Promotion: verified `pe` files are passed to `ProjectService.create(older, newer, name, root)`; provenance is recorded in the project (`Artifact` name plus an acquisition annotation). Staging is deleted only for the current operation.

The 256 MiB decoded-document limit also applies to uncompressed JSON supplied to
`parse`, `parse_rows`, or the shared `strict_json` boundary. Check the byte length
before UTF-8 decoding or JSON allocation. Exactly the limit remains eligible;
one byte over returns `PT-ACQ-LIMIT`, even for otherwise valid JSON. Compression
format and file-extension choices never waive this resource limit.

Network: HTTPS only; allowlist `winbindex.m417z.com`, `msdl.microsoft.com`, `*.blob.core.windows.net` (redirect target only); environment proxies ignored; no credentials; User-Agent `PatchTrace`; bounded retries (429/5xx, ≤ 3, Retry-After ≤ 60 s); cancellable. Nothing about the user's projects is sent.

Winbindex metadata has one 120-second network-operation budget, including all
attempts, connection/header waits, retry delays and body reads. Check cancellation
and this deadline before every request and after response headers. Each connection
timeout is the smaller of the ordinary 10 seconds and the remaining budget. Never
sleep for a Retry-After/backoff that would exhaust the remaining budget, retry
early against that server delay, or open another request after an overshooting
sleep. Preserve typed network/cancellation outcomes and close returned responses.
The shared internal retry helper accepts an optional deadline; other acquisition
operations retain their existing policies when it is absent. A custom opener must
honor its supplied timeout; this contract adds no arbitrary-call interruption or
local parsing CPU timeout.

## 5. Surfaces

- CLI: `PatchTrace acquire search NAME [--json]` (metadata only, needs `--consent-hosts winbindex.m417z.com`), `PatchTrace acquire fetch NAME --older SHA --newer SHA --project DIR --consent-hosts winbindex.m417z.com,msdl.microsoft.com [--json]`. Exit codes per SPEC-07 §11 (0/2/3/4/5; 4 = no downloadable candidates).
- GUI: New → "Download from Microsoft symbol server…" dialog: name, candidate table (version, KB, release date, download availability), explicit older/newer selection, consent text listing hosts and URLs, progress, cancel.

## 6. Acceptance

Pure: Winbindex fixture parsing (trimmed real afd.sys record + synthetic variants: missing virtualSize, missing required fields, non-x64), URL formatting `%08X%x`, candidate enumeration arithmetic, CRC/PA30 identification, wrong-hash rejection. Transport with fake opener: allowlist, single redirect to blob host only, 404 semantics, caps, cancellation, proxy ignored. Live probe (recorded separately, not CI-gating): one direct download of a small x64 system file with hash match. Windows-only CI: `msdelta.dll` presence and ApplyDeltaB on a synthetic delta created with `CreateDeltaB` in the test itself (no Microsoft payload committed).

### Promotion failure after initial snapshot (2026-11-05)

After `ProjectService.create` commits a normal project, a failure while checking copied identities or recording acquisition annotations must retain that committed project, its persistent lock inode and any contributor files. Close the service to release ownership; never recursively delete the project as rollback. Ordinary failures surface as the existing typed `AcquisitionError` (preserve an existing acquisition code, otherwise PT-ACQ-VERIFY), with the exact retained project path and a clear statement that acquisition provenance/final copy verification did not finish. Reopening permits analyst inspection, and an immediate new create at the same destination remains refused because a committed database exists. Interruptions are reraised after releasing the service, retaining files. This changes no wire/schema fields or error-code vocabulary. Failures before the first snapshot stay the existing ProjectService creation rollback path; acquisition staging cleanup still affects only the operation's private staging directory.

Destination preflight in acquisition/workflow.check_project_root uses the same read-only creation_directory_available storage helper as the dialogs and KB attachment intent: absent/empty/sole regular persistent lock is allowed, other entries and symlinks are refused. Actual project creation still acquires the kernel lock and refuses existing committed databases. No metadata/PID content is treated as lock availability.
