# SPEC-31-D: Verified Acquisition, Delta Recovery and Offline Package Safety

Status: developer-ready with optional advanced package support. Parent [SPEC-31](../kb-cve-correlation-and-acquisition.md). Depends on 31-A/C and existing SPEC-08. Owner: acquisition worker. First release uses existing Winbindex+symbol server and local PE import.

## D1. Sequence and exact ownership

Do not replace acquisition.winbindex.parse, metadata_url, BuildCandidate, acquisition.transport, acquisition.quarantine or acquisition.delta. The new bridge converts a chosen immutable PairProposal to the existing SPEC-08 DownloadPlan, coordinates separate old/new fetches and checks final hashes. It must use ProjectService.create only after both files are ready and SHA verified. No source provider creates a project; no Qt worker writes the project database.

Stages with side-level status: identified -> planned -> consented -> downloading -> staging -> format-detected -> delta-requires-base or final-pe-verified -> hash/PE/signature-assessed -> eligible-for-promotion. Any failure leaves old and new completely segregated and previously valid project untouched. A failed second side must not promote the first side into a project. DownloadPlan itself is immutable and pinned by plan_sha; consent covers exact URLs and operation kinds, not merely a checkbox/host.

## D2. Reuse of existing transport constraints

SPEC-08 constraints remain authoritative for symbol-server use: Winbindex metadata compressed ≤64 MiB and inflated ≤256 MiB, downloader payload ≤512 MiB, validated Microsoft symbol-server host and bounded redirect to Microsoft Azure blob endpoint, at most 256 candidate HEADs / four concurrent probes, bounded retries/timeouts, exact hash check against selected metadata record, no external upload. Explicit request-specific network authorization; --offline ignores all prior grants. Actual redirected signed URLs are never persisted. Enforce no proxy inheritance per existing transport until an explicit profile setting is reviewed.

Metadata fetch + binary fetch are two separate grants. An acquired sample's SHA matching Winbindex proves index consistency, not Microsoft vendor signature. Preserve source entry hash, expected vs observed bytes/hash, original and final response host, source record time and parser version.

Workspace metadata publication amendment (2026-11-05): after validating exact
Winbindex record bytes, `save_winbindex_record` uses the existing shared atomic
writer: create an exclusive, unique same-directory stage, write/flush/fsync,
then atomically replace the explicit same-name/date record. Existing fixed
`<record>.tmp` entries are foreign to this attempt and must not be opened,
modified, published or removed. A pre-publication write/flush/replace failure
preserves the prior committed record and cleans only the attempt's stage.
If buffering the newly created stage fails, close the still-owned raw
descriptor as well as cleaning the stage; once buffering succeeds, the stream
owns that descriptor and closes it exactly once.
Plain/gzip same-name/date replacement remains explicit and compatible. This
publication refuses an observed symlink or Windows junction at the workspace's
`winbindex` child before staging, preserving any aliased foreign directory.
It does not promise a sandbox against a noncooperating writer replacing parent
directories or stage/final pathnames after ownership checks.

### Offline index reader source-identity admission (2026-11-20)

An offline Winbindex record is identified by its file basename and data date,
with exactly one of the plain JSON or gzip encodings present for the selected
newest date. The reader must refuse simultaneous plain/gzip records of the same
basename and newest data date as an ambiguous input, regardless of directory
iteration order; it must not arbitrarily choose one claim source. Historical
older dates are still ignored when a unique newer record exists. A matching
record path that is a symbolic link or junction, or an aliased index directory,
invalidates the lookup before parsing any bytes; a missing ordinary record still
returns no rows. These are fail-closed input admission checks, not assertions
that the content is official or that a noncooperating writer cannot replace a
file between checks and read. Do not merge different raw records or fabricate
resolver membership from conflicting sources. This bounded safety repair is
**not** the outstanding full raw entry/index capture or resolver-input replay.

### Held offline reader and nonregular-source admission (2026-11-20, generation 17)

A name/date-matching workspace record that is a directory, FIFO, device or
other non-regular object is **not an absent record** and cannot silently make
a prior dated record appear newest. Refuse it with `PT-KBC-SOURCE` before
choosing any date. Ordinary absent filenames still return no rows; an alias
remains rejected under the earlier source-identity contract.

The selected record's prior pathname admission can become stale before open.
Where the host supports `O_NOFOLLOW`, open the record with that flag and
refuse a final-component symlink substitution as `PT-KBC-SOURCE`. Request
nonblocking open where supported, then confirm the **opened descriptor** is
regular before reading bytes; do not risk blocking on a substituted FIFO.
A regular record can also become a directory **after** `_record` selects it
but **before** the held `open`. On POSIX this may raise `EISDIR` from the
Python file-open wrapper before descriptor `fstat` runs. Classify that
specific nonregular-source substitution as `PT-KBC-SOURCE`, matching the
original admission contract; do not misreport it as a generic unreadable
input. Ordinary permission and I/O failures retain `PT-KBC-INPUT`. This
classification is not proof of source authenticity, does not make the
replacement atomic, and provides no Windows path race guarantee.

Continue to cap the descriptor read to `MAX_COMPRESSED + 1`, leave existing
valid rows and rejected-row counts intact, and never read a nonregular handle.
On hosts without `O_NOFOLLOW`, this does not provide the same final-component
race protection. No claim is made for parent-directory replacement, a swapped
ordinary regular file, source authenticity, full raw-index retention or the
separate Linux forced-export publisher race. The latter remains open.

### Offline index reader read budget and rejected-row freshness (2026-11-20)

The selected workspace record is untrusted and mutable. Once admitted, each
read must take **at most MAX_COMPRESSED + 1 bytes** from the opened stream,
refusing an over-budget body with `PT-KBC-LIMIT` before parsing; a preceding
pathname size check is advisory and may be stale. Do not allocate the complete
file via an unbounded read based only on an earlier `stat`. This guard does
not authenticate the source, pin its pathname through a competing replacement,
or close the Linux forced-export race in a separate publisher.

The index adapter's `skipped_rows` is scoped to the **current read of that
filename**, not to earlier records read by the same adapter instance. A missing
record has no rows and **zero** rejected entries, even when a prior record was
partially parsed; an unusable record reports its error rather than reusing an
older count. Preserve valid current-record skipped counts and existing
`index_rows` rejection accounting without inventing historical coverage.

### Offline version/body coverage accounting (2026-11-20, generation 19)

`parse_rows` exposes two independent rejected-input counters:
`skipped` for unreadable top-level SHA entries, and `skipped_bodies`
for unreadable Windows-version/KB bodies or version containers. The
workspace `IndexPort.rows` gap count MUST carry **both** parser counts
plus independent `lineage.index_rows` conversion rejections. A malformed
version/body cannot silently disappear and make an otherwise usable index
appear complete. Do not add successful normalized rows to the gap count,
count a rejected input twice, or call these rejected *units* the exact
number of missing builds. A missing current record still resets the count
to zero. File import receipts must report a separate `skipped_bodies`
field, preserving the existing meaning of `skipped`; human-readable import
output must also show nonzero unreadable version/KB body counts without
relabeling them as invalid top-level entries. Existing source
bytes, parser warnings, consent and provenance are unchanged. This is
bounded gap accounting, **not** full raw entry/index persistence or replay
of resolver input membership.

### Generation 20: Winbindex entry container loss accounting (2026-11-20)

For a top-level SHA entry whose `fileInfo` is already accepted by
`parse_rows`, an absent `windowsVersions` field or a present
`windowsVersions` value that is not a JSON object is **one
unreadable source container**. Count that unit in `skipped_bodies`,
even when another SHA entry in the same index produces valid rows.
Do not silently make the surviving rows appear to cover the entire index.

An explicitly present **empty object** `windowsVersions: {}` is an
observed empty set, not a rejected body; its loss count stays zero.
Do not infer a missing KB, version, fixed build, or a precise number of
unobserved builds from this container gap. Do not count one loss per
nonexistent version key. Malformed top-level entries remain counted once
under `skipped`, not a second time under `skipped_bodies`.
Keep `parse` (the separate acquisition candidate parser) unchanged.

The existing workspace index gap forwarding, import receipt's distinct
`skipped_bodies`, and conditional plain-text disclosure apply to this
new container-loss unit. No change is authorized to raw index retention,
resolver membership, binary confidence, native accuracy, consent,
source authenticity, limits, or release gates.

### Generation 21: same-read offline index gap identity (2026-11-20)

A single `WorkspaceFileIndex.rows(file_name, key)` result must bind its
normalized row mappings and **all parser rejection counts** to the **same
selected record read**. A concurrent or re-entrant `rows_for` call for the
same filename must not overwrite or clear the first call's loss accounting
between parsing and lineage conversion. Carry the count as call-local data,
not mutable adapter-wide state; add downstream `index_rows` conversion rejects
to that local count only. Preserve the separate `rows_for` mapping-only port,
original record admission and size limits, and the no-record zero-gap behavior.

This is distinct from generation 16's *sequential* missing-record freshness
repair: even when both reads succeed, interleaving can combine one read's
rows with another read's loss count, making an incomplete source look complete.
No source byte retention, resolver membership replay, new serialization,
source authenticity, cross-process snapshot, or Linux forced-export race
closure is inferred from this narrower same-call accounting guarantee.

### Generation 22: malformed BASE body loss accounting (2026-11-20)

A `BASE` body is readable only when it is a JSON object with a
`windowsVersionInfo` JSON object. If `BASE` has no
`windowsVersionInfo` member or that member is not an object, count this
as **one unreadable source body** in `skipped_bodies` and do not emit an
apparently valid undated baseline row. The next valid sibling rows are
preserved. This is independent of top-level SHA and version-container
losses, and a rejected body must not also be counted as a successful row.

An explicitly present `windowsVersionInfo: {}` is structurally readable
but has no known release date; keep its baseline row with
`release_date=None` and do not invent a date. Malformed or absent
`releaseDate` inside a valid object also remains an unknown date, not
a fabricated chronology fact. The ordinary KB `updateInfo` contract,
separate acquisition `parse` API, raw source bytes, resolver membership,
limits and existing public return shapes remain unchanged. This is only a
source-loss accounting repair; not complete raw retention, provenance
authentication, verified accuracy or release qualification.

### Generation 23: source-file admission for offline Winbindex imports (2026-11-20)

`save_winbindex_record` imports an existing local metadata **file**, not a pipe,
device, directory or other streaming endpoint. On a host that exposes
`os.O_NONBLOCK`, opening the user-selected source MUST request that flag,
so a substituted named pipe cannot block the importer before any size or
parser control runs. Check `fstat` on the opened descriptor and refuse
all non-regular sources with `PT-KBC-INPUT` **before reading or publishing**.
Do not rely only on a stale pathname inspection. On hosts without a supported
nonblocking-open capability, do not claim this fully prevents pre-open blocking.

A user-selected symbolic link resolving to a regular file remains supported,
consistent with the existing manual import path. This check is a filesystem
input and liveness guard, not vendor authentication or protection from a
noncooperating replacement of one regular file with another. Keep the
existing `MAX_COMPRESSED + 1` bound, strict parser, receipt schema, raw
record bytes, destination publication semantics and error code for unrelated
read failures. The separate Linux forced strings export replacement interval
remains open; this import admission cannot close it.

## D3. Verification precedence and authenticity states

Mandatory: stream to private non-executable staging, bounded size, SHA-256, final PE parse, supported architecture, filename identity, selected product/build association, chronology check, stable final bytes (no TOCTOU between verification and project copy). Promote only after re-opening/hash verification via existing ingestion path. Use private scratch names chosen by program; reject symlink traversal and path escape.

Distinct authenticity states:
- hash-matched-to-index: exact digest matches Winbindex source entry; no publisher authentication inferred.
- embedded-signature-valid: Windows Authenticode verification succeeded and identifies signer under recorded trust policy.
- catalog-signature-valid: matching catalog member hash and trusted catalog signature verified; important because many Windows binaries are catalog signed without embedded signatures.
- signature-unknown: no reliable verification, non-Windows host, unavailable catalog, untrusted/offline root state.
- signature-invalid: cryptographic failure or identity mismatch.
A signed package does not imply every extracted artifact is a valid target build without matched manifest identity. Verification result must capture policy, verifier version, time/chain status and SHA. For first alpha, report signature-unknown and keep strict policy configurable; never label Winbindex checksum as signed.

Microsoft docs distinguish catalog and embedded signing; future verifier can reuse pe_overview/authenticode.py if Windows-tested, or use separate WinVerifyTrust/CryptCAT APIs. Do not assume that inspecting a PE certificate table verifies catalog-member signing.

## D4. Direct/delta formats

Direct PE: existing quarantine identifies MZ/PE AMD64, verifies final expected hash and passes artifact path.

PA30/PA31 (and any recognized variant): return NEEDS_BASE rather than treating delta bytes as a PE. Resolve exact base artifact SHA and package/branch lineage, not simply a same-named older file. Maintain ReconstructionPlan (algorithm, delta_sha, expected_output_sha, base_sha, base_source, platform capability, required DLL/tools, resource estimates). Apply only with user-approved known exact base. SPEC-08 currently defines Windows msdelta.dll ApplyDeltaB for PA30 and optional explicit UpdateCompression.dll for PA31. Treat unsupported extensions as UNSUPPORTED_FORMAT. A delta chain (A -> B -> C) requires every verified intermediate output SHA; a wrong base aborts before promoting any output. All temporary outputs remain quarantined and rehashed.

No arbitrary Windows executables from package content are launched and no WUSA/online DISM operations. No Python 'best-effort' decompressor may label a partial reconstruction successful.

## D5. Package fallback as an optional separate capability

Initially provide official Microsoft Catalog browser handoff and manual local MSU/CAB intake, not an unverified programmatic Catalog JSON API. Never scrape temporary Catalog download URLs and persist them as a stable provider contract. Do not automatically install packages.

Inventory contract:
PackageSource (name, original_path_redacted, local_sha256, source_uri?, source_claims, signature_state)
PackagePart (kind msu|cab|cat|mum|manifest|delta|fullfile|unknown, inner_path, compressed_size, decompressed_size?, observed_sha, parent_sha, required_checkpoint_ids, package_identity?)
PackageInventory (package_id, parts, selected_product_scope_id?, applicability, manifest_evidence, component_claims, warnings, complete boolean)
All member paths are logical archive paths; physical extraction stays under private root.

For Windows servicing, catalog-provided MSUs on 24H2 and Server 2025+ may depend on previous checkpoint updates. Graph prerequisites come from independently sourced metadata; do not infer dependencies solely from naming or KB order. DISM image servicing, if offered in a later separate milestone, MUST operate only on an explicitly supplied disposable offline image, never /Online or the analyst workstation. Different servicing baselines, optional features and languages may yield different outputs.

## D6. Extraction threat model and budgets

Default optional package limits (tune with real fixtures): input ≤4 GiB, total expanded ≤8 GiB, per-entry ≤1 GiB, max entries 50k, recursive archive depth ≤4, min free space ≥2× estimated scratch, total 30 minutes, max 2 workers. Reject absolute/drive/UNC paths, path traversal, alternate data streams, NTFS reparse points, filename casefold collisions, decompression bombs, size lies, symlink/hardlink target escapes, duplicate manifest identities and hostile locale/unicode path tricks. Output creation must use exclusive handles in a newly created private directory under a controlled base. Never trust archive manifest file paths as host paths. Version and sanitize helper tool stdout/stderr, bound it, shell=False, absolute paths and process-tree kill-on-cancel. Prefer header/manifest inventory without full extraction. Enforce actual expanded bytes incrementally, not a declaration alone.

## D7. Crash and cancellation

A plan can be retried only when same plan_sha and expected bytes; staging artifact SHA must be verified again after restart. Partial files carry separate .partial marker and cannot be selected by pair resolver. Cancellation closes handles, terminates controlled jobs, retains completed verified source caches but never updates active project on incomplete state. Interrupted attempt journal records plan_id, side, last completed stage, file/hash, failure reason and cleanup outcome; stale workdirs are removed only if owned by the job and no live lock. No implicit resume that accesses network.

Service lifecycle amendment (2026-11-05): `KbService.acquire` accepts optional
`cancel` and `expected_revision` keyword arguments with backwards-compatible
defaults. A supplied stale revision is refused before staging/networking; an
already-set cancellation token returns cancelled without staging. Forward the
same token into the existing acquisition bridge and check it again at the
final import boundary. Capture the exact committed investigation revision and
ordered source records before resolution, and compare that snapshot before
staging and immediately before importing verified bytes. Source additions before
final source admission or revision/lead/scope changes invalidate the in-flight
operation even when the binary request plan itself is unchanged. Always pass
the captured revision to `import_pair`, whose in-store guard refuses a later
revision change. The acquisition callback also passes optional
`expected_source_snapshot` (the exact
ordered SourceDoc JSON strings, default `None` for existing manual callers).

Source admission amendment (2026-11-06): build one advisory index from the
workspace's materialized, ordered source records, then compare the current
source records with the captured snapshot before approval/project writes.
Cooperative source imports append immutable records and content-addressed
objects, so an addition before or during index construction returns stale
without creating a project. On successful admission, reuse that exact index
for selected-product validation, lead resolution and ContextBundle construction;
do not reload sources after approval. A source committed after admission remains
available in the workspace but is excluded from this operation's context and
source sidecars. Stored search coverage remains bound to the immutable coverage
IDs in the captured investigation revision; revision compare-and-swap and
attachment journal behavior remain unchanged. Existing manual callers without
`expected_source_snapshot` retain their current index-loading behavior.
Refusals discard owned staging and preserve prior completed projects; ordinary
CLI product/file selection and exact request-plan consent remain unchanged.
Snapshot comparison is an admission check, not one atomic transaction spanning
download and import; cancellation does not undo an already committed project.

## D8. Fault injection and acceptance

Acceptance matrix:
- old downloaded, new 404 -> no project, metadata retained.
- first 302 to unexpected host -> rejected, no data written outside quarantine.
- wrong SHA same size -> verification failure, never reused.
- PA30 with missing base -> explicit needs-base, metadata available.
- PA30 correct base -> verified final PE SHA (native Windows fixture required); PA31 missing UpdateCompression.dll -> typed unsupported.
- changed source bytes during copy -> fail rehash.
- user-provided local signed file but product unknown -> can inspect manually, no verified product label.
- malicious CAB entry ..\\ or C:\\ / ADS / duplicate case -> blocked.
- compressed package crosses expanded cap -> bounded abort, no partial project.
- valid package with two checkpoint dependencies -> ordered plan or unknown if graph lacks evidence.
- cancellation between staging and ProjectService.create -> atomic project absence and no orphan records.
- frozen Windows build passes direct PE pair import and one delta fixture independently; Linux reports Windows-only functionality as unsupported, not success.

Exit/transport codes wrap existing PT-ACQ-* with PT-KBC-* wrapper but do not alter existing CLI behavior. Docs: https://learn.microsoft.com/windows/deployment/update/catalog-checkpoint-cumulative-updates , https://learn.microsoft.com/windows/win32/secbp/understanding-pe-signatures , https://learn.microsoft.com/windows-hardware/drivers/install/catalog-files .
