# WB3 integration plan: pair-aware strings on the built FLOSS adapter

Status: E-1 research plan; WB3-S1 to S5, S7a and S8/S9 service and tests (view-model, copy, tooltip entries) built (strings sources, regions/cues/look-alike, built-in scan, links L1/L4/L5, basis/delta/edits/rank). Date 2026-10-14. Base `prep/program-e` d972125 (this worktree was fast-forwarded from the stale 1560531; nothing else changed). Read: AGENTS.md, CLAUDE.md, roadmap s3, modules.md, todo.md, `workbench/03-floss-strings.md`, `three-tool-evidence-adapters.md` T1-T10, `intelligence/tools/{floss,common,process,normalize,delta}.py` with tests and goldens, `normalization.py`, `models.py`, `evidence.py`, `jobs.py`, `cli.py`, `ui_evidence.py`, `tooltips.py`, `intelligence/anchors.py`, SPEC-31 IR docs. `F1..F22` are the facts of section 2.
Status: E-1 research plan; WB3-S1 to S6 built (strings sources, regions/cues/look-alike, built-in scan, links L1/L4/L5, basis/delta/edits/rank, anchors/search rows/export/CLI dispatcher). Date 2026-10-14. Base `prep/program-e` d972125 (this worktree was fast-forwarded from the stale 1560531; nothing else changed). Read: AGENTS.md, CLAUDE.md, roadmap s3, modules.md, todo.md, `workbench/03-floss-strings.md`, `three-tool-evidence-adapters.md` T1-T10, `intelligence/tools/{floss,common,process,normalize,delta}.py` with tests and goldens, `normalization.py`, `models.py`, `evidence.py`, `jobs.py`, `cli.py`, `ui_evidence.py`, `tooltips.py`, `intelligence/anchors.py`, SPEC-31 IR docs. `F1..F22` are the facts of section 2.

## 1. Verdict and scope
- Build a pure `patchtrace.strings` layer on the **already built** FLOSS adapter (the workbench spec's "not landed" is stale): compact per-side `StringTable`, settings-aware comparability, per-type delta, function links in tiers (L1, L4, L5 usable now; L2, L3, L6 when SPEC-31 IR or capa deliver), content cues and ordinal review tiers (no scores), advisory-anchor join, WB1 search rows, read-only CLI, one Strings tab in the single window.
- The value is the join, not the extraction (F4, F11): string <-> matched function pair, string <-> advisory/CVE text, imports (dynamic-API cue), build facts, rule seeds, series. FLOSS alone cannot say which function uses a static string (F5).
- FLOSS runs only through the shared `intel-tools` runner (one execution path), never automatically. Static strings need no emulation; stack/tight/decoded stay consent-gated emulation (F6) with time and memory caps. The target is never executed: it is data, copied read-only as `artifact.bin`.
- Recommended, owner decision Q1: also ship a ~100-line built-in byte scan that reproduces FLOSS 3.1.1 static semantics (F4). Reasons: the panel is otherwise empty on a fresh Windows install; the FLOSS bundle is 31.9 MB with an end-of-life CPython 3.8.10 (F8); it cannot be pip-installed wheels-only (F9). It is labelled "Built-in scan", never "FLOSS".
- Deliberately not built: Python FLOSS import, a second FLOSS parser, auto-download, JSON import (v1), the unreleased master/3.2 schema (F2), numeric scores, "fixed/vulnerable" wording, strings as a function matcher, FLOSS tags until released, graph drawing (a badge port only), any automatic run on project open.

## 2. Sources and facts (all retrieved 2026-10-14)
| id | claim | source URL or repo path | retrieved | conf |
|---|---|---|---|---|
| F1 | FLOSS 3.1.1 (2024-09-26) is the newest release: PyPI latest; HEAD probes of `releases/download/<tag>/floss-<tag>-windows.zip` give 302 for v3.0.1, v3.1.0, v3.1.1 and 404 for v3.1.2, v3.2.0, v3.2.1, v3.3.0, v3.4.0, v4.0.0, v4.0.1, v4.1.0. Apache-2.0. Releases API, feeds and release pages return 403 here. | pypi.org/pypi/flare-floss/json; github.com/mandiant/flare-floss/releases/download/v3.1.1/floss-v3.1.1-windows.zip | 2026-10-14 | high |
| F2 | Master is ahead of 3.1.1 while `__version__` still says 3.1.1 (the T1 "master still 3.1.1" row hides this): layout tree, per-string `tags/section/structure`, `metadata.md5/sha1/sha256`, `analysis.enable_language_strings/layout/tags`, `--string-type/--no-string-type`, result cache `FLOSS_CACHE_*`. A build from master reports 3.1.1 but fails our strict 3.1.1 result parser (unknown keys) and may fail the option probe: pin by asset hash, never by "FLOSS 3.x". | raw.githubusercontent.com/mandiant/flare-floss/master/{floss/version.py,floss/results.py,doc/usage.md,doc/results_document.md,README.md} | 2026-10-14 | high |
| F3 | 3.1.1 JSON: metadata{file_path,version,imagebase,min_length,runtime,language*}, analysis{4 enable_*,functions}, strings{6 arrays}; no hashes, no layout. Rendered by `json.dumps(sort_keys=True)` (ASCII-escaped, so Windows pipe code pages are harmless) and embeds `start_date` and timings, so raw bytes differ run to run. | .../flare-floss/v3.1.1/floss/{results.py,render/json.py} | 2026-10-14 | high |
| F4 | 3.1.1 static strings are two regexes over the whole file: bytes 0x20-0x7E plus TAB, min 4 (CR and LF end a string), and UTF-16LE of those ASCII-range characters only; offsets are file offsets; duplicates are kept; non-ASCII wide text, UTF-8 multibyte and packed data are not covered. | .../v3.1.1/floss/utils.py L10-87 | 2026-10-14 | high |
| F5 | `main()`: exit 0 with empty stdout when no static string (L572-574); language (Go/Rust) strings come from static mode without emulation (L653-683); no TTY prompt when `--only` is given (L626-644); deobfuscation aborts before printing anything above 16 MiB unless `-L`, exit 255 (L689-695, const.py); `--only static` never loads vivisect (golden: imagebase 0, functions.discovered 0). | .../v3.1.1/floss/{main.py,const.py}; repo goldens | 2026-10-14; repo d972125 | high |
| F6 | Emulation = pure-Python vivisect emulator. `api_hooks.py` imports no os/subprocess/socket/ctypes; hooks simulate a few APIs in emulated memory; calls to unhooked imports are jumped over with return 0 (viv-utils L313-337). Bounds: 20000 insns/function, 10000 per tight loop, 300 revisits, 100 MB per emulator map, top-20 decoder candidates (main.py L773). Workspace analysis before emulation has no such bound. | .../v3.1.1/{doc/theory.md,floss/{decoding_manager,const,api_hooks}.py}; raw.githubusercontent.com/williballenthin/viv-utils/master/viv_utils/emulator_drivers.py | 2026-10-14 | high (analysis phase unbounded: medium) |
| F7 | Release assets are one-member zips: `floss.exe` 31,866,819 B and `floss` 40,885,080 B (PyInstaller onefile). Re-hashed now; the Linux executable equals the digest recorded by the T-track real runs. `qa.md` abbreviates the Linux zip digest as `...2666`; measured ends `...4666` (transcription slip, size equal). Pins below. | github.com/mandiant/flare-floss/releases/download/v3.1.1/*; repo tests/fixtures/intel_tools/manifest.json | 2026-10-14 (downloaded, hashed); repo d972125 | high |
| F8 | Windows bundle (TOC parsed with PyInstaller 6.22.3, nothing executed): 90 entries, longest extracted member 47 chars, `python38.dll` = CPython 3.8.10 (last 3.8 build with binary installers 2021-05-03; EOL 2024-10-07; later fixes were source-only), vivisect 1.2.1, pydantic_core cp38, binary2strings cp38. The tool that parses hostile bytes runs on an interpreter without the 3.8.11-3.8.20 security fixes. | measured; raw.githubusercontent.com/python/peps/main/peps/pep-0569.rst | 2026-10-14 (measured) | high (patch-level inference: medium) |
| F9 | `flare_floss-3.1.1-py3-none-any.whl` (15.2 MB) needs `binary2strings`, whose only wheel is `cp310-win_amd64` (0.1.13, 2023-07-20) plus an sdist: `pip --only-binary=:all:` cannot install FLOSS on Python 3.12 or Linux. vivisect 1.3.2 is a pure wheel. | pypi.org/pypi/{flare-floss,binary2strings,vivisect}/json | 2026-10-14 | high |
| F10 | PyInstaller onefile extracts `_MEIxxxxxx` into the temp folder and removes it at exit, not after a kill. PE section data sit at PointerToRawData and are zero-padded when SizeOfRawData < VirtualSize. Windows long paths need registry plus manifest opt-in; directory names must stay MAX_PATH-12. | raw.githubusercontent.com/pyinstaller/pyinstaller/v6.22.3/doc/operating-mode.rst L186-231; MicrosoftDocs/win32/docs/desktop-src/{Debug/pe-format.md L477,FileIO/maximum-file-path-limitation.md} | 2026-10-14 | high |
| F11 | Ghidriff JSON root `strings` = {added, deleted}: non-function symbols whose data `hasStringValue()` that failed name matching; each entry has `name` (Ghidra label with the address embedded), `address`, `refcount`, `reftypes`, `calling` (short names of functions containing a referencing instruction). Moved strings therefore appear as add+delete. Ghidriff's LICENSE file is GPL-3.0 text (the roadmap files it under GPL/AGPL): output-format facts only, no code copied. | raw.githubusercontent.com/clearbluejar/ghidriff/main/ghidriff/ghidra_diff_engine.py L379-422, 1289-1297, 1571-1655, 1808 | 2026-10-14 | high (code read, not run) |
| F12 | Persisted Ghidriff JSON keeps `instructions/mnemonics/blocks` as hash ints (no assembly); its matchers include StringsRefsHasher/StrUniqueFuncRefsHasher, so strings can share origin with the pairing. | repo docs/research/unified-engine/03-ghidriff-rizin.md L29,58-59 [run] | repo d972125 | high |
| F13 | Ghidra decompiler prints image strings as `"..."` (wide `L"..."`), escapes C0, DEL/C1, bidi and specials, `\ " '` as `\0 \a \b \t \n \v \f \r \\ \" \'` else `\xNN/\xNNNN/\xNNNNNNNN`, and ends long ones with `..." /* TRUNCATED STRING LITERAL */`. Escapes cannot be parsed back unambiguously, so literals are matched by escaping, never by unescaping. | raw.githubusercontent.com/NationalSecurityAgency/ghidra/master/Ghidra/Features/Decompiler/src/decompile/cpp/{printc.cc L1489-1614,printlanguage.cc L415-491} | 2026-10-14 | high |
| F14 | Cost evidence: tiny synthetic PE, Linux: static 1.0-1.1 s (onefile cold start), emulation 5.7-6.3 s. Real-binary time, RSS and string counts were not measured [unverified]. | repo tests/fixtures/intel_tools/manifest.json | repo d972125 | high (synthetic only) |
| F15 | Existing per-string pydantic contract at 200k strings per side (Py 3.13.16, shared host): build 5.2-6.6 s and ~0.5 GiB per side, one-side JSON 138 MB, reload 8.5 s with 2.0 GiB peak, delta 2.5 s. | measured by this worker; not committed | 2026-10-14 (measured) | medium |
| F16 | Qt 6.12.0 (pinned PySide6 6.12.0): QToolTip tips are rich-text strings and wrap by `mightBeRichText`; `accessibleDescription` falls back to the tooltip; item-view cell name = AccessibleTextRole else DisplayRole, description = AccessibleDescriptionRole; `resizeContentsPrecision` defaults to 1000 rows; Windows uses `QWindowsUiaAccessibility`. UI Automation Table needs a regular row/column grid with header elements (no merged cells). | raw.githubusercontent.com/qt/qtbase/v6.12.0/src/{widgets/kernel/qtooltip.cpp L44-47,152,widgets/kernel/qwidget.cpp L11817-11870,widgets/accessible/itemviews.cpp L1322-1328,widgets/itemviews/qheaderview.cpp L1323-1343,plugins/platforms/windows/qwindowsintegration.cpp L32,105,561}; MicrosoftDocs/win32/docs/desktop-src/WinAuto/uiauto-implementingtable.md | 2026-10-14 | high |
| F17 | Blocked from this sandbox (403): api.github.com, GitHub release pages and feeds, doc.qt.io, learn.microsoft.com, www.sqlite.org, docs.python.org. Mirrors above replace them; SQLite FTS5 details belong to WB1. | proxy status | 2026-10-14 | high |
| F18 | Repo seams: `FunctionRecord` code/assembly exist only for changed functions; `anchors.py` deliberately never links anchors to diffs; SPEC-31-E/PIL require `lineage_group`, call string-only evidence a "tentative anchor" and list "introduced log string" as a golden negative. | docs/specs/kb-cve/31-E-evidence-intent.md L13-22,63,80; intelligence/anchors.py | repo d972125 | high |
| F19 | `FunctionPairing` gives pair status (added/removed/modified/unchanged/ambiguous/unknown) and the exactly-one-record rule; `evidence._related` resolves names only when unique over name, `metadata['upstream_name']` (the short Ghidra name, which is what `calling` holds) and `fullname` within one run and artifact. | repo intelligence/tools/normalize.py, evidence.py L24-33, normalization.py L63-65 | repo d972125 | high |
| F20 | Process seam: `run_process(..., separate_streams, stderr_limit, memory_limit_bytes)`, `ProcessResult.peak_memory_bytes` (Windows); stdout is decoded with `errors='replace'` and only the tail is kept past the limit; `process.execute` does not pass `memory_limit_bytes`. | repo jobs.py L226-336, process.py L267-279 | repo d972125 | high |
| F21 | Defects in current code: truncation (cap applied in input order: ASCII, then UTF-16, language, stack, tight, decoded) still yields added/removed in `delta`; `value_hash` ignores encoding so an ASCII->UTF-16LE change is invisible; decoded strings keep only the decoder VA (no call site, no string address); consent text omits that unhooked calls are skipped and the runtime is end-of-life. | repo floss.py L301-305,344-347,45-51, delta.py L164-190 | repo d972125 | high |
| F22 | Cache seam: `DerivedCache.get/put(stage, key64hex, payload, inputs)` with stage names `[a-z][a-z0-9-]{0,31}`; `evidence_entry_id`/`config_digest`/`cache_key` are content addressed; enrichment `KINDS` already reserves `tool-run`, `tool-evidence`. | repo enrichment/cache.py L209-215,366-384; storage.py L39-44 | repo d972125 | high |

Pins (trust-on-first-use; re-hashed by this worker on 2026-10-14: both zip sizes and the Windows zip digest ends equal the T-track record in `qa.md`, the Linux executable digest equals the T-track golden manifest; no upstream per-asset digest was reachable, so an independent second network path is still open; use these until `tools/intel_tools_pin.json` exists):
```
floss-v3.1.1-windows.zip 31580022 6c71089b8c629c69424b042769f1565f71adc6cd24b2f8d3713c96fa7fdac2fb  floss.exe 31866819 3a208ab834b4791e81592d66e91a7f07b3458504484d87c44ed32bc7384df7ef
floss-v3.1.1-linux.zip   40571555 40c05a869f34f7e2417b17ca290cc54bd3671ee1f0a2d9bd5103284c01a54666  floss     40885080 d71b9ea4fe3b2de974dc1ae3c5d0f67569921bc118dcb02ed72e905a662411cb
```
Licenses (SPDX): FLOSS Apache-2.0 (README badge, PyPI text); its bundled vivisect Apache-2.0 (PyPI classifier); Ghidra Apache-2.0 (LICENSE file; decompiler source read for facts); Ghidriff GPL-3.0 per its LICENSE file (facts only); `binary2strings`, `viv-utils` and the other bundled packages [unverified], irrelevant because PatchTrace neither bundles nor imports FLOSS. WB3 adds no Python dependency, wordlist or data file; the built-in scan reproduces FLOSS's documented character class and minimum length and copies no FLOSS code.

## 3. Standalone baseline versus PatchTrace value
| topic | FLOSS alone | in PatchTrace |
|---|---|---|
| unit | one binary, flat list | ordered pair, per-type delta, orientation explicit, series reuse of per-artifact runs |
| function | none in static mode (imagebase 0, no functions; F5) | link tiers L1-L6 (below) plus pair status; "no link" never means "unused" |
| completeness | none | per-type stage state (complete/heuristic/not-run/truncated); added/removed only when valid, else `?` |
| layout noise | a moved string is a new offset | value-hash join: relocation is "in both"; Ghidriff add+delete label noise (F11) suppressed |
| settings | the caller's problem | basis rules (7.1): min length harmonized to the larger value, types intersected, semantics must match; otherwise blocked with a re-scan action |
| safety | default runs all types incl. emulation | static default, emulation behind recorded consent, scratch env, timeouts, memory cap, tree kill |
| context | none | advisory phrases, hypothesis API hints, module and PDB anchors, import/export names, build facts, CWE-family hints |
| triage | none | ordinal review tiers R1-R7 with fixed-vocabulary reasons, never a score |
| hostile text | printed raw | escaped, copy-safe, redacted by default, look-alike pairing |
| reuse | file | search rows (WB1), badges (WB2), rule-seed facts (YRX), lifelines (N-way) |

**Charter check (roadmap s3)**: 1 pair-aware: link tiers, pair status, orientation on every record (S4, S5). 2 delta not inventory: Differences is the default scope; missing is `?` or not-compared, never a negative vote (7.1). 3 anchors in and out: section 4. 4 triage: review tiers R1-R7 with reasons; no score, no averaging with function attention, shared origin counted once (`lineage_group`). 5 one click to code: Open function with line reveal, Open in hex. 6 provenance: `StringBasis.parts` (tool pin, executable sha, options digest, consent hash, raw sha, artifact sha) and staleness through `WindowPort.key()`. 7 offline-first: the built-in scan needs nothing; FLOSS and emulation are optional with blocked states; nothing runs automatically. 8 teachable: `TEACH` hooks (section 7). 9 synergy test: `SYN-WB3-1`.

Workflows: W1 "which new messages does the patch add, and in which modified function?"; W2 "does the advisory wording occur in either build?"; W3 "which API names appear as strings but not as imports (possible dynamic resolution)?"; W4 "what changed in this function's strings?" (select a function, see added/removed/edited); W5 "was this string found by emulation?" (heuristic, absence is not evidence); W6 "give me the facts for a rule seed".

**Link tiers** (strongest first; shown as a label, never combined into a number). **L1 ghidra-xref**: Ghidriff `strings[].calling` names the function; the string joins FLOSS by RVA (Ghidra address minus the PE header ImageBase as `FunctionPairing` does; exact start, else unique containment); the name resolves only by the `evidence._related` rule (F19). **L2 ir-xref**: SPEC-31 IR `str` row (site RVA, function), after UE-S1. **L3 capa-feature**: CAP string-feature instruction RVA, only if CAP emits it. **L4 decompiled-literal**: each literal body in `FunctionRecord.code` is cut at every escape except `\t \\ \" \'` (FLOSS 3.1.1 ends a string at CR, LF and any other non-class byte, so `"bad header (%s)\n"` yields the segment `bad header (%s)`); a FLOSS value links when it equals a segment of the same width class (`L"..."` only with UTF-16LE); a segment ending in the TRUNCATED marker matches by prefix and is marked; text is compared in the escaped domain (F13), never unescaped. **L5 floss-frame**: stack/tight `function` VA equals a project function start. **L6 floss-call-site**: decoded `decoded_at` inside exactly one function range (needs IR ranges); `decoding_routine` is the decoder, never the consumer. No link is ever inferred from name similarity or by a model; an unlinked string stays unlinked.
**Edited pairs**: inside one modified function pair, a removed and an added string with difflib ratio >= 0.6 (mutual best, deterministic ties, at most 64x64 candidates) become one Edited row with a kind: `format-spec` (differences confined to `%` specifiers, for example `%s` -> `%.64s`), `case`, `digits`, `punctuation`, `wording`. A change of format precision is a review cue, not a verdict.

## 4. Cross-feature links
| anchor | WB3 emits | WB3 consumes | other tracks and use |
|---|---|---|---|
| function | `references-string` edge: string id, side, tier, `rva:0x..`, `project_function_id`, `match_id`, pair status, code line (L4) | `FunctionPairing`, `FunctionRecord.code/name/metadata`, IR ranges | KB/PIL graph (`String` node, `references-string`), WB2 badge port, GUI navigation |
| string | `StringRef`: value_sha256, display, enc, types, per-side offsets/RVAs, region, cues, review tier, `lineage_group` (`bytes:<sha>`, `ghidra:<raw_sha>`, `emulation:<run_id>`, `ir:<key>`) | FLOSS evidence or built-in scan | FAB fabric, WB1 search rows, YRX seed facts (count, uniqueness, ascii/wide, region), export |
| import/API | `api-name` cue (equals an import or export name); `dynamic-api` cue (equals an `api` anchor hint, or an import of the other side while absent from this side's imports) | `PeOverview.imports/exports`, `AnchorSet` | CAP cross-check, hypotheses `api_hints`, PE overview; no wordlist, so no cue means unknown |
| capability | none (strings never infer capabilities) | capa `feature_rvas` for the shared-origin note | CAP: a string and a capa rule fed by that string count once |
| rule | `rule_seed_facts` only (never rule text) | - | YRX: direction matters (newer-only text identifies the patched build) |
| build fact | `pdb-path`, `version`, compiler/linker banners, source paths as `build-fact` candidates | CodeView name | DIE: corroborate or contradict toolchain-change; shared origin noted |
| advisory phrase | `StringAnchorHit` (anchor id, match kind exact/casefold/substring, string id, side presence, links, strength fixed `anchor`) | `AnchorSet` kinds `string` (quoted text), `api`, `module`, `pdb`, `feature` | CSAF/PIL/KB: a hit raises review order only; a newly added message stays a tentative anchor |
| CVE / KB | none directly | CVE and KB id carried on anchors for display | KB correlator and patch search show the hit under the CVE; no CVE claim from strings |
| CWE | none | hypothesis family on `api` anchors | label "API often involved in CWE-xxx fixes (rule id)": a hint only |
| series | first/last-seen build index per value hash | per-artifact cached tables | N-way view; one FLOSS run per unique artifact |

## 5. Synergy test `SYN-WB3-1` (synthetic, committed)
Fixtures: `tests/strings_pe.py` builds two PEs with the T-track builder (`from test_intel_tools_pe import ...`, as `test_intel_tools_parsers.py` does; RIP-relative `lea` to `.rdata` strings; one string relocated by 0x40); `tests/fixtures/strings/synergy/` holds the real FLOSS 3.1.1 static and emulation goldens of those bytes (recorded under `unshare -rn`, manifest with sha256 like `intel_tools`), a hand-written Ghidriff-shaped PDiff (SYNTHETIC, not Ghidriff output) and an `AnchorSet` JSON (string "exceeds length", api `RtlULongAdd`, module `exampledrv.sys`).
| string (older -> newer) | each channel alone | combined expected |
|---|---|---|
| `index %u exceeds length %u` newer only, in modified `ParseHeader` | FLOSS: an offset. Ghidriff: a literal inside a code diff. Anchor: a hint | only-newer, static, L1+L4, pair modified, cues message+format+advisory-text, **R1**, reasons listed, strength anchor |
| literal `"bad header (%s)\n"` -> `"bad header (%.64s)\n"` in `ParseHeader` | two unrelated rows | one Edited row, kind `format-spec`, R1 (segmentation links both despite the `\n`) |
| `debug dump of internal state` older only, in `ParseHeader` | a row | only-older, message, L4, R4 |
| `configuration loaded` moved by +0x40; Ghidriff `strings` lists add+delete labels | add+delete noise | both (relocated), no tier; the labels only supply the L1 xref |
| `Software\Vendor\Product\Mode` newer only, `calling` = `InitRegistry` (not in the match set) | a row | only-newer, registry, function name shown, pair status unknown, R3 |
| `RtlULongAdd` newer only, in neither import table | a row | only-newer, api-name absent, dynamic-api, advisory-api hit, R3 |
| decoded `build one` -> `build two` (emulation run) | two decoded lists | found only by emulation, heuristic note "absence is not evidence", R5, no added/removed wording |
| `AKIAIOSFODNN7EXAMPLE` in both | secret in clear | both, redacted in every export and copy |
| `Error` -> the same word with its first letter U+0415 (Cyrillic capital IE) | looks unchanged | Edited, look-alike, codepoint diff shown, R6 |
Variants: older min length 4 vs newer 6 -> basis harmonized to 6, no false removals; newer truncated -> every only-older/only-newer becomes `?`; older FLOSS static vs newer built-in scan -> comparable on static (same semantics id), language not compared, both sources shown; emulation on one side only -> emulation types not compared. The known-answer assertions are tests (`test_synergy_known_answers`); the "beats each channel" claim is this table, not prose.

## 6. Traps and guards
| trap | guard (test) |
|---|---|
| layout shift reported as add+delete | identity = value hash, never offset/RVA/label (`test_relocated_string_is_in_both`; property: shifting all offsets changes nothing) |
| truncated extraction compared | any truncated side -> `?` and a banner (`test_truncated_side_is_indeterminate`); the cap is per type with recorded counts, not input order (F21) |
| emulation misses read as removals | stack/tight/decoded say "found only in newer/older", carry the heuristic note, tier R5 (`test_emulation_types_never_say_removed`) |
| settings differences read as new strings | basis rules 7.1, banner lists each difference (`test_basis_*`) |
| encoding-only change invisible (F21) | encodings are part of the comparison (`test_encoding_only_change_is_representation_changed`) |
| empty FLOSS stdout | 3.1.1 prints nothing when no static string exists (F5): `none-found` covers static only, emulation stages `not-run` (`test_empty_stdout_marks_emulation_not_run`) |
| CR/LF-ended messages never link | L4 segmentation (`test_literal_with_newline_links_segment`) |
| hostile text: ANSI, bidi, NUL, markup | `display_text` for every cell; PlainLabel/PlainText only; tooltips through `tooltips.template` because Qt renders rich text (F16); default copy is the escaped single-line form (`test_hostile_string_never_reaches_rich_text`) |
| `accessibleDescription` leaking a raw tooltip | the model returns explicit AccessibleText/Description roles (F16) (`test_accessible_roles_escaped`) |
| look-alike strings | NFKC+casefold key pairs different hashes as Edited with a codepoint diff (`test_lookalike_pair`) |
| secrets and PII | `secret_kind` redaction in table, copy, export and search index (the index keeps kind and hash only); never in AI context (`test_redaction_everywhere`) |
| string-only evidence over-read | strength fixed `anchor`; no "fixed/vulnerable" wording; banned-word sweep over every visible string (`test_banned_words`) |
| shared origin counted twice | `lineage_group`; built-in scan and FLOSS static share `bytes:`; StringsRefsHasher pairs flagged (F12) (`test_lineage_dedup`) |
| wrong function link | unique-name rule (F19), L4 width class and escaped body, no nearest-function guessing (`test_ambiguous_names_unlinked`) |
| stale link source | raw Ghidriff read only through the hash-verified loader; run id and raw sha in the delta key (`test_stale_raw_rejected`) |
| noise strings flood the view | changed-first scope; "noise-like" hidden only in the inventory view with a visible count; never excluded from delta or export |
| third-party library strings | region and cue only; no library claim until FLOSS tags exist (F2) |
| localized or resource text | region and cue `resource`; text outside F4 coverage is named in the empty state |
| target executed natively | argv[0] is the pinned tool, the artifact is a read-only `artifact.bin` path argument only (`test_target_never_executed` with a fake tool that tries to exec its input) |
| FLOSS runtime risk (F8) | consent v2 names it; scratch env, no network, memory cap, timeouts, tree kill; Windows scratch budget (`test_scratch_budget_floss_onefile`: len(scratch)+16+47 < 260) |
| automatic work | nothing runs on project open; Scan and Run are explicit; WB3 never deletes stored runs (`test_no_autorun_on_open`) |
| cache confusion | key includes basis digest, raw sha, parser version; incomplete runs never serve as hits; raw JSON bytes never used for equality (F3) |
| orientation | every record has `side`; a project key change invalidates (`WindowPort.key()`) (`test_orientation_swap_invalidates`) |

## 7. Contracts (`patchtrace.strings`; Pydantic strict/frozen/extra=forbid for small records; additive only; unknown major refused)
```
StringBasis  strings-basis/1: artifact_sha256 side min_length language{detected,selected} rows_seen rows_kept stages{type:{state: complete|heuristic|not-run|failed|truncated, detail}}
             parts[{source: builtin-scan|floss, semantics_id ('ascii+utf16le-ascii/v1'), source_version, executable_sha256?, run_id?, raw_sha256?, types[], config_digest, consent_sha256?}]
             (one static-class part, optionally one emulation part; the static strings of an emulation run are dropped in favour of the static part and serve as the static part only when no other exists)
StringTable  strings-table/1 (columnar sidecar, header = StringBasis): value_sha256(32B) type u8 enc u8 length u32 offset u32 rva u32 fn_rva u32 site u32 conf u8 flags u16 disp u32 frag u32
             (0xFFFFFFFF = none; artifacts are <= 1 GiB) deduplicated display_values[] (<=256 escaped chars) and fragments[]; hand-validated rows, no per-row pydantic (F15); ~65 B/row
StringLink   tier{L1..L6} join{exact,contains}? function{side,rva?,project_function_id?,match_id?,name?,ambiguous} pair_status line? lineage_group evidence_ref
StringChange id=domain_id('strings.change',1,..) value_sha256 display length status{only-older,only-newer,both,representation-changed,edited,not-compared,indeterminate}
             types/encodings per side, offsets+rvas per side (<=16), region per side, links(<=8), cues(<=8), review_tier 1..7, reasons, notes, edit{of,kind}?, lookalike_of?
StringsDelta strings-delta/1: older/newer basis digests, comparable, harmonized{min_length,types}, basis_notes, counts, changes(<=50000), truncated, pairing{available,notes}, anchors{digest,hits}, value_gate 'unvalidated'
StringAnchorHit strings-anchor-hit/1: anchor_id kind match{exact,casefold,substring,import-equal} string_id presence{older,newer} links strength='anchor' lineage_group
SearchRow    doc_key text(<=256) title field='strings' side status function_ids offsets coverage flags      (WB1 owns the translation into its index)
```
Review tiers (ordinal, uncalibrated, not combined with function attention): **R1** only-newer or edited message/format/advisory-text linked to a `modified` pair; **R2** other non-noise only-newer in a modified or added pair; **R3** only-newer api-name/dynamic-api/path/registry/url/guid/dll-name/advisory-api with any link state; **R4** only-older message/format/path/registry linked to a modified or removed pair; **R5** other differences and every emulation-derived one; **R6** representation, look-alike and moved-reference changes; **R7** noise-like and resource/structure strings. Inside a tier: function RVA (known first), casefold text, id. Cue vocabulary is fixed: message, format, path, registry, url, guid, api-name, dynamic-api, dll-name, pdb-path, version, identifier, advisory-text, advisory-api, lookalike, secret-like, resource, noise-like.
Teach hooks (charter 8): `strings/copy.py` holds `TEACH[id] = (what_it_means, next_step)` for every cue, reason, link tier and state id (`strings.cue.format`, `strings.reason.pair-modified`, `strings.link.L4`, ...): fixed text, no model, one entry per id (`test_every_id_has_teach_text`). Example `strings.cue.format`: what = "A format string shows which values a message prints or copies."; next = "Open the function and look at what the new specifier or width limit sits next to." The E-5 guide links its lessons to these ids and to the navigation actions.
Errors: `PT-STR-INPUT`, `PT-STR-BASIS` (reasons list), `PT-STR-STALE`, `PT-STR-LIMIT`, `PT-STR-SOURCE` (wraps `PT-TOOL-*`), `PT-STR-LINK`, `PT-STR-CONSENT`, `PT-STR-EXPORT`, `PT-STR-CANCEL`.
Storage: no new enrichment kind (F22). FLOSS rows stay `tool-run`/`tool-evidence` (T2) with the raw sidecar; tables and deltas are recomputable and live in derived-cache stages `strings-table` and `strings-delta`; analyst notes use `AnalystAnnotation`. Keys: `table = domain_id('strings-table',1,{basis_digest, part raw_sha256|artifact_sha256, table_version})`; `delta = domain_id('strings-delta',1,{older_table_key, newer_table_key, pairing_digest(run id, raw sha, manual overrides), anchors_digest|null, delta_version})`. Raw level and parsed level are separate, so a parser fix never re-runs FLOSS.
Limits (provisional until the S0 gate): 400k rows per side (T-track 200k until then), display 256 chars, detail window 4 KiB, delta rows 50k in the UI, Ghidriff `strings` entries 100k, literals 4000 per function and 20k lines (views limit), edit pairs 64x64 per function, anchors 200 (existing). Time: static 600 s, emulation 3600 s (T-track defaults, 10..86400 s adjustable); emulation memory cap default 4 GiB [unverified, measure in S9] via `memory_limit_bytes`; scan and delta check cancellation every 4 MiB / 5000 rows.
Budget gates: load both sides at 200k rows each <= 4 s and <= 400 MiB; delta <= 1 s; GUI model for 100k rows: reset <= 300 ms, filter+sort <= 400 ms.
Consent text v2 (`EMULATION_CONSENT`, new sha recorded in options): keeps the existing text and adds "calls to other imports are skipped with a zero result", "the bundled runtime (FLOSS 3.1.1: Python 3.8.10, end of life) parses the file's headers" and "memory and time are capped but not guaranteed".

### 7.1 Basis rules (comparability)
| difference between sides | handling |
|---|---|
| source or FLOSS build differs, same static `semantics_id` | comparable on static; both sources shown; language and emulation types need the same executable sha |
| `min_length` differs | harmonized to the larger value (shorter strings dropped from both, as FLOSS's own reload filter does); banner says so |
| requested types differ | intersect; a type run on one side only is `not-compared`, never "removed" |
| language detection differs | `language` not compared; static unaffected |
| emulation on one side only, or different consent hash | emulation types not compared |
| a side truncated or a stage failed | statuses for that type become `?`/indeterminate |
| semantics id differs (future FLOSS or scanner change) | blocked with reasons and a re-scan action |
| artifact hash, run id, raw sha or orientation changed | `PT-STR-STALE`, nothing navigates |

### 7.2 Run cost, caching, provisioning, failures
- **Provisioning**: users fetch the pinned zip themselves (pins above) and choose the absolute executable path (never PATH; `PATCHTRACE_FLOSS`); PatchTrace never downloads or writes there (Q9). The setup row shows the expected zip and executable SHA-256, then a Probe that hashes the file and runs `--version` and `-H`. Pin status, in text: `pinned build`, `3.1.1 other build` (allowed with a banner), `untested 3.x` (allowed with a warning), `unsupported`, `not set up`. The executable is re-hashed before every run and a mismatch with the probe is `PT-TOOL-STALE`. Windows: Mark-of-the-Web, SmartScreen or AV may delay or block a downloaded onefile exe [unverified; owner machine]; extraction happens inside the run's private scratch `tmp` (not the user's temp), removed with retries (a killed run leaves `_MEI*` there, F10); FLOSS `return -1` appears as exit 255 on Linux and presumably as 0xFFFFFFFF on Windows (`exit_text` prints codes above 255 in hex; confirm on the Windows leg with a fake exe) [unverified]; stdout is ASCII (F3). Linux: same zip layout, member `floss`.
- **Cost**: built-in scan linear in file size (target >= 100 MB/s, measure in S3) [unverified]; FLOSS static about 1 s fixed plus size (F14) [real size unverified]; emulation seconds on tiny files, minutes on real ones [unverified]; two sides run sequentially (T-track default), the panel shows "n of 2", elapsed time and Cancel. Tables and deltas: budgets above. A series reuses the cached run of every shared middle build.
- **Caching**: raw run key = T-track `cache_key` (artifact, tool identity, options, contract); table and delta keys above; a hit is re-validated; an incomplete or failed run is never a hit; normalized content, not raw bytes, is compared (timestamps and timings differ, F3).
- **Failures** (run status / code; the user sees the code plus one sanitized line, never stderr, and "Earlier results were not changed"):
| outcome | status / code |
|---|---|
| spawn error / cancel / timeout / stdout over limit | failed `PT-TOOL-RUN` / cancelled `PT-TOOL-CANCEL` / timeout `PT-TOOL-TIMEOUT` / failed `PT-TOOL-LIMIT` |
| exit 255 with "not PE" text | unsupported `PT-TOOL-UNSUPPORTED` |
| emulation run on a file above 16 MiB (nothing printed, F5) | unsupported `PT-TOOL-LIMIT` with the `-L` consent path; the static baseline is a separate part and stays |
| memory cap hit | failed `PT-TOOL-LIMIT` "memory" (S1b classification) |
| exit 0, empty stdout | `none-found` for static only (F5) |
| invalid JSON, unknown keys, wrong version (a master build) | failed `PT-TOOL-OUTPUT` |
| artifact changed or hash differs | failed `PT-TOOL-ARTIFACT` |

## 8. CLI and GUI
CLI (`strings/cli.py`; adapter `cli_commands/strings.py`, no `cli.py` hook; envelope `enrichment-cli/1`; exits 0 results, 2 invalid input or nothing readable, 3 rejected or partial (basis, stale, truncated, source failed), 4 complete without results, 5 cancelled; offline; FLOSS is run only by `intel-tools run --engines floss`):
```
patchtrace strings list    PROJECT [--side older|newer|both] [--change only-newer|only-older|edited|changed|all] [--type T..] [--function ID] [--cue K..] [--limit N] [--show-secrets] --json
patchtrace strings delta   PROJECT [--source auto|floss|builtin] --json         # strings-delta/1; auto = newest complete part per side
patchtrace strings explain PROJECT --id STRING_ID --json                        # links, reasons, provenance
patchtrace strings scan    PROJECT --builtin [--min-length N] --json            # in-process scan, no FLOSS
patchtrace strings export  PROJECT --out FILE --format json|csv [--scope changed|all] [--show-secrets] [--force]
```
Export is redacted by default and records basis and lineage.

### Export encoding (CSV metadata repair, 2026-11-19)

JSON retains `strings-export/1` unchanged. CSV uses `strings-export-csv/2`:

1. The first CSV record has exactly two fields: the literal `strings-export-csv/2`
   and a JSON object containing every document member except `changes`. This includes
   the document contract, selected scope, redaction policy, extraction basis and
   harmonized settings, basis notes, delta counts, truncation, anchor digest/hit count,
   and the selected rows' lineage groups. JSON uses sorted keys, compact separators,
   and escaped control/non-ASCII characters; it is one CSV field beginning with `{`,
   so a formula-like value inside metadata cannot become a spreadsheet formula.
2. The next CSV record is the existing eleven-column header, unchanged in names and
   order: `id,status,review_tier,display,length,cues,older_offsets,newer_offsets,functions,lineage_groups,reasons`.
3. Remaining records are selected string rows, with the existing cell meanings and
   formula-prefix neutralization. No metadata record is a string finding. An empty
   export contains the metadata record and column header only; its returned row
   count remains zero. Delta `counts` retain their existing meaning and need not
   equal the number of selected/exported rows.

This deliberately replaces the older, unversioned header-first CSV encoding, which
could not preserve document metadata. Consumers must validate and consume the first
CSV record before reading the table. Existing column-oriented processing can then
continue over the unchanged table; a header-first consumer needs this migration.
Do not infer completeness from an older CSV without its missing metadata. For example:

```python
import csv
import io
import json

MAX_EXPORT_BYTES = 8 * 1024 * 1024  # This reader's explicit policy, not an exporter limit.
with open(path, 'rb') as source:
    payload = source.read(MAX_EXPORT_BYTES + 1)
if len(payload) > MAX_EXPORT_BYTES:
    raise ValueError('Strings CSV exceeds this reader\'s 8 MiB budget')
source = io.StringIO(payload.decode('utf-8'), newline='')
previous_field_limit = csv.field_size_limit(MAX_EXPORT_BYTES)
try:
    marker, encoded_metadata = next(csv.reader(source))
    if marker != 'strings-export-csv/2':
        raise ValueError('Unsupported strings CSV encoding')
    metadata = json.loads(encoded_metadata)
    if not isinstance(metadata, dict) or metadata.get('contract') != 'strings-export/1':
        raise ValueError('Unsupported strings export document')
    rows = list(csv.DictReader(source))
finally:
    csv.field_size_limit(previous_field_limit)
```

This standalone reader assumes a locally produced export and accepts at most
8 MiB of UTF-8 file bytes. It reads a bounded snapshot with a one-byte overflow
sentinel; larger files are refused before decoding or CSV parsing. Its field
limit is 8,388,608 characters, an upper bound for any field in that UTF-8 byte budget,
and the previous process-global CSV limit is restored on success or failure.
Run the example in its own process, or serialize changes to that global limit
against other CSV readers when embedding it. Larger valid exports require a
deliberately chosen reader budget; this policy does not cap the exporter or
silently truncate metadata. Spreadsheet display/cell limits may hide a large
metadata field, but do not truncate the bytes emitted in the CSV file.
Importing untrusted files still requires the repository's strict JSON and
resource-budget admission rules.
The metadata does not include `changes` or revealed row values. Revealed values,
when explicitly requested, remain only in their existing row cells. Publication,
scope selection, returned row count and SHA-256 of the complete file are unchanged.

### File publication

Stored-source admission (2026-11-20): the Strings CLI must bind stored FLOSS
results to the current project, artifact hash and side through SPEC-36 T14's
opt-in admission helper. Swapping orientation must not relabel an earlier
artifact's results. Auto falls back to verified built-in scanning when stored
evidence is unavailable; explicit FLOSS selection refuses. Legitimate cached
results retain their admitted originating run's recorded raw provenance even
when the cache-hit run has no raw sidecar. This amendment changes no comparison,
cue, ranking, function-linking, export, or dock behavior.

Publication has explicit platform capabilities (2026-11-20 safety amendment):

- Without `--force`, the selected parent must already exist. Publication holds the source bytes and
  the selected parent identity, creates the destination exclusively, and refuses any existing or
  concurrently arriving destination, including one containing identical bytes. An unavailable
  platform or filesystem capability returns `PT-STR-EXPORT`; there is no pathname-replacement
  fallback. The reusable runtime boundary is `owned_publication.py`, recovered from the existing
  PW-01 publication design. Linux and Windows implementations require their own qualification;
  Linux results do not qualify Windows.
- With `--force`, Windows uses the same rooted, held-source publisher with explicit native
  `ReplaceIfExists=True`. Its default remains no-replace; forced replacement cannot be combined
  with immutable-evidence reuse. Cleanup discards only the held source handle. Native Windows
  filesystem qualification remains separate from portable call assertions.
- On Linux, `--force` can create a new destination but **cannot replace an existing destination**.
  It uses the same held-descriptor exclusive publisher as the default path. Any existing or
  concurrently arriving name, including a regular file with identical bytes, directory, live
  symlink or dangling symlink, is refused with `PT-STR-EXPORT`. The error directs the caller to
  choose a new destination; it must not suggest retrying with `--force`. There is no named source
  stage, final pathname rename, pre-deletion, rollback or destructive fallback. The CLI help
  states that replacement is available on Windows and Linux requires a new destination.
  This is an explicit reduction of the previously supported Linux overwrite capability, not a
  claim that Linux gained a held-inode replacement primitive. Exporting to a new filename
  remains available with either flag value. Byte verification still reads at most the expected
  length plus one byte and checks stable metadata before a successful digest receipt.
- The historical Linux final check-to-rename source substitution finding is mitigated in the
  exported operation by refusing replacement. A compatible, strongly owned Linux replacement
  capability remains **UNIMPLEMENTED**. Do not restore the pathname implementation, or mark
  native/platform acceptance complete, merely because the refusal controls pass.
  The [native primitive assessment](../../engineering/linux-force-primitive-assessment-20261119.md)
  records why descriptor linking, exchange, ordinary locks, a write lease and private-directory
  permissions did not close this interval. Its original failure evidence is retained unchanged.
- On forced failure, close only owned descriptors and preserve the original exception if close
  also fails. The shared Linux publisher preserves this rule for both flag values. A cleanup
  failure without an active operation failure still propagates, including when the caller is
  handling an unrelated exception. Anonymous failures leave no stage name. After exclusive
  publication, never unlink the destination on a later verification failure: it may now name a
  foreign entry. Windows cleanup addresses only the held source handle. Ordinary
  I/O and unsupported-capability failures retain `PT-STR-EXPORT`; cancellation and other
  non-I/O exceptions propagate unchanged.

These publication rules are independent of the encodings above and retain the redaction,
basis, lineage and export-digest semantics. Verification includes concurrent destinations, substituted source/parent names,
unsupported capabilities, descriptor-transfer failures and primary-exception preservation.

GUI (`ui_strings.py`, Qt only; logic in `strings/view_model.py`). **Where**: dock `strings.dock` (objectName), tabified with the Evidence dock on the right (`tabifyDockWidget`), action in the Analysis menu, `Ctrl+Shift+T` (free: used are Ctrl+N O I E S R, Ctrl+Shift+E, planned Ctrl+Shift+F/G); uses the E-2 panel registry when merged, else the `EvidenceController` pattern (own controller, generation counters, unparented registered threads, `WindowPort` for project and `select_match`).
**Widgets**: source bar (source combo Built-in scan/FLOSS, Scan, FLOSS path + Browse + Probe + pin status, "Run with emulation..." opening a consent dialog that defaults to Cancel, Cancel, elapsed indicator); basis banner (PlainLabel with harmonizations or the block reason and "Re-scan older with newer's settings"); filter bar (change, type buttons, side, cue, min length, text filter, function chip set from the navigator, scope Differences (diff view, default) / All strings (inventory), "Hide noise-like strings (N hidden)"); `QTableView` with columns Change, String, Type, Older, Newer, Function, Cues, Source; detail tabs Summary / Links / Provenance in read-only `QPlainTextEdit` (an Edited row shows both values with plain markers `[-old-]` and `{+new+}`, a look-alike row lists the differing code points with their Unicode names); buttons Open function (needs `match_id`), Open in hex (older/newer), Copy safe, Copy exact...; status line with coverage. The navigator gets a context action "Strings in this function" (A5) that sets the function chip (W4).
**Model/view**: `StringsTableModel(QAbstractTableModel)` over immutable view-model rows plus a Python index list for filter and sort (no `QSortFilterProxyModel`, as `EvidenceTableModel`); `data()` returns precomputed strings; one regular grid with header items (an Edited pair is one row, no merged cells; F16); the Change column carries a glyph and a word (`+ Only in newer`, `- Only in older`, `~ Edited`, `= In both`, `? Not compared`), never colour alone; AccessibleTextRole = row sentence ("Only in newer. Static string, 26 characters. Function ParseHeader, modified. Message with format specifier."), AccessibleDescriptionRole = reasons and link tier; ToolTipRole through `tooltips.template` (escaped, <= 300 chars). The default scope shows only changed strings (hundreds); All strings is a virtualized inventory (200k rows) with `resizeContentsPrecision(0)`, fixed header sections and font-metric row height (F16). Selection survives reloads by (value hash, side).
**Keyboard**: Tab order source bar, filters, table, detail, buttons; arrows, PageUp/PageDown, Home/End in the table; Enter opens the function (else the hex view); Space focuses the detail; Ctrl+C copies the escaped single-line form of up to 200 rows / 16 KiB (as `evidence_view`); Ctrl+Shift+C copies exact text, after a confirmation when it holds control characters; Ctrl+F inside the dock focuses the filter (a widget-scoped shortcut, so it never competes with code-pane search), Esc clears it; F6 cycles panes.
**Accessible names**: `Strings panel`, `Strings table`, `Change filter`, `Type filter`, `Side filter`, `Cue filter`, `Minimum length`, `Text filter`, `Scope`, `Comparison basis`, `String detail`, `Source`, `FLOSS path`, `Run with emulation`. **Tooltip ids** (What/Why/Effect/Source/Availability): `strings.dock`, `strings.action`, `strings.table`, `strings.col.{change,string,type,older,newer,function,cues,source}`, `strings.filter.{change,type,side,cue,minlen,text,scope,noise}`, `strings.run.{builtin,floss,emulation}`, `strings.{cancel,probe,browse,basis,detail,rescan}`, `strings.copy.{safe,exact}`, `strings.open.{function,hex}`, `strings.export`; entries live in `strings/tooltip_entries.py` (pure) and are merged by a `tooltips.register_entries()` hook (A7).

**Shipped column-help wiring (2026-11-20, Pacific):** the panel's built-tip declaration
includes all eight existing `strings.col.*` ids, and the corresponding
`ColumnSpec.tip_id` values make their registered help available through the real
table model's horizontal `ToolTipRole`, before and after results are loaded.
Header display/accessibility labels and cell rendering, filtering, sorting,
copying, and export data are unchanged. The Change help covers the recorded
comparison state, including shared and unknown results. Function help describes
an available link or a stated missing/unknown link; neither state proves that no
function uses the string. Offscreen checks cover all eight headers, escaped
registry text, and actual header participation in the global tooltip audit.
Native Windows screen-reader acceptance remains separate.
**States and exact copy** (checked against `BANNED`: no probab/likelihood/vulnerab/exploit/safe/secure/fixed/verified/proven/certain, also inside longer words):
| state | text |
|---|---|
| no project | "Open a project to compare the strings of two builds." |
| no data | "No strings have been extracted for this pair yet. The built-in scan needs no setup and reads both files without running them." [Scan both builds] |
| running | "Reading strings from the {side} build ({n} of 2)... {elapsed}. Cancel stops after the current file; nothing is saved from a cancelled run." |
| ready | "{n} strings differ between the older and newer build. They are listed in review order, which is a reading order and not a finding." |
| ready, none | "No string differences found with these settings. Text this scan cannot extract (non-ASCII wide text, compressed or encrypted data) is not covered." |
| blocked | "These two scans used different settings, so differences would be misleading: {reason}. Re-scan the older build with the newer build's settings." [Re-scan older] |
| incomplete | "The {side} scan stopped at the {limit} string limit. Added and removed marks are shown as '?' because strings may be missing from that side." |
| failed | "String extraction stopped: {code}. {message} Earlier results were not changed." |
| stale | "The project changed after these strings were loaded. Reload to see the current results." [Reload] |
| FLOSS missing | "FLOSS is not set up. You do not need it for plain strings. It is only needed for stack, tight and decoded strings." |
| FLOSS unsupported | "This FLOSS build is not supported: {reason}. PatchTrace is tested with FLOSS 3.1.1." |
| cancelled | "Extraction cancelled. Earlier results are unchanged." |
**Shutdown amendment (2026-11-20)**: closing the Strings controller ends admission of filter-preparation work as well as scans. A filter-control signal already queued before shutdown must not submit a new task afterward, whether the shared task runner is still serving another panel or has also shut down. Loaded rows and persistence remain unchanged. The existing generation/key guards continue to reject earlier results.

**Qt pitfalls**: rich-text tooltips and the `accessibleDescription` fallback (F16); never `setHtml/setMarkdown`; QLabel autodetects rich text (use `PlainLabel`); worker QThreads unparented and registered (a parent deleting a running QThread aborts); results delivered by signal with a generation check; model reset only on the GUI thread; no proxy model at 100k rows; clipboard capped; `visibilityChanged` queued; sizes from `QFontMetrics` for DPI 125/150/200.
**Performance budget**: model reset with 100k rows <= 300 ms; filter+sort <= 400 ms; `data()` O(1) on precomputed text; first paint of 40 rows x 8 columns <= 50 ms; GUI-process memory for two 200k tables <= 250 MiB (the pydantic path measured about 1 GiB, F15); the GUI thread never parses, hashes or reads artifacts.
**Offscreen tests**: `QT_QPA_PLATFORM=offscreen`, the pytest-qt MainWindow fixture of `test_ui_engine_setup.py`; every state above; hostile strings; 100k-row `data()` call counters and a `tracemalloc` peak; thread join on dock close; tooltip audit; contrast test for any fill; 20 repeats in one session without abort.
**Navigation**: Open function = `WindowPort.select_match(match_id)` plus a line reveal for L4; Open in hex needs `MainWindow.show_raw_offset(side, offset)` (A5). The raw view shares one page for both panes, so the caption says "Offset {offset} is in the {side} file; the other pane shows the same offset of its own file, which is a different place."

## 9. Slice plan (each merges alone; exclusive files; no Opus: no demonstrated hard blocker, and the security-sensitive process code already exists)
| slice | scope and exclusive files | needs | tier and why | size | gate | fallback |
|---|---|---|---|---|---|---|
| WB3-S0 contracts+table | `strings/{__init__,limits,contracts,keys,table}.py`, `tools/generate_strings_schemas.py`, `docs/schemas/strings/**`, `tests/test_strings_{contracts,table,schemas}.py` | none (A9 rows first) | Sonnet: contract design plus a measured gate | M | schema regenerate-compare; 200k/side load <= 4 s and <= 400 MiB | keep 200k rows |
| WB3-S1b FLOSS adapter amendments | `intelligence/tools/{floss,common,delta,process}.py` (two optional `EvidenceLink` fields `data_rva`, `site_rva`; `execute(..., memory_limit_bytes)`), `tests/test_intel_tools_floss_wb3.py`, `tests/test_intel_tools_delta_wb3.py`, and the existing assertions that pin the old consent hash or cap: per-type truncation quotas and `truncated_types`, delta without added/removed from a truncated side and with encodings compared, `-n` option plus probe check, `-L` consent path, `PT-TOOL-LIMIT` classification (16 MiB, memory), `memory_limit_bytes`, decoded call site and string RVA, `language_strings_missed` count, consent v2 | A1 text first; must land before TC-R persists rows and before CAP/DIE builders touch `common.py` | Sonnet: careful edits of audited code, red/green on F21 | S | F21 cases red then green; existing goldens unchanged | ship without `-n` |
| WB3-S1 sources | `strings/sources.py` (ports `StringSource`, `FlossEvidenceSource`, `RawFlossSource`), `tests/test_strings_sources.py` (existing goldens) | S0, S1b | Sonnet: adapter plus fixtures | S | goldens -> table equals parser output; sequential load peak <= 600 MiB | convert per side |
| WB3-S2 regions/cues | `strings/{regions,cues,lookalike}.py`, `tests/test_strings_{regions,cues,lookalike}.py` | S0 | Haiku writes the golden tables, Sonnet reviews: mostly data | M | golden tables; no cue outside the vocabulary | fewer cues |
| WB3-S3 built-in scan (recommended) | `strings/scan.py`, `tests/test_strings_scan.py` | S0 | Sonnet: chunk-boundary logic needs property tests | S | byte-identical to the FLOSS 3.1.1 goldens; property vs whole-buffer regex with random chunking; cancel; throughput measured | drop; FLOSS only |
| WB3-S4 links | `strings/{clit,links}.py`, `tests/strings_pe.py`, `tests/fixtures/strings/pdiff/**`, `tests/test_strings_{clit,links}.py` | S0, S1; `FunctionPairing` | Sonnet: exact rules in this plan | L | F13 escape table over every code-point class, segmentation, ambiguity, hostile `strings`/`calling` sizes, stale raw | L1+L4 only |
| WB3-S5 delta/basis/edits/rank | `strings/{basis,delta,edits,rank}.py`, `tests/fixtures/strings/synergy/**`, `tests/test_strings_{basis,delta,edits,rank,synergy}.py` | S0-S4 | Sonnet: pure logic with a known-answer oracle | L | `SYN-WB3-1`; swap symmetry, offset-shift invariance, permutation properties | no edit pairs; FLOSS-shaped JSON hand-written (manifest flag `synthetic: true`, validated by the strict parser) when the pinned binary is unavailable, replaced by real output in S9 |
| WB3-S6 anchors/search/export/CLI | `strings/{anchors,search_rows,export,cli}.py`, `tests/test_strings_{anchors,search_rows,export,cli}.py` | S5; `AnchorSet` contract | Sonnet | M | one-object `--json`, exit codes, redaction, atomic export | no export |
| WB3-S7a view-model | `strings/{view_model,copy,tooltip_entries}.py`, `tests/test_strings_{view_model,copy}.py` | S5 | Haiku for copy and tooltip tables, Sonnet for filters | M | banned-word sweep, filters, sentences, ordering | - |
| WB3-S7b Qt panel | `ui_strings.py`, `tests/test_ui_strings.py` | S7a; E-2 registry or the C6 pattern | Sonnet: follows `ui_evidence.py` | L | all states, hostile text, 100k gates, 20x repeat, tooltip audit | table without detail tabs |
| WB3-S8 run orchestration | `ui_strings_run.py`, `strings/run_service.py`, `tests/test_ui_strings_run.py` | S7b, **TC-R** | Sonnet | M | fake-runner end to end: consent hash recorded, cancel, project switch | built-in scan only |
| WB3-S9 live and QA | `tests/test_live_strings.py`, `tests/fixtures/strings/goldens/**`, qa.md rows | all; TC-P | Haiku for rows and goldens; the live runs belong to CI or the owner | S | Linux pinned run equals goldens; Windows leg recorded advisory | mark BLOCKED |
Prerequisites owned by a tools-core builder, not WB3: TC-R runner+store, TC-C `intel-tools` CLI, TC-P provisioning, pin file and `live-intel-tools.yml` (todo.md T:core). Optional later: WB3-S10 `floss-results/2` when a release exists (probe by HEAD request monthly); WB3-S11 series lifelines.

## 10. Amendments required and test and QA plan
| id | file and section | change |
|---|---|---|
| A1 | `specs/three-tool-evidence-adapters.md` T1 FLOSS row, T3, T5.2, T6.3, T8 | master diverged (F2); `-n`/`-L` argv; 3.1.1 JSON has no hash; string delta superseded by `strings.delta` (TC-C's `intel-tools delta` calls it for floss); truncation rule |
| A2 | `specs/workbench/03-floss-strings.md` s1-s9 | adapter landed; replace `StringObservation/StringRunResult` with the `strings-*` contracts; package `patchtrace.strings`; drop `--string-type` and Import JSON; reconcile budgets (T-track 600/3600 s, 10..86400 s); no hash validation for 3.1.1; add the xref and literal tiers |
| A3 | `intelligence/tools/{floss,process,common}.py` | the S1b items; `execute(..., memory_limit_bytes)` |
| A4 | `intelligence/tools/delta.py` `_strings` | no added/removed from a truncated side; encodings compared (or delegate floss to `strings.delta`) |
| A5 | F5 seam (`show_raw_offset` and the line reveal are in the F5 seam; this track does not edit `ui.py`) | 8-line `StringsController` seam; `MainWindow.show_raw_offset(side, offset)` (refactor of `raw_goto_offset`); a line-reveal method; navigator context action "Strings in this function" |
| A6 | `enrichment/storage.py` | none: reuse `tool-run`, `tool-evidence`; confirm `KINDS` unchanged |
| A7 | `PANEL.tips` (`strings/panel.py`) | the entries are declared in `PANEL` (GUI plan F5); `register_entries` is retired |
| A8 | `cli_commands/strings.py` | adapter file over `strings/cli.py` (<= 25 lines); stays with the track; no `cli.py` edit (GUI plan 8.12) |
| A9 | `docs/modules.md`, `tasks/todo.md`, roadmap ledger | WB3 rows before S0 code (AGENTS.md) |
| A10 | `.gitattributes` | `tests/fixtures/strings/** text eol=lf` |
| A11 | `specs/unified-engine/02-data-model.md` s2, `03-extraction.md` s4 | `str.sha` = SHA-256 of the UTF-8 (surrogatepass) Ghidra string value, same as `StringEvidence.value_hash`; min-length alignment |
| A12 | `docs/qa.md` T:core table | Linux zip digest `...4666`; full digests |
| A13 | `tools/frozen_smoke.py` | check `strings scan --builtin --json` on the sample project (stdlib only: no new hidden imports) |
| A14 | `specs/workbench/01-search-fts5-rapidfuzz.md` | field `strings`; default index = changed + linked strings with a coverage line (all strings exceed its 10k-document MVP target) |
Tests: the named tests of sections 5-6 plus `test_f13_escape_table`, `test_scan_matches_floss_goldens`, `test_dynamic_api_cue_requires_no_anchor_or_other_side_import`, `test_series_reuses_cached_table`. Properties (hypothesis): symmetry under side swap, invariance under relocation and row order, scan equals regex oracle, display has no control or bidi characters, export round trip. Windows list: CRLF via A10, short explicit parametrize ids (32767-character `PYTEST_CURRENT_TEST`), `>=` on monotonic clocks, YAML scalars containing `: ` quoted in any workflow edit, no new dependency (wheels-only unaffected), hermetic tests, fake FLOSS via `tests/fake_exe.py` (`.cmd` on Windows), exit code 0xFFFFFFFF handling, scratch retry on locked files, process-tree kill of the onefile parent and child. Fixtures contain no Microsoft binaries; Tier W stays on the owner's machine.
Blocked external acceptance, reported separately and never counted as done: pinned FLOSS live run on Linux (CI) and Windows (advisory leg; also records onefile start time, AV behaviour, longest extracted path); real-binary cost, RSS and string counts at the 200k/400k cap (owner machine, lawful local pair); NVDA/Narrator reading of row sentences; DPI 125/150/200; keyboard-only walk; frozen-EXE dock smoke.

## 11. Open questions (defaults; none blocks)
| q | default |
|---|---|
| Q1 ship the built-in scan (S3), on by default when FLOSS is not configured | yes; results labelled "Built-in scan", never "FLOSS" |
| Q2 who builds TC-R/TC-C/TC-P, and S1b first | one tools-core builder before S8; S1b before TC-R and before CAP/DIE builders; WB3 uses fakes meanwhile |
| Q3 store FLOSS evidence verbose or compact | compact `strings-table/1` at run time; the verbose pydantic dump only when <= 1 MiB (F15) |
| Q4 raise the row cap to 400k | yes after the S0 gate |
| Q5 which strings WB1 indexes | changed + linked; all strings is opt-in with a coverage line |
| Q6 FLOSS `-n` | extract at 4 (complete); the inventory view hides < 6 by default, with a count |
| Q7 allow `-L` for files above 16 MiB | off; separate consent, longer timeout |
| Q8 accept the end-of-life runtime risk for emulation | yes with consent v2, memory cap and no network; re-evaluate when a newer release exists |
| Q9 in-app FLOSS download | no for v1: show pinned URL and hashes, Browse, pin status |
| Q10 JSON import | defer: 3.1.1 JSON carries no hash, so provenance would be asserted, not checked |
| Q11 rule seeds | WB3 emits facts only; YRX owns rule text |
| Q12 master/3.2 adapter | wait for a tagged release; HEAD-probe monthly |
| Q13 shortcut and who applies A5/A7/A8 | `Ctrl+Shift+T`; A5 is in the F5 seam, A7 is `PANEL.tips`, A8 stays with the track as its adapter file |
| Q14 series lifelines | later slice S11 |
### WB3-S6 CSV leading-ignorable formula guard (generation 34, 2026-11-20)

The eleven string-row CSV columns are untrusted text, including an explicitly
revealed string display. For spreadsheet-oriented export, do not treat a leading
ASCII space, ASCII control whitespace (`\\t\\r\\n\\f\\v`) or UTF-8 BOM
character (`U+FEFF`) as proof that a formula-like token is harmless. If the
first non-ignorable character after these prefixes is `=`, `+`, `-`, or
`@`, emit an initial single-quote escape **before** the entire original cell
text. An initial tab, carriage return or newline is guarded even when no
formula token follows, consistent with the existing direct-control rule.
Preserve every original character after that added quote, rather than stripping,
normalizing or double-encoding it. Keep ordinary whitespace-prefixed prose
unchanged; do not change JSON export, the versioned CSV metadata/header,
row count, redaction, or publication paths.

This is a conservative text-export guard, not proof of universal spreadsheet
import behavior for every application/version or safe rendering of a malicious
spreadsheet file. Tests must round-trip through the real CSV serializer and
include both guarded formula-like prefixes and unchanged controls.


### WB3-S6 source-literal regression control (generation 35, 2026-11-20)

Tests asserting the CSV prefix guard MUST pass actual leading control
characters (LF, CR, tab, vertical tab, form feed) and U+FEFF to the real
serializer, not literal backslash-letter spellings such as the two-character
string consisting of a backslash and "n". Python source fixtures should use
single backslash escapes (`\n`, `\t`, `\ufeff`) and assert the corresponding
decoded CSV values. Keep non-formula prose and JSON behavior unchanged.
A literal backslash before "n" is benign prose, not a newline and not a
basis for inserting an apostrophe. This clarifies the test fixture only;
the production policy in the preceding section remains unchanged.


### WB3-S6 cross-column CSV admission regression (generation 36, 2026-11-20)

The same existing `_cell` formula-prefix contract applies to **every** of
`CSV_COLUMNS`, not solely the visible string-display column. In particular,
`cues`, `functions`, `lineage_groups` and `reasons` can include source-derived
free text after aggregation; the serializer must guard formula-leading text
in those columns without modifying benign prose or the underlying JSON
export's original values. Regression tests must exercise these fields through
`render(document, 'csv')` and a real Python CSV round trip, and must compare
`render(document, 'json')` as an unchanged control. These tests assert the
existing protection boundary; no new prefix policy, data model, analysis,
external transmission or publication semantics are authorized.


### 2026-11-20 sibling test reconciliation: CSV form-feed controls

The existing Strings CSV export prefix policy treats a form-feed before a
formula-like value as an ignorable prefix for formula detection, while preserving
original bytes. A form-feed before ordinary text does not by itself require a
formula marker. Maintain explicit distinct parameterized CSV/JSON presentation
regressions for these two cases. These tests do not change the Linux final-name
publication refusal, strict redaction, provenance or export contract.
