# SPEC-07h: Enrichment hardening backlog (P1 items of the 2026-10-14 audit)

Status: developer-ready, 2026-10-14. Source: `docs/plans/audit-20261014-and-next-phase.md` (open backlog, P1). Every "Current" line below was re-read in the code on `main` after `b7e819a`; line numbers will drift, symbol names will not. Contract versions (`enrichment/1`, `attention/1`) stay unchanged unless an item says "stage version bump" (this invalidates derived caches and stored rows by design: stage IDs digest the version, `pipeline.py:34`).
Process for each item: red test first, then the fix, then focused tests, full `QT_QPA_PLATFORM=offscreen python -m pytest -q`, `ruff check src tests tools`, Linux + Windows CI. Tiers: L = low-cost model, M = mid-tier, H = top-tier only for the named reason.

## H1. Enrichment row retention (storage cap deadlock) , tier M

Current: `EnrichmentStore.publish` upserts by id (`storage.py:122-149`) and nothing in `src/` ever issues `DELETE FROM enrichment_entries` (grep verified). Row ids are `kind:<ranking stage id>` / `wil:<wil stage id>` / `contextual:<ctx stage id>` (`pipeline.py:300-314`), so each project change that alters the input digest, each non-default profile and each snapshot set adds a full new generation. At `used + size > MAX_TOTAL` (128 MiB, `storage.py:134-138`) publish raises recoverable `PT-ENRICH-LIMIT` forever; the only remedy today is deleting the project.
Target:
- **Generation** = the pipeline row `pipeline:<rid>` plus the rows its body references: `signals:<rid>`, `ranking:<rid>`, `wil:<stage_ids.wil>`, `contextual:<stage_ids.contextual>` (when present). `wil`/`contextual` rows may be shared by several generations: reference counted by scanning retained pipeline bodies.
- **Classes**: *current* (guard equals the live guard and row `stale=0`), *stale* (anything else). `secondary-matches` is imported evidence that cannot be recomputed offline: **never evicted by retention**, only counted toward the cap (newest 8 per `run_id` kept; older ones are removed only by an explicit user action, out of scope). Unknown kinds and `read_only` (newer `extension_version`) stores: no deletion, ever.
- **Defaults**: keep at most `KEEP_CURRENT = 8` current generations (newest `created` first; distinct profiles) and `KEEP_STALE = 2` stale generations per `config_digest` (provenance of "what the analyst saw before the rebuild", consistent with SPEC-07 §3 "history is kept"). Everything else is deleted.
- **When**: (a) after `pipeline.publish` writes the `pipeline` row, one call `store.apply_retention(current_guard, protect=ids_just_written)` in a single `BEGIN IMMEDIATE` transaction; (b) **cap fallback** before the first `put` of a publish: `store.make_room(estimated_bytes, protect)`; it deletes in order stale generations (oldest first), then current generations beyond the newest 1 per `config_digest`, never touching `protect` or the live default-profile generation; only if still over the cap does it raise the existing `PT-ENRICH-LIMIT` (message gains "N MiB freed, M MiB still needed"). Orphan rows (no referencing pipeline row) are deleted by (a) only if `created` is older than the current publish call (a concurrent mid-publish set is written pipeline-last and must not be reaped).
- **Migration safety**: no schema change. Add meta key `retention_version='1'` (additive INSERT OR IGNORE into `enrichment_meta`; `extension_version` stays 1; v1 clients ignore the key and tolerate absent rows because every result is recomputable). Before the first retention that would delete rows in a database lacking a `project-pre-retention-*.sqlite3` backup, create one with the existing verified-backup routine (`_backup_before_create`, `storage.py:79`, generalized by a `label` argument). Deletion plus `retention_version` write are one transaction; failure rolls back and publish proceeds without GC (GC is best-effort except in the cap fallback). Space is returned to SQLite's free list, not the file; no automatic `VACUUM` (project may be large and locked); document `patchtrace cache`-style manual compaction as future work.
- **Pseudocode**
```
def apply_retention(self, current: Guard, protect: set[str]):
    if self.read_only: return 0
    pipes = [e for e in self.entries('pipeline')]            # newest first, integrity-checked
    live  = [p for p in pipes if not p.stale and p.guard == current]
    stale = [p for p in pipes if p not in live]
    keep  = live[:KEEP_CURRENT] + per_config(stale, KEEP_STALE)   # per_config groups by body.config_digest
    keep_ids = protect | refs(keep)                            # refs(): the 5 ids per pipeline body
    doomed = [id for id in all_ids_of_derived_kinds if id not in keep_ids and not orphan_too_new(id)]
    with self._db: DELETE ... WHERE id IN doomed ; INSERT OR IGNORE retention_version
```
Tests (new `tests/test_enrichment_retention.py`): 12 sequential edits then publish -> row count bounded and current generation intact (`load_default` still returns it); two profiles share one `wil` row and deleting one generation keeps it; cap fallback: fill to 120 MiB with stale rows, publish a 20 MiB generation succeeds; still-over-cap raises `PT-ENRICH-LIMIT` and leaves existing rows untouched; `secondary-matches` rows survive every path; read-only (future `extension_version`) store deletes nothing; backup created once, verified, not repeated; crash simulation (exception inside the transaction) leaves the table unchanged; v1 open/save/backup test with retention applied; orphan from a concurrent publish is not reaped.
Risk: deleting a generation a GUI still holds in memory (harmless: memory copy) ; mis-ref-counting shared `wil` rows (covered by test). 

### Engine-run retention admission (2026-11-19)

Engine-run eviction is permitted only after all stored `engine-run` and
`secondary-matches` rows used by its reference scan have been admitted through
the existing bounded exact-row reader. Apply the existing 32 MiB row limit before
materializing a body, verify its stored SHA-256, decode strict JSON, and validate
the corresponding current or supported legacy model. The row belongs to the live
project and its stored ID must match the model's run or set identity. A malformed,
unknown-version, oversized, integrity-failing or inconsistently owned row makes
the engine-run eviction scan indeterminate. Return no engine-run candidates for
that scan; do not substitute an anonymous group or infer that an unreadable
reference is absent. Preserve every original engine-run and secondary-match row
and body verbatim while that scan is indeterminate. No automatic repair, rewrite,
deletion or quarantine of corrupt evidence is authorized.

This admission rule applies to both best-effort `prune_runs` and the engine-run
portion of `make_room`. An indeterminate scan skips attempt pruning. The cap
fallback may use independently eligible derived generations under its existing
rules, but cannot count or delete the uncertain engine-run rows; if safe space is
insufficient, return the existing recoverable `PT-ENRICH-LIMIT` before publication.
The caller's explicit `protect` IDs apply to engine-run candidates as well as
derived generations: skip protected attempts before counting freed bytes or
deleting rows, and report insufficient safe space when the protected set prevents
meeting the cap.

Publication's used-byte accounting includes preserved rows whose SQLite ID is
NULL. Exclude only the exact row being replaced by an upsert, using null-safe
comparison in both cap checks. A valid replacement that fits the cap remains
allowed; insufficient safe space leaves the prior row and all protected evidence
unchanged.

Ordinary history, match-set and cache readers keep their existing per-row behavior;
this rule changes only deletion eligibility. Healthy rows retain the existing
per-engine/pair bound, reference protection and verified pre-retention backup.

A successful attempt INSERT and later retention remain separate operations.
Skipping an indeterminate retention scan does not undo or misreport the completed
write. Genuine publication failures and unexpected post-write exceptions retain
their existing propagation and UI uncertainty semantics; no atomic-save guarantee
is introduced. Tests preserve raw malformed bodies, healthy evidence and original
artifacts, exercise both eviction paths, and retain a deliberate post-write fault
control after malformed input no longer raises accidentally.

## H2. History table bound , tier M (**needs owner decision**, see end)

Current: every `ProjectStore.save` inserts a full snapshot payload (`persistence.py:328`, `history` table `:253`), each up to 256 MiB, and nothing prunes it; the module docstring promises "append-only history" (`:1`). `history()` is read by tests and revision displays (`:359`).
Target default: keep the newest `HISTORY_KEEP = 100` rows **and** at most `HISTORY_MAX_BYTES = 512 MiB` of payload, never deleting the row whose `sha256` equals `current_snapshot.sha256`. Skip the INSERT when the new payload hash equals the newest history hash (idempotent re-save, e.g. the load-time "interrupted run" save). Prune runs in the same transaction after the INSERT (`DELETE FROM history WHERE sequence NOT IN (newest N) ...`), oldest first. First prune on an existing project creates the standard verified backup (`backups/project-pre-history-prune-*`). Revision numbers in snapshots are unchanged (they live in the payload, not the row).
Tests: 150 saves -> 100 rows, current row present, `history()` ascending by sequence; byte budget with large synthetic payloads; duplicate-hash save adds no row; pruning failure rolls back the save as a whole ("prior snapshot retained", `:333`); backup restore still reproduces `history()` for the retained rows (existing `test_core.py:78-84` pattern). Risk: loss of old audit trail (hence the decision flag); alternative with no loss is zlib-compressing rows older than 20 (schema change, rejected for this slice).

### H2 service snapshot after an interrupted save (2026-11-21; normative)

The first deferred history backup runs after the snapshot transaction commits, as
specified in the phase D amendment below. A raised save exception therefore does
not prove rollback. Before `ProjectService._commit` propagates any save failure or
interruption, it reloads the committed snapshot with `recover_interrupted=False`.
This read must neither recover running jobs nor perform another save. A failed
transaction retains the prior snapshot; an already committed edit becomes the
service snapshot so the next edit cannot omit it. The original exception remains
the reported outcome; no successful-save or rollback claim is inferred.

If that reload also fails or is interrupted, keep the original exception and add
a fixed diagnostic requiring the project to be reopened. The same service must
refuse further snapshot commits, even if storage becomes readable later. Preserve
all project/history/raw evidence and the existing lock until normal close; a new
service opened from the persisted snapshot restores the normal editing path.
This refusal applies before `ProjectService.backup` reads or stages anything:
its normal `load()` may recover an interrupted run and write a snapshot/history
row. A healthy or reopened service retains that existing backup recovery behavior.
If a healthy backup's recovery load raises, it uses the same read-only outcome
reconciliation before propagating the original failure. A recovered run already
committed as failed must not revert to running through a subsequent service edit.
Tests use authored project files, the real deferred-prune boundary, a transaction
rollback control, and a second edit after each outcome. No schema or history
retention policy changes.

## H3. WIL status `partial` only for real partials , tier L/M

Current: `signals.detect` marks a one-sided pairing (added/removed function) with every detector `unavailable` and `SignalSet.status='unavailable'` (`signals.py:450-459, 907-919`). `pipeline.run` records the signals stage `complete` only if **all** sets are `complete` (`pipeline.py:210`), so any run containing one added or removed function reports stage `partial` and overall `partial` (`_overall`, `:154-165`). `_merge` then appends a `WIL` outcome carrying the **global** `wil_status` to every pairing (`:168-171, 240-244`), so a one-sided pairing has outcomes `{unavailable x7, complete}` and `ranking._evidence_status` returns `partial` instead of `unavailable` (`ranking.py:57-61`).
Target: status describes evidence quality of what was *requested and applicable*, not the presence of inapplicable pairings.
- Per pairing, the WIL outcome is derived per pairing: `unavailable` (reason from `wil.analyze` notes `one-sided-pairing` / `code-unavailable` / `pairing-ambiguous`) when WIL cannot apply, `partial` when notes contain `function-too-large` or `site-limit`, else `complete`; pipeline-level `wil_status` only overrides when the stage itself failed/cancelled.
- `SignalSet.status` ignores `unavailable` outcomes whose reason is a *category/one-sidedness* exclusion (an expected, structural not-applicable) when at least one other outcome is `complete`; it is `unavailable` only if all outcomes are not-applicable; `partial` only for truncation (`function-too-large`), `site-limit`, missing code on a required side of a 1:1 modified pair, or cancelled. Implement via a small `DetectorOutcome.reason` code enum is **not** added (contract frozen): use the existing `reason` text prefix constants `NOT-APPLICABLE:` vs `LIMIT:` defined in one module-level tuple and tested.
- Pipeline stage `signals` is `partial` only if some set has status `partial`; one-sided-only exclusions leave it `complete`. `ranking` per-entry `evidence` follows the same rule; a one-sided entry is `unavailable` (never silently "no defect").
Tests: run with one modified + one added + one removed pairing -> stage `complete`, overall `complete`, added/removed entries `evidence='unavailable'`, modified entry `complete`; truncated function -> `partial`; modified pair with null decompiled code on one side -> `partial`; WIL failed globally -> all `WIL` outcomes `failed`, overall `partial`; golden ranking arithmetic unchanged. Stage version bump for `ranking` (entry evidence changes). Risk: GUI/exports that print "partial" for one-sided rows change text (update `test_ui_enrichment.py`).

## H4. Contextual rerank requires binary evidence , tier M

Current: `contextual_rank` awards `identifier` points (+12, cap 24) from function-name tokens alone (`cve.py:416-429`); a pairing with **zero** signals and base score 0 can rise by 24 and, because `product` is only gated on "any contribution" (`:457`), by 28. SPEC-07 §8 says every contribution cites binary evidence and "no binary support -> 0". `binary_ref` today is `name:<fn>`, which is metadata, not change evidence.
Rule (normative): a pairing has **binary evidence** iff its `SignalSet` contains at least one `ChangeSignal` (any detector, including WIL, any confidence other than none) *or* a `qualifies=True` transition. Without it: `adjustment = 0`, `contributions = ()`, and `blocked` records `no-binary-evidence`. With it: `identifier` points stay +12/cap 24 but `binary_ref` becomes `signal:<lowest signal_id>` (and `detail` keeps the matched name); `cwe` unchanged (already requires moderate/strong aligned signal); `feature` unchanged (requires qualifying transition); `product` requires at least one *other* contribution (unchanged). One-sided or `unavailable` evidence never qualifies. Stage version bump `contextual` 1->2.
Test cases: (1) name token matches CVE, pairing has no signals -> adjustment 0 and order identical to base order; (2) same name, one weak ERR signal -> +12 with `binary_ref` starting `signal:`; (3) two matching tokens + two signals -> capped 24; (4) unavailable one-sided pairing with matching name -> 0; (5) matching name + product-module match, no signal -> 0 (product cannot lift alone); (6) CWE-787 + moderate BND -> +10 unchanged; (7) property: `context_score >= base_score` and `context_score == base_score` whenever no signals; (8) golden: existing contextual fixtures re-baselined, diff reviewed to show only no-signal pairings changed.

## H5. SIZE cast-only and BND added-loop false positives , tier M

SIZE current (`signals.py:755-784`): size args are compared as `_join(map(_norm_token, arg))` with **casts left in place**, so `memcpy(d,s,n)` -> `memcpy(d,s,(ulonglong)n)` (the decompiler re-emitting an implicit conversion) reports a size change. `_spilled_same` (`:787`) only forgives a single-temp spill.
Rule: define `size_canon(tokens)`: (1) `_strip_casts` repeatedly until fixpoint (type-only parentheses, incl. `*`); (2) remove redundant outermost `( ... )` pairs wrapping the whole argument; (3) numeric literals: strip integer suffix `[uUlL]{1,3}` and compare by integer value (`0x10`, `16`, `0x10U` equal); (4) apply `_norm_token`. SIZE fires iff canonical args differ **and** `_spilled_same` (using the same canonicalization on both sides) is false. A change of cast **type** alone (`(uint)n` -> `(ushort)n`) is not SIZE (it is INT's job; INT already handles width/sign casts on shared operands).
Counterexample fixtures (must **not** fire SIZE): `n`->`(ulonglong)n`; `(uint)n`->`(ulong)n`; `n`->`(n)`; `0x10`->`0x10U`; `16`->`0x10`; `(longlong)(int)n`->`n`; `malloc(n)`->`uVar1 = n; malloc(uVar1)` (existing). Must fire: `n`->`n - 1`; `n`->`(ulonglong)n - 1`; `n`->`m`; `sizeof(struct A)`->`sizeof(struct B)`; `0x10`->`0x20`.
BND current (`:526-533, 548-575`): `_added_cmps` yields any new comparison on a "control" line, and `control()` accepts `for`/`while` headers (`_CONTROL`, `:72, 301-309`). An entirely new loop `for (i = 0; i < n; i++) out[i] = in[i];` therefore reports "added bound comparison" although it is new structure, not a guard on pre-existing behaviour.
Rule: a comparison on a line whose first non-`}` token is `for` or `while` (loop header; `do { } while (c)` closer included) qualifies only if the edit's **old range** (`edit.old`) also contains a loop header of the same keyword, i.e. an existing loop's bound changed. A new loop header with no loop header in `edit.old` is skipped. `if`/`else if`/`&&`/`||` lines are unchanged. (Guards inside an added loop body still count.) Detector version bump BND 1->2.
Fixtures: must not fire: older has no loop, newer adds `for (i = 0; i < count; i++) { buf[i] = x; }`; newer adds `while (i < n) { p[i++] = 0; }`. Must fire: `for (i=0;i<n;i++) buf[i]=x;` -> `for (i=0;i<n && i<cap;i++) buf[i]=x;`; `while (i < n)` -> `while (i < min(n, cap))`; added `if (i >= cap) return -1;` before `buf[i]`. Risk: a real fix that rewrites a loop header together with its body might lose BND; accepted, other detectors (INT/OVF/VAL) and manual review remain.

## H6. `_TEMP` over-collapsing , tier M

Current (`signals.py:60-61`): `[a-z]{1,5}Var\d+`, `[a-z]{1,5}Stack_[0-9a-fA-F_]+`, and `(?:local|param|in|extraout|unaff|DAT|LAB|FUN|PTR|switchD|caseD|joined|stack)_\w+`. `_norm_token` maps every full match to `$v` (`:137`), which feeds `norm` lines, comparisons, `edit_group_key` identities and SIZE. So real names `myVar1`, `tmpVar2`, `in_len`, `in_buf`, `local_buffer`, `param_count`, `stack_size`, `DAT_table` collapse and renames of real variables become invisible.
Target regex (all anchored via `fullmatch`; address digits are hex, registers upper-case):
```
_PFX   = r'p{0,3}a?[bcdfilpsuvx]'                  # Ghidra datatype letters: pointer depth, array, base type
_TEMP  = (rf'{_PFX}Var\d+'                          # uVar1, iVar2, pcVar3, ppvVar4, auVar5
          rf'|{_PFX}Stack_[0-9a-fA-F]+'            # uStack_c, auStack_28
          rf'|{_PFX}Ram[0-9a-fA-F]{{8,16}}'         # uRam0000000140001000
          r'|local_(?:res)?[0-9a-fA-F]+'            # local_10, local_res8
          r'|param_\d+'
          r'|in_(?:[A-Z][A-Z0-9_]*|stack_[0-9a-fA-F]+)'          # in_RAX, in_XMM0_Da, in_stack_ffffffe8
          r'|extraout_(?:[A-Z][A-Z0-9_]*|var(?:_[0-9a-fA-F]+)?)' # extraout_RAX, extraout_var_00
          r'|unaff_(?:[A-Z][A-Z0-9_]*|retaddr)'                  # unaff_RBX, unaff_retaddr
          r'|(?:DAT|LAB|FUN)_[0-9a-fA-F]{4,16}'
          r'|PTR_(?:DAT|LAB|FUN)_[0-9a-fA-F]{4,16}|PTR_\w+_[0-9a-fA-F]{4,16}'
          r'|switchD_[0-9a-fA-F]+|caseD_[0-9a-fA-F]+|joined_r0x[0-9a-fA-F]+|stack0x[0-9a-fA-F]{4,16}')
```
Keep named, **not** temporaries: `myVar1`, `tmpVar2`, `idxVar1`, `in_len`, `in_buf`, `local_buffer`, `local_x`, `param_count`, `param_`, `stack_size`, `DAT_table`, `FUN_main`, `extraout_value`. Must be temporaries: `uVar1`, `iVar12`, `pcVar3`, `ppvVar4`, `auVar5`, `uStack_c`, `local_18`, `local_res10`, `param_3`, `in_RAX`, `in_stack_00000010`, `extraout_RAX`, `extraout_var_00`, `unaff_RBX`, `DAT_180012345`, `LAB_18001a2b0`, `FUN_1800010a0`, `PTR_DAT_180034560`, `switchD_180001234`, `caseD_3`, `joined_r0x180001abc`, `stack0x00000008`. Note `_TOKEN` already splits `switchD_x::caseD_n` at `::`. Stage version bump `signals` and `wil` 1->2 (group keys change because `normalized_text` uses `_norm_token`; this is expected and must be listed in `docs/qa.md`).
Tests: table-driven `fullmatch` parametrization of both lists; end-to-end: rename of `myVar1`->`count` is now a change (comparison signal), rename `iVar1`->`iVar2` is not; ordering/golden tests re-baselined with reviewed diff; hypothesis test that `_norm_token` is idempotent and never returns a name containing `$` input. Risk: Ghidra versions emitting new shapes (e.g. `lVar`+suffix); mitigated by the closed table plus a live-sample corpus check on the Windows CI decompiler output (log unmatched `[a-z]+Var\d+`/`local_` shapes as a CI artifact, no failure).

## H7. Child-process environment allowlist , tier M (validation needs a native run; H only if the Windows run reveals a loader/security surprise)

Current: `_environment` copies **all** of `os.environ`, drops only `PYTHONPATH`/`PYTHONHOME`, sets `GHIDRA_INSTALL_DIR`, optional `JAVA_HOME`/`PATH`, `PYTHONIOENCODING`, `XDG_CONFIG_HOME` (`backend.py:99-114`); used at `:139, :160, :463`. `cli.py:748` passes `dict(os.environ)` to rz-diff. Hazards: `JAVA_TOOL_OPTIONS`/`_JAVA_OPTIONS`/`JDK_JAVA_OPTIONS` (`-javaagent`), `LD_PRELOAD`, `PYTHON*` (`PYTHONSTARTUP`, `PYTHONUSERBASE`, `PYTHONNOUSERSITE` flips), `GHIDRA_*`, credentials (`*_TOKEN`, API keys, cloud creds) reaching a process that loads binaries.
Target: pure `build_child_env(base: Mapping, config, settings_dir, *, symbol_downloads: bool, for_tool: 'ghidra'|'rizin') -> dict[str,str]` in `backend.py` (or `child_env.py`), no I/O.
- **Windows required (case-insensitive names, original case preserved)**: `SystemRoot`, `SystemDrive`, `windir`, `ComSpec`, `PATH`, `PATHEXT`, `TEMP`, `TMP`, `USERPROFILE`, `HOMEDRIVE`, `HOMEPATH`, `APPDATA`, `LOCALAPPDATA`, `ProgramData`, `ProgramFiles`, `ProgramFiles(x86)`, `ProgramW6432`, `CommonProgramFiles`, `NUMBER_OF_PROCESSORS`, `PROCESSOR_ARCHITECTURE`, `OS`, `USERNAME`, `USERDOMAIN`. (`SystemRoot` is mandatory: Python/Winsock/crypto and the JVM fail without it.)
- **Linux/macOS required**: `PATH`, `HOME`, `USER`, `LOGNAME`, `LANG`, `LC_*`, `TMPDIR`, `TZ`, `SHELL`, `LD_LIBRARY_PATH` only when `config.java_home` is unset *and* it is non-empty (system JDK installs), `XDG_RUNTIME_DIR`, `XDG_DATA_HOME`, `XDG_CACHE_HOME`.
- **Set by PatchTrace** (unchanged): `GHIDRA_INSTALL_DIR`, `JAVA_HOME`+`PATH` prefix, `PYTHONIOENCODING=utf-8`, `XDG_CONFIG_HOME=<scratch>`; add `PYTHONNOUSERSITE=1`, `JAVA_TOOL_OPTIONS`/`_JAVA_OPTIONS`/`JDK_JAVA_OPTIONS` explicitly **absent**.
- **Only if `symbol_downloads`**: `HTTP_PROXY`, `HTTPS_PROXY`, `NO_PROXY` (either case), `SSL_CERT_FILE`, `SSL_CERT_DIR`, `REQUESTS_CA_BUNDLE`.
- **Escape hatch** (documented, visible in Setup): `BackendConfig.env_passthrough: tuple[str,...]` of extra names (validated `^[A-Za-z_][A-Za-z0-9_()]*$`, a denylist rejects `PYTHONPATH`, `PYTHONHOME`, `LD_PRELOAD`, `*_OPTIONS`); temporary emergency switch env `PATCHTRACE_CHILD_ENV=inherit` for one release, logged as a warning in `analysis.log`.
- rz-diff uses the same function with `for_tool='rizin'` (no JAVA/GHIDRA/PYTHON vars, adds `RZ_*` only if present in base and in a fixed list `RZ_PREFIX`, `RZ_LIBR_PLUGINS`).
- **How to validate** (do not mark done on unit tests alone): (1) unit: golden env for synthetic Windows/Linux bases, case-insensitive match on Windows, denylist, secret names absent, ordering stable (`jobs._windows_process` sorts, `jobs.py:109`); (2) Linux CI: native Ghidriff matrix with allowlist default; (3) Windows CI: existing `raw-cache-hit` job (real Ghidra 12.0.4 / Temurin 25, runs twice) executed with the allowlist plus a probe step that runs the same builder with a base environment seeded with `JAVA_TOOL_OPTIONS=-Dx=1` and a fake `GITHUB_TOKEN` and asserts both are absent from the child (child dump via `python -c` as the `python_executable`); (4) on Windows failure, bisect by adding the missing name to the table and recording the evidence in `docs/qa.md`. Rollout: PR A adds the builder and tests with default `inherit`; PR B flips the default only after (2) and (3) are green on the PR.
Risk: a missing Windows variable breaks the real run in a way the fake backend cannot show (hence the native gate); enterprise proxies and custom JDK locations need `env_passthrough`.

SPEC-31 S1 (A-21): the unified extractor child (`unified/extract/runner.py`) builds its environment with `backend._environment(config, settings_dir)`, so `restrict_env`, `env_passthrough` and the `PYTHONPATH`/`PYTHONHOME` removal apply to it unchanged; it adds nothing to the allow-list.

## H8. Raw output stored twice , tier M

Current: the backend publishes the run directory with the Ghidriff JSON at `runs/<id>/raw/json/result.ghidriff.json` and sets `raw_path` to it (`backend.py:379-395`); `ProjectService._prepare_analysis` then writes the same bytes again at `runs/<id>/raw/result.ghidriff.json` and rewrites `raw_path`/`raw_sha256` (`service.py:~140-165`). Up to 2 x 100 MiB per run in the project, plus the optional global raw cache copy (intentional).
Target: one project-owned copy. `_prepare_analysis` first checks whether `source` already resolves inside `self.root/runs/<run.id>/` and is the backend output; if so it reuses it in place (verifies size/mtime/inode stability exactly as today, sets `raw_path` to that relative path, `chmod 0o444`), no second write. Import of a user-supplied JSON (outside the run directory) keeps the current copy to `raw/result.ghidriff.json`. Existing projects: `raw_path` is authoritative and never rewritten; a startup/`open` cleanup (best-effort, after a successful load, never during `_verify_files`) removes `runs/<id>/raw/json/result.ghidriff.json` **only if** the snapshot's run has `raw_path == runs/<id>/raw/result.ghidriff.json` and the leftover file's SHA-256 equals `raw_sha256`; otherwise leave it and log. Never delete when hashes differ (could be diagnostic evidence). Normalization and `nway.read_raw_matches` use `run.raw_path` only (verify; no code may assume the `raw/result...` name).
Tests: backend-produced run stores exactly one `*.ghidriff.json` under the run directory; import from a temp path still copies once; idempotent re-prepare; legacy project with two copies: cleanup removes the duplicate only when hashes match, keeps it on mismatch, project backup/restore round trip still verifies raw hash; swapped-orientation cache hit path (`backend.py:432`) covered. Risk: `test_*` and docs that reference the old second path (grep `raw/result.ghidriff.json`).

## H9. Provider call cancellation latency (NVD/MSRC and LLM providers) , tier M

Current: `intelligence._attempt` opens the connection with a socket timeout of `min(10 s, remaining)` (`:298`) and reads with the same per-operation timeout; `cancel` is only polled between chunks (`:325`) and before each attempt (`:271`). A cancelled fetch can therefore block up to 10 s in `connect`/first byte and up to 10 s per stalled read. `providers.py:92` uses `TIMEOUT_SECONDS = 120` per socket operation with `cancel` polled between reads (`:95`), so cancelling an interpretation can wait up to 120 s.
Target: cancellation observed within 250 ms of `cancel.set()` for every blocking network call. Shared helper `interruptible(call, cancel, poll=0.1)` (new tiny module `netutil.py`, stdlib only): run `call` on a daemon thread, wait on a `threading.Event` in `poll` slices, on cancel return/raise `Cancelled` immediately, and have the abandoned thread close its response/socket when it eventually returns (flag set under a lock; no shared mutable result after abandonment). Apply to `opener(...)` and each `response.read(...)` in `intelligence._attempt` and the equivalent in `providers.py`. Per-operation socket timeouts stay as the upper bound for abandoned threads (bounded leak: at most one live thread per in-flight request; cap 4 abandoned threads, then new calls fail `PT-ENRICH-NETWORK` "previous requests still closing"). Tests use injected fakes with `threading.Event` blockers: fake opener blocks until released; assert `fetch` raises `PT-ENRICH-CANCEL` < 0.5 s after `cancel.set()`; blocked read same; no thread leak after release; deterministic clock tests remain (the helper takes `poll`/wait injection). Risk: abandoned thread holding the NVD key header (it already exists in memory; no new exposure) and Windows socket close races (native Windows CI covers `providers` loopback tests).

## H10. NVD pacing and HTTP 403 handling , tier M

Current: `fetch_all` issues requests back-to-back (`intelligence.py:230-245`) although the module docstring records NVD's public limit of 5 requests per rolling 30 s without a key, 50 with (`:12-13`); up to 64 CVEs x 2 providers are allowed (`MAX_CVES`). Retryable statuses are only 429/502/503/504 (`:46`); any other status, including NVD's rate-limit/forbidden **403**, becomes `PT-ENRICH-PROVIDER 'provider returned HTTP 403'` (`:317-318`) with no distinction between a rejected key and throttling and no back-off for following requests (test `test_enrichment_intelligence.py:142` expects the keyed 403 failure).
Target:
- Per-provider `Pacer(limit, window=30.0, clock, sleep, cancel)` (sliding window of request timestamps). Defaults: NVD keyless 4 per 30 s (one below the documented 5, safety margin), NVD with key 45 per 30 s, MSRC 1 per second. `acquire()` sleeps with the cancellable sleep until a slot is free; the sleep counts against a separate **plan deadline** (not the per-request 30 s `TOTAL_TIMEOUT`, which still starts at the actual send) = `ceil(n_requests / limit) * 30 s + 60 s`; exceeding it fails the remaining requests with a recoverable `PT-ENRICH-NETWORK 'pacing budget exhausted'` while keeping results already fetched. The consent preview (UI/CLI) states the minimum duration ("about 6 minutes for 40 NVD requests without a key").
- 403 policy: NVD **with** an API key -> `PT-ENRICH-PROVIDER` "NVD rejected the API key or access (HTTP 403)" , not retried, no further NVD requests in this plan (one error per remaining request, `skipped: key rejected`). NVD **without** a key -> treated as throttling: provider enters a cooldown of `max(Retry-After if valid, 30 s)`; the current request is not retried inside its 30 s window; it and any later NVD requests inside the cooldown are not sent and are reported as recoverable `PT-ENRICH-NETWORK 'NVD is rate limiting; retry after ~30 s or use an API key'`. MSRC 403 stays `PT-ENRICH-PROVIDER` (no cooldown). 429/503 `Retry-After` handling is unchanged; they also set the same cooldown so the pacer does not immediately resend.
Pseudocode: `acquire(): while len(window) >= limit or now < cooldown_until: sleep(min(needed, 1.0), cancel); check cancel; window.append(clock())`.
Tests (injected clock/sleep like the existing `Clock` fixture): 6 keyless NVD requests -> 5th waits until the first leaves the window and total sleep >= 30 s - epsilon, 0 sleeps with key for 10 requests; MSRC unaffected by NVD cooldown; 403 keyless -> remaining NVD skipped without opener calls, MSRC succeeds, result partial with named provider; 403 keyed -> key-rejected message, no key text in message; cancel during pacing sleep returns in < 0.5 s; plan deadline test; existing 403/429 tests updated deliberately (diff reviewed). Risk: NVD's actual enforcement is unverified live (recorded 2026-10-12 only from documentation); capture a live probe in `tests/fixtures/cve/README.md` as a separate non-gating step.

## H11. Stale snapshot -> `partial` , tier L

Current: `contextual_rank` computes `stale` (`cve.py:468-470`) and stores it in `stale_snapshots` but derives status only from "no snapshots" / term truncation (`:471`), so a stale snapshot still yields `complete`, contradicting SPEC-07 §8 ("result status is `partial` with a per-CVE warning"). Existing test `test_stale_snapshots_reported` (`test_enrichment_cve.py:322`) asserts only the list.
Target: `status = 'partial'` if `stale` or `len(all_terms) > MAX_TERMS`; CLI/GUI render one warning per CVE in `stale_snapshots`. `now=None` or `max_age_days=None` means freshness was not evaluated: status unchanged and a `freshness-unchecked` limitation is not invented (no new field). Stage version bump `contextual` (shared with H4). Tests: stale -> `partial` and `stale_snapshots == (cve,)`; fresh -> `complete`; future-dated retrieval -> stale; not evaluated -> `complete`; pipeline `_overall` with `requested_context=True` -> overall `partial`.

## H12. CVSS conflict only across providers , tier L

Current: `_conflicts` groups **all** CVSS records by version and flags a conflict when their `(base vector, score)` pairs differ (`cve.py:246-252`). `_parse_nvd` emits one record per NVD metric entry with `source='nvd:<metric source>'` (`:177-182`), so NVD's own Primary (NIST) and Secondary (CNA) entries for the same version, which routinely differ, produce a false "conflict" even when only NVD was queried. Severity conflicts have the same flaw (`:253-256`).
Target: provider = `source.split(':', 1)[0]`. For each CVSS version, build per-provider sets of `(base_vector, score)` ; a conflict exists only if at least two providers have records for that version **and** their sets are disjoint (no shared pair). Same rule for severity (providers with an empty severity are ignored, which today leaves NVD alone, so effectively no severity conflict from MSRC, documented). Multiple differing records inside one provider are kept in `cvss` unmodified (information preserved) and add no conflict. Conflict text stays `cvss <version>: nvd=..; msrc=..` using provider names. `snapshot_id` unaffected (digests of responses); `conflicts` is derived, so existing stored snapshots keep their old strings until re-normalized: loaded snapshots are not re-derived (document).
Tests: NVD-only with Primary 9.8 / Secondary 8.1 same version -> no conflict; NVD 9.8 vs MSRC 7.5 same version -> conflict; NVD primary and secondary where MSRC equals the secondary -> no conflict (shared pair); versions 3.1 vs 4.0 never compared; MSRC temporal metrics ignored by `_base_vector` (unchanged).

## H13. `select_latest` provider loss , tier M

Current: `select_latest` keeps one snapshot per CVE by newest `retrieved_at` and **discards the rest** (`cve.py:310-325`). If the newest snapshot came from a fetch where one provider failed (partial fetch, a supported outcome) the provider's data from an older snapshot is silently dropped from ranking.
Target: per CVE, per provider (`response_digests` keys), take the data from the newest snapshot that contains that provider. If that equals a single snapshot, return it unchanged (no behaviour change). Otherwise synthesize a **merged snapshot**: fields attributed by `source` prefix (`descriptions`, `cwes`, `cvss`, `products`, `advisories`, `published`) are filtered to the chosen provider for each snapshot and concatenated in the existing sorted order; `response_digests` = chosen digests per provider; `snapshot_id = domain_id('cve-snapshot', 1, {cve_id, normalization_version, response_digests})` (same recipe as `normalize`, so merged and fresh snapshots with identical responses share an ID); `retrieved_at` = the **oldest** of the contributing snapshots (conservative for staleness and recorded as such); `conflicts` re-derived with the H12 rule from the merged fields; `feature_ids=()` stays. Return value gains the contributing snapshots in `ignored`-style reporting: `ignored` holds only snapshots that contributed nothing. A merged snapshot is labelled unverified if any contributor was loaded from a file. Stage `contextual` input digest uses merged `snapshot_id`s, so reruns are deterministic.
Tests: old {msrc,nvd} + newer {nvd} -> merged {msrc(old), nvd(new)}, `retrieved_at` = older time, conflicts recomputed; identical timestamps tie-break by `snapshot_id`; single provider each -> unchanged output; merged id equals id of a fresh `normalize` with those digests; ignored list correct; order independence (permute input); no mutation of inputs (frozen). Risk: contract unchanged but merged snapshot has no single fetch time; documented above. Decide with the owner whether the merged time rule is acceptable (below).

## Delivery order and gates

1. H11, H12 (low-cost, small, share the `contextual` version bump with H4) ; 2. H3 ; 3. H4 + H13 ; 4. H5 + H6 (one signals version bump, re-baseline goldens once) ; 5. H1 (+H8) ; 6. H10, H9 ; 7. H2 ; 8. H7 (last: needs the native runs). Each PR: spec text above copied into `docs/specs/enrichment.md` sections it changes (SPEC-07 §5, §8, §10) in the same PR, `docs/qa.md` and `tasks/todo.md` updated, generated schemas re-run if a contract file changes (none planned), Linux + Windows CI, native Ghidriff matrix for H7/H8 (backend/job code). Do not weaken or skip any existing test; deliberate re-baselines are listed in the PR description with a reviewed diff.

## Decisions for the product owner

1. H2: may old project history rows be deleted (keep 100 / 512 MiB), or must "append-only history" be preserved (then only compress)?
2. H1: acceptable defaults of 8 current and 2 stale generations per profile; is losing older stale rankings acceptable?
3. H7: default `allowlist` after native validation, with `env_passthrough` visible in Setup; confirm no required corporate-proxy or custom-JDK variable beyond the list.
4. H10: slower fetch for keyless NVD users (about 6 s per request after the first four) versus rate-limit errors; may the consent preview state the expected duration?
5. H13: merged snapshot reports the oldest contributing `retrieved_at`; alternative is keeping the newest and showing a per-provider age in the UI (needs a contract change).

## Implementation status (2026-10-14)
H7 (builder + opt-in `restrict_env`/`env_passthrough`, default OFF pending the native Windows gate), H2 (bound without pre-prune backup), H8 (in-place reuse + discard cleanup; legacy cleanup pending), H9 (`netutil.interruptible`, simplified to the 4-thread cap) and H10 (simplified: single-slot pacing 6 s / 0.6 s instead of the sliding window, NVD 403 retried with backoff instead of the key/keyless split, overall deadline = expected + 120 s) landed; where this differs from the text above, the code and `docs/qa.md` are authoritative. "Append-only" history is now "bounded" (see `persistence.py` docstring).

## Phase D track B amendments (2026-10-14; normative, supersede the H1/H2 backup sentences above where they differ)

November 1 publication clarification: stage each new SQLite backup in an exclusively created, unique sibling `.sqlite3.part` file. Publish the verified inode through an atomic, non-replacing hard link; a timestamp collision or unsupported hard links fail closed without authorizing prune. Preserve any earlier final backup or interrupted `.part`, including when final verification fails. Clean up only this attempt's owned temporary inode. This is not a lock against arbitrary same-user filesystem mutation or a universal power-loss durability claim.

November 2 admission clarification: a final `project-pre-<label>-<stamp>.sqlite3` is not discoverable
while a matching unique `project-pre-<label>-<stamp>-*.sqlite3.part` staging name remains. Remove
this attempt's owned staging name only after final byte revalidation succeeds. If post-link
validation fails, retain that staging name and diagnostic bytes, leave every final name untouched,
and raise `BackupError`; later discovery, including after restart, must not adopt that unfinished
publication. This refusal also applies while publication is in progress or staging cleanup fails.
Returning a newly written backup requires both final byte revalidation and completion of the
owned staging-name removal. An ownership mismatch, an unreadable staging identity, or failed
removal is `BackupError`: preserve the final name and any remaining staging/foreign bytes,
and authorize no first prune. After removing the owned name, observe its absence; a replacement
at that name is also failure and is never removed. This does not promise exclusion of arbitrary
filesystem changes after those observations. A verified SQLite copy may still contain every
would-be deleted row after cleanup fails, but it is not a completed backup for the caller.
Failure to open or completely read either directory enumeration refuses every candidate; a
suppressed scan error must never be interpreted as absence of staging names.
Other timestamps' completed backups remain eligible. Existing legacy backups with no matching
unique stage retain the existing project/snapshot/table and fresh-byte verification rules.

Windows timestamp clarification: compare descriptor timestamps before/after through `fstat`, and path timestamps before/after through `lstat`. Their `st_ctime_ns` values can have different meanings on the same unchanged file, so bind the two observations through device, inode, size and mtime instead of comparing ctime across APIs. Preserve each API's change detection, the native Windows change-time fingerprint, full SHA-256 rereads and SQLite verification; no timestamp alone grants trust.

- **Verified pre-prune backup (H2, applies to H1 too).** No prune deletes a row (history prune, enrichment retention, `make_room`, engine-run pruning) unless a trusted backup exists. Module `verified_backup.py` (stdlib + `ingestion.safe_path`, no Qt): a new backup is written with the SQLite backup API to `backups/project-pre-<label>-<UTC stamp>.sqlite3.part`, the writing connection is closed, the file is **re-opened read-only** and must pass `PRAGMA integrity_check` and return the same answers as the live database to identity queries (current snapshot hash; plus `COUNT(*), MAX(sequence)` of `history` or `COUNT(*)` of `enrichment_entries`); only then is it renamed to the final name. An existing backup is trusted only if it re-opens read-only, passes `PRAGMA quick_check`, holds the live project id and the label's table; the verdict is cached per process by (path, size, mtime_ns), so a backup is re-checked once per process and whenever its file changes, not on every save. Labels: `history-prune` (H2), `retention` (H1), `enrichment` (pre-extension, additionally requires the live snapshot hash). Failure is never data loss: the prune is skipped and every row kept (history: the save itself still commits, a warning is logged and the session does not retry the copy; retention: `apply_retention`/`prune_runs` return 0; `make_room` raises recoverable `PT-ENRICH-LIMIT` "retention backup failed"). History: the first prune of a session that lacks a trusted backup is deferred to a second transaction right after the save commits (the copy cannot run inside the save transaction); later prunes of that session stay inside the save transaction. One backup per label is kept and reused ("taken once"); it holds every row deleted by the first prune, not rows created after it (decision 1 above: bounded history is accepted).
- **Legacy duplicate raw cleanup on open (H8).** `ProjectService.open(root, *, maintenance=True)` runs `raw_cleanup.cleanup_legacy_raw_duplicates` after a successful load (never inside `_verify_files`; read-only series readers pass `maintenance=False`). Scope, closed: for each run of the loaded snapshot whose `raw_path` is exactly the legacy copy `runs/<id>/raw/result.ghidriff.json`, the candidates are regular files (no links/junctions) matching `runs/<id>/raw/json/*.ghidriff.json`. A candidate is removed only if the kept `raw_path` file still hashes to `raw_sha256` and the candidate has the same size and SHA-256; anything else (different bytes, unreadable, link, other names, `artifacts/`, quarantine or unreferenced run directories) is left and logged. Backed up and reversible: before each removal one JSON line `{"v":1,"run_id","removed","kept","sha256","size","utc"}` is appended (flushed and fsynced) to `backups/raw-duplicates.jsonl`; the bytes stay recoverable from the verified kept copy, and `raw_cleanup.restore_raw_duplicates(root)` recreates every journalled file whose path is absent after re-checking the kept copy's hash. Idempotent: a second open finds nothing. Best effort: it never raises and never blocks the open; directories are not removed.
- **H3 truncation gap.** A truncated function (`function-too-large`) is `partial` for every applicable detector even when the scanned part holds no non-noise edit (the change may sit in the unscanned tail); before, such a pairing reported `complete` with "no non-noise changed hunk". Untruncated pairings are unchanged. The per-pairing WIL outcome follows the same rule: a truncated function on either side makes it `partial` (`LIMIT: function-too-large`) even when no transition was found in the scanned part. No contract change; covered by the `signals` stage version already bumped in this release cycle plus the algorithm digest below.
- **SPEC-07 §4 `validate_location` (P1 "spec validate_location").** `views.validate_location(project_or_run_view, loc) -> FunctionView` is the single check: the function exists in the run's pairings, belongs to `loc.run_id`, `loc.artifact_id` and `loc.side` (`PT-ENRICH-OWNERSHIP` otherwise), and the 1-based lines exist and hash to `loc.excerpt_sha256` (`PT-ENRICH-STALE` otherwise). The derived-cache hit path (`pipeline._locations_owned`) uses it. GUI navigation (`ui.py`, not in this track) still checks only the function id: wiring it there is left to the UI owner.
- **Algorithm digests in derived-cache keys and stored rows (P2 "derived-cache keys lack algorithm digest").** `identity.constants_digest(domain, version, namespaces, exclude)` digests every plain-data module constant (int/str/bool/None, compiled regex as `{re, flags}`, float as its repr, tuples/lists, sets as sorted lists, dicts with stringified keys, dataclass instances without callable fields; functions, classes, modules and dunder names are skipped). `pipeline.algorithm_digests()` returns one digest per stage: `signals` (constants of `signals`, `views`, `alignment`; `CANCEL_EVERY` excluded), `wil` (`wil` + the `signals` set, because WIL reuses its normalization), `ranking` (`ranking`), `contextual` (`cve`). Each stage id adds the input `'algorithm': <digest>` (stage versions unchanged), so the derived cache misses and new rows get new ids whenever an algorithm constant changes, even if nobody bumps a version. The `pipeline` row body gains the additive key `algorithms` (stage -> digest); `load_default`/`load_profile` serve a row only when its stage versions **and** `algorithms` equal the running code's, otherwise the note reads "Stored ranking is stale (computed by an older PatchTrace version). Rank changes again." Rows written before this change have no `algorithms` and are recomputed once (deliberate re-baseline, listed in `docs/qa.md`). Logic changes that touch no constant still need a stage/detector version bump; a golden-digest test makes every constant change a visible, reviewed re-baseline and checks that the digests are identical on Linux and Windows.
- **H10 live probe (separate, non-gating).** `tools/live_nvd_probe.py` checks direct TCP reachability of each provider host (no proxy, like the transport), then runs the real `patchtrace correlate --fetch` (keyless; two CVEs by default so the 6 s NVD pacing is observable) on a synthetic sample project and writes `build/live-status/cve-providers.json` (`passed | failed | blocked`, per-provider detail, consent preview, pacing evidence). Unreachable hosts, `PT-ENRICH-NETWORK`/rate limits and probe timeouts are `blocked`; normalization failures, CLI errors and broken pacing are `failed` (exit 1). `.github/workflows/live-nvd.yml` runs it weekly and on demand only; it is never a required check and its results are never summed with pytest counts.
- **Performance (no contract change).** Diff hunks are derived lazily, canonical JSON has an exact-type fast path, `_clean` skips delimiter-free lines, WIL skips functions without `Feature` text and reuses B1's hunk filter, and `pipeline.run` pauses the cyclic GC (re-entrant, restores the caller's setting). The 500 ms derived-cache objective at 10,000 pairs remains unmet: strict re-validation of the cached records and ownership revalidation are kept by design; numbers in `docs/qa.md` `[B:hardening]`.

### Backup trust amendment (2026-11-01; issue #121)

The metadata-only backup cache rule above is superseded. Before any cached
backup verdict authorizes deletion, freshly hash the complete backup bytes and
match their SHA-256, file identity and size to the checked version. Restoring a
file's modification time must not preserve trust after its bytes change. Keep
SQLite integrity/identity results cached for unchanged verified bytes, including
worker-to-owner reuse; do not repeat SQLite checks merely because trust is queried.

Read in bounded chunks through one regular-file descriptor. Reject an unreadable,
replaced, resized, or observably changing file during that read. Bind the SQLite
verification to matching fingerprints taken before and after the check, and
revalidate the published copy after exclusive hard-link publication before returning it. Failure retains
all live rows and preserves previously published evidence. This fresh read has
linear I/O cost in backup size; it is a deliberate durability boundary, not a
metadata-only performance shortcut or a lock against arbitrary later writers.

The cached trust-only path may reject a known failed verdict or already-ineligible project/snapshot/table facts without reading the bytes. This is refusal only: every eligible verdict must still pass the complete fresh byte hash before it authorizes deletion. Preparatory verification remains able to inspect a changed candidate and establish a new verdict.
