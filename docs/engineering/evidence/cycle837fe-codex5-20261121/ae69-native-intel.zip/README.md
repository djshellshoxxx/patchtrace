# Native Intel acceptance at ae69f1e65d7c

Run: https://github.com/djshellshoxxx/patchtrace/actions/runs/44881741040 — attempt 1, pull_request, completed/success.

Published head: `ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e`  
Published and actual checkout tree: `c3f09435deb99ca0ddb3406e27ab315dba7740cf`  
Actual checkout in both native job logs: `66f153a8372ad93c72e2f5b10365dcf210681684`

## Actual outcomes

| Platform | Job | Pytest result | Duration |
| --- | --- | --- | --- |
| linux | 136778306622 | 4 passed | 17.85 s |
| windows | 136778306878 | 3 passed, 1 skipped | 48.93 s |

The Windows offline artifact's blocked status and pytest skip describe the same check: `unshare -rn` is unavailable. This is separate from the three engine tests. The dispatch-only live-build-environment job is separately skipped, not another pytest skip.

## Actual native probe and analysis statuses

| Platform | Engine | Version | Probe exits | Analysis status |
| --- | --- | --- | --- | --- |
| linux | capa | 9.4.0 | capa --version: 0, capa --help: 0 | passed |
| linux | floss | 3.1.1 | floss --version: 0, floss -H: 0 | passed |
| linux | diec | 3.21 | diec --version: 0, diec --help: 0 | passed |
| windows | capa | 9.4.0 | capa.exe --version: 0, capa.exe --help: 0 | passed |
| windows | floss | 3.1.1 | floss.exe --version: 0, floss.exe -H: 0 | passed |
| windows | diec | 3.21 | diec.exe --version: 0, diec.exe --help: 0 | passed |

Each per-engine passed artifact requires a supported pinned manifest, both older/newer synthetic fixture analyses returning ok, and selected normalized evidence matching committed goldens. The authored pairs are capa-api, floss-static and diec-same. The exact status JSON and bounded initial probe records are retained. Longer help tails may be marked truncated; the observer does not retain complete raw analysis streams.

## Source and qualification boundaries

Actual `git log -1 --format=%H` command/output receipts and synthetic-merge metadata establish the checkout. Both artifact metadata records bind their ZIP to this published head. Nine fixed-tree workflow/test/adapter/pin source snapshots are retained with blob and SHA-256 identities. Those Intel sources equal a73, but no previous native pass was transferred: only run 44881741040 qualifies this head.

This does not establish arbitrary-binary accuracy, capa Ghidra, FLOSS deobfuscation, DIE heuristic mode or Windows offline namespace isolation. The earlier a73 evidence remains unchanged under ../final-intel-live. This receipt does not qualify a later source head.

## Artifact integrity

| Platform | Artifact | Bytes | SHA-256 |
| --- | --- | --- | --- |
| linux | 14697683317 | 5646 | `bc0ed1446e8755f5420330c786f4615dcdd9cffe0522d7fa5db5c97650515e46` |
| windows | 14698632267 | 5754 | `b75985367d589e936a567e64351bf48b565c871cbea8ec485202509cb04e9e37` |

Both sizes and digests match GitHub API metadata; ZIP CRC checks pass and extracted JSON bytes match original members. Signed download URLs are not retained.

Included: exact artifact ZIPs/status members; full decoded native logs; initial/final run/job/artifact metadata; source snapshots and identities; checkout proof; summary.json; the sealing script; and per-file integrity manifest.

Only existing CI was observed. No source/ref edit, retry, dispatch, local upstream execution or analyzed-target execution occurred. Observation of this run is complete; no background monitoring continues after this report.
