"""Seal only already downloaded evidence; never calls GitHub or executes tools/targets."""
import hashlib
import json
import re
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent
HEAD = 'ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e'
TREE = 'c3f09435deb99ca0ddb3406e27ab315dba7740cf'
CHECKOUT = '66f153a8372ad93c72e2f5b10365dcf210681684'
metadata = json.loads((ROOT / 'final-metadata.json').read_text())
logs = json.loads((ROOT / 'decoded-job-logs.json').read_text())
run = metadata['run']
merge = metadata['synthetic_checkout_commit']
assert run['id'] == 44881741040 and run['head_sha'] == HEAD
assert run['status'] == 'completed' and run['head_commit']['tree_id'] == TREE
assert merge['sha'] == CHECKOUT and merge['tree']['sha'] == TREE
assert HEAD in [parent['sha'] for parent in merge['parents']]

summary = {
    'workflow_run_id': run['id'], 'workflow_url': run['html_url'],
    'run_attempt': run['run_attempt'], 'event': run['event'],
    'head_sha': HEAD, 'tree_sha': TREE, 'actual_checkout_sha': CHECKOUT,
    'workflow_status': run['status'], 'workflow_conclusion': run['conclusion'],
    'platforms': {}, 'total_pytest_counts': {'passed': 0, 'failed': 0, 'skipped': 0, 'errors': 0},
    'blocked_artifact_checks': 0,
    'scope': 'Only this exact head and existing native CI on pinned tools/default synthetic pairs.',
    'previous_results_transferred': False,
    'boundaries': [
        'Windows offline namespace unavailable is a blocked artifact and one skipped pytest check.',
        'Probe observer retains bounded redacted version/help tails, not complete raw analysis streams.',
        'No arbitrary-binary accuracy, capa Ghidra, FLOSS deobfuscation or DIE heuristic qualification.',
        'No source/ref edits, retries, dispatches, local upstream tools or analyzed targets executed.',
    ],
}
checkout_receipts = {}
table = []
probe_table = []
artifact_table = []
for platform, job_id in [('linux', 136778306622), ('windows', 136778306878)]:
    job = next(item for item in metadata['jobs']['jobs'] if item['id'] == job_id)
    assert job['status'] == 'completed'
    log = logs[platform]
    (ROOT / f'{platform}-job-log.txt').write_bytes(log.encode('utf-8'))
    lines = log.splitlines()
    observations = []
    for index, line in enumerate(lines):
        if 'log -1 --format=%H' in line and any(CHECKOUT in value for value in lines[index + 1:index + 4]):
            observations.append(lines[index:index + 3])
    assert observations
    checkout_receipts[platform] = {'job_id': job_id, 'sha': CHECKOUT, 'command_output': observations}
    summaries = [line for line in lines if re.search(r'={2,}.*\bin [0-9.]+s\s*=+', line)]
    assert summaries
    pytest_line = summaries[-1]
    counts = {key: 0 for key in ('passed', 'failed', 'skipped', 'errors')}
    for number, name in re.findall(r'(\d+) (passed|failed|skipped|errors?)\b', pytest_line):
        counts['errors' if name.startswith('error') else name] = int(number)
    seconds = float(re.search(r'\bin ([0-9.]+)s', pytest_line).group(1))
    for key, number in counts.items():
        summary['total_pytest_counts'][key] += number
    checks = {}
    for name in ('capa', 'floss', 'diec', 'floss-offline'):
        record = json.loads((ROOT / platform / f'intel-tools-{name}.json').read_text())
        checks[name] = record
        summary['blocked_artifact_checks'] += int(record['status'] == 'blocked')
        if name != 'floss-offline':
            probes = record.get('probe_diagnostics', {}).get('probes', [])
            exits = ', '.join(f"{' '.join(probe['argv'])}: {probe['returncode']}" for probe in probes)
            probe_table.append(f"| {platform} | {name} | {record.get('version', 'unavailable')} | {exits} | {record['status']} |")
    artifact = json.loads((ROOT / f'{platform}-artifact-metadata.json').read_text())
    archive = ROOT / f'{platform}-live-status.zip'
    data = archive.read_bytes()
    digest = hashlib.sha256(data).hexdigest()
    assert artifact['workflow_run']['head_sha'] == HEAD and artifact['workflow_run']['id'] == run['id']
    assert artifact['size_in_bytes'] == len(data) and artifact['digest'] == f'sha256:{digest}'
    with zipfile.ZipFile(archive) as zipped:
        assert zipped.testzip() is None
        for member in zipped.namelist():
            assert zipped.read(member) == (ROOT / platform / member).read_bytes()
    summary['platforms'][platform] = {
        'job_id': job_id, 'job_url': job['html_url'], 'job_conclusion': job['conclusion'],
        'pytest_counts': counts, 'pytest_seconds': seconds, 'pytest_summary_line': pytest_line,
        'checks': checks,
        'artifact': {'id': artifact['id'], 'bytes': len(data), 'sha256': digest,
                     'api_digest_match': True, 'zip_crc_passed': True},
    }
    text_counts = ', '.join(f'{number} {key}' for key, number in counts.items() if number)
    table.append(f'| {platform} | {job_id} | {text_counts} | {seconds:.2f} s |')
    artifact_table.append(f"| {platform} | {artifact['id']} | {len(data)} | `{digest}` |")
summary['dispatch_only_job'] = {
    'id': 136778307631, 'conclusion': 'skipped', 'counted_as_pytest_skip': False,
    'reason': 'Live build environment job requires workflow_dispatch; this is pull_request.',
}
summary['all_three_engines_passed_both_platforms'] = all(
    platform['checks'][engine]['status'] == 'passed'
    for platform in summary['platforms'].values() for engine in ('capa', 'floss', 'diec')
)
(ROOT / 'checkout-verification.json').write_text(json.dumps(checkout_receipts, indent=2) + '\n')
(ROOT / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
readme = f'''# Native Intel acceptance at ae69f1e65d7c

Run: {run['html_url']} — attempt {run['run_attempt']}, {run['event']}, {run['status']}/{run['conclusion']}.

Published head: `{HEAD}`  
Published and actual checkout tree: `{TREE}`  
Actual checkout in both native job logs: `{CHECKOUT}`

## Actual outcomes

| Platform | Job | Pytest result | Duration |
| --- | --- | --- | --- |
{chr(10).join(table)}

The Windows offline artifact's blocked status and pytest skip describe the same check: `unshare -rn` is unavailable. This is separate from the three engine tests. The dispatch-only live-build-environment job is separately skipped, not another pytest skip.

## Actual native probe and analysis statuses

| Platform | Engine | Version | Probe exits | Analysis status |
| --- | --- | --- | --- | --- |
{chr(10).join(probe_table)}

Each per-engine passed artifact requires a supported pinned manifest, both older/newer synthetic fixture analyses returning ok, and selected normalized evidence matching committed goldens. The authored pairs are capa-api, floss-static and diec-same. The exact status JSON and bounded initial probe records are retained. Longer help tails may be marked truncated; the observer does not retain complete raw analysis streams.

## Source and qualification boundaries

Actual `git log -1 --format=%H` command/output receipts and synthetic-merge metadata establish the checkout. Both artifact metadata records bind their ZIP to this published head. Nine fixed-tree workflow/test/adapter/pin source snapshots are retained with blob and SHA-256 identities. Those Intel sources equal a73, but no previous native pass was transferred: only run {run['id']} qualifies this head.

This does not establish arbitrary-binary accuracy, capa Ghidra, FLOSS deobfuscation, DIE heuristic mode or Windows offline namespace isolation. The earlier a73 evidence remains unchanged under ../final-intel-live. This receipt does not qualify a later source head.

## Artifact integrity

| Platform | Artifact | Bytes | SHA-256 |
| --- | --- | --- | --- |
{chr(10).join(artifact_table)}

Both sizes and digests match GitHub API metadata; ZIP CRC checks pass and extracted JSON bytes match original members. Signed download URLs are not retained.

Included: exact artifact ZIPs/status members; full decoded native logs; initial/final run/job/artifact metadata; source snapshots and identities; checkout proof; summary.json; the sealing script; and per-file integrity manifest.

Only existing CI was observed. No source/ref edit, retry, dispatch, local upstream execution or analyzed-target execution occurred. Observation of this run is complete; no background monitoring continues after this report.
'''
(ROOT / 'README.md').write_text(readme)
entries = []
for path in sorted(ROOT.rglob('*')):
    if path.is_file() and path.name not in ('manifest.json', 'final-ae69-intel.zip'):
        data = path.read_bytes()
        entries.append({'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data),
                        'sha256': hashlib.sha256(data).hexdigest()})
(ROOT / 'manifest.json').write_text(json.dumps({'head_sha': HEAD, 'files': entries}, indent=2) + '\n')
archive = ROOT / 'final-ae69-intel.zip'
with zipfile.ZipFile(archive, 'w', zipfile.ZIP_DEFLATED) as zipped:
    for path in sorted(ROOT.rglob('*')):
        if path.is_file() and path != archive:
            zipped.write(path, path.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as zipped:
    assert zipped.testzip() is None
    members = len(zipped.namelist())
data = archive.read_bytes()
print(json.dumps({'archive': str(archive), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
                  'members': members, 'crc': 'passed', 'counts': summary['total_pytest_counts'],
                  'all_engines_passed': summary['all_three_engines_passed_both_platforms']}, indent=2))
