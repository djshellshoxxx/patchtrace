# Historical Java-probe branches: complete contribution review

Both fresh remote heads match the preserved census. Each branch differs from its exact merge base `8ee61c623fa37c5a219f912cf7870bfeddcb1f70` in exactly one test file. No production behavior or additional path is omitted from this branch-level review.

| Branch | Head | Disposition |
|---|---|---|
| chatgpt/java-probe-ci-fix-20261016 | 0254841e3e635ed717e35abcf83021f001d7df29 | DUPLICATE |
| chatgpt/java-probe-boundaries-20261016 | 09bb4519d7d8e9ff8f40abcba7e11cb297d8b61e | SUPERSEDED |

The first branch only corrects import order. Its unchanged donor test passes against current source. The second retains this correction and expands timeout, cancellation, spawn/error, unknown-version and missing-Java controls. Seven of its eight function declarations are AST-identical to current code. In the remaining test, the current explicit per-iteration list state replaces the donor loop-variable closure. Removing exactly those two fixture assignments and restoring exactly one return expression makes the entire function AST identical; assertions and all four outcome classes remain intact.

On clean local `06ea27de0936f1f8eb1aeca264833c21845a7f36`, whose complete tree `c3f09435deb99ca0ddb3406e27ab315dba7740cf` equals published ae69, one run passed **13 tests**, with zero failures, errors or skips: one original import-order donor test, six original boundary donor tests and six maintained current tests. These are 13 executed test cases with overlapping behavior, not additive native coverage. No runtime, workflow, test, ledger, ref or PR was changed.

The original 181 unmatched / 16 patch-equivalent historical census remains an immutable snapshot. This report accounts for two named whole-branch contributions; it does not claim all remaining branches are reviewed or authorize branch deletion. The old native unknown-Java failure retains its undiagnosed cause; these subprocess fixtures are not native acceptance.

`review.json` records exact identities, paths, command, timing, AST checks, source cleanliness and test counts. The unchanged donor files, complete branch diffs, current comparison, fresh ref receipt and raw/JUnit test output are retained.
