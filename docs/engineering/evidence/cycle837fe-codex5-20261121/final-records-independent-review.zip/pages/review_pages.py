"""Bounded read-only Pages patch checks and in-memory workflow contract controls."""

import ast
import copy
import hashlib
import importlib.metadata
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import time
import xml.etree.ElementTree as ET
import zipfile

import yaml


ROOT = Path('/workspace/scratch/837fe19aae3a')
WORK = ROOT / 'repair-pages-config-hold'
OUT = Path(__file__).resolve().parent / 'pages'
OUT.mkdir(exist_ok=True)
AUTHOR = ROOT / 'evidence/pages-config-hold-repair'
BASE = '5b5328ee83ee4990b3311f7ac90e2f5e5f76f800'
HEAD = '0cdd5bf37130206c2ddec399450be6338ae8e4fd'
TREE = '6d532dd606a1fdf987245a03271970758a03fe57'
PREDICATE = "github.event_name != 'push' || !contains(github.event.head_commit.message, '[no deploy]')"
WORKFLOW = '.github/workflows/pages.yml'
TEST = 'tests/test_site_workflow.py'
PATHS = [WORKFLOW, 'docs/specs/REGISTRY.md', 'docs/specs/pages-deployment-control.md', TEST]


def git(*args):
    return subprocess.run(['git', '-C', str(WORK), *args], check=True, capture_output=True).stdout


def source(commit, path):
    return git('show', commit + ':' + path)


def sha(value):
    return hashlib.sha256(value).hexdigest()


def normalized(node):
    return ast.dump(node, include_attributes=False)


assert git('rev-parse', 'HEAD', 'HEAD^{tree}', 'HEAD^').decode().splitlines() == [HEAD, TREE, BASE]
assert not git('status', '--porcelain=v1')
assert git('diff', '--name-only', BASE, HEAD).decode().splitlines() == PATHS
for marker in ('[no release]', '[no deploy]'):
    assert marker in git('show', '-s', '--format=%B', HEAD).decode()
before = source(BASE, WORKFLOW).decode()
after = source(HEAD, WORKFLOW).decode()
condition_line = '        if: ' + PREDICATE + '\n'
assert after.count(condition_line) == 1
assert after.replace(condition_line, '', 1) == before
parsed_before = yaml.load(before, Loader=yaml.BaseLoader)
parsed_after = yaml.load(after, Loader=yaml.BaseLoader)
build = parsed_after['jobs']['build']
configure = [step for step in build['steps'] if step.get('uses', '').startswith('actions/configure-pages@')]
assert len(configure) == 1
assert configure[0]['if'] == parsed_after['jobs']['deploy']['if'] == PREDICATE
assert 'if' not in build
assert all('if' not in step for step in build['steps'] if step is not configure[0])
normalized_after = copy.deepcopy(parsed_after)
normalized_after['jobs']['build']['steps'][build['steps'].index(configure[0])].pop('if')
assert normalized_after == parsed_before

old_functions = {n.name: n for n in ast.parse(source(BASE, TEST)).body if isinstance(n, ast.FunctionDef)}
new_functions = {n.name: n for n in ast.parse(source(HEAD, TEST)).body if isinstance(n, ast.FunctionDef)}
assert len(old_functions) == 7 and len(new_functions) == 8
changed_name = 'test_builds_with_the_site_tool_and_deploys_the_dist_artifact_to_github_pages'
removed_assert = ast.parse("assert '[no deploy]' not in TEXT.split('\\n  deploy:\\n', 1)[0]").body[0]
for name, fn in old_functions.items():
    if name == changed_name:
        fn = copy.deepcopy(fn)
        matches = [n for n in fn.body if normalized(n) == normalized(removed_assert)]
        assert len(matches) == 1
        fn.body = [n for n in fn.body if n is not matches[0]]
    assert normalized(fn) == normalized(new_functions[name])

spec = importlib.util.spec_from_file_location('independent_pages_workflow_contract', WORK / TEST)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
assert module.TEXT == after
assert module.ROOT.resolve() == WORK.resolve()
checks = [(name, getattr(module, name)) for name in new_functions]
cases = [('candidate', after, True), ('original_missing_configure_guard', before, False)]
cases.append(('wrong_configure_guard', after.replace(condition_line, '        if: true\n', 1), False))
cases.append(('wrong_shared_guard', after.replace(PREDICATE, "github.event_name != 'push'"), False))
cases.append(('build_job_guard', after.replace('  build:\n', '  build:\n    if: false\n', 1), False))
for label, marker in [
    ('install', '      - name: Install the site build tools (never the app dependencies)\n'),
    ('site_tests', '      - name: Site tests (links, alt text, privacy allow-list, address validator, logo, QR)\n'),
    ('site_build', '      - name: Build the site into site/dist\n'),
    ('artifact_upload', '      - uses: actions/upload-pages-artifact@56afc609e74202658d3ffba0e8f6dda462b719fa # v3.0.1\n'),
]:
    assert after.count(marker) == 1
    cases.append((label + '_incorrectly_conditional', after.replace(marker, marker + '        if: false\n', 1), False))
configure_block = '      - uses: actions/configure-pages@983d7736d9b0ae728b81ab479565c72886d7745b # v5.0.0\n' + condition_line
assert after.count(configure_block) == 1
cases.append(('duplicate_configure_step', after.replace(configure_block, configure_block * 2, 1), False))
cases.append(('wrong_artifact_path', after.replace('          path: site/dist\n', '          path: site/other\n', 1), False))
cases.append(('mutable_configure_ref', after.replace('actions/configure-pages@983d7736d9b0ae728b81ab479565c72886d7745b', 'actions/configure-pages@v5', 1), False))
controls = []
for label, text, expected_valid in cases:
    module.TEXT = text
    failed = []
    for name, check in checks:
        try:
            check()
        except (AssertionError, IndexError, ValueError) as error:
            failed.append({'test': name, 'type': type(error).__name__, 'message': str(error)})
    assert (not failed) == expected_valid, (label, failed)
    controls.append({'name': label, 'expected_valid': expected_valid, 'checks_executed': len(checks), 'failures': failed, 'expected_outcome_observed': True})
module.TEXT = after

python = ROOT / 'pages-config-hold-venv/bin/python'
command = [str(python), '-B', '-I', '-m', 'pytest', '--noconftest', '--disable-plugin-autoload',
           '-p', 'no:cacheprovider', '-q', TEST, 'tests/test_spec_registry.py',
           '--junitxml=' + str(OUT / 'maintained.xml')]
if '--seal-only' in sys.argv:
    earlier = json.loads((OUT / 'initial-sealing-attempt.json').read_text())
    assert earlier['source'] == HEAD
    for name, expected in earlier['retained_result_hashes'].items():
        assert sha((OUT / name).read_bytes()) == expected
    run = subprocess.CompletedProcess(command, 0, (OUT / 'maintained.stdout.txt').read_text(),
                                      (OUT / 'maintained.stderr.txt').read_text())
    seconds = None
else:
    started = time.monotonic()
    run = subprocess.run(command, cwd=WORK, env=dict(os.environ, PYTHONDONTWRITEBYTECODE='1', QT_QPA_PLATFORM='offscreen'), capture_output=True, text=True)
    seconds = round(time.monotonic() - started, 3)
    (OUT / 'maintained.stdout.txt').write_text(run.stdout)
    (OUT / 'maintained.stderr.txt').write_text(run.stderr)
assert run.returncode == 0, run.stdout + run.stderr
xml = ET.parse(OUT / 'maintained.xml')
testcases = list(xml.iter('testcase'))
assert len(testcases) == 119 and len({(c.attrib.get('classname'), c.attrib['name']) for c in testcases}) == 119
assert all(not list(c) for c in testcases)
assert not git('status', '--porcelain=v1')

archive = AUTHOR / 'pages-config-hold-repair-0cdd5bf3.zip'
assert sha(archive.read_bytes()) == 'a0f0f0dd5a9cb68698a7e6b410b9c39059755fc00c78168cd8c89df0f1997025'
with zipfile.ZipFile(archive) as z:
    assert len(z.namelist()) == len(set(z.namelist())) == 44
    assert z.testzip() is None
    manifest_name = 'evidence-manifest.json'
    manifest = z.read(manifest_name)
    assert sha(manifest) == '14554ab8bbb08d03a1731461785bf8c11777779e79b3254999c54de95e7a3565'
    entries = []
    for entry in json.loads(manifest)['files']:
        content = z.read(entry['path'])
        assert len(content) == entry['bytes'] and sha(content) == entry['sha256']
        assert content == (AUTHOR / entry['path']).read_bytes()
        entries.append(entry['path'])
    assert set(entries) | {manifest_name} == set(z.namelist())

result = {
    'verdict': 'No blocker found for the narrow Pages configuration hold repair.',
    'head': HEAD, 'tree': TREE, 'parent': BASE, 'changed_paths': PATHS,
    'workflow_change': 'Exactly one if line on configure-pages, identical to the unchanged deploy predicate.',
    'workflow_raw_and_parsed_proof': True, 'other_build_steps_unconditional': True,
    'six_original_test_functions_ast_unchanged': True,
    'remaining_original_test_only_removes_superseded_global_marker_ban': True,
    'new_test_enforces_exactly_one_configure_step_and_other_steps_unconditional': True,
    'controls': controls,
    'maintained': {'command': command, 'cwd': str(WORK), 'returncode': run.returncode,
                   'passed': len(testcases), 'failed': 0, 'errors': 0, 'skipped': 0,
                   'command_seconds': seconds, 'pytest_summary': run.stdout.strip().splitlines()[-1],
                   'clean_before_after': True, 'project_test_run_count': 1,
                   'sealing_resumed_without_test_rerun': '--seal-only' in sys.argv},
    'author_archive': {'sha256': sha(archive.read_bytes()), 'bytes': archive.stat().st_size, 'members': 44, 'verified_manifest_payloads': len(entries)},
    'file_identities': [{'path': path, 'blob': git('rev-parse', HEAD + ':' + path).decode().strip(), 'sha256': sha(source(HEAD, path))} for path in PATHS],
    'boundaries': [
        'This independent run is 119 maintained workflow/registry cases; overlaps author selections and is not added to them.',
        'In-memory negative controls exercise maintained source assertions without editing workflow or test source.',
        'The actual post-main configure GET404 remains separate from successful premerge primary qualification; its cause is not narrowed beyond the retained evidence.',
        'Manual dispatch and unmarked pushes retain existing configure/deploy behavior and its configuration/permission prerequisites.',
        'No Pages enablement, hosted dispatch, release or deployment occurred. A future automatic held main push must establish hosted skip/upload behavior.',
        'The existing transitive upload-artifact tag is unchanged; no nested-action closure is claimed.',
    ],
    'source_or_ref_edits': False,
    'initial_sealing_attempt': json.loads((OUT / 'initial-sealing-attempt.json').read_text()),
}
(OUT / 'review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'verdict': result['verdict'], 'head': HEAD, 'tree': TREE,
                  'maintained_passed': len(testcases), 'controls': len(controls),
                  'review_sha256': sha((OUT / 'review.json').read_bytes())}, indent=2))
