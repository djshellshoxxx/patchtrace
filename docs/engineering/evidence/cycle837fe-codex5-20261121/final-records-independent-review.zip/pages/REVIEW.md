# Independent Pages configuration-hold review

**No blocker found** on exact commit `0cdd5bf37130206c2ddec399450be6338ae8e4fd`, tree `6d532dd606a1fdf987245a03271970758a03fe57`, parent `5b5328ee83ee4990b3311f7ac90e2f5e5f76f800`.

The complete delta contains exactly four paths: the Pages workflow, its deployment-control spec, the registry row and `tests/test_site_workflow.py`. Both publication opt-out markers are present in the commit message.

Removing the new `configure-pages` condition line makes the workflow byte-identical to its parent. Independent YAML parsing likewise finds exactly one added step condition; the rest of the parsed workflow is equal. Its predicate equals the unchanged deploy condition. The build job and every other build step—including site tool installation, tests, build and artifact upload—remain unconditional. Action pins, ordering, permissions, triggers, environment and concurrency are unchanged.

Six original workflow-test functions are AST-identical. The seventh removes only the obsolete global ban on a marker anywhere before the deploy job. The added test requires exactly one configure step, equality with the separately exact-checked deploy predicate, no build-job condition and no condition on any other build step. The updated spec and registry describe that narrow exception and preserve manual-dispatch behavior.

Independent exact-source workflow/registry execution completed **119 passed**, zero failures/errors/skips, on the clean frozen checkout. Raw stdout reports **0.23 seconds**. This overlaps the author's selections and is not added to them.

All **12 distinct in-memory controls** produced the expected outcomes: the valid candidate passes; the original unguarded workflow and ten other altered texts are rejected. Those controls cover wrong configure/shared predicates, a conditional build job, conditional install/tests/build/upload steps, duplicate configure steps, an incorrect artifact path and a mutable configure Action reference. No checked-in source was changed for controls.

The author's archive is **96,916 bytes, 44 members**, SHA-256 `a0f0f0dd5a9cb68698a7e6b410b9c39059755fc00c78168cd8c89df0f1997025`. All **43 payloads** match their manifest hashes and retained disk files; CRCs and exact membership pass. The original 404 evidence and lower-baseline regression are retained. The author disclosed the final explanatory spec wording change; the final frozen workflow/registry receipt binds the exact commit.

The initial independent sealing step expected the wrong manifest filename. Its failure, script and passing test outputs are preserved; sealing was resumed using the advertised JSON manifest without rerunning project tests. This was a reviewer receipt-format correction, not a product failure.

This is source/contract clearance. The observed post-main configure GET404 remains separate from successful PR349 premerge qualification, and does not alone distinguish absent configuration from permission visibility. Unmarked pushes and manual dispatch retain their existing Pages prerequisites. No Pages enablement, ref/PR operation, hosted dispatch, release or deployment was performed. The next authorized held main push must establish the actual hosted skip/upload result. Existing transitive Action references remain outside this repair.
