"""Read-only audit of the frozen records tree; writes reviewer evidence only."""

from __future__ import annotations

import collections
import datetime
import hashlib
import io
import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET
import zipfile

ROOT = Path('/workspace/scratch/837fe19aae3a')
REPO = ROOT / 'PatchTrace-codex5-followup'
OUT = ROOT / 'evidence/codex5-final-records-independent'
TREE = 'e7ecad2c0b1128a83876bf137634cf9f64d29f1f'
CODE = '0cdd5bf37130206c2ddec399450be6338ae8e4fd'
CODE_TREE = '6d532dd606a1fdf987245a03271970758a03fe57'
C5 = '5b5328ee83ee4990b3311f7ac90e2f5e5f76f800'
C5_TREE = '1e12edd510399fd92da6867cd071394ceb7fc95b'
MAIN = '9023761a4066ac1c50c127ac09d0ba5f56cdc9e4'
AE69 = 'ae69f1e65d7c4564ec5b0e6d7a80119193fabc4e'
FDC = 'fdc2696c23bdbfe7668348f25e3b336ce33039f7'
PRIMARY_TREE = 'c3f09435deb99ca0ddb3406e27ab315dba7740cf'
DONOR = '36b58a7d857690a8bf0093bcee1edd5036189b30'
PREFIX = 'docs/engineering/evidence/cycle837fe-codex5-20261121/'
LEDGER = 'docs/engineering/task-ledger.json'
checks: list[dict] = []


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git(*args: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(REPO), *args])


def blob(ref: str, path: str) -> bytes:
    return git('show', f'{ref}:{path}')


def record(name: str, condition: bool, **details: object) -> None:
    entry = {'check': name, 'passed': bool(condition), **details}
    checks.append(entry)
    if not condition:
        (OUT / 'failed-verifier-receipt.json').write_text(json.dumps(checks, indent=2) + '\n')
        raise AssertionError(name)


def payload(name: str) -> bytes:
    return blob(TREE, PREFIX + name)


def pj(name: str):
    return json.loads(payload(name))


def tree_entries(ref: str) -> dict[str, str]:
    out = {}
    for entry in git('ls-tree', '-rz', '--full-tree', ref).split(b'\0'):
        if entry:
            meta, path = entry.split(b'\t', 1)
            out[path.decode()] = meta.decode()
    return out


record('HEAD matches reviewed Pages source', git('rev-parse', 'HEAD').decode().strip() == CODE)
record('Code tree identity', git('rev-parse', CODE + '^{tree}').decode().strip() == CODE_TREE)
record('No tracked unstaged edits', subprocess.run(['git', '-C', str(REPO), 'diff', '--quiet']).returncode == 0)
record('Index equals immutable reviewed tree', subprocess.run(['git', '-C', str(REPO), 'diff', '--cached', '--quiet', TREE]).returncode == 0)
merge_path = Path(git('rev-parse', '--git-path', 'MERGE_HEAD').decode().strip())
if not merge_path.is_absolute():
    merge_path = REPO / merge_path
record('Pending merge parents ordered actual main then original donor', merge_path.read_text().splitlines() == [MAIN, DONOR])
base_entries, final_entries = tree_entries(CODE), tree_entries(TREE)
changed = sorted(p for p in base_entries.keys() | final_entries.keys() if base_entries.get(p) != final_entries.get(p))
record_paths = {
    'docs/engineering-handoffs/cycle837fe-combined-pr349-20261121.md',
    'docs/engineering/cycle837fe-codex5-20261121.md', LEDGER, 'docs/qa.md', 'tasks/todo.md',
}
record('Only five record paths and evidence subtree change', all(p in record_paths or p.startswith(PREFIX) for p in changed), changed_path_count=len(changed), changed_paths=changed)
record('No code-tree path deleted', set(base_entries) <= set(final_entries))
record('Every other tracked entry exactly equals reviewed source', all(final_entries[p] == v for p, v in base_entries.items() if p not in record_paths), protected_entries=sum(p not in record_paths for p in base_entries))

baseline_raw = blob(C5, LEDGER)
baseline = json.loads(baseline_raw)
current_raw = blob(TREE, LEDGER)
current = json.loads(current_raw)
donor = json.loads(blob(DONOR, LEDGER))
donor_base = json.loads(blob('f928a0cef29eac2b603d390c40fb86448111b91b', LEDGER))
by_id = {t['id']: t for t in current['tasks']}
before_by_id = {t['id']: t for t in baseline['tasks']}
record('Entire prior authoritative ledger retained byte-for-byte', payload('prior-ledger-ae69.json') == baseline_raw and blob(AE69, LEDGER) == baseline_raw, sha256=sha(baseline_raw))
record('Original 98 IDs/order; 104 unique total', len(baseline['tasks']) == 98 and len(current['tasks']) == len(by_id) == 104 and [t['id'] for t in current['tasks'][:98]] == [t['id'] for t in baseline['tasks']])
promoted = {
    'search-header-help-20261121-837fe', 'service-postcommit-snapshot-20261121-837fe',
    'backup-cleanup-cancellation-20261121-837fe', '837fe-codex1-direct-actions',
    '837fe-intel-windows-version-names', '837fe-intel-probe-diagnostics',
    '837fe-pr349-spec-registry', '837fe-combined-pr349-qualification',
    '837fe-intel-synthetic-windows-identity', '837fe-native-c4-combined-qualification',
    '837fe-tier-r-immutable-pin-contract',
}
legacy = {
    'codex14-linux-frozen-cli-smoke-20261121', 'codex6-corpus-cache-archive-20261121',
    'codex6-cache-hit-fixture-20261121', 'cycle3-pages-deployment-control',
    'pages-site-isolation-and-hashes-20261121-95fe',
    'codex5-per-command-audit-gap-20261121-95fe', '837fe-codex5-bounded-assessment',
}
changed_tasks = {i for i, t in before_by_id.items() if t != by_id[i]}
record('Exactly 11 promotions plus seven authorized legacy updates; other 80 rows exact', changed_tasks == promoted | legacy and not promoted & legacy, changed_ids=sorted(changed_tasks))
record('All eleven primary promotions retain implementation COMPLETE', all(by_id[i]['status'] == 'MERGED' and before_by_id[i]['status'] == 'TESTING' and by_id[i]['implementation_status'] == before_by_id[i]['implementation_status'] == 'COMPLETE' for i in promoted))
record('Baseline three continuation histories preserved exactly', current['continuation_history'][:3] == baseline['continuation_history'] and len(current['continuation_history']) == 6)
h3, h4, h5 = current['continuation_history'][3:]
record('Eleven complete pre-promotion rows preserved', {t['id']: t for t in h3['updated_tasks_before_promotion']} == {i: before_by_id[i] for i in promoted})
record('Prior top-level current fields deep copied', all(v == baseline[k] for k, v in h3['previous_current_fields'].items()))
legacy_receipt = pj('primary-acceptance-reconciliation.json')
record('All seven legacy before rows and history equal baseline', {t['id']: t for t in legacy_receipt['before']} == {i: before_by_id[i] for i in legacy} and h4['before'] == legacy_receipt['before'])
record('All seven recorded after rows equal final current rows', {t['id']: t for t in legacy_receipt['after']} == {i: by_id[i] for i in legacy})
record('Pages checkpoint retains former C5 source and qualification', h5['previous_current_fields']['aggregate_source_commit'] == C5 and h5['previous_current_fields']['aggregate_source_tree'] == C5_TREE)
expected_top_changes = {
    'aggregate_source_commit', 'aggregate_source_tree', 'checkpoint_local_commit',
    'codex5_followup_837fe', 'continuation', 'continuation_history', 'current_qualification',
    'integration_branch', 'local_integration_branch', 'notes', 'primary_main_promotion_837fe',
    'remote_publication', 'tasks', 'updated_at',
}
top_changes = {k for k in baseline.keys() | current.keys() if baseline.get(k) != current.get(k)}
record('Only authorized ledger top-level fields change; workers/history retained', top_changes == expected_top_changes, changed_fields=sorted(top_changes))
new_donor_tasks = [t for t in donor['tasks'] if t['id'] not in {x['id'] for x in donor_base['tasks']}]
new_donor_notes = [n for n in donor['notes'] if n not in donor_base['notes']]
recovery = pj('recovered-donor-task-and-notes.json')
record('Exactly one original donor task and two notes recovered', len(new_donor_tasks) == 1 and len(new_donor_notes) == 2 and recovery['task'] == new_donor_tasks[0] and recovery['notes'] == new_donor_notes)
record('Original 44 notes remain prefix; exact two donor notes appended', current['notes'] == baseline['notes'] + new_donor_notes and len(current['notes']) == 46)
record('Donor task deep copy and notes retained in history and current checkpoint', h3['original_donor_task'] == new_donor_tasks[0] and h3['original_donor_notes'] == new_donor_notes and by_id[new_donor_tasks[0]['id']]['original_donor_checkpoint'] == new_donor_tasks[0])
context = pj('primary-promotion-context.json')
record('Four additional completed tasks exactly match frozen authorized context', current['tasks'][99:103] == context['additional_completed_tasks'] and all(t['status'] == 'COMPLETE' for t in current['tasks'][99:103]))
record('Final appended Pages task is complete implementation, testing acceptance', current['tasks'][103]['id'] == '837fe-pages-configuration-hold' and current['tasks'][103]['status'] == 'TESTING' and current['tasks'][103]['implementation_status'] == 'COMPLETE')
for path in ['docs/engineering-handoffs/cycle837fe-combined-pr349-20261121.md', 'docs/qa.md', 'tasks/todo.md']:
    original = blob(C5, path)
    record('Prior complete file retained as exact suffix: ' + path, blob(TREE, path).endswith(original), original_bytes=len(original), original_sha256=sha(original))

manifest = pj('manifest.json')
rows = manifest['payloads']
names = [row['path'] for row in rows]
evidence_entries = {p[len(PREFIX):] for p in final_entries if p.startswith(PREFIX)}
record('Manifest exactly inventories all 51 payloads', len(names) == len(set(names)) == 51 and set(names) | {'manifest.json'} == evidence_entries)
archive_inventory = []
total = 0
for row in rows:
    data = payload(row['path'])
    total += len(data)
    record('Payload size and digest: ' + row['path'], len(data) == row['bytes'] and sha(data) == row['sha256'])
    if row['path'].endswith('.zip'):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            record('ZIP CRC and unique members: ' + row['path'], z.testzip() is None and len(set(z.namelist())) == len(z.namelist()))
            archive_inventory.append({'path': row['path'], 'members': len(z.namelist()), 'bytes': len(data), 'sha256': sha(data)})
record('Total evidence payload bytes', total == 8441650, payloads=51, bytes=total)
known = {
    'primary-final-ae69-evidence.zip': '8eb127426bcf216b840bc10d5243fccdb8964d4ba17bf53b6282920406b57859',
    'ae69-native-intel.zip': '6e32067c94180fec5f94223eeed28b6456e54592e4f432a9c8aeb69b9595af9b',
    'independent-review.zip': '356c89a7e9ffd7c01e25d47e98ed02b291be0c69bc0e22934ee609e61c99f7e6',
    'author-history.zip': '888cae02ac96bc90a9a51061f2d1e2ee38935ea8a1187f9c60b0921e585ba878',
    'root-validation.zip': 'b0cf012bab566eb9b9102a167ef820b0401d131844f09769c5d610ee4ab44b89',
    'historical-java-probe.zip': '5bae9c5cde288a619c5aef2cb23df84c7c991a51999532266b2b12797eeafb29',
    'historical-license-review.zip': 'a86b0478942988b249857c600a964cfb521b096cebbfe69ddb47f6e7e2ae8769',
    'historical-license-independent.zip': 'e35b585568b7bfc861abdab661ecb6282deee1f662e43d47afae33e2271c53fb',
    'ancillary-branches.zip': '81bc99aa2ece7800031b75649da9c0527edbf977c6ef16bf3192f0fdf82cf3d0',
    'pr-chain-reconciliation-review.zip': 'ddb93f07a44cf41106c5ed9237b10a5f0c4e965d6f28d91530f73fc0a331279c',
    'pages-config-hold-repair.zip': 'a0f0f0dd5a9cb68698a7e6b410b9c39059755fc00c78168cd8c89df0f1997025',
    'pages-independent-review.zip': '0144ec7a091e1c4e7da8624d5ffe3e5ce1212f9a032c6ae81971033ec14d954e',
    'combined-pages-record-validation.zip': 'aa3e6238d4e3386fa0763cf77b83d5081493854b808dfce8be2107009b2c8d77',
    'records-assembly-helper.py': 'b73c4d771bdd17ca35e63ff7663b3cf92b907ef8714ff4c37e63051d701d1c26',
    'primary-promotion-context.json': '161b88781535beb8a905a19264b9ff0e39e6a8cf4b0184bbe6fea16f352aabe2',
    'local-codex5-pages-source.bundle': '350676f4a9d97e37b3da4e7cdaf2ec3363859430e0bac9690bb30cab5d886997',
}
for name, digest in known.items():
    record('Exact previously reviewed/frozen evidence retained: ' + name, sha(payload(name)) == digest)
bundle_path = OUT / 'verified-source.bundle'
bundle_path.write_bytes(payload('local-codex5-pages-source.bundle'))
bundle_result = subprocess.run(['git', '-C', str(REPO), 'bundle', 'verify', str(bundle_path)], capture_output=True, text=True)
heads = git('bundle', 'list-heads', str(bundle_path)).decode()
(OUT / 'bundle-verification.log').write_text(bundle_result.stdout + bundle_result.stderr + '\nADVERTISED HEADS\n' + heads)
record('Source bundle verifies against retained base', bundle_result.returncode == 0, advertised_heads=heads.splitlines())
record('Exact C5 and Pages ordered local code chain retained', git('rev-list', '--reverse', AE69 + '..' + CODE).decode().splitlines() == ['93b053a88e4373d9f5c69cd68f96e1a49305d579', '4cbe479023067b05b688cd1c1b02994b0228e305', C5, CODE])

proof = pj('primary-merge-proof.json')
main_raw = git('cat-file', 'commit', MAIN)
main_headers = main_raw.split(b'\n\n', 1)[0].decode().splitlines()
record('Actual main Git object identity', hashlib.sha1(b'commit ' + str(len(main_raw)).encode() + b'\0' + main_raw).hexdigest() == MAIN)
record('Actual primary merge parents/tree/opt-outs', [s[7:] for s in main_headers if s.startswith('parent ')] == [FDC, AE69] and 'tree ' + PRIMARY_TREE in main_headers and b'[no release]' in main_raw and b'[no deploy]' in main_raw)
record('Retained REST actual merge agrees with full Git object', proof['actual_commit']['sha'] == MAIN and [p['sha'] for p in proof['actual_commit']['parents']] == [FDC, AE69] and proof['actual_commit']['tree']['sha'] == PRIMARY_TREE and proof['pull_request']['merged_at'] == '2026-11-21T09:25:16Z')
seven = pj('primary-final-qualification.json')
prelim = json.loads((OUT / 'preliminary-input-review.json').read_text())
record('Seven-run archive and separate Intel form eight unique workflows', {r['id'] for r in seven['runs']} == set(prelim['seven_run_ids']) and {r['id'] for r in proof['premerge_workflows']} == set(prelim['seven_run_ids']) | {44881741040} and len(proof['premerge_workflows']) == 8)
record('Eight workflows success attempt one on exact primary head', all(r['head_sha'] == AE69 and r['run_attempt'] == 1 and r['conclusion'] == 'success' for r in proof['premerge_workflows']))
job_counts = collections.Counter(j['conclusion'] for j in proof['premerge_jobs'])
record('Primary combined 30 successful jobs and four skipped jobs', job_counts == {'success': 30, 'skipped': 4}, counts=dict(job_counts))
record('Source-specific primary full suite figures unchanged', seven['qa']['full_suites'] == prelim['platform_full_suites'])
closures = pj('primary-pr-closures.json')
closure_summaries = []
for item in closures:
    b, a = item['before'], item['after']
    record(f'PR {item["pr"]}: closed after actual merge, original description suffix retained', a['state'] == 'closed' and a['merged'] is False and a['draft'] is True and a['merged_at'] is None and a['closed_at'] > '2026-11-21T09:25:16Z' and a['body'].endswith(b['body']) and item['via_merge'] == MAIN)
    record(f'PR {item["pr"]}: original head, base and title preserved', all(a[k] == b[k]['ref'] and a[k + '_sha'] == b[k]['sha'] for k in ['head', 'base']) and a['title'] == b['title'])
    closure_summaries.append({'pr': item['pr'], 'method': item['method'], 'head': a['head_sha'], 'base': a['base_sha'], 'original_body_sha256': sha(b['body'].encode()), 'original_body_preserved_as_suffix': True, 'reconciliation_prefix_bytes': len(a['body'].encode()) - len(b['body'].encode())})
record('PR346 remains explicitly selective recovery, not whole-head ancestry', [c for c in closures if c['pr'] == 346][0]['method'] == 'selective recovery')
dispositions = pj('historical-dispositions.json')
record('Original 181/16 census unchanged', dispositions['original_census'] == {'unmatched': 181, 'patch_equivalent': 16} and dispositions['original_census_rewritten'] is False)
record('Only five previously reviewed complete-branch dispositions', len(dispositions['dispositions']) == 5 and {x['head'] for x in dispositions['dispositions']} == {'0254841e3e635ed717e35abcf83021f001d7df29', '09bb4519d7d8e9ff8f40abcba7e11cb297d8b61e', 'd3617acf9af7834582b4962a8c149969a7d55a22', '09f07582d8d9017fe2be080605120b5c4cfd0b91', '566c43cd1647697cc770ea0cb92a0fb130015ec9'} and all(x['original_ref_retained'] and not x['original_census_rewritten'] for x in dispositions['dispositions']))

qualification = pj('qualification.json')
record('C5 1548 pass/two strict xfail belongs only to 5b', qualification['source_commit'] == C5 and qualification['source_tree'] == C5_TREE and qualification['distinct_affected_passed'] == 1548 and qualification['case_count'] == 1550 and qualification['xfailed'] == 2 and qualification['selection_node_selectors'] == 66 and len(qualification['expected_failure_ids']) == 2)
full = qualification['prior_full_attempt']
record('Prior dirty failed full attempt preserved without cause invention or pass transfer', full['source'] == '93b053a88e4373d9f5c69cd68f96e1a49305d579' and full['started_from_modified_worktree'] and full['exit_code'] == -9 and full['wrapper_exit_code'] == 247 and full['seconds'] == 498.536 and full['cause'] == 'unknown' and full['aggregate_summary'] is None and full['second_local_full_attempt'] is False)
record('Current source identifies Pages combination; release and merge eligibility false', current['aggregate_source_commit'] == current['checkpoint_local_commit'] == CODE and current['aggregate_source_tree'] == CODE_TREE and current['release_ready'] is False and current['main_merge_eligible'] is False and current['continuation']['status'] == 'TESTING')
record('Bounded parser and Pages implementation remain testing; broader C5 rows blocked', by_id['codex5-per-command-audit-20261121']['status'] == 'TESTING' and by_id['codex5-per-command-audit-20261121']['implementation_status'] == 'COMPLETE' and by_id['837fe-pages-configuration-hold']['status'] == 'TESTING' and by_id['codex5-per-command-audit-gap-20261121-95fe']['status'] == 'BLOCKED' and by_id['837fe-codex5-bounded-assessment']['status'] == 'BLOCKED')
record('Manifest distinguishes current source and original assembly checkpoint', manifest['code_source'] == CODE and manifest['code_tree'] == CODE_TREE and manifest['assembly_checkpoint']['code_source'] == C5 and manifest['release_ready'] is False and manifest['new_source_main_merge_eligible'] is False)
mapping = pj('pages-code-publication-mapping.json')
record('Pages remote code mapping exact tree and ordered single parent; no ref movement claimed', mapping['source'] == CODE and mapping['tree'] == CODE_TREE and mapping['remote'] == '06b5ed67c78aac30972e657b4a7ae5a17de739b8' and mapping['actual_remote_commit']['tree']['sha'] == CODE_TREE and [p['sha'] for p in mapping['actual_remote_commit']['parents']] == ['92dfc4d4d2ef9d604bc9db1a639d4f19add535a8'] and mapping['local_parent'] == C5 and mapping['ref_movement'] is False)
validation = pj('combined-pages-record-validation.json')
record('Post-record validation explicitly scoped to 0cdd with records dirty', validation['source'] == CODE and validation['source_tree'] == CODE_TREE and validation['records_dirty_explicit'] and validation['no_runtime_tests_tools_workflow_diffs'] and validation['no_full_suite_attempt'] and all(r['head'] == CODE and r['returncode'] == 0 and r['dirty_before'] == r['dirty_after'] for r in validation['receipts']))
with zipfile.ZipFile(io.BytesIO(payload('combined-pages-record-validation.zip'))) as z:
    cases = ET.fromstring(z.read('registry.xml')).findall('.//testcase')
    record('Archived final registry XML independently counts 111 passes', len(cases) == 111 and all(not any(c.find(tag) is not None for tag in ['failure', 'error', 'skipped']) for c in cases))
report = blob(TREE, 'docs/engineering/cycle837fe-codex5-20261121.md').decode()
record('Report explicitly retains source boundaries and open acceptance gates', all(text in report for text in ['Earlier `5b5328ee` evidence below remains source-specific', '30 successful jobs and four intentional skips', 'No second local full run occurred', 'Cause: **unknown**', '181 unmatched / 16 patch-equivalent', 'Release readiness and new-source merge eligibility remain false']))
record('Frozen index and tracked source still unchanged at review end', subprocess.run(['git', '-C', str(REPO), 'diff', '--quiet']).returncode == 0 and subprocess.run(['git', '-C', str(REPO), 'diff', '--cached', '--quiet', TREE]).returncode == 0)

result = {
    'schema': 'patchtrace/independent-final-records-review/1',
    'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'verdict': 'CLEAR for this exact staged records tree and planned ordered ancestry; actual final commit/ref/CI are not yet asserted',
    'blockers': [], 'reviewer': '/root/codex1_independent_review',
    'records_tree': TREE, 'code_source': CODE, 'code_tree': CODE_TREE,
    'planned_ordered_parents': [CODE, MAIN, DONOR],
    'checks_passed': len(checks), 'checks': checks,
    'ledger': {'baseline_tasks': 98, 'current_tasks': 104, 'unchanged_original_tasks': 80, 'promoted_original_tasks': 11, 'reconciled_legacy_tasks': 7, 'appended_tasks': 6, 'prior_notes': 44, 'donor_notes': 2, 'prior_histories': 3, 'current_histories': 6, 'current_sha256': sha(current_raw)},
    'payloads': {'count': len(rows), 'bytes': total, 'manifest_sha256': sha(payload('manifest.json')), 'archives': archive_inventory},
    'pr_closures': closure_summaries,
    'source_tests_rerun_for_records_review': 0,
    'pages_independent_source_review': {'source': CODE, 'maintained_passed': 119, 'in_memory_controls': 12, 'archive_sha256': known['pages-independent-review.zip']},
    'review_scope': 'Retained exact objects and artifacts only; no fresh remote claims, product tests, helper execution, source/index/ref/PR/CI mutations.',
    'remaining_gates': ['Verify actual final record commit and equivalent remote ordered parents/tree after creation.', 'A bounded review-receipt-only addition may follow; recheck that exact delta.', 'Applicable hosted qualification for the final new source and guarded main promotion remain pending.', 'Hosted held Pages configure-skip/upload evidence remains pending.', 'Broad CODEX-5 hashes, native/environment, Ghidra archive-cache, manual/trust/provenance and L1/L2/L3 gates stay open; release readiness is false.'],
}
(OUT / 'review.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['verdict', 'records_tree', 'planned_ordered_parents', 'checks_passed', 'ledger']}, indent=2))
