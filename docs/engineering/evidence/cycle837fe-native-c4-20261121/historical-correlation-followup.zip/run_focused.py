from __future__ import annotations
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parent
CWD = ROOT / 'frozen-source'
PYTHON = ROOT / 'venv/bin/python'
EXPECTED = 'd628749401f61d3653b5e066ff38245b938c5dcd'
SELECTION = [
    'tests/test_kbc_components.py',
    'tests/test_kbc_pairs_index.py::test_explicit_title_filename_survives_component_selection_and_reopening',
    'tests/test_kbc_resolver.py::test_unsupported_product_scope_architecture_blocks_amd64_index_pairs',
    'tests/test_kbc_resolver.py::test_arm64_product_name_does_not_resolve_to_amd64_index_pair',
    'tests/test_kbc_resolver.py::test_arm64_side_is_a_hard_block',
    'tests/test_kbc_card_field_provenance.py',
    'tests/test_kbc_msrc_review_findings.py',
    'tests/test_enrichment_cve.py',
    'tests/test_intel_audit_c_enrichment.py',
]


def git(*args):
    return subprocess.check_output(['git', *args], cwd=CWD, text=True).strip()


env = dict(os.environ)
env.pop('PYTHONPATH', None)
env['QT_QPA_PLATFORM'] = 'offscreen'
head = git('rev-parse', 'HEAD')
assert head == EXPECTED
assert not git('status', '--porcelain')
commands = {
    'source-binding': [str(PYTHON), '-I', '-c',
                       'from pathlib import Path; import patchtrace; p=Path(patchtrace.__file__).resolve(); '
                       f'print(p); assert p == Path({str(CWD / "src/patchtrace/__init__.py")!r})'],
    'focused': [str(PYTHON), '-m', 'pytest', '-q', *SELECTION, '--junitxml=' + str(ROOT / 'focused.xml')],
}
receipts = []
for label, command in commands.items():
    start = datetime.datetime.now(datetime.timezone.utc)
    clock = time.monotonic()
    with (ROOT / (label + '.log')).open('w') as stream:
        p = subprocess.run(command, cwd=CWD, env=env, stdout=stream, stderr=subprocess.STDOUT)
    r = {'label': label, 'command': command, 'cwd': str(CWD), 'source_commit': head,
         'source_tree': git('rev-parse', 'HEAD^{tree}'), 'returncode': p.returncode,
         'started_at_utc': start.isoformat(), 'finished_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'seconds': round(time.monotonic() - clock, 3), 'dirty_after': git('status', '--porcelain'),
         'source_after': git('rev-parse', 'HEAD'), 'log_sha256': hashlib.sha256((ROOT / (label + '.log')).read_bytes()).hexdigest()}
    if label == 'focused' and (ROOT / 'focused.xml').exists():
        cases = list(ET.parse(ROOT / 'focused.xml').getroot().iter('testcase'))
        counts = {'passed': 0, 'failed': 0, 'errors': 0, 'skipped': 0, 'xfailed': 0}
        for c in cases:
            if c.find('failure') is not None:
                counts['failed'] += 1
            elif c.find('error') is not None:
                counts['errors'] += 1
            elif c.find('skipped') is not None:
                counts['xfailed' if c.find('skipped').get('type') == 'pytest.xfail' else 'skipped'] += 1
            else:
                counts['passed'] += 1
        r['counts'] = counts
        r['identities'] = [[c.get('classname'), c.get('name')] for c in cases]
        r['case_count'] = len(cases)
        r['distinct_count'] = len({tuple(x) for x in r['identities']})
        r['selectors'] = SELECTION
    receipts.append(r)
    (ROOT / (label + '.json')).write_text(json.dumps(r, indent=2) + '\n')
    print(json.dumps({k: v for k, v in r.items() if k not in ('identities', 'command', 'selectors')}), flush=True)
    assert p.returncode == 0
    assert r['source_after'] == head and not r['dirty_after']
(ROOT / 'test-receipts.json').write_text(json.dumps(receipts, indent=2) + '\n')
