from __future__ import annotations

import ast
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/837fe19aae3a/PatchTrace-native-followup')
TARGET = 'd628749401f61d3653b5e066ff38245b938c5dcd'
SCOPES = [
    {'id': 'pr190-filename-selection', 'branch': 'codex/kb-explicit-filename-selection-20261104',
     'head': '761b6b885f00143597c74f0457b1165a144fbdd4', 'pr': 190,
     'production': {'src/patchtrace/kbcorrelation/components.py': None},
     'tests': {'tests/test_kbc_components.py': None,
               'tests/test_kbc_pairs_index.py': ['test_explicit_title_filename_survives_component_selection_and_reopening']}},
    {'id': 'pr122-product-architecture', 'branch': 'codex/pr110-kb-arch-scope-20261029',
     'head': '40e02daf93c8e13a94b74f5b80d86c1680fea7ad', 'pr': 122,
     'production': {'src/patchtrace/kbcorrelation/resolver.py': ['resolve']},
     'tests': {'tests/test_kbc_resolver.py': None}},
    {'id': 'pr159-card-field-provenance', 'branch': 'codex/msrc-reconcile-integration-20261102',
     'head': '56374f867594dd923383c91ea71970cb7d24d173', 'pr': 159,
     'production': {'src/patchtrace/kbcorrelation/card_provenance.py': None,
                    'src/patchtrace/kbcorrelation/context.py': ['ContextBundle', 'ContextBundle._same_cves', 'build_bundle'],
                    'src/patchtrace/kbcorrelation/sources/importer.py': ['ImportedDocument', '_import_plain'],
                    'src/patchtrace/kbcorrelation/wiring.py': ['IntelligenceRules.interpret', '_merge_profiles'],
                    'src/patchtrace/intelligence/lexicon.py': ['classify'],
                    'src/patchtrace/intelligence/contracts.py': ['CweClassification', 'CweClassification._honest', 'CweProfile']},
     'tests': {'tests/test_kbc_card_field_provenance.py': None}},
    {'id': 'enrichment-cve-normalization', 'branch': 'feat/enrichment-cve',
     'head': '49bf245583d040a8b29d80daee8666d8c7f7b8d4', 'pr': None,
     'production': {'src/patchtrace/enrichment/cve.py': None},
     'tests': {'tests/test_enrichment_cve.py': None}},
]


def git(*args: str, binary: bool = False):
    out = subprocess.check_output(['git', *args], cwd=REPO)
    return out if binary else out.decode().strip()


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def declarations(source: bytes):
    tree = ast.parse(source)
    found = {}

    def walk(body, prefix=''):
        for node in body:
            if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                name = prefix + node.name
                found[name] = node
                if isinstance(node, ast.ClassDef):
                    walk(node.body, name + '.')
    walk(tree.body)
    return found


def compare(scope, path, selected):
    donor = git('show', scope['head'] + ':' + path, binary=True)
    target = git('show', TARGET + ':' + path, binary=True)
    donor_decl, target_decl = declarations(donor), declarations(target)
    records = []
    for name in selected or donor_decl:
        old = ast.dump(donor_decl[name], include_attributes=False).encode()
        new = ast.dump(target_decl[name], include_attributes=False).encode() if name in target_decl else None
        records.append({'name': name, 'present': new is not None, 'ast_identical': old == new,
                        'donor_ast_sha256': digest(old), 'target_ast_sha256': digest(new) if new else None})
    for label, content in [('donor', donor), ('target', target)]:
        out = ROOT / 'source' / scope['id'] / label / path
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(content)
    return {'path': path, 'donor_blob': git('rev-parse', scope['head'] + ':' + path),
            'target_blob': git('rev-parse', TARGET + ':' + path),
            'donor_bytes_sha256': digest(donor), 'target_bytes_sha256': digest(target),
            'byte_identical': donor == target, 'declarations': records,
            'target_added_declarations': sorted(set(target_decl) - set(donor_decl))}


inventory = json.loads(gzip.decompress(git('show', TARGET + ':docs/engineering/evidence/cycle837fe-20261121/references/technical-inventory.compact.json.gz', binary=True)))
by_branch = {b['branch']: b for b in inventory['branches']}
results = []
for scope in SCOPES:
    b = by_branch[scope['branch']]
    assert b['head'] == scope['head']
    pr = next((p for p in b['pull_requests'] if p['number'] == scope['pr']), None)
    obj = {k: v for k, v in scope.items() if k not in ('production', 'tests')}
    obj.update({'donor_tree': git('rev-parse', scope['head'] + '^{tree}'), 'captured_pr': pr,
                'merge_bases_with_target': git('merge-base', '--all', scope['head'], TARGET).splitlines(),
                'unique_nonmerge_commits_vs_target': git('rev-list', '--no-merges', scope['head'], '^' + TARGET).splitlines(),
                'production_comparisons': [compare(scope, path, names) for path, names in scope['production'].items()],
                'test_source_comparisons': [compare(scope, path, names) for path, names in scope['tests'].items()]})
    base = pr['base_sha'] if pr else 'bafd62a52c2cc397698fd993ea21cf56c3ef4936'
    obj['original_scope_base'] = base
    obj['original_changed_paths'] = git('diff', '--name-status', base, scope['head']).splitlines()
    results.append(obj)

report = {'target_commit': TARGET, 'target_tree': git('rev-parse', TARGET + '^{tree}'),
          'observed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'scope': 'Source behavior review; declaration counts are not executed-test counts.', 'records': results}
(ROOT / 'source-comparison.json').write_text(json.dumps(report, indent=2) + '\n')
for row in results:
    print(row['id'])
    for kind in ['production_comparisons', 'test_source_comparisons']:
        for c in row[kind]:
            print(json.dumps({'kind': kind, 'path': c['path'], 'byte_identical': c['byte_identical'],
                              'equal': len([d for d in c['declarations'] if d['ast_identical']]),
                              'changed': [d['name'] for d in c['declarations'] if not d['ast_identical']],
                              'missing': [d['name'] for d in c['declarations'] if not d['present']]}))
