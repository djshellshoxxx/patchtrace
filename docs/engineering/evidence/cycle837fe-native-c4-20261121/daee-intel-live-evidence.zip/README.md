# Intel live acceptance triage — PR 349

## Result

Exact published head: `daee337c48c63dda8aeac149c407e900c79dcc86`.
Exact tree: `6c2a8d018ccc00bf65ef074579604b40627f7658`.
Run: https://github.com/djshellshoxxx/PatchTrace/actions/runs/44876415860

The advisory workflow completed successfully, but Windows acceptance did not pass.

| Platform | Job | Actual pytest outcome | Artifact outcome |
| --- | --- | --- | --- |
| Linux | 136761988496 | 4 passed in 17.81 s | capa, FLOSS, DIE, and offline FLOSS passed |
| Windows | 136761988615 | 2 failed, 1 passed, 1 skipped in 28.49 s | capa and FLOSS failed; DIE passed; offline FLOSS blocked |

Windows blocked and pytest skipped describe the same offline check, not two checks.
The Linux live-build-environment job was dispatch-only and skipped in this run.

## Native evidence

Windows capa `--version` returned zero and emitted `capa.exe 9.4.0` with CRLF. Its help probe also returned zero. The optional `.exe` version-name repair therefore has actual native confirmation for capa. Subsequent analysis of both synthetic fixtures failed with exit 1 and generic `ModuleNotFoundError`; the missing module is not named by capa's retained analysis error.

Windows FLOSS `--version` and `-H` both returned 1. Complete bounded stderr names the stack `vivisect.defconfig -> getpass.getuser -> ModuleNotFoundError: No module named 'pwd'`. Neither probe timed out, exceeded the output bound, failed to spawn, nor truncated its stderr. Its version parsing cannot fix this process failure.

DIE 3.21 passed with reproduced synthetic goldens on both platforms. Linux capa 9.4.0 and FLOSS 3.1.1 passed with reproduced synthetic goldens. Linux offline FLOSS passed in an empty network namespace. Windows offline FLOSS is blocked because `unshare -rn` is unavailable.

## Source diagnosis and minimum proposed repair

`process.tool_env` delegates to the from-scratch BinDiff environment layout. Its Windows mapping has `USERPROFILE` but none of `LOGNAME`, `USER`, `LNAME`, or `USERNAME`. Python `getpass.getuser` checks those identity variables and falls back to `pwd` when none is set. The actual FLOSS traceback proves that fallback failed in its native executable.

A controlled stdlib check using actual `tool_env(..., windows=True)` plus simulated unavailable `pwd` reproduced that exact exception. Adding only the fixed synthetic value `USERNAME=patchtrace` returned `patchtrace`; no supplied caller identity or secret marker was inherited. This controlled mechanism check did not execute FLOSS or capa and is not native Windows acceptance.

The smallest proposed repair is a fixed synthetic Windows `USERNAME` in Intel `process.tool_env`, corresponding Intel environment specification, and focused controls. Preserve exclusion of real inherited identities and secrets. Preserve supported-major checks, pinning, exit admission, process limits, isolated paths, and shared BinDiff/Rizin policy. A fresh exact-head native Windows run remains necessary to confirm the resulting tool outcomes.

Capa may share the Vivisect identity failure, but its generic analysis error lacks the stack needed to prove that link. Treat it as inference until a fresh native result resolves it or supplies diagnostic proof.

The environment implementation files have identical blobs at prior head `11f51c105bf63946f59373ae605b937c4fee607a` and this head. Thus the omitted identity was pre-existing, not introduced by the `.exe` admission or diagnostic-observer patch. Old observations alone lacked stderr proof; this run supplies that proof for FLOSS. No source edits, workflow retries/dispatches, remote mutations, or local upstream/analyzed-target execution were made during this read-only triage.

## Evidence contents and integrity

- `raw-github-responses.json`: run, job, and artifact metadata.
- `decoded-job-logs.json`: full decoded native Linux and Windows logs.
- Platform ZIPs: exact downloaded artifacts, with IDs, byte sizes, API SHA-256 comparisons in `artifact-verification.json`.
- `linux/` and `windows/`: byte-preserved extracted artifact JSON members.
- `source/`: exact relevant source bytes from the fixed published commit, not a moving working tree.
- `source-identity.json`: head/tree and relevant before/after Git blob IDs.
- `python-getuser-source.json`: official illustrative CPython v3.11.7 source; this does not identify FLOSS's bundled Python version.
- `getuser-environment-control.json`: controlled stdlib mechanism-check result.
- `summary.json`: machine-readable outcomes and boundaries.
- `manifest.json`: relative paths, byte sizes, and SHA-256 of all enclosed evidence except the manifest itself.

Signed download URLs are not retained. Artifact checksums match GitHub's API digests and ZIP CRC checks pass.
