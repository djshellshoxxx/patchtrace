from __future__ import annotations

import datetime
import hashlib
import io
import json
import subprocess
import tempfile
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path

REPO = Path('/workspace/scratch/837fe19aae3a/PatchTrace-native-followup')
OUT = Path('/workspace/scratch/837fe19aae3a/evidence/native-publication-audit')
HEAD = '717027dec2f3d4b1c6ee67c0c663f6505f7bf34a'
TREE = 'dc8b45543f4ddd517aad239a5945f67dbf30ed59'
CODE = '6bf79feffe68a9fdc1293a69900320e12be662bc'
CODE_TREE = 'dc659c7ef80e317b6c13c120e09f47c5d313f3ca'
INTEL = 'd628749401f61d3653b5e066ff38245b938c5dcd'
C4 = '39a95c549d48eb523e9efdfda394bb9f184e2b16'
BASE = 'daee337c48c63dda8aeac149c407e900c79dcc86'
E = 'docs/engineering/evidence/cycle837fe-native-c4-20261121/'


def git(*args, raw=False, cwd=REPO, input=None):
    value = subprocess.check_output(['git', *args], cwd=cwd, input=input)
    return value if raw else value.decode().strip()


def data(path):
    return git('show', HEAD + ':' + path, raw=True)


def obj(path):
    return json.loads(data(path))


def digest(value):
    return hashlib.sha256(value).hexdigest()


def junit(value):
    cases = list(ET.fromstring(value).iter('testcase'))
    identities = [(x.get('classname'), x.get('name')) for x in cases]
    counts = dict(passed=0, failed=0, errors=0, skipped=0, xfailed=0)
    xfails = []
    for case in cases:
        skip = case.find('skipped')
        if case.find('failure') is not None:
            counts['failed'] += 1
        elif case.find('error') is not None:
            counts['errors'] += 1
        elif skip is not None:
            key = 'xfailed' if skip.get('type') == 'pytest.xfail' else 'skipped'
            counts[key] += 1
            if key == 'xfailed':
                xfails.append({'id': case.get('classname') + '::' + case.get('name'), 'message': skip.get('message')})
        else:
            counts['passed'] += 1
    assert len(identities) == len(set(identities)), 'Duplicate test identities'
    return {'counts': counts, 'cases': len(cases), 'distinct': len(set(identities)), 'xfails': xfails}


started = datetime.datetime.now(datetime.timezone.utc).isoformat()
assert git('rev-parse', HEAD + '^{tree}') == TREE
assert git('rev-parse', CODE + '^{tree}') == CODE_TREE
assert git('show', '-s', '--format=%P', CODE).split() == [INTEL, C4]
initial = {'head': git('rev-parse', 'HEAD'), 'status': git('status', '--porcelain')}
# The coordinator may append record-only commits; every audited byte below is
# read from the requested immutable Git object, never the mutable working tree.
source_paths = ['src', 'tests', 'tools', '.github', 'docs/specs', 'site']
source_diff = git('diff', '--name-only', CODE, HEAD, '--', *source_paths)
assert not source_diff
changed = git('diff', '--name-only', CODE, HEAD).splitlines()
assert all(p.startswith(('docs/engineering/', 'docs/engineering-handoffs/')) or p in ['docs/modules.md', 'docs/qa.md', 'tasks/todo.md'] for p in changed)

manifest = obj(E + 'manifest.json')
assert manifest['source_commit'] == CODE and manifest['source_tree'] == CODE_TREE
files = manifest['payloads']
assert len(files) == 45 and len({f['path'] for f in files}) == 45
actual_files = set(git('ls-tree', '-r', '--name-only', HEAD, '--', E).splitlines())
assert actual_files == {E + f['path'] for f in files} | {E + 'manifest.json'}
archives = []
inner_hashes = 0
total_members = 0
nested_archives = []
for entry in files:
    payload = data(E + entry['path'])
    assert len(payload) == entry['bytes'] and digest(payload) == entry['sha256'], entry['path']
    if not entry['path'].endswith('.zip'):
        continue
    with zipfile.ZipFile(io.BytesIO(payload)) as z:
        names = z.namelist()
        assert len(names) == len(set(names)) and z.testzip() is None
        total_members += len(names)
        for member in names:
            path = Path(member)
            assert not path.is_absolute() and '..' not in path.parts
            if member.endswith('.zip'):
                with zipfile.ZipFile(io.BytesIO(z.read(member))) as child:
                    assert child.testzip() is None
                    nested_archives.append({'outer': entry['path'], 'member': member, 'members': len(child.namelist())})
        if 'manifest.json' in names:
            m = json.loads(z.read('manifest.json'))
            records = m if isinstance(m, list) else m.get('files', m.get('payloads'))
            assert records is not None
            assert set(names) == {r['path'] for r in records} | {'manifest.json'}, entry['path']
            for r in records:
                content = z.read(r['path'])
                assert len(content) == r['bytes'] and digest(content) == r['sha256'], (entry['path'], r['path'])
            inner_hashes += len(records)
        else:
            lines = z.read('manifest.sha256').decode().splitlines()
            records = [line.split(None, 1) for line in lines if line]
            assert set(names) == {r[1] for r in records} | {'manifest.sha256'}
            for h, n in records:
                assert digest(z.read(n)) == h
            inner_hashes += len(records)
        archives.append({'path': entry['path'], 'members': len(names), 'sha256': digest(payload), 'bytes': len(payload)})
assert len(archives) == 7

primary = junit(data(E + 'combined-focused.xml'))
assert primary['counts'] == dict(passed=1396, failed=0, errors=0, skipped=0, xfailed=1)
assert primary['cases'] == primary['distinct'] == 1397
assert primary['xfails'] == [{'id': 'tests.test_codex_pkg_workflows::test_pip_downloads_require_hashes', 'message': 'CODEX-5'}]
prior_intel = junit(data(E + 'intel-combined-focused.xml'))
assert prior_intel['counts'] == dict(passed=1314, failed=0, errors=0, skipped=0, xfailed=1)
plan = obj(E + 'combined-test-plan.json')
assert plan['prepared_at_head'] == CODE and len(plan['selection']) == 64 and len(set(plan['selection'])) == 64
receipts = []
for prefix, source, tree in [('combined-', CODE, CODE_TREE), ('intel-combined-', INTEL, '5d4f2d3beff122b352d0d62a15ea0800c578c0b9')]:
    for label in ['focused', 'ruff', 'dependencies', 'source-binding']:
        receipt = obj(E + prefix + label + '.json')
        assert receipt['head'] == receipt['head_after'] == source and receipt['tree'] == tree
        assert receipt['returncode'] == 0 and receipt['dirty_before'] == receipt['dirty_after'] == ''
        receipts.append({'path': prefix + label + '.json', 'source': source, 'returncode': 0})
primary_receipt = obj(E + 'combined-focused.json')
assert [v for v in primary_receipt['command'] if v.startswith('tests/')] == plan['selection']
assert primary_receipt['junit_counts'] == primary['counts']
assert primary_receipt['case_count'] == primary_receipt['distinct_case_count'] == 1397
assert '1396 passed, 1 xfailed in 83.09s' in data(E + 'combined-focused.log').decode()

with zipfile.ZipFile(io.BytesIO(data(E + 'native-c4-independent.zip'))) as z:
    report = json.loads(z.read('review-report.json'))
    test = json.loads(z.read('integration-tests.json'))
    log = z.read('integration-tests.log').decode()
    assert report['reviewed_head'] == CODE and report['reviewed_tree'] == CODE_TREE
    assert report['runtime']['maintained_tests']['passed'] == 141
    assert '141 passed in 3.26s' in log
    assert test['returncode'] == 0
    assert report['file_composition']['entire_tree_exact_union']
    assert not report['standards_findings'] and not report['spec_findings']
    assert report['pages']['hosted_index_or_build_acceptance_established'] is False
with zipfile.ZipFile(io.BytesIO(data('docs/engineering/evidence/cycle4-parent-20261121/qualification-and-review-evidence.zip'))) as z:
    c4_cases = junit(z.read('root/combined-after.xml'))
    c4_receipt = json.loads(z.read('root/combined-after.json'))
    assert c4_cases['counts'] == dict(passed=580, failed=0, errors=0, skipped=0, xfailed=1)
    assert c4_receipt['head'] == '111803d54cfebc1b779f4832a069904b3ee91a7c'
with zipfile.ZipFile(io.BytesIO(data(E + 'historical-correlation-followup.zip'))) as z:
    hist_cases = junit(z.read('focused.xml'))
    hist_receipt = json.loads(z.read('focused.json'))
    assert hist_cases['counts'] == dict(passed=134, failed=0, errors=0, skipped=0, xfailed=0)
    assert hist_receipt['source_commit'] == hist_receipt['source_after'] == INTEL

intel = obj(E + 'daee-intel-summary.json')
assert intel['head_sha'] == BASE and intel['workflow_conclusion'] == 'success'
assert intel['advisory_success_is_not_acceptance'] is True
assert intel['platforms']['windows']['counts'] == dict(passed=1, failed=2, skipped=1, blocked=1)
assert intel['platforms']['windows']['checks']['floss-offline']['status'] == 'blocked'
native = obj(E + 'daee-native-summary.json')
assert native['source']['head'] == BASE
tier = native['actual_results']['tier_r']
assert tier['status'] == 'warning'
assert tier['pairs']['attempted'] == 11 and tier['pairs']['completed'] == 5 and tier['pairs']['failed'] == 6
assert tier['historical_comparison']['pair_status_reason_mappings_equal'] is True
assert tier['historical_comparison']['canonical_report_digest_equal'] is True
assert native['qa_snapshot']['status'] == 'in_progress'
assert obj(E + 'qualification.json')['final_source_hosted'] == 'pending exact final PR349 publication head'

common_dir = Path(git('rev-parse', '--path-format=absolute', '--git-common-dir'))
bundle_results = []
for name, expected_commits, expected_prerequisites, expected_tip in [
    ('intel-original-source.bundle', {INTEL}, {BASE}, INTEL),
    ('combined-original-source.bundle', {C4, CODE}, {INTEL, '111803d54cfebc1b779f4832a069904b3ee91a7c'}, CODE),
]:
    blob = data(E + name)
    header, pack = blob.split(b'\n\n', 1)
    lines = header.decode().splitlines()
    prerequisites = {line[1:].split(' ', 1)[0] for line in lines if line.startswith('-')}
    refs = [line.split(' ', 1) for line in lines if line and not line.startswith(('#', '-', '@'))]
    assert prerequisites == expected_prerequisites
    assert refs == [[expected_tip, 'HEAD']]
    with tempfile.TemporaryDirectory(dir=OUT, prefix='bundle-check-') as tmp:
        tmp = Path(tmp)
        git('init', '-q', '--bare', str(tmp))
        (tmp / 'objects/info/alternates').write_text(str(common_dir / 'objects') + '\n')
        indexed = git('index-pack', '--stdin', '--fix-thin', cwd=tmp, input=pack)
        idx = next((tmp / 'objects/pack').glob('*.idx'))
        verified = git('verify-pack', '-v', str(idx), cwd=tmp)
        packed_commits = {line.split()[0] for line in verified.splitlines() if len(line.split()) >= 2 and line.split()[1] == 'commit'}
        assert packed_commits == expected_commits, (name, packed_commits)
        metadata = []
        for commit in sorted(packed_commits):
            metadata.append({'sha': commit, 'tree': git('show', '-s', '--format=%T', commit, cwd=tmp),
                             'parents': git('show', '-s', '--format=%P', commit, cwd=tmp).split(),
                             'author': git('show', '-s', '--format=%an <%ae> %aI', commit, cwd=tmp)})
        bundle_results.append({'path': name, 'bytes': len(blob), 'sha256': digest(blob), 'prerequisites': sorted(prerequisites),
                               'tip': expected_tip, 'actual_packed_commits': metadata, 'pack_index': indexed})

final = {'head': git('rev-parse', 'HEAD'), 'status': git('status', '--porcelain')}
result = {'reviewed_head': HEAD, 'reviewed_tree': TREE, 'tested_code': CODE, 'tested_code_tree': CODE_TREE,
          'started_at': started, 'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'source_areas_unchanged': source_paths, 'changed_paths': len(changed), 'payloads': len(files),
          'payload_bytes': sum(x['bytes'] for x in files), 'archives': archives, 'archive_members': total_members,
          'inner_payload_hashes_verified': inner_hashes, 'nested_archives_crc_verified': nested_archives,
          'combined_junit': primary, 'intel_prior_junit': prior_intel, 'c4_prior_junit': c4_cases,
          'historical_scope_junit': hist_cases, 'independent_maintained_passes': 141,
          'receipts': receipts, 'bundle_verification': bundle_results, 'source_state_before': initial,
          'source_state_after': final, 'blocking_findings': [], 'candidate_mutation': False,
          'immutable_object_reads': True, 'coordinator_moved_live_head': initial != final,
          'tests_executed': False, 'native_execution': False, 'remote_mutation': False}
(OUT / 'package-checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: result[k] for k in ['reviewed_head','payloads','payload_bytes','archive_members','inner_payload_hashes_verified','combined_junit','blocking_findings']}, indent=2))
