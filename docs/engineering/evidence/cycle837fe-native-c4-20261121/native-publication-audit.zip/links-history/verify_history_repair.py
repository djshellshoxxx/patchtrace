from __future__ import annotations

import datetime
import json
import subprocess
from pathlib import Path

REPO = Path('/workspace/scratch/837fe19aae3a/PatchTrace-native-followup')
OUT = Path('/workspace/scratch/837fe19aae3a/evidence/native-publication-audit/links-history')
BASE = '6bf79feffe68a9fdc1293a69900320e12be662bc'
INITIAL = '717027dec2f3d4b1c6ee67c0c663f6505f7bf34a'
PARENT = '7ace25243baffe92533e472ef7c0e8229b734e77'
FIXED = '5435d9cdb7daf272156916dd32034d103fa8988c'
TREE = '754a90a94ed60cda2293c3c332e5778cda65c0a2'
LEDGER = 'docs/engineering/task-ledger.json'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO, text=True).strip()


def load(commit):
    return json.loads(git('show', commit + ':' + LEDGER))


source, before, after = load(BASE), load(INITIAL), load(FIXED)
assert git('rev-parse', FIXED + '^{tree}') == TREE
assert git('show', '-s', '--format=%P', FIXED) == PARENT
changed_paths = git('diff', '--name-only', PARENT, FIXED).splitlines()
assert changed_paths == [LEDGER]
expected = json.loads(json.dumps(before))
expected['continuation_history'][-1]['record']['combined_followup_837fe'] = source['combined_followup_837fe']
assert after == expected
assert after['continuation_history'][-1]['record']['combined_followup_837fe'] == source['combined_followup_837fe']
assert after['continuation_history'][-1]['record']['combined_followup_837fe']['code_commit'] == '2a67980cfeb88ad72bf8ad523d2bafc8426e5b7c'
assert after['continuation_history'][-1]['record']['combined_followup_837fe']['qualification']['distinct_affected_passed'] == 1296
assert after['combined_followup_837fe']['code_commit'] == BASE
assert after['combined_followup_837fe']['qualification']['distinct_affected_passed'] == 1396
assert after['current_qualification']['source_commit'] == BASE
assert after['current_qualification']['distinct_affected_passed'] == 1396
assert after['tasks'] == before['tasks']
assert len(after['tasks']) == len({task['id'] for task in after['tasks']}) == 97
assert after['main_merge_eligible'] is False and after['release_ready'] is False

result = {
    'finding': 'LH-H1 / parent N-PUB-H1', 'status': 'CLOSED',
    'initial_head': INITIAL, 'repair_parent': PARENT, 'repaired_head': FIXED, 'repaired_tree': TREE,
    'verified_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'changed_paths': changed_paths,
    'exact_ledger_delta': 'Only continuation_history[-1].record.combined_followup_837fe restored from exact6bf source ledger.',
    'historical_source': '2a67980cfeb88ad72bf8ad523d2bafc8426e5b7c', 'historical_passed': 1296,
    'current_source': BASE, 'current_passed': 1396,
    'all_other_ledger_values_exact': True, 'tasks_unchanged': True,
    'previous_29_link_and_12_file_history_checks_unaffected': True,
    'candidate_edited': False, 'tests_or_remote_actions': False,
    'observed_live_head': git('rev-parse', 'HEAD'), 'observed_worktree_status': git('status', '--porcelain'),
    'passed': True,
}
(OUT / 'repair-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
