from __future__ import annotations

import datetime
import difflib
import hashlib
import json
import posixpath
import re
import subprocess
from pathlib import Path

REPO = Path('/workspace/scratch/837fe19aae3a/PatchTrace-native-followup')
OUT = Path('/workspace/scratch/837fe19aae3a/evidence/native-publication-audit/links-history')
BASE = '6bf79feffe68a9fdc1293a69900320e12be662bc'
HEAD = '717027dec2f3d4b1c6ee67c0c663f6505f7bf34a'
EXPECTED_TREE = 'dc8b45543f4ddd517aad239a5945f67dbf30ed59'


def git(*args: str, allow_missing: bool = False) -> str | None:
    result = subprocess.run(['git', *args], cwd=REPO, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
    if result.returncode:
        if allow_missing:
            return None
        raise RuntimeError(result.stderr)
    return result.stdout


def strict_pairs(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f'duplicate key: {key}')
        result[key] = value
    return result


def load(path: str, commit: str):
    return json.loads(git('show', f'{commit}:{path}'), object_pairs_hook=strict_pairs)


def changed_keys(before, after):
    return sorted(k for k in before.keys() | after.keys() if before.get(k) != after.get(k))


started = datetime.datetime.now(datetime.timezone.utc).isoformat()
observed_head_before = git('rev-parse', 'HEAD').strip()
dirty_before = git('status', '--porcelain')
assert git('rev-parse', HEAD + '^{tree}').strip() == EXPECTED_TREE
paths = git('diff', '--name-only', BASE, HEAD).splitlines()
markdown_paths = [p for p in paths if p.endswith('.md') and '/evidence/' not in p]
tree_paths = set(git('ls-tree', '-r', '--name-only', HEAD).splitlines())
histories = []
links = []
issues = []

for path in markdown_paths:
    before = git('show', f'{BASE}:{path}', allow_missing=True)
    after = git('show', f'{HEAD}:{path}')
    old_lines = [] if before is None else before.splitlines(keepends=True)
    new_lines = after.splitlines(keepends=True)
    changes = difflib.SequenceMatcher(a=old_lines, b=new_lines, autojunk=False).get_opcodes()
    deletes = [dict(operation=kind, old_start=i1 + 1, old_end=i2, new_start=j1 + 1, new_end=j2)
               for kind, i1, i2, j1, j2 in changes if kind in ('delete', 'replace')]
    if deletes:
        issues.append(dict(scope='historical Markdown preservation', path=path, changes=deletes))
    additions = [(j1, ''.join(new_lines[j1:j2])) for kind, i1, i2, j1, j2 in changes if kind == 'insert']
    histories.append(dict(path=path, existed_before=before is not None,
                          old_lines=len(old_lines), new_lines=len(new_lines),
                          inserted_lines=sum(j2-j1 for kind, i1, i2, j1, j2 in changes if kind == 'insert'),
                          replacements_or_deletions=deletes,
                          before_sha256=hashlib.sha256(before.encode()).hexdigest() if before is not None else None,
                          after_sha256=hashlib.sha256(after.encode()).hexdigest()))
    for offset, text in additions:
        for match in re.finditer(r'\[[^\]\n]*\]\(([^)\s]+)\)', text):
            target = match.group(1)
            if re.match(r'^[a-zA-Z][a-zA-Z0-9+.-]*:', target) or target.startswith('//'):
                continue
            target_path, _, fragment = target.partition('#')
            resolved = posixpath.normpath(posixpath.join(posixpath.dirname(path), target_path)) if target_path else path
            record = dict(source=path, target=target, resolved=resolved, fragment=fragment or None,
                          line=offset + text[:match.start()].count('\n') + 1,
                          exists=resolved in tree_paths)
            links.append(record)
            if not record['exists']:
                issues.append(dict(scope='new local Markdown link', **record))

old = load('docs/engineering/task-ledger.json', BASE)
new = load('docs/engineering/task-ledger.json', HEAD)
assert len(old['tasks']) == 93
assert len(new['tasks']) == 97
assert len({t['id'] for t in new['tasks']}) == 97
assert [t['id'] for t in old['tasks']] == [t['id'] for t in new['tasks'][:93]]
allowed_changed = {
    'search-header-help-20261121-837fe',
    'service-postcommit-snapshot-20261121-837fe',
    'backup-cleanup-cancellation-20261121-837fe',
    '837fe-intel-windows-version-names',
    '837fe-combined-pr349-qualification',
}
task_changes = []
for previous, current in zip(old['tasks'], new['tasks'][:93]):
    keys = changed_keys(previous, current)
    if not keys:
        continue
    task_id = previous['id']
    task_changes.append(dict(id=task_id, keys=keys))
    assert task_id in allowed_changed, (task_id, keys)
    if task_id in {'search-header-help-20261121-837fe', 'service-postcommit-snapshot-20261121-837fe',
                   'backup-cleanup-cancellation-20261121-837fe'}:
        expected = {k: previous.get(k) for k in ['target_integration_branch', 'blockers', 'next_action', 'dependencies']}
        assert current['integration_history'][-1] == expected
        assert set(keys) == {'target_integration_branch', 'blockers', 'next_action', 'dependencies', 'integration_history'}
        for key, value in previous.items():
            if key not in {'target_integration_branch', 'blockers', 'next_action', 'dependencies', 'integration_history'}:
                assert current[key] == value, (task_id, key)
    elif task_id == '837fe-intel-windows-version-names':
        assert keys == ['latest_native_observation']
        assert all(current[k] == v for k, v in previous.items())
    elif task_id == '837fe-combined-pr349-qualification':
        assert keys == ['current_followup']
        assert all(current[k] == v for k, v in previous.items())

assert old['tasks'][-3:] == new['tasks'][90:93]
history = new['continuation_history'][-1]['record']
history_fields = ['checkpoint_local_commit', 'aggregate_source_commit', 'aggregate_source_tree',
                  'current_qualification', 'remote_publication', 'current_handoff',
                  'local_integration_branch', 'continuation', 'combined_followup_837fe']
history_mismatches = [key for key in history_fields if history.get(key) != old.get(key)]
if history_mismatches:
    issues.append(dict(id='LH-H1', scope='preserved predecessor checkpoint',
                       fields=history_mismatches,
                       explanation='The prior daee checkpoint record contains new combined code and qualification instead of its original predecessor values.'))
assert new['checkpoint_local_commit'] == new['aggregate_source_commit'] == BASE
assert new['aggregate_source_tree'] == 'dc659c7ef80e317b6c13c120e09f47c5d313f3ca'
assert new['current_qualification']['source_commit'] == BASE
assert new['current_handoff'] == 'docs/engineering-handoffs/cycle837fe-combined-pr349-20261121.md'
assert new['local_integration_branch'] == git('branch', '--show-current').strip()
assert new['continuation']['code_commit'] == new['combined_followup_837fe']['code_commit'] == BASE
assert new['native_c4_followup_837fe']['code_commit'] == BASE
assert 'remote_code_commit' not in new['combined_followup_837fe']
assert new['remote_publication']['previous_source_head'] == 'daee337c48c63dda8aeac149c407e900c79dcc86'
assert new['remote_publication']['branch'] == new['integration_branch'] == 'integration/patchtrace-20261121-95fe-c3'
assert new['remote_publication']['pr_number'] == new['continuation']['target_pr'] == 349
assert new['main_merge_eligible'] is False and new['release_ready'] is False
assert new['parallel_followup_cycle4']['consumed_into']['source'] == BASE
assert new['parallel_followup_cycle4']['consumed_into']['target'] == 'PR349'
assert 'Historical' in new['parallel_continuation_837fe']['scope_note']
handoff = git('show', HEAD + ':' + new['current_handoff'])
assert BASE in handoff and new['aggregate_source_tree'] in handoff
assert 'Current Intel + C4 follow-up' in handoff
assert '[no release] [no deploy]' in handoff
assert new['current_handoff'] in tree_paths

result = dict(
    reviewed_head=HEAD, reviewed_tree=EXPECTED_TREE, compared_source=BASE,
    started_at_utc=started, finished_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    observed_head_before=observed_head_before, observed_head_after=git('rev-parse', 'HEAD').strip(),
    dirty_before=dirty_before, dirty_after=git('status', '--porcelain'),
    scope='Only inserted/new non-evidence Markdown and ledger changes between frozen commits; no tests, remote operations or candidate edits.',
    historical_markdown=histories, local_markdown_links=links,
    ledger=dict(original_task_count=93, current_task_count=97, unique_ids=97,
                original_id_order_preserved=True, changed_original_tasks=task_changes,
                unchanged_original_tasks=93-len(task_changes), c4_three_original_tasks_exact=True,
                changed_values_preserved_in_history=True,
                previous_top_level_checkpoint_preserved=not history_mismatches,
                predecessor_history_mismatches=history_mismatches,
                new_ids=[t['id'] for t in new['tasks'][93:]],
                current_branch_code_handoff_consistent=True,
                main_merge_eligible=False, release_ready=False),
    issues=issues, passed=not issues,
)
OUT.mkdir(parents=True, exist_ok=True)
(OUT/'checks.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(dict(passed=result['passed'], markdown_files=len(histories),
                     existing_markdown_files=sum(x['existed_before'] for x in histories),
                     new_local_links=len(links), issues=issues,
                     original_tasks=93, unchanged_original_tasks=93-len(task_changes),
                     modified_original_tasks=len(task_changes), new_tasks=4,
                     head_stable=result['observed_head_before']==result['observed_head_after']==HEAD,
                     clean=result['dirty_before']==result['dirty_after']==''), indent=2))
