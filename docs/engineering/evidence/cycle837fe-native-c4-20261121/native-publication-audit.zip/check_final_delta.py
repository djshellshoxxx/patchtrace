from __future__ import annotations

import datetime
import hashlib
import io
import json
import subprocess
import zipfile
from pathlib import Path

REPO = Path('/workspace/scratch/837fe19aae3a/PatchTrace-native-followup')
OUT = Path('/workspace/scratch/837fe19aae3a/evidence/native-publication-audit')
INITIAL = '717027dec2f3d4b1c6ee67c0c663f6505f7bf34a'
FINAL = '5435d9cdb7daf272156916dd32034d103fa8988c'
FINAL_TREE = '754a90a94ed60cda2293c3c332e5778cda65c0a2'
CODE = '6bf79feffe68a9fdc1293a69900320e12be662bc'
EVIDENCE = 'docs/engineering/evidence/cycle837fe-native-c4-20261121/'
ADDITION = 'docs/engineering/evidence/cycle4-parent-final-audit-20261121/'
LEDGER = 'docs/engineering/task-ledger.json'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def obj(commit, path):
    return json.loads(git('show', commit + ':' + path))


assert git('rev-parse', FINAL + '^{tree}').decode().strip() == FINAL_TREE
paths = git('diff', '--name-only', INITIAL, FINAL).decode().splitlines()
assert set(paths) == {LEDGER, ADDITION + 'audit-evidence.zip', ADDITION + 'manifest.json', ADDITION + 'review.md'}
assert git('diff', '--name-only', CODE, FINAL, '--', 'src', 'tests', 'tools', '.github', 'docs/specs', 'site') == b''
assert git('diff', '--name-only', INITIAL, FINAL, '--', EVIDENCE) == b''
prior = obj(CODE, LEDGER)
initial = obj(INITIAL, LEDGER)
final = obj(FINAL, LEDGER)
original = prior['combined_followup_837fe']
assert initial['continuation_history'][-1]['record']['combined_followup_837fe'] != original
expected = json.loads(json.dumps(initial))
expected['continuation_history'][-1]['record']['combined_followup_837fe'] = original
assert final == expected, 'Correction changed another ledger field'
assert final['continuation_history'][-1]['record']['combined_followup_837fe']['code_commit'] == '2a67980cfeb88ad72bf8ad523d2bafc8426e5b7c'
assert final['continuation_history'][-1]['record']['combined_followup_837fe']['qualification']['distinct_affected_passed'] == 1296
assert final['combined_followup_837fe']['code_commit'] == CODE
assert final['combined_followup_837fe']['qualification']['distinct_affected_passed'] == 1396

manifest = obj(FINAL, ADDITION + 'manifest.json')
assert manifest['audited_local_commit'] == '39a95c549d48eb523e9efdfda394bb9f184e2b16'
assert manifest['audited_tree'] == 'f53e92d6bc128c929295f6baf3c6241081ee6ed2'
assert manifest['source_qualification_unchanged'] == '111803d54cfebc1b779f4832a069904b3ee91a7c'
for entry in manifest['files']:
    value = git('show', FINAL + ':' + ADDITION + entry['path'])
    assert len(value) == entry['bytes'] and hashlib.sha256(value).hexdigest() == entry['sha256']
payload = git('show', FINAL + ':' + ADDITION + 'audit-evidence.zip')
with zipfile.ZipFile(io.BytesIO(payload)) as archive:
    assert archive.testzip() is None
    names = archive.namelist()
    assert len(names) == len(set(names)) == 5
    enclosed = json.loads(archive.read('manifest.json'))
    assert set(names) == {'manifest.json'} | {entry['path'] for entry in enclosed['files']}
    for entry in enclosed['files']:
        value = archive.read(entry['path'])
        assert len(value) == entry['bytes'] and hashlib.sha256(value).hexdigest() == entry['sha256']

result = {
    'initial_reviewed_head': INITIAL, 'final_reviewed_head': FINAL, 'final_reviewed_tree': FINAL_TREE,
    'tested_code': CODE, 'changed_paths_since_initial': paths, 'all_original_45_payloads_unchanged': True,
    'source_tests_workflows_tools_specs_site_unchanged': True,
    'finding': {'id': 'N-PUB-H1', 'status': 'CLOSED', 'initial_failure': 'The archived daee-stage combined_followup_837fe had shared-object updates from the current stage.',
                'repair_commit': FINAL, 'exact_repair': 'Only the archived object was restored from tested combined-code ledger; every other ledger value equals the initial audited document.',
                'preserved_historical_code': original['code_commit'], 'preserved_historical_passes': 1296,
                'current_code': CODE, 'current_passes': 1396},
    'additional_c4_audit': {'files': 3, 'archive_members': 5, 'enclosed_hashes_verified': 4,
                            'archive_sha256': hashlib.sha256(payload).hexdigest(), 'metadata_bound_to_original_c4_source': True},
    'remaining_blocking_findings': [], 'recorded_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'current_worktree_head': git('rev-parse', 'HEAD').decode().strip(),
    'current_worktree_status': git('status', '--porcelain').decode().strip(),
    'candidate_mutation': False, 'test_execution': False, 'remote_mutation': False,
}
(OUT / 'final-delta-checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
