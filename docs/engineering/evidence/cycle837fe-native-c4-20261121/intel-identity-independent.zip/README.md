# Independent review: Windows identity for Intel tools

## Verdict and exact source

**No blocking code or specification finding.** The repair is ready for guarded publication and a fresh native Windows acceptance run.

- Reviewed head: `d628749401f61d3653b5e066ff38245b938c5dcd`
- Reviewed tree: `5d4f2d3beff122b352d0d62a15ea0800c578c0b9`
- Published baseline: `daee337c48c63dda8aeac149c407e900c79dcc86`
- Independent checkout: `/workspace/scratch/837fe19aae3a/review-intel-windows-identity`
- Checkout clean before and after verification; no candidate edits or remote mutations.

The four-file diff changes only the Intel T4 specification, the Windows addition in `process.tool_env`, one existing expectation in the runner test, and a dedicated maintained environment regression file. Source snapshots, Git blob identities and hashes are retained in `source/`, `source-identity.json` and `candidate.diff`.

## Standards

**0 findings.** The small production change remains in the existing process helper, outside UI code. It introduces no new application module, data schema, execution route, inherited environment policy or native subprocess behavior. The existing runner test replaces its former absent-USERNAME expectation with exact equality to the fixed synthetic value; it still rejects the parent identity. Whole-repository Ruff and `git diff --check` pass. Relevant `AGENTS.md` and module/spec contracts were reviewed. Tests and this report explicitly preserve the distinction between controlled checks and native compatibility.

## Spec

**0 findings.** T4 now documents the exact fixed Windows value `USERNAME=patchtrace`, no inheritance of any caller identity, no override through configured extras, Intel-only scope, and unchanged POSIX/shared BinDiff/Rizin behavior. The implementation matches that contract. The shared environment builder, backend environment policy, all three adapters and the job runner retain their baseline Git blobs.

The one added Windows key reaches both `process.run_version_probe` and `runner.run_job` because both use the actual `process.tool_env`. The default OS-selection branch, explicit platform override, private home/temp/application paths, SystemRoot/SystemDrive/windir handling, PATH construction, Java additions and platform-specific DIE library addition remain intact. Explicit extras still reject identity names and invalid values.

## Independent controls

The reviewer used a separate source-bound environment and authored a fresh control harness in `independent_controls.py`. This harness imports the reviewed repository source, uses the real stdlib `getpass.getuser`, and simulates an unavailable `pwd` module by intercepting only that import.

| Control | Observed result |
| --- | --- |
| Published baseline helper output, unavailable `pwd` | `ModuleNotFoundError: No module named 'pwd'`; one `pwd` import attempt |
| Candidate helper output, unavailable `pwd` | `patchtrace`; zero `pwd` import attempts |
| Baseline output plus fixed synthetic identity | `patchtrace`; zero `pwd` import attempts |
| Candidate output with identity removed | Original missing-`pwd` failure reproduced |
| All case combinations of LOGNAME, USER, LNAME and USERNAME | All **432** variants excluded as caller identities |
| Explicit extras | **894** rejected cases covering identity variants, protected keys and empty/NUL/CR/LF values on both platforms |
| Configured additions | Java/Ghidra and DIE additions preserved; DIE library path present only on the actual POSIX adapter route |
| Missing SystemRoot | Still rejected; windir fallback still works |
| Actual adapter call paths with injected authored fake runners | **24** calls: version, help and analysis for capa vivisect, capa Ghidra, FLOSS and DIE, on POSIX and simulated Windows branches |
| Private scratch | Directory layout, read-only non-executable artifact copy and post-call cleanup verified |
| Nonzero analysis result | Fake exit 7 remains a failed `PT-TOOL-RUN` result |

The fake-runner checks use inert authored tool placeholders and inert input bytes; no upstream executable or analyzed target runs. They check actual probe/helper/job/execute calls and environment handoff, not the operating system's native Windows process implementation. The independent controls retained synthetic identity and secret markers only; the real caller environment was not copied into evidence.

## Maintained checks

The independent seven-file selection reports **130 passed in 7.64 seconds**, no failures and no skips. It includes environment, shared engine environment, runner, audit, subprocess security, version-name admission and probe diagnostic tests. Exact argv, cwd, source head/tree, timestamps and log hashes are retained in `maintained-tests.json`; full output is in `maintained-tests.log`.

The log's `LIVE ACCEPTANCE BLOCKED` banner is expected output from an intentionally unsupported controlled observer test. It is not a native run or a hidden failure of the selected tests.

Whole-repository Ruff, `pip check`, isolated source binding and diff whitespace validation all pass. No full suite was run. These counts are this reviewer's independently executed selection; they should not be added to the author's overlapping counts.

## Prior native evidence and remaining acceptance

Read-only review of the retained actual Windows artifact from workflow `44876415860`, published head `daee337c48c63dda8aeac149c407e900c79dcc86`, confirms that both FLOSS probes exited 1 with complete stderr identifying `vivisect.defconfig -> getpass.getuser -> ModuleNotFoundError: pwd`. Those exact JSON bytes are copied in `native-prior/`.

Capa's actual version and help probes returned 0; analysis subsequently failed with a generic `ModuleNotFoundError`. The available capa evidence does not identify the missing module, so a shared getpass cause remains an inference.

The original native evidence bundle SHA-256 is `c5e4718313eb99fdca0da7739978097d30be65468173f533831132de9e3e0430`. Its advisory successful workflow conclusion is not Windows acceptance: that run had two failed, one passed and one skipped Windows checks.

This review establishes the scoped implementation and controlled fallback mechanism. **Fresh exact-published-head Windows probes and analysis, plus all applicable CI, remain required before merge/release acceptance.**

## Evidence map

- `review-report.json`: machine-readable findings, outcomes and limits.
- `source-identity.json`, `candidate.diff`, `source/`, `baseline-process.py`: exact source evidence.
- `baseline-controls.json`, `candidate-controls.json`, `control-execution.json`: independent controls and source bindings.
- `independent_controls.py`: complete reproducible control harness.
- `stdlib-getuser.json`: reviewer-host stdlib source, qualified separately from each native tool's bundled Python.
- `run_verification.py`, `*-tests.*`, `whole-ruff.*`, `pip-check.*`, `source-binding.*`: maintained command receipts and logs.
- `native-prior/`: byte-preserved prior Windows diagnostics.
- `manifest.json`: relative names, byte sizes and SHA-256 checksums, excluding itself and the final bundle.
