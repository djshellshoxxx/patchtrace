"""Independent source-bound controls; no upstream tool or analyzed target is executed."""
from __future__ import annotations

import argparse
import builtins
import getpass
import hashlib
import importlib
import itertools
import json
import os
import stat
import sys
import tempfile
import threading
from pathlib import Path
from unittest.mock import patch

parser = argparse.ArgumentParser()
parser.add_argument('--checkout', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--baseline', action='store_true')
args = parser.parse_args()
checkout = args.checkout.resolve()
sys.path.insert(0, str(checkout / 'src'))
from patchtrace.intelligence.tools import capa, diec, floss, process, runner
from patchtrace.intelligence.tools.common import ToolError
from patchtrace.jobs import ProcessResult

shared = importlib.import_module('patchtrace.secondary.engine_env')
assert Path(process.__file__).resolve().is_relative_to(checkout)


def variants(text):
    return {''.join(chars) for chars in itertools.product(*[(c.lower(), c.upper()) for c in text])}


identity_keys = set().union(*(variants(name) for name in ('LOGNAME', 'USER', 'LNAME', 'USERNAME')))
identities = {key: 'caller-identity-' + key for key in identity_keys}
secrets = {
    'AWS_SECRET_ACCESS_KEY': 'synthetic-secret-marker',
    'https_proxy': 'synthetic-proxy-marker',
    'PYTHONPATH': 'synthetic-python-marker',
    'PYTHONHOME': 'synthetic-pythonhome-marker',
    'CAPA_SAVE_WORKSPACE': 'synthetic-capa-marker',
    'FLOSS_SAVE_WORKSPACE': 'synthetic-floss-marker',
    'HOMEDRIVE': 'synthetic-drive-marker',
    'HOMEPATH': 'synthetic-home-marker',
    'PATH': 'synthetic-parent-path-marker',
}
parent = {'sYsTeMrOoT': r'C:\Windows', 'sYsTeMdRiVe': 'C:', **identities, **secrets}
receipt = {
    'checkout': str(checkout),
    'interpreter': sys.executable,
    'process_source': process.__file__,
    'process_sha256': hashlib.sha256(Path(process.__file__).read_bytes()).hexdigest(),
    'baseline': args.baseline,
    'host_os': os.name,
    'qualification': 'Controlled Linux mechanism and authored fake-runner checks; not native Windows acceptance.',
    'identity_case_variants': len(identity_keys),
    'getpass': {},
    'call_paths': [],
}


def getuser_outcome(env):
    imports = []
    original_import = builtins.__import__

    def without_pwd(name, *a, **kw):
        if name == 'pwd':
            imports.append(name)
            raise ModuleNotFoundError("No module named 'pwd'", name='pwd')
        return original_import(name, *a, **kw)

    with patch.object(os, 'environ', dict(env)), patch.object(builtins, '__import__', without_pwd):
        try:
            outcome = {'value': getpass.getuser()}
        except ModuleNotFoundError as exc:
            outcome = {'error': type(exc).__name__, 'message': str(exc), 'module': exc.name}
    outcome['pwd_import_attempts'] = len(imports)
    return outcome


def assert_private(env, exe, scratch, windows, extra=None):
    extra = extra or {}
    relevant = {key.upper(): value for key, value in env.items() if key.upper() in
                {'LOGNAME', 'USER', 'LNAME', 'USERNAME'}}
    assert relevant == ({'USERNAME': 'patchtrace'} if windows and not args.baseline else {})
    serialized = json.dumps(env)
    assert not any(value in serialized for value in identities.values())
    assert not any(value in serialized for value in secrets.values())
    expected = shared.engine_env(parent, 'bindiff', windows=windows, executable=exe, workdir=scratch)
    if windows and not args.baseline:
        expected['USERNAME'] = 'patchtrace'
    expected.update(extra)
    if extra.get('JAVA_HOME'):
        expected['PATH'] = str(Path(extra['JAVA_HOME']) / 'bin') + (';' if windows else ':') + expected['PATH']
    assert env == expected
    return True


class OsView:
    """Select only the code's platform branches while keeping host filesystem operations intact."""
    def __init__(self, windows):
        self.name = 'nt' if windows else 'posix'
        self.environ = parent.copy()

    def __getattr__(self, key):
        return getattr(os, key)


with tempfile.TemporaryDirectory(prefix='identity-review-') as temp:
    root = Path(temp)
    exe, scratch = root / 'bin' / 'tool.exe', root / 'scratch'
    windows_env = process.tool_env(exe, scratch, environ=parent, windows=True)
    assert_private(windows_env, exe, scratch, True)
    native_mechanism = getuser_outcome(windows_env)
    receipt['getpass']['actual_helper_output'] = native_mechanism
    if args.baseline:
        assert native_mechanism == {'error': 'ModuleNotFoundError', 'message': "No module named 'pwd'",
                                    'module': 'pwd', 'pwd_import_attempts': 1}
    else:
        assert native_mechanism == {'value': 'patchtrace', 'pwd_import_attempts': 0}

    # A positive control plus an omission control establish that the blocker is causally exercised.
    positive = {**windows_env, 'USERNAME': 'patchtrace'}
    negative = {key: value for key, value in windows_env.items() if key.upper() != 'USERNAME'}
    receipt['getpass']['fixed_identity_control'] = getuser_outcome(positive)
    receipt['getpass']['identity_removed_control'] = getuser_outcome(negative)
    assert receipt['getpass']['fixed_identity_control'] == {'value': 'patchtrace', 'pwd_import_attempts': 0}
    assert receipt['getpass']['identity_removed_control']['module'] == 'pwd'
    assert receipt['getpass']['identity_removed_control']['pwd_import_attempts'] == 1
    receipt['privacy'] = {'all_identity_variants_excluded': True, 'synthetic_secret_values_excluded': True}

    if not args.baseline:
        rejected = 0
        for windows in (False, True):
            env = process.tool_env(exe, scratch, environ=parent, windows=windows)
            assert_private(env, exe, scratch, windows)
            view = OsView(windows)
            with patch.object(process, 'os', view), patch.object(shared, 'os', view):
                default_env = process.tool_env(exe, scratch)
            assert default_env == env
            additions = {'JAVA_HOME': str(root / 'java'), 'GHIDRA_INSTALL_DIR': str(root / 'ghidra'),
                         'LD_LIBRARY_PATH': str(root / 'die-libs')}
            assert_private(process.tool_env(exe, scratch, environ=parent, windows=windows, extra=additions),
                           exe, scratch, windows, additions)
            for key in sorted(identity_keys | {'PATH', 'SystemRoot', 'AWS_SECRET_ACCESS_KEY'}):
                try:
                    process.tool_env(exe, scratch, environ=parent, windows=windows, extra={key: 'override'})
                except ToolError as exc:
                    assert exc.code == 'PT-TOOL-INPUT'
                    rejected += 1
                else:
                    raise AssertionError(f'Unexpected extra admitted: {key}')
            for key in process.EXTRA_ENV:
                for value in ('', 'value\0tail', 'value\rtail', 'value\ntail'):
                    try:
                        process.tool_env(exe, scratch, environ=parent, windows=windows, extra={key: value})
                    except ToolError as exc:
                        assert exc.code == 'PT-TOOL-INPUT'
                        rejected += 1
                    else:
                        raise AssertionError('Invalid configured value admitted')
        receipt['extra_validation'] = {'rejected_cases': rejected, 'configured_additions_preserved': True}
        try:
            process.tool_env(exe, scratch, environ=identities, windows=True)
        except OSError as exc:
            assert 'SystemRoot is not set' in str(exc)
            receipt['required_systemroot'] = 'rejected when missing'
        else:
            raise AssertionError('Missing SystemRoot was admitted')
        fallback = process.tool_env(exe, scratch, environ={'wInDiR': r'C:\Windows', **identities}, windows=True)
        assert fallback['SystemRoot'] == fallback['windir'] == r'C:\Windows'
        assert fallback['USERNAME'] == 'patchtrace'
        receipt['windir_fallback'] = True

        fixture_names = {
            'capa': ('capa/version.stdout.txt', 'capa/help.stdout.txt'),
            'floss': ('floss/version.stdout.txt', 'floss/help-advanced.stdout.txt'),
            'diec': ('diec/version.stdout.txt', 'diec/help.stdout.txt'),
        }
        artifact_path = root / 'inert-input.bin'
        artifact_path.write_bytes(b'Authored inert data for call-path checks; never executable.\n')
        artifact = runner.ArtifactRef('older', artifact_path, process.sha256_file(artifact_path),
                                      artifact_path.stat().st_size)
        db = root / 'authored-db'
        db.mkdir()
        (db / 'stub.txt').write_text('authored inert database marker')
        ghidra = root / 'configured-ghidra'
        (ghidra / 'Ghidra').mkdir(parents=True)
        (ghidra / 'Ghidra' / 'application.properties').write_text('application.version=12.0\n')
        java = root / 'configured-java'
        (java / 'bin').mkdir(parents=True)
        for name in ('java', 'java.exe'):
            (java / 'bin' / name).write_bytes(b'Authored inert Java placeholder; never executed.')
        library = root / 'configured-die-libraries'
        library.mkdir()
        for windows in (False, True):
            view = OsView(windows)
            for label in ('capa', 'capa-ghidra', 'floss', 'diec'):
                engine = label.split('-')[0]
                tool = root / f'{label}-authored-placeholder.exe'
                tool.write_bytes(b'Authored inert tool placeholder; only an injected Python runner is called.')
                module = {'capa': capa, 'floss': floss, 'diec': diec}[engine]
                if label == 'capa-ghidra':
                    config = capa.CapaConfig(tool, backend='ghidra', ghidra_dir=ghidra, java_home=java,
                                             accept_untested=True)
                elif engine == 'capa':
                    config = capa.CapaConfig(tool, accept_untested=True)
                elif engine == 'floss':
                    config = floss.FlossConfig(tool, accept_untested=True)
                else:
                    config = diec.DiecConfig(tool, database=db, library_path=library, accept_untested=True)
                calls = []

                def fake_runner(argv, **kwargs):
                    phase = 'version' if argv[1:] == ['--version'] else (
                        'help' if argv[1:] in (['--help'], ['-H']) else 'analysis')
                    child_scratch = Path(kwargs['cwd']).parent
                    expected_extra = {}
                    if label == 'capa-ghidra' and phase == 'analysis':
                        expected_extra = {'GHIDRA_INSTALL_DIR': str(ghidra), 'JAVA_HOME': str(java)}
                    if engine == 'diec' and not windows:
                        expected_extra = {'LD_LIBRARY_PATH': str(library)}
                    assert_private(kwargs['env'], tool, child_scratch, windows, expected_extra)
                    if windows:
                        assert getuser_outcome(kwargs['env']) == {'value': 'patchtrace', 'pwd_import_attempts': 0}
                    assert kwargs['separate_streams'] is True
                    assert kwargs['max_output_bytes'] > 0 and kwargs['stderr_limit'] > 0
                    assert kwargs['timeout_seconds'] > 0
                    for parts in process.PRIVATE_DIRS:
                        assert child_scratch.joinpath(*parts).is_dir()
                    if phase == 'analysis':
                        copied = Path(argv[-1])
                        assert copied == child_scratch / 'in' / 'artifact.bin'
                        assert copied.read_bytes() == artifact_path.read_bytes()
                        assert not copied.stat().st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH |
                                                           stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
                        assert kwargs['memory_limit_bytes'] == 512 * 1024 * 1024
                        result = ProcessResult(7, '', stderr_tail='authored fake runner reached analysis')
                    else:
                        name = fixture_names[engine][0 if phase == 'version' else 1]
                        raw = (checkout / 'tests' / 'fixtures' / 'intel_tools' / name).read_bytes()
                        result = ProcessResult(0, raw.decode(), log_bytes=raw, stdout_total=len(raw))
                    calls.append({'phase': phase, 'scratch': str(child_scratch),
                                  'identity': kwargs['env'].get('USERNAME'),
                                  'extra_keys': sorted(expected_extra), 'private_paths_exist': True})
                    return result

                with patch.object(process, 'os', view), patch.object(shared, 'os', view), \
                        patch.object(capa, 'os', view), patch.object(diec, 'os', view):
                    manifest = module.probe(config, runner=fake_runner, environ=parent, use_cache=False)
                    assert manifest.supported, manifest.reason
                    req = runner.RunRequest((artifact,), runner.Setup(**{engine: config}),
                                             profile='full', engines=(engine,), use_cache=False,
                                             memory_limit_bytes=512 * 1024 * 1024)
                    result = runner.run_job(engine, artifact, manifest, req, threading.Event(),
                                             fake_runner, root)
                    assert (result.run.status, result.run.error_code, result.run.returncode) == (
                        'failed', 'PT-TOOL-RUN', 7), result.run
                assert [call['phase'] for call in calls] == ['version', 'help', 'analysis']
                assert all(not Path(call['scratch']).exists() for call in calls)
                receipt['call_paths'].append({'label': label, 'windows_simulated': windows,
                                               'calls': calls, 'scratch_cleanup_verified': True,
                                               'fake_exit_preserved': 7})

receipt['all_assertions_passed'] = True
args.output.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'output': str(args.output), 'baseline': args.baseline,
                  'getpass': receipt['getpass'], 'case_variants': len(identity_keys),
                  'call_path_groups': len(receipt['call_paths']), 'all_assertions_passed': True}, indent=2))
