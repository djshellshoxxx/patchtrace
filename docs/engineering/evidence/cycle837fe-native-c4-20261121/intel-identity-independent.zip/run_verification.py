"""Retain exact commands, source bindings and logs for the bounded independent selection."""
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/workspace/scratch/837fe19aae3a')
checkout = root / 'review-intel-windows-identity'
evidence = root / 'evidence/intel-windows-identity-independent'
python = str(root / 'review-intel-windows-identity-venv/bin/python')
selected = ['tests/test_intel_tools_environment.py', 'tests/test_engine_env.py',
            'tests/test_intel_tools_runner.py', 'tests/test_intel_tools_audit.py',
            'tests/test_security_subprocess.py', 'tests/test_intel_tool_version_names.py',
            'tests/test_intel_probe_diagnostics.py']
checks = {
    'maintained-tests': [python, '-m', 'pytest', '-q', *selected],
    'whole-ruff': [python, '-m', 'ruff', 'check', 'src', 'tests', 'tools'],
    'pip-check': [python, '-m', 'pip', 'check'],
    'source-binding': [python, '-I', '-c',
                       'import json,sys,patchtrace; from patchtrace.intelligence.tools import process; '
                       'print(json.dumps({"python":sys.executable,"package":patchtrace.__file__, '
                       '"process":process.__file__}))'],
}
environment = dict(os.environ)
environment['QT_QPA_PLATFORM'] = 'offscreen'
environment['PYTHONPATH'] = str(checkout / 'src')


def run(item):
    name, argv = item
    start = datetime.now(UTC).isoformat()
    outcome = subprocess.run(argv, cwd=checkout, env=environment, capture_output=True)
    log = outcome.stdout + outcome.stderr
    (evidence / f'{name}.log').write_bytes(log)
    receipt = {
        'argv': argv, 'cwd': str(checkout), 'started_utc': start,
        'finished_utc': datetime.now(UTC).isoformat(), 'returncode': outcome.returncode,
        'pythonpath': environment['PYTHONPATH'], 'qt_qpa_platform': 'offscreen',
        'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=checkout, text=True).strip(),
        'tree': subprocess.check_output(['git', 'rev-parse', 'HEAD^{tree}'], cwd=checkout, text=True).strip(),
        'log_sha256': hashlib.sha256(log).hexdigest(),
    }
    (evidence / f'{name}.json').write_text(json.dumps(receipt, indent=2) + '\n')
    return {'check': name, 'returncode': outcome.returncode, 'tail': log.decode(errors='replace')[-2000:]}


with ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(run, checks.items()))
print(json.dumps(results, indent=2))
raise SystemExit(any(result['returncode'] for result in results))
