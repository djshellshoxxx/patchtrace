"""Read-only, exact-tree composition check for reviewed C4 plus reviewed Intel identity repair."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess

C4_REPO = Path('/workspace/scratch/patchtrace-95fe-c4/coordinator')
INTEL_REPO = Path('/workspace/scratch/837fe19aae3a/PatchTrace-combined')
BASE = 'daee337c48c63dda8aeac149c407e900c79dcc86'
C4 = '39a95c549d48eb523e9efdfda394bb9f184e2b16'
INTEL = 'd628749401f61d3653b5e066ff38245b938c5dcd'

parser = argparse.ArgumentParser()
parser.add_argument('--checkout', type=Path, required=True)
parser.add_argument('--head', required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--published-c4')
args = parser.parse_args()


def git(repo, *argv):
    return subprocess.check_output(['git', *argv], cwd=repo)


def tree(repo, ref):
    rows = {}
    for entry in git(repo, 'ls-tree', '-r', '-z', ref).split(b'\0'):
        if not entry:
            continue
        fields, path = entry.split(b'\t', 1)
        mode, kind, oid = fields.decode().split()
        rows[path.decode()] = {'mode': mode, 'kind': kind, 'oid': oid}
    return rows


def digest_map(data):
    return hashlib.sha256(json.dumps(data, sort_keys=True, separators=(',', ':')).encode()).hexdigest()


base, c4, intel = tree(C4_REPO, BASE), tree(C4_REPO, C4), tree(INTEL_REPO, INTEL)
candidate = tree(args.checkout, args.head)
intel_delta = sorted(path for path in set(base) | set(intel) if base.get(path) != intel.get(path))
c4_delta = sorted(path for path in set(base) | set(c4) if base.get(path) != c4.get(path))
assert not set(intel_delta) & set(c4_delta)
assert len(intel_delta) == 4
expected = dict(c4)
for path in intel_delta:
    if path in intel:
        expected[path] = intel[path]
    else:
        expected.pop(path, None)
missing = sorted(set(expected) - set(candidate))
extra = sorted(set(candidate) - set(expected))
different = sorted(path for path in set(candidate) & set(expected) if candidate[path] != expected[path])
head_now = git(args.checkout, 'rev-parse', 'HEAD').decode().strip()
status = git(args.checkout, 'status', '--porcelain').decode()
pages = '.github/workflows/pages.yml'
evidence_paths = [path for path in c4 if path.startswith('docs/engineering/evidence/')]
checks = {
    'head_matches_requested': head_now == args.head,
    'clean_worktree': status == '',
    'entire_expected_tree_matches': not (missing or extra or different),
    'all_c4_files_except_intel_delta_preserved': all(candidate.get(path) == item for path, item in c4.items()
                                                   if path not in intel_delta),
    'four_intel_delta_blobs_and_modes_exact': all(candidate.get(path) == intel.get(path) for path in intel_delta),
    'all_c4_workflows_exact': all(candidate.get(path) == item for path, item in c4.items()
                                  if path.startswith('.github/workflows/')),
    'all_c4_tests_except_intel_delta_exact': all(candidate.get(path) == item for path, item in c4.items()
                                               if path.startswith('tests/') and path not in intel_delta),
    'pages_workflow_exact': candidate.get(pages) == c4[pages],
    'pages_lock_exact': candidate.get('tools/site/requirements-ci.lock') == c4['tools/site/requirements-ci.lock'],
    'original_evidence_blobs_and_modes_exact': all(candidate.get(path) == c4[path] for path in evidence_paths),
    'c4_worktree_unchanged_and_clean': not git(C4_REPO, 'status', '--porcelain').decode(),
}
publication = None
if args.published_c4:
    published_tree = git(args.checkout, 'rev-parse', args.published_c4 + '^{tree}').decode().strip()
    local_c4_tree = git(C4_REPO, 'rev-parse', C4 + '^{tree}').decode().strip()
    checks['published_c4_is_tree_identical'] = published_tree == local_c4_tree
    publication = {'head': args.published_c4, 'tree': published_tree}
report = {
    'base': BASE, 'c4_local': C4, 'c4_tree': git(C4_REPO, 'rev-parse', C4 + '^{tree}').decode().strip(),
    'c4_publication': publication, 'intel': INTEL,
    'candidate': args.head, 'candidate_tree': git(args.checkout, 'rev-parse', args.head + '^{tree}').decode().strip(),
    'checkout': str(args.checkout), 'checks': checks,
    'c4_delta_paths': c4_delta, 'intel_delta_paths': intel_delta,
    'candidate_file_count': len(candidate), 'c4_evidence_file_count': len(evidence_paths),
    'expected_map_sha256': digest_map(expected), 'candidate_map_sha256': digest_map(candidate),
    'missing_paths': missing, 'extra_paths': extra,
    'different_paths': [{'path': path, 'expected': expected[path], 'actual': candidate[path]} for path in different],
    'workflow_dispatch_performed': False,
    'pages_boundary': 'Exact preserved workflow has no PR trigger. Its manual dispatch retains deployment behavior and was not invoked.',
    'all_checks_passed': all(checks.values()),
}
args.output.write_text(json.dumps(report, indent=2) + '\n')
args.output.with_name('expected-tree-map.json').write_text(json.dumps(expected, indent=2, sort_keys=True) + '\n')
args.output.with_name('candidate-tree-map.json').write_text(json.dumps(candidate, indent=2, sort_keys=True) + '\n')
print(json.dumps({'candidate': args.head, 'tree': report['candidate_tree'], 'checks': checks,
                  'missing': missing, 'extra': extra, 'different': different}, indent=2))
raise SystemExit(not report['all_checks_passed'])
