"""Bounded integration checks; no workflow dispatch, upstream tool, target execution or full suite."""
from concurrent.futures import ThreadPoolExecutor
from datetime import UTC, datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/workspace/scratch/837fe19aae3a')
checkout = root / 'review-native-c4'
evidence = root / 'evidence/native-c4-independent'
python = str(root / 'review-native-c4-venv/bin/python')
head = '6bf79feffe68a9fdc1293a69900320e12be662bc'
harness = root / 'evidence/intel-windows-identity-independent/independent_controls.py'
copied = evidence / 'identity_controls.py'
copied.write_bytes(harness.read_bytes())
tests = [
    'tests/test_intel_tools_environment.py',
    'tests/test_intel_tools_runner.py::test_windows_environment_layout_is_private_and_semicolon_separated',
    'tests/test_tooltips.py::test_every_registry_id_is_applied_somewhere',
    'tests/test_site_workflow.py',
    'tests/test_site_dependency_lock.py',
    'tests/test_spec_registry.py',
]
commands = {
    'identity-controls': [python, str(copied), '--checkout', str(checkout),
                          '--output', str(evidence / 'identity-controls-result.json')],
    'integration-tests': [python, '-m', 'pytest', '-q', *tests],
    'source-binding': [python, '-I', '-c',
                       'import json,sys,patchtrace; from patchtrace.intelligence.tools import process; '
                       'print(json.dumps({"python":sys.executable,"package":patchtrace.__file__, '
                       '"process":process.__file__}))'],
    'intel-delta-whitespace': ['git', 'diff', '--check',
                               '39a95c549d48eb523e9efdfda394bb9f184e2b16...' + head],
}
environment = dict(os.environ)
environment['PYTHONPATH'] = str(checkout / 'src')
environment['QT_QPA_PLATFORM'] = 'offscreen'


def git(*argv):
    return subprocess.check_output(['git', *argv], cwd=checkout, text=True).strip()


def run(item):
    name, argv = item
    assert git('rev-parse', 'HEAD') == head
    assert not git('status', '--porcelain')
    start = datetime.now(UTC).isoformat()
    result = subprocess.run(argv, cwd=checkout, env=environment, capture_output=True)
    log = result.stdout + result.stderr
    (evidence / f'{name}.log').write_bytes(log)
    receipt = {
        'argv': argv, 'cwd': str(checkout), 'pythonpath': environment['PYTHONPATH'],
        'qt_qpa_platform': 'offscreen', 'head': head, 'tree': git('rev-parse', 'HEAD^{tree}'),
        'started_utc': start, 'finished_utc': datetime.now(UTC).isoformat(),
        'returncode': result.returncode, 'log_sha256': hashlib.sha256(log).hexdigest(),
        'clean_after': not git('status', '--porcelain'),
    }
    (evidence / f'{name}.json').write_text(json.dumps(receipt, indent=2) + '\n')
    return {'name': name, 'returncode': result.returncode, 'tail': log.decode(errors='replace')[-3000:]}


with ThreadPoolExecutor(max_workers=4) as pool:
    results = list(pool.map(run, commands.items()))
print(json.dumps(results, indent=2))
raise SystemExit(any(result['returncode'] for result in results))
