# Windows Intel synthetic identity repair

Author head: `d628749401f61d3653b5e066ff38245b938c5dcd`  
Parent: `daee337c48c63dda8aeac149c407e900c79dcc86`  
Tree: `5d4f2d3beff122b352d0d62a15ea0800c578c0b9`

## Change

Intel `process.tool_env` adds fixed `USERNAME=patchtrace` on Windows. The T4 environment specification was updated before implementation. No caller identity is inherited; extra configuration cannot override the identity. Shared BinDiff/Rizin and POSIX environment policies, private paths, required Windows system roots, configured Java/DIE additions, tool admission and resource limits remain unchanged.

Exactly four files changed: the T4 specification, Intel process module, a dedicated maintained environment regression module, and the pre-existing runner test's username expectation. No new runtime dependency or schema change.

## Verification

- Retained baseline: the maintained regression called real Python `getpass.getuser()` using the actual published-source child environment and a controlled unavailable-`pwd` import. It failed with `ModuleNotFoundError: No module named 'pwd'` (one expected failure). The receipt confirms production `process.py` was byte-equal to the exact published baseline during this run.
- Fixed code: 130 focused maintained tests passed in 8.28 seconds. Coverage includes environment/getpass, private identity/path and inheritance boundaries, configured and refused extras, required SystemRoot, shared environments, authored runner orchestration, tool auditing, literal subprocess arguments, version admission, and bounded diagnostic observation.
- Whole-repository Ruff (`src tests tools`), `pip check`, and exact worktree source-binding checks passed. Source SHA-256 values were stable during verification and match the committed files.
- `git diff --check` passed. The worktree is clean. No full suite was run, per assigned scope.

The focused test log contains a deliberately unsupported controlled probe's `LIVE ACCEPTANCE BLOCKED` banner. It belongs to a passing maintained observer test; it is not a new native tool observation.

## Remaining native gate

The earlier actual Intel run 44876415860 remains retained separately under `../combined-intel-live` at the exact published daee source. Its Linux result was 4 passed; Windows was 2 failed, 1 passed, 1 skipped. Native FLOSS stderr directly identified getpass falling through to missing pwd. Capa version/help admission passed, followed by a generic analysis ModuleNotFoundError; a common cause remains inference. This repair requires fresh independent review and a new exact-head native Windows run before native resolution can be claimed.

No upstream executable or analyzed target was run locally. Maintained runner tests use authored fixtures and establish orchestration only. No remote refs, workflows, shared engine policy, or global ledgers were changed.

## Receipt contents

`author-report.json` binds commit, tree, scope and results. Each check has a full `.log` and `.json` command/timing/source receipt. `baseline-getuser` preserves the failing production baseline. `source/` contains exact changed source files from the author commit; `candidate.diff` is the complete base-to-head patch. `manifest.json` lists byte sizes and SHA-256 values of every enclosed file except itself. The ZIP is CRC-checked.
