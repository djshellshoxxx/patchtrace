"""Bounded diagnostic: ordinary local socket operations with no project guard armed."""
from __future__ import annotations

import errno
import json
import platform
import socket
import sys
import tempfile
from pathlib import Path

import network_guard


def run() -> dict:
    record = {
        'python': sys.version,
        'platform': platform.platform(),
        'guard_module': str(Path(network_guard.__file__).resolve()),
        'guard_active_before': network_guard._active is not None,
        'guard_hook_installed_before': network_guard._hook_installed,
        'socket_connect_type': type(socket.socket.connect).__name__,
        'operations': [],
    }
    with tempfile.TemporaryDirectory(prefix='pt-local-socket-') as temporary:
        endpoint = str(Path(temporary) / 's')
        record['path_utf8_bytes'] = len(endpoint.encode('utf-8'))
        stage = 'socket_creation'
        try:
            with socket.socket(socket.AF_UNIX) as server:
                record['operations'].append('AF_UNIX socket created')
                stage = 'bind'
                server.bind(endpoint)
                record['operations'].append('bind succeeded')
                stage = 'listen'
                server.listen(1)
                record['operations'].append('listen succeeded')
                stage = 'client_socket_creation'
                with socket.socket(socket.AF_UNIX) as client:
                    stage = 'connect'
                    client.connect(endpoint)
                    record['operations'].append('connect succeeded')
        except OSError as exc:
            record['exception'] = {
                'type': type(exc).__name__, 'errno': exc.errno,
                'errno_name': errno.errorcode.get(exc.errno), 'strerror': exc.strerror,
                'operation': stage,
            }
        record['socket_path_created'] = Path(endpoint).exists()
    record['guard_active_after'] = network_guard._active is not None
    record['guard_hook_installed_after'] = network_guard._hook_installed
    return record


if __name__ == '__main__':
    print(json.dumps(run(), indent=2, sort_keys=True))
