"""Authored control: a class-wide counter should measure only its selected model."""
from __future__ import annotations

import json
import sys
from pathlib import Path

from PySide6.QtWidgets import QApplication, QTableView

ROOT = Path(__file__).resolve().parents[4]
sys.path.insert(0, str(ROOT / 'tests'))

from qt_support import _paint_counting_data  # noqa: E402
from test_gui_table import prepare  # noqa: E402

from patchtrace.gui.qt.table import VirtualTableModel  # noqa: E402

app = QApplication.instance() or QApplication([])
prepared = prepare(10_000)
observations = []
for with_other in (False, True):
    target = VirtualTableModel()
    target.set_prepared(prepared)
    other = VirtualTableModel()
    other.set_prepared(prepared)
    other_view = QTableView()
    other_view.resize(800, 400)
    other_view.setModel(other)
    if with_other:
        other_view.show()  # The first paint is intentionally pending.
    before = target.data_calls, other.data_calls
    reported, ceiling = _paint_counting_data(target, 8)
    observations.append({
        'other_first_paint_pending': with_other,
        'reported_calls': reported,
        'target_calls': target.data_calls - before[0],
        'other_calls': other.data_calls - before[1],
        'ceiling': ceiling,
    })
    other_view.setModel(None)
    other_view.hide()
    other_view.deleteLater()
    app.processEvents()
print(json.dumps({'observations': observations}, indent=2))
assert all(row['reported_calls'] == row['target_calls'] for row in observations)
