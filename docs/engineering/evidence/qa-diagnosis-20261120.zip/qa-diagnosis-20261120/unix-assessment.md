# Local Unix-socket qualification failure

Reviewed source: `bffcfa99d6a5044024256edbc0457ab20c92cbae`.

## Finding

The focused, unchanged test
`tests/test_network_consent_guard.py::test_a_local_unix_socket_is_not_network`
fails with `PermissionError: [Errno 1] Operation not permitted` **while creating
the first `socket.socket(AF_UNIX)`**. The test has not reached `bind`, `listen`,
or its `with NetworkGuard()` block. The focused result is one failure in
0.50 seconds; its complete log and JUnit are retained.

An authored standalone control then attempted the ordinary operation with no
guard active and no guard audit hook installed. It received the same
`PermissionError`, `EPERM`, during `socket_creation`. No server socket, endpoint
file, connection, or network destination was created. Its proposed temporary
path was 31 UTF-8 bytes, but the operation failed before using that path. Both
guard state flags remained false. The control's exit 0 means its diagnostic
record was written successfully, not that socket creation succeeded.

The evidence therefore establishes an execution-environment restriction before
the project's guard logic runs. It does not establish the enforcement mechanism
or qualify the AF_UNIX behavioral assertion on a supporting runner.

## Source comparison

Both relevant files are byte-identical at current main
`fdc2696c23bdbfe7668348f25e3b336ce33039f7`, PR #322
`f2458aae22ea6177be64cfc2fb439a79950f00ff`, and frozen aggregate source
`bffcfa99d6a5044024256edbc0457ab20c92cbae`:

| File | Git blob at all three commits |
|---|---|
| `tests/network_guard.py` | `f686e57af5a6f431f81ab7ecceab1e846cb6e4fd` |
| `tests/test_network_consent_guard.py` | `e83b23ae12bc53bc24acac8441e0dc3482a29996` |

The guard patches connection, datagram and opener operations; its audit hook
handles listed address/lookup events. The test's socket construction precedes
guard entry. No source repair is indicated by this reproduction.

## Preserved diagnostic correction

The first standalone probe failed before attempting a socket because it tried
to read `__module__` from the built-in `socket.socket.connect` method descriptor.
The initial script and error output are retained. The corrected probe records
the descriptor type and explicitly tracks each operation stage. That harness
mistake is not a product failure or a second socket attempt.

## Disposition

Keep the original aggregate failure and classify this local acceptance check as
blocked by the execution environment. Do not weaken the assertion, replace it
with a claimed pass, or change network/security controls. A separate actual
result from a runner permitting local Unix sockets is needed to qualify the
behavior. No source, tests, dependencies, policies, permissions or repository
configuration were modified in this subtask.

## Commands

```sh
QT_QPA_PLATFORM=offscreen PYTHONPATH=src:tests python -m pytest -q \
  tests/test_network_consent_guard.py::test_a_local_unix_socket_is_not_network \
  --junitxml=docs/engineering/evidence/qa-diagnosis-20261120/unix-focused.xml
PYTHONPATH=src:tests python \
  docs/engineering/evidence/qa-diagnosis-20261120/unix-unguarded-probe.py
```

The dedicated interpreter was
`/workspace/scratch/4c8dc848d760/venv/bin/python`. `unix-manifest.json` records
the exact commands, source identities, observed outcomes and artifact hashes.
