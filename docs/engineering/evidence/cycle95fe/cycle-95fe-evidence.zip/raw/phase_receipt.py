import json, os, time
from pathlib import Path
_stream = None
def _record(event, **fields):
    global _stream
    if _stream is None:
        _stream = Path(os.environ["PATCHTRACE_PHASE_LOG"]).open("a", encoding="utf-8")
    _stream.write(json.dumps({"monotonic": time.monotonic(), "event": event, **fields}, separators=(",", ":")) + "\n")
    _stream.flush()
def pytest_sessionstart(session):
    _record("session-start")
def pytest_runtest_logstart(nodeid, location):
    _record("start", nodeid=nodeid)
def pytest_runtest_logreport(report):
    _record("report", nodeid=report.nodeid, phase=report.when, outcome=report.outcome, duration=report.duration)
def pytest_sessionfinish(session, exitstatus):
    _record("session-finish", exitstatus=int(exitstatus), collected=session.testscollected, failed=session.testsfailed)
