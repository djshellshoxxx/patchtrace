from __future__ import annotations
import json, os, subprocess, sys, time
from datetime import datetime, timezone
from pathlib import Path
label, repo, *command = sys.argv[1:]
dest = Path("/tmp/patchtrace-95fe-evidence")
dest.mkdir(exist_ok=True)
def git(*args):
    return subprocess.check_output(["git", "-C", repo, *args], text=True).strip()
receipt = {"label": label, "command": command, "cwd": repo, "head": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"), "dirty_before": git("status", "--porcelain"), "started_at": datetime.now(timezone.utc).isoformat(), "qt_platform": os.environ.get("QT_QPA_PLATFORM"), "pythonpath": os.environ.get("PYTHONPATH")}
started = time.monotonic()
with (dest / (label + ".log")).open("w", encoding="utf-8") as stream:
    process = subprocess.Popen(command, cwd=repo, stdout=stream, stderr=subprocess.STDOUT)
    receipt["pid"] = process.pid
    print(json.dumps({"label": label, "pid": process.pid, "head": receipt["head"]}), flush=True)
    (dest / (label + ".json")).write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
    rc = process.wait()
receipt.update(returncode=rc, seconds=round(time.monotonic()-started, 3), finished_at=datetime.now(timezone.utc).isoformat(), head_after=git("rev-parse", "HEAD"), dirty_after=git("status", "--porcelain"))
(dest / (label + ".json")).write_text(json.dumps(receipt, indent=2) + "\n", encoding="utf-8")
print(json.dumps(receipt, indent=2))
print((dest / (label + ".log")).read_text(encoding="utf-8", errors="replace")[-12000:])
sys.exit(rc if rc >= 0 else 128-rc)
