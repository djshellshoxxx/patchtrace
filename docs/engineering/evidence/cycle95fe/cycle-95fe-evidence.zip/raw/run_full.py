from __future__ import annotations
import json, os, resource, shutil, subprocess, time
from datetime import datetime, timezone
from pathlib import Path
repo = Path("/tmp/patchtrace-95fe-qualify")
dest = Path("/tmp/patchtrace-95fe-evidence")
python = "/workspace/scratch/8c4bcaaa669f/qualification-venv/bin/python"
def git(*args):
    return subprocess.check_output(["git", "-C", str(repo), *args], text=True).strip()
def utc():
    return datetime.now(timezone.utc).isoformat()
def memory_events():
    p = Path("/sys/fs/cgroup/memory.events")
    return p.read_text().strip() if p.exists() else None
def sample(pid):
    found, queue, seen = [], [pid], set()
    while queue:
        current = queue.pop()
        if current in seen: continue
        seen.add(current)
        try:
            values = {}
            for line in Path(f"/proc/{current}/status").read_text().splitlines():
                name, _, value = line.partition(":")
                if name in ("VmRSS", "VmHWM", "Threads"): values[name] = value.strip()
            found.append({"pid": current, **values})
            queue.extend(int(x) for x in Path(f"/proc/{current}/task/{current}/children").read_text().split())
        except (OSError, ValueError): pass
    return {"at": utc(), "processes": found, "tmp_free_bytes": shutil.disk_usage("/tmp").free, "memory_events": memory_events()}
env = dict(os.environ, QT_QPA_PLATFORM="offscreen", PYTHONPATH=str(repo / "src") + ":" + str(dest), PYTHONDONTWRITEBYTECODE="1", PYTHONFAULTHANDLER="1", PATCHTRACE_PHASE_LOG=str(dest / "full-phases.jsonl"))
command = [python, "-m", "pytest", "-q", "-p", "phase_receipt", "--basetemp=/tmp/patchtrace-95fe-fulltmp", "--junitxml=" + str(dest / "full.xml")]
receipt = {"command": command, "cwd": str(repo), "head": git("rev-parse", "HEAD"), "tree": git("rev-parse", "HEAD^{tree}"), "dirty_before": git("status", "--porcelain"), "started_at": utc(), "memory_events_before": memory_events(), "source_paths": {p: git("rev-parse", "HEAD:" + p) for p in ["src", "tests", "tools", "pyproject.toml"]}}
assert not receipt["dirty_before"], receipt
start = time.monotonic()
with (dest / "full.log").open("w") as log, (dest / "full-resources.jsonl").open("w") as resources:
    proc = subprocess.Popen(command, cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT)
    receipt["pid"] = proc.pid
    (dest / "full.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"state": "running", "pid": proc.pid, "head": receipt["head"]}), flush=True)
    while True:
        resources.write(json.dumps(sample(proc.pid)) + "\n"); resources.flush()
        try:
            code = proc.wait(timeout=5)
            break
        except subprocess.TimeoutExpired: pass
receipt.update(returncode=code, seconds=round(time.monotonic()-start,3), finished_at=utc(), head_after=git("rev-parse", "HEAD"), dirty_after=git("status", "--porcelain"), memory_events_after=memory_events(), children_maxrss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
(dest / "full.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))
print((dest / "full.log").read_text(errors="replace")[-16000:])
raise SystemExit(code if code >= 0 else 128-code)
