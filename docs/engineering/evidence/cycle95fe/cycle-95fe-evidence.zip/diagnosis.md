# Interrupted runner diagnosis

The four captured -9 return codes establish SIGKILL, with sender and cause
unknown. The wrappers do not terminate pytest: run_check.py calls wait() without
a timeout; run_full.py catches repeated five-second wait timeouts, samples
resources, and continues. The observed durations do not support a fixed
30-second wrapper timeout. No final pytest summary/JUnit was produced.

The passing GUI worker and killed combined selection have identical selected GUI
tests, shared fixtures, GUI runtime and Evidence source. Their complete trees
differ and their commands differ in module order, cacheprovider and basetemp.
None of those differences has been shown to cause SIGKILL.

The separate read-only diagnostic review reported no exposed cgroup memory
limit/event records and denied kernel-log access. Post-failure resource values
and a cumulative oom_kill counter had no matching event/PID/time or pre-failure
baseline. The full-run RSS/resource samples do not establish OOM or exclude it.
Do not infer an OOM, GUI regression, test-order defect or outer-runner policy from
this evidence. Preserve the interruptions and keep full/native qualification
pending. No additional execution was performed for this diagnosis record.
