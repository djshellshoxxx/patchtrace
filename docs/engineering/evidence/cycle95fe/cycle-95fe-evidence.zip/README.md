# PatchTrace cycle 95fe evidence

This archive preserves byte-for-byte copies of the captured raw receipts, logs,
JUnit reports, source diffs, donor mappings, inventory inputs and replay output.
It is a source-specific evidence checkpoint, not a full application acceptance.

## Source identity and history

- Base stack: `67f7e08ea9bee61653f8ab5ad66048d3e7141810`.
- Combined tested code source: `ccc3664f11a81d3d30f907da36fc3d22da0063d0`.
- Complete tested code tree: `a72efdcbf503e0480a182fd323c5c4320d27c098`.
- The separate `local-code-history.bundle` preserves all nine local commits
  after the base, including the three local merge commits and ordered parents.
- Bundle SHA-256: `81d15e5383e3aa7ddd7a8826122f4499789f2c97375525eebaf4316bcdf93517`; size: 16743 bytes.
- The bundle requires the base commit and its reachable objects. Verify it with
  `git bundle verify local-code-history.bundle` in a clone containing that base.
- `local-code-history.json` records the ordered commits and their trees/parents.

The code source above predates the documentation/evidence publication commit.
Remote Git Data API commit IDs, if used by the coordinator, may differ; exact
tree equality and the separately recorded local/remote mapping establish content
identity. This archive makes no assertion about any later publication head.

## Completed bounded combined-source checks

`combined-admission` passed 183 cases and `combined-changed-cases` passed 50.
Their JUnit `(classname, name)` sets overlap by 21 cases: **212 distinct passing
cases across two bounded runs**, with no failures, errors or skips. Both receipts
record the exact combined commit/tree above and a clean worktree before/after.
The receipt wall times are 13.170 and 4.758 seconds, respectively; pytest's own
test durations can differ. `checks.json` records the verified set arithmetic.

Whole-tree Ruff passed on this combined source. The inventory replay is exactly
byte-identical to the captured 353-topic-branch inventory. Its SHA-256 is
`d82d52544646eb029f38684e2dd3802ffa1596c7eb02d5c11d0ae0b5783aa902`.

## Worker and baseline evidence remains separate

Earlier worker results belong to their own source identities: 183 related
admission cases on clean `649ed46e`; 212 GUI cases on the working diff subsequently
committed as `2c7f506b`; and 47 coverage cases on the working diff subsequently
committed as `c71d604e`. The two handoffs verify tested/committed diff equality.
The worker GUI count of 212 is a different test set and source from the 212
distinct combined-source cases. The ten fixed inventory tests were run
on the working changes subsequently committed as `076c1ffa`; the clean combined
50-case run later includes all ten. Preserve the exact dirty-state/source details
in each original receipt. Do not sum these overlapping selections.

The baseline failures in admission, GUI and inventory receipts remain unchanged.
They demonstrate the particular repaired behaviors; they are not failures of the
final combined-source checks. Coverage-only additions do not claim a production
defect or a failing baseline. The earlier g41 selection has its own source and
one native Windows-only skip.

## Interrupted and outstanding qualification

Four clean combined-source attempts terminated with SIGKILL (return code -9):
full (23.089 seconds), 27-file combined-focused (70.395), combined-gui (32.827),
and combined-integrity-coverage (21.474). They produced no terminal pytest summary
or JUnit. The full-run phase log has only session-start, before a first test-start.
Progress dots from interrupted runs are not counted as completed passing cases.
The kill sender and cause are unestablished. `diagnosis.md` records the limit of
the available evidence; no OOM or GUI-regression attribution is warranted.

No full-suite, final-source native Windows/Linux/package, actual screen-reader,
release or deployment acceptance is claimed here. Earlier PR check snapshots
qualify only their recorded source. This archive preserves those snapshots as
history rather than transferring their results to the new candidate.

## Reproducibility and integrity

`MANIFEST.json` lists every other ZIP member, byte count and SHA-256. Raw members
are unchanged source bytes under `raw/`. Generated explanatory/check/history
records are marked separately. The ZIP uses sorted names, fixed 2026-11-20
00:00:00 metadata, regular-file permissions and deterministic deflate settings;
this timestamp is archive metadata, not the tests' execution time.

The build verified all raw source bytes against the archived bytes, extracted
and hashed every member, and rebuilt the ZIP to check byte-for-byte identity.
Narrow credential-signature screening found no matches; it is not a universal
secret-detection guarantee. No tests or target binaries were executed to build
this pack. No repository file or source ref was modified by the pack builder.
