# Frozen stable full-suite stall: bounded diagnosis

## Observed result

The full run stopped emitting progress after **1,232 outcomes: 1,231 pass dots and one skip**. The raw log had 1,368 bytes and last changed at **2026-11-19 08:39:15.121890 UTC**. The retained progress snapshot is byte-exact. This is an incomplete run, not a full-suite pass or an identified test failure.

A separate bounded collection in the same frozen source returned **23,313 tests collected in 24.55 s** (29.21 s wall), exit zero. Root confirmed the original run used plain `pytest -q` with only its JUnit output argument, `PYTHONPATH=src`, and offscreen Qt. Default collection order therefore maps the boundary as follows:

| Position | Test |
|---|---|
| 1,231 | `tests/test_bindiff_run.py::test_stderr_flood_and_writes_outside_out_do_not_break_result` |
| 1,232: last reported outcome | `tests/test_bindiff_run.py::test_output_limit` |
| 1,233: next case | `tests/test_bindiff_run.py::test_timeout_kills_tree_and_records_kind` |
| 1,234 | `tests/test_bindiff_run.py::test_cancel_stops_run` |

A progress dot can precede fixture teardown, so the mapping alone cannot locate the blocked stack. Additional filesystem evidence supports entry into the timeout case: its authored grandchild heartbeat exists at `/tmp/pytest-of-agent/pytest-82/test_timeout_kills_tree_and_recurrent/bd/heartbeat.txt`. It contains 55 bytes and last changed at **2026-11-19T08:39:18.329921+00:00**, roughly three seconds after the last test progress. Both private engine directories recorded in its spy calls are already absent. This supports child termination and cleanup having advanced, but does not establish where the Python test runner stopped.

## Test and dependency inspection

The suspect case uses authored fake BinDiff/BinExport data, with no native BinDiff or network dependency. It asks `jobs.run_process` for a **3.0 s** timeout, asserts elapsed time under **60 s**, and checks that a started grandchild heartbeat stops. The fake grandchild itself has an indefinite heartbeat loop; the test relies on process-tree containment. The test's `<60` assertion is reached only after `go()` returns and is not an independent timeout.

The supervisor polls a fixed deadline, kills the owned process group, bounds child waits and reader joins at five seconds, and cleans private output. The scheduler waits for its worker future and joins its pool. The autouse Qt modal watchdog applies only to tests with `qtbot` or `window`; this case has neither. No global outer pytest timeout is configured for this test. Source inspection alone did not reproduce or isolate the original hang.

## Bounded exact-case reproduction

The adjacent output-limit and timeout cases ran once, in their original order, using the dedicated stable venv and frozen stable worktree:

- Commit: `a25db213a1ecb5d8a360a422dacedc925deababa` (documentation descendant of source `4cdee5a26837802bd90b8b50c11696b039ac9335`).
- Production source tree: `97ab627e0416f3e389f3ea4822899905e5f55f4e`.
- **2 passed in 6.23 s**, exit zero; outer wall time **8.76 s**.
- A **60 s outer process deadline** and **40 s faulthandler dump** were configured. Neither fired.
- Only the owned subprocess would have been terminated on timeout. No kill was needed.
- Cache/bytecode writes were disabled; no source or shared-venv mutations occurred.

The exact command and output are retained in `stable-stall-focused-result.json`, `stable-stall-focused.log` and `stable-stall-focused.xml`.

The stall **did not reproduce** under this bounded sequence. Per root's instruction, no untouched-main comparison or broader repeat was started. The isolated success does not establish a host failure, erase the original incomplete run, or qualify the full candidate. Root owns interruption and any original-session stack evidence.

## Artifacts

`stable-full-stall-diagnosis.json` retains counts, surrounding nodes, exact source blobs, filesystem observations, command/runtime details and SHA-256 values for the raw progress snapshot, complete collection output, and focused run evidence.
