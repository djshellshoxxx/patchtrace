# Issues #120 and #121: bounded current-source review

Recorded 2026-11-19T09:00:27.648186+00:00. Both issue bodies were retrieved live during this audit and remained open with zero comments. Original audit source: `5ed624e91468c410f2cf738ed4e36c2be3e0201d`.

## Outcome

**All five issue #120 findings are repaired in new main.** Their relevant source blobs are identical between the audited stable candidate and main. Issue #121 contains repaired defects, a newly repaired CI setup defect, and broader native/release/resource qualification items. It should not be marked wholly resolved on the strength of this bounded audit.

- Audited stable source: `40d27a0cbe95ab1ff8a422313af7f45449219554`; tree `f65687ac6dd46f1b50466165eef2d0076eabd474`.
- New main: `fdc2696c23bdbfe7668348f25e3b336ce33039f7`; tree `af464108043aaa42b527a473985350a4daadc0d2`.
- Fresh focused run: **135 passed, zero failures/errors/skips, 12.00 s**. JUnit suite time is 11.741 s. This is not a full-suite or native qualification claim.
- The primary environment-default repair is present on stable through `0b2d7a142d313bc0a49e7c5b0359a31350b29463`, but is not yet in the audited main.
- Isolated native setup repair is ready at `52b711eb5a40be78ec84d267e2a3dfc1f000413b`; seven new controls independently passed in 2.86 s. Exact-candidate native matrix results remain required.

## [Issue #120](https://github.com/djshellshoxxx/patchtrace/issues/120)

Live issue updated `2026-10-30T04:08:30Z`; state `open`. These dispositions describe exact inspected source, not an issue closure.

| Finding | Current disposition | Evidence and practical scope |
|---|---|---|
| 1. Ambiguous one-to-one manual correction promoted to matched | `REPAIRED_IN_MAIN` | manual/5 admits only affirmative one-to-one decisions as matched. Ambiguous input remains an ambiguous group; unresolved members do not form partial pairs. Sources: [manual.py](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/src/patchtrace/unified/sources/manual.py). |
| 2. Manual source identity omits persisted content | `REPAIRED_IN_MAIN` | manual_digest_of includes every field of each complete validated match model_dump(mode=json), rather than an incomplete selected-field signature. Sources: [manual.py](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/src/patchtrace/unified/sources/manual.py). |
| 3. Secondary source identity omits validated normalized content | `REPAIRED_IN_MAIN` | source_ref_of binds the validated body digest or the canonical complete ordered normalized matches and alternatives; raw file identity is separate. Sources: [secondary.py](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/src/patchtrace/unified/sources/secondary.py). |
| 4. Alternative source/anchor/candidate identities not cross-validated | `REPAIRED_IN_MAIN` | AlternativeMatch validates source against candidate engine and anchor address against the chosen side; SecondaryMatchSet validates engine/version consistency and per-anchor limits. Sources: [contracts.py](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/src/patchtrace/secondary/contracts.py). |
| 5. rz-diff preparation permits a 1-TiB uninterruptible copy | `REPAIRED_IN_MAIN` | Preparation uses MAX_ARTIFACT_BYTES (1 GiB), checks cancellation and the shared preparation/execution deadline between copy chunks, and passes remaining time to the engine. Copy admission uses an exclusive destination and a held regular-file identity. **Limit:** The tool capability probe has its own budget. This does not establish native engine accuracy, containment or complete resource qualification. Sources: [scheduler.py](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/src/patchtrace/secondary/scheduler.py), [bindiff_inputs.py](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/src/patchtrace/secondary/bindiff_inputs.py). |

## [Issue #121](https://github.com/djshellshoxxx/patchtrace/issues/121)

Live issue updated `2026-10-30T04:07:57Z`; state `open`. These dispositions describe exact inspected source, not an issue closure.

| Finding | Current disposition | Evidence and practical scope |
|---|---|---|
| 1. Release job prerequisites omit Qt/native gates | `PARTIAL_POLICY_AND_NATIVE_GATE_REMAIN` | The current package/release DAG includes qt-gate. Native qualification is not an automatic release prerequisite. The current milestone specification distinguishes automatic integration beta builds from acceptance candidates, which require applicable native evidence. **Limit:** No release-policy rewrite or native qualification was authorized in this bounded audit. L1-L3, native accuracy and containment remain separate gates. Sources: [qa-windows.yml](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/.github/workflows/qa-windows.yml), [windows-acceptance-and-milestone-builds.md](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/docs/specs/windows-acceptance-and-milestone-builds.md). |
| 2. Backup/prune trusts metadata-only fingerprints | `REPAIRED_IN_MAIN` | Trusted reuse requires fresh byte hashes from held descriptors, with two full-byte observations and identity checks. Publication uses a unique stage, no-replace publication and post-publication admission. Pruning requires a trusted eligible backup and completed owned-stage cleanup. **Limit:** The documented cooperative-filesystem contract is retained. Portable controls do not prove native Windows behavior or exclusion of arbitrary writers after the admission check. Sources: [verified_backup.py](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/src/patchtrace/verified_backup.py), [persistence.py](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/src/patchtrace/persistence.py). |
| 3. Primary child process inherits parent secrets by default | `REPAIRED_IN_STABLE_PENDING_MAIN` | BackendConfig.restrict_env defaults to True in the stable candidate via the selected #311 repair. The explicit compatibility opt-out remains available. New main still has the earlier backend blob. **Limit:** Portable default/environment controls passed. Actual native H7/cache results on the combined candidate remain required. Sources: [backend.py](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/src/patchtrace/backend.py). |
| 4. Diaphora sliding deadline and resource limits | `DEADLINE_REPAIRED_RESOURCE_QUALIFICATION_OPEN` | Snapshot.rows uses one total iterator deadline and checks around fetch/yield rather than granting each row a new budget. Database/row limits remain 256 MiB, 500,000 matches and 200,000 unmatched rows. **Limit:** This does not establish a whole-import RSS cap or native memory headroom. Sources: [sqlite_guard.py](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/src/patchtrace/diaphora/sqlite_guard.py), [result_import.py](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/src/patchtrace/diaphora/result_import.py). |
| 5. Verified artifact cache trusts restored metadata | `REPAIRED_IN_MAIN` | Initial verification records content block digests; each returned range is checked against those digests using the returned bytes. File metadata is only a hint. Sources: [artifact_bytes.py](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/src/patchtrace/artifact_bytes.py). |
| 6. Native seeded-store setup masks child failures | `MINIMAL_REPAIR_READY_NATIVE_MATRIX_PENDING` | The old positive setup unconditionally cleared LASTEXITCODE without checking seed or symbol-enabled engine success. Pinned upstream only documents the deliberate cached-PDB exception under no_symbols. The isolated repair checks both child processes, stops before the engine on seed failure, and preserves the separate asserted negative reproduction. **Limit:** Seven controls independently passed; GUI worker recorded 97 related controls. Neither run executes PowerShell/Ghidra or qualifies persisted Windows preferences. Sources: [live-backend.yml](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/.github/workflows/live-backend.yml), [live_symbol_store_setup.py](https://github.com/djshellshoxxx/PatchTrace/blob/52b711eb5a40be78ec84d267e2a3dfc1f000413b/tools/live_symbol_store_setup.py), [test_live_symbol_store_setup.py](https://github.com/djshellshoxxx/PatchTrace/blob/52b711eb5a40be78ec84d267e2a3dfc1f000413b/tests/test_live_symbol_store_setup.py). |
| 7. Build dependencies and actions not fully reproducible | `BROADER_REPRODUCIBILITY_GAP_REMAINS` | Dependency ranges and mutable action tags remain broader reproducibility work. NSIS is requested by package version 3.13 without a digest pinned in this workflow. The release-mutating action is pinned, which does not make every build input immutable. **Limit:** No broad dependency, packaging or action-pin update was included in this audit. Sources: [pyproject.toml](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/pyproject.toml), [qa-windows.yml](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/.github/workflows/qa-windows.yml). |
| 8. Primary engine lacks generic memory and total-output caps | `NATIVE_RESOURCE_GATE_REMAINS` | The primary backend has timeout and output-file checks but does not request generic run_process memory_limit or max_output_bytes caps. The existing JVM/native-headroom architecture exception remains explicit. **Limit:** No unmeasured cap was invented. Native containment and suitable resource-budget evidence remain separate qualification work. Sources: [backend.py](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/src/patchtrace/backend.py). |
| 9. Four failing tests at the old PR #110 head | `HISTORICAL_FAILURE_CURRENT_GATE_REQUIRED` | The issue identifies an old exact source. Those results remain historical evidence and are not transferred to the current candidate. This audit ran only the named 135 controls; root owns fresh combined full-suite/hosted qualification. **Limit:** No claim that the current full suite or native CI passed follows from this bounded run. |
| 10. NavResult.ambiguous consumes an arbitrary iterable without a scan cap | `LATENT_API_LIMIT_NO_CURRENT_PRODUCTION_REPRO` | Only two production call sites were found: locate_match passes a finite list from MatchIndex.functions_for, and the strings panel passes a generator over found[:20]. GUI framework §3.4 caps retained candidates at 20; tests explicitly require the total count. No production infinite-iterator path was identified. **Limit:** The public iterable API remains unbounded in scan length. A scan/time budget would alter exact-count semantics and needs a separately defined contract; no change made. Sources: [anchors.py](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/src/patchtrace/gui/anchors.py), [projection.py](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/src/patchtrace/gui/projection.py), [qt_panel.py](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/src/patchtrace/strings/qt_panel.py), [gui-framework.md](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/docs/specs/gui-framework.md), [test_gui_core_anchors.py](https://github.com/djshellshoxxx/PatchTrace/blob/40d27a0cbe95ab1ff8a422313af7f45449219554/tests/test_gui_core_anchors.py). |

## Repair lineage and existing receipts

The exact representative repair commits below were checked as ancestors of new main. Machine-readable JSON includes full commit identities, per-path Git blobs and main/stable comparisons.

| Boundary | Existing repair lineage | Existing receipts |
|---|---|---|
| Manual/secondary identity | `15deb8f28e207a9679379265571d2691de52e7e2` | `docs/qa/identity-main-repair-20261101.md`; identity regression controls |
| rz-diff preparation | `ea9d04f64b3b723213b603f57af87ff2c14e153d`, `8244ec7e7437203d31d6b271a3065fb17cb084f2` | `tests/test_audit120_rzdiff_prep.py` and existing copy-admission controls |
| Backup fresh bytes, publication and prune admission | `bf35ad49`, `ad634163`, `7d9dce5c`, `9c468bc7`, `1f284a19`, `9911af4d`, `f1a55c4c` | `docs/qa/backup-byte-stability-20261102.md`, `backup-completion-20261102.md`, `backup-publication-admission-20261102.md`, `backup-publication-collision-20261101.md`, `backup-reuse-filter-20261102.md`, `backup-stat-api-recovery-20261102.md`, `backup-windows-review-20261102.md` |
| Diaphora total iteration deadline | `bf35ad49cb2e950cc040bd45a39c7a755cc953d2` | `tests/test_diaphora_deadline.py` |
| Artifact content-block verification | `e5f9302e20ee37e8e3323a8d8b177fd8b0649e6a` | `tests/test_artifact_bytes.py`; original restored-metadata regression/repair receipts in `docs/qa.md` |

Historical receipts retain their original source and platform limits. Their pass counts were not added to the fresh 135-test total. The later backup amendments in `docs/specs/enrichment-hardening-backlog.md` supersede its older metadata-only description.

## Fresh focused controls

| Test module | Passed |
|---|---:|
| `tests.test_unified_evidence_identity_20261101` | 21 |
| `tests.test_secondary_alternative_identity_20261101` | 10 |
| `tests.test_audit120_rzdiff_prep` | 6 |
| `tests.test_verified_backup_byte_integrity` | 13 |
| `tests.test_verified_backup_publication_admission` | 17 |
| `tests.test_verified_backup_reuse_filter` | 4 |
| `tests.test_verified_backup_stat_api` | 9 |
| `tests.test_prune_backup` | 11 |
| `tests.test_diaphora_deadline` | 7 |
| `tests.test_artifact_bytes` | 24 |
| `tests.test_primary_environment_defaults` | 13 |

```sh
QT_QPA_PLATFORM=offscreen PYTHONPATH=src <shared-venv>/python -m pytest -q \
  tests/test_unified_evidence_identity_20261101.py \
  tests/test_secondary_alternative_identity_20261101.py \
  tests/test_audit120_rzdiff_prep.py tests/test_verified_backup_*.py \
  tests/test_prune_backup.py tests/test_diaphora_deadline.py \
  tests/test_artifact_bytes.py tests/test_primary_environment_defaults.py \
  --junitxml=/workspace/scratch/80dddc5347b2/issues-120-121-current-core.xml
```

Raw evidence: `issues-120-121-current-core.log` and `.xml`. Their SHA-256 values are in the JSON report. No additional whole-suite run was started; root owns combined candidate qualification.

## Native setup defect: why the reset was incorrect

The setup step is symbol-enabled. It populates the retained symbol store, then launches upstream Ghidriff to establish the persisted configuration used by three matrix variants. The old code did not check either child status and ended with an unconditional `LASTEXITCODE = 0`. The later plain `--no-symbols` reproduction is different: it requires a nonzero status and the specific cached-PDB diagnostic before resetting the status.

The [pinned upstream source](https://github.com/clearbluejar/ghidriff/blob/4f5d895fcbb1eacd65efd81145922c15bb7e741d/ghidriff/ghidra_diff_engine.py) places the deliberate cached-PDB exception under `no_symbols`. `setup_symbol_server` saves the preferences during the positive setup path. No documented allowance for nonzero positive setup or independent postcondition check was found. Consequently the reset could falsely qualify an unseeded or failed setup.

The delegated isolated repair has three commits, in order:

1. `e4c73786517163e1f5874aa658341f80ae5b14c3` — specification and seven controls.
2. `eb65f7fe9991167fb77c6f620240c46edc6ac702` — small CI-only checked runner and workflow call.
3. `52b711eb5a40be78ec84d267e2a3dfc1f000413b` — original baseline/red evidence and fresh qualification receipts.

Independent review found no blocking defect. The helper keeps `sys.executable`, original list arguments and inherited environment. Both subprocesses must succeed, the first failure stops further setup, and output streams directly without a Python log buffer. A structured YAML comparison confirmed that all other workflow values are identical after accounting only for the setup command and new helper path filter. The production `src/` tree is unchanged.

Seven authored-child controls passed independently in 2.86 s, and the worker recorded 97 related controls in 3.81 s plus whole-tree Ruff. The full repair range passes `git diff --check`. Portable tests verify real seed-file copies, failure stopping the next child, and engine exits 1 and 23. They do not execute PowerShell or native Ghidra. Source/evidence live at `PatchTrace-native-seed/docs/qa/native-symbol-setup-20261119/`.

## Anchor iterable scope

`NavResult.ambiguous` stores at most 20 candidates but counts the entire supplied iterable. The production call graph contains two callers: `gui/anchors.py::locate_match` supplies a finite list built from `MatchIndex.functions_for` (a tuple from an already-built finite project index); `strings/qt_panel.py::show_anchor` supplies a generator over `found[:20]`.

`docs/specs/gui-framework.md` §3.4 specifies the retained-candidate cap. `tests/test_gui_core_anchors.py::test_ambiguity_lists_candidates_up_to_twenty_but_counts_them_all` deliberately requires an exact total. An arbitrary external infinite generator remains a latent API limitation, but no current production route supplying one was found. A count/time budget would require a new truncated-count contract. No such change was made under this bounded audit.

## Scope and handoff

Core inspection and the 135-test run used a clean detached worktree at the pinned stable source. The only new repair is the isolated CI setup slice; neither main nor the stable worktree was edited. No remote actions or issue closures were performed. Preserve broader native release prerequisites, L1-L3 accuracy, resource limits, packaging, and exact-candidate hosted qualification as distinct unresolved gates.
